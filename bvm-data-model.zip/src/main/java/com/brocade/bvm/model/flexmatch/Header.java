package com.brocade.bvm.model.flexmatch;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Setter
@Getter
/*
Represents Flex Match Header POJO
 */
public class Header {

    private String id;

    private String name;

    private Integer headerLevel;

    private Integer headerLength;

    private Boolean isSupported = true;

    private Set<Field> subHeaders;

    private Set<Field> fields;
}
