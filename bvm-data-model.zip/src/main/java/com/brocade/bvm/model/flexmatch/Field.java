package com.brocade.bvm.model.flexmatch;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
/*
Represents Flex Match Header Field POJO
 */
public class Field {

    private String id;

    private String name;

    private Integer value;

    private Integer byteSize;

    private Boolean isSupported = true;
}
