package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PacketStampingModulePolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Entity(name = "packet_stamping_module_policy")
@Polymorphism(type= PolymorphismType.EXPLICIT)
@Slf4j
public class PacketStampingModulePolicy extends ModulePolicy implements HasHistory {

    @Column(name = "processor_number")
    @Setter
    @Enumerated(EnumType.STRING)
    private ProcessorNumber processor;

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    public enum ProcessorNumber {
        ALL("0"),
        ONE("1"),
        TWO("2");

        private String processorNumber;

        ProcessorNumber(String number) {
            this.processorNumber = number;
        }

        public String getProcessorNumber() {
            return this.processorNumber;
        }
    }


    @Override
    public HistoryObject buildHistory() {
        PacketStampingModulePolicyHistory policyHistory = new PacketStampingModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(PacketStampingModulePolicy.class, new PacketStampingModulePolicy.PacketStampingModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the PacketStampingModulePolicy Object in History", e);
        }
        return policyHistory;
    }


    private class PacketStampingModulePolicyJsonSerializer extends JsonSerializer<PacketStampingModulePolicy> {
        @Override
        public void serialize(PacketStampingModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                jsonGenerator.writeStringField("processor", String.valueOf(getProcessor().getProcessorNumber()));
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }
}
