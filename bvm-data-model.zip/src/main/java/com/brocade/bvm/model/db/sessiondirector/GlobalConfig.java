package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.GlobalConfigHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.io.IOException;
import java.util.Set;

@Getter
@Entity(name = "sd_global_config")
public class GlobalConfig extends ManagedObject implements HasHistory {

    public static final Integer FCR_TIMER_DEFAULT = 10;

    public static final Integer SIP_PORTS_MAX_SIZE = 10;

    public static final Integer SIP_PORT_MIN_RANGE = 1;

    public static final Integer SIP_PORT_MAX_RANGE = 65355;

    public static final Integer SIP_PORT_DEFAULT = 5060;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Mode mode;

    @Setter
    @Column(name = "fcr_status")
    private Boolean fcrStatus;

    @Setter
    @Min(value = 10)
    @Max(value = 1440)
    @Column(name = "fcr_mtime")
    private Integer fcrFileTime;

    @Setter
    @Column(name = "s11_drop_status")
    private Boolean s11DropStatus;

    @Setter
    @Column(name = "rx_tx_split_status")
    private Boolean rxTxSplitStatus;

    @Setter
    @Column(name = "sgi_correlation_status")
    private Boolean sgiCorrelationStatus;

    @Setter
    @Column(name = "ip_fragmentation_status")
    private Boolean ipFragmentationStatus;

    @Setter
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "sip_port_mapping", joinColumns = @JoinColumn(name = "global_config_id"))
    @Column(name = "sip_port_no")
    private Set<Integer> sipPorts;

    public ImmutableSet<Integer> getSipPorts() {
        return ImmutableSet.copyOf(sipPorts);
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    public enum Mode {
        SINGLE,
        MULTINODE
    }

    @Override
    public HistoryObject buildHistory() {
        GlobalConfigHistory globalConffigHistory = new GlobalConfigHistory();
        globalConffigHistory.setName(getName());
        globalConffigHistory.setDevice(this.device);
        globalConffigHistory.setWorkflowStatus(getWorkflowStatus());
        globalConffigHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(GlobalConfig.class, new GlobalConfig.GlobalConfigJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            globalConffigHistory.setGlobalConfigJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to create Global Config history", e);
        }
        return globalConffigHistory;
    }

    private class GlobalConfigJsonSerializer extends JsonSerializer<GlobalConfig> {
        @Override
        public void serialize(GlobalConfig globalConfig, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", globalConfig.getId());
                jsonGenerator.writeStringField("name", globalConfig.getName());
                jsonGenerator.writeStringField("mode", globalConfig.getMode().name());
                jsonGenerator.writeNumberField("fcrFileTime", globalConfig.getFcrFileTime());
                jsonGenerator.writeObjectField("sipPorts", globalConfig.getSipPorts());
                jsonGenerator.writeBooleanField("fcrStatus", globalConfig.getFcrStatus());
                jsonGenerator.writeBooleanField("s11DropStatus", globalConfig.getS11DropStatus());
                jsonGenerator.writeBooleanField("rxTxSplitStatus", globalConfig.getRxTxSplitStatus());
                jsonGenerator.writeBooleanField("sgiCorrelationStatus", globalConfig.getSgiCorrelationStatus());
                jsonGenerator.writeBooleanField("ipFragmentationStatus", globalConfig.getIpFragmentationStatus());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
