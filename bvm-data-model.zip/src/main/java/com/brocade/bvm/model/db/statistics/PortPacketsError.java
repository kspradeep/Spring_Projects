package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortPacketsError {
    private long inPacketsError;
    private long outPacketsError;
    private String lastUpdatedTime = "0";
}
