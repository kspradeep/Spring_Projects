package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.SlxPtpPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "slx_ptp_policy_history")
public class SlxPtpPolicyHistory extends HistoryObject<SlxPtpPolicy> {
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "device_policy_json")
    private String devicePolicyJson;

    @Override
    public SlxPtpPolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        SlxPtpPolicy devicePolicy = null;
        try {
            devicePolicy = mapper.readValue(devicePolicyJson, SlxPtpPolicy.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the SlxPtpPolicy", e);
        }
        return devicePolicy;
    }
}
