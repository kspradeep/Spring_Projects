package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.time.Instant;

/**
 * Represents a history record of  {@link HasHistory}
 * Type4 https://en.wikipedia.org/wiki/Slowly_changing_dimension
 */
@Getter
@MappedSuperclass
public abstract class HistoryObject<T extends ManagedObject> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /*
    Parent object represented by the history record. Eg. PolicyHistory will have parent sent to the Policy object.
     */
    @Setter
    @Column(name = "parent_id")
    private Long parentId;

    @Setter
    @Column(name = "revision_type")
    @Enumerated(EnumType.STRING)
    private RevisionType revisionType;

    @Setter
    @Column(name = "revision_time")
    private Instant revisionTime;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "workflow_status")
    @Enumerated(EnumType.STRING)
    private WorkflowParticipant.WorkflowStatus workflowStatus;

    @Setter
    @Column(name = "workflow_type")
    @Enumerated(EnumType.STRING)
    private Job.Type workflowType;

    public enum RevisionType {
        CREATED, UPDATED, DELETED
    }

    /**
     * Deserialize {@link HistoryObject} to {@link HasHistory}
     */
    abstract T buildParent();
}
