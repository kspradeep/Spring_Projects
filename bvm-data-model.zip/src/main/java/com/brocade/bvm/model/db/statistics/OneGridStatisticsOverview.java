package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class OneGridStatisticsOverview {
  private long packetDifInTapAndTool;
  private List<String> topFivePolicies = new ArrayList<>();
  private int portOverThreshold;
  private List<AllPoliciesAndHitCount> allPoliciesAndHitCounts = new ArrayList<>();
}
