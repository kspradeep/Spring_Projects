package com.brocade.bvm.model.db;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;

@Getter
@Entity(name = "device_policy")
@Inheritance(strategy = InheritanceType.JOINED)
//The @Polymorphism is used to prevent from creating a 61 Join issue.
//This will ensure to pull only the sub classes of the current class but not the sub-classes of the parent class.
//This way it ensures to pull data only from the relevent sub-classes only.
// References: https://docs.jboss.org/hibernate/orm/5.0/javadocs/org/hibernate/annotations/PolymorphismType.html#EXPLICIT
//To Understand Implicit and Explicit : https://v4forums.wordpress.com/2008/12/27/implicit-explicit-polymorphism-in-hibernate/
@Polymorphism(type= PolymorphismType.EXPLICIT)
@Slf4j
public abstract class DevicePolicy extends ManagedObject {

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    //for getting the policy types for fetching global policies
    public enum Type {
        gtp_device_policy,
        mpls_device_policy,
        reserved_vlan_device_policy,
        slx_ptp_policy,
        tunnel_device_policy
    }
}
