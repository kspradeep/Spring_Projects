package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.EgressPortHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "sd_egress_port")
public class EgressPort extends ManagedObject implements Comparable<EgressPort>, HasHistory {

    public static final Integer VLAN_MIN = 2;
    public static final Integer VLAN_MAX = 2045;
    public static final Integer VLAN_INCREMENT_VALUE = 2045;

    public static final Integer IMSI_MIN = 0;
    public static final Integer IMSI_MAX = 10000000;

    @Setter
    @Column(name = "load_balance")
    @Enumerated(EnumType.STRING)
    private LoadBalanceAlgorithms loadBalance;

    @Setter
    @Column(name = "imsi_limit")
    private String imsiLimit;

    @Setter
    @Column(name = "is_default")
    private boolean isDefault;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @Setter
    @Transient
    @Enumerated(EnumType.STRING)
    private ACTION action;

    @Setter
    @Transient
    private Set<Long> taggedVlanIds = new HashSet<>();

    @Setter
    @Transient
    private Set<Long> untaggedVlanIds = new HashSet<>();

    @OneToMany(mappedBy = "sdPort", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<SdPortVlanMapping> vlanMappings = new HashSet<>(); //some devices accept regex strings like "any" for vlan

    public Set<SdPortVlanMapping> getVlanMappings() {
        return ImmutableSet.copyOf(vlanMappings);
    }

    public void addVlanMappings(Set<SdPortVlanMapping> vlanMappings) {
        this.vlanMappings.addAll(vlanMappings);
        vlanMappings.forEach(vlanMapping -> vlanMapping.reverseMapSdPort(this));
    }

    public void removeVlanMappings(Set<SdPortVlanMapping> vlanMappings) {
        this.vlanMappings.removeAll(vlanMappings);
    }

    public void setVlanMappings(Set<SdPortVlanMapping> vlanMappings) {
        this.vlanMappings.clear();
        addVlanMappings(vlanMappings);
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "egress_port_id", referencedColumnName = "id")
    private Port sourcePort;

    @JsonDeserialize
    public void setSourcePort(Port sourcePort) {
        this.sourcePort = sourcePort;
    }

    public enum ACTION {
        ADD,
        DELETE,
        UPDATE,
        RECOVERY
    }

    public enum LoadBalanceAlgorithms {
        HASH("hash"),
        ROUND_ROBIN("round-robin");

        private String loadBalanceAlgorithms;

        LoadBalanceAlgorithms(String loadBalanceAlgorithms) {
            this.loadBalanceAlgorithms = loadBalanceAlgorithms;
        }

        public String getName() {
            return this.loadBalanceAlgorithms;
        }
    }

    @Override
    public HistoryObject buildHistory() {
        EgressPortHistory portHistory = new EgressPortHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(EgressPort.class, new EgressPort.PortJsonSerializer());
        portHistory.setName(getName());
        portHistory.setWorkflowStatus(getWorkflowStatus());
        portHistory.setWorkflowType(this.getWorkflowType());
        mapper.registerModule(simpleModule);
        try {
            portHistory.setPortJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to create sd egress port history", e);
        }
        return portHistory;
    }

    private class PortJsonSerializer extends JsonSerializer<EgressPort> {
        @Override
        public void serialize(EgressPort egressPort, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", egressPort.getId().longValue());
                jsonGenerator.writeStringField("name", egressPort.getName());
                jsonGenerator.writeObjectField("loadBalance", egressPort.getLoadBalance());
                jsonGenerator.writeStringField("imsiLimit", egressPort.getImsiLimit());
                jsonGenerator.writeBooleanField("default", egressPort.isDefault());
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", egressPort.getDevice().getId());
                jsonGenerator.writeEndObject();
                if (egressPort.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", egressPort.getWorkflowStatus().name());
                }
                if (egressPort.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", egressPort.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("vlanMappings");
                egressPort.getVlanMappings().forEach(vlanMapping -> {
                    try {
                        jsonGenerator.writeObject(vlanMapping);
                    } catch (Exception e) {
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }

    @Override
    public int compareTo(@NotNull EgressPort other) {
        return compare(this.getName(), other.getName());
    }

    private final boolean isDigit(char ch) {
        return ((ch >= 48) && (ch <= 57));
    }

    /**
     * Length of string is passed in for improved efficiency (only need to calculate it once)
     **/
    private final String getChunk(String s, int slength, int marker) {
        StringBuilder chunk = new StringBuilder();
        char c = s.charAt(marker);
        chunk.append(c);
        marker++;
        if (isDigit(c)) {
            while (marker < slength) {
                c = s.charAt(marker);
                if (!isDigit(c))
                    break;
                chunk.append(c);
                marker++;
            }
        } else {
            while (marker < slength) {
                c = s.charAt(marker);
                if (isDigit(c))
                    break;
                chunk.append(c);
                marker++;
            }
        }
        return chunk.toString();
    }

    public int compare(String s1, String s2) {
        if ((s1 == null) || (s2 == null)) {
            return 0;
        }

        int thisMarker = 0;
        int thatMarker = 0;
        int s1Length = s1.length();
        int s2Length = s2.length();

        while (thisMarker < s1Length && thatMarker < s2Length) {
            String thisChunk = getChunk(s1, s1Length, thisMarker);
            thisMarker += thisChunk.length();

            String thatChunk = getChunk(s2, s2Length, thatMarker);
            thatMarker += thatChunk.length();

            // If both chunks contain numeric characters, sort them numerically
            int result = 0;
            if (isDigit(thisChunk.charAt(0)) && isDigit(thatChunk.charAt(0))) {
                // Simple chunk comparison by length.
                int thisChunkLength = thisChunk.length();
                result = thisChunkLength - thatChunk.length();
                // If equal, the first different number counts
                if (result == 0) {
                    for (int i = 0; i < thisChunkLength; i++) {
                        result = thisChunk.charAt(i) - thatChunk.charAt(i);
                        if (result != 0) {
                            return result;
                        }
                    }
                }
            } else {
                result = thisChunk.compareTo(thatChunk);
            }

            if (result != 0)
                return result;
        }
        return s1Length - s2Length;
    }
}
