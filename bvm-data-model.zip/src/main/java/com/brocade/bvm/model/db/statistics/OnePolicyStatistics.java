package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class OnePolicyStatistics {
    private long packetHitCounts;
    private long byteCounts;
}
