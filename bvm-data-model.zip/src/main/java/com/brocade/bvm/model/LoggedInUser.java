package com.brocade.bvm.model;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.inject.Named;

@Named
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class LoggedInUser {

	public String getUsername() {
		return SecurityContextHolder.getContext().getAuthentication().getName();
	}
	
	public String getPassword() {
		return SecurityContextHolder.getContext().getAuthentication().getCredentials().toString();
	}
}
