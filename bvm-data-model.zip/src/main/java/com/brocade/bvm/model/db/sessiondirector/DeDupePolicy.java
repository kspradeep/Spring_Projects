package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.history.DedupePolicyHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.IOException;

@Getter
@Setter
@Entity(name = "dedupe_policy")
@Slf4j
public class DeDupePolicy extends SdPolicy implements HasHistory {

    public static final Integer DEFAULT_TIMEOUT = 50;

    @Column
    private Integer timeout;

    @Override
    public HistoryObject buildHistory() {
        DedupePolicyHistory dedupePolicyHistory = new DedupePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(DeDupePolicy.class, new DeDupePolicy.PolicyJsonSerializer());
        dedupePolicyHistory.setName(getName());
//        dedupePolicyHistory.setDevice(getDevice());
        dedupePolicyHistory.setWorkflowStatus(getWorkflowStatus());
        dedupePolicyHistory.setWorkflowType(this.getWorkflowType());
        mapper.registerModule(simpleModule);
        try {
            dedupePolicyHistory.setPolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to create sd DeDupePolicy history", e);
        }
        return dedupePolicyHistory;
    }

    private class PolicyJsonSerializer extends JsonSerializer<DeDupePolicy> {
        @Override
        public void serialize(DeDupePolicy deDupePolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", deDupePolicy.getId().longValue());
                jsonGenerator.writeStringField("name", deDupePolicy.getName());
                jsonGenerator.writeNumberField("timeout", deDupePolicy.getTimeout());
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", deDupePolicy.getDevice().getId());
                jsonGenerator.writeEndObject();
                if (deDupePolicy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", deDupePolicy.getWorkflowStatus().name());
                }
                if (deDupePolicy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", deDupePolicy.getWorkflowType().name());
                }
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
