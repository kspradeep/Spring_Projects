package com.brocade.bvm.model.flexmatch;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Setter
@Getter
public class FlexMatchHeaders {
    private Set<Header> headers;
}
