package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Enums;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "flex_header_field")
public class FlexHeaderField implements DomainObject, Comparable<FlexHeaderField> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flex_header_id", referencedColumnName = "id")
    private FlexHeader flexHeader;

    void reverseMappingFlexHeader(FlexHeader flexHeader) {
        this.flexHeader = flexHeader;
    }

    //9850:   -1 (ignore), -63 - 63
    @Setter
    @Column
    private Integer offset = -1;

    //9850:   -1 (ignore), -63 - 63
    @Setter
    @Column(name = "custom_offset")
    private Integer customOffset = -1;

    //9850
    @Setter
    @Column(name = "is_positive")
    private Boolean isPositive = true;

    //9240 : SIP, DIP, SRC_PORT, TARGET_IP, TYPE_CODE, LABEL0, VNI, WORD1
    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "header_field")
    private HEADER_FIELDS headerField;

    @Setter
    @Column(name = "custom_field")
    private String customField;

    @Setter
    @Column(name = "byte_size")
    private Integer byteSize;

    @Setter
    @Column
    private Integer sequence = 0;

    public enum HEADER_FIELDS {
        HAS_INNER_TAG("HAS_INNER_TAG"), HAS_OUTER_TAG("HAS_OUTER_TAG"), HAS_8021BR_TAG("HAS_8021BR_TAG"), HAS_VNTAG("HAS_VNTAG"), ETHER_TYPE("ETHER_TYPE"), INNER_VID("INNER_VID"), OUTER_VID("OUTER_VID"), BR_TAG_8021("8021BR_TAG"), VNTAG("VNTAG"), MAC_SA_0_15("MAC_SA_0_15"), MAC_SA_16_47("MAC_SA_16_47"), MAC_DA_32_47("MAC_DA_32_47"), MAC_DA_0_31("MAC_DA_0_31"),   //ETH_FIELDS
        DIP("DIP"), SIP("SIP"), PROTOCOL("PROTOCOL"), //TOTAL_LENGTH, ECN, DSCP,    //IPV4_FIELDS
        NEXT_HEADER("NEXT_HEADER"), TOTAL_LENGTH("TOTAL_LENGTH"), ECN("ECN"), DSCP("DSCP"), DIP1("DIP1"), DIP0("DIP0"), SIP1("SIP1"), SIP0("SIP0"),    //IPV6_FIELDS
        TARGET_IP("TARGET_IP"), TARGET_HW_ADDR_1_32("TARGET_HW_ADDR_1_32"), TARGET_HW_ADDR_0_16("TARGET_HW_ADDR_0_16"), SENDER_IP_1_16(""), SENDER_IP_0_16(""), SENDER_HW_ADDR_1_16(""), SENDER_HW_ADDR_0_32(""),   //ARP_FIELDS
        FLAGS("FLAGS"), DST_PORT("DST_PORT"), SRC_PORT("SRC_PORT"),    //TCP_FIELDS
        //DST_PORT, SRC_PORT,     //UDP_FIELDS
        //DST_PORT, SRC_PORT,     //SCTP_FIELDS
        TYPE("TYPE"),     //IGMP_FIELDS
        //TYPE_CODE,    //ICMP_FIELDS
        TYPE_CODE("TYPE_CODE"),     //ICMPV6_FIELDS
        LABEL0("LABEL0"), LABEL1("LABEL1"), LABEL2("LABEL2"), LABEL3("LABEL3"),    //MPLS_FIELDS
        IS_NVGRE("IS_NVGRE"), IS_ERSPAN("IS_ERSPAN"), TNI("TNI"), IS_IPV4("IS_IPV4"), IS_IPV6("IS_IPV6"), IS_L2("IS_L2"), KEY_0_23("KEY_0_23"), KEY_24_31("KEY_24_31"),   //GRE_FIELDS
        VNI("VNI"),    //VXLAN_FIELDS
        TEID("TEID"),    //GTP_FIELDS
        PORTS("PORTS"),
        TARGET_HW_ADDR_16_47("TARGET_HW_ADDR_16_47"), TARGET_HW_ADDR_0_15("TARGET_HW_ADDR_0_15"), SENDER_IP_0_15("SENDER_IP_0_15"), SENDER_IP_16_31("SENDER_IP_16_31"), SENDER_HW_ADDR_0_31("SENDER_HW_ADDR_0_31"), SENDER_HW_ADDR_32_47("SENDER_HW_ADDR_32_47"),
        WORD0("WORD0"), WORD1("WORD1"), WORD2("WORD2"), WORD3("WORD3"), WORD4("WORD4"), WORD5("WORD5"), WORD6("WORD6"), WORD7("WORD7") ;   //PAYLOAD_FIELDS

        private String value;

        HEADER_FIELDS(String value) {
            this.value = value;
        }

        public String value() {
            return this.value;
        }

        public static HEADER_FIELDS getIfPresent(String name) {
            return Enums.getIfPresent(HEADER_FIELDS.class, name).orNull();
        }
    }

    @Override
    public int compareTo(FlexHeaderField flexHeaderField) {
        return this.sequence - flexHeaderField.getSequence();
    }

    public void clearId(){
        this.id = null;
    }
}
