

package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.FlowExporterHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.IOException;

@Getter
@Entity(name = "sd_flow_exporter")
public class FlowExporter extends ManagedObject implements HasHistory {

    @Setter
    @Column(name = "sd_transport_protocol")
    @Enumerated(EnumType.STRING)
    private TransportTypes transportType;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "sd_management_port_id", referencedColumnName = "id")
    private PhysicalInterface sdManagementPort;

    @JsonDeserialize
    public void setSdManagementPort(PhysicalInterface physicalInterface) {
        this.sdManagementPort = physicalInterface;
    }

    @Setter
    @Column(name = "sd_transport_port")
    private Integer sdTransportPort;

    @Setter
    @Column(name = "ip_address")
    private String ipAdress;

    @Setter
    @Column(name = "c_plane_idle_timer")
    private Integer cPlaneIdleTimer = 5;//The default value for this parameter is 5secs

    @Setter
    @Column(name = "pen_value")
    private Integer pen = 289;//289 being the default value need to restrict to be one among SD supports

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    public enum TransportTypes {
        TCP("tcp"),
        UDP("udp");

        private String transportTypes;

        TransportTypes(String transportTypes) {
            this.transportTypes = transportTypes;
        }

        public String getName() {
            return this.transportTypes;
        }
    }

    @Override
    public HistoryObject buildHistory() {
        FlowExporterHistory flowExporterHistory = new FlowExporterHistory();
        flowExporterHistory.setName(getName());
        flowExporterHistory.setDevice(this.device);
        flowExporterHistory.setWorkflowStatus(getWorkflowStatus());
        flowExporterHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(FlowExporter.class, new FlowExporter.flowExporterJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            flowExporterHistory.setFlowExporterJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to Flow Exporter history", e);
        }
        return flowExporterHistory;
    }

    private class flowExporterJsonSerializer extends JsonSerializer<FlowExporter> {
        @Override
        public void serialize(FlowExporter flowExporter, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", flowExporter.getId());
                jsonGenerator.writeStringField("name", flowExporter.getName());
                jsonGenerator.writeObjectField("transportType", flowExporter.getTransportType());
                jsonGenerator.writeNumberField("sdTransportPort", flowExporter.getSdTransportPort());
                jsonGenerator.writeObjectField("sdManagementPort", flowExporter.getSdManagementPort());
                jsonGenerator.writeStringField("sdCollectorName", flowExporter.getName());
                jsonGenerator.writeStringField("ipAdress", flowExporter.getIpAdress());
                jsonGenerator.writeNumberField("cPlaneIdleTimer", flowExporter.getCPlaneIdleTimer());
                jsonGenerator.writeNumberField("pen", flowExporter.getPen());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }


}



