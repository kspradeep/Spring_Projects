package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Objects;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "filter_rule")
public class FilterRule implements DomainObject, Comparable<FilterRule> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public static final Integer PRIORITY_MAX = 65535;
    public static final Integer PRIORITY_MIN = 1;

    public static final Integer QCI_MAX = 9;
    public static final Integer QCI_MIN = 1;

    public static final Integer SIP_CALL_PARTY_MAX = 15;
    public static final Integer SIP_CALL_PARTY_MIN = 10;

    public static final Integer IMSI_MIN = 14;
    public static final Integer IMSI_MAX = 15;
    public static final Integer IMEI_MIN = 15;
    public static final Integer IMEI_MAX = 16;

    public static final Integer IMSI_SAMPLING_MIN = 5;
    public static final Integer IMEI_SAMPLING_MIN = 8;

    public static final Integer FILTER_POLICY_MAX = 5;
    public static final Integer FILTER_POLICY_NAME_MAX = 16;

    public static final String FORWARD = "forward";
    public static final String APPLY_DEFERRED = "deferred";

    @Column
    private String name;

    @Column(name = "subscriber_traffic")
    private String subscriberTraffic;

    @Column(name = "charging_char")
    private String chargingChar;

    @Column(name = "imsi_range")
    private Integer range;

    @Column
    private Integer priority;

    @Column
    private String apply;

    @Column
    private String imsi;

    @Column
    private String apn;

    @Column
    private String imei;

    @Column
    private Integer qci;

    @Column
    private Integer mcc;

    @Column(name = "sip_calling_party")
    private String sipCallingParty;

    @Column(name = "sip_called_party")
    private String sipCalledParty;

    @Column
    private String mnc;

    @Transient
    private String action;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "filter_policy_id", referencedColumnName = "id")
    private FilterPolicy policy;

    void reverseMapPolicy(FilterPolicy policy) {
        this.policy = policy;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sampling_policy_id", referencedColumnName = "id")
    private SamplingPolicy samplingPolicy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "port_group_id", referencedColumnName = "id")
    private SdPortGroup portGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "replication_port_group_id", referencedColumnName = "id")
    private SdPortGroup replicationPortGroup;

    @Column(name = "imsi_file_name")
    private String imsiFileName;

    @Column(name = "imei_file_name")
    private String imeiFileName;

    @Column(name = "apn_file_name")
    private String apnFileName;

    @Column(name = "sip_calling_party_file_name")
    private String sipCallingPartyFileName;

    @Column(name = "sip_called_party_file_name")
    private String sipCalledPartyFileName;

    @Column(name = "is_bulk_delete")
    private boolean bulkDelete;

    @Setter
    @Column
    private Integer sequence = 0;

    /**
     * Utility method to return the hashcode of the contents of the object. hashcode is not overridden to not alter hibernate behaviour
     *
     * @return
     */
    public int hash() {
        Long pgId = portGroup != null ? portGroup.getId() : 0;
        Long rpgId = replicationPortGroup != null ? replicationPortGroup.getId() : 0;
        Long samplingPolicyId = samplingPolicy != null ? samplingPolicy.getId() : 0;
        return Objects.hash(this.priority, pgId, this.imsi, this.qci, rpgId, this.apn, this.sipCallingParty, this.sipCalledParty, samplingPolicyId, this.imei, this.mcc, this.mnc, this.imsiFileName, this.imeiFileName, this.apnFileName, this.sipCallingPartyFileName, this.sipCalledPartyFileName, this.apply, this.sequence);
    }

    public void clearId() {
        this.id = null;
    }

    @Override
    public int compareTo(FilterRule filterRule) {
        return this.sequence - filterRule.getSequence();
    }
}
