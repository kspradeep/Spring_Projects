package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "flow_managed_object_egress")
public class FlowEgressManagedObject implements DomainObject {

    @Id
    @Getter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    @Getter
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flow_id", referencedColumnName = "id")
    private Flow flow;

    void reverseMapFlow(Flow flow) {
        this.flow = flow;
    }

    @JsonIgnore
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "managed_object_id", referencedColumnName = "id")
    private ManagedObject managedObject;

    @JsonProperty
    public void setPort(Port port) {
        if (port != null)
            this.managedObject = port;
    }

    @JsonProperty
    public void setPortGroup(PortGroup portGroup) {
        if (portGroup != null)
            this.managedObject = portGroup;
    }

    @JsonProperty
    public ManagedObject getPort() {
        if (this.managedObject instanceof Port)
            return this.managedObject;
        else return null;
    }

    @JsonProperty
    public ManagedObject getPortGroup() {
        if (this.managedObject instanceof PortGroup)
            return this.managedObject;
        else return null;
    }

    @Setter
    @Column
    private Integer precedence = 0;

    @Setter
    @Column(name = "tvf_domain_id")
    @JsonIgnore
    private String tvfDomainId;
}
