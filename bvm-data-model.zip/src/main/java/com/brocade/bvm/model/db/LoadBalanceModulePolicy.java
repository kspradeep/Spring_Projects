package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Entity(name = "load_balance_module_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
@JsonPropertyOrder({"id", "name", "workflowStatus", "workflowType", "modules", "device", "isSourceIpIncluded", "isSourcePortIncluded", "isDestinationIpIncluded", "isDestinationPortIncluded",
        "isTeIdIncluded", "isInnerIpIncluded", "isProtocolMaskIncluded", "isBiDirectional", "tunnelingProtocol", "biDirectional", "sourceIpIncluded", "sourcePortIncluded", "destinationIpIncluded",
        "destinationPortIncluded", "protocolMaskIncluded", "innerIpIncluded", "teIdIncluded"})
public class LoadBalanceModulePolicy extends ModulePolicy implements HasHistory {

    @Column(name = "is_source_ip_included")
    @Setter
    @JsonProperty
    private boolean isSourceIpIncluded;


    @Column(name = "is_source_port_included")
    @Setter
    @JsonProperty
    private boolean isSourcePortIncluded;


    @Column(name = "is_dest_ip_included")
    @Setter
    @JsonProperty
    private boolean isDestinationIpIncluded;


    @Column(name = "is_dest_port_included")
    @Setter
    @JsonProperty
    private boolean isDestinationPortIncluded;


    @Column(name = "is_teid_included")
    @Setter
    @JsonProperty
    private boolean isTeIdIncluded;


    @Column(name = "is_inner_ip_included")
    @Setter
    @JsonProperty
    private boolean isInnerIpIncluded;


    @Column(name = "is_protocol_mask_included")
    @Setter
    @JsonProperty
    private boolean isProtocolMaskIncluded;


    @Column(name = "is_bidirectional")
    @Setter
    @JsonProperty
    private boolean isBiDirectional;


    @Column(name = "tunneling_protocol")
    @Setter
    private String tunnelingProtocol;

    @Override
    public HistoryObject buildHistory() {
        LoadBalanceModulePolicyHistory policyHistory = new LoadBalanceModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(LoadBalanceModulePolicy.class, new LoadBalanceModulePolicy.LoadBalanceModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the Policy Object in History", e);
        }
        return policyHistory;
    }


    private class LoadBalanceModulePolicyJsonSerializer extends JsonSerializer<LoadBalanceModulePolicy> {
        @Override
        public void serialize(LoadBalanceModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeBooleanField("isSourceIpIncluded", isSourceIpIncluded);
                jsonGenerator.writeBooleanField("isSourcePortIncluded", isSourcePortIncluded);
                jsonGenerator.writeBooleanField("isDestinationIpIncluded", isDestinationIpIncluded);
                jsonGenerator.writeBooleanField("isDestinationPortIncluded", isDestinationPortIncluded);
                jsonGenerator.writeBooleanField("isTeIdIncluded", isTeIdIncluded);
                jsonGenerator.writeBooleanField("isInnerIpIncluded", isInnerIpIncluded);
                jsonGenerator.writeBooleanField("isProtocolMaskIncluded", isProtocolMaskIncluded);
                jsonGenerator.writeBooleanField("isBiDirectional", isBiDirectional);
                jsonGenerator.writeStringField("tunnelingProtocol", tunnelingProtocol);
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }
}
