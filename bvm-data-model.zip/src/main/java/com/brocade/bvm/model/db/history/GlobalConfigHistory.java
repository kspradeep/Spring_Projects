package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.GlobalConfig;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sd_global_config_history")
public class GlobalConfigHistory extends HistoryObject<GlobalConfig> {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "global_config_json")
    private String globalConfigJson;

    @Override
    public GlobalConfig buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        GlobalConfig globalConfig = null;
        try {
            globalConfig = mapper.readValue(globalConfigJson, GlobalConfig.class);
            globalConfig.setDevice(device);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the Global config history", e);
        }
        return globalConfig;
    }
}

