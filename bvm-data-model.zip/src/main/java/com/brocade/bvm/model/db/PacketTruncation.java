package com.brocade.bvm.model.db;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "packet_truncation")
public class PacketTruncation extends ManagedObject {

    @Column(name = "frame_size")
    @Setter
    private Long frameSize;

    @Column(name = "is_global")
    @Setter
    private boolean global;

    @Column(name = "global_policy_name")
    @Setter
    private String globalPolicyName;

    @Column(name = "global_policy_sequence_number")
    @Setter
    private String globalPolicySequenceNumbers;

    @JsonIgnore
    @OneToMany(mappedBy = "packetTruncation", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<PacketTruncationMapping> packetTruncationMappings = new HashSet<>();

    public ImmutableSet<PacketTruncationMapping> getPacketTruncationMappings() {
        return ImmutableSet.copyOf(packetTruncationMappings);
    }

    public void addPacketTruncationMappings(Set<PacketTruncationMapping> packetTruncationMappings) {
        this.packetTruncationMappings.addAll(packetTruncationMappings);
        packetTruncationMappings.forEach(truncationProfile -> truncationProfile.reverseMapPacketTruncation(this));
    }

    public void removePacketTruncationMappings(Set<PacketTruncationMapping> packetTruncationMappings) {
        this.packetTruncationMappings.removeAll(packetTruncationMappings);
    }

    public void setPacketTruncationMappings(Set<PacketTruncationMapping> packetTruncationMappings) {
        this.packetTruncationMappings.clear();
        addPacketTruncationMappings(packetTruncationMappings);
    }

}
