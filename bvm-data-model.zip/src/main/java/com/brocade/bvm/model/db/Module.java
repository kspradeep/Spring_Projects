package com.brocade.bvm.model.db;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSet;
import com.google.common.primitives.Ints;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Entity(name = "module")
public class Module extends ManagedObject implements Comparable<Module> {

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    void reverseMapDevice(Device device) {
        this.device = device;
    }

    @JsonIgnore
    @Setter
    @Column(name = "stablenet_id")
    private Long stablenetId;
    
    @JsonIgnore
    @Setter
    @Column(name = "serial_number")
    private String serialNumber;

    @JsonIgnore
    @Setter
    @Column(name = "module_number")
    private Integer moduleNumber;

    @Setter
    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private Type type;

    public enum Type {
        G10,
        G100,
        G40
    }

    @OneToMany(mappedBy = "module", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Port> ports = new HashSet<>();

    public ImmutableSet<Port> getPorts() {
        return ImmutableSet.copyOf(ports);
    }

    public void addPorts(Set<Port> ports) {
        this.ports.addAll(ports);
        ports.forEach(port -> port.reverseMapModule(this));
    }

    public void removePorts(Set<Port> ports) {
        this.ports.removeAll(ports);
    }

    public void setPorts(Set<Port> ports) {
        this.ports.clear();
        addPorts(ports);
    }

    @Override
    public int compareTo(@NotNull Module other) {
        return Ints.compare(moduleNumber, other.getModuleNumber());
    }
}
