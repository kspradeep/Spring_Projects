package com.brocade.bvm.model.db.history;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.brocade.bvm.model.db.Port;

@Getter
@NoArgsConstructor
@Entity(name = "port_history")
public class PortHistory extends HistoryObject<Port> {

    @Setter
    @Column(name = "mode")
    @Enumerated(EnumType.STRING)
    private Port.Mode mode;

    @Getter
    @Setter
    @Column(name = "line_speed")
    private Long lineSpeed;

    @Getter
    @Setter
    @Column(name = "max_speed")
    private Long maxSpeed;

    @Getter
    @Setter
    @Column(name = "is_loop_back_enabled")
    private boolean loopBackEnabled;

    @Override
    Port buildParent() {
        return null; //TODO
    }
}
