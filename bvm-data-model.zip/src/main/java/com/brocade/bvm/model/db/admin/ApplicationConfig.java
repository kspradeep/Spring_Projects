package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.exception.ServerException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Optional;

@Slf4j
@NoArgsConstructor
@Entity(name = "application_config")
//TODO cache
public class ApplicationConfig implements DomainObject {

    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Getter
    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "config_key")
    private Key key;

    @Column(name = "config_value")
    private String value;

    public enum Key {
        StablenetRestUrl,
        StablenetUsername,
        StablenetPassword,
        StablenetJobId,
        StablenetRediscoverJobId,
        StablenetDeleteJobId,
        BscRestUrl,
        BscUsername,
        BscPassword,
        OpenStackRestUrl,
        OpenStackUsername,
        OpenStackPassword,
        vTAPPrivateKey,
        VlanIdMinimum,
        VlanIdMaximum,
        OdlRestUrl,
        OdlUsername,
        OdlPassword;

        public static Optional<Key> findByName(String keyName) {
            return Arrays.stream(values())
                    .filter(key1 -> key1.name().toLowerCase().equalsIgnoreCase(keyName.toLowerCase()))
                    .findAny();
        }
    }

    private static java.security.Key PRIVATE_KEY;
    static {
        try {
            /*
            128bits (16bytes) key is used and not 256.
            See https://github.com/spring-projects/spring-security/issues/2917 and https://en.wikipedia.org/wiki/Restrictions_on_the_import_of_cryptography
            to understand why it's not easy to ship with a 256 bit key.
            Spring Encryptors has a much easier interface for AES encryption, but provides only a 256 bit key encryption.
             */
            byte[] keyBytes = Arrays.copyOf("v3@F_Fww6}_As~BV".getBytes("UTF-8"), 16);
            PRIVATE_KEY = new SecretKeySpec(keyBytes, "AES");
        } catch (UnsupportedEncodingException e) {
            throw new ServerException(e);
        }
    }

    public ApplicationConfig(Key key, String value) {
        this.setKey(key);
        this.setValue(value);
    }

    /**
     * Keys which end with "password" are encrypted and stored
     *
     * @param value
     */
    public void setValue(String value) {
        if (key != null && value != null && key.name().toLowerCase().endsWith("password")) {
            this.value = encryptPassword(value);
        } else {
            this.value = value;
        }
    }

    private String encryptPassword(String plainTextPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, PRIVATE_KEY);
            byte[] encrypted = cipher.doFinal(plainTextPassword.getBytes("UTF-8"));
            return new BASE64Encoder().encode(encrypted);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | UnsupportedEncodingException | IllegalBlockSizeException e) {
            throw new ServerException(e);
        }
    }

    /**
     * Returns the raw value stored in DB
     *
     * @return
     */
    public String getRawValue() {
        return this.value;
    }

    /**
     * Returns a processed value. For eg. passwords are encrypted and stored in DB. This method returns a decrypted password.
     *
     * @return
     */
    public String getValue() {
        if (key == null || value == null) {
            throw new ServerException("Invalid application configuration!");
        }
        if (key.name().toLowerCase().endsWith("password")) {
            return decryptPassword(value);
        } else {
            return this.value;
        }
    }

    private String decryptPassword(String encryptedPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, PRIVATE_KEY);
            byte[] decoded = new BASE64Decoder().decodeBuffer(encryptedPassword);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted, "UTF-8");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | IOException e) {
            throw new ServerException(e);
        }
    }

    @Override
    public String getName() {
        return "";
    }
}
