package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.Port.Type;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortGroupHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Getter
@NoArgsConstructor
@Entity(name = "port_group")
public class PortGroup extends ManagedObject implements HasHistory {

    public static final Integer PORT_CHANNEL_MIN = 1;
    public static final Integer PORT_CHANNEL_MAX = 1024;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    public void setDevice(Device device) {
        this.device = device;
        device.reverseMapPortGroup(this);
    }

    @Setter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "primary_port_id", referencedColumnName = "id")
    private Port primaryPort;

    // TODO added a Json ignore to aviod too much data issue in getDevice api if portGroup is created with GTPProfile
    @JsonIgnore
    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "gtp_device_policy_id", referencedColumnName = "id")
    private GTPDevicePolicy gtpProfile;//Should not use DevicePolicy , we get 61 join problem

    // TODO added a Json property to device object in GTP profile to null, to aviod too much data issue in getDevice api if portGroup is created with GTPProfile
    @JsonProperty(value = "gtpProfileId")
    @Setter
    @Transient
    private Long gtpProfileId;

    @Getter
    @Setter
    @Column(name = "line_speed")
    private Long lineSpeed;

    @Setter
    @Column(name = "is_minimum_link_enabled")
    private Boolean minimumLinkEnabled = false;

    public Boolean isMinimumLinkEnabled() {
        return minimumLinkEnabled;
    }

    @Getter
    @Setter
    @Column(name = "is_loop_back_enabled")
    private Boolean loopbackEnabled = false;

    public Boolean isLoopbackEnabled() {
        return loopbackEnabled;
    }

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "port_portgroup_mapping",
            joinColumns = @JoinColumn(name = "port_group_id"),
            inverseJoinColumns = @JoinColumn(name = "port_id")
    )
    private Set<Port> ports = new HashSet<>();

    public ImmutableSet<Port> getPorts() {
        return ImmutableSet.copyOf(ports);
    }

    public void addPorts(Set<Port> ports) {
        this.ports.addAll(ports);
    }

    public void removePorts(Set<Port> ports) {
        this.ports.removeAll(ports);
    }

    public void setPorts(Set<Port> ports) {
        this.ports.clear();
        addPorts(ports);
    }

    //temporary field for egress set next hop precedence.
    @Getter
    @Setter
    @Transient
    private Integer precedence = 0;

    @JsonProperty
    public Type getType() {
        Optional<Port> first = ports.stream().findFirst();
        return first.isPresent() ? first.get().getType() : null;
    }

    @Override
    public HistoryObject<PortGroup> buildHistory() {
        PortGroupHistory portGroupHistory = new PortGroupHistory();
        portGroupHistory.setName(getName());
        portGroupHistory.setWorkflowStatus(getWorkflowStatus());
        portGroupHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(PortGroup.class, new PortGroupJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            portGroupHistory.setPortGroupJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to create port group history", e);
        }
        return portGroupHistory;
    }

    private class PortGroupJsonSerializer extends JsonSerializer<PortGroup> {
        @Override
        public void serialize(PortGroup portGroup, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeStringField("name", portGroup.getName());
                if (portGroup.getLineSpeed() != null) {
                    jsonGenerator.writeNumberField("lineSpeed", portGroup.getLineSpeed());
                } else {
                    jsonGenerator.writeNullField("lineSpeed");
                }
                if (portGroup.getGtpProfileId() == null && portGroup.getGtpProfile() == null) {
                    jsonGenerator.writeNullField("gtpProfileId");
                } else {
                    jsonGenerator.writeNumberField("gtpProfileId", portGroup.getGtpProfileId() != null ? portGroup.getGtpProfileId() : portGroup.getGtpProfile().getId());
                }
                if(portGroup.getLoopbackEnabled() != null) {
                    jsonGenerator.writeBooleanField("loopbackEnabled", portGroup.getLoopbackEnabled());
                }
                if (portGroup.getGtpProfile() != null) {
                    jsonGenerator.writeObjectFieldStart("gtpProfile");
                    jsonGenerator.writeNumberField("id", portGroup.getGtpProfile().getId());
                    jsonGenerator.writeStringField("name", portGroup.getGtpProfile().getName());
                    jsonGenerator.writeNumberField("profileId", portGroup.getGtpProfile().getProfileId());
                    jsonGenerator.writeEndObject();
                }

                jsonGenerator.writeObjectFieldStart("primaryPort");
                jsonGenerator.writeNumberField("id", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getId() : -1);
                jsonGenerator.writeStringField("name", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getName() : "");
                jsonGenerator.writeEndObject();

                jsonGenerator.writeArrayFieldStart("ports");
                if (portGroup.getPorts() != null) {
                    portGroup.getPorts().forEach(port -> {
                        try {
                            if (port != null && port.getId() != null) {
                                jsonGenerator.writeStartObject();
                                jsonGenerator.writeNumberField("id", port.getId());
                                if (port.getName() != null) {
                                    jsonGenerator.writeStringField("name", port.getName());
                                }
                                if (port.getAdminStatus() != null) {
                                    jsonGenerator.writeStringField("adminStatus", port.getAdminStatus().name());
                                }
                                if (port.getDiscoveredAdminStatus() != null) {
                                    jsonGenerator.writeStringField("discoveredAdminStatus", port.getDiscoveredAdminStatus().name());
                                }
                                jsonGenerator.writeEndObject();
                            }
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                }
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();

            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
