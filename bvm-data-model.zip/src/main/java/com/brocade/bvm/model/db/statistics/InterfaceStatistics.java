package com.brocade.bvm.model.db.statistics;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.Date;

@Getter
@Entity(name = "interface_statistics")
@NoArgsConstructor
public class InterfaceStatistics {

    @Id
    private Long id = System.nanoTime();

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "collector_device_id", referencedColumnName = "id")
    private CollectorDeviceMapping collectorDeviceMapping;

    @JsonDeserialize
    public void setCollectorDeviceMapping(CollectorDeviceMapping collectorDeviceMapping) {
        this.collectorDeviceMapping = collectorDeviceMapping;
    }

    @Setter
    @Column(name = "last_updated_time", columnDefinition = "timestamp", length = 6)
    private Instant lastUpdatedTime;

    //TODO:Map the port object if required by UI
    @Setter
    @Column(name = "port_id")
    private Long portId;


    @Setter
    @Column(name = "if_index")
    private Long ifIndex = 0L;

    @Setter
    @Column(name = "if_name")
    private String ifName;

    @Setter
    @Column(name = "in_packets")
    private Long inPackets = 0L;

    @Setter
    @Column(name = "in_octets")
    private Long inOctets = 0L;

    @Setter
    @Column(name = "in_errors")
    private Long inErrors = 0L;

    @Setter
    @Column(name = "in_discards")
    private Long inDiscards = 0L;

    @Setter
    @Column(name = "in_unicast_pkts")
    private Long inUnicastPkts = 0L;

    @Setter
    @Column(name = "in_multicast_pkts")
    private Long inMulticastPkts = 0L;

    @Setter
    @Column(name = "in_broadcast_pkts")
    private Long inBroadcastPkts = 0L;

    @Setter
    @Column(name = "in_pkts_per_second")
    private Long inPktsPerSecond = 0L;

    @Setter
    @Column(name = "in_band_width")
    private Long inBandwidth = 0L;

    @Setter
    @Column(name = "in_crc_errors")
    private Long inCrcErrors = 0L;

    @Setter
    @Column(name = "in_link_utilization")
    private Double inLinkUtilization = 0.0d;

    @Setter
    @Column(name = "out_packets")
    private Long outPackets = 0L;

    @Setter
    @Column(name = "out_octets")
    private Long outOctets = 0L;

    @Setter
    @Column(name = "out_errors")
    private Long outErrors = 0L;

    @Setter
    @Column(name = "out_discards")
    private Long outDiscards = 0L;

    @Setter
    @Column(name = "out_unicast_pkts")
    private Long outUnicastPkts = 0L;

    @Setter
    @Column(name = "out_multicast_pkts")
    private Long outMulticastPkts = 0L;

    @Setter
    @Column(name = "out_broadcast_pkts")
    private Long outBroadcastPkts = 0L;

    @Setter
    @Column(name = "out_pkts_per_second")
    private Long outPktsPerSecond = 0L;

    @Setter
    @Column(name = "out_band_width")
    private Long outBandwidth = 0L;

    @Setter
    @Column(name = "out_crc_errors")
    private Long outCrcErrors = 0L;

    @Setter
    @Column(name = "out_link_utilization")
    private Double outLinkUtilization = 0.0d;

    @Setter
    @Column(name = "received_time", columnDefinition = "DATETIME", length = 6)
    private Date receivedTime;

}
