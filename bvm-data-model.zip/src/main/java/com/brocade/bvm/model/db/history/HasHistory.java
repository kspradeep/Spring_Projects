package com.brocade.bvm.model.db.history;

import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public interface HasHistory {
    Long getId();

    /**
     * Serialize {@link HasHistory} to {@link HistoryObject}
     */
    HistoryObject buildHistory();
}
