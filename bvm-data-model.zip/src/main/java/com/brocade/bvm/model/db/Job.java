package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "job")
@EntityListeners(CustomAuditingEntityListener.class)
public class Job implements DomainObject {

    @Id
    @GeneratedValue
    private Long id;

    @JsonIgnore //TODO get only id
    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "target_host_id", referencedColumnName = "id")
    @JsonProperty
    private TargetHost targetHost;

    public Device getDevice() {
        assert targetHost instanceof Device;
        return (Device) targetHost;
    }

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Type type;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Status status = Status.CREATED;

    /**
     * Set of objects whose {@link com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus} will get impacted because of the job.
     * See parentObject too.
     */
    @JsonIgnore
    @Setter
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "job_object_mapping", joinColumns = @JoinColumn(name = "job_id"))
    @Column(name = "impacted_object_id")
    private Set<Long> impactedObjectsIds;

    public ImmutableSet<Long> getImpactedObjectIds() {
        return ImmutableSet.copyOf(impactedObjectsIds);
    }

    /**
     * Parent object of the job. For eg. for POLICY_CREATE job, the policy object is the parentObject,
     * while all the ports and portGroups will be impactedObjects.
     * See impactedObjects too.
     */
    @Setter
    @Column(name = "parent_object_id")
    private Long parentObjectId;

    @JsonIgnore
    @Setter
    @Column(name = "external_job_id")
    private Long externalJobId;

    @Setter
    @Lob
    @Column(name = "job_result")
    private String jobResult;

    @Setter(AccessLevel.PACKAGE)
    @Column(name = "created_by")
    private String createdByUser;

    @Setter
    @Column(name = "created_by_pwd")
    private String createdByUserPassword;

    @Setter(AccessLevel.PACKAGE)
    @Column(name = "created_time")
    private Instant createdTime;

    @Setter(AccessLevel.PACKAGE)
    @Column(name = "last_updated_time")
    private Instant lastUpdatedTime;

    @Setter
    @Lob
    @Column(name = "error_log")
    private String errorLog;

    @Override
    public String getName() {
        return String.format("%s_%s_%s", type, parentObjectId, impactedObjectsIds);
    }

    public enum Status {
        CREATED,
        SUBMITTED,
        SUCCESS,
        FAILED
    }

    public enum Type {
        PORT_ENABLE, PORT_DISABLE, PORT_MARK_INGRESS, PORT_MARK_EGRESS, PORT_MARK_NONE, PORT_MARK_SERVICE, PORT_MARK_RECOVER, PORT_DESCRIPTION,
        PORT_MARK_INGRESS_GRID, PORT_MARK_EGRESS_GRID, PORT_MARK_NONE_GRID,
        PORT_GROUP_CREATE, PORT_GROUP_UPDATE, PORT_GROUP_DELETE(true), PORT_GROUP_RECOVER,
        PORT_CHANNEL_CREATE, PORT_CHANNEL_UPDATE, PORT_CHANNEL_DELETE(true), PORT_CHANNEL_RECOVER,
        LOAD_BALANCE_MODULE_POLICY_CREATE, LOAD_BALANCE_MODULE_POLICY_UPDATE, LOAD_BALANCE_MODULE_POLICY_DELETE(true),
        PACKET_STAMPING_MODULE_POLICY_CREATE, PACKET_STAMPING_MODULE_POLICY_UPDATE, PACKET_STAMPING_MODULE_POLICY_DELETE(true), PACKET_STAMPING_MODULE_POLICY_ROLLBACK(true),
        PACKET_LABELING_MODULE_POLICY_CREATE, PACKET_LABELING_MODULE_POLICY_UPDATE, PACKET_LABELING_MODULE_POLICY_DELETE(true), PACKET_LABELING_MODULE_POLICY_ROLLBACK(true),
        PACKET_SLICING_MODULE_POLICY_CREATE, PACKET_SLICING_MODULE_POLICY_UPDATE, PACKET_SLICING_MODULE_POLICY_DELETE(true), PACKET_SLICING_MODULE_POLICY_ROLLBACK(true),
        GTP_DE_ENCAPSULATION_MODULE_POLICY_CREATE, GTP_DE_ENCAPSULATION_MODULE_POLICY_UPDATE, GTP_DE_ENCAPSULATION_MODULE_POLICY_DELETE(true), GTP_DE_ENCAPSULATION_MODULE_POLICY_ROLLBACK(true),
        SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_CREATE, SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_UPDATE, SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_DELETE(true), SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_ROLLBACK(true),
        IP_PAYLOAD_LENGTH_POLICY_CREATE, IP_PAYLOAD_LENGTH_POLICY_UPDATE, IP_PAYLOAD_LENGTH_POLICY_DELETE(true), IP_PAYLOAD_LENGTH_POLICY_ROLLBACK(true),
        POLICY_CREATE, POLICY_UPDATE, POLICY_DELETE(true), POLICY_ROLLBACK, POLICY_REVERT, POLICY_DELETE_DRAFT,
        SD_SET_INGRESS_PORT,
        HEADER_STRIPPING_8021BR_AND_VNTAG_CREATE, HEADER_STRIPPING_8021BR_AND_VNTAG_UPDATE, HEADER_STRIPPING_8021BR_AND_VNTAG_DELETE(true), HEADER_STRIPPING_8021BR_AND_VNTAG_ROLLBACK(true),
        HEADER_STRIPPING_SLX_CREATE, HEADER_STRIPPING_SLX_UPDATE, HEADER_STRIPPING_SLX_DELETE(true), HEADER_STRIPPING_SLX_ROLLBACK(true),
        HEADER_STRIPPING_MPLS_POP_CREATE, HEADER_STRIPPING_MPLS_POP_UPDATE, HEADER_STRIPPING_MPLS_POP_DELETE(true),
        GTP_PROFILE_CREATE, GTP_PROFILE_UPDATE, GTP_PROFILE_DELETE(true), GTP_PROFILE_ROLLBACK(true),
        MPLS_TUNNEL_UPDATE, GRE_TUNNEL_UPDATE,
        TAP_POLICY_CREATE, TAP_POLICY_UPDATE, TAP_POLICY_DELETE(true), TAP_POLICY_ROLLBACK, PORT_SPEED_UPDATE, PORT_BREAKOUT_ENABLE, PORT_BREAKOUT_DISABLE, SLX_PTP_ENABLE, SLX_PTP_DISABLE, SLX_PTP_DELETE(true),
        SD_EGRESS_PORT_CREATE, SD_EGRESS_PORT_UPDATE, SD_EGRESS_PORT_DELETE(true), SD_EGRESS_PORT_ROLLBACK,
        SD_PORT_GROUP_CREATE, SD_PORT_GROUP_UPDATE, SD_PORT_GROUP_DELETE(true), SD_DEFAULT_PORT_GROUP_DELETE, SD_PORT_GROUP_ROLLBACK, SD_DEFAULT_PORT_ROLLBACK,
        SD_FILTER_POLICY_CREATE, SD_FILTER_POLICY_UPDATE, SD_FILTER_POLICY_DELETE(true), SD_FILTER_POLICY_RECOVER, SD_GLOBAL_CONFIG_UPDATE, SD_PROFILE_UPDATE, SD_SAVE_RUNNING_CONFIG,
        SD_DEDUPE_POLICY_CREATE, SD_DEDUPE_POLICY_UPDATE, SD_DEDUPE_POLICY_DELETE(true), SD_DEDUPE_POLICY_RECOVER,
        SD_SAMPLING_POLICY_CREATE, SD_SAMPLING_POLICY_UPDATE, SD_SAMPLING_POLICY_DELETE(true), SD_SAMPLING_POLICY_RECOVER,
        SD_ACTIVE_INTERFACE_CREATE, SD_ACTIVE_INTERFACE_UPDATE, SD_ACTIVE_INTERFACE_DELETE(true), SD_ACTIVE_INTERFACE_RECOVER, SD_STATUS,
        ENABLE_ACL_FRAG_CONSERVATIVE, DISABLE_ACL_FRAG_CONSERVATIVE, SD_CLEAR_CONFIG, SD_CREATE_FLOW_EXPORTER, SD_UPDATE_FLOW_CONFIG, SD_DELETE_FLOW_CONFIG(true),
        RECONCILE_DEVICE, RECONCILE_POLICY, RECONCILE_PORT_GROUP, RECONCILE_PORT_CHANNEL,
        NETWORK_PATH_SWITCH_MANUAL, NETWORK_PATH_SWITCH_AUTO, CONFIG_TACACS_SERVER, DELETE_TACACS_SERVER,
        CONFIG_TELEMETRY_PROFILE, RECONFIG_TELEMETRY_PROFILE, UPDATE_TELEMETRY_PROFILE, DELETE_TELEMETRY_PROFILE,
        GRID_TOOL_GROUP_CREATE, GRID_TOOL_GROUP_UPDATE_ADD, GRID_TOOL_GROUP_UPDATE_DELETE, GRID_TOOL_GROUP_DELETE, GRID_TOOL_GROUP_ROLLBACK,
        GRID_TOOL_ADDRESS_CREATE, GRID_TOOL_ADDRESS_UPDATE, GRID_TOOL_ADDRESS_DELETE, GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE, GRID_TOOL_ADDRESS_ROLLBACK, DEVICE_STATUS,
        PORT_LINK_STATUS, TELEMETRY_CLEAR_COUNTER, PACKET_TRUNCATION_PROFILE_CREATE, PACKET_TRUNCATION_PROFILE_UPDATE, PACKET_TRUNCATION_PROFILE_DELETE(true),
        AGENT_CONFIGURATION, JOB_CONFIGURATION, PACKET_TRUNCATION_ROLLBACK,
        INITIALIZING_VISIBILITY_MANAGER, COMPLETED_INITIALIZING_VISIBILITY_MANAGER, PACKET_CAPTURE_CREATE;

        @Getter
        private boolean isDeleteParent;

        Type(boolean isDeleteParent) {
            this.isDeleteParent = isDeleteParent;
        }

        Type() {
            this.isDeleteParent = false;
        }
    }

    public enum Priority {
        LOW, HIGH
    }
}
