package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.FlowExporter;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sd_flow_exporter_history")
public class FlowExporterHistory extends HistoryObject<FlowExporter> {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "flow_exporter_json")
    private String flowExporterJson;

    @Override
    public FlowExporter buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        FlowExporter flowExporter = null;
        try {
            flowExporter = mapper.readValue(flowExporterJson, FlowExporter.class);
            flowExporter.setDevice(device);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the Flow Exporter history", e);
        }
        return flowExporter;
    }
}

