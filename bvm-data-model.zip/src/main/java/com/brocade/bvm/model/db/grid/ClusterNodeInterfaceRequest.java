package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Setter
@Getter
public class ClusterNodeInterfaceRequest {

    private Long id;

    private String name;

    private GridCluster gridCluster;

    private Set<Port> ports = new HashSet<>();

    private Set<PortGroup> portGroups = new HashSet<>();
}
