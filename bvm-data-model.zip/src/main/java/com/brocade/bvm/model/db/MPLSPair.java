package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "mpls_port_pair")
@Slf4j
public class MPLSPair implements DomainObject {

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_policy_id", referencedColumnName = "id")
    private MPLSDevicePolicy devicePolicy;

    void reverseMapDevicePolicy(MPLSDevicePolicy devicePolicy) {
        this.devicePolicy = devicePolicy;
    }

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ingress_port_id", referencedColumnName = "id")
    private Port ingressPort;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "egress_port_id", referencedColumnName = "id")
    private Port egressPort;

    @Id
    @Getter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Override
    public String getName() {
        return devicePolicy.getName();
    }
}