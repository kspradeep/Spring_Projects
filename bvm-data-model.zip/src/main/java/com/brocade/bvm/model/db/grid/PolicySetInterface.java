package com.brocade.bvm.model.db.grid;

import lombok.Data;

@Data
public class PolicySetInterface {
    private Long policySetId;
    private Long clusterNodeId;
}
