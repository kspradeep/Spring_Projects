package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortBandwidth {
  private long portId;
  private long inBandwidth;
  private long outBandwidth;
  private String receivedTime;
  private String lastUpdatedTime = "0";
  private double inUtilization;
  private double outUtilization;
  private long throughput;
  private long lineSpeed;

}
