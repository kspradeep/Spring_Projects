package com.brocade.bvm.model.db;


import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PacketTruncationMappingHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Entity(name = "packet_truncation_device_mapping")
public class PacketTruncationMapping extends ManagedObject implements HasHistory {

    public static final int FRAME_SIZE_MULTIPLE = 16;

    public static final int FRAME_SIZE_MIN = 64;

    public static final int FRAME_SIZE_MAX = 9216;

    public static final int MAX_FOUR = 4;

    public static final int SIZE_ONE = 1;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "port_id", referencedColumnName = "id")
    @Setter
    private Port port;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "port_group_id", referencedColumnName = "id")
    @Setter
    private PortGroup portGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "packet_truncation_id", referencedColumnName = "id")
    private PacketTruncation packetTruncation;

    void reverseMapPacketTruncation(PacketTruncation packetTruncation) {
        this.packetTruncation = packetTruncation;
    }

    @Override
    public HistoryObject buildHistory() {
        PacketTruncationMappingHistory packetTruncationMappingHistory = new PacketTruncationMappingHistory();
        BeanUtils.copyProperties(this, packetTruncationMappingHistory);
        packetTruncationMappingHistory.setName(this.getName());
        packetTruncationMappingHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(PacketTruncationMapping.class, new PacketTruncationMapingJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            packetTruncationMappingHistory.setPacketTruncationJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialize the Policy object in History", e);
        }
        return packetTruncationMappingHistory;
    }

    private class PacketTruncationMapingJsonSerializer extends JsonSerializer<PacketTruncationMapping> {

        @Override
        public void serialize(PacketTruncationMapping packetTruncationMapping, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", packetTruncationMapping.getId());
                if (packetTruncationMapping.getPacketTruncation() != null) {
                    jsonGenerator.writeObjectFieldStart("packetTruncation");
                    jsonGenerator.writeNumberField("id", packetTruncationMapping.getPacketTruncation().getId());
                    jsonGenerator.writeStringField("name", packetTruncationMapping.getPacketTruncation().getName());
                    jsonGenerator.writeNumberField("frameSize", packetTruncationMapping.getPacketTruncation().getFrameSize());
                    jsonGenerator.writeEndObject();
                }
                if (packetTruncationMapping.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", packetTruncationMapping.getWorkflowStatus().name());
                } else {
                    jsonGenerator.writeNullField("workflowStatus");
                }
                if (packetTruncationMapping.getDevice() != null) {
                    jsonGenerator.writeObjectFieldStart("device");
                    if (packetTruncationMapping.getDevice().getId() != null) {
                        jsonGenerator.writeNumberField("id", packetTruncationMapping.getDevice().getId());
                    } else {
                        jsonGenerator.writeNullField("id");
                    }
                    jsonGenerator.writeEndObject();
                }
                if (packetTruncationMapping.getPort() != null) {
                    jsonGenerator.writeObjectFieldStart("port");
                    if (packetTruncationMapping.getPort().getId() != null) {
                        jsonGenerator.writeNumberField("id", packetTruncationMapping.getPort().getId());
                    } else {
                        jsonGenerator.writeNullField("id");
                    }
                    jsonGenerator.writeEndObject();
                }
                if (packetTruncationMapping.getPortGroup() != null) {
                    jsonGenerator.writeObjectFieldStart("portGroup");
                    if (packetTruncationMapping.getPortGroup().getId() != null) {
                        jsonGenerator.writeNumberField("id", packetTruncationMapping.getPortGroup().getId());
                    } else {
                        jsonGenerator.writeNullField("id");
                    }
                    jsonGenerator.writeEndObject();
                }
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
