package com.brocade.bvm.model.db;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "reserved_vlan_device_policy")
@Polymorphism(type= PolymorphismType.EXPLICIT)
@Slf4j
public class ReservedVlanDevicePolicy extends DevicePolicy {

    @Column(name = "reserved_vlan")
    private Integer reservedVlan;

}
