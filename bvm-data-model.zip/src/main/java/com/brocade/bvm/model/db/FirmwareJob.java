package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "firmware_job")
@EntityListeners(CustomAuditingEntityListener.class)
public class FirmwareJob implements DomainObject {

    @Id
    @GeneratedValue
    private Long id;

    @JsonIgnore //TODO get only id
    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "target_host_id", referencedColumnName = "id")
    @JsonProperty
    private TargetHost targetHost;

    public Device getDevice() {
        assert targetHost instanceof Device;
        return (Device) targetHost;
    }

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Type type;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Status status = Status.CREATED;

    @Setter
    @Column(name = "parent_object_id")
    private Long parentObjectId;

    @Setter
    @Lob
    @Column(name = "job_result")
    private String jobResult;

    @Setter(AccessLevel.PACKAGE)
    @Column(name = "created_time")
    private Instant createdTime;

    @Setter(AccessLevel.PACKAGE)
    @Column(name = "last_updated_time")
    private Instant lastUpdatedTime;

    @Override
    public String getName() {
        return String.format("%s_%s", type, parentObjectId);
    }

    public enum Status {
        CREATED,
        SUBMITTED,
        SUCCESS,
        FAILED
    }

    public enum Type {
        FIRMWARE_UPGRADE, DEVICE_RELOAD;

        @Getter
        private boolean isDeleteParent;

        Type(boolean isDeleteParent) {
            this.isDeleteParent = isDeleteParent;
        }

        Type() {
            this.isDeleteParent = false;
        }
    }

    public enum Priority {
        LOW, HIGH
    }
}
