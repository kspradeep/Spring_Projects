package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
@NoArgsConstructor
@Entity(name = "intermediate_node")
public class IntermediateNode implements DomainObject, Comparable<IntermediateNode> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    private String name;

    @Setter
    private Integer sequence = 0;

    @JsonIgnore
    @Getter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_topology_path_id", referencedColumnName = "id")
    private GridTopologyPath gridTopologyPath;

    void reverseMapGridTopologyPath(GridTopologyPath gridTopologyPath) {
        this.gridTopologyPath = gridTopologyPath;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "intermediate_node_interface_mapping_ingress",
            joinColumns = {@JoinColumn(name = "node_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<ManagedObject> ingressPortsAndPortGroups = new HashSet<>();

    public void removeIngressPorts(Set<Port> ports) {
        this.ingressPortsAndPortGroups.removeAll(ports);
    }

    public void removeIngressPortGroups(Set<PortGroup> portGroups) {
        this.ingressPortsAndPortGroups.removeAll(portGroups);
    }

    public void addIngressPort(Port port) {
        if (port != null) {
            this.ingressPortsAndPortGroups.add(port);
        }
    }

    public void addIngressPortGroup(PortGroup portGroup) {
        if (portGroup != null) {
            this.ingressPortsAndPortGroups.add(portGroup);
        }
    }

    @JsonProperty
    public void setIngressPorts(Set<Port> ports) {
        this.ingressPortsAndPortGroups.addAll(ports);
    }

    @JsonProperty
    public void setIngressPortGroups(Set<PortGroup> portGroups) {
        this.ingressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public ImmutableSet<Port> getIngressPorts() {
        return ImmutableSet.copyOf(ingressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet()));
    }

    @JsonProperty
    public ImmutableSet<PortGroup> getIngressPortGroups() {
        return ImmutableSet.copyOf(ingressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet()));
    }

    public void clearIngressPortsAndPortGroups() {
        this.ingressPortsAndPortGroups.clear();
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "intermediate_node_interface_mapping_egress",
            joinColumns = {@JoinColumn(name = "node_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<ManagedObject> egressPortsAndPortGroups = new HashSet<>();

    public void removeEgressPorts(Set<Port> ports) {
        this.egressPortsAndPortGroups.removeAll(ports);
    }

    public void removeEgressPortGroups(Set<PortGroup> portGroups) {
        this.egressPortsAndPortGroups.removeAll(portGroups);
    }

    public void addEgressPort(Port port) {
        if (port != null) {
            this.egressPortsAndPortGroups.add(port);
        }
    }

    public void addEgressPortGroup(PortGroup portGroup) {
        if (portGroup != null) {
            this.egressPortsAndPortGroups.add(portGroup);
        }
    }

    @JsonProperty
    public void setEgressPorts(Set<Port> ports) {
        this.egressPortsAndPortGroups.addAll(ports);
    }

    @JsonProperty
    public void setEgressPortGroups(Set<PortGroup> portGroups) {
        this.egressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public ImmutableSet<Port> getEgressPorts() {
        return ImmutableSet.copyOf(egressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet()));
    }

    @JsonProperty
    public ImmutableSet<PortGroup> getEgressPortGroups() {
        return ImmutableSet.copyOf(egressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet()));
    }

    @Override
    public int compareTo(IntermediateNode intermediateNode) {
        //ascending order
        return this.sequence - intermediateNode.getSequence();
    }
}
