package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sd_egress_port_group_history")
public class EgressPortGroupHistory extends HistoryObject {

    @Setter
    @Lob
    @Column(name = "port_group_json")
    private String portGroupJson;

    @Override
    public SdPortGroup buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        SdPortGroup portGroup = null;
        try {
            portGroup = mapper.readValue(portGroupJson, SdPortGroup.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the sdPortGroup history",e);
        }
        return portGroup;
    }
}
