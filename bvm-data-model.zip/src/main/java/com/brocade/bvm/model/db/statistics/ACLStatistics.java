package com.brocade.bvm.model.db.statistics;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "acl_statistics")
public class ACLStatistics {

    @Id
    private Long id = System.nanoTime();

    @Setter
    @Column(name = "interface_name")
    private String interfaceName;

    @Setter
    @Column(name = "acl_name")
    private String aclName;

    @Setter
    @Column(name = "rules_count")
    private Long numberOfRules = 0L;;

    @Setter
    @Column(name = "policy_id")
    private Long policyId;

    @Setter
    @OneToMany(mappedBy = "aclStatistics", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ACL> acls = new HashSet<>();

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "pbr_statistics_id", referencedColumnName = "id")
    private PBRStatistics pbrStatistics;

}
