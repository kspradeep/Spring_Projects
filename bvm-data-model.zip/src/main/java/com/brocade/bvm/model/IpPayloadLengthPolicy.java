package com.brocade.bvm.model;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ModulePolicy;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.IpPayloadLengthPolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "ip_payload_length_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
public class IpPayloadLengthPolicy extends ModulePolicy implements HasHistory {

    public static final Integer PAYLOAD_LENGTH_MIN = 0;
    public static final Integer PAYLOAD_LENGTH_MAX = 16382;

    @Column(name = "min_range")
    @Setter
    private Long minRange;

    @Column(name = "max_range")
    @Setter
    private Long maxRange;

    @Column(name = "ip_type")
    @Setter
    @Enumerated(EnumType.STRING)
    private IpType ipType;

    @Column(name = "processor_number")
    @Setter
    @Enumerated(EnumType.STRING)
    private ProcessorNumber processor;

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    public enum IpType {
        IPV4,
        IPV6;
    }

    public enum ProcessorNumber {
        ALL("0"),
        ONE("1"),
        TWO("2");

        private String processorNumber;

        ProcessorNumber(String processorNumber) {
            this.processorNumber = processorNumber;
        }

        public String getProcessorNumber() {
            return this.processorNumber;
        }

    }

    @Override
    public HistoryObject buildHistory() {
        IpPayloadLengthPolicyHistory policyHistory = new IpPayloadLengthPolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(IpPayloadLengthPolicy.class, new IpPayloadLengthPolicy.IpPayloadLengthPolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the IpPayloadLengthPolicy Object in History", e);
        }
        return policyHistory;
    }

    private class IpPayloadLengthPolicyJsonSerializer extends JsonSerializer<IpPayloadLengthPolicy> {
        @Override
        public void serialize(IpPayloadLengthPolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                jsonGenerator.writeStringField("processor", String.valueOf(getProcessor().getProcessorNumber()));
                jsonGenerator.writeStringField("ipType", getIpType().name());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }


}
