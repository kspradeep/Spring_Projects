package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.DeviceGridHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "device_grid")
public class DeviceGrid extends ManagedObject implements HasHistory {

    public static final Integer TOOL_GROUP_ADDRESS_LIMIT = 8192;
    public static final Integer TOOL_ADDRESS_LIMIT = 8192;

    @Setter
    private String description;

    @JsonIgnore
    @OneToMany(mappedBy = "deviceGridSource", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private Set<GridCluster> sourceNodes = new HashSet<>();

    @JsonProperty
    public void setSourceNodes(Set<GridCluster> sourceNodes) {
        this.sourceNodes.clear();
        addSourceNodes(sourceNodes);
    }

    public void addSourceNodes(Set<GridCluster> sourceNodes) {
        this.sourceNodes.addAll(sourceNodes);
        sourceNodes.forEach(gridCluster -> gridCluster.reverseMapGridFlowSource(this));
    }

    public void removeSourceNodes(Set<GridCluster> sourceNodes) {
        this.sourceNodes.removeAll(sourceNodes);
    }

    @JsonProperty
    public Set<GridCluster> getSourceNodes() {
        return sourceNodes;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "deviceGridDestination", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private Set<GridCluster> destinationNodes = new HashSet<>();

    @JsonProperty
    public void setDestinationNodes(Set<GridCluster> destinationNodes) {
        this.destinationNodes.clear();
        addDestinationNodes(destinationNodes);
    }

    public void addDestinationNodes(Set<GridCluster> destinationNodes) {
        this.destinationNodes.addAll(destinationNodes);
        destinationNodes.forEach(gridCluster -> gridCluster.reverseMapGridFlowDestination(this));
    }

    public void removeDestinationNodes(Set<GridCluster> destinationNodes) {
        this.destinationNodes.removeAll(destinationNodes);
    }

    @JsonProperty
    public Set<GridCluster> getDestinationNodes() {
        return destinationNodes;
    }

    public enum TYPE {
        AGGREGATOR,
        DISTRIBUTOR
    }

    @Override
    public HistoryObject buildHistory() {
        DeviceGridHistory deviceGridHistory = new DeviceGridHistory();
        BeanUtils.copyProperties(this, deviceGridHistory);
        deviceGridHistory.setDeviceGridId(this.getId());
        deviceGridHistory.setName(this.getName());
        deviceGridHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(DeviceGrid.class, new DeviceGrid.DeviceGridJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            deviceGridHistory.setGridJson(mapper.writeValueAsString(this));
        } catch (Exception e) {
            throw new ServerException("Failed to serialize the Device Grid object in History", e);
        }
        return deviceGridHistory;
    }

    private class DeviceGridJsonSerializer extends JsonSerializer<DeviceGrid> {
        @Override
        public void serialize(DeviceGrid deviceGrid, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                if (deviceGrid.getId() != null) {
                    jsonGenerator.writeNumberField("id", deviceGrid.getId().longValue());
                } else {
                    jsonGenerator.writeNullField("id");
                }
                jsonGenerator.writeStringField("name", deviceGrid.getName());
                if (deviceGrid.getWorkflowStatus() != null)
                    jsonGenerator.writeStringField("workflowStatus", deviceGrid.getWorkflowStatus().name());
                else
                    jsonGenerator.writeNullField("workflowStatus");
                jsonGenerator.writeStringField("loopbackEnabled", deviceGrid.getDescription());
                jsonGenerator.writeArrayFieldStart("sourceNodes");
                if (deviceGrid.getSourceNodes() != null) {
                    deviceGrid.getSourceNodes().forEach(gridCluster -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (gridCluster.getId() != null) {
                                jsonGenerator.writeNumberField("id", gridCluster.getId().longValue());
                            } else {
                                jsonGenerator.writeNullField("id");
                            }
                            jsonGenerator.writeStringField("name", gridCluster.getName());
                            if (gridCluster.getDevice() != null) {
                                jsonGenerator.writeObjectFieldStart("device");
                                jsonGenerator.writeNumberField("id", gridCluster.getDevice().getId());
                                jsonGenerator.writeStringField("name", gridCluster.getDevice().getName());
                                jsonGenerator.writeEndObject();
                            }
                            jsonGenerator.writeArrayFieldStart("clusterNodeInterfaces");
                            if (gridCluster.getClusterNodeInterfaces() != null) {
                                gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                    try {
                                        jsonGenerator.writeStartObject();
                                        if (clusterNodeInterface.getId() != null) {
                                            jsonGenerator.writeNumberField("id", clusterNodeInterface.getId().longValue());
                                        } else {
                                            jsonGenerator.writeNullField("id");
                                        }
                                        jsonGenerator.writeStringField("name", clusterNodeInterface.getName());
                                        jsonGenerator.writeArrayFieldStart("ports");
                                        if (clusterNodeInterface.getPorts() != null) {
                                            clusterNodeInterface.getPorts().forEach(managedObject -> {
                                                try {
                                                    jsonGenerator.writeStartObject();
                                                    if (managedObject.getId() != null) {
                                                        jsonGenerator.writeNumberField("id", managedObject.getId().longValue());
                                                    } else {
                                                        jsonGenerator.writeNullField("id");
                                                    }
                                                    jsonGenerator.writeStringField("name", managedObject.getName());
                                                    jsonGenerator.writeEndObject();
                                                } catch (IOException e) {
                                                    throw new ServerException(e);
                                                }
                                            });
                                        }
                                        jsonGenerator.writeEndArray();
                                        jsonGenerator.writeArrayFieldStart("portGroups");
                                        if (clusterNodeInterface.getPortGroups() != null) {
                                            clusterNodeInterface.getPortGroups().forEach(managedObject -> {
                                                try {
                                                    jsonGenerator.writeStartObject();
                                                    if (managedObject.getId() != null) {
                                                        jsonGenerator.writeNumberField("id", managedObject.getId().longValue());
                                                    } else {
                                                        jsonGenerator.writeNullField("id");
                                                    }
                                                    jsonGenerator.writeStringField("name", managedObject.getName());
                                                    jsonGenerator.writeEndObject();
                                                } catch (IOException e) {
                                                    throw new ServerException(e);
                                                }
                                            });
                                        }
                                        jsonGenerator.writeEndArray();
                                        jsonGenerator.writeEndObject();
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                }
                jsonGenerator.writeEndArray();
                jsonGenerator.writeArrayFieldStart("destinationNodes");
                if (deviceGrid.getDestinationNodes() != null) {
                    deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (gridCluster.getId() != null) {
                                jsonGenerator.writeNumberField("id", gridCluster.getId().longValue());
                            } else {
                                jsonGenerator.writeNullField("id");
                            }
                            jsonGenerator.writeStringField("name", gridCluster.getName());
                            if (gridCluster.getDevice() != null) {
                                jsonGenerator.writeObjectFieldStart("device");
                                jsonGenerator.writeNumberField("id", gridCluster.getDevice().getId());
                                jsonGenerator.writeStringField("name", gridCluster.getDevice().getName());
                                jsonGenerator.writeEndObject();
                            }
                            jsonGenerator.writeArrayFieldStart("clusterNodeInterfaces");
                            if (gridCluster.getClusterNodeInterfaces() != null) {
                                gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                    try {
                                        jsonGenerator.writeStartObject();
                                        if (clusterNodeInterface.getId() != null) {
                                            jsonGenerator.writeNumberField("id", clusterNodeInterface.getId().longValue());
                                        } else {
                                            jsonGenerator.writeNullField("id");
                                        }
                                        jsonGenerator.writeStringField("name", clusterNodeInterface.getName());
                                        jsonGenerator.writeArrayFieldStart("ports");
                                        if (clusterNodeInterface.getPorts() != null) {
                                            clusterNodeInterface.getPorts().forEach(managedObject -> {
                                                try {
                                                    jsonGenerator.writeStartObject();
                                                    if (managedObject.getId() != null) {
                                                        jsonGenerator.writeNumberField("id", managedObject.getId().longValue());
                                                    } else {
                                                        jsonGenerator.writeNullField("id");
                                                    }
                                                    jsonGenerator.writeStringField("name", managedObject.getName());
                                                    jsonGenerator.writeEndObject();
                                                } catch (IOException e) {
                                                    throw new ServerException(e);
                                                }
                                            });
                                        }
                                        jsonGenerator.writeEndArray();
                                        jsonGenerator.writeArrayFieldStart("portGroups");
                                        if (clusterNodeInterface.getPortGroups() != null) {
                                            clusterNodeInterface.getPortGroups().forEach(managedObject -> {
                                                try {
                                                    jsonGenerator.writeStartObject();
                                                    if (managedObject.getId() != null) {
                                                        jsonGenerator.writeNumberField("id", managedObject.getId().longValue());
                                                    } else {
                                                        jsonGenerator.writeNullField("id");
                                                    }
                                                    jsonGenerator.writeStringField("name", managedObject.getName());
                                                    jsonGenerator.writeEndObject();
                                                } catch (IOException e) {
                                                    throw new ServerException(e);
                                                }
                                            });
                                        }
                                        jsonGenerator.writeEndArray();

                                        jsonGenerator.writeEndObject();
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                }
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
