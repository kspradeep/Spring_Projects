package com.brocade.bvm.model;

public interface WorkflowParticipant {
    WorkflowStatus getWorkflowStatus();

    /**
     * DRAFT +--> SUBMITTED +--> ACTIVE
     * ^            +            ^
     * |            |            |
     * |            v            +
     * +-------+ ERROR <--> REVERTING
     * <p>
     * Reconciled Policy +--> ACTIVE
     * +
     * |
     * +------------> ERROR
     * +
     * |
     * +------------> WARNING
     */
    enum WorkflowStatus {
        DRAFT, //Saved locally
        SUBMITTED, //Submitted to the job framework
        ERROR, //An earlier submitted job had failed
        REVERTING, //Rollback to an earlier known good state
        ACTIVE, //Applied on device
        WARNING, //Applied on Device but incomplete as per EVM(only for reconciled Policies)
    }
}
