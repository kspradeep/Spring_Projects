package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.FlexMatchProfile;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "flex_match_profile_history")
public class FlexMatchProfileHistory extends HistoryObject {

    @Setter
    @Column(name = "device_model")
    private String deviceModel;

    @Setter
    @Lob
    @Column(name = "profile_json")
    private String profileJson;

    public FlexMatchProfile buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        FlexMatchProfile flexMatchProfile = null;
        try {
            flexMatchProfile = mapper.readValue(profileJson, FlexMatchProfile.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the FlexMatchProfileHistory", e);
        }
        return flexMatchProfile;
    }
}
