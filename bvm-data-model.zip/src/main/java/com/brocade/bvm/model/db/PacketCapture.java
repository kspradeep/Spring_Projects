package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PacketCaptureHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Entity(name = "packet_capture")
public class PacketCapture extends ManagedObject implements HasHistory {

    public static final int PACKET_COUNT__MIN = 1;

    public static final int PACKET_COUNT__MAX = 8000;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "port_id", referencedColumnName = "id")
    @Setter
    private Port port;

    @Setter
    @Column
    private String direction;

    @Setter
    @Column
    private String filter;

    @Column(name = "packet_count")
    @Setter
    private Long packetCount;

    @Column(name = "destination_path")
    @Setter
    private String destinationPath;

    @Column(name = "destination_ip")
    @Setter
    private String destinationIp;

    @Column(name = "is_downloaded")
    @Setter
    private boolean downloaded;

    @Column(name = "is_pcap_created")
    @Setter
    private boolean pcapCreated;

    @Override
    public HistoryObject buildHistory() {
        PacketCaptureHistory packetCaptureHistory = new PacketCaptureHistory();
        BeanUtils.copyProperties(this, packetCaptureHistory);
        packetCaptureHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(PacketCapture.class, new PacketCaptureJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            packetCaptureHistory.setPacketCaptureJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialize the packet capture object in History", e);
        }
        return packetCaptureHistory;
    }

    private class PacketCaptureJsonSerializer extends JsonSerializer<PacketCapture> {

        @Override
        public void serialize(PacketCapture packetCapture, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();

                if (packetCapture.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", packetCapture.getWorkflowStatus().name());
                } else {
                    jsonGenerator.writeNullField("workflowStatus");
                }
                if (packetCapture.getDevice() != null) {
                    jsonGenerator.writeObjectFieldStart("device");
                    if (packetCapture.getDevice().getId() != null) {
                        jsonGenerator.writeNumberField("id", packetCapture.getDevice().getId());
                    } else {
                        jsonGenerator.writeNullField("id");
                    }
                    jsonGenerator.writeEndObject();
                }
                if (packetCapture.getPort() != null) {
                    jsonGenerator.writeObjectFieldStart("port");
                    if (packetCapture.getPort().getId() != null) {
                        jsonGenerator.writeNumberField("id", packetCapture.getPort().getId());
                    } else {
                        jsonGenerator.writeNullField("id");
                    }
                    jsonGenerator.writeEndObject();
                }
                jsonGenerator.writeStringField("direction", packetCapture.getDirection());
                jsonGenerator.writeStringField("filter", packetCapture.getFilter());
                if (packetCapture.getPacketCount() != null) {
                    jsonGenerator.writeNumberField("packetCount", packetCapture.getPacketCount());
                } else {
                    jsonGenerator.writeNullField("packetCount");
                }
                if (packetCapture.getDestinationPath() != null) {
                    jsonGenerator.writeStringField("destinationPath", packetCapture.getDestinationPath());
                } else {
                    jsonGenerator.writeNullField("destinationPath");
                }
                jsonGenerator.writeBooleanField("isPcapCreated", packetCapture.isPcapCreated());
                jsonGenerator.writeBooleanField("isDownloaded", packetCapture.isDownloaded());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
