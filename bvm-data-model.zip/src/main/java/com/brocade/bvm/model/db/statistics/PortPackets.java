package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortPackets {
    private int sequence;
    private String receivedTime;
    private long inPackets;
    private long outPackets;
    private long inBytes;
    private long outBytes;
    private long inPPS;
    private long outPPS;
    private long inPortsUtilization;
    private long outPortUtilization;
    private long throughput;
    private String lastUpdatedTime="0";
}
