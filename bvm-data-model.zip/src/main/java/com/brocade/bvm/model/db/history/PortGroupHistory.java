package com.brocade.bvm.model.db.history;

import java.io.IOException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Entity(name = "port_group_history")
public class PortGroupHistory extends HistoryObject<PortGroup> {

    @Setter
    @Lob
    @Column(name = "port_group_json")
    private String portGroupJson;

    @Override
    public PortGroup buildParent() {    	
    	ObjectMapper mapper = new ObjectMapper();    	
    	PortGroup portGroup = null;    	
    	try {            
    		portGroup =	mapper.readValue(portGroupJson, PortGroup.class);
		} catch (IOException e) {
            e.printStackTrace();
            throw new ServerException("Failed to construct the EgressPortGroupHistory",e);
		}    	
        return portGroup;
    }
}
