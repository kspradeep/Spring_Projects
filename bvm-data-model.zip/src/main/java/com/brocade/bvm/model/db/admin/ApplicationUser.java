package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.persistence.*;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@NoArgsConstructor
@Entity(name = "application_user")
public class ApplicationUser implements DomainObject {

    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Getter
    @Setter
    @Column
    private String username;

    @Column
    private String password;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Role role;

    public enum Role {
        ADMIN
    }

    @Getter
    @Setter
    @Column
    private String email;

    @Column(name = "temporary_token")
    private String temporaryToken;

    @Column(name = "token_generated_time")
    private Instant tokenGeneratedTime;

    private static SecureRandom random;
    private static final int TOKEN_EXPIRY_MINS = 60;

    public void setPassword(String password) {
        this.password = new BCryptPasswordEncoder().encode(password);
    }

    public boolean isPasswordEqualTo(String password) {
        return new BCryptPasswordEncoder().matches(password, this.password);
    }

    public String generateTemporaryToken() {
        String token = new BigInteger(128, random).toString(32);
        this.temporaryToken = new BCryptPasswordEncoder().encode(token);
        this.tokenGeneratedTime = Instant.now();
        return token;
    }

    public boolean isValidToken(String token) {
        return tokenGeneratedTime != null
                && tokenGeneratedTime.plus(TOKEN_EXPIRY_MINS, ChronoUnit.MINUTES).isAfter(Instant.now())
                && token != null && this.temporaryToken != null && new BCryptPasswordEncoder().matches(token, this.temporaryToken);
    }

    @Override
    public String getName() {
        return getUsername();
    }
}
