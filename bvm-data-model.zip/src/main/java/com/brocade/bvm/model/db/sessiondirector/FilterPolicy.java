package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.history.FilterPolicyHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@Setter
@Entity(name = "filter_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class FilterPolicy extends SdPolicy implements HasHistory {

    public final static String RESERVE_NAME_FILTER = "filter";

    @Column(name = "is_preserve_cplane")
    private boolean isPreserveCplane;

    @Column(name = "traffic_type")
    private String trafficType;

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "policy", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<FilterRule> rules = new TreeSet<>();

    public SortedSet<FilterRule> getRules() {
        return ImmutableSortedSet.copyOf(rules);
    }

    public void addRules(SortedSet<FilterRule> rules) {
        this.rules.addAll(rules);
        rules.forEach(rule -> rule.reverseMapPolicy(this));
    }

    public void removeRules(SortedSet<FilterRule> rules) {
        this.rules.removeAll(rules);
    }

    public void setRules(SortedSet<FilterRule> rules) {
        this.rules.clear();
        addRules(rules);
    }

    @Transient
    @JsonProperty(value = "records")
    @Getter
    private BulkFilterPolicyRequest bulkFilterPolicyRequest;

    @Override
    public HistoryObject buildHistory() {
        FilterPolicyHistory filterPolicyHistory = new FilterPolicyHistory();
        BeanUtils.copyProperties(this, filterPolicyHistory);
        filterPolicyHistory.setDevice(this.getDevice());
        filterPolicyHistory.setName(this.getName());
        filterPolicyHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(FilterPolicy.class, new FilterPolicy.PolicyJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            filterPolicyHistory.setPolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the FilterPolicy Object in History", e);
        }
        return filterPolicyHistory;
    }

    private class PolicyJsonSerializer extends JsonSerializer<FilterPolicy> {
        @Override
        public void serialize(FilterPolicy filterPolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", filterPolicy.getId().longValue());
                jsonGenerator.writeStringField("name", filterPolicy.getName());
                jsonGenerator.writeStringField("trafficType", filterPolicy.getTrafficType());
                jsonGenerator.writeBooleanField("preserveCplane", filterPolicy.isPreserveCplane());
                jsonGenerator.writeStringField("workflowStatus", filterPolicy.getWorkflowStatus().name());
                jsonGenerator.writeArrayFieldStart("rules");
                Device device = filterPolicy.getDevice();
                device.setLastCollectedTime(null);
                device.setLastUpdatedTime(null);
                filterPolicy.getRules().forEach(rule -> {
                    try {
                        if (rule.getPortGroup() != null) {
                            SdPortGroup sdPortGroup = rule.getPortGroup();
                            sdPortGroup.setDevice(device);
                            sdPortGroup.setEgressPorts(sdPortGroup.getEgressPorts());
                            rule.setPortGroup(sdPortGroup);
                        }

                        if (rule.getReplicationPortGroup() != null) {
                            SdPortGroup sdReplicationPortGroup = rule.getReplicationPortGroup();
                            sdReplicationPortGroup.setDevice(device);
                            sdReplicationPortGroup.setEgressPorts(sdReplicationPortGroup.getEgressPorts());
                            rule.setReplicationPortGroup(sdReplicationPortGroup);
                        }

                        if (rule.getSamplingPolicy() != null) {
                            SamplingPolicy samplingPolicy = rule.getSamplingPolicy();
                            samplingPolicy.setDevice(device);
                            rule.setSamplingPolicy(samplingPolicy);
                        }
                        jsonGenerator.writeObject(rule);
                    } catch (Exception e) {
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
