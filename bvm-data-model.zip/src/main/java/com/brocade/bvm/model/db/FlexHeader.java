package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.Enums;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "flex_header")
public class FlexHeader implements DomainObject, Comparable<FlexHeader> {

    //max byte length supported from all the headers in the stack
    public static final Integer HEADER_BYTE_LENGTH_MAX = 128;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flex_match_profile_id", referencedColumnName = "id")
    private FlexMatchProfile flexMatchProfile;

    void reverseMappingFlexMatch(FlexMatchProfile flexMatchProfile) {
        this.flexMatchProfile = flexMatchProfile;
    }

    //header Name
    //9240: ETH, IPV4, IPV6, UDP, TCP, VXLAN
    @Setter
    @Column(name = "header_name")
    @Enumerated(EnumType.STRING)
    private HEADER headerName;

    //9850: -1(ignore), OffsetBaseFirstHeader, OffsetBaseSecondHeader, OffsetBaseThirdHeader and OffsetBaseFourthHeader  (1-4)
    //9240: -1(ignore), h0, h1, h2, h3, h4, h5, h6, h7    (0-7)
    @Setter
    @Column(name = "header_level")
    private Integer headerLevel = -1;

    @Setter
    @Column
    private Integer sequence = 0;

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "flexHeader", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<FlexHeaderField> flexHeaderFields = new TreeSet<>();

    public ImmutableSortedSet<FlexHeaderField> getFlexHeaderFields() {
        return ImmutableSortedSet.copyOf(flexHeaderFields);
    }

    public void addFlexHeaderFields(SortedSet<FlexHeaderField> flexHeaderFields) {
        this.flexHeaderFields.addAll(flexHeaderFields);
        flexHeaderFields.forEach(header -> header.reverseMappingFlexHeader(this));
    }

    public void removeFlexHeaderFields(SortedSet<FlexHeaderField> flexHeaderFields) {
        this.flexHeaderFields.removeAll(flexHeaderFields);
    }

    public void setFlexHeaderFields(SortedSet<FlexHeaderField> flexHeaderFields) {
        this.flexHeaderFields.clear();
        addFlexHeaderFields(flexHeaderFields);
    }

    public enum HEADER {
        ETHERNET("ETHERNET"),
        MPLS("MPLS"), NSH("NSH"), PTP("PTP"), ARP("ARP"),
        IPV4("IPV4"), IPV4_PAYLOAD32("IPV4"), IPV4_PAYLOAD16("IPV4"), IPV4_GRE_PAYLOAD16("IPV4"), IPV4_GTP_IPV4("IPV4"), IPV4_GTP_IPV6("IPV4"), IPV4_TUNETHERNET_GRE("IPV4"), IPV4_PAYLOAD8("IPV4"),
        IPV6("IPV6"), IPV6_MPLS("IPV6"), IPV6_PAYLOAD32("IPV6"), IPV6_PAYLOAD16_IPV6("IPV6"), IPV6_TUNETHERNET_PAYLOAD32("IPV6"), IPV6_PAYLOAD16("IPV6"), IPV6_GTP_GRE("IPV6"), IPV6_PAYLOAD4("IPV6"), IPV6_GTP("IPV6"),
        GRE_IPV4("GRE"), GRE_IPV6("GRE"),
        TUN_ETHERNET("TUN_ETHERNET"),
        GTP_IPV4("GTP"), GTP_IPV6("GTP"),
        VXLAN("VXLAN"),
        ICMP("ICMP"), ICMP_PAYLOAD4("ICMP"), ICMP_PAYLOAD16("ICMP"),
        ICMPV6("ICMPV6"), ICMPV6_PAYLOAD8("ICMPV6"), ICMPV6_PAYLOAD16("ICMPV6"),
        IGMP("IGMP"), IGMP_PAYLOAD4("IGMP"), IGMP_PAYLOAD16("IGMP"),
        SCTP("SCTP"), SCTP_IPV6("SCTP"), SCTP_PAYLOAD4("SCTP"), SCTP_PAYLOAD8("SCTP"), SCTP_PAYLOAD16("SCTP"),
        TCP("TCP"), TCP_PAYLOAD4("TCP"), TCP_PAYLOAD8("TCP"), TCP_PAYLOAD16("TCP"),
        UDP("UDP"), UDP_IPV4("UDP"), UDP_IPV6("UDP"), UDP_PAYLOAD4("UDP"), UDP_PAYLOAD8("UDP"), UDP_PAYLOAD16("UDP"), UDP_PAYLOAD32("UDP"),
        PAYLOAD4("PAYLOAD4"), PAYLOAD8("PAYLOAD8"), PAYLOAD16("PAYLOAD16"), PAYLOAD32("PAYLOAD32");

        private String value;

        HEADER(String value) {
            this.value = value;
        }

        public String value() {
            return this.value;
        }

        public static HEADER getIfPresent(String name) {
            return Enums.getIfPresent(HEADER.class, name).orNull();
        }
    }

    public enum HEADER_BYTE_LENGTH {
        ETHERNET(14),
        TCP(20),
        TUN_ETHERNET(14),
        UDP(8),
        IPV4(20),
        SCTP(28),
        IPV6(40),
        IGMP(8),
        ARP(28),
        ICMP(8),
        ICMPV6(4),
        MPLS(4),
        GRE(4),
        VXLAN(8),
        GTP(8),
        PAYLOAD4(4),
        PAYLOAD8(8),
        PAYLOAD16(16),
        PAYLOAD32(32);

        private Integer byteLength;

        HEADER_BYTE_LENGTH(Integer byteLength) {
            this.byteLength = byteLength;
        }

        public Integer getByteLength() {
            return this.byteLength;
        }

        public static HEADER_BYTE_LENGTH getIfPresent(String name) {
            return Enums.getIfPresent(HEADER_BYTE_LENGTH.class, name).orNull();
        }
    }

    @Override
    public int compareTo(FlexHeader flexHeader) {
        return this.sequence - flexHeader.getSequence();
    }

    public void clearId() {
        this.id = null;
    }
}
