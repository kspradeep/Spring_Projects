package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.util.Objects;

@Data
public class PolicyUtilization {
  private Long id;
  private String name;
  Long hits;

  @Override
  public int hashCode() {
    return Long.hashCode(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) return false;
    if (!(obj instanceof PortUtilization)) return false;
    if (obj == this) return true;
    return Objects.equals(this.getId(), ((PolicyUtilization) obj).getId());
  }
}
