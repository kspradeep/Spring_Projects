package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "packet_truncation_device_history")
public class PacketTruncationMappingHistory extends HistoryObject<PacketTruncationMapping> {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "packet_truncation_json")
    private String packetTruncationJson;

    @Override
    public PacketTruncationMapping buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        PacketTruncationMapping packetTruncationMapping = null;
        try {
            packetTruncationMapping = mapper.readValue(packetTruncationJson, PacketTruncationMapping.class);
            packetTruncationMapping.setDevice(device);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the PacketTruncationHistory", e);
        }
        return packetTruncationMapping;
    }
}
