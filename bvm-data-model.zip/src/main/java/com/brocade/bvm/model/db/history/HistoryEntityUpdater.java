package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.ManagedObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import java.time.Instant;

@Slf4j
@Named
public class HistoryEntityUpdater {

    @Autowired
    private EntityManager entityManager;

    @PostPersist
    public void postPersist(Object target) {
        buildHistoryObject(target, HistoryObject.RevisionType.CREATED);
    }

    @PostUpdate
    public void postUpdate(Object target) {
        buildHistoryObject(target, HistoryObject.RevisionType.UPDATED);
    }

    @PostRemove
    public void postRemove(Object target) {
        buildHistoryObject(target, HistoryObject.RevisionType.DELETED);
    }

    private void buildHistoryObject(Object target, HistoryObject.RevisionType revisionType) {
        AutowireHelper.autowire(this, this.entityManager);
        if (target instanceof HasHistory && target instanceof ManagedObject) {
            HistoryObject historyObject = ((HasHistory) target).buildHistory();
            historyObject.setParentId(((HasHistory) target).getId());
            historyObject.setName(((ManagedObject) target).getName());
            historyObject.setWorkflowStatus(((ManagedObject) target).getWorkflowStatus());
            historyObject.setWorkflowType(((ManagedObject) target).getWorkflowType());
            historyObject.setRevisionType(revisionType);
            historyObject.setRevisionTime(Instant.now());
            entityManager.persist(historyObject);
        }
    }
}
