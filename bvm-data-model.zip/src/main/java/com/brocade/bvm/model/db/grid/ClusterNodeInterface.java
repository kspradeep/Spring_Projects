package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
@NoArgsConstructor
@Entity(name = "cluster_node_interface")
public class ClusterNodeInterface implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @JsonIgnore
    @Getter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_cluster_id", referencedColumnName = "id")
    private GridCluster gridCluster;

    void reverseMapNetworkNode(GridCluster gridCluster) {
        this.gridCluster = gridCluster;
    }

    @OneToMany(fetch = FetchType.LAZY)
    @JsonIgnore
    @JoinTable(name = "cluster_node_port_mapping",
            joinColumns = {@JoinColumn(name = "cluster_node_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<ManagedObject> portsAndPortGroups = new HashSet<>();

    public void removePorts(Set<Port> ports) {
        this.portsAndPortGroups.removeAll(ports);
    }

    public void removePortGroups(Set<PortGroup> portGroups) {
        this.portsAndPortGroups.removeAll(portGroups);
    }

    public void addPorts(Set<Port> ports) {
        this.portsAndPortGroups.addAll(ports);
    }

    public void addPortGroups(Set<PortGroup> portGroups) {
        this.portsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public void setPorts(Set<Port> ports) {
        this.portsAndPortGroups.addAll(ports);
    }

    @JsonProperty
    public void setPortGroups(Set<PortGroup> portGroups) {
        this.portsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public ImmutableSet<Port> getPorts() {
        return ImmutableSet.copyOf(portsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet()));
    }

    @JsonProperty
    public ImmutableSet<PortGroup> getPortGroups() {
        return ImmutableSet.copyOf(portsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet()));
    }

    public void clearPortsAndPortGroups() {
        this.portsAndPortGroups.clear();
    }

}
