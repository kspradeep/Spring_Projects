package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.IngressPortHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.IOException;

@Getter
@Entity(name = "sd_ingress_port")
public class IngressPort extends ManagedObject implements HasHistory {

    @Setter
    @Column
    private boolean jumboFrame;

    @Setter
    @Column
    private boolean ptpTimestamp;

    @Setter
    @Column
    private Integer vlanId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "profile_id", referencedColumnName = "id")
    private Profile profile;

    @JsonDeserialize
    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "physical_interface_id", referencedColumnName = "id")
    private PhysicalInterface physicalInterface;

    @JsonDeserialize
    public void setPhysicalInterface(PhysicalInterface physicalInterface) {
        this.physicalInterface = physicalInterface;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "service_port_id", referencedColumnName = "id")
    private Port servicePort;

    @JsonDeserialize
    public void setServicePort(Port servicePort) {
        this.servicePort = servicePort;
    }

    @Override
    public HistoryObject buildHistory() {
        IngressPortHistory portHistory = new IngressPortHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(IngressPort.class, new IngressPort.PortJsonSerializer());
        portHistory.setName(getName());
        portHistory.setWorkflowStatus(getWorkflowStatus());
        portHistory.setWorkflowType(this.getWorkflowType());
        mapper.registerModule(simpleModule);
        try {
            portHistory.setPortJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to create sd ingress port history", e);
        }
        return portHistory;
    }

    private class PortJsonSerializer extends JsonSerializer<IngressPort> {
        @Override
        public void serialize(IngressPort ingressPort, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", ingressPort.getId());
                jsonGenerator.writeStringField("name", ingressPort.getName());
                jsonGenerator.writeObjectField("physicalInterface", ingressPort.getPhysicalInterface());
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", ingressPort.getDevice().getId());
                jsonGenerator.writeEndObject();
                if (ingressPort.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", ingressPort.getWorkflowStatus().name());
                }
                if (ingressPort.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", ingressPort.getWorkflowType().name());
                }
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
