package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.GtpDeEncapsulationModulePolicyHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "gtp_de_encapsulation_module_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
public class GtpDeEncapsulationModulePolicy extends ModulePolicy implements HasHistory {

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "gtp_de_encapsulation_port_mapping", joinColumns = {@JoinColumn(name = "module_policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "port_id", referencedColumnName = "id")})
    private Set<Port> ports = new HashSet<>();

    public void removePorts(Set<Port> ports) {
        this.ports.removeAll(ports);
    }

    @JsonProperty
    public void setPorts(Set<Port> ports) {
        this.ports.clear();
        this.ports.addAll(ports);
    }

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @Override
    public HistoryObject buildHistory() {
        GtpDeEncapsulationModulePolicyHistory policyHistory = new GtpDeEncapsulationModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(GtpDeEncapsulationModulePolicy.class, new GtpDeEncapsulationModulePolicy.GtpDeEncapsulationModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the PacketSlicingModulePolicy Object in History", e);
        }
        return policyHistory;
    }


    private class GtpDeEncapsulationModulePolicyJsonSerializer extends JsonSerializer<GtpDeEncapsulationModulePolicy> {
        @Override
        public void serialize(GtpDeEncapsulationModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("ports");
                policy.getPorts().forEach(port -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", port.getId().longValue());
                        jsonGenerator.writeStringField("name", port.getName());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }
}
