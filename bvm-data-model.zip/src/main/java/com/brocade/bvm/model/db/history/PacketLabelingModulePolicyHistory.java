package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.PacketLabelingModulePolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@Slf4j
@Getter
@NoArgsConstructor
@Entity(name = "packet_labeling_module_policy_history")
public class PacketLabelingModulePolicyHistory extends HistoryObject<PacketLabelingModulePolicy> {
    @Setter
    @Lob
    @Column(name = "module_policy_json")
    private String modulePolicyJson;

    @Override
    public PacketLabelingModulePolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        PacketLabelingModulePolicy policy = null;
        try {
            policy = mapper.readValue(modulePolicyJson, PacketLabelingModulePolicy.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the PacketSlicingModulePolicyHistory", e);
        }
        return policy;
    }
}
