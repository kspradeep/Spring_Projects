package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@NoArgsConstructor
@Entity(name = "stablenet_device_config")
@Getter
public class StablenetDeviceConfig implements DomainObject {

    public static final String MLXE_COMMANDS_TEMPLATE = "Brocade MLXe Commands";
    public static final String DELETE_COMMAND_IF_EXISTS_TEMPLATE = "Brocade Delete Command if exists";
    public static final String USER_GROUP_ID_LIST = "USER_GROUP_ID_LIST";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Lob
    @Column(name = "value")
    private String value;
}
