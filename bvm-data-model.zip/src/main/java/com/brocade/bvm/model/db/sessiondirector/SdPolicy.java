package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;

@Getter
@Entity(name = "sd_policy")
@Inheritance(strategy = InheritanceType.JOINED)
@Polymorphism(type= PolymorphismType.EXPLICIT)
public abstract class SdPolicy extends ManagedObject {

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

}
