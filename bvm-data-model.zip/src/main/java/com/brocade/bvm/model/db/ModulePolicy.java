package com.brocade.bvm.model.db;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "module_policy")
@Inheritance(strategy = InheritanceType.JOINED)
//The @Polymorphism is used to prevent from creating a 61 Join issue.
//This will ensure to pull only the sub classes of the current class but not the sub-classes of the parent class.
//This way it ensures to pull data only from the relevent tables, this must be used when using the Inheritance Type joined.
// References: https://docs.jboss.org/hibernate/orm/5.0/javadocs/org/hibernate/annotations/PolymorphismType.html#EXPLICIT
//To Understand Implicit and Explicit : https://v4forums.wordpress.com/2008/12/27/implicit-explicit-polymorphism-in-hibernate/
@Polymorphism(type = PolymorphismType.EXPLICIT)
public abstract class ModulePolicy extends ManagedObject {

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "module_policy_mapping",
            joinColumns = {@JoinColumn(name = "module_policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "module_id", referencedColumnName = "id")})
    private Set<Module> modules = new HashSet<>();

    public void removeModule(Set<Module> modules) {
        this.modules.removeAll(modules);
    }

    public void addModules(Set<Module> modules) {
        this.modules.addAll(modules);
    }

    @JsonProperty
    public void setModules(Set<Module> modules) {
        this.modules.clear();
        this.modules.addAll(modules);
    }

    @JsonProperty
    public ImmutableSet<Module> getModules() {
        return ImmutableSet.copyOf(modules);
    }

    @Setter
    @Transient
    //for global policy management
    private Device device;

    //for getting the policy types for fetching global policies
    public enum Type {
        gtp_de_encapsulation_module_policy,
        header_stripping_module_policy,
        ip_payload_length_policy,
        load_balance_module_policy,
        packet_labeling_module_policy,
        packet_slicing_module_policy,
        packet_stamping_module_policy,
        slx_load_balance_module_policy
    }
}
