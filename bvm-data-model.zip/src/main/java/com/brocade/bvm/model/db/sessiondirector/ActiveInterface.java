package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.ActiveInterfaceHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.IOException;

@Slf4j
@Getter
@Setter
@Entity(name = "sd_active_interface")
public class ActiveInterface extends ManagedObject implements HasHistory {

    public static String VOLTE = "volte";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sampling_policy_id", referencedColumnName = "id")
    private SamplingPolicy samplingPolicy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "filter_policy_id", referencedColumnName = "id")
    private FilterPolicy filterPolicy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dedupe_policy_id", referencedColumnName = "id")
    private DeDupePolicy deDupePolicy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "port_group_id", referencedColumnName = "id")
    private SdPortGroup portGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "replication_port_group_id", referencedColumnName = "id")
    private SdPortGroup replicatePortGroup;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "interface_mapping_id", referencedColumnName = "id")
    private ProfileInterfaceMapping profileInterfaceMapping;

    @Override
    public HistoryObject buildHistory() {
        ActiveInterfaceHistory activeInterfaceHistory = new ActiveInterfaceHistory();
        BeanUtils.copyProperties(this, activeInterfaceHistory);
        activeInterfaceHistory.setName(this.getName());
        activeInterfaceHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(ActiveInterface.class, new ActiveInterface.ActiveInterfaceJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            activeInterfaceHistory.setInterfaceJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the ActiveInterface Object in History", e);
        }
        return activeInterfaceHistory;
    }

    private class ActiveInterfaceJsonSerializer extends JsonSerializer<ActiveInterface> {
        @Override
        public void serialize(ActiveInterface activeInterface, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", activeInterface.getId().longValue());
                jsonGenerator.writeStringField("name", activeInterface.getName());
                if (activeInterface.getReplicatePortGroup() != null) {
                    jsonGenerator.writeObjectFieldStart("replicatePortGroup");
                    jsonGenerator.writeNumberField("id", activeInterface.getReplicatePortGroup().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getReplicatePortGroup().getName());
                    jsonGenerator.writeEndObject();
                }
                if (activeInterface.getPortGroup() != null) {
                    jsonGenerator.writeObjectFieldStart("portGroup");
                    jsonGenerator.writeNumberField("id", activeInterface.getPortGroup().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getPortGroup().getName());
                    jsonGenerator.writeEndObject();
                }
                if (activeInterface.getProfileInterfaceMapping() != null) {
                    jsonGenerator.writeObjectFieldStart("profileInterfaceMapping");
                    jsonGenerator.writeNumberField("id", activeInterface.getProfileInterfaceMapping().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getProfileInterfaceMapping().getName());
                    jsonGenerator.writeEndObject();
                }
                if (activeInterface.getSamplingPolicy() != null) {
                    jsonGenerator.writeObjectFieldStart("samplingPolicy");
                    jsonGenerator.writeNumberField("id", activeInterface.getSamplingPolicy().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getSamplingPolicy().getName());
                    jsonGenerator.writeEndObject();
                }
                if (activeInterface.getDeDupePolicy() != null) {
                    jsonGenerator.writeObjectFieldStart("deDupePolicy");
                    jsonGenerator.writeNumberField("id", activeInterface.getDeDupePolicy().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getDeDupePolicy().getName());
                    jsonGenerator.writeEndObject();
                }
                if (activeInterface.getFilterPolicy() != null) {
                    jsonGenerator.writeObjectFieldStart("filterPolicy");
                    jsonGenerator.writeNumberField("id", activeInterface.getFilterPolicy().getId());
                    jsonGenerator.writeStringField("name", activeInterface.getFilterPolicy().getName());
                    jsonGenerator.writeEndObject();
                }
                jsonGenerator.writeStringField("workflowStatus", activeInterface.getWorkflowStatus().name());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
