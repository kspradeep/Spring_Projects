package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "grid_matrix")
public class GridMatrix extends ManagedObject implements HasHistory {

    @Setter
    @Column(name = "failure_count")
    private Integer failureCount = 0;

    @Setter
    @Column(name = "grid_policy_set_id")
    private Long gridPolicySetId;

    @Setter
    @Column(name = "policy_id")
    private Long policyId;

    @Setter
    @Column(name = "source_device_id")
    private Long sourceDeviceId;

    @Setter
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "matrix_destination_device_mapping", joinColumns = @JoinColumn(name = "matrix_id"))
    @Column(name = "destination_device_id")
    private Set<Long> destinationDeviceIds = new HashSet<>();

    public void addDestinationDeviceId(Long destinationDeviceId) {
        this.destinationDeviceIds.add(destinationDeviceId);
    }

    public void removeDestinationDeviceId(Long destinationDeviceId) {
        this.destinationDeviceIds.remove(destinationDeviceId);
    }

    @OneToMany(mappedBy = "gridMatrix", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private Set<GridTopologyPath> gridTopologyPaths = new HashSet<>();

    public ImmutableSet<GridTopologyPath> getGridTopologyPaths() {
        return ImmutableSet.copyOf(gridTopologyPaths);
    }

    public void setGridTopologyPaths(Set<GridTopologyPath> gridTopologyPaths) {
        this.gridTopologyPaths.clear();
        addGridTopologyPaths(gridTopologyPaths);
    }

    public void addGridTopologyPaths(Set<GridTopologyPath> gridTopologyPaths) {
        this.gridTopologyPaths.addAll(gridTopologyPaths);
        gridTopologyPaths.forEach(gridTopologyPath -> gridTopologyPath.reverseMapGridMatrix(this));
    }

    public void addGridTopologyPath(GridTopologyPath gridTopologyPath) {
        this.gridTopologyPaths.add(gridTopologyPath);
        gridTopologyPath.reverseMapGridMatrix(this);
    }

    public void removeGridTopologyPaths(Set<GridTopologyPath> gridTopologyPaths) {
        this.gridTopologyPaths.removeAll(gridTopologyPaths);
    }

    public void removeGridTopologyPath(GridTopologyPath gridTopologyPath) {
        this.gridTopologyPaths.remove(gridTopologyPath);
    }

    @OneToMany(mappedBy = "gridMatrix", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<DestinationGroup> destinationGroups = Sets.newHashSet();

    public ImmutableSet<DestinationGroup> getDestinationGroups() {
        return ImmutableSet.copyOf(destinationGroups);
    }

    public void addDestinationGroups(Set<DestinationGroup> destinationGroups) {
        this.destinationGroups.addAll(destinationGroups);
        destinationGroups.forEach(destinationGroup -> destinationGroup.reverseMapGridMatrix(this));
    }

    public void removeDestinationGroups(Set<DestinationGroup> destinationGroups) {
        this.destinationGroups.removeAll(destinationGroups);
    }

    public void setDestinationGroups(Set<DestinationGroup> destinationGroups) {
        this.destinationGroups.clear();
        addDestinationGroups(destinationGroups);
    }

    @Override
    public HistoryObject buildHistory() {
        GridMatrixHistory gridMatrixHistory = new GridMatrixHistory();
        BeanUtils.copyProperties(this, gridMatrixHistory);
        gridMatrixHistory.setGridPolicySetId(this.gridPolicySetId);
        gridMatrixHistory.setPolicyId(this.policyId);
        gridMatrixHistory.setName(this.getName());
        gridMatrixHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(GridMatrix.class, new GridMatrix.GridMatrixJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            gridMatrixHistory.setGridMatrixJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialize the GridMatrix object in History", e);
        }
        return gridMatrixHistory;
    }

    private class GridMatrixJsonSerializer extends JsonSerializer<GridMatrix> {
        @Override
        public void serialize(GridMatrix gridMatrix, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                if (gridMatrix.getId() != null) {
                    jsonGenerator.writeNumberField("id", gridMatrix.getId().longValue());
                } else {
                    jsonGenerator.writeNullField("id");
                }
                jsonGenerator.writeStringField("name", gridMatrix.getName());
                if (gridMatrix.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", gridMatrix.getWorkflowStatus().name());
                } else {
                    jsonGenerator.writeNullField("workflowStatus");
                }
                jsonGenerator.writeNumberField("failureCount", gridMatrix.failureCount);
                if (gridMatrix.gridPolicySetId != null) {
                    jsonGenerator.writeNumberField("gridPolicySetId", gridMatrix.gridPolicySetId);
                } else {
                    jsonGenerator.writeNullField("gridPolicySetId");
                }
                if (gridMatrix.policyId != null) {
                    jsonGenerator.writeNumberField("policyId", gridMatrix.policyId);
                } else {
                    jsonGenerator.writeNullField("policyId");
                }
                if (gridMatrix.sourceDeviceId != null) {
                    jsonGenerator.writeNumberField("sourceDeviceId", gridMatrix.sourceDeviceId);
                } else {
                    jsonGenerator.writeNullField("sourceDeviceId");
                }

                if (gridMatrix.getDestinationDeviceIds() != null) {
                    jsonGenerator.writeArrayFieldStart("destinationDeviceIds");
                    gridMatrix.getDestinationDeviceIds().forEach(destinationDeviceId -> {
                        try {
                            jsonGenerator.writeObject(destinationDeviceId);
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                    jsonGenerator.writeEndArray();
                }
                if (gridMatrix.getGridTopologyPaths() != null) {
                    jsonGenerator.writeArrayFieldStart("gridTopologyPaths");
                    gridMatrix.getGridTopologyPaths().forEach(gridTopologyPath -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (gridTopologyPath.getId() == null) {
                                jsonGenerator.writeNullField("id");
                            } else {
                                jsonGenerator.writeNumberField("id", gridTopologyPath.getId());
                            }
                            jsonGenerator.writeStringField("name", gridTopologyPath.getName());
                            if (gridTopologyPath.getPathId() != null) {
                                jsonGenerator.writeNumberField("pathId", gridTopologyPath.getPathId());
                            }
                            if (gridTopologyPath.getToolAddress() != null) {
                                jsonGenerator.writeNumberField("toolAddress", gridTopologyPath.getToolAddress());
                            }
                            if (gridTopologyPath.getPolicySetId() != null) {
                                jsonGenerator.writeNumberField("policySetId", gridTopologyPath.getPolicySetId());
                            }
                            if (gridTopologyPath.getBandwidth() != null) {
                                jsonGenerator.writeNumberField("bandwidth", gridTopologyPath.getBandwidth());
                            }
                            if (gridTopologyPath.getIsCspfEnabled() != null) {
                                jsonGenerator.writeBooleanField("isCspfEnabled", gridTopologyPath.getIsCspfEnabled());
                            }
                            if (Job.Type.POLICY_DELETE != gridMatrix.getWorkflowType() && Job.Type.POLICY_ROLLBACK != gridMatrix.getWorkflowType()) {
                                if (gridTopologyPath.getIsCspfEnabled() != null) {
                                    jsonGenerator.writeNumberField("toolNodeInterfaceId", gridTopologyPath.getToolNodeInterfaceId());
                                }
                                if (!gridTopologyPath.getTapNodeInterfaceIds().isEmpty()) {
                                    jsonGenerator.writeArrayFieldStart("tapNodeInterfaceIds");
                                    gridTopologyPath.getTapNodeInterfaceIds().forEach(interfaceId -> {
                                        try {
                                            jsonGenerator.writeObject(interfaceId);
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (!gridTopologyPath.getIntermediateNodes().isEmpty()) {
                                    jsonGenerator.writeArrayFieldStart("intermediateNodes");
                                    gridTopologyPath.getIntermediateNodes().forEach(intermediateNode -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            if (intermediateNode.getId() == null) {
                                                jsonGenerator.writeNullField("id");
                                            } else {
                                                jsonGenerator.writeNumberField("id", intermediateNode.getId());
                                            }
                                            jsonGenerator.writeStringField("name", intermediateNode.getName());
                                            jsonGenerator.writeNumberField("sequence", intermediateNode.getSequence());

                                            if (intermediateNode.getIngressPorts() != null) {
                                                jsonGenerator.writeArrayFieldStart("ingressPorts");
                                                intermediateNode.getIngressPorts().forEach(managedObject -> {
                                                    try {
                                                        jsonGenerator.writeStartObject();
                                                        jsonGenerator.writeNumberField("id", managedObject.getId());
                                                        jsonGenerator.writeStringField("name", managedObject.getName());
                                                        jsonGenerator.writeEndObject();
                                                    } catch (IOException e) {
                                                        throw new ServerException(e);
                                                    }
                                                });
                                                jsonGenerator.writeEndArray();
                                            }
                                            if (intermediateNode.getIngressPortGroups() != null) {
                                                jsonGenerator.writeArrayFieldStart("ingressPortGroups");
                                                intermediateNode.getIngressPortGroups().forEach(managedObject -> {
                                                    try {
                                                        jsonGenerator.writeStartObject();
                                                        jsonGenerator.writeNumberField("id", managedObject.getId());
                                                        jsonGenerator.writeStringField("name", managedObject.getName());
                                                        jsonGenerator.writeEndObject();
                                                    } catch (IOException e) {
                                                        throw new ServerException(e);
                                                    }
                                                });
                                                jsonGenerator.writeEndArray();
                                            }
                                            if (intermediateNode.getEgressPorts() != null) {
                                                jsonGenerator.writeArrayFieldStart("egressPorts");
                                                intermediateNode.getEgressPorts().forEach(managedObject -> {
                                                    try {
                                                        jsonGenerator.writeStartObject();
                                                        jsonGenerator.writeNumberField("id", managedObject.getId());
                                                        jsonGenerator.writeStringField("name", managedObject.getName());
                                                        jsonGenerator.writeEndObject();
                                                    } catch (IOException e) {
                                                        throw new ServerException(e);
                                                    }
                                                });
                                                jsonGenerator.writeEndArray();
                                            }
                                            if (intermediateNode.getEgressPortGroups() != null) {
                                                jsonGenerator.writeArrayFieldStart("egressPortGroups");
                                                intermediateNode.getEgressPortGroups().forEach(managedObject -> {
                                                    try {
                                                        jsonGenerator.writeStartObject();
                                                        jsonGenerator.writeNumberField("id", managedObject.getId());
                                                        jsonGenerator.writeStringField("name", managedObject.getName());
                                                        jsonGenerator.writeEndObject();
                                                    } catch (IOException e) {
                                                        throw new ServerException(e);
                                                    }
                                                });
                                                jsonGenerator.writeEndArray();
                                            }

                                            if (intermediateNode.getDevice() != null) {
                                                jsonGenerator.writeObjectFieldStart("device");
                                                if (intermediateNode.getDevice().getId() == null) {
                                                    jsonGenerator.writeNullField("id");
                                                } else {
                                                    jsonGenerator.writeNumberField("id", intermediateNode.getDevice().getId());
                                                }
                                                jsonGenerator.writeEndObject();
                                            }
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                            }

                            if (gridTopologyPath.getSourceNetworkNode() != null && Job.Type.POLICY_DELETE != gridMatrix.getWorkflowType() && Job.Type.POLICY_ROLLBACK != gridMatrix.getWorkflowType()) {
                                jsonGenerator.writeObjectFieldStart("sourceNetworkNode");
                                if (gridTopologyPath.getSourceNetworkNode().getId() == null) {
                                    jsonGenerator.writeNullField("id");
                                } else {
                                    jsonGenerator.writeNumberField("id", gridTopologyPath.getSourceNetworkNode().getId());
                                }
                                if (gridTopologyPath.getSourceNetworkNode().getIngressPorts() != null) {
                                    jsonGenerator.writeArrayFieldStart("ingressPorts");
                                    gridTopologyPath.getSourceNetworkNode().getIngressPorts().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getSourceNetworkNode().getIngressPortGroups() != null) {
                                    jsonGenerator.writeArrayFieldStart("ingressPortGroups");
                                    gridTopologyPath.getSourceNetworkNode().getIngressPortGroups().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getSourceNetworkNode().getEgressPorts() != null) {
                                    jsonGenerator.writeArrayFieldStart("egressPorts");
                                    gridTopologyPath.getSourceNetworkNode().getEgressPorts().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getSourceNetworkNode().getEgressPortGroups() != null) {
                                    jsonGenerator.writeArrayFieldStart("egressPortGroups");
                                    gridTopologyPath.getSourceNetworkNode().getEgressPortGroups().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }

                                if (gridTopologyPath.getSourceNetworkNode().getDevice() != null) {
                                    jsonGenerator.writeObjectFieldStart("device");
                                    if (gridTopologyPath.getSourceNetworkNode().getDevice().getId() == null) {
                                        jsonGenerator.writeNullField("id");
                                    } else {
                                        jsonGenerator.writeNumberField("id", gridTopologyPath.getSourceNetworkNode().getDevice().getId());
                                    }
                                    jsonGenerator.writeEndObject();
                                }
                                jsonGenerator.writeEndObject();
                            }
                            if (gridTopologyPath.getDestinationNetworkNode() != null && Job.Type.POLICY_DELETE != gridMatrix.getWorkflowType() && Job.Type.POLICY_ROLLBACK != gridMatrix.getWorkflowType()) {
                                jsonGenerator.writeObjectFieldStart("destinationNetworkNode");
                                if (gridTopologyPath.getDestinationNetworkNode().getId() == null) {
                                    jsonGenerator.writeNullField("id");
                                } else {
                                    jsonGenerator.writeNumberField("id", gridTopologyPath.getDestinationNetworkNode().getId());
                                }
                                if (gridTopologyPath.getDestinationNetworkNode().getDevice() != null) {
                                    jsonGenerator.writeObjectFieldStart("device");
                                    if (gridTopologyPath.getDestinationNetworkNode().getDevice().getId() == null) {
                                        jsonGenerator.writeNullField("id");
                                    } else {
                                        jsonGenerator.writeNumberField("id", gridTopologyPath.getDestinationNetworkNode().getDevice().getId());
                                    }
                                    jsonGenerator.writeEndObject();
                                }
                                if (gridTopologyPath.getDestinationNetworkNode().getIngressPorts() != null) {
                                    jsonGenerator.writeArrayFieldStart("ingressPorts");
                                    gridTopologyPath.getDestinationNetworkNode().getIngressPorts().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getDestinationNetworkNode().getIngressPortGroups() != null) {
                                    jsonGenerator.writeArrayFieldStart("ingressPortGroups");
                                    gridTopologyPath.getDestinationNetworkNode().getIngressPortGroups().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getDestinationNetworkNode().getEgressPorts() != null) {
                                    jsonGenerator.writeArrayFieldStart("egressPorts");
                                    gridTopologyPath.getDestinationNetworkNode().getEgressPorts().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                if (gridTopologyPath.getDestinationNetworkNode().getEgressPortGroups() != null) {
                                    jsonGenerator.writeArrayFieldStart("egressPortGroups");
                                    gridTopologyPath.getDestinationNetworkNode().getEgressPortGroups().forEach(managedObject -> {
                                        try {
                                            jsonGenerator.writeStartObject();
                                            jsonGenerator.writeNumberField("id", managedObject.getId());
                                            jsonGenerator.writeStringField("name", managedObject.getName());
                                            jsonGenerator.writeEndObject();
                                        } catch (IOException e) {
                                            throw new ServerException(e);
                                        }
                                    });
                                    jsonGenerator.writeEndArray();
                                }
                                jsonGenerator.writeEndObject();
                            }
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                    jsonGenerator.writeEndArray();
                }
                if (gridMatrix.getDestinationGroups() != null) {
                    jsonGenerator.writeArrayFieldStart("destinationGroups");
                    gridMatrix.getDestinationGroups().forEach(destinationGroup -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (destinationGroup.getId() == null) {
                                jsonGenerator.writeNullField("id");
                            } else {
                                jsonGenerator.writeNumberField("id", destinationGroup.getId());
                            }
                            jsonGenerator.writeStringField("name", destinationGroup.getName());
                            jsonGenerator.writeNumberField("groupId", destinationGroup.getGroupId());
                            jsonGenerator.writeArrayFieldStart("gridTopologyPathIds");
                            destinationGroup.getGridTopologyPathIds().forEach(topologyPathId -> {
                                try {
                                    jsonGenerator.writeObject(topologyPathId);
                                } catch (IOException e) {
                                    throw new ServerException(e);
                                }
                            });
                            jsonGenerator.writeEndArray();
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                    jsonGenerator.writeEndArray();
                }
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
