package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.time.Instant;

@Data
public class SystemUtilizationModel {
    private long id;
    private String lastUpdatedTime;
    private long totalSystemMemory;
    private long totalUsedMemory;
    private long totalFreeMemory;
    private long cachedMemory;
    private long buffers;
    private long userFreeMemory;
    private long kernelFreeMemory;
    private long userProcess;
    private long systemProcess;
    private long idleState;
    private long uptime;
}
