package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.GTPDevicePolicyHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.MPLSDevicePolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "mpls_device_policy")
@Slf4j
public class MPLSDevicePolicy extends DevicePolicy implements HasHistory {

    @JsonIgnore
    @OneToMany(mappedBy = "devicePolicy", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Set<MPLSPair> mplsPairs = new HashSet<>();

    public ImmutableSet<MPLSPair> getMPLSPairs() {
        return ImmutableSet.copyOf(mplsPairs);
    }

    public void addMPLSPairs(Set<MPLSPair> mplsPair) {
        this.mplsPairs.addAll(mplsPair);
        mplsPair.forEach(eachPair -> eachPair.reverseMapDevicePolicy(this));
    }

    public void removeMPLSPairs(Set<MPLSPair> mplsPair) {
        this.mplsPairs.removeAll(mplsPair);
    }

    @JsonProperty(value = "mplsPairs")
    public void setMPLSPairs(Set<MPLSPair> mplsPair) {
        this.mplsPairs.clear();
        addMPLSPairs(mplsPair);
    }

    @Override
    public HistoryObject buildHistory() {
        MPLSDevicePolicyHistory policyHistory = new MPLSDevicePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(MPLSDevicePolicy.class, new MPLSDevicePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setDevice(this.getDevice());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setDevicePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the Policy Object in History",e);
        }
        return policyHistory;
    }

    private class MPLSDevicePolicyJsonSerializer extends JsonSerializer<MPLSDevicePolicy> {
        @Override
        public void serialize(MPLSDevicePolicy devicePolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", devicePolicy.getId().longValue());
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                if (devicePolicy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", devicePolicy.getWorkflowStatus().name());
                }
                if (devicePolicy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", devicePolicy.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("mplsPairs");
                devicePolicy.getMPLSPairs().forEach(mplsPair -> {
                    try {
                        jsonGenerator.writeStartObject();
                        //jsonGenerator.writeNumberField("id", mplsPair.getId().longValue()); commented to avoid NullPointerPointerException
                        jsonGenerator.writeObjectFieldStart("ingressPort");
                        jsonGenerator.writeNumberField("id", mplsPair.getIngressPort().getId().longValue());
                        jsonGenerator.writeStringField("name", mplsPair.getIngressPort().getName());
                        jsonGenerator.writeEndObject();
                        jsonGenerator.writeObjectFieldStart("egressPort");
                        jsonGenerator.writeNumberField("id", mplsPair.getEgressPort().getId().longValue());
                        jsonGenerator.writeStringField("name", mplsPair.getEgressPort().getName());
                        jsonGenerator.writeEndObject();
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }
}
