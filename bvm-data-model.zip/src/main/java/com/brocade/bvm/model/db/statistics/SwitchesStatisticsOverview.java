package com.brocade.bvm.model.db.statistics;

import com.brocade.bvm.model.db.Device;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
public class SwitchesStatisticsOverview {
    private List<String> topFiveDevices;
    private List<Device> bottomFiveDevices;
    private Set<String> topFiveTapPorts;
    private Set<String> bottomFiveTapPorts;
    private Set<String> topFiveToolPorts;
    private Set<String> bottomFiveToolPorts;
    private List<String> topFivePolicies = new ArrayList<>();
    private List<String> bottomFivePolicies = new ArrayList<>();
}
