package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "grid_policy_set_history")
public class GridPolicySetHistory extends HistoryObject<GridPolicySet> {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "grid_id", referencedColumnName = "id")
    @Setter
    private DeviceGrid deviceGrid;

    @Setter
    @Lob
    @Column(name = "policy_json")
    private String policyJson;

    @Override
    public GridPolicySet buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        GridPolicySet gridPolicySet = null;
        try {
            gridPolicySet = mapper.readValue(policyJson, GridPolicySet.class);
            gridPolicySet.setDeviceGrid(deviceGrid);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the GridPolicySetHistory", e);
        }
        return gridPolicySet;
    }
}
