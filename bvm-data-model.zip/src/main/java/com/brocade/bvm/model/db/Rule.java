package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.constraints.Max;

/**
 * Rule bean containing capability to support all rule types
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "rule")
public class Rule implements DomainObject, Comparable<Rule> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ruleset_id", referencedColumnName = "id")
    private RuleSet ruleSet;

    void reverseMapRuleSet(RuleSet ruleSet) {
        this.ruleSet = ruleSet;
    }

    @Setter
    @Column(name = "grid_rule_id")
    private Long gridRuleId;

    @Setter
    @Column(name = "source_ip")
    private String sourceIp;

    @Setter
    @Max(65535)
    @Column(name = "source_port")
    private Integer sourcePort;

    @Setter
    @Column(name = "source_port_operator")
    private String sourcePortOperator;

    @Setter
    @Column(name = "destination_ip")
    private String destinationIp;

    @Setter
    @Max(65535)
    @Column(name = "destination_port")
    private Integer destinationPort;

    @Setter
    @Column(name = "destination_port_operator")
    private String destinationPortOperator;

    @Setter
    @Max(4096)
    @Column(name = "vlan_id")
    private Integer vlanId;

    @Setter
    @Column
    private String protocol;

    @Setter
    @Column(name = "protocol_type")
    private String protocolType;

    @Setter
    @JsonProperty(value = "permit")
    @Column(name = "is_permit")
    private Boolean isPermit;

    @Setter
    @Column(name = "custom_acl")
    @Type(type = "text")
    private String customAcl;

    @Setter
    @Column(name = "source_mac")
    private String sourceMac;

    @Setter
    @Column(name = "source_mac_mask")
    private String sourceMacMask;

    @Setter
    @Column(name = "destination_mac")
    private String destinationMac;

    @Setter
    @Column(name = "destination_mac_mask")
    private String destinationMacMask;

    @Setter
    @Column(name = "eth_type")
    private String ethType;

    @Setter
    @Column
    private Long sequence;

    @Setter
    @Column(name = "field_mask_1")
    private String fieldmask1;

    @Setter
    @Column(name = "field_mask_2")
    private String fieldmask2;

    @Setter
    @Column(name = "field_mask_3")
    private String fieldmask3;

    @Setter
    @Column(name = "field_mask_4")
    private String fieldmask4;

    @Setter
    @Column(name = "field_value_1")
    private String fieldValue1;

    @Setter
    @Column(name = "field_value_2")
    private String fieldValue2;

    @Setter
    @Column(name = "field_value_3")
    private String fieldValue3;

    @Setter
    @Column(name = "field_value_4")
    private String fieldValue4;

    @Setter
    @Column(name = "is_hexadecimal_type_1")
    private Boolean isHexadecimalType1 = true;

    @Setter
    @Column(name = "is_hexadecimal_type_2")
    private Boolean isHexadecimalType2 = true;

    @Setter
    @Column(name = "is_hexadecimal_type_3")
    private Boolean isHexadecimalType3 = true;

    @Setter
    @Column(name = "is_hexadecimal_type_4")
    private Boolean isHexadecimalType4 = true;

    @Setter
    @Column(name = "byte_size_1")
    private Integer byteSize1;

    @Setter
    @Column(name = "byte_size_2")
    private Integer byteSize2;

    @Setter
    @Column(name = "byte_size_3")
    private Integer byteSize3;

    @Setter
    @Column(name = "byte_size_4")
    private Integer byteSize4;

    @Setter
    @Column(name = "is_match_payload_length")
    private Boolean matchPayloadLength = false;

    @Setter
    @Column(name = "is_count_enabled")
    private Boolean isCountEnabled = false;

    @Override
    public int compareTo(Rule rule) {
        //ascending order
        return this.sequence.compareTo(rule.getSequence());
    }

    public void clearId() {
        this.id = null;
    }
}
