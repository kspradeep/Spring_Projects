package com.brocade.bvm.model.exception;

import lombok.Getter;

@Getter
public class UserVisibileException extends RuntimeException {
    private String messageId;

    public UserVisibileException(String messageId) {
        super(messageId);
        this.messageId = messageId;
    }
}
