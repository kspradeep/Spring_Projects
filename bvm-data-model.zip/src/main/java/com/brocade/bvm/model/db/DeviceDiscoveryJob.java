package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor

@Entity(name = "discovery_job")
public class DeviceDiscoveryJob implements DomainObject {

    public final static String IP = "ip";

    public final static String CLI_USER = "cli user";

    public final static String CLI_PASSWORD = "cli password";

    public final static String CLI_ENABLE_PASSWORD = "cli enable password";

    public final static String SNMP_COMMUNITY = "snmp_community";

    public final static String SNMP_WRITE_COMMUNITY = "snmp_write_community";

    public final static String DISCOVERY_AUTO_USE_ALL_IP = "discovery_auto_use_all_ip";

    public final static String DISCOVERY_AUTO_USE_INTERFACE_DESCRIPTION = "discovery_auto_use_interface_description";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @JsonIgnore
    @Column(name = "obj_id")
    private String objId;

    @JsonIgnore
    @Transient
    private Type type;

    @JsonIgnore
    @Transient
    private TemplateName templateName;

    @Transient
    private Set<String> ips;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "cli_username")
    private String cliUserName;

    @Transient
    private String cliPassword;

    @Column(name = "snmp_community")
    private String snmpCommunity;

    @Column(name = "snmp_write_community")
    private String snmpWriteCommunity;

    @Transient
    private String cliEnablePassword;

    @JsonIgnore
    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "is_running")
    private boolean isRunning;

    @Enumerated(EnumType.STRING)
    @Column(name = "trigger_type")
    private TriggerType triggerType;

    @Column(name = "interval_value")
    private Long intervalValue;

    @Column(name = "job_status")
    @Enumerated(EnumType.STRING)
    private JOB_STATUS job_status;

    @Lob
    private String response;

    @Override
    public String getName() {
        return null;
    }

    public enum Type {
        XML("xmldiscovery"), REDISCOVERY("rediscovery");

        private String value;

        public String getValue() {
            return this.value;
        }

        private Type(String value) {
            this.value = value;
        }

    }

    public enum TriggerType {
        SINGLE, INTERVAL, DAILY, MONTHLY
    }

    public enum TemplateName {
        SINGLE_DEVICE_XML("Brocade Discovery Single Device.xml"), SESSION_DIRECTOR("Brocade Discovery Session Director.xml");

        private String value;

        public String getValue() {
            return this.value;
        }

        private TemplateName(String value) {
            this.value = value;
        }

    }

    public enum JOB_STATUS {
        SUCCESS, FAILED
    }
}
