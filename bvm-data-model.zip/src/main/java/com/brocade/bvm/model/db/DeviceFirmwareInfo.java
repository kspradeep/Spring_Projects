package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.WorkflowParticipant;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "device_firmware_info")
@EntityListeners(CustomAuditingEntityListener.class)
public class DeviceFirmwareInfo implements DomainObject {

    @Id
    @GeneratedValue
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @Setter
    @Column(name = "username")
    private String username;

    @Setter
    @Column(name = "password")
    private String password;

    @Setter
    @Column(name = "firmware_name")
    private String firmwareName;

    @Setter
    @JsonProperty(value = "rebootRequired")
    @Column(name = "is_reboot_required")
    private Boolean rebootRequired = false;

    @Setter
    @Column(name = "workflow_status")
    @Enumerated(EnumType.STRING)
    private WorkflowParticipant.WorkflowStatus workflowStatus;

    @Setter
    @Column(name = "is_deleted")
    private Boolean deleted;

    @Override
    public String getName() {
        return null;
    }
}
