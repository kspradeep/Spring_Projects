package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.db.FlexMatchProfile;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.GridPolicySetHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "grid_policy_set")
@Slf4j
public class GridPolicySet extends ManagedObject implements HasHistory {

    public static final String POLICY_NAME_FORMAT = "rm_%s";

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_id", referencedColumnName = "id")
    @JsonProperty(value = "device")
    private DeviceGrid deviceGrid;

    @JsonDeserialize
    @JsonProperty(value = "device")
    public void setDeviceGrid(DeviceGrid deviceGrid) {
        this.deviceGrid = deviceGrid;
    }

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "gridPolicySet", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonProperty(value = "flows")
    private SortedSet<GridPolicy> gridPolicies = new TreeSet<>();

    public ImmutableSortedSet<GridPolicy> getGridPolicies() {
        return ImmutableSortedSet.copyOf(gridPolicies);
    }

    public void addGridPolicies(SortedSet<GridPolicy> gridPolicies) {
        this.gridPolicies.addAll(gridPolicies);
        gridPolicies.forEach(gridPolicy -> gridPolicy.reverseMapGridPolicySet(this));
    }

    public void removeGridPolicies(SortedSet<GridPolicy> gridPolicies) {
        this.gridPolicies.removeAll(gridPolicies);
    }

    public void setGridPolicies(SortedSet<GridPolicy> gridPolicies) {
        this.gridPolicies.clear();
        addGridPolicies(gridPolicies);
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "grid_template_policy_mapping",
            joinColumns = {@JoinColumn(name = "policy_set_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "template_id", referencedColumnName = "id")})
    private Set<FlexMatchProfile> flexMatchProfiles = new HashSet<>();

    public ImmutableSet<FlexMatchProfile> getFlexMatchProfiles() {
        return ImmutableSortedSet.copyOf(flexMatchProfiles);
    }

    public void addFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.addAll(flexMatchProfiles);
    }

    public void removeFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.removeAll(flexMatchProfiles);
    }

    @JsonProperty
    public void setFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.clear();
        addFlexMatchProfiles(flexMatchProfiles);
    }

    @Setter
    @Column(name = "is_cspf_enabled")
    private Boolean isCspfEnabled;

    @Setter
    @Column(name = "is_over_subscription_allowed")
    private Boolean isOverSubscriptionAllowed = false;

    @Setter
    @Transient
    private Boolean isManualReloadRequired = false;

    @Setter
    @Column(name = "field_offset_1")
    private Long fieldOffset1;

    @Setter
    @Column(name = "field_offset_2")
    private Long fieldOffset2;

    @Setter
    @Column(name = "field_offset_3")
    private Long fieldOffset3;

    @Setter
    @Column(name = "field_offset_4")
    private Long fieldOffset4;

    @Setter
    @Column(name = "is_loopback")
    private boolean isLoopbackEnabled;

    @Setter
    @Column(name = "is_timestamp")
    private boolean isTimestamp;

    @Setter
    @Column(name = "is_gtp_http_filtered")
    private boolean isGtpHttpFiltered;

    @Setter
    @Column(name = "is_ingress_valid")
    private boolean isIngressValid;

    @Setter
    @Column(name = "egress_action")
    private String egressAction;

    @Setter
    @Getter
    @Column(name = "preserve_header")
    private boolean preserveHeader;

    @Override
    public HistoryObject buildHistory() {
        GridPolicySetHistory policyHistory = new GridPolicySetHistory();
        BeanUtils.copyProperties(this, policyHistory);
        policyHistory.setDeviceGrid(this.deviceGrid);
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(GridPolicySet.class, new GridPolicySetJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setPolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialize the Policy object in History", e);
        }
        return policyHistory;
    }

    private class GridPolicySetJsonSerializer extends JsonSerializer<GridPolicySet> {
        @Override
        public void serialize(GridPolicySet policySet, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                if (policySet.getId() != null) {
                    jsonGenerator.writeNumberField("id", policySet.getId().longValue());
                } else {
                    jsonGenerator.writeNullField("id");
                }
                jsonGenerator.writeStringField("name", policySet.getName());
                jsonGenerator.writeStringField("workflowStatus", policySet.getWorkflowStatus().name());
                if (policySet.getFieldOffset1() != null && policySet.getFieldOffset2() != null && policySet.getFieldOffset3() != null && policySet.getFieldOffset4() != null) {
                    jsonGenerator.writeNumberField("fieldOffset1", policySet.getFieldOffset1());
                    jsonGenerator.writeNumberField("fieldOffset2", policySet.getFieldOffset2());
                    jsonGenerator.writeNumberField("fieldOffset3", policySet.getFieldOffset3());
                    jsonGenerator.writeNumberField("fieldOffset4", policySet.getFieldOffset4());
                }
                jsonGenerator.writeBooleanField("loopbackEnabled", policySet.isLoopbackEnabled);
                jsonGenerator.writeBooleanField("timestamp", policySet.isTimestamp);
                jsonGenerator.writeBooleanField("gtpHttpFiltered", policySet.isGtpHttpFiltered);
                jsonGenerator.writeBooleanField("ingressValid", policySet.isIngressValid);
                jsonGenerator.writeStringField("egressAction", policySet.getEgressAction());
                jsonGenerator.writeBooleanField("preserveHeader", policySet.preserveHeader);
                jsonGenerator.writeBooleanField("isCspfEnabled", policySet.isCspfEnabled);
                jsonGenerator.writeBooleanField("isOverSubscriptionAllowed", policySet.isOverSubscriptionAllowed);

                jsonGenerator.writeArrayFieldStart("flexMatchProfiles");
                policySet.getFlexMatchProfiles().forEach(profile -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", profile.getId());
                        jsonGenerator.writeStringField("name", profile.getName());
                        jsonGenerator.writeBooleanField("isInUse", profile.getIsInUse());
                        jsonGenerator.writeArrayFieldStart("flexHeaders");
                        profile.getFlexHeaders().forEach(flexHeader -> {
                            try {
                                jsonGenerator.writeObject(flexHeader);
                            } catch (IOException e) {
                                throw new ServerException(e);
                            }
                        });
                        jsonGenerator.writeEndArray();
                        jsonGenerator.writeEndObject();
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();

                jsonGenerator.writeArrayFieldStart("flows");
                policySet.getGridPolicies().forEach(flow -> {
                    try {
                        jsonGenerator.writeStartObject();
                        if (flow.getId() == null) {
                            jsonGenerator.writeNullField("id");
                        } else {
                            jsonGenerator.writeNumberField("id", flow.getId());
                        }
                        jsonGenerator.writeStringField("name", flow.getName());

                        jsonGenerator.writeArrayFieldStart("ruleSets");
                        flow.getRuleSets().forEach(ruleSet -> {
                            try {
                                jsonGenerator.writeObject(ruleSet);
                            } catch (IOException e) {
                                throw new ServerException(e);
                            }
                        });
                        jsonGenerator.writeEndArray();

                        jsonGenerator.writeNumberField("sequence", flow.getSequence());

                        jsonGenerator.writeStringField("sourceMacTag", flow.getSourceMacTag());
                        jsonGenerator.writeStringField("destinationMacTag", flow.getDestinationMacTag());

                        jsonGenerator.writeArrayFieldStart("vlans");
                        flow.getVlans().forEach(vlan -> {
                            try {
                                jsonGenerator.writeObject(vlan);
                            } catch (IOException e) {
                                throw new ServerException(e);
                            }
                        });
                        jsonGenerator.writeEndArray();

                        jsonGenerator.writeArrayFieldStart("egressPorts");
                        flow.getEgressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                            try {
                                jsonGenerator.writeObject(clusterNodeInterface);
                            } catch (IOException e) {
                                throw new ServerException(e);
                            }
                        });
                        jsonGenerator.writeEndArray();

                        jsonGenerator.writeArrayFieldStart("ingressPorts");
                        flow.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                            try {
                                jsonGenerator.writeObject(clusterNodeInterface);
                            } catch (IOException e) {
                                throw new ServerException(e);
                            }
                        });
                        jsonGenerator.writeEndArray();
                        jsonGenerator.writeBooleanField("tagged", flow.getIsTagged());
                        jsonGenerator.writeBooleanField("tvfDomain", flow.getTvfDomain());
                        jsonGenerator.writeBooleanField("vlanStripping", flow.getVlanStripping());
                        jsonGenerator.writeBooleanField("defaultRouteMapDrop", flow.getIsDefaultRouteMapDrop());
                        if (flow.getTaggedVlanId() == null) {
                            jsonGenerator.writeNullField("taggedVlanId");
                        } else {
                            jsonGenerator.writeNumberField("taggedVlanId", flow.getTaggedVlanId());
                        }
                        jsonGenerator.writeEndObject();
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }

}
