package com.brocade.bvm.model.db.statistics;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "pbr_statistics")
public class PBRStatistics {

    @Id
    private Long id = System.nanoTime();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "collector_device_id", referencedColumnName = "id")
    private CollectorDeviceMapping collectorDeviceMapping;

    public void setCollectorDeviceMapping(CollectorDeviceMapping collectorDeviceMapping) {
        this.collectorDeviceMapping = collectorDeviceMapping;
    }

    @Setter
    @Column(name = "interface_name")
    private String interfaceName;

    @Setter
    @Column(name = "last_updated_time", columnDefinition = "timestamp", length = 6)
    private Instant lastUpdatedTime;

    @Setter
    @Column(name = "received_time", columnDefinition = "DATETIME", length = 6)
    private Date receivedTime;

    @Setter
    @OneToMany(mappedBy = "pbrStatistics", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ACLStatistics> aclStatistics = new HashSet<>();


}
