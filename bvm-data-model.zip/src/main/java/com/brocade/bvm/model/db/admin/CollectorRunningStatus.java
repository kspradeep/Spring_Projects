package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Slf4j
@NoArgsConstructor
@Entity(name = "collector_running_status")
public class CollectorRunningStatus implements DomainObject {
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Getter
    @Setter
    @Column(name = "is_running")
    private boolean isCollectorRunning;

    @Getter
    @Setter
    @Column(name = "is_reconciliation_running")
    private boolean isReconciliationRunning;

    @Override
    public String getName() {
        return "";
    }
}