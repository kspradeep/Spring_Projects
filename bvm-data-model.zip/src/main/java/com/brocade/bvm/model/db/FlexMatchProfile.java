package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.FlexMatchProfileHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "flex_match_profile")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class FlexMatchProfile extends TemplatePolicy implements HasHistory {

    public static final Integer PROFILE_NAME_MAX_LENGTH = 63;

    public static final String SLX_9240 = "SLX9240";
    public static final String SLX_9140 = "SLX9140";
    public static final String SLX_9850 = "SLX9850";

    @Column(name = "is_default")
    @Setter
    private Boolean isDefault = false;

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "flexMatchProfile", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<FlexHeader> flexHeaders = new TreeSet<>();

    public ImmutableSortedSet<FlexHeader> getFlexHeaders() {
        return ImmutableSortedSet.copyOf(flexHeaders);
    }

    public void addFlexHeaders(SortedSet<FlexHeader> flexHeaders) {
        this.flexHeaders.addAll(flexHeaders);
        flexHeaders.forEach(header -> header.reverseMappingFlexMatch(this));
    }

    public void removeFlexHeaders(SortedSet<FlexHeader> flexHeaders) {
        this.flexHeaders.removeAll(flexHeaders);
    }

    public void setFlexHeaders(SortedSet<FlexHeader> flexHeaders) {
        this.flexHeaders.clear();
        addFlexHeaders(flexHeaders);
    }

    @Override
    public HistoryObject buildHistory() {
        FlexMatchProfileHistory flexMatchProfileHistory = new FlexMatchProfileHistory();
        BeanUtils.copyProperties(this, flexMatchProfileHistory);
        flexMatchProfileHistory.setName(this.getName());
        flexMatchProfileHistory.setWorkflowType(this.getWorkflowType());
        flexMatchProfileHistory.setDeviceModel(this.getDeviceModel());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(FlexMatchProfile.class, new FlexMatchProfile.FlexMatchProfileJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            flexMatchProfileHistory.setProfileJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the FlexMatchProfile Object in History", e);
        }
        return flexMatchProfileHistory;
    }

    private class FlexMatchProfileJsonSerializer extends JsonSerializer<FlexMatchProfile> {
        @Override
        public void serialize(FlexMatchProfile flexMatchProfile, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", flexMatchProfile.getId().longValue());
                jsonGenerator.writeStringField("name", flexMatchProfile.getName());
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeStringField("name", flexMatchProfile.getDeviceModel());
                jsonGenerator.writeEndObject();
                if (flexMatchProfile.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", flexMatchProfile.getWorkflowStatus().name());
                }
                if (flexMatchProfile.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", flexMatchProfile.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("flexHeaders");
                flexMatchProfile.getFlexHeaders().forEach(flexHeader -> {
                    try {
                        jsonGenerator.writeObject(flexHeader);
                    } catch (Exception e) {
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
