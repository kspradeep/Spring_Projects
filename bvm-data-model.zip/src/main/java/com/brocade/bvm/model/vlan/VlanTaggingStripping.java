package com.brocade.bvm.model.vlan;

import lombok.Getter;
import lombok.Setter;

/*
Represents VLAN Tagging and Stripping status of a flow
 */
@Setter
@Getter
public class VlanTaggingStripping {

    Integer sequence;

    boolean isVlanStripping;

    Boolean isVlanStrippingOld;

    Integer taggedVlanId;

    Integer taggedVlanIdDeleted;

    boolean isValnStrippingUpdated;

    boolean isVlanTaggedUpdated;
}
