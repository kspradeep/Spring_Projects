package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class SwitchOverview {
    private String os;
    private String ipAddress;
    private int ports;
    private int policies;
    private int downPorts;
    private int activePorts;
}
