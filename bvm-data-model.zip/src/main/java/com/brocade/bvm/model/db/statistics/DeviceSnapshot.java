package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class DeviceSnapshot {
    private Long id;

    private String name;

    private String os;

    private String type;

    private String ipAddress;

    private boolean isProfileConfigured;
}
