package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.Device;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "grid_cluster")
public class GridCluster implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    private String name;

    @JsonIgnore
    @Getter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_source_id", referencedColumnName = "id")
    private DeviceGrid deviceGridSource;

    void reverseMapGridFlowSource(DeviceGrid deviceGridSource) {
        this.deviceGridSource = deviceGridSource;
    }

    @JsonIgnore
    @Getter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_destination_id", referencedColumnName = "id")
    private DeviceGrid deviceGridDestination;

    void reverseMapGridFlowDestination(DeviceGrid deviceGridDestination) {
        this.deviceGridDestination = deviceGridDestination;
    }

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "gridCluster", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
    private Set<ClusterNodeInterface> clusterNodeInterfaces = new HashSet<>();

    @JsonProperty
    public void setClusterNodeInterfaces(Set<ClusterNodeInterface> clusterNodeInterfaces) {
        this.clusterNodeInterfaces.clear();
        addClusterNodeInterfaces(clusterNodeInterfaces);
    }

    public void addClusterNodeInterfaces(Set<ClusterNodeInterface> clusterNodeInterfaces) {
        this.clusterNodeInterfaces.addAll(clusterNodeInterfaces);
        clusterNodeInterfaces.forEach(clusterNodeInterface -> clusterNodeInterface.reverseMapNetworkNode(this));
    }

    public void removeClusterNodeInterfaces(Set<ClusterNodeInterface> clusterNodeInterfaces) {
        this.clusterNodeInterfaces.removeAll(clusterNodeInterfaces);
    }

    @JsonProperty
    public Set<ClusterNodeInterface> getClusterNodeInterfaces() {
        return clusterNodeInterfaces;
    }
}
