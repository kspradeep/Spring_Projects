package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PolicyStatistics {
  private String portNumber;
  private String acls;
  private String rule;
  private Long packetCount;
}
