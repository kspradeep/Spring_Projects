package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Data
public class GridStatisticsOverview {
  private List<String> topFiveGrids;
  private List<String> bottomFiveGrids;
  private Set<String> topFiveTapPorts;
  private Set<String> bottomFiveTapPorts;
  private Set<String> topFiveToolPorts;
  private Set<String> bottomFiveToolPorts;
  private List<String> toFivePolicies = new ArrayList<>();
  private List<String> bottomFivePolicies = new ArrayList<>();
}
