package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.Device;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.time.Instant;

@Setter
@Getter
@Entity(name = "sd_stats")
public class SdStats implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @Lob
    @Column(name = "stats_data")
    private String statsData;

    @Column(name = "report_time")
    private Instant reportTime;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }
}
