package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class ACLSummary {
    private Long id;
    private String name;
    private String port;
}
