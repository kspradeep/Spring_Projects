package com.brocade.bvm.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "session_timeout")
public class SessionTimeout {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String userName;

    @Column
    private Integer timeOut;

    @JsonIgnore
    public boolean isValid() {
        if(this.getTimeOut() >= 0 && this.getUserName() != "") {
            return true;
        }
        return false;
    }
}
