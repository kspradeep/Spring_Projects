package com.brocade.bvm.model.db.sessiondirector;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BulkFilterPolicyRequest {
    private Integer priority;
    private String dataHeader;
    private String data;
    private SdPortGroup portGroup;
    private Integer qci;
    private String apn;
    private String action;
    private String imei;
    private String sipCallingParty;
    private String sipCalledParty;
    private SamplingPolicy samplingPolicy;
    private SdPortGroup replicationPortGroup;
    private String rat;
}
