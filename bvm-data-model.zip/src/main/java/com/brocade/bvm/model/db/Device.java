package com.brocade.bvm.model.db;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;

@Getter
@NoArgsConstructor
@Entity(name = "device")
public class Device extends TargetHost {

    public static final String SLX_9850 = "SLX9850";

    public static final String UNKNOWN_MODEL = "UNKNOWN";

    /* IronWare Version V5.9.0 (V) (major version) (.) (minor version) */
    private static final String MLXE_OS_VALIDATION_REGEX = "(IronWare)(\\s+)(Version)(\\s+)(V)(\\d+)(\\.)(\\d+)";

    /* IronWare Version (major version) (.) (minor version) (.) (patch version) */
    private static final String ICX_OS_VALIDATION_REGEX = "(IronWare)(\\s+)(Version)(\\s+)(\\d+)(\\.)(\\d+)(\\.)(\\d+)";

    private static final float ICX_OS_VERSION = 8.061f;

    private static final float MLXE_OS_6_1_VERSION = 6.1f;

    public static final Integer STATUS_DOWN = 0;
    public static final Integer STATUS_UP = 1;
    public static final Integer STATUS_DISCONNECTED = 2;

    @JsonIgnore
    @Setter
    @Column(name = "stablenet_id")
    private Long stablenetId;

    @JsonIgnore
    @Setter
    @Column(name = "openflow_id")
    private String openflowId;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Type type;

    @Setter
    @Column
    private String model;

    @Setter
    @Column
    private String os;

    @Setter
    @Column
    @org.hibernate.annotations.Type(type = "text")
    private String description;

    @Setter
    @Column(name = "system_description")
    @org.hibernate.annotations.Type(type = "text")
    private String systemDescription;

    @Setter
    @Column(name = "last_collected_time")
    private Instant lastCollectedTime;

    @Setter
    @Column(name = "is_deleted")
    private boolean isDeleted;

    @Setter
    @Transient
    private Integer numberOfPorts;

    @Setter
    @Column(name = "active_since")
    private String sdActiveSince;

    @Setter
    @Column(name = "is_reconciled")
    private boolean isReconciled;

    @Setter
    @Column(name = "status")
    private Integer status;

    @Setter
    @Column(name = "is_profile_configured")
    private boolean isProfileConfigured;

    @Setter
    @Column(name = "is_authentication_configured")
    private boolean authenticationConfigured;

    @Setter
    @Column(name = "is_authorization_configured")
    private boolean authorizationConfigured;

    @Setter
    @Column
    private String chassis;

    @Override
    @JsonProperty
    public Instant getLastUpdatedTime() {
        return super.getLastUpdatedTime();
    }

    @OneToMany(mappedBy = "device", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Module> modules = new HashSet<>();

    public ImmutableSet<Module> getModules() {
        return ImmutableSet.copyOf(modules);
    }

    public void addModules(Set<Module> modules) {
        this.modules.addAll(modules);
        modules.forEach(module -> module.reverseMapDevice(this));
    }

    public void removeModules(Set<Module> modules) {
        this.modules.removeAll(modules);
    }

    public void setModules(Set<Module> modules) {
        this.modules.clear();
        addModules(modules);
    }

    @OneToMany(mappedBy = "device", fetch = FetchType.LAZY)
    private Set<PortGroup> portGroups = new HashSet<>();

    public ImmutableSet<PortGroup> getPortGroups() {
        return ImmutableSet.copyOf(portGroups);
    }

    void reverseMapPortGroup(PortGroup portGroup) {
        this.portGroups.add(portGroup);
    }

    public enum Type {
        MLXE, ICX, SD, SLX
    }


    @JsonIgnore
    public int getOsMajorVersion() {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(MLXE_OS_VALIDATION_REGEX, java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL);
        Matcher m = p.matcher(this.os);
        if (m.find()) {
            String majorVer = m.group(6);
            if (!majorVer.isEmpty()) {
                return Integer.parseInt(majorVer);
            }
        }
        return 0;
    }

    @JsonIgnore
    public boolean isOsVersionInvalid() {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(MLXE_OS_VALIDATION_REGEX, java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL);
        Matcher m = p.matcher(this.os);
        if (m.find()) {
            String majorVer = m.group(6);
            String minorVer = m.group(8);
            if (!majorVer.isEmpty() && !minorVer.isEmpty()) {
                Float osVersion = Float.parseFloat(majorVer + "." + minorVer);
                if (osVersion < MLXE_OS_6_1_VERSION) {
                    return true;
                }
            }
        }
        return false;
    }

    @JsonIgnore
    public boolean isICXOsVersion8061() {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ICX_OS_VALIDATION_REGEX, java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.DOTALL);
        Matcher m = p.matcher(this.os);
        if (m.find()) {
            String majorVer = m.group(5);
            String minorVer = m.group(7);
            String patchVer = m.group(9);
            if (!majorVer.isEmpty() && !minorVer.isEmpty() && !patchVer.isEmpty()) {
                Float osVersion = Float.parseFloat(majorVer + "." + minorVer + patchVer);
                if (osVersion >= ICX_OS_VERSION) {
                    return true;
                }
            }
        }
        return false;
    }
}
