package com.brocade.bvm.model.db.statistics;

import com.brocade.bvm.model.db.Device;
import lombok.Data;

@Data
public class SwitchUtilization {
  private long id;
  private Device device;
  private double utilization;

  @Override
  public int hashCode() {
    return Long.hashCode(id);
  }

  @Override
  public boolean equals(Object obj) {
      if (obj == null) return false;
      if (!(obj instanceof SwitchUtilization))
          return false;
      if (obj == this)
          return true;
    return this.getId() == ((SwitchUtilization) obj).getId();
  }
}
