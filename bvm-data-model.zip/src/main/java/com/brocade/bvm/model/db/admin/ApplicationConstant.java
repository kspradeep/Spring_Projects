package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.exception.ServerException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

@NoArgsConstructor
@Entity(name = "application_constant")
@Getter
public class ApplicationConstant implements DomainObject {

    public static final String GRID_FEATURE_STATUS_KEY = "GRID_FEATURE_STATUS";
    public static final String EVM_INIT_STATUS_KEY = "EVM_INIT_STATUS_KEY";
    public static final String TACACS_SERVER_IP = "TACACS_SERVER_IP";
    public static final String TACACS_SERVER_SHARED_KEY = "TACACS_SERVER_SHARED_KEY";
    public static final String TELEMETRY_COLLECTOR_CONFIG_OLD = "TELEMETRY_COLLECTOR_CONFIG_OLD";
    public static final String TACACS_AUTHENTICATION_PROTOCOL = "TACACS_AUTHENTICATION_PROTOCOL";
    public static final String TACACS_SERVER_TIMEOUT_SECONDS = "TACACS_SERVER_TIMEOUT_SECONDS";
    public static final String TACACS_SERVER_CONNECTION_RETRIES = "TACACS_SERVER_CONNECTION_RETRIES";
    public static final String TACACS_AUTHENTICATION_PORT = "TACACS_AUTHENTICATION_PORT";
    public static final String TACACS_SERVICE_ATTRIBUTE = "TACACS_SERVICE_ATTRIBUTE";
    public static final String TACACS_AUTO_CONFIGURATION_STATUS = "TACACS_AUTO_CONFIGURATION_STATUS";

    //default value of TACACS server key
    public static final String TACACS_SHARED_KEY_DEFAULT = "sharedsecret";

    public enum THRESHOLD {
        UTILIZATION_THRESHOLD("UTILIZATION_THRESHOLD"),
        INTERVAL("INTERVAL");

        private String constant;

        THRESHOLD(String constant) {
            this.constant = constant;
        }

        public String getConstant() {
            return this.constant;
        }
    }

    public enum TACACS_PROTOCOL {
        CHAP("chap"),
        PAP("pap");

        private String constant;

        TACACS_PROTOCOL(String constant) {
            this.constant = constant;
        }

        public String getConstant() {
            return this.constant;
        }
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Lob
    @Column(name = "value")
    private String value;

    public enum GRID_FEATURE_STATUS {
        UP,
        DOWN
    }

    private static java.security.Key PRIVATE_KEY;

    static {
        try {
            /*
            128bits (16bytes) key is used and not 256.
            See https://github.com/spring-projects/spring-security/issues/2917 and https://en.wikipedia.org/wiki/Restrictions_on_the_import_of_cryptography
            to understand why it's not easy to ship with a 256 bit key.
            Spring Encryptors has a much easier interface for AES encryption, but provides only a 256 bit key encryption.
             */
            byte[] keyBytes = Arrays.copyOf("v3@F_Fww6}_As~BV".getBytes("UTF-8"), 16);
            PRIVATE_KEY = new SecretKeySpec(keyBytes, "AES");
        } catch (UnsupportedEncodingException e) {
            throw new ServerException(e);
        }
    }

    /**
     * Keys which end with "password" are encrypted and stored
     *
     * @param value
     */
    public void setConstantValue(String value) {
        if (name != null && value != null && name.toLowerCase().endsWith("password")) {
            this.value = encryptPassword(value);
        } else {
            this.value = value;
        }
    }

    private String encryptPassword(String plainTextPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, PRIVATE_KEY);
            byte[] encrypted = cipher.doFinal(plainTextPassword.getBytes("UTF-8"));
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | UnsupportedEncodingException | IllegalBlockSizeException e) {
            throw new ServerException(e);
        }
    }

    /**
     * Returns a processed value. For eg. passwords are encrypted and stored in DB. This method returns a decrypted password.
     *
     * @return
     */
    public String getConstantValue() {
        if (name == null || value == null) {
            throw new ServerException("Invalid application configuration!");
        }
        if (name.toLowerCase().endsWith("password")) {
            return decryptPassword(value);
        } else {
            return this.value;
        }
    }

    private String decryptPassword(String encryptedPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, PRIVATE_KEY);
            byte[] decoded = Base64.getDecoder().decode(encryptedPassword);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted, "UTF-8");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | IOException e) {
            throw new ServerException(e);
        }
    }
}
