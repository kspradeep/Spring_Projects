package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.Flow;
import com.brocade.bvm.model.db.Rule;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "grid_ruleset")
public class GridRuleSet implements DomainObject, Comparable<GridRuleSet> {

    @Id
    @Getter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    @Getter
    private String name;

	@JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "policy_id", referencedColumnName = "id")
    private GridPolicy gridPolicy;

    void reverseMapGridPolicy(GridPolicy gridPolicy) {
        this.gridPolicy = gridPolicy;
    }

    @Setter
	@Column
	@Enumerated(EnumType.STRING)
	private Type type;

    @Setter
	@Column(name = "ip_version")
    @Enumerated(EnumType.STRING)
    private IpVersion ipVersion;

    @Setter
	@Column
	private Integer sequence = 0;

    @OrderBy("sequence ASC")
	@OneToMany(mappedBy = "gridRuleSet", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval=true)
	private SortedSet<GridRule> rules = new TreeSet<>();

    public ImmutableSortedSet<GridRule> getRules() {
        return ImmutableSortedSet.copyOf(rules);
    }

    public void addRules(SortedSet<GridRule> rules) {
        this.rules.addAll(rules);
        rules.forEach(rule -> rule.reverseMapGridRuleSet(this));
    }

    public void removeRules(SortedSet<GridRule> rules) {
        this.rules.removeAll(rules);
    }

    public void setRules(SortedSet<GridRule> rules) {
        this.rules.clear();
        addRules(rules);
    }

    public enum Type {
        L2, L3, L23, UDA
    }

	public enum IpVersion {
		V4("ip"), V6("ipv6");
        private String value;
        IpVersion(String value) {
            this.value = value;
        }
        public String getValue() {
            return value;
        }
	}

    @Override
    public int compareTo(GridRuleSet ruleSet) {
        //ascending order
        return this.sequence - ruleSet.getSequence();
    }

    public void clearId(){
        this.id = null;
    }
}
