package com.brocade.bvm.model.db;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.Setter;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Set;

@Getter
public class TelemetryStats {

    @Setter
    private String profileType;

    @Setter
    private String profileName;

    @Setter
    private String ipAddress;

    @Setter
    private Set counters = Sets.newHashSet();

    @Setter
    private DeviceInfo deviceInfo;

    @Setter
    private Instant timestamp;
}
