package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.GtpDeEncapsulationModulePolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@Getter
@NoArgsConstructor
@Entity(name = "gtp_de_encapsulation_Module_policy_history")
@Slf4j
public class GtpDeEncapsulationModulePolicyHistory extends HistoryObject<GtpDeEncapsulationModulePolicy> {
    @Setter
    @Lob
    @Column(name = "module_policy_json")
    private String modulePolicyJson;

    @Override
    public GtpDeEncapsulationModulePolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        GtpDeEncapsulationModulePolicy policy = null;
        try {
            policy = mapper.readValue(modulePolicyJson, GtpDeEncapsulationModulePolicy.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the GtpDeEncapsulationModulePolicyHistory", e);
        }
        return policy;
    }
}
