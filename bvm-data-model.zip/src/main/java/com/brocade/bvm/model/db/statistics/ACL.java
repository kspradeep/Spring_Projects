package com.brocade.bvm.model.db.statistics;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Getter
@Entity(name = "acl")
public class ACL {

    @Id
    private Long id = System.nanoTime();

    @Setter
    @Column(name = "seq_num")
    private Long seqNum = 0L;;

    @Setter
    @Column(name = "byte_count")
    private Long byteCount = 0L;;

    @Setter
    @Column(name = "hit_count")
    private Long hitCount = 0L;;

    @Setter
    @Column(name = "last_updated_time", columnDefinition = "timestamp", length = 6)
    private Instant lastUpdatedTime;

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "acl_statistics_id", referencedColumnName = "id")
    private ACLStatistics aclStatistics;


}
