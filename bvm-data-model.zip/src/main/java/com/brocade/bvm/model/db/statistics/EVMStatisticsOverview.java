package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.util.List;

@Data
public class EVMStatisticsOverview extends SwitchesStatisticsOverview{
    private List<String> topFiveGrids;
    private List<String> bottomFiveGrids;
}
