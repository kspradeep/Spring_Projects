package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class AllPoliciesAndHitCount {
  private String policyName = "";
  private Long hitCount = 0L;
}
