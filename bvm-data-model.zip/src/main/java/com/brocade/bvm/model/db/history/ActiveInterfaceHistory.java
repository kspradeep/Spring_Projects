
package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sd_active_interface_history")
public class ActiveInterfaceHistory extends HistoryObject {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "interface_json")
    private String interfaceJson;

    public ActiveInterface buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ActiveInterface activeInterface = null;
        try {
            activeInterface = mapper.readValue(interfaceJson, ActiveInterface.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the ActiveInterfaceHistory", e);
        }
        return activeInterface;
    }
}

