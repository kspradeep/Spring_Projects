package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortHistory;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.Instant;

@NoArgsConstructor
@Entity(name = "port")
@SecondaryTable(name = "port_bvm_defined", pkJoinColumns = @PrimaryKeyJoinColumn(name = "id"))
@JsonPropertyOrder({"id", "name", "workflowStatus", "workflowType", "portDescription", "portNumber", "openFlowPortNumber"})
public class Port extends ManagedObject implements Comparable<Port>, HasHistory {

    public static final String OPENFLOW_PORTNUMBER_FORMAT = "eth%s";
    public static final String OPENFLOW_PORTNUMBER_FORMAT_ICX = "ethernet%s";

    public static final Long SPEED_0 = 0L;
    public static final Long SPEED_25G = 25000L;
    public static final Long SPEED_10G = 10000L;
    public static final Long SPEED_40G = 40000L;
    public static final Long SPEED_100G = 100000L;

    @JsonIgnore
    @Getter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "module_id", referencedColumnName = "id")
    private Module module;

    void reverseMapModule(Module module) {
        this.module = module;
    }

    @JsonIgnore
    @Getter
    @Setter
    @Column(name = "stablenet_id")
    private Long stablenetId;

    @JsonIgnore
    @Getter
    @Setter
    @Column(name = "stablenet_index")
    private Long stablenetIndex;

    @JsonIgnore
    @Getter
    @Setter
    @Column(name = "openflow_id")
    private String openflowId;

    @Getter
    @Setter
    @Column(name = "physical_address")
    private String physicalAddress;

    @Getter
    @Setter
    @Column(name = "link_status")
    @Enumerated(EnumType.STRING)
    private LinkStatus linkStatus;

    @JsonIgnore
    @Getter
    @Setter
    @Column(name = "admin_status")
    @Enumerated(EnumType.STRING)
    private AdminStatus discoveredAdminStatus;

    @JsonIgnore
    @Getter
    @Setter
    @Column
    @org.hibernate.annotations.Type(type = "text")
    private String description;

    @Getter
    @Setter
    @Column
    private Integer ppcr;

    @JsonIgnore
    @Setter
    @Getter
    @Column(table = "port_bvm_defined", name = "description")
    private String customDescription;

    @JsonProperty
    public String getPortDescription() {
        String actualCustomDescription;
        if (this.customDescription != null && getBvmDefinedLastUpdatedTime() != null && getBvmDefinedLastUpdatedTime().isAfter(module.getDevice().getLastUpdatedTime())) {
            if (getWorkflowType() == Job.Type.PORT_DESCRIPTION && getWorkflowStatus() == WorkflowStatus.ERROR) {
                actualCustomDescription = this.description;
            } else {
                actualCustomDescription = this.customDescription;
            }
        } else if (this.customDescription != null && getBvmDefinedLastUpdatedTime() != null && getBvmDefinedLastUpdatedTime().isBefore(module.getDevice().getLastUpdatedTime())) {
            if (getWorkflowType() == Job.Type.PORT_DESCRIPTION && getWorkflowStatus() == WorkflowStatus.ERROR) {
                actualCustomDescription = this.description;
            } else {
                actualCustomDescription = this.customDescription;
            }
        } else if (this.customDescription == null && getBvmDefinedLastUpdatedTime() != null && module.getDevice().getLastUpdatedTime() != null && getBvmDefinedLastUpdatedTime().isAfter(module.getDevice().getLastUpdatedTime())) {
            if (getWorkflowType() == Job.Type.PORT_DESCRIPTION && getWorkflowStatus() == WorkflowStatus.ERROR) {
                actualCustomDescription = this.description;
            } else {
                actualCustomDescription = this.customDescription;
            }
        } else {
            actualCustomDescription = this.description;
        }
        return actualCustomDescription;
    }

    @Getter
    @Setter
    @Column(table = "port_bvm_defined", name = "type")
    @Enumerated(EnumType.STRING)
    private Type type;

    @Getter
    @Setter
    @Column(table = "port_bvm_defined", name = "mode")
    @Enumerated(EnumType.STRING)
    private Mode mode;

    @Getter
    @Setter
    @Column(name = "line_speed")
    private Long lineSpeed;

    @Getter
    @Setter
    @Column(name = "max_speed")
    private Long maxSpeed;

    @JsonIgnore
    @Setter
    @Column(table = "port_bvm_defined", name = "admin_status")
    @Enumerated(EnumType.STRING)
    private AdminStatus adminStatus;

    @JsonProperty
    public AdminStatus getAdminStatus() {
        AdminStatus actualAdminStatus;
        if (this.adminStatus != null
                && getBvmDefinedLastUpdatedTime() != null && getBvmDefinedLastUpdatedTime().isAfter(module.getDevice().getLastCollectedTime())) {
            if ((getWorkflowType() == Job.Type.PORT_ENABLE || getWorkflowType() == Job.Type.PORT_DISABLE) && getWorkflowStatus() == WorkflowStatus.ERROR) {
                actualAdminStatus = this.discoveredAdminStatus;
            } else {
                actualAdminStatus = this.adminStatus;
            }

        } else {
            actualAdminStatus = this.discoveredAdminStatus;
        }

        return actualAdminStatus;
    }

    @Getter
    @Setter
    @Column(name = "is_loop_back_enabled")
    public Boolean loopbackEnabled = false;

    public Boolean isLoopbackEnabled() {
        return loopbackEnabled;
    }

    @JsonIgnore
    @Getter
    @Setter
    @Column(table = "port_bvm_defined", name = "last_updated_time")
    private Instant bvmDefinedLastUpdatedTime = Instant.now();

    //Commented to fix the PortGroup to Port mapping issue
    /*@JsonIgnore
    @Getter
    @ManyToOne(fetch = FetchType.EAGER)
	@JoinTable(name = "port_portgroup_mapping", joinColumns = {
			@JoinColumn(name = "port_id") },
			inverseJoinColumns = { @JoinColumn(name = "port_group_id") })
    private PortGroup portGroup;

    void reverseMapPortGroup(PortGroup portGroup) {
        this.portGroup = portGroup;
    }*/

    //temporary field for egress set next hop precedence.
    @Getter
    @Setter
    @Transient
    private Integer precedence = 0;

    public enum Type {
        INGRESS, EGRESS, SERVICE_PORT, NONE
    }

    public enum Mode {
        LAYER2, LAYER3, LAYER23
    }

    public enum LinkStatus {
        UP, DOWN
    }

    public enum AdminStatus {
        ENABLED, DISABLED
    }

    @JsonProperty
    public String getPortNumber() {
        return getName() != null && getName().toLowerCase().contains("ethernet")
                ? getName().substring(getName().toLowerCase().indexOf("ethernet") + "ethernet".length())
                : "";
    }

    @JsonProperty
    public String getOpenFlowPortNumber() {
        String portNo = getPortNumber();
        return String.format((this.module.getDevice().getType() == Device.Type.ICX) && (this.module.getDevice().isICXOsVersion8061()) ? OPENFLOW_PORTNUMBER_FORMAT_ICX : OPENFLOW_PORTNUMBER_FORMAT, portNo);
    }

    @Override
    public int compareTo(@NotNull Port other) {
        return compare(this.getName(), other.getName());
    }

    private final boolean isDigit(char ch) {
        return ((ch >= 48) && (ch <= 57));
    }

    /**
     * Length of string is passed in for improved efficiency (only need to calculate it once)
     **/
    private final String getChunk(String s, int slength, int marker) {
        StringBuilder chunk = new StringBuilder();
        char c = s.charAt(marker);
        chunk.append(c);
        marker++;
        if (isDigit(c)) {
            while (marker < slength) {
                c = s.charAt(marker);
                if (!isDigit(c))
                    break;
                chunk.append(c);
                marker++;
            }
        } else {
            while (marker < slength) {
                c = s.charAt(marker);
                if (isDigit(c))
                    break;
                chunk.append(c);
                marker++;
            }
        }
        return chunk.toString();
    }

    public int compare(String s1, String s2) {
        if ((s1 == null) || (s2 == null)) {
            return 0;
        }

        int thisMarker = 0;
        int thatMarker = 0;
        int s1Length = s1.length();
        int s2Length = s2.length();

        while (thisMarker < s1Length && thatMarker < s2Length) {
            String thisChunk = getChunk(s1, s1Length, thisMarker);
            thisMarker += thisChunk.length();

            String thatChunk = getChunk(s2, s2Length, thatMarker);
            thatMarker += thatChunk.length();

            // If both chunks contain numeric characters, sort them numerically
            int result = 0;
            if (isDigit(thisChunk.charAt(0)) && isDigit(thatChunk.charAt(0))) {
                // Simple chunk comparison by length.
                int thisChunkLength = thisChunk.length();
                result = thisChunkLength - thatChunk.length();
                // If equal, the first different number counts
                if (result == 0) {
                    for (int i = 0; i < thisChunkLength; i++) {
                        result = thisChunk.charAt(i) - thatChunk.charAt(i);
                        if (result != 0) {
                            return result;
                        }
                    }
                }
            } else {
                result = thisChunk.compareTo(thatChunk);
            }

            if (result != 0)
                return result;
        }
        return s1Length - s2Length;
    }

    @Override
    public HistoryObject buildHistory() {
        PortHistory portHistory = new PortHistory();
        portHistory.setMode(this.getMode());
        portHistory.setName(this.getName());
        portHistory.setWorkflowStatus(this.getWorkflowStatus());
        portHistory.setWorkflowType(this.getWorkflowType());
        portHistory.setLoopBackEnabled(this.loopbackEnabled);
        portHistory.setLineSpeed(this.getLineSpeed());
        portHistory.setMaxSpeed(this.getMaxSpeed());
        return portHistory;
    }
}
