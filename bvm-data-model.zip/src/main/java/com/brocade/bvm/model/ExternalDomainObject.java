package com.brocade.bvm.model;

/**
 * Represents an entity managed externally, eg. by Stablenet, OpenStack, etc.
 */
public interface ExternalDomainObject extends DomainObject {
    String getExternalId();
}
