package com.brocade.bvm.model.firmware;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FirmwareHistoryObject {

    private String deviceName;

    private String dateAndTime;

    private String slotNumber;

    private String pId;

    private String osVersion;

}
