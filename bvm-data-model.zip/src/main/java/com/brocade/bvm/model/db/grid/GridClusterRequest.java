package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.db.Device;
import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class GridClusterRequest {

    private Long id;

    private String name;

    private DeviceGrid deviceGridSource;

    private DeviceGrid deviceGridDestination;

    private Device device;

    private Set<ClusterNodeInterfaceRequest> clusterNodeInterfaces = new HashSet<>();

    public void addClusterNodeInterface(ClusterNodeInterface clusterNodeInterface) {
        ClusterNodeInterfaceRequest clusterNodeInterfaceRequest = new ClusterNodeInterfaceRequest();
        clusterNodeInterfaceRequest.setId(clusterNodeInterface.getId());
        clusterNodeInterfaceRequest.setName(clusterNodeInterface.getName());
        clusterNodeInterfaceRequest.setPorts(clusterNodeInterface.getPorts());
        clusterNodeInterfaceRequest.setPortGroups(clusterNodeInterface.getPortGroups());
        this.clusterNodeInterfaces.add(clusterNodeInterfaceRequest);
    }

    public void removeClusterNodeInterface(ClusterNodeInterfaceRequest clusterNodeInterface) {
        this.clusterNodeInterfaces.remove(clusterNodeInterface);
    }
}