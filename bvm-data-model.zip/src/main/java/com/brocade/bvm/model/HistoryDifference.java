package com.brocade.bvm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Set;

@Getter
@AllArgsConstructor
public class HistoryDifference<T extends DomainObject> {
    private Set<T> newDiscoveredEntities;
    private Set<UpdatedEntityHolder<T>> updatedDbEntities;
    private Set<T> deletedDbEntities;

    @Getter
    @AllArgsConstructor
    public static class UpdatedEntityHolder<T> {
        private T oldDbEntity;
        private T newDiscoveredEntity;
    }
}
