package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.LoadBalanceModulePolicy;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "load_balance_module_policy_history")
@Slf4j
public class LoadBalanceModulePolicyHistory extends HistoryObject<LoadBalanceModulePolicy> {

    @Setter
    @Lob
    @Column(name = "module_policy_json")
    private String modulePolicyJson;

    @Override
    public LoadBalanceModulePolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        LoadBalanceModulePolicy policy = null;
        try {
            policy =mapper.readValue(modulePolicyJson, LoadBalanceModulePolicy.class);

        } catch (Exception e) {
            throw new ServerException("Failed to construct the LoadBalanceModulePolicyHistory",e);
        }
        return policy;
    }
}
