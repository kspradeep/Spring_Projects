package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.SamplingPolicyHistory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;
import org.springframework.beans.BeanUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.IOException;

@Getter
@Setter
@Slf4j
@Entity(name = "sampling_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
public class SamplingPolicy extends SdPolicy implements HasHistory {

    public final static String RESERVE_NAME_SAMPLE = "sample";
    public static final Integer SAMPLE_POLICY_NAME_MAX = 16;
    public static final Integer MIN_SAMPLE_RATE = 1;
    public static final Integer MAX_SAMPLE_RATE = 100;
    public static final Integer MAX_SAMPLE_POLICY = 10;

    @Column(name = "is_preserve_cplane")
    private boolean preserveCplane;

    @Column
    private String action;

    @Column
    private Integer rate;

    @Column(name = "load_balance_algo")
    @Enumerated(EnumType.STRING)
    private SamplingPolicy.LoadBalanceAlgorithms loadBalanceAlgo;

    public enum LoadBalanceAlgorithms {
        HASH("hash"),
        ROUND_ROBIN("round-robin");

        private String loadBalanceAlgorithms;

        LoadBalanceAlgorithms(String loadBalanceAlgorithms) {
            this.loadBalanceAlgorithms = loadBalanceAlgorithms;
        }

        public String getName() {
            return this.loadBalanceAlgorithms;
        }
    }

    @Override
    public HistoryObject buildHistory() {
        SamplingPolicyHistory samplingPolicyHistory = new SamplingPolicyHistory();
        BeanUtils.copyProperties(this, samplingPolicyHistory);
        samplingPolicyHistory.setDevice(this.getDevice());
        samplingPolicyHistory.setName(this.getName());
        samplingPolicyHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(SamplingPolicy.class, new SamplingPolicy.PolicyJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            samplingPolicyHistory.setPolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the SamplingPolicy Object in History", e);
        }
        return samplingPolicyHistory;
    }

    private class PolicyJsonSerializer extends JsonSerializer<SamplingPolicy> {
        @Override
        public void serialize(SamplingPolicy samplingPolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", samplingPolicy.getId().longValue());
                jsonGenerator.writeStringField("name", samplingPolicy.getName());
                jsonGenerator.writeBooleanField("preserveCplane", samplingPolicy.isPreserveCplane());
                jsonGenerator.writeStringField("action", samplingPolicy.getAction());
                jsonGenerator.writeObjectField("loadBalanceAlgo", samplingPolicy.getLoadBalanceAlgo());
                jsonGenerator.writeNumberField("rate", samplingPolicy.getRate());
                jsonGenerator.writeStringField("workflowStatus", samplingPolicy.getWorkflowStatus().name());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
