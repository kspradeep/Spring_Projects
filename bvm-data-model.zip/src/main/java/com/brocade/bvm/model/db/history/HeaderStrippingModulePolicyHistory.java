package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@Getter
@NoArgsConstructor
@Entity(name = "header_stripping_module_policy_history")
@Slf4j
public class HeaderStrippingModulePolicyHistory extends HistoryObject<HeaderStrippingModulePolicy> {

    @Setter
    @Lob
    @Column(name = "module_policy_json")
    private String modulePolicyJson;

    @Override
    public HeaderStrippingModulePolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        HeaderStrippingModulePolicy policy = null;
        try {
            policy =mapper.readValue(modulePolicyJson, HeaderStrippingModulePolicy.class);

        } catch (Exception e) {
            throw new ServerException("Failed to construct the HeaderStrippingModulePolicyHistory",e);
        }
        return policy;
    }
}
