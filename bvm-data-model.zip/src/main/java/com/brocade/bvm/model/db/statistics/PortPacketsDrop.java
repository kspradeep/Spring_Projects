package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortPacketsDrop {
    private long inDropPackets;
    private long outDropPackets;
    private String lastUpdatedTime = "0";
}
