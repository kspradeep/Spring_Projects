package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "grid_topology_path")
public class GridTopologyPath implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "policy_set_id")
    private Long policySetId;

    @Setter
    @Column(name = "path_id")
    private Long pathId;

    @Setter
    @Column(name = "tool_address")
    private Integer toolAddress;

    @Setter
    @Column(name = "bandwidth")
    private Long bandwidth;

    @Setter
    @Lob
    @Column(name = "path_json")
    private String pathJson;

    @Setter
    @Column(name = "is_active")
    private Boolean isActive = true;

    @Setter
    @Column(name = "is_cspf_enabled")
    private Boolean isCspfEnabled;

    @JsonIgnore
    @Getter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_matrix_id", referencedColumnName = "id")
    private GridMatrix gridMatrix;

    void reverseMapGridMatrix(GridMatrix gridMatrix) {
        this.gridMatrix = gridMatrix;
    }

    @Setter
    @OneToOne(mappedBy = "gridTopologyPathSource", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private NetworkNode sourceNetworkNode;

    public void setSourceNetworkNode(NetworkNode sourceNetworkNode) {
        this.sourceNetworkNode = sourceNetworkNode;
        sourceNetworkNode.reverseMapGridTopologySource(this);
    }

    @Setter
    @OneToOne(mappedBy = "gridTopologyPathDestination", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private NetworkNode destinationNetworkNode;

    public void setDestinationNetworkNode(NetworkNode destinationNetworkNode) {
        this.destinationNetworkNode = destinationNetworkNode;
        destinationNetworkNode.reverseMapGridTopologyPathDestination(this);
    }

    @Setter
    @Column(name = "tool_node_interface_id")
    private Long toolNodeInterfaceId;

    @Setter
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "tap_node_interface_mapping", joinColumns = @JoinColumn(name = "topology_path_id"))
    @Column(name = "tap_node_interface_id")
    private Set<Long> tapNodeInterfaceIds = new HashSet<>();

    public void addTapNodeInterfaceId(Long gridTopologyPathId) {
        this.tapNodeInterfaceIds.add(gridTopologyPathId);
    }

    public void removeTapNodeInterfaceId(Long gridTopologyPathId) {
        this.tapNodeInterfaceIds.remove(gridTopologyPathId);
    }

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "gridTopologyPath", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<IntermediateNode> intermediateNodes = new TreeSet<>();

    public ImmutableSortedSet<IntermediateNode> getIntermediateNodes() {
        return ImmutableSortedSet.copyOf(intermediateNodes);
    }

    public void addIntermediateNodes(SortedSet<IntermediateNode> intermediateNodes) {
        this.intermediateNodes.addAll(intermediateNodes);
        intermediateNodes.forEach(gridPolicy -> gridPolicy.reverseMapGridTopologyPath(this));
    }

    public void removeIntermediateNodes(SortedSet<IntermediateNode> intermediateNodes) {
        this.intermediateNodes.removeAll(intermediateNodes);
    }

    public void setIntermediateNodes(SortedSet<IntermediateNode> intermediateNodes) {
        this.intermediateNodes.clear();
        addIntermediateNodes(intermediateNodes);
    }
}
