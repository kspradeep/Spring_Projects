package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.ManagedObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Entity(name = "profile_interface_mapping")
public class ProfileInterfaceMapping extends ManagedObject {

    @JsonIgnore
    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "profile_id", referencedColumnName = "id")
    private Profile profile;

    void reverseMapProfile(Profile profile) {
        this.profile = profile;
    }
}
