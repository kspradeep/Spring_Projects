package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.grid.GridMatrix;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@Getter
@NoArgsConstructor
@Entity(name = "grid_matrix_history")
public class GridMatrixHistory extends HistoryObject<GridMatrix> {

    @Setter
    @Column(name = "grid_policy_set_id")
    private Long gridPolicySetId;

    @Setter
    @Column(name = "policy_id")
    private Long policyId;

    @Setter
    @Lob
    @Column(name = "grid_matrix_json")
    private String gridMatrixJson;

    @Override
    public GridMatrix buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        GridMatrix gridMatrix;
        try {
            gridMatrix = mapper.readValue(gridMatrixJson, GridMatrix.class);
            gridMatrix.setGridPolicySetId(gridPolicySetId);
            gridMatrix.setPolicyId(policyId);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the GridMatrixHistory", e);
        }
        return gridMatrix;
    }
}