package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortPacketType {
    private long inUniCastPackets;
    private long outUniCastPackets;
    private long inMultiCastPackets;
    private long outMultiCastPackets;
    private long inBroadcastPackets;
    private long OutBroadcastPackets;
    private String lastUpdatedTime = "0";
}
