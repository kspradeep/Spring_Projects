package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sd_egress_port_history")
public class EgressPortHistory extends HistoryObject<EgressPort> {

    @Setter
    @Lob
    @Column(name = "port_json")
    private String portJson;

    @Override
    public EgressPort buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        EgressPort egressPort = null;
        try {
            egressPort = mapper.readValue(portJson, EgressPort.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the egressPort history", e);
        }
        return egressPort;
    }
}

