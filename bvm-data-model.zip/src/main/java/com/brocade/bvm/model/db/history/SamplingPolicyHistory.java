package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "sampling_policy_history")
@Slf4j
public class SamplingPolicyHistory extends HistoryObject {
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "policy_json")
    private String policyJson;

    public SamplingPolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        SamplingPolicy samplingPolicy = null;
        try {
            samplingPolicy = mapper.readValue(policyJson, SamplingPolicy.class);
            samplingPolicy.setDevice(device);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the SamplingPolicyHistory", e);
        }
        return samplingPolicy;
    }
}
