package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "grid_policy")
public class GridPolicy implements DomainObject, Comparable<GridPolicy> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_policyset_id", referencedColumnName = "id")
    private GridPolicySet gridPolicySet;

    void reverseMapGridPolicySet(GridPolicySet gridPolicySet) {
        this.gridPolicySet = gridPolicySet;
    }

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "gridPolicy", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<GridRuleSet> ruleSets = new TreeSet<>();

    public ImmutableSortedSet<GridRuleSet> getRuleSets() {
        return ImmutableSortedSet.copyOf(ruleSets);
    }

    public void addRuleSets(SortedSet<GridRuleSet> ruleSets) {
        this.ruleSets.addAll(ruleSets);
        ruleSets.forEach(ruleSet -> ruleSet.reverseMapGridPolicy(this));
    }

    public void removeRuleSets(SortedSet<GridRuleSet> ruleSets) {
        this.ruleSets.removeAll(ruleSets);
    }

    public void setRuleSets(SortedSet<GridRuleSet> ruleSets) {
        this.ruleSets.clear();
        addRuleSets(ruleSets);
    }

    @Setter
    @Column
    private Integer sequence;

    @Setter
    @Column
    private String sourceMacTag;

    @Setter
    @Column
    private String destinationMacTag;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "grid_policy_vlan_mapping", joinColumns = @JoinColumn(name = "policy_id"))
    @Column(name = "vlan_id")
    private Set<String> vlans = new HashSet<>(); //some devices accept regex strings like "any" for vlan

    public ImmutableSet<String> getVlans() {
        return ImmutableSet.copyOf(vlans);
    }

    public void addVlan(Set<String> vlans) {
        this.vlans.addAll(vlans);
    }

    public void removeVlan(Set<String> vlans) {
        this.vlans.removeAll(vlans);
    }

    public void setVlans(Set<String> vlans) {
        this.vlans.clear();
        addVlan(vlans);
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "grid_policy_cluster_node_mapping_ingress",
            joinColumns = {@JoinColumn(name = "policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "cluster_node_id", referencedColumnName = "id")})
    private Set<ClusterNodeInterface> ingressClusterNodeInterfaces = new HashSet<>();

    public void removeIngressClusterNodeInterfaces(Set<ClusterNodeInterface> ingressClusterNodeInterfaces) {
        this.ingressClusterNodeInterfaces.removeAll(ingressClusterNodeInterfaces);
    }

    public void addIngressClusterNodeInterfaces(Set<ClusterNodeInterface> ingressClusterNodeInterfaces) {
        this.ingressClusterNodeInterfaces.addAll(ingressClusterNodeInterfaces);
    }

    @JsonProperty(value = "ingressPorts")
    public void setIngressClusterNodeInterfaces(Set<ClusterNodeInterface> ingressClusterNodeInterfaces) {
        this.ingressClusterNodeInterfaces.clear();
        this.ingressClusterNodeInterfaces.addAll(ingressClusterNodeInterfaces);
    }

    @JsonProperty(value = "ingressPorts")
    public ImmutableSet<ClusterNodeInterface> getIngressClusterNodeInterfaces() {
        return ImmutableSet.copyOf(ingressClusterNodeInterfaces);
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "grid_policy_cluster_node_mapping_egress",
            joinColumns = {@JoinColumn(name = "policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "cluster_node_id", referencedColumnName = "id")})
    private Set<ClusterNodeInterface> egressClusterNodeInterfaces = new HashSet<>();

    public void removeEgressClusterNodeInterfaces(Set<ClusterNodeInterface> egressClusterNodeInterfaces) {
        this.egressClusterNodeInterfaces.removeAll(egressClusterNodeInterfaces);
    }

    public void addEgressClusterNodeInterfaces(Set<ClusterNodeInterface> egressClusterNodeInterfaces) {
        this.egressClusterNodeInterfaces.addAll(egressClusterNodeInterfaces);
    }

    @JsonProperty(value = "egressPorts")
    public void setEgressClusterNodeInterfaces(Set<ClusterNodeInterface> egressClusterNodeInterfaces) {
        this.egressClusterNodeInterfaces.clear();
        this.egressClusterNodeInterfaces.addAll(egressClusterNodeInterfaces);
    }

    @JsonProperty(value = "egressPorts")
    public ImmutableSet<ClusterNodeInterface> getEgressClusterNodeInterfaces() {
        return ImmutableSet.copyOf(egressClusterNodeInterfaces);
    }

    @Setter
    @JsonProperty(value = "tagged")
    @Column(name = "is_tagged")
    private Boolean isTagged;

    @Setter
    @JsonProperty(value = "tvfDomain")
    @Column(name = "tvf_domain")
    private Boolean tvfDomain = false;

    @Setter
    @JsonProperty(value = "vlanStripping")
    @Column(name = "vlan_stripping")
    private Boolean vlanStripping = false;

    @Setter
    @Column(name = "tagged_vlan_id")
    private Integer taggedVlanId;

    @Setter
    @JsonProperty(value = "defaultRouteMapDrop")
    @Column(name = "is_default_route_map_drop")
    private Boolean isDefaultRouteMapDrop;

    @Override
    public int compareTo(GridPolicy gridPolicy) {
        //ascending order
        return this.sequence - gridPolicy.getSequence();
    }

    public void clearId() {
        this.id = null;
    }
}
