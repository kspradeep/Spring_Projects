package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.HistoryEntityUpdater;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

/**
 * Represents an external object that is managed by BVM
 */
@Getter
@Entity(name = "managed_object")
// InheritanceType.JOINED is used in case Table per sub-class hierarchy. This strategy enables helps in removing the redundant data being stored in multiple tables.
// And when constructing a Sub-class object the data is collected from multiple tables to construct a concerete object of a sub-class based on the discriminator column.
//Determination of the type of object is identified based on the Discriminator column which is by default the entity name of the JPA Class.
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "object_type")
@EntityListeners({HistoryEntityUpdater.class, CustomAuditingEntityListener.class})
//Added tbe below annotation for fixing the Hibernate Lazy initialization Exception which occurs when serializing the JPA Entity to JSON incase of lazy property defined.
// The below annotation acts as a handler which supress Lazy initialization Exception and also enables the jackson serialize to get triggered only after loading the JPA Entity.
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@NamedQuery(name="ManagedObject.findByIds",
        query="SELECT m FROM managed_object m WHERE m.id IN (:ids)")
public abstract class ManagedObject implements DomainObject, WorkflowParticipant {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

    @JsonIgnore
    @Column(name = "object_type", insertable = false, updatable = false)
    private String objectType;

    @Setter
	@Column
	private String name;

    @Setter
    @Column(name = "workflow_status")
    @Enumerated(EnumType.STRING)
    private WorkflowStatus workflowStatus;

    @Setter
    @Column(name = "workflow_type")
    @Enumerated(EnumType.STRING)
    private Job.Type workflowType;

    @JsonIgnore
    @Setter(AccessLevel.PACKAGE)
    @Column(name = "last_updated_time")
    private Instant lastUpdatedTime;

    public void clearId(){
        this.id = null;
    }
}
