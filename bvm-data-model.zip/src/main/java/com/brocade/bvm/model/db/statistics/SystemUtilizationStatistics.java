package com.brocade.bvm.model.db.statistics;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;
import java.util.Date;

@Data
@Entity(name = "system_utilization_statistics")
public class SystemUtilizationStatistics {

    @Id
    private Long id = System.nanoTime();

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "collector_device_id", referencedColumnName = "id")
    private CollectorDeviceMapping collectorDeviceMapping;

    @JsonDeserialize
    public void setCollectorDeviceMapping(CollectorDeviceMapping collectorDeviceMapping) {
        this.collectorDeviceMapping = collectorDeviceMapping;
    }

    @Setter
    @Column(name = "last_updated_time", columnDefinition = "timestamp", length = 6)
    private Instant lastUpdatedTime;

    @Setter
    @Column(name = "total_system_memory")
    private Long totalSystemMemory = 0L;

    @Setter
    @Column(name = "total_used_memory")
    private Long totalUsedMemory = 0L;

    @Setter
    @Column(name = "total_free_memory")
    private Long totalFreeMemory = 0L;

    @Setter
    @Column(name = "cached_memory")
    private Long cachedMemory = 0L;

    @Setter
    @Column(name = "buffers")
    private Long buffers = 0L;

    @Setter
    @Column(name = "user_free_memory")
    private Long userFreeMemory = 0L;

    @Setter
    @Column(name = "kernel_free_memory")
    private Long kernelFreeMemory = 0L;

    @Setter
    @Column(name = "user_process")
    private Long userProcess = 0L;

    @Setter
    @Column(name = "system_process")
    private Long systemProcess = 0L;

    @Setter
    @Column(name = "idle_state")
    private Long idleState = 0L;

    @Setter
    @Column(name = "uptime")
    private Long uptime = 0L;

    @Setter
    @Column(name = "received_time", columnDefinition = "DATETIME", length = 6)
    private Date receivedTime;
}
