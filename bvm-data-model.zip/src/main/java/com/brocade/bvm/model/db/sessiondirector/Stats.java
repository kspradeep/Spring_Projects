package com.brocade.bvm.model.db.sessiondirector;


public class Stats {
    public enum Request {
        PKT_STATS_ALL("packet-stats@all"),
        PKT_STATS_LTE_SIP("packet-stats@lte-sip"),
        PKT_STATS_LTE_RTP("packet-stats@lte-rtp"),
        PKT_STATS_LTE_S5U("packet-stats@lte-s5u"),
        PKT_STATS_RX("packet-stats@rx"),
        PKT_STATS_TX("packet-stats@tx"),
        PKT_STATS_LTE_GTPU("packet-stats@lte-gtpu"),
        PKT_STATS_LTE_GTPC("packet-stats@lte-gtpc"),
        PKT_STATS_3G_GTPC("packet-stats@3g-gtpc"),

        MEM_STATS_LTE_GTPC("memory-stats@lte-gtpc"),
        MEM_STATS_LTE_SIP("memory-stats@lte-sip"),
        MEM_STATS_SGI("memory-stats@sgi"),
        MEM_STATS_3G("memory-stats@3g"),

        TRAFFIC_STATS_LTE_GTPC("traffic-stats@lte-gtpc"),
        TRAFFIC_STATS_3G("traffic-stats@3g"),
        TRAFFIC_STATS_SGI("traffic-stats@sgi"),
        TRAFFIC_STATS_SIP("traffic-stats@lte-sip"),

        RULES_STATS_LTE_SIP("rules-stats@lte-sip"),
        RULES_STATS_LTE_GTPC("rules-stats@lte-gtpc"),
        RULES_STATS_3G("rules-stats@3g"),

        ANOMALY_STATS_LTE_GTPC("anomaly-stats@lte-gtpc"),
        ANOMALY_STATS_LTE_SIP("anomaly-stats@lte-sip"),
        ANOMALY_STATS_SGI("anomaly-stats@sgi"),
        ANOMALY_STATS_3G("anomaly-stats@3g"),

        MGMT_RULE_STATS_LTE_GTPC("mgmt-rule-stats@lte-gtpc"),
        MGMT_RULE_STATS_3G("mgmt-rule-stats@3g"),

        USER_COUNT_STATS("user-count"),

        RULE_COUNT_STATS("rule-count"),

        SAMPLING_STATS_VOLTE("sampling-stats@volte"),
        SAMPLING_STATS_S11_S1U_GNGP("sampling-stats@s11-s1u-gngp"),
        SAMPLING_STATS_S11_S5S8U_SGI("sampling-stats@s11-s5s8u-sgi"),

        CLEAR_STATS("clear-all");

        private String request;

        Request(String request) {
            this.request = request;
        }

        public String getValue() {
            return this.request;
        }
    }

    public enum Response {
        PKT_STATS_ALL("Packet-Stats"),
        PKT_STATS_LTE_SIP("Packet-Stats"),
        PKT_STATS_LTE_RTP("Packet-Stats"),
        PKT_STATS_LTE_S5U("Packet-Stats"),
        PKT_STATS_RX("Packet-Stats"),
        PKT_STATS_TX("Packet-Stats"),
        PKT_STATS_LTE_GTPU("Packet-Stats"),
        PKT_STATS_LTE_GTPC("Packet-Stats"),
        PKT_STATS_3G_GTPC("Packet-Stats"),

        MEMORY_STATS("memory-stats"),

        TRAFFIC_STATS("traffic-stats"),

        RULES_STATS_LTE_SIP("rules-stats-sip"),
        RULES_STATS_LTE_GTPC("rules-stats-gtpv2"),
        RULES_STATS_3G("rules-stats-3g"),

        ANOMALY_STATS_LTE_GTPC("anomaly-stats-gtpv2"),
        ANOMALY_STATS_SGI("anomaly-stats-sgi"),
        ANOMALY_STATS_3G("anomaly-stats-3g"),
        ANOMALY_STATS_LTE_SIP("anomaly-stats-sip"),

        MGMT_RULE_STATS_LTE_GTPC("mgmt-rules-stats-lte-gtpc"),
        MGMT_RULE_STATS_3G("mgmt-rules-stats-3g"),

        USER_COUNT_STATS("user-count"),

        SAMPLING_STATS_VOLTE("Sampling-Stats"),
        SAMPLING_STATS_S11_S1U_GNGP("Sampling-Stats"),
        SAMPLING_STATS_S11_S5S8U_SGI("Sampling-Stats"),

        RULE_COUNT_STATS("rule-count");

        private String responce;

        Response(String responce) {
            this.responce = responce;
        }

        public String getValue() {
            return this.responce;
        }
    }
}
