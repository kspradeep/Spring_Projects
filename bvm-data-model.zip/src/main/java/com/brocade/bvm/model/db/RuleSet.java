package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.regex.Pattern;

@Getter
@NoArgsConstructor
@Entity(name = "ruleset")
public class RuleSet implements DomainObject, Comparable<RuleSet> {

    public static final int RULESET_NAME_MAX_LENGTH = 63;
    public static final String SLX_RULESET_NAME_PATTERN = "[a-zA-Z0-9]{1}([-a-zA-Z0-9_]{0,62})";
    public static final String RULESET_PATTERN_MISMATCH_ERROR = "Ruleset name can contain only alphanumeric characters, underscores and hyphens.$ It must start with an alphanumeric character and not include spaces.$Ruleset name cannot exceed 63 characters.";

    @Id
    @Getter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    @Getter
    private String name;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flow_id", referencedColumnName = "id")
    private Flow flow;

    void reverseMapFlow(Flow flow) {
        this.flow = flow;
    }

    @Setter
    @Column(name = "grid_ruleset_id")
    private Long gridRuleSetId;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Type type;

    @Setter
    @Column(name = "ip_version")
    @Enumerated(EnumType.STRING)
    private IpVersion ipVersion;

    @Setter
    @Column
    private Integer sequence = 0;

    @Setter
    @Column(name = "is_inactive")
    private Boolean isInactive = false;

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "ruleSet", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<Rule> rules = new TreeSet<>();

    public ImmutableSortedSet<Rule> getRules() {
        return ImmutableSortedSet.copyOf(rules);
    }

    public void addRules(SortedSet<Rule> rules) {
        this.rules.addAll(rules);
        rules.forEach(rule -> rule.reverseMapRuleSet(this));
    }

    public void removeRules(SortedSet<Rule> rules) {
        this.rules.removeAll(rules);
    }

    public void setRules(SortedSet<Rule> rules) {
        this.rules.clear();
        addRules(rules);
    }

    public enum Type {
        L2, L3, L23, UDA
    }

    public enum IpVersion {
        V4("ip"), V6("ipv6");
        private String value;

        IpVersion(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    @Override
    public int compareTo(RuleSet ruleSet) {
        //ascending order
        return this.sequence - ruleSet.getSequence();
    }

    public void clearId() {
        this.id = null;
    }
}
