package com.brocade.bvm.model.db.grid;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "destination_group")
public class DestinationGroup implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "group_id")
    private Integer groupId;

    @JsonIgnore
    @Setter
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grid_matrix_id", referencedColumnName = "id")
    private GridMatrix gridMatrix;

    void reverseMapGridMatrix(GridMatrix gridMatrix) {
        this.gridMatrix = gridMatrix;
    }

    @Setter
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "group_path_address_topology_mapping", joinColumns = @JoinColumn(name = "destination_group_id"))
    @Column(name = "grid_topology_path_id")
    private Set<Long> gridTopologyPathIds = new HashSet<>();

    public void addGridTopologyPathId(Long gridTopologyPathId) {
        this.gridTopologyPathIds.add(gridTopologyPathId);
    }

    public void removeGridTopologyPathId(Long gridTopologyPathId) {
        this.gridTopologyPathIds.remove(gridTopologyPathId);
    }
}
