package com.brocade.bvm.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 
 * Represents a first class entity of BVM
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public interface DomainObject {
	Long getId();
	String getName();
}
