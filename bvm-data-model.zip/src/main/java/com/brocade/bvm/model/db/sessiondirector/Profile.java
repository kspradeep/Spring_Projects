package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.db.Device;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "sd_profile")
public class Profile implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "profile_id")
    private Integer profileId;

    @JsonIgnore
    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @OneToMany(mappedBy = "profile", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ProfileInterfaceMapping> interfaceMappings = new HashSet<>();

    public Set<ProfileInterfaceMapping> getInterfaceMappings() {
        return ImmutableSet.copyOf(interfaceMappings);
    }

    public void addInterfaceMappings(Set<ProfileInterfaceMapping> interfaceMappings) {
        this.interfaceMappings.addAll(interfaceMappings);
        interfaceMappings.forEach(interfaceMapping -> interfaceMapping.reverseMapProfile(this));
    }

    public void removeInterfaceMappings(Set<ProfileInterfaceMapping> interfaceMappings) {
        this.interfaceMappings.removeAll(interfaceMappings);
    }

    public void setInterfaceMappings(Set<ProfileInterfaceMapping> interfaceMappings) {
        this.interfaceMappings.clear();
        addInterfaceMappings(interfaceMappings);
    }
}
