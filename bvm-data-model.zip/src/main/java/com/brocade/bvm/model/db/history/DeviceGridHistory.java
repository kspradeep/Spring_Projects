package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "device_grid_history")
public class DeviceGridHistory extends HistoryObject<DeviceGrid> {

    @Setter
    private Long deviceGridId;

    @Setter
    @Lob
    @Column(name = "grid_json")
    private String gridJson;

    @Override
    public DeviceGrid buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        DeviceGrid deviceGrid = null;
        try {
            deviceGrid = mapper.readValue(gridJson, DeviceGrid.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the DeviceGridHistory", e);
        }
        return deviceGrid;
    }
}
