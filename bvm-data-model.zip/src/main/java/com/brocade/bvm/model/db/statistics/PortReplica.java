package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortReplica {
    private long id;
    private String name;
    private String type;
}
