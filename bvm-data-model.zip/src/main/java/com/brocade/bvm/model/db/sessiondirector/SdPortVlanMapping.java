package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;


/**
 * VLAN Mapping POJO for SD Egress port
 */

@Setter
@Getter
@Entity(name = "port_vlan_mapping")
public class SdPortVlanMapping implements DomainObject{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String name;

    @Column(name = "vlan_id")
    private Long vlanId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sd_port_id", referencedColumnName = "id")
    private EgressPort sdPort;

    void reverseMapSdPort(EgressPort port) {
        this.sdPort = port;
    }

    @Column(name = "is_tagged")
    private boolean tagged;
}

