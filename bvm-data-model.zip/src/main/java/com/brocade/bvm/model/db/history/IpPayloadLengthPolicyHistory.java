package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;

@NoArgsConstructor
@Entity(name = "ip_payload_length_policy_history")
@Getter
@Slf4j
public class IpPayloadLengthPolicyHistory extends HistoryObject<IpPayloadLengthPolicy> {
    @Setter
    @Lob
    @Column(name = "module_policy_json")
    private String modulePolicyJson;

    @Override
    public IpPayloadLengthPolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        IpPayloadLengthPolicy policy = null;
        try {
            policy = mapper.readValue(modulePolicyJson, IpPayloadLengthPolicy.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the IpPayloadLengthPolicyHistory", e);
        }
        return policy;
    }
}
