package com.brocade.bvm.model.db;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity(name = "setup_history")
public class SetupHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column(name = "set_up_date_time")
    private String setUpDateTime;

    @Setter
    @Column
    private String version;

    @Setter
    @Column
    private String action;

}
