package com.brocade.bvm.model.db;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Getter
@Entity(name = "template_policy")
@Inheritance(strategy = InheritanceType.JOINED)
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public abstract class TemplatePolicy extends ManagedObject {

    @Column(name = "device_type")
    @Setter
    @Enumerated(EnumType.STRING)
    private Device.Type deviceType;

    @Column(name = "device_mode")
    @Setter
    @Enumerated(EnumType.STRING)
    private Device.Mode deviceMode;

    @Column(name = "device_model")
    @Setter
    private String deviceModel;

    @Setter
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "template_policy_device_mapping", joinColumns = @JoinColumn(name = "template_policy_id"))
    @Column(name = "device_id")
    private Set<Long> deviceIds = new HashSet<>();

    @Setter
    @Transient
    private Boolean isInUse = false;
}
