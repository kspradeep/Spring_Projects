package com.brocade.bvm.model.db;


import lombok.Getter;
import lombok.Setter;

@Getter
public class DeviceInfo {
    @Setter
    private String sysName;

    @Setter
    private String ipAddress;

    @Setter
    private String chassis;

    @Setter
    private Device device;
}
