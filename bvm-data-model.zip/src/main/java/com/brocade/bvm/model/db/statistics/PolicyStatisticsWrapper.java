package com.brocade.bvm.model.db.statistics;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PolicyStatisticsWrapper {
    String name;
    List<PolicyStatistics> policyStatistics = new ArrayList<>();
}
