package com.brocade.bvm.model.db;

import com.brocade.bvm.model.exception.ServerException;
import org.springframework.security.core.context.SecurityContextHolder;
import sun.misc.BASE64Encoder;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Named;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Arrays;

@Named
public class CustomAuditingEntityListener {
    private static java.security.Key PRIVATE_KEY;

    static {
        try {
            /*
            128bits (16bytes) key is used and not 256.
            See https://github.com/spring-projects/spring-security/issues/2917 and https://en.wikipedia.org/wiki/Restrictions_on_the_import_of_cryptography
            to understand why it's not easy to ship with a 256 bit key.
            Spring Encryptors has a much easier interface for AES encryption, but provides only a 256 bit key encryption.
             */
            byte[] keyBytes = Arrays.copyOf("v3@F_Fww6}_As~BV".getBytes("UTF-8"), 16);
            PRIVATE_KEY = new SecretKeySpec(keyBytes, "AES");
        } catch (UnsupportedEncodingException e) {
            throw new ServerException(e);
        }
    }

    @PrePersist
    public void prePersist(Object target) {
        if (target instanceof ManagedObject) {
            ((ManagedObject) target).setLastUpdatedTime(Instant.now());
        }

        if (target instanceof Job) {
            Job job = (Job) target;
            job.setCreatedTime(Instant.now());
            job.setLastUpdatedTime(Instant.now());
            job.setCreatedByUser(SecurityContextHolder.getContext().getAuthentication() != null
                    ? SecurityContextHolder.getContext().getAuthentication().getName()
                    : "infosim"); // Job is always created under request scope, so this should never happen!
            if (Job.Type.RECONCILE_POLICY != job.getType() && Job.Type.RECONCILE_PORT_GROUP != job.getType() && Job.Type.RECONCILE_PORT_CHANNEL != job.getType() && Job.Type.RECONCILE_DEVICE != job.getType()) {
                job.setCreatedByUserPassword(SecurityContextHolder.getContext().getAuthentication() != null
                        ? encryptPassword(SecurityContextHolder.getContext().getAuthentication().getCredentials().toString())
                        : encryptPassword("stablenet"));
            }
        } else if (target instanceof FirmwareJob) {
            FirmwareJob job = (FirmwareJob) target;
            job.setCreatedTime(Instant.now());
            job.setLastUpdatedTime(Instant.now());
        }
    }

    @PreRemove
    @PreUpdate
    public void preUpdate(Object target) {
        if (target instanceof ManagedObject) {
            ((ManagedObject) target).setLastUpdatedTime(Instant.now());
        }

        if (target instanceof Job) {
            ((Job) target).setLastUpdatedTime(Instant.now());
        } else if (target instanceof FirmwareJob) {
            ((FirmwareJob) target).setLastUpdatedTime(Instant.now());
        }
    }

    private String encryptPassword(String plainTextPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, PRIVATE_KEY);
            byte[] encrypted = cipher.doFinal(plainTextPassword.getBytes("UTF-8"));
            return new BASE64Encoder().encode(encrypted);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | UnsupportedEncodingException | IllegalBlockSizeException e) {
            throw new ServerException(e);
        }
    }
}
