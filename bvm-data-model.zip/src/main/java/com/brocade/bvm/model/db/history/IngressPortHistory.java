package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

/**
 * This class saves the ingress Port history
 */

@Getter
@NoArgsConstructor
@Entity(name = "sd_ingress_port_history")
public class IngressPortHistory extends HistoryObject<IngressPort> {

    @Setter
    @Lob
    @Column(name = "port_json")
    private String portJson;

    @Override
    public IngressPort buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        IngressPort ingressPort = null;
        try {
            ingressPort = mapper.readValue(portJson, IngressPort.class);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the ingressPort history", e);
        }
        return ingressPort;
    }
}
