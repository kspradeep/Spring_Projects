package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class EVMOverview {
    private int totalNoOfGrids;
    private int totalTapPorts;
    private int totalToolPorts;
    private int totalPolices;
}
