package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "event")
public class Event implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Status status = Status.NEW;

    @ManyToOne
    @JoinTable(name = "event_job_mapping",
            joinColumns = {@JoinColumn(name = "event_id")},
            inverseJoinColumns = {@JoinColumn(name = "job_id", referencedColumnName = "id")})
    private Job job;

    @Column(name = "created_time")
    private Instant createdTime;

    @Column(name = "last_updated_time")
    private Instant lastUpdatedTime;

    @Setter
    @Column(name = "target_host")
    private String targetHost;

    @Setter
    @Column(name = "parent_object_id")
    private Long parentObjectId;

    @Setter
    @Lob
    @Column(name = "result")
    private String result;

    @Setter
    @Column
    private String type;

    @Column(name = "created_by")
    private String createdByUser;

    @Setter
    @Column(name = "job_status")
    private String jobStatus;

    @Setter
    @Enumerated(EnumType.STRING)
    @Column(name = "job_severity")
    private Severity severity;

    @Override
    public String getName() {
        return String.format("%s_%s", job, createdTime);
    }

    public enum Status {
        NEW, CLOSED
    }

    public enum Severity {
        INFO,
        WARNING,
        MAJOR,
        CRITICAL
    }
}
