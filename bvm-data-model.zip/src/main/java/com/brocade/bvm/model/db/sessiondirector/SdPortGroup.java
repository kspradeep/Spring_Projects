package com.brocade.bvm.model.db.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.EgressPortGroupHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "sd_egress_port_group")
public class SdPortGroup extends ManagedObject implements HasHistory {

    public static final Integer NAME_MAX_LENGTH = 32;

    public static final Integer MAX_PORT_COUNT_ALLOWED = 100;

    @Setter
    @Column
    private String state;

    @Setter
    @Column(name = "load_balance")
    @Enumerated(EnumType.STRING)
    private LoadBalanceAlgorithms loadBalance;

    @Setter
    @Column(name = "is_default")
    private boolean isDefault;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinTable(
            name = "port_port_group",
            joinColumns = @JoinColumn(name = "sd_egress_port_group_id"),
            inverseJoinColumns = @JoinColumn(name = "sd_port_id")
    )
    private Set<EgressPort> egressPorts = new HashSet<>();

    public ImmutableSet<EgressPort> getEgressPorts() {
        return ImmutableSet.copyOf(egressPorts);
    }

    public void addEgressPorts(Set<EgressPort> egressPorts) {
        this.egressPorts.addAll(egressPorts);
    }

    public void removeEgressPorts(Set<EgressPort> egressPorts) {
        this.egressPorts.removeAll(egressPorts);
    }

    public void setEgressPorts(Set<EgressPort> egressPorts) {
        this.egressPorts.clear();
        addEgressPorts(egressPorts);
    }

    public enum LoadBalanceAlgorithms {
        HASH("hash"),
        ROUND_ROBIN("round-robin"),
        NO_VLAN("none-novlan");

        private String loadBalanceAlgorithms;

        LoadBalanceAlgorithms(String loadBalanceAlgorithms) {
            this.loadBalanceAlgorithms = loadBalanceAlgorithms;
        }

        public String getName() {
            return this.loadBalanceAlgorithms;
        }
    }

    @Override
    public HistoryObject buildHistory() {
        EgressPortGroupHistory portGroupHistory = new EgressPortGroupHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(SdPortGroup.class, new SdPortGroup.EgressPortGroupJsonSerializer());
        portGroupHistory.setName(getName());
        portGroupHistory.setWorkflowStatus(getWorkflowStatus());
        portGroupHistory.setWorkflowType(this.getWorkflowType());
        mapper.registerModule(simpleModule);
        try {
            SdPortGroup portGroup = this;
            portGroupHistory.setPortGroupJson(mapper.writeValueAsString(portGroup));
        } catch (JsonProcessingException e) {
            log.error("Failed to create sd port group history. {}", e.getMessage());
            throw new ServerException("Failed to create sd port group history", e);
        }
        return portGroupHistory;
    }

    private class EgressPortGroupJsonSerializer extends JsonSerializer<SdPortGroup> {
        @Override
        public void serialize(SdPortGroup portGroup, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.configure(JsonGenerator.Feature.IGNORE_UNKNOWN, true);
                jsonGenerator.writeNumberField("id", portGroup.getId().longValue());
                jsonGenerator.writeStringField("name", portGroup.getName());
                jsonGenerator.writeObjectField("loadBalance", portGroup.getLoadBalance());
                jsonGenerator.writeBooleanField("default", portGroup.isDefault());
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", portGroup.getDevice().getId());
                jsonGenerator.writeEndObject();
                if (portGroup.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", portGroup.getWorkflowStatus().name());
                }
                if (portGroup.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", portGroup.getWorkflowType().name());
                }
                Device device = portGroup.getDevice();
                device.setLastCollectedTime(null);
                device.setLastUpdatedTime(null);
                jsonGenerator.writeArrayFieldStart("egressPorts");
                if (!portGroup.getEgressPorts().isEmpty()) {
                    portGroup.getEgressPorts().forEach(port -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (port.getId() == null) {
                                jsonGenerator.writeNullField("id");
                            } else {
                                jsonGenerator.writeNumberField("id", port.getId());
                            }
                            jsonGenerator.writeStringField("name", port.getName());
                            jsonGenerator.writeObjectFieldStart("device");
                            jsonGenerator.writeNumberField("id", portGroup.getDevice().getId());
                            jsonGenerator.writeEndObject();
                            jsonGenerator.writeEndObject();
                        } catch (Exception e) {
                        }
                    });
                }
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
