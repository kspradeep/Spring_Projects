package com.brocade.bvm.model.db.admin;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.exception.ServerException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.persistence.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

@NoArgsConstructor
@Entity(name = "stablenet_agent_config")
@Getter
public class StablenetAgentConfig implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "agent_id")
    private String agentId;

    @Setter
    @Column(name = "port_no")
    private Integer portNo;

    @Setter
    private String ip;

    @Setter
    @Column(name = "is_connected")
    private boolean connected;
}
