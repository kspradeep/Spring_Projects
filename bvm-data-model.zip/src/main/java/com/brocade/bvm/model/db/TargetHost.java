package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import java.time.Instant;

@Getter
@Entity(name = "target_host")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "object_type")
@EntityListeners({CustomAuditingEntityListener.class})
//Added handler for hibernateLazyInitialier , so the jackson serialize gets triggered only after loading the beans.
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public abstract class TargetHost implements DomainObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Column
    private String name;

    @Setter
    @Column(name = "last_updated_time")
    private Instant lastUpdatedTime;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Mode mode;

    @Setter
    //accepts IP address and hostname
    //TODO rename ipAddress to host
    @Column(name = "ip_address")
    private String ipAddress;

    public enum Mode {
        PLAIN, OPENFLOW, OPENSTACK
    }

    public void clearId(){
        this.id = null;
    }
}

