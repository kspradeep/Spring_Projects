package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.TunnelDevicePolicyHistory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.IOException;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "tunnel_device_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class TunnelDevicePolicy extends DevicePolicy implements HasHistory {

    public static final Integer TUNNEL_ID_MIN = 1;

    public static final Integer TUNNEL_ID_MAX = 256;

    public static final Integer TUNNEL_NAME_LENGTH_MAX = 64;

    @Column(name = "is_enabled")
    private boolean isEnabled;

    @Setter
    @Column
    @Enumerated(EnumType.STRING)
    private Type type;

    public enum Type {
        GRE,
        MPLS
    }

    @Override
    public HistoryObject buildHistory() {
        TunnelDevicePolicyHistory policyHistory = new TunnelDevicePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(TunnelDevicePolicy.class, new TunnelDevicePolicy.MPLSTunnelPolicyJsonSerializer());
        policyHistory.setDevice(this.getDevice());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setDevicePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the Policy Object in History", e);
        }
        return policyHistory;
    }

    private class MPLSTunnelPolicyJsonSerializer extends JsonSerializer<TunnelDevicePolicy> {
        @Override
        public void serialize(TunnelDevicePolicy devicePolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", devicePolicy.getId().longValue());
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                jsonGenerator.writeStringField("type", devicePolicy.getType().name());
                if (devicePolicy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", devicePolicy.getWorkflowStatus().name());
                }
                if (devicePolicy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", devicePolicy.getWorkflowType().name());
                }
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", devicePolicy.getDevice().getId());
                jsonGenerator.writeEndObject();
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                jsonGenerator.writeBooleanField("enabled", isEnabled);
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                //e.printStackTrace();
            }
            //jsonGenerator.writeEndObject();
        }
    }
}
