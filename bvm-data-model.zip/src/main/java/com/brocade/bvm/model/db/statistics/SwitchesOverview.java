package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class SwitchesOverview {
    private int totalOperationalSwitches;
    private long totalTapPorts;
    private long totalToolPorts;
    private int operationalSwitchedPolicies;
    private int standaloneSwitches;
    private int gridSwitches;
    private int gridPolices;
}
