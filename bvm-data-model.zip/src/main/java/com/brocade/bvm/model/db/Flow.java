package com.brocade.bvm.model.db;

import com.brocade.bvm.model.DomainObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

@NoArgsConstructor
@Entity(name = "flow")
public class Flow implements DomainObject, Comparable<Flow> {

    @Id
    @Getter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Setter
    @Getter
    @Column
    private String name;

    @Setter
    @Getter
    @Column(name = "flow_name")
    private String flowName;

    @JsonIgnore
    @Getter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "policy_id", referencedColumnName = "id")
    private Policy policy;

    void reverseMapPolicy(Policy policy) {
        this.policy = policy;
    }

    @Setter
    @Getter
    @Column(name = "grid_policy_id")
    private Long gridPolicyId;

    @Setter
    @Getter
    @Column(name = "destination_group_id")
    private Integer destinationGroupId;

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "flow", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<RuleSet> ruleSets = new TreeSet<>();

    public ImmutableSortedSet<RuleSet> getRuleSets() {
        return ImmutableSortedSet.copyOf(ruleSets);
    }

    public void addRuleSets(SortedSet<RuleSet> ruleSets) {
        this.ruleSets.addAll(ruleSets);
        ruleSets.forEach(ruleSet -> ruleSet.reverseMapFlow(this));
    }

    public void removeRuleSets(SortedSet<RuleSet> ruleSets) {
        this.ruleSets.removeAll(ruleSets);
    }

    public void setRuleSets(SortedSet<RuleSet> ruleSets) {
        this.ruleSets.clear();
        addRuleSets(ruleSets);
    }

    @Getter
    @Setter
    @Column
    private Integer sequence;

    @Getter
    @Setter
    @Column
    private String sourceMacTag;

    @Getter
    @Setter
    @Column
    private String destinationMacTag;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "flow_vlan_mapping", joinColumns = @JoinColumn(name = "flow_id"))
    @Column(name = "vlan_id")
    private Set<String> vlans = new HashSet<>(); //some devices accept regex strings like "any" for vlan

    public ImmutableSet<String> getVlans() {
        return ImmutableSet.copyOf(vlans);
    }

    public void addVlan(Set<String> vlans) {
        this.vlans.addAll(vlans);
    }

    public void removeVlan(Set<String> vlans) {
        this.vlans.removeAll(vlans);
    }

    public void setVlans(Set<String> vlans) {
        this.vlans.clear();
        addVlan(vlans);
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "flow_tunnel_mapping",
            joinColumns = {@JoinColumn(name = "flow_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "tunnel_id", referencedColumnName = "id")})
    @OrderColumn(name = "order_index")
    private List<TunnelDevicePolicy> tunnelPolicies = new ArrayList<>();

    public void removeTunnelPolicies(List<TunnelDevicePolicy> tunnelPolicies) {
        this.tunnelPolicies.removeAll(tunnelPolicies);
    }

    public void addTunnelPolicies(List<TunnelDevicePolicy> tunnelPolicies) {
        this.tunnelPolicies.addAll(tunnelPolicies);
    }

    @JsonProperty
    public void setTunnelPolicies(List<TunnelDevicePolicy> tunnelPolicies) {
        this.tunnelPolicies.clear();
        this.tunnelPolicies.addAll(tunnelPolicies);
    }

    @JsonProperty
    public ImmutableList<TunnelDevicePolicy> getTunnelPolicies() {
        return ImmutableList.copyOf(tunnelPolicies);
    }

    /*
        Ingress ports/groups ideally belong in a policy, but are mapped here for simplified db model
        Validation will be performed outside the model
         */
    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "flow_port_mapping_ingress",
            joinColumns = {@JoinColumn(name = "flow_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<ManagedObject> ingressPortsAndPortGroups = new HashSet<>();

    public void removeIngressPorts(Set<Port> ports) {
        this.ingressPortsAndPortGroups.removeAll(ports);
    }

    public void removeIngressPortGroups(Set<PortGroup> portGroups) {
        this.ingressPortsAndPortGroups.removeAll(portGroups);
    }

    public void addIngressPorts(Set<Port> ports) {
        this.ingressPortsAndPortGroups.addAll(ports);
    }

    public void addIngressPortGroups(Set<PortGroup> portGroups) {
        this.ingressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public void setIngressPorts(Set<Port> ports) {
        this.ingressPortsAndPortGroups.addAll(ports);
    }

    @JsonProperty
    public void setIngressPortGroups(Set<PortGroup> portGroups) {
        this.ingressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public ImmutableSet<Port> getIngressPorts() {
        return ImmutableSet.copyOf(ingressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet()));
    }

    @JsonProperty
    public ImmutableSet<PortGroup> getIngressPortGroups() {
        return ImmutableSet.copyOf(ingressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet()));
    }

    public void clearIngressPortsAndPortGroups() {
        this.ingressPortsAndPortGroups.clear();
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "flow_port_mapping_egress",
            joinColumns = {@JoinColumn(name = "flow_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<ManagedObject> egressPortsAndPortGroups = new HashSet<>();

    public void removeEgressPorts(Set<Port> ports) {
        this.egressPortsAndPortGroups.removeAll(ports);
    }

    public void removeEgressPortGroups(Set<PortGroup> portGroups) {
        this.egressPortsAndPortGroups.removeAll(portGroups);
    }

    public void addEgressPorts(Set<Port> ports) {
        this.egressPortsAndPortGroups.addAll(ports);
    }

    public void addEgressPortGroups(Set<PortGroup> portGroups) {
        this.egressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public void setEgressPorts(Set<Port> ports) {
        this.egressPortsAndPortGroups.addAll(ports);
    }

    @JsonProperty
    public void setEgressPortGroups(Set<PortGroup> portGroups) {
        this.egressPortsAndPortGroups.addAll(portGroups);
    }

    @JsonProperty
    public ImmutableSet<Port> getEgressPorts() {
        Set<Port> egressPorts = egressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet());
        egressPorts.forEach(mo -> {
            if (mo != null) {
                Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flowEgressManagedObjects.stream().filter(flowEgressMO -> flowEgressMO.getManagedObject().getId().longValue() == mo.getId().longValue()).findAny();
                if (optionalFlowEgressManagedObject != null && optionalFlowEgressManagedObject.isPresent()) {
                    FlowEgressManagedObject flowEgressManagedObject = optionalFlowEgressManagedObject.get();
                    if (flowEgressManagedObject.getPrecedence() != null) {
                        mo.setPrecedence(flowEgressManagedObject.getPrecedence());
                    }
                }
            }
        });
        return ImmutableSet.copyOf(egressPorts);
    }

    @JsonProperty
    public ImmutableSet<PortGroup> getEgressPortGroups() {
        Set<PortGroup> egressPortGroups = egressPortsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet());
        egressPortGroups.forEach(mo -> {
            if (mo != null) {
                Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flowEgressManagedObjects.stream().filter(flowEgressMO -> flowEgressMO.getManagedObject().getId().longValue() == mo.getId().longValue()).findAny();
                if (optionalFlowEgressManagedObject != null && optionalFlowEgressManagedObject.isPresent()) {
                    FlowEgressManagedObject flowEgressManagedObject = optionalFlowEgressManagedObject.get();
                    if (flowEgressManagedObject.getPrecedence() != null) {
                        mo.setPrecedence(flowEgressManagedObject.getPrecedence());
                    }
                }
            }
        });
        return ImmutableSet.copyOf(egressPortGroups);
    }

    public void clearEgressPortsAndPortGroups() {
        this.egressPortsAndPortGroups.clear();
        clearFlowEgressPortGroups();
    }

    @JsonIgnore
    @OneToMany(mappedBy = "flow", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<FlowEgressManagedObject> flowEgressManagedObjects = new HashSet<>();

    public void addFlowEgressManagedObjects(Set<? extends ManagedObject> managedObjects) {
        if (managedObjects != null && !managedObjects.isEmpty()) {
            managedObjects.forEach(mo -> {
                if (mo != null) {
                    FlowEgressManagedObject flowEgressManagedObject = new FlowEgressManagedObject();
                    Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flowEgressManagedObjects.stream().filter(flowEgressMO -> flowEgressMO.getManagedObject().getId().longValue() == mo.getId().longValue()).findAny();
                    if (optionalFlowEgressManagedObject == null || !optionalFlowEgressManagedObject.isPresent()) {
                        if (mo instanceof Port) {
                            Port port = (Port) mo;
                            flowEgressManagedObject.setPort(port);
                            flowEgressManagedObject.setPrecedence(port.getPrecedence());
                        } else {
                            PortGroup portGroup = (PortGroup) mo;
                            flowEgressManagedObject.setPortGroup(portGroup);
                            flowEgressManagedObject.setPrecedence(portGroup.getPrecedence());
                        }
                        flowEgressManagedObjects.add(flowEgressManagedObject);
                    }
                }
            });
            flowEgressManagedObjects.forEach(flowEgressManagedObject -> flowEgressManagedObject.reverseMapFlow(this));
        }
    }

    public void removeFlowEgressManagedObjects(Set<? extends ManagedObject> managedObjects) {
        managedObjects.forEach(mo -> {
            if (mo != null) {
                Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flowEgressManagedObjects.stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getManagedObject().getId().longValue() == mo.getId().longValue()).findAny();
                if (optionalFlowEgressManagedObject != null && optionalFlowEgressManagedObject.isPresent()) {
                    flowEgressManagedObjects.remove(optionalFlowEgressManagedObject.get());
                }
            }
        });
    }

    @JsonProperty
    public Set<FlowEgressManagedObject> getFlowEgressPorts() {
        return ImmutableSet.copyOf(flowEgressManagedObjects.stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getManagedObject() instanceof Port).collect(Collectors.toSet()));
    }

    @JsonProperty
    public Set<FlowEgressManagedObject> getFlowEgressPortGroups() {
        return ImmutableSet.copyOf(flowEgressManagedObjects.stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getManagedObject() instanceof PortGroup).collect(Collectors.toSet()));
    }

    @JsonProperty
    public void setFlowEgressPorts(Set<FlowEgressManagedObject> flowEgressManagedObjects) {
        this.flowEgressManagedObjects.addAll(flowEgressManagedObjects);
    }

    @JsonProperty
    public void setFlowEgressPortGroups(Set<FlowEgressManagedObject> flowEgressManagedObjects) {
        this.flowEgressManagedObjects.addAll(flowEgressManagedObjects);
    }

    @JsonProperty
    public void setFlowEgressManagedObjects(Set<FlowEgressManagedObject> flowEgressManagedObjects) {
        this.flowEgressManagedObjects.addAll(flowEgressManagedObjects);
    }

    public void clearFlowEgressPortGroups() {
        this.flowEgressManagedObjects.clear();
    }

    @Setter
    @Getter
    @JsonProperty(value = "tagged")
    @Column(name = "is_tagged")
    private Boolean isTagged;

    @Setter
    @Getter
    @JsonProperty(value = "tvfDomain")
    @Column(name = "tvf_domain")
    private Boolean tvfDomain = false;

    @Setter
    @Getter
    @JsonProperty(value = "vlanStripping")
    @Column(name = "vlan_stripping")
    private Boolean vlanStripping = false;

    @Setter
    @Getter
    @Column(name = "tagged_vlan_id")
    private Integer taggedVlanId;

    @Setter
    @Getter
    @JsonProperty(value = "defaultRouteMapDrop")
    @Column(name = "is_default_route_map_drop")
    private Boolean isDefaultRouteMapDrop;

    @JsonIgnore
    @Getter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "packet_truncation_mapping_id", referencedColumnName = "id")
    private PacketTruncationMapping packetTruncationMapping;

    @JsonDeserialize
    public void setPacketTruncationMapping(PacketTruncationMapping packetTruncationMapping) {
        this.packetTruncationMapping = packetTruncationMapping;
    }

    @Override
    public int compareTo(Flow flow) {
        //ascending order
        return this.sequence - flow.getSequence();
    }

    public void clearId() {
        this.id = null;
    }
}
