package com.brocade.bvm.model.db.statistics;

import lombok.Data;

@Data
public class PortUtilization {
    private Long id;
    private double utilization;
    private String port;

    @Override
    public int hashCode() {
        return Long.hashCode(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (!(obj instanceof PortUtilization))
            return false;
        if (obj == this)
            return true;
        return this.getId() == ((PortUtilization) obj).getId();
    }
}
