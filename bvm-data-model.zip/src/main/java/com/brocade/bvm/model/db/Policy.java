package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Getter
@NoArgsConstructor
@Entity(name = "policy")
@Slf4j
public class Policy extends ManagedObject implements HasHistory {

    public static final int MLXE_POLICY_NAME_MAX_LENGTH = 80;

    public static final String POLICY_NAME_FORMAT = "rm_%s";
    public static final String SLX_POLICY_NAME_PATTERN = "[a-zA-Z]{1}([-a-zA-Z0-9\\.\\\\\\\\@#\\+\\*\\(\\)=\\{~\\}%<>=$_\\[\\]\\|]{0,62})";

    public static final String SLX_POLICY_NAME_ERROR_MESSAGE = "Invalid Policy Set name!$" +
            "Policy Set name:$" +
            "1.\tCan contain up to 63 characters, and must start with a alphabetic character" +
            "2.\tCannot include spaces, but can include these special characters along with character dollar: %@\\#%*()_+-{}[]<>|$.~=";

    @JsonIgnore
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @JsonDeserialize
    public void setDevice(Device device) {
        this.device = device;
    }

    @Setter
    @Column(name = "field_offset_1")
    private Long fieldOffset1;

    @Setter
    @Column(name = "field_offset_2")
    private Long fieldOffset2;

    @Setter
    @Column(name = "field_offset_3")
    private Long fieldOffset3;

    @Setter
    @Column(name = "field_offset_4")
    private Long fieldOffset4;

    @Setter
    @Column(name = "is_loopback")
    private Boolean loopbackEnabled = false;

    public Boolean isLoopbackEnabled() {
        return loopbackEnabled;
    }

    @Setter
    @Column(name = "is_timestamp")
    private boolean isTimestamp;

    @Setter
    @Column(name = "is_gtp_http_filtered")
    private boolean isGtpHttpFiltered;

    @Setter
    @Column(name = "is_ingress_valid")
    private boolean isIngressValid;

    @Setter
    @Column(name = "egress_action")
    private String egressAction;

    @Setter
    @Column(name = "created_from_sd")
    private boolean createdFromSd;

    @Setter
    @Column(name = "grid_policy_set_id")
    private Long gridPolicySetId;

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "gtp_device_policy_id", referencedColumnName = "id")
    private GTPDevicePolicy gtpProfile;//Should not use DevicePolicy , we get 61 join problem

    @OrderBy("sequence ASC")
    @OneToMany(mappedBy = "policy", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private SortedSet<Flow> flows = new TreeSet<>();

    @Setter
    @Column(name = "audit_flow_name")
    private String auditFlowName;

    @Setter
    @Column(name = "is_in_warning_state")
    private boolean isInWarningState;

    public ImmutableSortedSet<Flow> getFlows() {
        return ImmutableSortedSet.copyOf(flows);
    }

    public void addFlows(SortedSet<Flow> flows) {
        this.flows.addAll(flows);
        flows.forEach(flow -> flow.reverseMapPolicy(this));
    }

    public void removeFlows(SortedSet<Flow> flows) {
        this.flows.removeAll(flows);
    }

    public void setFlows(SortedSet<Flow> flows) {
        this.flows.clear();
        addFlows(flows);
    }

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "template_policy_mapping",
            joinColumns = {@JoinColumn(name = "policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "template_id", referencedColumnName = "id")})
    private Set<FlexMatchProfile> flexMatchProfiles = new HashSet<>();

    public ImmutableSet<FlexMatchProfile> getFlexMatchProfiles() {
        return ImmutableSortedSet.copyOf(flexMatchProfiles);
    }

    public void addFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.addAll(flexMatchProfiles);
    }

    public void removeFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.removeAll(flexMatchProfiles);
    }

    @JsonProperty
    public void setFlexMatchProfiles(Set<FlexMatchProfile> flexMatchProfiles) {
        this.flexMatchProfiles.clear();
        addFlexMatchProfiles(flexMatchProfiles);
    }

    public String getComputedName() {
        if (isLegacy() || isCustomRmName()) {
            return getName();
        } else {
            return String.format(Policy.POLICY_NAME_FORMAT, this.getId());
        }
    }

    @Setter
    @Column(name = "preserve_header")
    private boolean preserveHeader;

    @Setter
    @Column(name = "is_legacy")
    private boolean legacy;

    @Setter
    @Column(name = "is_grid_policy")
    private boolean gridPolicy;

    @Setter
    @Column(name = "is_custom_rm_name")
    private boolean isCustomRmName = true;

    @Override
    public HistoryObject buildHistory() {
        PolicyHistory policyHistory = new PolicyHistory();
        BeanUtils.copyProperties(this, policyHistory);
        policyHistory.setDevice(this.device);
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(Policy.class, new PolicyJsonSerializer());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setPolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialize the Policy object in History", e);
        }
        return policyHistory;
    }

    private class PolicyJsonSerializer extends JsonSerializer<Policy> {
        @Override
        public void serialize(Policy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                if (policy.getFieldOffset1() != null && policy.getFieldOffset2() != null && policy.getFieldOffset3() != null && policy.getFieldOffset4() != null) {
                    jsonGenerator.writeNumberField("fieldOffset1", policy.getFieldOffset1());
                    jsonGenerator.writeNumberField("fieldOffset2", policy.getFieldOffset2());
                    jsonGenerator.writeNumberField("fieldOffset3", policy.getFieldOffset3());
                    jsonGenerator.writeNumberField("fieldOffset4", policy.getFieldOffset4());
                }
                if (policy.getLoopbackEnabled() != null) {
                    jsonGenerator.writeBooleanField("loopbackEnabled", policy.getLoopbackEnabled());
                }
                jsonGenerator.writeBooleanField("timestamp", policy.isTimestamp());
                jsonGenerator.writeBooleanField("gtpHttpFiltered", policy.isGtpHttpFiltered());
                jsonGenerator.writeBooleanField("ingressValid", policy.isIngressValid());
                jsonGenerator.writeStringField("egressAction", policy.getEgressAction());
                jsonGenerator.writeBooleanField("createdFromSd", policy.isCreatedFromSd());
                jsonGenerator.writeBooleanField("gridPolicy", policy.gridPolicy);
                if (policy.getGridPolicySetId() != null) {
                    jsonGenerator.writeNumberField("gridPolicySetId", policy.getGridPolicySetId().longValue());
                }
                if (policy.getAuditFlowName() != null) {
                    jsonGenerator.writeStringField("auditFlowName", policy.getAuditFlowName());
                }
                if (policy.getGtpProfile() != null) {
                    jsonGenerator.writeObjectFieldStart("gtpProfile");
                    jsonGenerator.writeNumberField("id", policy.getGtpProfile().getId());
                    jsonGenerator.writeStringField("name", policy.getGtpProfile().getName());
                    jsonGenerator.writeNumberField("profileId", policy.getGtpProfile().getProfileId());
                    jsonGenerator.writeEndObject();
                }
                jsonGenerator.writeBooleanField("preserveHeader", policy.isPreserveHeader());
                jsonGenerator.writeBooleanField("legacy", policy.isLegacy());

                jsonGenerator.writeArrayFieldStart("flexMatchProfiles");
                if (policy.getFlexMatchProfiles() != null) {
                    policy.getFlexMatchProfiles().forEach(profile -> {
                        try {
                            jsonGenerator.writeStartObject();
                            jsonGenerator.writeNumberField("id", profile.getId());
                            jsonGenerator.writeStringField("name", profile.getName());
                            jsonGenerator.writeBooleanField("isInUse", profile.getIsInUse());
                            jsonGenerator.writeArrayFieldStart("flexHeaders");
                            if (profile.getFlexHeaders() != null) {
                                profile.getFlexHeaders().forEach(flexHeader -> {
                                    try {
                                        jsonGenerator.writeObject(flexHeader);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                }
                jsonGenerator.writeEndArray();

                jsonGenerator.writeArrayFieldStart("flows");
                if (policy.getFlows() != null) {
                    policy.getFlows().forEach(flow -> {
                        try {
                            jsonGenerator.writeStartObject();
                            if (flow.getId() == null) {
                                jsonGenerator.writeNullField("id");
                            } else {
                                jsonGenerator.writeNumberField("id", flow.getId());
                            }
                            jsonGenerator.writeStringField("name", flow.getName());
                            if (!Strings.isNullOrEmpty(flow.getFlowName())) {
                                jsonGenerator.writeStringField("flowName", flow.getFlowName());
                            }
                            if (flow.getGridPolicyId() != null) {
                                jsonGenerator.writeNumberField("gridPolicyId", flow.getGridPolicyId().longValue());
                            }
                            jsonGenerator.writeArrayFieldStart("ruleSets");
                            if (flow.getRuleSets() != null) {
                                flow.getRuleSets().forEach(ruleSet -> {
                                    try {
                                        jsonGenerator.writeObject(ruleSet);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeNumberField("sequence", flow.getSequence());
                            if (flow.getDestinationGroupId() == null) {
                                jsonGenerator.writeNullField("destinationGroupId");
                            } else {
                                jsonGenerator.writeNumberField("destinationGroupId", flow.getDestinationGroupId());
                            }
                            jsonGenerator.writeStringField("sourceMacTag", flow.getSourceMacTag());
                            jsonGenerator.writeStringField("destinationMacTag", flow.getDestinationMacTag());

                            jsonGenerator.writeArrayFieldStart("vlans");
                            if (flow.getVlans() != null) {
                                flow.getVlans().forEach(vlan -> {
                                    try {
                                        jsonGenerator.writeObject(vlan);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("tunnelPolicies");
                            if (flow.getTunnelPolicies() != null) {
                                flow.getTunnelPolicies().forEach(tunnelDevicePolicy -> {
                                    try {
                                        jsonGenerator.writeStartObject();
                                        if (tunnelDevicePolicy.getId() == null) {
                                            jsonGenerator.writeNullField("id");
                                        } else {
                                            jsonGenerator.writeNumberField("id", tunnelDevicePolicy.getId());
                                        }
                                        jsonGenerator.writeStringField("name", tunnelDevicePolicy.getName());
                                        jsonGenerator.writeStringField("type", tunnelDevicePolicy.getType().name());
                                        jsonGenerator.writeObjectFieldStart("device");
                                        if (tunnelDevicePolicy.getDevice() != null) {
                                            jsonGenerator.writeNumberField("id", tunnelDevicePolicy.getDevice().getId());
                                        }
                                        jsonGenerator.writeEndObject();
                                        jsonGenerator.writeStringField("name", tunnelDevicePolicy.getName());
                                        jsonGenerator.writeBooleanField("enabled", tunnelDevicePolicy.isEnabled());
                                        jsonGenerator.writeEndObject();
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("egressPorts");
                            if (flow.getEgressPorts() != null) {
                                flow.getEgressPorts().forEach(port -> {
                                    try {
                                        jsonGenerator.writeObject(port);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("egressPortGroups");
                            if (flow.getEgressPortGroups() != null) {
                                flow.getEgressPortGroups().forEach(portGroup -> {
                                    try {
                                        jsonGenerator.writeStartObject();
                                        if (portGroup.getId() == null) {
                                            jsonGenerator.writeNullField("id");
                                        } else {
                                            jsonGenerator.writeNumberField("id", portGroup.getId());
                                        }
                                        jsonGenerator.writeStringField("name", portGroup.getName());
                                        jsonGenerator.writeObjectFieldStart("primaryPort");
                                        jsonGenerator.writeNumberField("id", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getId() : -1);
                                        jsonGenerator.writeStringField("name", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getName() : "");
                                        jsonGenerator.writeEndObject();
                                        jsonGenerator.writeEndObject();
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("flowEgressManagedObjects");
                            if (flow.getFlowEgressPorts() != null) {
                                flow.getFlowEgressPorts().forEach(flowEgressManagedObject -> {
                                    try {
                                        jsonGenerator.writeObject(flowEgressManagedObject);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            if (flow.getFlowEgressPortGroups() != null) {
                                flow.getFlowEgressPortGroups().forEach(flowEgressManagedObject -> {
                                    try {
                                        jsonGenerator.writeObject(flowEgressManagedObject);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("ingressPorts");
                            if (flow.getIngressPorts() != null) {
                                flow.getIngressPorts().forEach(port -> {
                                    try {
                                        jsonGenerator.writeObject(port);
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();

                            jsonGenerator.writeArrayFieldStart("ingressPortGroups");
                            if (flow.getIngressPortGroups() != null) {
                                flow.getIngressPortGroups().forEach(portGroup -> {
                                    try {
                                        jsonGenerator.writeStartObject();
                                        if (portGroup.getId() == null) {
                                            jsonGenerator.writeNullField("id");
                                        } else {
                                            jsonGenerator.writeNumberField("id", portGroup.getId());
                                        }
                                        jsonGenerator.writeStringField("name", portGroup.getName());
                                        jsonGenerator.writeObjectFieldStart("primaryPort");
                                        jsonGenerator.writeNumberField("id", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getId() : -1);
                                        jsonGenerator.writeStringField("name", portGroup.getPrimaryPort() != null ? portGroup.getPrimaryPort().getName() : "");
                                        jsonGenerator.writeEndObject();
                                        //all ingress ports in service port group
                                        jsonGenerator.writeArrayFieldStart("ports");
                                        if (portGroup.getPorts() != null) {
                                            portGroup.getPorts().forEach(port -> {
                                                try {
                                                    jsonGenerator.writeStartObject();
                                                    if (port.getId() == null) {
                                                        jsonGenerator.writeNullField("id");
                                                    } else {
                                                        jsonGenerator.writeNumberField("id", port.getId());
                                                    }
                                                    jsonGenerator.writeStringField("name", port.getName());
                                                    jsonGenerator.writeEndObject();
                                                } catch (IOException iex) {
                                                    throw new ServerException(iex);
                                                }
                                            });
                                        }
                                        jsonGenerator.writeEndArray();
                                        jsonGenerator.writeEndObject();
                                    } catch (IOException e) {
                                        throw new ServerException(e);
                                    }
                                });
                            }
                            jsonGenerator.writeEndArray();
                            jsonGenerator.writeBooleanField("tagged", flow.getIsTagged());
                            jsonGenerator.writeBooleanField("tvfDomain", flow.getTvfDomain());
                            jsonGenerator.writeBooleanField("vlanStripping", flow.getVlanStripping());
                            if (flow.getIsDefaultRouteMapDrop() != null) {
                                jsonGenerator.writeBooleanField("defaultRouteMapDrop", flow.getIsDefaultRouteMapDrop());
                            }
                            if (flow.getTaggedVlanId() == null) {
                                jsonGenerator.writeNullField("taggedVlanId");
                            } else {
                                jsonGenerator.writeNumberField("taggedVlanId", flow.getTaggedVlanId());
                            }
                            if (flow.getPacketTruncationMapping() != null) {
                                jsonGenerator.writeObjectFieldStart("packetTruncationMapping");
                                if (flow.getPacketTruncationMapping().getId() != null) {
                                    jsonGenerator.writeNumberField("id", flow.getPacketTruncationMapping().getId());
                                } else {
                                    jsonGenerator.writeNullField("id");
                                }
                                jsonGenerator.writeEndObject();
                            }
                            jsonGenerator.writeEndObject();
                        } catch (IOException e) {
                            throw new ServerException(e);
                        }
                    });
                }
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }

}
