package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PacketSlicingModulePolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "packet_slicing_module_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class PacketSlicingModulePolicy extends ModulePolicy implements HasHistory {

    public static final Integer TRUNCATION_SIZE_MIN = 64;
    public static final Integer TRUNCATION_SIZE_MAX = 9198;

    @Column(name = "number_of_bytes")
    @Setter
    private Integer numberOfBytes;

    @JsonIgnore
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "packet_slicing_port_mapping",
            joinColumns = {@JoinColumn(name = "module_policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "managed_object_id", referencedColumnName = "id")})
    private Set<Port> ports = new HashSet<>();

    public void removePorts(Set<Port> ports) {
        this.ports.removeAll(ports);
    }

    public void addPorts(Set<Port> ports) {
        this.ports.addAll(ports);
    }

    @JsonProperty
    public void setPorts(Set<Port> ports) {
        this.ports.clear();
        this.ports.addAll(ports);
    }

    @Override
    public HistoryObject buildHistory() {
        PacketSlicingModulePolicyHistory policyHistory = new PacketSlicingModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(PacketSlicingModulePolicy.class, new PacketSlicingModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the PacketSlicingModulePolicy Object in History", e);
        }
        return policyHistory;
    }


    private class PacketSlicingModulePolicyJsonSerializer extends JsonSerializer<PacketSlicingModulePolicy> {
        @Override
        public void serialize(PacketSlicingModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                jsonGenerator.writeNumberField("numberOfBytes", policy.getNumberOfBytes());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();

                jsonGenerator.writeArrayFieldStart("ports");
                policy.getPorts().forEach(port -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", port.getId().longValue());
                        jsonGenerator.writeStringField("name", port.getName());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }
}

