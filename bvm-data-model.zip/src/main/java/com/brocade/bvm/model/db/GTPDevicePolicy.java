package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.GTPDevicePolicyHistory;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.IOException;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "gtp_device_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class GTPDevicePolicy extends DevicePolicy implements HasHistory {

    public static final Integer ID_MIN = 1;
    public static final Integer ID_MAX = 16;

    @Column(name = "profile_id")
    @JsonProperty
    private Long profileId;

    @Column(name = "description")
    @JsonProperty
    @org.hibernate.annotations.Type(type = "text")
    private String description;

    @Column(name = "is_gtpc_teid_enabled")
    private boolean isGTPCTeIdEnabled;

    @Column(name = "is_gtpu_l3_enabled")
    private boolean isGTPUInnerL3Enabled;

    @Column(name = "is_gtpu_teid_enabled")
    private boolean isGTPUTeIdEnabled;

    @Override
    public HistoryObject buildHistory() {
        GTPDevicePolicyHistory policyHistory = new GTPDevicePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(GTPDevicePolicy.class, new GTPDevicePolicy.GTPDevicePolicyJsonSerializer());
        policyHistory.setDevice(this.getDevice());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setDevicePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the Policy Object in History", e);
        }
        return policyHistory;
    }

    private class GTPDevicePolicyJsonSerializer extends JsonSerializer<GTPDevicePolicy> {
        @Override
        public void serialize(GTPDevicePolicy devicePolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", devicePolicy.getId().longValue());
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                if (devicePolicy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", devicePolicy.getWorkflowStatus().name());
                }
                if (devicePolicy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", devicePolicy.getWorkflowType().name());
                }
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", devicePolicy.getDevice().getId());
                jsonGenerator.writeEndObject();
                jsonGenerator.writeNumberField("profileId", devicePolicy.getProfileId().intValue());
                jsonGenerator.writeBooleanField("gtpcteIdEnabled", isGTPCTeIdEnabled);
                jsonGenerator.writeBooleanField("gtpuinnerL3Enabled", isGTPUInnerL3Enabled);
                jsonGenerator.writeBooleanField("gtputeIdEnabled", isGTPUTeIdEnabled);
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
