package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.SlxPtpPolicyHistory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.IOException;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "slx_ptp_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class SlxPtpPolicy extends DevicePolicy implements HasHistory {
    @Column(name = "is_enabled")
    private boolean enabled;


    @Override
    public HistoryObject buildHistory() {
        SlxPtpPolicyHistory policyHistory = new SlxPtpPolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(SlxPtpPolicy.class, new SlxPtpPolicy.SlxPtpPolicyJsonSerializer());
        policyHistory.setDevice(this.getDevice());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setDevicePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialized the Policy Object in History", e);
        }
        return policyHistory;
    }

    private class SlxPtpPolicyJsonSerializer extends JsonSerializer<SlxPtpPolicy> {
        @Override
        public void serialize(SlxPtpPolicy devicePolicy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", devicePolicy.getId().longValue());
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                if (devicePolicy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", devicePolicy.getWorkflowStatus().name());
                }
                if (devicePolicy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", devicePolicy.getWorkflowType().name());
                }
                jsonGenerator.writeObjectFieldStart("device");
                jsonGenerator.writeNumberField("id", devicePolicy.getDevice().getId());
                jsonGenerator.writeEndObject();
                jsonGenerator.writeStringField("name", devicePolicy.getName());
                jsonGenerator.writeBooleanField("enabled", devicePolicy.isEnabled());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
            }
        }
    }
}
