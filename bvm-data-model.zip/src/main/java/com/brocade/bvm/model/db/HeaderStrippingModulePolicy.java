package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HeaderStrippingModulePolicyHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Getter
@NoArgsConstructor
@Entity(name = "header_stripping_module_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class HeaderStrippingModulePolicy extends ModulePolicy implements HasHistory {

    public static final Integer VLAN_MIN_VALUE = 1;

    public static final Integer VLAN_MAX_VALUE = 4090;

    public enum Headers {
        BR802,
        VNTAG,
        VXLAN,
        NVGRE,
        GTP_DE_ENCAPSULATION,
        MPLS,
        ERSPAN,
        ALL
    }

    @Setter
    @ElementCollection(targetClass = Headers.class, fetch = FetchType.EAGER)
    @Enumerated(EnumType.STRING)
    @Column(name = "strip_header")
    @CollectionTable(name = "header_strip_mapping", joinColumns = @JoinColumn(name = "header_strip_id"))
    private Set<Headers> stripHeaders;

    @Setter
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    private Device device;

    @Setter
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "header_strip_port_mapping",
            joinColumns = {@JoinColumn(name = "module_policy_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "port_id", referencedColumnName = "id")})
    private Set<Port> ports = new HashSet<>();

    @Column(name = "processor_number")
    @Setter
    @Enumerated(EnumType.STRING)
    private HeaderStrippingModulePolicy.ProcessorNumber processor;

    public enum ProcessorNumber {
        ALL("0"),
        ONE("1"),
        TWO("2");

        private String processorNumber;

        ProcessorNumber(String number) {
            this.processorNumber = number;
        }

        public String getProcessorNumber() {
            return this.processorNumber;
        }
    }

    @Setter
    @Column(name = "is_preserve")
    @JsonProperty(value = "preserve")
    private boolean isPreserve;

    @Setter
    @Column(name = "intermediate_vlan")
    private Integer intermediateVlan = 0;

    @Setter
    @Transient
    private ManagedObject intermediatePort;

    @Setter
    @Column(name = "intermediate_port_id")
    private Long intermediatePortId;

    @Setter
    @Column(name = "replace_vlan")
    private Integer replaceVlan = 0;

    @Override
    public HistoryObject buildHistory() {
        HeaderStrippingModulePolicyHistory policyHistory = new HeaderStrippingModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(HeaderStrippingModulePolicy.class, new HeaderStrippingModulePolicy.HeaderStrippingModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the HeaderStrippingModulePolicyHistory in History", e);
        }
        return policyHistory;
    }


    private class HeaderStrippingModulePolicyJsonSerializer extends JsonSerializer<HeaderStrippingModulePolicy> {
        @Override
        public void serialize(HeaderStrippingModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeStringField("processor", String.valueOf(getProcessor().getProcessorNumber()));
                jsonGenerator.writeObjectField("stripHeaders", policy.getStripHeaders());
                jsonGenerator.writeBooleanField("preserve", isPreserve());
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeArrayFieldStart("ports");
                policy.getPorts().forEach(port -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", port.getId().longValue());
                        jsonGenerator.writeStringField("name", port.getName());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeNumberField("intermediateVlan", policy.getIntermediateVlan().intValue());

                if (policy.getIntermediatePortId() == null) {
                    jsonGenerator.writeNullField("intermediatePortId");
                } else {
                    jsonGenerator.writeNumberField("intermediatePortId", policy.getIntermediatePortId());
                }
                jsonGenerator.writeNumberField("replaceVlan", policy.getReplaceVlan().intValue());
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }
        }
    }
}
