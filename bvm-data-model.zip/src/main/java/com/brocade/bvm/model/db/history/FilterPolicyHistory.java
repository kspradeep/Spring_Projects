package com.brocade.bvm.model.db.history;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Slf4j
@Entity(name = "filter_policy_history")
public class FilterPolicyHistory extends HistoryObject {

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "device_id", referencedColumnName = "id")
    @Setter
    private Device device;

    @Setter
    @Lob
    @Column(name = "policy_json")
    private String policyJson;

    public FilterPolicy buildParent() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        FilterPolicy filterPolicy = null;
        try {
            filterPolicy = mapper.readValue(policyJson, FilterPolicy.class);
            //filterPolicy.setDevice(device);
        } catch (Exception e) {
            throw new ServerException("Failed to construct the FilterPolicyHistory", e);
        }
        return filterPolicy;
    }
}
