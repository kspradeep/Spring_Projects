package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.annotations.Polymorphism;
import org.hibernate.annotations.PolymorphismType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.IOException;

@Getter
@NoArgsConstructor
@Entity(name = "slx_load_balance_module_policy")
@Polymorphism(type = PolymorphismType.EXPLICIT)
@Slf4j
public class SlxLoadBalanceModulePolicy extends ModulePolicy implements HasHistory {

    /* Selected load balancing Policy*/
    @Column(name = "applied_load_balance_policy")
    @Setter
    @JsonProperty
    @Enumerated(EnumType.STRING)
    private LoadBalancePolicy selectedLoadBalancePolicy;

    @Override
    public HistoryObject buildHistory() {
        LoadBalanceModulePolicyHistory policyHistory = new LoadBalanceModulePolicyHistory();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(SlxLoadBalanceModulePolicy.class, new SlxLoadBalanceModulePolicy.SlxLoadBalanceModulePolicyJsonSerializer());
        policyHistory.setName(this.getName());
        policyHistory.setWorkflowType(this.getWorkflowType());
        policyHistory.setWorkflowStatus(this.getWorkflowStatus());
        mapper.registerModule(simpleModule);
        try {
            policyHistory.setModulePolicyJson(mapper.writeValueAsString(this));
        } catch (JsonProcessingException e) {
            throw new ServerException("Failed to serialized the Policy Object in History", e);
        }
        return policyHistory;
    }


    private class SlxLoadBalanceModulePolicyJsonSerializer extends JsonSerializer<SlxLoadBalanceModulePolicy> {
        @Override
        public void serialize(SlxLoadBalanceModulePolicy policy, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                jsonGenerator.writeStartObject();
                jsonGenerator.writeNumberField("id", policy.getId().longValue());
                jsonGenerator.writeStringField("name", policy.getName());
                if (policy.getWorkflowStatus() != null) {
                    jsonGenerator.writeStringField("workflowStatus", policy.getWorkflowStatus().name());
                }
                if (policy.getWorkflowType() != null) {
                    jsonGenerator.writeStringField("workflowType", policy.getWorkflowType().name());
                }
                jsonGenerator.writeObjectField("selectedLoadBalancePolicy", selectedLoadBalancePolicy);
                jsonGenerator.writeArrayFieldStart("modules");
                policy.getModules().forEach(module -> {
                    try {
                        jsonGenerator.writeStartObject();
                        jsonGenerator.writeNumberField("id", module.getId().longValue());
                        jsonGenerator.writeNumberField("moduleNumber", module.getModuleNumber().longValue());
                        jsonGenerator.writeEndObject();
                    } catch (Exception e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeEndObject();
            } catch (IOException e) {
                throw new ServerException(e);
            }

        }
    }

    public enum LoadBalancePolicy {
        DST_MAC_VID("dst-mac-vid"),
        SRC_DST_IP("src-dst-ip"),
        SRC_DST_IP_MAC_VID("src-dst-ip-mac-vid"),
        SRC_DST_IP_MAC_VID_PORT("src-dst-ip-mac-vid-port"),
        SRC_DST_IP_PORT("src-dst-ip-port"),
        SRC_DST_MAC_VID("src-dst-mac-vid"),
        SRC_MAC_VID("src-mac-vid");

        private String loadBalancePolicy;

        LoadBalancePolicy(String selectedPolicy) {
            this.loadBalancePolicy = selectedPolicy;
        }

        public String getloadBalancePolicy() {
            return this.loadBalancePolicy;
        }
    }
}
