package com.brocade.bvm.model.db;

import static org.assertj.core.api.StrictAssertions.assertThat;

import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class PolicyTest {

	private Policy policy = null;

	private SortedSet<Flow> flows = new TreeSet<>();

	@Before
	public void setUp() throws Exception {
		policy = new Policy();
	}

	@Test
	public void testGetComputedNameWithOneIngressPort() {
		flows.clear();
		Flow flow = new Flow();

		Set<Port> ingressPortsAndPorts = new HashSet<>();
		Port ingressPort1 = new Port();
		ingressPort1.setName("10GigabitEthernet5/2");
		ingressPortsAndPorts.add(ingressPort1);

		flow.addIngressPorts(ingressPortsAndPorts);
		flow.setSequence(1);
		flows.add(flow);

		ReflectionTestUtils.setField(policy, "flows", flows);
		ReflectionTestUtils.setField(policy, "id", 5L);
		assertThat(policy.getComputedName()).isEqualTo("rm_5");
	}

	private void replacePolicyName(Policy policyToSave, Long policySetId){
		policyToSave.getFlows().forEach(flow -> {
			flow.getRuleSets().forEach(ruleSet -> {
				String aclName = ruleSet.getName();
				aclName = aclName.replace("_null_", "_" + policySetId + "_");
				ruleSet.setName(aclName);
			});
		});
	}

	@Test
	public void testGetComputedNameWithMultipleIngressPorts() {
		flows.clear();
		Flow flow = new Flow();
		flow.setSequence(1);
		Set<Port> ingressPortsAndPorts = new HashSet<>();
		Port ingressPort1 = new Port();
		ingressPort1.setName("10GigabitEthernet5/4");
		Port ingressPort2 = new Port();
		ingressPort2.setName("10GigabitEthernet5/1");
		ingressPortsAndPorts.add(ingressPort1);
		ingressPortsAndPorts.add(ingressPort2);

		flow.addIngressPorts(ingressPortsAndPorts);
		flows.add(flow);

		ReflectionTestUtils.setField(policy, "flows", flows);
		ReflectionTestUtils.setField(policy, "id", 5L);

		assertThat(policy.getComputedName()).isEqualTo("rm_5");
	}

	@Test
	public void testGetComputedNameWithPortsAndPrimaryPort() {
		flows.clear();
		Flow flow = new Flow();
		flow.setSequence(1);
		Set<Port> ingressPortsAndPorts = new HashSet<>();
		Port ingressPort1 = new Port();
		ingressPort1.setName("10GigabitEthernet5/7");
		Port ingressPort2 = new Port();
		ingressPort2.setName("10GigabitEthernet5/4");
		ingressPortsAndPorts.add(ingressPort1);
		ingressPortsAndPorts.add(ingressPort2);

		Set<PortGroup> ingressPortsAndPortGroups = new HashSet<>();
		PortGroup ingressPortGroup = new PortGroup();
		Port primaryPort = new Port();
		primaryPort.setName("10GigabitEthernet5/2");
		ingressPortGroup.setPrimaryPort(primaryPort);
		ingressPortsAndPortGroups.add(ingressPortGroup);

		flow.addIngressPorts(ingressPortsAndPorts);
		flow.addIngressPortGroups(ingressPortsAndPortGroups);

		flows.add(flow);

		ReflectionTestUtils.setField(policy, "flows", flows);
		ReflectionTestUtils.setField(policy, "id", 5L);
		assertThat(policy.getComputedName()).isEqualTo("rm_5");
	}
}
