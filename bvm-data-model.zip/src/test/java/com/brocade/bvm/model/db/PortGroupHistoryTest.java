package com.brocade.bvm.model.db;

import com.brocade.bvm.model.db.history.PortGroupHistory;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

public class PortGroupHistoryTest {

    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void buildParentTest(){
        String portGroupJson = " {\"name\":\"spg1\",\"primaryPort\":{\"name\":\"10GigabitEthernet1/1\"}," +
                "\"ports\":[{\"id\":7,\"name\":\"10GigabitEthernet1/2\",\"adminStatus\":\"ENABLED\",\"discoveredAdminStatus\":\"DISABLED\"}," +
                "{\"id\":16,\"name\":\"10GigabitEthernet1/1\",\"adminStatus\":\"ENABLED\",\"discoveredAdminStatus\":\"DISABLED\"}]}";
        PortGroupHistory history = new PortGroupHistory();
        history.setPortGroupJson(portGroupJson);
        PortGroup portGroupFromHistory = history.buildParent();
        Assertions.assertThat(portGroupFromHistory).isNotNull();
        Assertions.assertThat(portGroupFromHistory.getPorts().size()).isEqualTo(2);
    }
}
