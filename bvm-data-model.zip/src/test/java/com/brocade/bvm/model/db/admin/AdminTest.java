package com.brocade.bvm.model.db.admin;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class AdminTest {

    @Test
    public void testConfigPasswordEncryption() {
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setKey(ApplicationConfig.Key.StablenetPassword);
        applicationConfig.setValue("test@123");

        String encryptedValue = (String) ReflectionTestUtils.getField(applicationConfig, "value");
        System.out.println(encryptedValue);
        Assertions.assertThat(encryptedValue).isNotNull();
        Assertions.assertThat(encryptedValue).isNotEqualTo("test@123");

        String decryptedValue = applicationConfig.getValue();
        System.out.println(decryptedValue);
        Assertions.assertThat(decryptedValue).isEqualTo("test@123");
    }

    @Test
    public void testUserPasswordEncryption() {
        ApplicationUser user = new ApplicationUser();
        user.setPassword("password@123");
        Assertions.assertThat(ReflectionTestUtils.getField(user, "password")).isNotEqualTo("password@123");
        Assertions.assertThat(user.isPasswordEqualTo("password@123")).isTrue();
        Assertions.assertThat(user.isPasswordEqualTo("password@1234")).isFalse();
    }
}