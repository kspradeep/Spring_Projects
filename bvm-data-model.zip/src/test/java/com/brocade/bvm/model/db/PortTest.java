package com.brocade.bvm.model.db;

import com.brocade.bvm.model.WorkflowParticipant;
import com.google.common.collect.Sets;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;


public class PortTest {

    private Port port;
    private Device device;

    private Instant instantNow = Instant.now();
    private Instant instantLater = instantNow.plusSeconds(30);

    @Before
    public void setup() {
        this.device = new Device();
        device.setLastCollectedTime(instantNow);
        Module module = new Module();
        device.addModules(Sets.newHashSet(module));
        port = new Port();
        port.setName("ethernet1/1");
        port.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        module.addPorts(Sets.newHashSet(port));
    }

    @Test
    public void testAdminStatusUpdate() {
        //After collector run
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);

        //User updated adminStatus to disabled
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        port.setWorkflowType(Job.Type.PORT_DISABLE);
        port.setBvmDefinedLastUpdatedTime(instantLater);
        port.setAdminStatus(Port.AdminStatus.DISABLED);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.DISABLED);

        //Collector ran again - Looks like stablenet doesnt have wwhat we applied!
        device.setLastCollectedTime(instantLater);
        port.setBvmDefinedLastUpdatedTime(instantNow);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);
    }

    @Test
    public void testAdminStatusUpdateFailedAndRetry() {
        //User updated stauts to disabled, job failed
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
        port.setWorkflowType(Job.Type.PORT_DISABLE);
        device.setLastCollectedTime(instantNow);
        port.setBvmDefinedLastUpdatedTime(instantLater);
        port.setAdminStatus(Port.AdminStatus.DISABLED);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);

        //User retried job
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        port.setWorkflowType(Job.Type.PORT_DISABLE);
        device.setLastCollectedTime(instantNow);
        port.setBvmDefinedLastUpdatedTime(instantLater);
        port.setAdminStatus(Port.AdminStatus.DISABLED);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.DISABLED);

        //Collector reran, stablenet discovered
        device.setLastCollectedTime(instantLater);
        port.setDiscoveredAdminStatus(Port.AdminStatus.DISABLED);
        port.setBvmDefinedLastUpdatedTime(instantNow);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.DISABLED);
    }

    @Test
    public void testAdminStatusWhenTypeChanges() {
        //After collector run
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);

        //User updated type and job succeeds
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        port.setWorkflowType(Job.Type.PORT_MARK_EGRESS);
        port.setType(Port.Type.EGRESS);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);
    }

    @Test
    public void testAdminStatusWhenTypeChangesFails() {
        //After collector run
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.ENABLED);

        //User updated adminStatus to disabled
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        port.setWorkflowType(Job.Type.PORT_DISABLE);
        port.setBvmDefinedLastUpdatedTime(instantLater);
        port.setAdminStatus(Port.AdminStatus.DISABLED);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.DISABLED);

        //User updated type and job fails
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
        port.setWorkflowType(Job.Type.PORT_MARK_EGRESS);
        port.setType(Port.Type.EGRESS);
        assertThat(port.getAdminStatus()).isEqualTo(Port.AdminStatus.DISABLED);
    }

    @Test
    public void testPortNumber() {
        assertThat(port.getPortNumber()).isEqualTo("1/1");

        port.setName("ethernet1/2");
        assertThat(port.getPortNumber()).isEqualTo("1/2");

        port.setName("1/1/1");
        assertThat(port.getPortNumber()).isEqualTo("");
    }

}