package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PortGroupRecoveryCommandList;
import com.google.common.collect.Lists;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetPortGroupDeleteJobExecutor class implements methods to recover failed portGroup on Non Open Flow device through Stablenet
 */
@Named
public class StablenetPortGroupRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.PORT_GROUP_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method constructs portGroup recovery commands to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    public List<CommandBlock> getCommands(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        PortGroupRecoveryCommandList recoveryCommandList = new PortGroupRecoveryCommandList();
        List<CommandBlock> commandBlocks = recoveryCommandList.constructCommandBlockList(portGroup);
        return commandBlocks;
    }
}
