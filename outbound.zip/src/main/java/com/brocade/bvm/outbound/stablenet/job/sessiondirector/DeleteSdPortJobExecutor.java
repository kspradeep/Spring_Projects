package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Named
public class DeleteSdPortJobExecutor extends AbstractSdPortJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_EGRESS_PORT_DELETE);
    }

    /**
     * This method builds commands to delete Egress Port
     *
     * @param job
     * @return
     */
    @Override
    public String getCommands(Job job) {
        Set<EgressPort> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof EgressPort)
                .map(mo -> (EgressPort) mo)
                .collect(Collectors.toSet());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(buildDeleteCommand(ports));
        command.append(EXIT);
        log.info("Stablenet command generated from Job Id{} on device{} for deleting SD Egress Port is {}", job.getId(), job.getDevice().getId(), command);
        return command.toString();
    }
}