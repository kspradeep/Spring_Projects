package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class is used for handling Delete Interface request
 */
@Slf4j
@Named
public class DeleteActiveInterfaceJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_ACTIVE_INTERFACE_DELETE);
    }

    @Override
    public String getCommands(Job job) {
        List<ActiveInterface> activeInterfaces = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof ActiveInterface)
                .map(mo -> (ActiveInterface) mo)
                .collect(Collectors.toList());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(INTERFACE);
        activeInterfaces.forEach(activeInterface -> {
            command.append(String.format(EDIT_INTERFACE, activeInterface.getProfileInterfaceMapping().getName()));
            if (activeInterface.getPortGroup() != null) {
                command.append(CLEAR).append(CPG).append(END);
            }
            if (activeInterface.getReplicatePortGroup() != null) {
                command.append(CLEAR).append(RPG).append(END);
            }
            if (activeInterface.getSamplingPolicy() != null) {
                command.append(CLEAR).append(SP).append(END);
            }
            if (activeInterface.getDeDupePolicy() != null) {
                command.append(CLEAR).append(DP).append(END);
            }
            if (activeInterface.getFilterPolicy() != null) {
                command.append(CLEAR).append(FP).append(END);
            }
            command.append(RETURN);
        });
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
