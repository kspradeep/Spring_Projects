package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PacketStampingModulePolicy;

/**
 * The AbstractPacketStampingModulePolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE of PacketStampingModulePolicy on Non Open Flow device through Stablenet
 */
public abstract class AbstractPacketStampingModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String END = "end;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String MODULE_POLICY_EGRESS_PACKET_TIME_STAMPING_FORMAT = "packet-timestamp slot %s %s;";

    protected static final String MODULE_POLICY_REVERT_EGRESS_PACKET_TIME_STAMPING_FORMAT = "no packet-timestamp slot %s %s;";

    private static final String DEVICE_ID = "device-id ";

    /**
     * This method returns processorNumber value to be applied on the device based on device OS and processor number
     *
     * @param device
     * @param modulePolicy
     * @return String returns processorVal
     */
    protected String getProcessor(Device device, PacketStampingModulePolicy modulePolicy) {
        String processorVal = modulePolicy.getProcessor().getProcessorNumber();
        if (PacketStampingModulePolicy.ProcessorNumber.ALL == modulePolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = isOsVersion6(device) ? DEVICE_ID + processorVal : processorVal;
        }
        return processorVal;
    }

    /**
     * This method checks if the given device OS version is above 6
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        int osMajorVersion = device.getOsMajorVersion();
        return osMajorVersion >= MLXE_OS_MAJOR_VERSION;
    }
}
