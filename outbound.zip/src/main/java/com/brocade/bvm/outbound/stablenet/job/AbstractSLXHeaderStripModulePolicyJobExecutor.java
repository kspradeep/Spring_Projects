package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Named
@Slf4j
public abstract class AbstractSLXHeaderStripModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String SLX_CEDER_OS_VERSION = "ceder";
    protected static final String SLX_FREEDOM_OS_VERSION = "freedom";

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String END = "end;";

    protected static final String EXIT = "exit;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String NO = "no ";

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String STRIP_802_1_BR = "strip-802-1br;";

    protected static final String STRIP_VN_TAG = "strip-vn-tag;";

    protected static final String ALLOW_VN_TAG = "allow-vn-tag;";

    protected static final String STRIP_VXLAN = "strip-vxlan;";

    protected static final String STRIP_ERSPAN = "strip-erspan;";

    protected static final String STRIP_NVGRE = "strip-nvgre;";

    protected static final String STRIP_MPLS = "strip-mpls;";

    protected static final String STRIP_GTP_DE_ENCAPSULATION = "gtp-de-encapsulation;";

    protected static final String ALL = "all";

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method builds create commands to be applied on the device
     *
     * @param ports
     * @param header
     * @return String
     */
    protected String buildCreateCommand(Set<Port> ports, HeaderStrippingModulePolicy.Headers header) {
        StringBuilder command = new StringBuilder();
        ports.forEach(port -> {
            command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                command.append(STRIP_802_1_BR);
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                command.append(ALLOW_VN_TAG);
                command.append(STRIP_VN_TAG);
            } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
                command.append(STRIP_VXLAN);
            } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
                command.append(STRIP_NVGRE);
            } else if (HeaderStrippingModulePolicy.Headers.ERSPAN == header) {
                command.append(STRIP_ERSPAN);
            } else if (HeaderStrippingModulePolicy.Headers.MPLS == header) {
                command.append(STRIP_MPLS);
            } else if (HeaderStrippingModulePolicy.Headers.GTP_DE_ENCAPSULATION == header) {
                command.append(STRIP_GTP_DE_ENCAPSULATION);
            }
            command.append(EXIT);
        });
        return command.toString();
    }

    /**
     * This method builds delete commands to be applied on the device
     *
     * @param ports
     * @param header
     * @return String
     */
    protected String buildDeleteCommand(Set<Port> ports, HeaderStrippingModulePolicy.Headers header) {
        StringBuilder command = new StringBuilder();
        ports.forEach(port -> {
            command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                command.append(NO).append(STRIP_802_1_BR);
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                command.append(NO).append(STRIP_VN_TAG);
                command.append(NO).append(ALLOW_VN_TAG);
            } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
                command.append(NO).append(STRIP_VXLAN);
            } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
                command.append(NO).append(STRIP_NVGRE);
            } else if (HeaderStrippingModulePolicy.Headers.ERSPAN == header) {
                command.append(NO).append(STRIP_ERSPAN);
            } else if (HeaderStrippingModulePolicy.Headers.MPLS == header) {
                command.append(NO).append(STRIP_MPLS);
            } else if (HeaderStrippingModulePolicy.Headers.GTP_DE_ENCAPSULATION == header) {
                command.append(NO).append(STRIP_GTP_DE_ENCAPSULATION);
            }
            command.append(EXIT);
        });
        return command.toString();
    }

    /**
     * This method checks if the given device OS version is above 6
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        String osMajorVersion = device.getOs();
        return osMajorVersion == SLX_CEDER_OS_VERSION || osMajorVersion == SLX_FREEDOM_OS_VERSION;
    }

    private ManagedObject getManagedObject(Long intermediatePortId) {
        Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
        List<Long> ids = new ArrayList<>();
        ids.add(intermediatePortId);
        query.setParameter("ids", ids);
        return (ManagedObject) query.getSingleResult();
    }
}
