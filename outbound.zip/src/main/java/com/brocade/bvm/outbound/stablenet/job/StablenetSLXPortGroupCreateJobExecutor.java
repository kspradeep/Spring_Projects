package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class StablenetSLXPortGroupCreateJobExecutor extends AbstractStablenetSLXPortGroupJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_GROUP_CREATE, Job.Type.PORT_CHANNEL_CREATE);
    }

    /**
     * This method constructs portGroup update commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        log.trace("SLX Port Group create input: {}", portGroup);
        StringBuilder command = new StringBuilder();

        if (portGroup != null) {
            command.append(CONFIGURE_TERMINAL);
            command.append(createPortGroup(portGroup));
            command.append(EXIT);
        }
        log.debug("SLX Port Group create command: {}", command);
        return command.toString();
    }
}
