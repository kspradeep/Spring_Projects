package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.GTPDevicePolicy;
import com.brocade.bvm.model.db.Job;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetGtpDevicePolicyDeleteJobExecutor class implements methods to delete GTPDevicePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetGtpDevicePolicyDeleteJobExecutor extends AbstractGtpDevicePolicyJobExecutor {

    /**
     * This method constructs delete GTPDevicePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        GTPDevicePolicy gtpDevicePolicy = (GTPDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        if (gtpDevicePolicy != null) {
            command.append(CONFIGURE_TERMINAL);
            command.append(buildDeleteCommand(gtpDevicePolicy));
            command.append(WRITE_MEMORY);
        } else {
            log.error("GTP Profile entity is null!");
        }
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_PROFILE_DELETE);
    }
}
