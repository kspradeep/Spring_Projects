package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SLXHeaderStrippingCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class SLXHeaderStripModulePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_SLX_ROLLBACK);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method constructs headerStripping module policy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        HeaderStrippingModulePolicy headerStrippingModulePolicy = (HeaderStrippingModulePolicy) getParentObject(job);
        log.debug("HeaderStrippingModulePolicyRecovery Job executor for policy id {}", headerStrippingModulePolicy.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(headerStrippingModulePolicy);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", headerStrippingModulePolicy.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs headerStripping module policy recovery command blocks for the given policy
     *
     * @param headerStrippingModulePolicy
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(HeaderStrippingModulePolicy headerStrippingModulePolicy) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        headerStrippingModulePolicy.getPorts().forEach(port -> {
            Device device = headerStrippingModulePolicy.getDevice();
            headerStrippingModulePolicy.getStripHeaders().forEach(header -> {
                finalCommandBlocks.add(constructModuleCommandBlockForOs6(port, header, device));
            });
        });

        return finalCommandBlocks;
    }


    private SLXHeaderStrippingCommandBlock constructModuleCommandBlockForOs6(Port port, HeaderStrippingModulePolicy.Headers header, Device device) {
        SLXHeaderStrippingCommandBlock headerStrippingCommandBlock = new SLXHeaderStrippingCommandBlock();
        headerStrippingCommandBlock.setDeviceId(device.getStablenetId().intValue());
        headerStrippingCommandBlock.setHeader(header);
        headerStrippingCommandBlock.setPortNo(port.getPortNumber());
        return headerStrippingCommandBlock;
    }

}
