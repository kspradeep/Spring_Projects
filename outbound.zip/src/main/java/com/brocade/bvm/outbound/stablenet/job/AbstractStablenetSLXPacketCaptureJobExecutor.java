package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.db.Device;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public abstract class AbstractStablenetSLXPacketCaptureJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String PACKET_CAPTURE_WITH_PACKET_COUNT = "capture packet interface ethernet %s direction %s filter %s packet-count %s;";

    protected static final String PACKET_CAPTURE_WITH_OUT_PACKET_COUNT = "capture packet interface ethernet %s direction %s filter %s;";

    protected static final String NO_PACKET_CAPTURE = "no capture packet interface all;";

    @Inject
    protected PortRepository portRepository;

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
