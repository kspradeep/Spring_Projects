package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.RuleSetRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.TargetHost.Mode;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.model.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXB;
import java.io.StringReader;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
@Named
public abstract class AbstractStablenetRecoveryJobExecutor extends BaseOutboundJobExecutor {

    @Inject
    private StablenetAdminConnection stablenetConnection;

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String userGroupsUrl;

    @Value("${stablenet.resource-url.jobs.deploy}")
    private String jobDeployUrl;

    @Value("${stablenet.resource-url.jobs.start}")
    private String jobStartUrl;

    @Value("${stablenet.resource-url.jobs.isrunning}")
    private String jobStatusUrl;

    @Value("${stablenet.resource-url.jobs.jobresult}")
    private String jobResultUrl;

    @Value("${stablenet.resource-url.jobs.jobresultlist}")
    private String jobResultListUrl;

    @Value("${stablenet.resource-url.jobs.jobresultdevice}")
    private String jobResultDeviceUrl;

    @Value("${stablenet-response.timeout.minutes}")
    private int timeoutMinutes;

    private List<Map.Entry<Integer, Integer>> sleepTimeouts = Lists.newArrayList();

    protected static final int MLXE_OS_MAJOR_VERSION = 6;

    @PostConstruct
    public void intilizeExecutorTimeouts() {
        sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(5, 5 * 60 * 1000));//5 secs poll for first 5 mins(5*60*1000 ms)
        if (timeoutMinutes > 5) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(30, 30 * 60 * 1000)); //30 secs poll for the next 30 mins
        }
        if (timeoutMinutes > 30) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(60, timeoutMinutes * 60 * 1000)); //60 secs poll for the rest till timeoutMinutes
        }
    }

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @Override
    public Mode getSupportedMode() {
        return Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE);
    }

    @Override
    public Long startExternalJob(Job job) {
        return null;
    }

    @Override
    public OutboundJobResponse execute(Job job) {
        //Put request and get stablenet's job id (this is a clone id of parent template job)
        log.debug("Starting Stablnet job for jobId {}", job.getId());
        OutboundJobResponse jobResponse = null;

        UserVO user = null;
        if (!Strings.isNullOrEmpty(job.getCreatedByUser()) && job.getDevice().isAuthenticationConfigured()) {
            user = JAXB.unmarshal(
                    new StringReader(stablenetConnection.get(userGroupsUrl, job.getCreatedByUser()).readEntity(String.class)),
                    UserVO.class);
        }
        ApplicationConfig applicationConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetDeleteJobId);
        String stablenetDeleteJobId = null;
        if (applicationConfig != null && applicationConfig.getValue() != null) {
            stablenetDeleteJobId = applicationConfig.getValue();
        } else {
            log.error("StableNet job ID is not configured!");
            throw new OutboundApiException("StableNet job ID is not configured!");
        }
        CliCapabilityVO cli = new CliCapabilityVO();
        if (user != null && "true".equals(user.getExternalauthentication())) {
            cli.setUser(job.getCreatedByUser() != null
                    ? job.getCreatedByUser() : configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
            cli.setPassword(job.getCreatedByUserPassword() != null
                    ? decryptPassword(job.getCreatedByUserPassword()) : configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue());
        }

        long startTimeRecovery = System.currentTimeMillis();
        List<CommandBlock> commandBlocks = getCommands(job);
        if (commandBlocks != null && !commandBlocks.isEmpty()) {
            for (CommandBlock commandBlock : commandBlocks) {
                if (commandBlock != null) {
                    DeployJobParameter deployJobParameter = commandBlock.getTemplateJobInput();
                    if (user != null && "true".equals(user.getExternalauthentication())) {
                        deployJobParameter.setCredentialsetting("override");
                        deployJobParameter.setCli(cli);
                    }
                    String jobTemplateCloneId = stablenetConnection
                            .put(Entity.entity(deployJobParameter, MediaType.APPLICATION_XML_TYPE),
                                    jobDeployUrl, stablenetDeleteJobId)
                            .readEntity(ScheduledJobBaseVO.class)
                            .getObid();

                    if (Strings.isNullOrEmpty(jobTemplateCloneId) ||
                            !stablenetConnection.get(jobStartUrl, jobTemplateCloneId).readEntity(ResultVo.class)
                                    .getState().equalsIgnoreCase(RestResultStateEnum.SUCCESS.value())) {
                        throw new OutboundApiException("Unable to start job");
                    }

                    log.debug("Executing job for jobId {}", job.getId());
                    // Checking status of tmp job in infosim
                    boolean isComplete = false;

                    int i = 0;
                    long startTime = System.currentTimeMillis();
                    while (true) {
                        try {
                            Result result = JAXB.unmarshal(new StringReader(stablenetConnection.get(jobStatusUrl, jobTemplateCloneId).readEntity(String.class)), Result.class);
                            isComplete = result != null && result.getInfo().equalsIgnoreCase("not found");
                            if (isComplete) {
                                break;
                            }
                        } catch (OutboundApiException e) {
                            log.debug(e.getMessage());
                        }
                        try {
                            TimeUnit.SECONDS.sleep(sleepTimeouts.get(i).getKey());
                        } catch (InterruptedException e1) {
                            throw new ServerException(e1);
                        }

                        long elapsedTime = System.currentTimeMillis() - startTime;
                        if (elapsedTime >= timeoutMinutes * 60 * 1000) {
                            log.warn("Job timeout! Exhausted the staggered timeout intervals");
                            break;
                        } else if (elapsedTime >= sleepTimeouts.get(i).getValue()) {
                            i++;
                            log.info("Staggering to the next timeout interval:{}", i);
                        }
                    }
                    log.debug("Stablenet Job Id:{} for EVM Job Id:{} is complete: {}  for commandBlock {}", jobTemplateCloneId, job.getId(), isComplete, commandBlock.getTemplateJobInput());
                    if (!isComplete) {
                        throw new OutboundApiException("Job timed out for jobId: " + job.getId());
                    }

                    // Getting list of all Available jobs
                    //15. get a list of results of all clone jobs of template id
                    List<JobResultVO> jobResultList = stablenetConnection.get(jobResultListUrl, stablenetDeleteJobId).readEntity(new GenericType<List<JobResultVO>>() {
                    });
                    Optional<JobResultVO> jobResultVO = jobResultList.stream()
                            .filter(input -> String.format("Deployed Object ID: %s", jobTemplateCloneId)
                                    .equalsIgnoreCase(input.getLabel()))
                            .findFirst();

                    if (!jobResultVO.isPresent()) {
                        throw new OutboundApiException("Unable to find job result for jobId: " + job.getId());
                    }

                    JobResult jobResult = stablenetConnection.get(jobResultUrl, jobResultVO.get().getObid()).readEntity(JobResult.class);
                    if (jobResult != null && jobResult.getJobresultdevices() != null && jobResult.getJobresultdevices().getJobresultdevice() != null
                            && !jobResult.getJobresultdevices().getJobresultdevice().isEmpty()) {
                        Optional<JobResultDeviceVO> first = jobResult.getJobresultdevices().getJobresultdevice().stream().findFirst();

                        if (first.isPresent()) {
                            JobResultDeviceVO jobResultDevice = stablenetConnection.get(jobResultDeviceUrl, first.get().getObid())
                                    .readEntity(JobResultDeviceVO.class);

                            String commandStatus = jobResultDevice.getState().toString();
                            if ("SUCCESS".equalsIgnoreCase(commandStatus)) {
                                log.debug("EVM Job Id:{} is successful", job.getId());
                                jobResponse = new OutboundJobResponse(Job.Status.SUCCESS, jobResultDevice.getContent());
                            } else {
                                log.debug("EVM Job Id:{} is failed", job.getId());
                                jobResponse = new OutboundJobResponse(Job.Status.FAILED, jobResultDevice.getContent());
                                return jobResponse;
                            }
                        }
                    }
                    long elapsedTimeRecovery = System.currentTimeMillis() - startTimeRecovery;
                    if (elapsedTimeRecovery >= timeoutMinutes * 60 * 1000) {
                        log.warn("Recovery job timed out! Exhausted the staggered timeout intervals...");
                        throw new OutboundApiException("Job timed out for jobId: " + job.getId());
                    }
                } else {
                    log.error("Error occurred in recovery command builder!");
                }
            }
        } else if (commandBlocks != null && commandBlocks.isEmpty()) {
            jobResponse = new OutboundJobResponse(Job.Status.SUCCESS, "No commands to recover!");
        }
        return jobResponse;

    }

    /**
     * To find if the Ruleset needs to be created or deleted based on the shared acl Policy status
     *
     * @param ruleSet
     * @param deviceId
     * @return
     */
    protected boolean isRuleSetChangesRequired(RuleSetIdNameMap ruleSet, Long deviceId, Long currentPolicyId) {
        List<Long> matchingRuleSetIds = ruleSetRepository.findIdsByNameAndDeviceIdAndNotInPolicyId(ruleSet.getName(), ruleSet.getId(), deviceId, currentPolicyId);
        AtomicBoolean isRuleSetChangesRequired = new AtomicBoolean(false);
        if (!matchingRuleSetIds.isEmpty()) {
            List<Long> matchingPolicyIdInWarningOrActiveState = ruleSetRepository.findPolicyByRuleSetIdAndWorkFlowStatus(matchingRuleSetIds, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING, WorkflowParticipant.WorkflowStatus.ERROR));
            if (matchingPolicyIdInWarningOrActiveState == null || matchingPolicyIdInWarningOrActiveState.isEmpty()) {
                List<Long> matchingPolicyIdInDraftState = ruleSetRepository.findPolicyByRuleSetIdAndWorkFlowStatus(matchingRuleSetIds, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.DRAFT));
                if (matchingPolicyIdInDraftState != null && !matchingPolicyIdInDraftState.isEmpty()) {
                    for (Long policyId : matchingPolicyIdInDraftState) {
                        Policy policyHistory = getPolicyNameFromHistoryByTypes(policyId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING, WorkflowParticipant.WorkflowStatus.ERROR));
                        if (policyHistory == null || WorkflowParticipant.WorkflowStatus.ERROR == policyHistory.getWorkflowStatus()) {
                            isRuleSetChangesRequired.set(true);
                        } else if (policyHistory != null && isPolicyInActiveOrWarnningState(policyHistory.getWorkflowStatus())) {
                            isRuleSetChangesRequired.set(false);
                            break;
                        }
                    }
                }
            }
        } else {
            isRuleSetChangesRequired.set(true);
        }
        return isRuleSetChangesRequired.get();
    }

    /**
     * Fetches the policy history object
     *
     * @param policyId
     * @param status
     * @return
     */
    protected Policy getPolicyNameFromHistoryByTypes(Long policyId, List<WorkflowParticipant.WorkflowStatus> status) {
        Policy policyFromHistory = null;
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policyId, status);
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policy history entity with oldName {} and latest Policy Id {}", oldPolicy.getName(), policyId);
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * To know if the given policy is in warning or  active state
     *
     * @param policyWorkflowStatus
     * @return
     */
    protected boolean isPolicyInActiveOrWarnningState(WorkflowParticipant.WorkflowStatus policyWorkflowStatus) {
        return WorkflowParticipant.WorkflowStatus.ACTIVE == policyWorkflowStatus || WorkflowParticipant.WorkflowStatus.WARNING == policyWorkflowStatus;
    }

    public abstract List<CommandBlock> getCommands(Job job);

    @Data
    class RuleSetIdNameMap {
        private Long id;
        private String name;
    }
}
