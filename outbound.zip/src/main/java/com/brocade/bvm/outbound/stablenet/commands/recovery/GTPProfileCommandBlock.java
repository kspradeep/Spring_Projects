package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kraikar on 8/8/2016.
 */
public class GTPProfileCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String profileName;

    @Getter
    @Setter
    private Long profileId;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * argument #1 is GTP profile name
     * argument #2 is GTP profile id
     * gtp 'gtp profile name' 'gtp profile id'
     * </pre>
     */
    private static final String PRE_CMD = "conf t;";

    /**
     * <pre>
     * argument #1 is GTP profile name
     * eg: show gtp name 'gtp profile name'$
     * </pre>
     */
    private static final String SHOW_CMD = "sh gtp name \"%s\"";

    /**
     * <pre>
     * eg: ===========GTP "profile name"\("profile id"\)============$
     * </pre>
     */
    private static final String MATCH_CMD = "===========GTP %s\\(%s\\)============$";

    /**
     * <pre>
     * eg: no gtp "profile name"
     * </pre>
     */
    private static final String ACTION_CMD = "no gtp \"%s\"";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, profileName, profileId));
        args.add(String.format(SHOW_CMD, profileName));
        args.add(String.format(MATCH_CMD, profileName, profileId));
        args.add(String.format(ACTION_CMD, profileName));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "GTPProfileCommandBlock{" +
                "deviceId=" + deviceId +
                ", profileName='" + profileName + '\'' +
                ", profileId=" + profileId +
                ", writeMem='" + writeMem + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GTPProfileCommandBlock)) return false;

        GTPProfileCommandBlock that = (GTPProfileCommandBlock) o;

        if (getDeviceId() != null ? !getDeviceId().equals(that.getDeviceId()) : that.getDeviceId() != null)
            return false;
        if (getProfileName() != null ? !getProfileName().equals(that.getProfileName()) : that.getProfileName() != null)
            return false;
        if (getProfileId() != null ? !getProfileId().equals(that.getProfileId()) : that.getProfileId() != null)
            return false;
        return getWriteMem() != null ? getWriteMem().equals(that.getWriteMem()) : that.getWriteMem() == null;

    }

    @Override
    public int hashCode() {
        int result = getDeviceId() != null ? getDeviceId().hashCode() : 0;
        result = 31 * result + (getProfileName() != null ? getProfileName().hashCode() : 0);
        result = 31 * result + (getProfileId() != null ? getProfileId().hashCode() : 0);
        result = 31 * result + (getWriteMem() != null ? getWriteMem().hashCode() : 0);
        return result;
    }
}
