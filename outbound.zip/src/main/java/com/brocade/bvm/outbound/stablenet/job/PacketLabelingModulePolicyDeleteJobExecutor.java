package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketLabelingModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class PacketLabelingModulePolicyDeleteJobExecutor extends AbstractPacketLabelingModulePolicyJobExecutor {
    /**
     * This method constructs delete PacketLabelingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketLabelingModulePolicy modulePolicy = (PacketLabelingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getModules().forEach(module -> {
            command.append(String.format(MODULE_POLICY_REVERT_SOURCE_PORT_LABELING_FORMAT, module.getModuleNumber(), getProcessor(module.getDevice(), modulePolicy)));
        });
        command.append(WRITE_MEMORY);
        log.debug("PacketLabelingModulePolicyDelete command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_LABELING_MODULE_POLICY_DELETE);
    }
}
