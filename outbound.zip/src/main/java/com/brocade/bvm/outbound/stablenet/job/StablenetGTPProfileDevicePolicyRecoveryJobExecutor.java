package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.*;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.GTPProfileCommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PacketSlicingCommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PacketSlicingPortCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetGTPProfileDevicePolicyRecoveryJobExecutor class implements methods to recover GTPDevicePolicy which is in ERROR state on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetGTPProfileDevicePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_PROFILE_ROLLBACK);
    }

    /**
     * This method constructs GTPDevicePolicy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        GTPDevicePolicy gtpDevicePolicyToDelete = (GTPDevicePolicy) getParentObject(job);
        log.debug("GTPDevicePolicyRecovery Job executor for policy id {}", gtpDevicePolicyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(gtpDevicePolicyToDelete);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", gtpDevicePolicyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs GTPDevicePolicy recovery command blocks for the given policy
     *
     * @param gtpDevicePolicyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(GTPDevicePolicy gtpDevicePolicyToDelete) {
        List<CommandBlock> commandBlocks = Lists.newArrayList();
        commandBlocks.add(constructGtpProfileCommandBlock(gtpDevicePolicyToDelete));
        return commandBlocks;
    }

    /**
     * This method constructs GTPDevicePolicy recovery command block
     *
     * @param gtpDevicePolicyToDelete
     * @return GTPProfileCommandBlock
     */
    private GTPProfileCommandBlock constructGtpProfileCommandBlock(GTPDevicePolicy gtpDevicePolicyToDelete) {
        GTPProfileCommandBlock gtpProfileCommandBlock = new GTPProfileCommandBlock();
        gtpProfileCommandBlock.setDeviceId(gtpDevicePolicyToDelete.getDevice().getStablenetId().intValue());
        gtpProfileCommandBlock.setProfileName(gtpDevicePolicyToDelete.getName());
        gtpProfileCommandBlock.setProfileId(gtpDevicePolicyToDelete.getProfileId());
        return gtpProfileCommandBlock;
    }
}
