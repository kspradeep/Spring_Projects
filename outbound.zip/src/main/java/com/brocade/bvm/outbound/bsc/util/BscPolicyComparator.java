/*
* $Id$ $Revision$
* Copyright Brocade 2016
*/

package com.brocade.bvm.outbound.bsc.util;

import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.db.*;
import lombok.Setter;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Class to compare policy based on rules created
 */
@Named
public class BscPolicyComparator {

    protected static final String BSC_RULE_VERIFY_FORMAT = "%s_%s";

    @Setter
    private Map<String, String> portIdNameMap;

    @Inject
    private PortRepository portRepository;

    /**
     * This method is used compare oldFlow with newFlow and returns the difference
     *
     * @param oldFlow
     * @param newFlow
     * @return
     */
    public BscPolicyDiff comparePolicy(Flow oldFlow, Flow newFlow) {
        BscPolicyDiff policyDiff = new BscPolicyDiff();

        if (oldFlow != null && newFlow != null) {
            List<Port> oldPortList = (List<Port>)portRepository.findAll(oldFlow.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            Set<String> oldIngressSet = oldPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            Set<PortGroup> oldPortGroups = oldFlow.getIngressPortGroups();
            for(PortGroup portGroup: oldPortGroups) {
                List<Port> oldPortGroupPortList = (List<Port>)portRepository.findAll(portGroup.getPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
                oldIngressSet.addAll(oldPortGroupPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
            }

            Set<String> newIngressSet = newFlow.getIngressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            Set<PortGroup> newPortGroups = newFlow.getIngressPortGroups();
            for(PortGroup portGroup: newPortGroups) {
                newIngressSet.addAll(portGroup.getPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
            }

            boolean isSingleIngressOld = false;
            boolean isSingleIngressNew = false;
            if (newIngressSet.size() == 1) {
                isSingleIngressNew = true;
            }
            if (oldIngressSet.size() == 1) {
                isSingleIngressOld = true;
            }

            boolean isSingleEgressOld = false;
            boolean isSingleEgressNew = false;
            if (newFlow.getEgressPorts().size() == 1) {
                isSingleEgressNew = true;
            }
            if (oldFlow.getEgressPorts().size() == 1) {
                isSingleEgressOld = true;
            }

            boolean isEgressPgOld = false;
            boolean isEgressPgNew = false;
            if (newFlow.getEgressPortGroups().size() == 1) {
                isEgressPgNew = true;
            }
            if (oldFlow.getEgressPortGroups().size() == 1) {
                isEgressPgOld = true;
            }

            BscPolicyDiff.Transition oldCategory = null;
            if (isSingleIngressOld && isEgressPgOld) {
                oldCategory = BscPolicyDiff.Transition.SI_PG;
            } else if (!isSingleIngressOld && isEgressPgOld) {
                oldCategory = BscPolicyDiff.Transition.MI_PG;
            } else if (isSingleIngressOld && isSingleEgressOld) {
                oldCategory = BscPolicyDiff.Transition.SI_SE;
            } else if (isSingleIngressOld && !isSingleEgressOld) {
                oldCategory = BscPolicyDiff.Transition.SI_ME;
            } else if (!isSingleIngressOld && isSingleEgressOld) {
                oldCategory = BscPolicyDiff.Transition.MI_SE;
            } else if (!isSingleIngressOld && !isSingleEgressOld) {
                oldCategory = BscPolicyDiff.Transition.MI_ME;
            }

            policyDiff.setOldCategory(oldCategory);

            BscPolicyDiff.Transition newCategory = null;
            if (isSingleIngressNew && isEgressPgNew) {
                newCategory = BscPolicyDiff.Transition.SI_PG;
            } else if (!isSingleIngressNew && isEgressPgNew) {
                newCategory = BscPolicyDiff.Transition.MI_PG;
            } else if (isSingleIngressNew && isSingleEgressNew) {
                newCategory = BscPolicyDiff.Transition.SI_SE;
            } else if (isSingleIngressNew && !isSingleEgressNew) {
                newCategory = BscPolicyDiff.Transition.SI_ME;
            } else if (!isSingleIngressNew && isSingleEgressNew) {
                newCategory = BscPolicyDiff.Transition.MI_SE;
            } else if (!isSingleIngressNew && !isSingleEgressNew) {
                newCategory = BscPolicyDiff.Transition.MI_ME;
            }
            policyDiff.setNewCategory(newCategory);

            policyDiff.setIsPGAlterationNeeded(isPGAlterationNeeded(oldCategory,newCategory));

            policyDiff.setIsEgressChanged(isEgressChanged(oldFlow,newFlow));

            policyDiff.setIsPGChanged(isPGChanged(oldFlow,newFlow));

            getRulesDiff(getFlatRules(newFlow.getRuleSets()), getFlatRules(oldFlow.getRuleSets()), policyDiff);

        }
        return policyDiff;
    }

    /**
     *
     * @param ruleSets
     * @return
     */
    private List<Rule> getFlatRules(Set<RuleSet> ruleSets) {
        List<Rule> rules = new ArrayList<>();
        ruleSets.forEach(ruleSet -> {
            rules.addAll(ruleSet.getRules());
        });
        return rules;
    }

    /**
     * This method is used to handle indirect PG creation and marking PUT for all ingress if it is below transition
     *
     * @param oldCategory
     * @param newCategory
     * @return
     */
    private Boolean isPGAlterationNeeded(BscPolicyDiff.Transition oldCategory, BscPolicyDiff.Transition newCategory){
        Boolean isPGAlterationNeeded = false;
        if(oldCategory == BscPolicyDiff.Transition.SI_SE && newCategory == BscPolicyDiff.Transition.MI_SE ){
            isPGAlterationNeeded = true;
        }
        else if(oldCategory == BscPolicyDiff.Transition.MI_SE && newCategory == BscPolicyDiff.Transition.SI_SE){
            isPGAlterationNeeded = true;
        }
        return isPGAlterationNeeded;
    }

    /**
     * This method validates if the egress is changed
     *
     * @param oldFlow
     * @param newFlow
     * @return
     */
    private boolean isEgressChanged(Flow oldFlow, Flow newFlow){
        boolean isEgressChanged = false;
        if (oldFlow.getEgressPorts().size() != newFlow.getEgressPorts().size()) {
            isEgressChanged = true;
        } else {
            Set<Long> oldPortIds = oldFlow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            if (!newFlow.getEgressPorts().stream().allMatch(port -> oldPortIds.contains(port.getId()))) {
                isEgressChanged = true;
            }
        }
        return isEgressChanged;
    }

    /**
     * This method compares PG ids in old and new Flow, if there is any change it returns true.
     * IsEgressChanged method will not handle the case where PG is replaced by new PG, hence added this method
     * case tested SI-PG to SI-PG. Update flow with new PG without any other change
     *
     * @param oldFlow
     * @param newFlow
     * @return
     */
    private boolean isPGChanged(Flow oldFlow, Flow newFlow){
        boolean isPGChanged = false;
        if (oldFlow.getEgressPortGroups().size()>0 && newFlow.getEgressPortGroups().size()>0) {
            Set<Long> oldPGIds = oldFlow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet());
            if (!newFlow.getEgressPortGroups().stream().allMatch(portGroup -> oldPGIds.contains(portGroup.getId()))) {
                isPGChanged = true;
            }
        }
        return isPGChanged;
    }

    /**
     * This method is used to compare old rules with new rules and returns the difference
     *
     * @param nRuleList
     * @param oRuleList
     * @return
     */
    private void getRulesDiff(List<Rule> nRuleList, List<Rule> oRuleList, BscPolicyDiff policyDiff) {
        if (!oRuleList.containsAll(nRuleList)) {
            List<Long> updateRuleIds = nRuleList.stream().map(Rule::getId).collect(Collectors.toList());
            List<Rule> deletedRules = new ArrayList<>();
            List<Rule> unchangedRules = new ArrayList<>();
            oRuleList.forEach(oldRule -> {
                if (!updateRuleIds.contains(oldRule.getId())) {
                    deletedRules.add(oldRule);
                } else {
                    unchangedRules.add(oldRule);
                }
            });
            policyDiff.setDeletedRules(deletedRules);
            policyDiff.setUnchangedRules(unchangedRules);
            List<Long> oldRuleIds = oRuleList.stream().map(Rule::getId).collect(Collectors.toList());
            Set<Rule> addedRules = new HashSet<>();
            nRuleList.forEach(newRule -> {
                if (!oldRuleIds.contains(newRule.getId())) {
                    addedRules.add(newRule);
                }
            });
            policyDiff.setAddedRules(addedRules);
        }
        buildVerificationMap(nRuleList,oRuleList,policyDiff);
    }

    /**
     * This method is used to build map between rule verify format and operation to be done
     *
     * @param nRuleList
     * @param oRuleList
     * @param policyDiff
     */
    private void buildVerificationMap(List<Rule> nRuleList, List<Rule> oRuleList, BscPolicyDiff policyDiff){
        Map<String,BscPolicyDiff.RuleOperation> ruleOperationMap = new HashMap<>();
        policyDiff.setRuleOperationMap(ruleOperationMap);
        //map of rule id to Rule object for both old and new
        Map<Long,Rule> oldRuleMap= new HashMap<>();
        Map<Long,Rule> newRuleMap= new HashMap<>();
        oRuleList.stream().forEach(rule -> {oldRuleMap.put(rule.getId(),rule);});
        nRuleList.stream().forEach(rule -> {newRuleMap.put(rule.getId(),rule);});

        //build old rules verify match
        List<String> oldRuleVerifyString = new ArrayList<>();
        oRuleList.stream().forEach(rule -> {
            //iterate over the ingress ports
            List<Port> oldIngressPortList = (List<Port>)portRepository.findAll(rule.getRuleSet().getFlow().getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            Set<String> ingressPortIds = oldIngressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

            Set<PortGroup> portGroups = rule.getRuleSet().getFlow().getIngressPortGroups();
            for(PortGroup portGroup: portGroups) {
                List<Port> oldPortGroupIngressPortList = (List<Port>)portRepository.findAll(portGroup.getPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
                ingressPortIds.addAll(oldPortGroupIngressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
            }

            ingressPortIds.stream().forEach(eachIngressId ->{
                String ingressOpenFlowId = portIdNameMap.get(eachIngressId);
                String ruleVerifyString = String.format(BSC_RULE_VERIFY_FORMAT,ingressOpenFlowId,rule.getId());
                oldRuleVerifyString.add(ruleVerifyString);
            });
        });
        //build new rules verify map
        List<String> newRuleVerifyString = new ArrayList<>();
        nRuleList.stream().forEach(rule -> {
            //iterate over the ingress ports
            //List<Long> ingressPortIds = rule.getRuleSet().getFlow().getIngressPorts().stream().map(Port::getId).collect(Collectors.toList());
            Set<String> ingressPortIds = rule.getRuleSet().getFlow().getIngressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

            Set<PortGroup> portGroups = rule.getRuleSet().getFlow().getIngressPortGroups();
            for(PortGroup portGroup: portGroups) {
                ingressPortIds.addAll(portGroup.getPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
            }

            ingressPortIds.stream().forEach(eachIngressId ->{
                String ingressOpenFlowId = portIdNameMap.get(eachIngressId);
                String ruleVerifyString = String.format(BSC_RULE_VERIFY_FORMAT,ingressOpenFlowId,rule.getId());
                newRuleVerifyString.add(ruleVerifyString);
            } );
        });

        //compare both the lists and identify for PUT and NO op
        newRuleVerifyString.forEach(eachNewRule ->{
            if(oldRuleVerifyString.contains(eachNewRule)){
                //get rule id from rule String
                String ruleStringArray[] = eachNewRule.split("_");
                Long ruleId = Long.parseLong(ruleStringArray[1]);
                //check if rule is changed
                if(isRuleChanged(oldRuleMap.get(ruleId),newRuleMap.get(ruleId)) || policyDiff.getIsEgressChanged() == true ||
                        policyDiff.getIsPGChanged() == true || policyDiff.getIsPGAlterationNeeded() == true){
                    policyDiff.addToRuleOperationMap(eachNewRule, BscPolicyDiff.RuleOperation.PUT);
                }else{
                    policyDiff.addToRuleOperationMap(eachNewRule, BscPolicyDiff.RuleOperation.NO_OP);
                }
            }else{
                policyDiff.addToRuleOperationMap(eachNewRule, BscPolicyDiff.RuleOperation.PUT);
            }
        });
        //iterate over old rule strings and add Delete for all the rule not present in new rule string
        oldRuleVerifyString.forEach(eachOldRule ->{
            if(!newRuleVerifyString.contains(eachOldRule)){
                policyDiff.addToRuleOperationMap(eachOldRule, BscPolicyDiff.RuleOperation.DELETE);
            }
        });
    }

    /**
     * This method is used to validate if the rule data is updated
     *
     * @param oldRule
     * @param newRule
     * @return
     */
    private boolean isRuleChanged(Rule oldRule, Rule newRule) {

        // Policy parameters
        if(oldRule.getRuleSet().getFlow().getPolicy().getName() != null ? !oldRule.getRuleSet().getFlow().getPolicy().getName().equals(newRule.getRuleSet().getFlow().getPolicy().getName()) : newRule.getRuleSet().getFlow().getPolicy().getName() != null)
                return true;

        //flow parameters

        if (oldRule.getRuleSet().getFlow().getSourceMacTag() != null ? !oldRule.getRuleSet().getFlow().getSourceMacTag().equals(newRule.getRuleSet().getFlow().getSourceMacTag()) : newRule.getRuleSet().getFlow().getSourceMacTag() != null)
            return true;

        if (oldRule.getRuleSet().getFlow().getDestinationMacTag() != null ? !oldRule.getRuleSet().getFlow().getDestinationMacTag().equals(newRule.getRuleSet().getFlow().getDestinationMacTag()) : newRule.getRuleSet().getFlow().getDestinationMacTag() != null)
            return true;

        if (!oldRule.getRuleSet().getFlow().getSequence().equals(newRule.getRuleSet().getFlow().getSequence()))
            return true;

        String oldVLan = oldRule.getRuleSet().getFlow().getVlans().size() > 0 ? oldRule.getRuleSet().getFlow().getVlans().stream().findFirst().get():null;
        String newVLan = newRule.getRuleSet().getFlow().getVlans().size() > 0 ? newRule.getRuleSet().getFlow().getVlans().stream().findFirst().get():null;

        if(oldVLan != null ? !oldVLan.equals(newVLan) : newVLan != null)
           return true;

        //Rule parameters
        if (oldRule.getSourcePort() != newRule.getSourcePort()) return true;
        if (oldRule.getDestinationPort() != newRule.getDestinationPort()) return true;
        if (oldRule.getVlanId() != newRule.getVlanId()) return true;
        if (oldRule.getIsPermit() != newRule.getIsPermit()) return true;
        if (oldRule.getId() != null ? !oldRule.getId().equals(newRule.getId()) : newRule.getId() != null) return true;
        if (oldRule.getName() != null ? !oldRule.getName().equals(newRule.getName()) : newRule.getName() != null)
            return true;
        if (oldRule.getSourceIp() != null ? !oldRule.getSourceIp().equals(newRule.getSourceIp()) : newRule.getSourceIp() != null)
            return true;
        if (oldRule.getSourcePortOperator() != null ? !oldRule.getSourcePortOperator().equals(newRule.getSourcePortOperator()) : newRule.getSourcePortOperator() != null)
            return true;
        if (oldRule.getDestinationIp() != null ? !oldRule.getDestinationIp().equals(newRule.getDestinationIp()) : newRule.getDestinationIp() != null)
            return true;
        if (oldRule.getDestinationPortOperator() != null ? !oldRule.getDestinationPortOperator().equals(newRule.getDestinationPortOperator()) : newRule.getDestinationPortOperator() != null)
            return true;
        if (oldRule.getProtocol() != null ? !oldRule.getProtocol().equals(newRule.getProtocol()) : newRule.getProtocol() != null)
            return true;
        if (oldRule.getProtocolType() != null ? !oldRule.getProtocolType().equals(newRule.getProtocolType()) : newRule.getProtocolType() != null)
            return true;
        if (oldRule.getCustomAcl() != null ? !oldRule.getCustomAcl().equals(newRule.getCustomAcl()) : newRule.getCustomAcl() != null)
            return true;
        if (oldRule.getSourceMac() != null ? !oldRule.getSourceMac().equals(newRule.getSourceMac()) : newRule.getSourceMac() != null)
            return true;
        if (oldRule.getSourceMacMask() != null ? !oldRule.getSourceMacMask().equals(newRule.getSourceMacMask()) : newRule.getSourceMacMask() != null)
            return true;
        if (oldRule.getDestinationMac() != null ? !oldRule.getDestinationMac().equals(newRule.getDestinationMac()) : newRule.getDestinationMac() != null)
            return true;
        if (oldRule.getDestinationMacMask() != null ? !oldRule.getDestinationMacMask().equals(newRule.getDestinationMacMask()) : newRule.getDestinationMacMask() != null)
            return true;
        if (oldRule.getEthType() != null ? !oldRule.getEthType().equals(newRule.getEthType()) : newRule.getEthType() != null)
            return true;
        if (oldRule.getSequence() != null ? !oldRule.getSequence().equals(newRule.getSequence()) : newRule.getSequence() != null)
            return true;

        return false;
    }

}
