package com.brocade.bvm.outbound.stablenet.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * To Construct XML Content for StableNet Rest Job Template(For Job Deploy).
 */
@XmlRootElement
@ToString
public class Deployparameter {
    @XmlAttribute
    private String configmode = "default";
    @Getter
    @Setter
    private Input input;
    @Getter
    @Setter
    private Devices devices;
    @Getter
    @Setter
    private SingleTrigger singletrigger;
    @Getter
    @Setter
    private CliCapabilityVO cli;

    @XmlAttribute
    @Setter
    private String credentialsetting = "devicecredentials";

    public Deployparameter() {
        super();
    }
}
