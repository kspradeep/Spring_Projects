package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * This class enables the Acl Frag Conservative feature on target device
 */
@Slf4j
@Named
public class AclFragConservativeExecutor extends AbstractStablenetJobExecutor {

    protected static final String ACL_POLICY = "acl-policy;";
    protected static final String ACL_FRAG_CONSERVATIVE = "acl-frag-conservative;";
    protected static final String ENABLE_ACL_COUNTER = "enable-acl-counter;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.ENABLE_ACL_FRAG_CONSERVATIVE, Job.Type.DISABLE_ACL_FRAG_CONSERVATIVE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE);
    }

    /**
     * This method gets the command for enabling the acl frag conservative feature on targe device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(ACL_POLICY);
        if (job.getType() == Job.Type.ENABLE_ACL_FRAG_CONSERVATIVE) {
            command.append(ACL_FRAG_CONSERVATIVE);
            command.append(ENABLE_ACL_COUNTER);
        } else if (job.getType() == Job.Type.DISABLE_ACL_FRAG_CONSERVATIVE) {
            command.append(REVERT).append(ACL_FRAG_CONSERVATIVE);
            command.append(REVERT).append(ENABLE_ACL_COUNTER);
        }
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
