package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.vlan.VlanTaggingStripping;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

@Getter
@NoArgsConstructor
public class StablenetSLXPolicyDiff {

    @Setter
    private String routeMapName;

    @Setter
    private Set<Port> deletedIngressPorts;

    @Setter
    private Set<Port> addedIngressPorts;

    @Setter
    private Set<PortGroup> deletedIngressPortChannels;

    @Setter
    private Set<PortGroup> addedIngressPortChannels;

    @Setter
    private Set<Port> deletedEgressPorts;

    @Setter
    private Set<Port> addedEgressPorts;

    @Setter
    private Set<PortGroup> deletedEgressPortChannels;

    @Setter
    private Set<PortGroup> addedEgressPortChannels;

    @Setter
    private Set<Port> unchangedEgressPorts;

    @Setter
    private Set<PortGroup> unchangedEgressPortChannels;

    @Setter
    private Set<Port> unchangedIngressPorts;

    @Setter
    private Set<PortGroup> unchangedIngressPortChannels;

    @Setter
    private Map<Integer, Set<String>> oldEgressPortsMap;

    @Setter
    private Map<Integer, Set<String>> newEgressPortsMap;

    @Setter
    private Map<Integer, Set<FlowEgressManagedObject>> oldFlowEgressPortsMap;

    @Setter
    private Map<Integer, Set<FlowEgressManagedObject>> newFlowEgressPortsMap;

    @Setter
    private Map<Integer, Set<String>> oldSequenceTvfDomainIdMap;

    @Setter
    private Map<Integer, Set<String>> newSequenceTvfDomainIdMap;

    @Setter
    private Map<Integer, Set<String>> existingSequenceTvfDomainIdMap;

    @Setter
    private Map<Integer, Set<String>> oldEgressPortGroupsMap;

    @Setter
    private Map<Integer, Set<String>> newEgressPortGroupsMap;

    @Setter
    private Map<Integer, Set<FlowEgressManagedObject>> oldFlowEgressPortGroupsMap;

    @Setter
    private Map<Integer, Set<FlowEgressManagedObject>> newFlowEgressPortGroupsMap;

    @Setter
    private Set<Integer> deletedSeqs;

    @Setter
    private Set<Integer> addedSeqs;

    @Setter
    private Set<Integer> updatedSeqs;

    @Setter
    private SortedSet<RuleSet> deletedRuleSets;

    @Setter
    private SortedSet<RuleSet> addedRuleSets;

    @Setter
    private Set<RuleSet.Type> deletedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> deletedRuleSetIpList;

    @Setter
    private Set<RuleSet.Type> addedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> addedRuleSetIpList;

    @Setter
    private Set<RuleSet.Type> updatedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> updatedRuleSetIpList;

    @Setter
    //port_number
    private Map<String, RuleSetDiff> policyMap;

    @Setter
    //route-map/sequence
    private Map<Integer, RuleSetDiff> flowMap;

    @Setter
    //acl_type
    private Map<RuleSet.Type, List<RuleDiff>> ruleSetTypeMap;

    @Setter
    //acl_type
    private Map<RuleSet.IpVersion, List<RuleDiff>> ruleSetIpVersionMap;

    @Setter
    private VlanDiff vlanDiff;

    @Setter
    private TvfDiff tvfDiff;

    @Setter
    private boolean isRulesUpdatedForPolicy;

    @Setter
    private boolean isRulesDeletedForPolicy;

    @Setter
    private boolean isRulesAddedForPolicy;

    @Setter
    private Set<Long> updatedRules;

    @Setter
    private Set<RuleSet.Type> ruleSetsTypeToUnmap;

    @Setter
    private Set<RuleSet.IpVersion> ruleSetsIpVersionToUnmap;

    @Setter
    private Map<Long, Flow> updatedFlowDefaultRouteMapDrop;

    // Includes all added and updated flows with Vlan tagging and stripping info
    @Setter
    private Map<Integer, VlanTaggingStripping> addedUpdatedFlowVlanTaggingStripping;

    @Setter
    private Map<Integer, Integer> oldDestinationGroupMap;

    @Setter
    private Map<Integer, Integer> newDestinationGroupMap;

    @Setter
    private Map<Integer, Integer> exitingDestinationGroupMap;

    @Setter
    private boolean isGridPolicy;

}
