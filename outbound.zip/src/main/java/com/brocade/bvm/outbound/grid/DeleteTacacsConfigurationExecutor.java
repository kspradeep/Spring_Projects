package com.brocade.bvm.outbound.grid;

import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

/**
 * DeleteTacacsConfigurationExecutor removes the TACACS authentication and authorization configurations from device.
 */
@Named
@Slf4j
public class DeleteTacacsConfigurationExecutor extends AbstractStablenetJobExecutor {

    private static final String NO_COMMAND = "no %s";
    private static final String TACACS_SERVER_IP = "tacacs-server host %s use-vrf mgmt-vrf;";
    private static final String AAA_AUTHENTICATION_LOGIN = "aaa authentication login tacacs+ local-auth-fallback;";
    private static final String AAA_ACCOUNTING_EXEC = "aaa accounting exec default start-stop tacacs+;";
    private static final String AAA_ACCOUNTING_TACACS = "aaa accounting commands default start-stop tacacs+;";
    private static final String NO_TACACS_AUTHORIZATION = "no aaa authorization command;";

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();
        Device device = job.getDevice();
        ApplicationConstant tacacsProtocolAppConstant = featureConstantsRepository.findByName(ApplicationConstant.TACACS_SERVER_IP);
        command.append(CONFIGURE_TERMINAL);
        if (device.isAuthenticationConfigured() && !Strings.isNullOrEmpty(tacacsProtocolAppConstant.getValue())) {
            command.append(String.format(NO_COMMAND, AAA_AUTHENTICATION_LOGIN));
            if (device.isAuthorizationConfigured()) {
                command.append(NO_TACACS_AUTHORIZATION);
            }
            command.append(String.format(NO_COMMAND, AAA_ACCOUNTING_TACACS));
            command.append(String.format(NO_COMMAND, AAA_ACCOUNTING_EXEC));
            command.append(String.format(NO_COMMAND, String.format(TACACS_SERVER_IP, tacacsProtocolAppConstant.getValue())));
        }
        command.append(EXIT);
        log.debug("DeleteTacacsConfigurationExecutor {} on device: {} command: {} ", job.getType(), device.getId(), command);
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.DELETE_TACACS_SERVER);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
