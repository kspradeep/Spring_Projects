package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PacketTruncationMappingHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public abstract class AbstractStablenetSLXPacketTruncationJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String INTERFACE_PORT_CHANNEL = "interface port-channel %s;";

    protected static final String TRUNCATION_PROFILE_NAME = "truncation-profile %s;";

    protected static final String FRAME_SIZE = "frame-size %s;";

    protected static final String NO_FRAME_SIZE = "no frame-size;";

    protected static final String SET_INTERFACE_ETHERNET = "set interface ethernet %s;";

    protected static final String SET_INTERFACE_PORT_CHANNEL = "set interface port-channel %s;";

    protected static final String NO_INTERFACE_ETHERNET = "no set interface ethernet;";

    protected static final String NO_INTERFACE_PORT_CHANNEL = "no set interface port-channel;";

    protected static final String CONVERT_LOOPBACK_PORT = "loopback phy;";

    protected static final String TRUNCATION_PROFILE = "truncation-profile";

    protected static final String NO_TRUNCATION_PROFILE_NAME = "no truncation-profile %s;";

    protected static final String NO_LOOPBACK_PORT = "no loopback phy;";

    @Inject
    private PacketTruncationRepository packetTruncationRepository;

    @Inject
    protected PacketTruncationMappingRepository packetTruncationMapingRepository;

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    private PacketTruncationMappingHistoryRepository packetTruncationMappingHistoryRepository;

    @Inject
    protected ManagedObjectRepository managedObjectRepository;

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * Retrive the old active PacketTruncationMapping entity to remove the loop back purpose.
     *
     * @param id
     * @return
     */
    protected PacketTruncationMapping getOldPacketTruncationMapping(Long id, List statusses) {
        PacketTruncationMapping oldPacketTruncationMapping = null;
        List<PacketTruncationMappingHistory> packetTruncationMapingHistories = packetTruncationMappingHistoryRepository.findByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(id, statusses);
        if (!packetTruncationMapingHistories.isEmpty()) {
            PacketTruncationMappingHistory packetTruncationMappingHistory = packetTruncationMapingHistories.get(0);
            oldPacketTruncationMapping = packetTruncationMappingHistory.buildParent();
        }
        return oldPacketTruncationMapping;
    }

}
