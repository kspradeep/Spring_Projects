package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.GTPDevicePolicy;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import java.util.List;
import java.util.Set;

/**
 * The AbstractStablenetPortGroupJobExecutor class implemented methods used in CREATE/DELETE of portGroup on Non Open Flow device through Stablenet
 */
@Slf4j
public abstract class AbstractStablenetPortGroupJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";
    protected static final String PORT_GROUP_CONFIG_COMMAND = "lag \"%s\" %s;";
    protected static final String NO_PORT_GROUP_CONFIG_COMMAND = "no lag \"%s\" %s;";
    protected static final String PORT_GROUP_DISABLE_PORT = "disable ethernet %s;";
    protected static final String ENABLE_PORT = "interface ethernet %s;enable;exit;";
    protected static final String PORT_GROUP_NO_DEPLOY = "no deploy;";
    protected static final String EXIT = "exit;";
    protected static final String END = "end;";
    protected static final String WRITE_MEMORY = "write memory;";
    protected static final String PORT_GROUP_PORTS = "ports%s;";
    protected static final String PORT_GROUP_PRIMARY_PORT = "primary-port %s;";
    protected static final String PORT_GROUP_DEPLOY = "deploy;";
    protected static final String ETHERNET = " ethernet %s";
    protected static final String GTP_PROFILE_CONFIG = "gtp \"%s\" %s;";
    protected static final String GTP_PROFILE_PORT_MAP = "ports ethernet %s;";
    protected static final String GTP_PROFILE_PORT_UNMAP = "no ports ethernet %s;";
    protected static final String TVF_DOMAIN_VLAN = "tvf-domain %s;";
    protected static final String NO_TVF_DOMAIN_VLAN = "no tvf-domain %s;";
    protected static final String PORTS = "ports ethe %s;";
    protected static final String VLAN = "vlan %s name EgressVLAN;";
    protected static final String TAGGED = "tagged ethe %s;";
    protected static final String UNTAGGED = "untagged ethe %s;";
    protected static final String NO_TAGGED = "no tagged ethe %s;";
    protected static final String NO_PORTS = "no ports ethe %s;";
    protected static final String NO_UN_TAGGED = "no untagged ethe %s;";

    @Inject
    private FlowRepository flowRepository;

    /**
     * This method builds command to delete portGroup
     *
     * @param portGroup
     * @return String returns delete commands
     */
    protected String buildDeleteCommand(PortGroup portGroup) {
        StringBuilder deleteCmd = new StringBuilder();
        StringBuilder reEnablePortsCmd = new StringBuilder();
        if (portGroup != null) {
            // Delete port group
            deleteCmd.append(String.format(PORT_GROUP_CONFIG_COMMAND, portGroup.getName(), "static"));
            if (portGroup.getPrimaryPort() != null) {
                Set<Port> ports = portGroup.getPorts();
                if (ports != null && !ports.isEmpty()) {
                    for (Port port : ports) { // iterate ports
                        deleteCmd.append(String.format(PORT_GROUP_DISABLE_PORT, port.getPortNumber()));
                        if (port.getAdminStatus() == Port.AdminStatus.ENABLED) {
                            reEnablePortsCmd.append(String.format(ENABLE_PORT, port.getPortNumber()));
                        }
                    }
                }
            } else {
                log.error("Primary port not available.");
            }
            deleteCmd.append(PORT_GROUP_NO_DEPLOY);
            deleteCmd.append(EXIT);
            deleteCmd.append(String.format(NO_PORT_GROUP_CONFIG_COMMAND, portGroup.getName(), "static"));
            deleteCmd.append(reEnablePortsCmd);
        }
        return deleteCmd.toString();
    }

    /**
     * This method builds command to create portGroup
     *
     * @param portGroup
     * @return String returns delete commands
     */
    protected String buildCreateCommand(PortGroup portGroup) {
        StringBuilder createCmd = new StringBuilder();
        if (portGroup != null) {
            createCmd.append(String.format(PORT_GROUP_CONFIG_COMMAND, portGroup.getName(), "static"));
            Set<Port> ports = portGroup.getPorts();
            if (ports != null && !ports.isEmpty()) {
                StringBuilder portsCommand = new StringBuilder();
                for (Port port : ports) {
                    portsCommand.append(String.format(ETHERNET, port.getPortNumber()));
                }
                createCmd.append(String.format(PORT_GROUP_PORTS, portsCommand));
            } else {
                log.error("Please provide the participating port(s).");
            }
            if (portGroup.getPrimaryPort() != null) {
                createCmd.append(String.format(PORT_GROUP_PRIMARY_PORT, portGroup.getPrimaryPort().getPortNumber()));
            } else {
                log.error("Please provide the primary port.");
            }
            createCmd.append(PORT_GROUP_DEPLOY);
            createCmd.append(EXIT);
        }
        return createCmd.toString();
    }

    /**
     * To map primary port of port group to GTP profile
     *
     * @param portGroup
     * @return
     */
    protected String buildMapPortToGtpProfile(PortGroup portGroup) {
        StringBuilder command = new StringBuilder();
        GTPDevicePolicy gtpProfile = portGroup.getGtpProfile();
        if (gtpProfile != null) {
            command.append(String.format(GTP_PROFILE_CONFIG, gtpProfile.getName(), gtpProfile.getProfileId()));
            command.append(String.format(GTP_PROFILE_PORT_MAP, portGroup.getPrimaryPort().getPortNumber()));
            command.append(EXIT);
        }
        return command.toString();
    }

    /**
     * To unmap primary port of port group from GTP profile
     *
     * @param portGroup
     * @return
     */
    protected String buildUnMapPortFromGtpProfile(PortGroup portGroup) {
        StringBuilder command = new StringBuilder();
        GTPDevicePolicy gtpProfile = portGroup.getGtpProfile();
        if (gtpProfile != null) {
            command.append(String.format(GTP_PROFILE_CONFIG, gtpProfile.getName(), gtpProfile.getProfileId()));
            command.append(String.format(GTP_PROFILE_PORT_UNMAP, portGroup.getPrimaryPort().getPortNumber()));
            command.append(EXIT);
        }
        return command.toString();
    }

    /**
     * To map/unmap primary port of port group from GTP profile
     *
     * @param oldPortGroup
     * @param newPortGroup
     * @return
     */
    protected String buildSmartUnMapPortFromGtpProfile(PortGroup oldPortGroup, PortGroup newPortGroup) {
        StringBuilder command = new StringBuilder();
        GTPDevicePolicy oldGtpProfile = oldPortGroup.getGtpProfile();
        GTPDevicePolicy newGtpProfile = newPortGroup.getGtpProfile();
        if (oldGtpProfile != null && newGtpProfile != null) {
            if (oldGtpProfile.getId() != newGtpProfile.getId()
                    || oldPortGroup.getPrimaryPort().getId() != newPortGroup.getPrimaryPort().getId()) {
                command.append(buildUnMapPortFromGtpProfile(oldPortGroup));
            }
        } else if (oldGtpProfile == null && newGtpProfile != null) {
            command.append(buildMapPortToGtpProfile(newPortGroup));
        } else if (oldGtpProfile != null && newGtpProfile == null) {
            command.append(buildUnMapPortFromGtpProfile(oldPortGroup));
        }
        return command.toString();
    }

    /**
     * To map/unmap primary port of port group from GTP profile
     *
     * @param oldPortGroup
     * @param newPortGroup
     * @return
     */
    protected String buildSmartMapPortFromGtpProfile(PortGroup oldPortGroup, PortGroup newPortGroup) {
        StringBuilder command = new StringBuilder();
        GTPDevicePolicy oldGtpProfile = oldPortGroup.getGtpProfile();
        GTPDevicePolicy newGtpProfile = newPortGroup.getGtpProfile();
        if (oldGtpProfile != null && newGtpProfile != null) {
            if (oldGtpProfile.getId() != newGtpProfile.getId()
                    || oldPortGroup.getPrimaryPort().getId() != newPortGroup.getPrimaryPort().getId()) {
                // command.append(buildUnMapPortFromGtpProfile(oldPortGroup));
                command.append(buildMapPortToGtpProfile(newPortGroup));
            }
        } else if (oldGtpProfile == null && newGtpProfile != null) {
            command.append(buildMapPortToGtpProfile(newPortGroup));
        } else if (oldGtpProfile != null && newGtpProfile == null) {
            command.append(buildUnMapPortFromGtpProfile(oldPortGroup));
        }
        return command.toString();
    }

    protected String buildVlanCommandForModifiedPorts(PortGroup portGroup, String existingPrimaryPortName, boolean isAdd) {
        StringBuilder command = new StringBuilder();
        Port primaryPort = portGroup.getPrimaryPort();
        List<Object[]> vlanList = flowRepository.findVlanByEgressPortGroup(portGroup.getId());
        if (!vlanList.isEmpty() && primaryPort != null) {
            String primaryPortName = primaryPort.getPortNumber();
            vlanList.forEach(valueArray -> {
                Boolean tvfDomain = Boolean.valueOf(String.valueOf(valueArray[1]));
                Boolean isTagged = Boolean.valueOf(String.valueOf(valueArray[2]));
                String value = String.valueOf(valueArray[3]);
                if (tvfDomain == true) {
                    if (isAdd) {
                        command.append(String.format(TVF_DOMAIN_VLAN, value));
                        command.append(String.format(PORTS, primaryPortName));
                        command.append(EXIT);
                    } else {
                        command.append(String.format(TVF_DOMAIN_VLAN, value));
                        command.append(String.format(NO_PORTS, existingPrimaryPortName));
                        command.append(EXIT);
                    }
                } else {
                    command.append(String.format(VLAN, value));
                    if (isAdd) {
                        command.append(String.format(isTagged ? TAGGED : UNTAGGED, primaryPortName));
                    } else {
                        command.append(String.format(isTagged ? NO_TAGGED : NO_UN_TAGGED, existingPrimaryPortName));
                    }
                    command.append(EXIT);
                }
            });
        }
        return command.toString();
    }
}
