package com.brocade.bvm.outbound;

import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.FirmwareJob;
import com.brocade.bvm.model.exception.ServerException;
import org.springframework.context.ApplicationContext;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collection;
import java.util.Optional;

@Named
public class FirmwareOutboundJobExecutorBuilder {

    @Inject
    private ApplicationContext applicationContext;
    private Collection<FirmwareOutboundJobExecutor> outboundJobExecutors;

    @Inject
    protected PolicyRepository policyRepository;

    @PostConstruct
    void init() {
        outboundJobExecutors = applicationContext.getBeansOfType(FirmwareOutboundJobExecutor.class).values();
    }

    public FirmwareOutboundJobExecutor build(FirmwareJob firmwareJob) {
        Optional<FirmwareOutboundJobExecutor> outboundJobExecutor = outboundJobExecutors.stream()
                .filter(oje -> oje.getSupportedJobTypes().contains(firmwareJob.getType()) &&
                        //TODO to fix the cast issue for open stack device
                        (oje.getSupportedDeviceTypes().contains(firmwareJob.getDevice().getType())))
                .findFirst();
        if (outboundJobExecutor.isPresent()) {
            return outboundJobExecutor.get();
        } else {
            throw new ServerException(String.format("No supported FirmwareOutboundJobExecutor found for job: %s, device: %s, %s ", firmwareJob.getType(), firmwareJob.getDevice().getType(), firmwareJob.getDevice().getMode()));
        }
    }
}
