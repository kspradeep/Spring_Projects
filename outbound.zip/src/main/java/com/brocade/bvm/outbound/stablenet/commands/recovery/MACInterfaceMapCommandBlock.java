package com.brocade.bvm.outbound.stablenet.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;

import lombok.Getter;
import lombok.Setter;

public class MACInterfaceMapCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";
    /**
     * <pre>
     * argument #1 is port name
     * int e 1/1
     * </pre>
     */
    private static final String PRE_CMD = "conf t;int e %s;";
    /**
     * <pre>
     * argument #1 is port name
     * eg: show running-config interface ethernet 1/1
     * eg: sh run int e 1/1
     * </pre>
     */
    private static final String SHOW_CMD = "sh run int e %s";
    /**
     * <pre>
     * argument #1 is port name
     * eg: 1/1
     * </pre>
     */
    private static final String MATCH_CMD = "%s";
    /**
     * <pre>
     * mac access-group DENY_ANY out
     * </pre>
     */
    private static final String ACTION_CMD = "mac access-group DENY_ANY out";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, port));
        args.add(String.format(SHOW_CMD, port));
        args.add(String.format(MATCH_CMD, port));
        args.add(writeMem);
        args.add(ACTION_CMD);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "MACInterfaceMapCommandBlock [deviceId=" + deviceId + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MACInterfaceMapCommandBlock)) return false;

        MACInterfaceMapCommandBlock that = (MACInterfaceMapCommandBlock) o;

        if (getDeviceId() != null ? !getDeviceId().equals(that.getDeviceId()) : that.getDeviceId() != null)
            return false;
        if (getPort() != null ? !getPort().equals(that.getPort()) : that.getPort() != null) return false;
        return getWriteMem() != null ? getWriteMem().equals(that.getWriteMem()) : that.getWriteMem() == null;

    }

    @Override
    public int hashCode() {
        int result = getDeviceId() != null ? getDeviceId().hashCode() : 0;
        result = 31 * result + (getPort() != null ? getPort().hashCode() : 0);
        result = 31 * result + (getWriteMem() != null ? getWriteMem().hashCode() : 0);
        return result;
    }
}
