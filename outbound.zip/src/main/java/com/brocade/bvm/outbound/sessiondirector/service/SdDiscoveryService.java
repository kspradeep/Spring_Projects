package com.brocade.bvm.outbound.sessiondirector.service;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.brocade.bvm.outbound.sessiondirector.SessionDirectorConnection;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Get SD devices specific initial configuration using Session Director REST API
 */
@Slf4j
@Named
public class SdDiscoveryService {

    @Value("${sd.url.profile}")
    protected String profileUrl;

    @Value("${sd.url.all.ports}")
    protected String allPortsUrl;

    @Value("${sd.url.ingress.ports}")
    protected String ingressPortsUrl;

    @Value("${sd.url.all.port.group}")
    protected String allPortGroupUrl;

    @Value("${sd.url.physical.interface}")
    protected String physicalInterfaceUrl;

    @Inject
    protected SessionDirectorConnection sessionDirectorConnection;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected ProfileRepository profileRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    protected IngressPortRepository ingressPortRepository;

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    protected EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    private DedupePolicyRepository dedupePolicyRepository;

    @Inject
    protected PhysicalInterfaceRepository physicalInterfaceRepository;

    @Value("${sd.url.get.dedupe.policy}")
    protected String allDedupePolicy;

    /* Start of list of Strings used to extract values from SD REST Response */
    protected static final String PROFILES = "Profiles";
    protected static final String CURRENT_PROFILES = "Current Profile";
    protected static final String INGRESS_PORTS = "ingress port(s)";
    protected static final String PORT_NAME = "Port Name";
    protected static final String INTERFCAE_NAME = "Interface name";
    protected static final String JUMBO_FRAME = "Jumbo Frame";
    protected static final String LB_ALGO = "LB algo";
    protected static final String ENABLED = "enabled";
    protected static final String PORT_CONFIG = "Port-Config";
    protected static final String NAME = "Name";
    protected static final String DEFAULT_PORT = "default-port";
    protected static final String IMSI_LIMIT = "IMSI limit";
    protected static final String NO_LIMIT = "nolimit";
    protected static final String VLAN_IDS = "VLAN Ids";
    protected static final String PORT_GROUP = "Port-Group";
    protected static final String DEFAULT_PORT_GROUP = "default-port-group";
    protected static final String PORTS = "Ports";

    private static final String DEDUPE_POLICY = "Dedupe-Policy";
    private static final String POLICY_NAME = "Policy Name";
    private static final String INTERFACES = "Interfaces";
    /* End of list of Strings used to extract values from SD REST Response */

    /**
     * This method extracts Profiles form REST response and saves in DB
     *
     * @param device
     */
    public void saveProfile(Device device) {
        List<Profile> profiles = profileRepository.findByDevice(device);
        if (profiles == null || profiles.isEmpty()) {
            try {
                Response res = getResponse(device.getIpAddress(), profileUrl);
                profiles = new ArrayList<>();
                String currentProfileName = "";
                if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                    JSONObject responseJson = getJsonFromResponse(res);
                    JSONArray profilesJson = (JSONArray) (responseJson.has(PROFILES) ? responseJson.get(PROFILES) : new JSONArray());
                    JSONObject profileJson = null;
                    for (int i = 0; i < profilesJson.length(); i++) {
                        Object profileObj = profilesJson.get(i);
                        profileJson = new JSONObject(profileObj.toString());
                        Iterator<String> keysItr = profileJson.keys();
                        while (keysItr.hasNext()) {
                            String key = keysItr.next();
                            String value = (String) profileJson.get(key);
                            if (CURRENT_PROFILES.equals(key)) {
                                currentProfileName = value;
                            } else if (key.matches("\\d+")) {
                                Profile profile = new Profile();
                                profile.setDevice(device);
                                profile.setName(value);
                                profile.setProfileId(new Integer(key));

                                //TODO take from the REST response for time being interface is hardcoded in DB
                                Set<ProfileInterfaceMapping> interfaceMappings = getProfileInterfaces(profile);
                                profile.setInterfaceMappings(interfaceMappings);
                                profiles.add(profile);
                            }
                        }
                    }
                    profileRepository.save(profiles);
                    log.info("Profile List updated successfully for SD device {}.", device.getId());
                    if (!currentProfileName.isEmpty()) {
                        Profile currentProfile = profileRepository.findByNameDeviceId(currentProfileName, device.getId());
                        ProfileMapping profileMapping = new ProfileMapping();
                        profileMapping.setDevice(device);
                        profileMapping.setProfile(currentProfile);
                        profileMappingRepository.save(profileMapping);
                    }
                    log.info("Current Profile updated successfully for SD device {}.", device.getId());
                } else {
                    log.error("SD REST Response unsuccessful for SD device {}.", device.getId());
                }
            } catch (Exception e) {
                log.error("Error occurred while saving the Profiles for SD device {} :{} ", device.getId(), e.getMessage());
            }
        }
    }

    /**
     * This method is temporarily used to set the relevant interface list to profile ID 9, 13, 14
     *
     * @param profile
     * @return
     */
    public Set<ProfileInterfaceMapping> getProfileInterfaces(Profile profile) {
        Set<ProfileInterfaceMapping> interfaceMappings = new HashSet<>();
        if (profile.getProfileId() == 9 || profile.getProfileId() == 13) {
            ProfileInterfaceMapping profileInterfaceMapping = new ProfileInterfaceMapping();
            profileInterfaceMapping.setProfile(profile);
            profileInterfaceMapping.setName("s11-s1u-gngp");
            interfaceMappings.add(profileInterfaceMapping);
        }
        if (profile.getProfileId() == 13) {
            ProfileInterfaceMapping profileInterfaceMapping = new ProfileInterfaceMapping();
            profileInterfaceMapping.setProfile(profile);
            profileInterfaceMapping.setName("volte");
            interfaceMappings.add(profileInterfaceMapping);
            profileInterfaceMapping = new ProfileInterfaceMapping();
            profileInterfaceMapping.setProfile(profile);
            profileInterfaceMapping.setName("s11-s5s8u-sgi");
            interfaceMappings.add(profileInterfaceMapping);
        }
        return interfaceMappings;
    }

    /**
     * This method sends request to SD REST API and extracts and saves the ingress port for selected profile from the response
     *
     * @param sdDevice
     */
    public void saveIngressPorts(Device sdDevice) {
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDevice.getId());
        Profile profile = null;
        if (profileMapping != null) {
            profile = profileMapping.getProfile();
        }
        if (profile != null) {
            Long profileId = profile.getId();
            List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(sdDevice.getId(), profileId);
            if (profileId != null && (ingressPorts == null || ingressPorts.isEmpty())) {
                try {
                    Response res = getResponse(sdDevice.getIpAddress(), ingressPortsUrl);
                    if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                        JSONObject responseJson = getJsonFromResponse(res);
                        JSONArray ingressPortsJson = (JSONArray) (responseJson.has(INGRESS_PORTS) ? responseJson.get(INGRESS_PORTS) : new JSONArray());
                        JSONObject portJson = null;
                        ingressPorts = new ArrayList<>();
                        for (int i = 0; i < ingressPortsJson.length(); i++) {
                            Object portObj = ingressPortsJson.get(i);
                            portJson = new JSONObject(portObj.toString());
                            IngressPort ingressPort = new IngressPort();
                            ingressPort.setDevice(sdDevice);
                            Iterator<String> keysItr = portJson.keys();
                            while (keysItr.hasNext()) {
                                String key = keysItr.next();
                                String value = (String) portJson.get(key);
                                if (PORT_NAME.equals(key)) {
                                    ingressPort.setName(value);
                                } else if (INTERFCAE_NAME.equals(key)) {
                                    PhysicalInterface physicalInterface = physicalInterfaceRepository.findByNameAndDeviceId(value, sdDevice.getId());
                                    ingressPort.setPhysicalInterface(physicalInterface);
                                } else if (JUMBO_FRAME.equals(key)) {
                                    ingressPort.setJumboFrame(ENABLED.equals(value));
                                }
                            }
                            ingressPort.setProfile(profile);
                            ingressPorts.add(ingressPort);
                        }
                        ingressPortRepository.save(ingressPorts);
                        log.info("ingress-ports updated successfully for SD device {}.", sdDevice.getId());

                    } else {
                        log.error("SD REST Response for ingress-ports unsuccessful for SD device {}.", sdDevice.getId());
                    }
                } catch (Exception e) {
                    log.error("Error occurred while saving the ingress-ports for SD device {} :{} ", sdDevice.getId(), e.getMessage());
                }
            }
        }
    }


    /**
     * This method sends request to SD REST API and extracts and saves the default egress port from the response
     *
     * @param sdDevice
     */
    public Set<EgressPort> getDefaultEgressPort(Device sdDevice) {
        Set<EgressPort> egressPorts = Sets.newHashSet();
        EgressPort defaultEgressPort = egressPortRepository.findByIsDefaultTrueAndDeviceId(sdDevice.getId());
        if (defaultEgressPort == null) {
            try {
                Response res = getResponse(sdDevice.getIpAddress(), allPortsUrl);
                if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                    JSONObject responseJson = getJsonFromResponse(res);
                    JSONArray portsJson = (JSONArray) (responseJson.has(PORT_CONFIG) ? responseJson.get(PORT_CONFIG) : new JSONArray());
                    JSONObject portJson = null;
                    for (int i = 0; i < portsJson.length(); i++) {
                        Object portObj = portsJson.get(i);
                        portJson = new JSONObject(portObj.toString());
                        if (portJson.has(NAME) && DEFAULT_PORT.equals(portJson.get(NAME))) {
                            defaultEgressPort = new EgressPort();
                            defaultEgressPort.setDevice(sdDevice);
                            Iterator<String> keysItr = portJson.keys();
                            defaultEgressPort.setName(DEFAULT_PORT);
                            if (portJson.has(IMSI_LIMIT)) {
                                String imsiLimit = String.valueOf(portJson.get(IMSI_LIMIT));
                                if (NO_LIMIT.equals(imsiLimit)) {
                                    imsiLimit = "0";
                                }
                                defaultEgressPort.setImsiLimit(imsiLimit);
                            }
                            defaultEgressPort.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                            defaultEgressPort.setDefault(true);
                            while (keysItr.hasNext()) {
                                String key = keysItr.next();
                                String value = String.valueOf(portJson.get(key));
                                if (LB_ALGO.equals(key)) {
                                    if (value.equals(EgressPort.LoadBalanceAlgorithms.HASH.getName())) {
                                        defaultEgressPort.setLoadBalance(EgressPort.LoadBalanceAlgorithms.HASH);
                                    } else {
                                        defaultEgressPort.setLoadBalance(EgressPort.LoadBalanceAlgorithms.ROUND_ROBIN);
                                    }
                                } else if (VLAN_IDS.equals(key)) {
                                    String[] vlanArray = value.split(",");
                                    Set<Long> vlanIds = Sets.newHashSet();
                                    for (String vlan : vlanArray) {
                                        if (!vlan.trim().isEmpty()) {
                                            vlanIds.add(Long.parseLong(vlan.trim()));
                                        }
                                    }
                                    if (vlanIds.size() > 0) {
                                        Set<SdPortVlanMapping> sdPortVlanMappings = new HashSet<>();
                                        for (Long vlan : vlanIds) {
                                            SdPortVlanMapping sdPortVlanMapping = new SdPortVlanMapping();
                                            sdPortVlanMapping.setVlanId(vlan);
                                            sdPortVlanMapping.setTagged(true);
                                            sdPortVlanMappings.add(sdPortVlanMapping);
                                        }
                                        defaultEgressPort.addVlanMappings(sdPortVlanMappings);
                                    }
                                }
                            }
                            egressPorts.add(defaultEgressPort);

                        }
                    }
                } else {
                    log.error("SD REST Response for ports@all unsuccessful for SD device {}.", sdDevice.getId());
                }
            } catch (Exception e) {
                log.error("Error occurred while saving the default Egress Port for SD device {} :{} ", sdDevice.getId(), e.getMessage());
            }
        } else {
            egressPorts.add(defaultEgressPort);
        }
        return egressPorts;
    }

    /**
     * This method sends request to SD REST API and extracts and save the default egress port group from the response
     *
     * @param sdDevice
     */
    public void saveDefaultEgressPortGroup(Device sdDevice) {
        SdPortGroup defaultEgressPortGroupDb = egressPortGroupRepository.findByIsDefaultTrueAndDeviceId(sdDevice.getId());
        if (defaultEgressPortGroupDb == null) {
            try {
                Response res = getResponse(sdDevice.getIpAddress(), allPortGroupUrl);
                if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                    JSONObject responseJson = getJsonFromResponse(res);
                    JSONArray portGroupJsonArray = (JSONArray) (responseJson.has(PORT_GROUP) ? responseJson.get(PORT_GROUP) : new JSONArray());
                    JSONObject portGroupJson = null;
                    for (int i = 0; i < portGroupJsonArray.length(); i++) {
                        Object portObj = portGroupJsonArray.get(i);
                        portGroupJson = new JSONObject(portObj.toString());
                        if (portGroupJson.has(NAME) && DEFAULT_PORT_GROUP.equals(portGroupJson.get(NAME))) {
                            SdPortGroup defaultEgressPortGroup = new SdPortGroup();
                            defaultEgressPortGroup.setDevice(sdDevice);
                            Iterator<String> keysItr = portGroupJson.keys();
                            defaultEgressPortGroup.setName(DEFAULT_PORT_GROUP);
                            defaultEgressPortGroup.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                            defaultEgressPortGroup.setDefault(true);
                            while (keysItr.hasNext()) {
                                String key = keysItr.next();
                                String value = String.valueOf(portGroupJson.get(key));
                                if (LB_ALGO.equals(key)) {
                                    if (value.equals(EgressPort.LoadBalanceAlgorithms.HASH.getName())) {
                                        defaultEgressPortGroup.setLoadBalance(SdPortGroup.LoadBalanceAlgorithms.HASH);
                                    } else {
                                        defaultEgressPortGroup.setLoadBalance(SdPortGroup.LoadBalanceAlgorithms.ROUND_ROBIN);
                                    }
                                } else if (PORTS.equals(key)) {
                                    Set<EgressPort> egressPorts = getDefaultEgressPort(sdDevice);
                                    if (egressPorts.size() > 0) {
                                        defaultEgressPortGroup.setEgressPorts(egressPorts);
                                    }
                                }
                            }
                            egressPortGroupRepository.save(defaultEgressPortGroup);
                            log.debug("Default Egress port updated successful for SD device {}.", sdDevice.getId());
                            log.debug("Default Egress portGroup updated successful for SD device {}.", sdDevice.getId());
                        }
                    }
                } else {
                    log.error("SD REST Response for ports-group@all unsuccessful for SD device {}.", sdDevice.getId());
                }
            } catch (Exception e) {
                log.error("Error occurred while saving the egress port group for SD device {} :{} ", sdDevice.getId(), e.getMessage());
            }
        }
    }

    /**
     * This method is used for inserting dedupe Policy available on device
     *
     * @param device
     */
    public void saveDedupePolicy(Device device) {
        List<DeDupePolicy> dupePolicies = dedupePolicyRepository.findAllByDeviceId(device.getId());
        if (dupePolicies.isEmpty()) {
            try {
                Response res = getResponse(device.getIpAddress(), allDedupePolicy);
                if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                    device.setLastUpdatedTime(null);
                    device.setLastCollectedTime(null);
                    JSONObject responseJson = getJsonFromResponse(res);
                    JSONArray policyJsonArray = (JSONArray) (responseJson.has(DEDUPE_POLICY) ? responseJson.get(DEDUPE_POLICY) : new JSONArray());
                    JSONObject policyObj = null;
                    for (int i = 0; i < policyJsonArray.length(); i++) {
                        Object dedupePolicyObj = policyJsonArray.get(i);
                        policyObj = new JSONObject(dedupePolicyObj.toString());
                        if (policyObj.has(POLICY_NAME)) {
                            DeDupePolicy policy = new DeDupePolicy();
                            policy.setName(policyObj.get(POLICY_NAME).toString());
                            policy.setWorkflowType(Job.Type.SD_DEDUPE_POLICY_CREATE);
                            policy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                            policy.setTimeout(DeDupePolicy.DEFAULT_TIMEOUT);
                            policy.setDevice(device);
                            dupePolicies.add(policy);
                        }
                    }
                    dedupePolicyRepository.save(dupePolicies);
                    log.debug("Dedupe Policy updated successful for SD device {}.", device.getId());
                } else {
                    log.error("SD REST Response for dedupe-policy unsuccessful for SD device {}.", device.getId());
                }
            } catch (Exception e) {
                log.error("Error occurred while saving the dedupe policy for SD device {} {}", device.getId(), e.getMessage());
            }
        }
    }

    /**
     * Method saves the physical interface for the selected SD device
     *
     * @param sdDevice
     */
    public void savePhysicalInterface(Device sdDevice) {
        List<PhysicalInterface> existingPhysicalInterfaces = physicalInterfaceRepository.findByDeviceId(sdDevice.getId());
        List<PhysicalInterface> newPhysicalInterfaces = Lists.newArrayList(getPhysicalInterface(sdDevice));
        if ((existingPhysicalInterfaces == null || existingPhysicalInterfaces.isEmpty()) && !newPhysicalInterfaces.isEmpty()) {
            physicalInterfaceRepository.save(newPhysicalInterfaces);
            log.debug("Physical Interfaces saved successfully for SD device {}.", sdDevice.getId());
        } else {
            Set<PhysicalInterface> addedPorts = new HashSet<>(newPhysicalInterfaces);
            Set<PhysicalInterface> removedPorts = new HashSet<>(existingPhysicalInterfaces);
            Set<PhysicalInterface> existingPhysicalInterface = new HashSet<>();
            for (PhysicalInterface physicalInterface : existingPhysicalInterfaces) {
                newPhysicalInterfaces.forEach(newInterface -> {
                    if (physicalInterface.getName().equals(newInterface.getName()) && physicalInterface.getSpeed().equals(newInterface.getSpeed())) {
                        existingPhysicalInterface.add(physicalInterface);
                    }
                });
            }
            removedPorts.removeAll(existingPhysicalInterface);
            newPhysicalInterfaces.forEach(newInterface -> {
                existingPhysicalInterface.forEach(sameInterface -> {
                    if (newInterface.getName().equals(sameInterface.getName()) && newInterface.getSpeed().equals(sameInterface.getSpeed())) {
                        addedPorts.remove(newInterface);
                    }
                });
            });
            if (!addedPorts.isEmpty()) {
                physicalInterfaceRepository.save(addedPorts);
                log.debug("Physical Interfaces added : {}  for device {}.", addedPorts.stream().map(PhysicalInterface::getId).collect(Collectors.toSet()), sdDevice.getId());
            }
            if (!removedPorts.isEmpty()) {
                removedPorts.forEach(physicalInterfaceToDelete -> {
                    List<IngressPort> ingressPorts = ingressPortRepository.findByPhysicalInterfaceIdAndDeviceId(physicalInterfaceToDelete.getId(), sdDevice.getId());
                    ingressPorts.forEach(ingress -> {
                        ingress.setPhysicalInterface(null);
                        ingressPortRepository.save(ingress);
                    });
                });
                physicalInterfaceRepository.delete(removedPorts);
                log.debug("Physical Interfaces deleted : {}  for device {}.", removedPorts.stream().map(PhysicalInterface::getId).collect(Collectors.toSet()), sdDevice.getId());
            }
        }
    }

    /**
     * Retrieve the physical interface list for the selected SD device
     *
     * @param sdDevice
     * @return
     */
    private Set<PhysicalInterface> getPhysicalInterface(Device sdDevice) {
        Set<PhysicalInterface> physicalInterfaceSet = new HashSet<>();
        try {
            Response res = getResponse(sdDevice.getIpAddress(), physicalInterfaceUrl);
            if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                JSONObject responseJson = getJsonFromResponse(res);
                JSONArray interfaceJsonArray = (JSONArray) (responseJson.has(INTERFACES) ? responseJson.get(INTERFACES) : new JSONArray());
                if (interfaceJsonArray != null && interfaceJsonArray.length() > 0) {
                    Object interfaceObj = interfaceJsonArray.get(0);
                    JSONObject interfaceJson = new JSONObject(interfaceObj.toString());
                    if (interfaceObj != null) {
                        Iterator keyIterator = interfaceJson.keys();
                        while (keyIterator.hasNext()) {
                            Object key = keyIterator.next();
                            if (key != null) {
                                PhysicalInterface physicalInterface = new PhysicalInterface();
                                physicalInterface.setName(String.valueOf(key));
                                if (interfaceJson.has(key.toString())) {
                                    physicalInterface.setSpeed(String.valueOf(interfaceJson.get(key.toString())));
                                }
                                physicalInterface.setDevice(sdDevice);
                                physicalInterfaceSet.add(physicalInterface);
                            }
                        }
                    }
                }
                return physicalInterfaceSet;
            } else {
                log.error("SD REST Response for SD physical interfaces {} for SD device {}.", res != null ? res.getStatus() : "unsuccessful", sdDevice.getId());
            }
        } catch (Exception e) {
            log.error("Error occurred while retrieving the SD device {} physical interfaces {}.", sdDevice.getId(), e.getMessage());
        }
        return physicalInterfaceSet;
    }

    /**
     * This method initiates SD Rest Call and returns the Response
     *
     * @param ipAddress
     * @param url
     * @return
     */
    private Response getResponse(String ipAddress, String url) {
        sessionDirectorConnection.setBaseUrl(ipAddress);
        return sessionDirectorConnection.get(url);
    }

    /**
     * This method extracts the response and sends the JSON Object of it
     *
     * @param res
     * @return
     * @throws JSONException
     */
    private JSONObject getJsonFromResponse(Response res) throws JSONException {
        String responseString = res.readEntity(String.class);
        return new JSONObject(responseString);
    }
}
