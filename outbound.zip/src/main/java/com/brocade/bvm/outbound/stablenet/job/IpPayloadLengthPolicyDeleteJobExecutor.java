package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.db.Job;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class IpPayloadLengthPolicyDeleteJobExecutor extends AbstractIpPayloadLengthPolicyJobExecutor {

    /**
     * This method constructs delete IpPayloadLengthPolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        IpPayloadLengthPolicy payloadLengthPolicy = (IpPayloadLengthPolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        payloadLengthPolicy.getModules().forEach(module -> {
            if (IPV4.equals(payloadLengthPolicy.getIpType().name()))
                command.append(REVERT).append(String.format(IPV4_IP_PAYLOAD_LENGHT, module.getModuleNumber(), getProcessorCommand(payloadLengthPolicy), ""));
            else if (IPV6.equals(payloadLengthPolicy.getIpType().name()))
                command.append(REVERT).append(String.format(IPV6_IP_PAYLOAD_LENGHT, module.getModuleNumber(), getProcessorCommand(payloadLengthPolicy), ""));
        });
        command.append(EXIT);
        command.append(WRITE_MEMORY);
        log.debug("IpPayloadLengthPolicyDelete on Device-ID {} and command {} ", payloadLengthPolicy.getDevice().getId(), command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.IP_PAYLOAD_LENGTH_POLICY_DELETE);
    }

}
