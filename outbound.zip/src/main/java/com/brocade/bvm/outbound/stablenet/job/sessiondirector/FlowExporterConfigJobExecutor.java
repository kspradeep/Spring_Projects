
package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.FlowExporterHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.FlowExporterRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.FlowExporterHistory;
import com.brocade.bvm.model.db.sessiondirector.FlowExporter;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;


/*
 * Executor file for processing SD Collector Client side configuration
 */


@Slf4j
@Named
public class FlowExporterConfigJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private FlowExporterRepository flowExporterRepository;

    @Inject
    private FlowExporterHistoryRepository flowExporterHistoryRepository;

    protected static final String FLOW_EXPORTER = "flow-exporter;";

    protected static final String SET_FLOW_EXPORTER = "set flow-export-port=%s;";

    protected static final String ADD_COLLECTOR = "add collector name=%s ip=%s transport=%s port=%d;";

    protected static final String SET_CPLANE_TIMMER = "set cplane-idle-timer=%d;";

    protected static final String SET_PEN = "set pen=%d;";

    protected static final String DELETE_COLLECTOR_NAME = "del collector name=%s;";

    protected static final String CLEAR_CPLANE_TIMMER = "clear cplane-idle-timer;";

    protected static final String CLEAR_FLOW_EXPORTER = "clear flow-export-port;";

    protected static final String CLEAR_PEN = "clear pen;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_UPDATE_FLOW_CONFIG, Job.Type.SD_CREATE_FLOW_EXPORTER, Job.Type.SD_DELETE_FLOW_CONFIG);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    /* This method builds commands to Create/Update/Delete for Flow exporter
    * @param job
    * @return
    */
    @Override
    public String getCommands(Job job) {
        log.debug("Start : FlowExporterConfig");
        FlowExporter collectorConfiguration = flowExporterRepository.findByDeviceId(job.getDevice().getId());
        job.setParentObjectId(collectorConfiguration.getId());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        if (job.getType().equals(Job.Type.SD_CREATE_FLOW_EXPORTER)) {
            command.append(createCommand(collectorConfiguration));
        } else if (job.getType().equals(Job.Type.SD_UPDATE_FLOW_CONFIG)) {
            FlowExporter collectorConfigFromHistory = getFlowExporterFromHistory(collectorConfiguration);
            command.append(deleteCommand(collectorConfigFromHistory));//get from the history and delete the existing collector
            command.append(createCommand(collectorConfiguration));//Add or create new collector with updated details
        } else {
            command.append(deleteCommand(collectorConfiguration));
        }
        command.append(EXIT);
        log.debug("End : FlowExporterConfig");
        return command.toString();
    }

    /* Generates set of commands to add new Collector configuration
     * @param collectorConfiguration
     * @return
     */
    private String createCommand(FlowExporter collectorConfiguration) {
        log.debug("Start : Create FlowExporterConfig");
        StringBuilder command = new StringBuilder(FLOW_EXPORTER);
        command.append(String.format(SET_FLOW_EXPORTER, collectorConfiguration.getSdManagementPort().getName()));
        command.append(String.format(ADD_COLLECTOR, collectorConfiguration.getName(), collectorConfiguration.getIpAdress(), collectorConfiguration.getTransportType().getName(), collectorConfiguration.getSdTransportPort()));
        //commenting below commands as of now SD is not supporting cplane-timmer and value instead persists the default values
        /*command.append(String.format(SET_CPLANE_TIMMER, collectorConfiguration.getCPlaneIdleTimer()));
        command.append(String.format(SET_PEN, collectorConfiguration.getPen()));*/
        command.append(EXIT);
        log.debug("End : Create FlowExporterConfig");
        return command.toString();
    }

 /* Generates set of commands to Delete existing Collector configuration
  * @param collectorConfiguration
  * @return
  */

    private String deleteCommand(FlowExporter collectorConfiguration) {
        log.debug("Start : Delete FlowExporterConfig");
        StringBuilder command = new StringBuilder(FLOW_EXPORTER);
        command.append(String.format(DELETE_COLLECTOR_NAME, collectorConfiguration.getName()));
        command.append(CLEAR_CPLANE_TIMMER);
        command.append(CLEAR_FLOW_EXPORTER);
        command.append(CLEAR_PEN);
        command.append(EXIT);
        log.debug("End : Delete FlowExporterConfig cmnd:{}", command);
        return command.toString();
    }

    protected FlowExporter getFlowExporterFromHistory(FlowExporter flowExporter) {
        // get the previous policy name from the history.
        FlowExporter flowExporterFromHistory = null;
        List<FlowExporterHistory> flowExporterFromHistoryList = flowExporterHistoryRepository.findByIdAndWorkflowStatus(flowExporter.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (!flowExporterFromHistoryList.isEmpty()) {
            FlowExporterHistory oldConfig = flowExporterFromHistoryList.get(0);
            flowExporterFromHistory = oldConfig.buildParent();
        }
        return flowExporterFromHistory;
    }
}

