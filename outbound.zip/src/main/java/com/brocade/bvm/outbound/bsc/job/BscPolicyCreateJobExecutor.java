package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import com.brocade.bvm.outbound.exception.InterfaceMissingException;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The BscPolicyCreateJobExecutor class implements methods to COMMIT Policy through BSC on Open flow device
 */
@Slf4j
@Named
public class BscPolicyCreateJobExecutor extends BscPolicyDeleteJobExecutor {

    @Inject
    private DeviceRepository deviceRepository;

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_CREATE);
    }

    @Override
    public Long startExternalJob(Job job) {
        //not required for Bsc
        return null;
    }

    /**
     * This method is used to CREATE policy on device through BSC REST API
     *
     * @param job
     * @return
     */
    @Override
    public OutboundJobResponse execute(Job job) {

        Policy policyToApply = (Policy) getParentObject(job);
        String openFlowId = job.getDevice().getOpenflowId();
        Long deviceId = job.getDevice().getId();
        Map<String, Set<String>> flowIdNameMap = getFlowInfo(openFlowId);
        Map<String, Set<String>> grpIdNameMap = getGroupInfo(openFlowId);
        log.info("grpIdNameMap : " + grpIdNameMap);
        log.info("flowIdNameMap : " + flowIdNameMap);
        //TODO: Remove the openflow id for port enrichment call
        Map<String, String> portIdNameMap = getPortNameIdMap(openFlowId);
        log.info("portIdNameMap : " + portIdNameMap);

        Set<String> grpIds = grpIdNameMap.get("ids");
        log.info("grpIds : " + grpIds);
        Set<String> flowIds = flowIdNameMap.get("ids");
        List<String> operationalFlowIds = getOperationalFlowInfo(openFlowId);
        flowIds.addAll(operationalFlowIds);
        log.info("flowIds : " + flowIds);
        boolean jobResult = false;
        // iterate for each flow in a policy
        for (Flow eachFlow : policyToApply.getFlows()) {
            int flowPriority = eachFlow.getSequence();
            String vlan = eachFlow.getVlans().size() > 0 ? eachFlow.getVlans().stream().findFirst().get() : null;
            String srcMacTag = eachFlow.getSourceMacTag();
            String destMacTag = eachFlow.getDestinationMacTag();
            Set<String> egressSet = eachFlow.getEgressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            Set<String> ingressSet = eachFlow.getIngressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            try {

                Set<String> ports = new HashSet<String>(egressSet);
                ports.addAll(ingressSet);
                checkIfValidInterface(portIdNameMap, ports);

            } catch (InterfaceMissingException e) {
                return new OutboundJobResponse(Job.Status.FAILED, e.getMessage());
            }
            Set<PortGroup> portGroups = eachFlow.getIngressPortGroups();
            for (PortGroup portGroup : portGroups) {
                ingressSet.addAll(portGroup.getPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
            }

            jobResult = addPolicyOnDecvice(deviceId, openFlowId, policyToApply.getName(), policyToApply.getId(), portIdNameMap, grpIds, flowIds, egressSet,
                    ingressSet, eachFlow.getEgressPortGroups(), eachFlow.getRuleSets(), flowPriority, vlan, srcMacTag, destMacTag, eachFlow.getVlanStripping());

            log.debug("Flow creation for sequence: {} with status:{}", eachFlow.getSequence(), jobResult);
            if (!jobResult) {
                log.error("Exiting the Policy creation as the flow with sequence: {} is failed", eachFlow.getSequence());
                break;
            }
        }

        if (jobResult) {
            return new OutboundJobResponse(Job.Status.SUCCESS, "Policy Creation Successful on Device");
        } else {
            return new OutboundJobResponse(Job.Status.FAILED, "Policy Creation Failed on Device");
        }
        //TODO: Any job result has to be set ?

    }

}
