package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class GtpDeEncapsulationCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String portNumber;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "configure terminal;interface ethernet %s";
    private static final String SHOW_CMD = "show running-config interface ethernet %s";
    private static final String MATCH_CMD = "gtp-de-encapsulation";
    private static final String ACTION_CMD = "no gtp-de-encapsulation";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, portNumber));
        args.add(String.format(SHOW_CMD, portNumber));
        args.add(MATCH_CMD);
        args.add(ACTION_CMD);
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "GtpDeEncapsulationCommandBlock [deviceId=" + deviceId + ", portNumber=" + portNumber + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
