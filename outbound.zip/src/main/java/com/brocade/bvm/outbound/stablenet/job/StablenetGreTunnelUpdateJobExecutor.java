package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.TunnelDevicePolicyRepository;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.TunnelDevicePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

/**
 * The StablenetGreTunnelUpdateJobExecutor class implements methods to enable/disable GRE Tunnel on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetGreTunnelUpdateJobExecutor extends AbstractGreTunnelJobExecutor {

    @Inject
    private TunnelDevicePolicyRepository tunnelDevicePolicyRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GRE_TUNNEL_UPDATE);
    }

    /**
     * This method constructs commands to enable/disable GRE Tunnel on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        TunnelDevicePolicy tunnelDevicePolicy = (TunnelDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        if (tunnelDevicePolicy != null && tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.GRE) {
            command.append(CONFIGURE_TERMINAL);
            command.append(String.format(TUNNEL_CONFIG, tunnelDevicePolicy.getName()));
            if (tunnelDevicePolicy.isEnabled()) {
                command.append(TUNNEL_ENABLE);
            } else {
                command.append(TUNNEL_DISABLE);
            }
            command.append(EXIT);
            command.append(WRITE_MEMORY);
        } else {
            log.error("IP GRE Tunnel entity is null!");
        }
        log.trace("Command = " + command.toString());
        return command.toString();
    }
}
