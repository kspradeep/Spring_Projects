package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kraikar on 8/5/2016.
 */
public class UnMapPortFromGTPProfileCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String profileName;

    @Getter
    @Setter
    private Long profileId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * argument #1 is GTP profile name
     * argument #2 is GTP profile id
     * gtp 'gtp profile name' 'gtp profile id'
     * </pre>
     */
    private static final String PRE_CMD = "conf t;gtp %s %s;";

    /**
     * <pre>
     * argument #1 is GTP profile name
     * argument #2 is Port number
     * argument #3 is Port number
     * eg: show gtp name 'gtp profile name' 'gtp profile id' | include 'port number' | 'port number'$
     * </pre>
     */
    private static final String SHOW_CMD = "sh gtp name %s | inc %s |%s$";

    /**
     * <pre>
     * eg: port number 1/1
     * </pre>
     */
    private static final String MATCH_CMD = "%s |%s$";

    /**
     * <pre>
     * eg: no ports ethernet 1/1
     * </pre>
     */
    private static final String ACTION_CMD = "no ports e %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, profileName, profileId));
        args.add(String.format(SHOW_CMD, profileName, port, port));
        args.add(String.format(MATCH_CMD, port, port));
        args.add(String.format(ACTION_CMD, port));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "UnMapPortFromGTPProfileCommandBlock{" +
                "deviceId=" + deviceId +
                ", profileName='" + profileName + '\'' +
                ", profileId=" + profileId +
                ", port='" + port + '\'' +
                ", writeMem='" + writeMem + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UnMapPortFromGTPProfileCommandBlock)) return false;

        UnMapPortFromGTPProfileCommandBlock that = (UnMapPortFromGTPProfileCommandBlock) o;

        if (getDeviceId() != null ? !getDeviceId().equals(that.getDeviceId()) : that.getDeviceId() != null)
            return false;
        if (getProfileName() != null ? !getProfileName().equals(that.getProfileName()) : that.getProfileName() != null)
            return false;
        if (getProfileId() != null ? !getProfileId().equals(that.getProfileId()) : that.getProfileId() != null)
            return false;
        if (getPort() != null ? !getPort().equals(that.getPort()) : that.getPort() != null) return false;
        return getWriteMem() != null ? getWriteMem().equals(that.getWriteMem()) : that.getWriteMem() == null;

    }

    @Override
    public int hashCode() {
        int result = getDeviceId() != null ? getDeviceId().hashCode() : 0;
        result = 31 * result + (getProfileName() != null ? getProfileName().hashCode() : 0);
        result = 31 * result + (getProfileId() != null ? getProfileId().hashCode() : 0);
        result = 31 * result + (getPort() != null ? getPort().hashCode() : 0);
        result = 31 * result + (getWriteMem() != null ? getWriteMem().hashCode() : 0);
        return result;
    }
}
