package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.TunnelDevicePolicyRepository;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.TunnelDevicePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

/**
 * The StablenetMplsTunnelUpdateJobExecutor class implements methods to enable/disable MPLS Tunnel on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetMplsTunnelUpdateJobExecutor extends AbstractMplsTunnelJobExecutor {

    @Inject
    private TunnelDevicePolicyRepository tunnelDevicePolicyRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.MPLS_TUNNEL_UPDATE);
    }

    /**
     * This method constructs commands to enable/disable MPLS Tunnel on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        TunnelDevicePolicy tunnelDevicePolicy = (TunnelDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        if (tunnelDevicePolicy != null && tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) {
            command.append(CONFIGURE_TERMINAL);
            command.append(ROUTER_MPLS);
            command.append(String.format(MPLS_TUNNEL_CONFIG, tunnelDevicePolicy.getName()));
            if(tunnelDevicePolicy.isEnabled()){
                command.append(TUNNEL_ENABLE);
            } else {
                command.append(TUNNEL_DISABLE);
            }
            command.append(EXIT);
            command.append(EXIT);
            command.append(WRITE_MEMORY);
        } else {
            log.error("MPLS Tunnel entity is null!");
        }
        log.trace("Command = " + command.toString());
        return command.toString();
    }
}
