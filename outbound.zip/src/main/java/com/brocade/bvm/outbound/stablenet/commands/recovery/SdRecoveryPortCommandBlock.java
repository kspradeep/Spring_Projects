package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the command blocks to recover the ports from SD
 *
 */
public class SdRecoveryPortCommandBlock  implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * configure terminal
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal\nport\n";
    /**
     * <pre>
     * argument #1 is port-group name
     * eg: show port-group=pg1
     * </pre>
     */
    private static final String SHOW_CMD = "show port=%s";
    /**
     * <pre>
     * argument #1 is port-group name
     * eg: pg1
     * </pre>
     */
    private static final String MATCH_CMD = "name  : %s$";
    /**
     * <pre>
     * argument #1 is port-group name
     * eg: del port-group pg1
     * </pre>
     */
    private static final String ACTION_CMD = "del port=%s\nexit\nexit\n";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, name));
        args.add(String.format(MATCH_CMD, name));
        args.add(String.format(ACTION_CMD, name));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SdRecoveryPortCommandBlock [deviceId=" + deviceId + ", name=" + name + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
