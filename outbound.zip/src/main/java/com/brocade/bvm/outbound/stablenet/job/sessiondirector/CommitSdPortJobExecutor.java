package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This class builds commands to create Egress Port
 */

@Slf4j
@Named
public class CommitSdPortJobExecutor extends AbstractSdPortJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_EGRESS_PORT_CREATE);
    }

    /**
     * This method builds commands to create Egress Port
     *
     * @param job
     * @return
     */
    @Override
    public String getCommands(Job job) {
        Set<EgressPort> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof EgressPort)
                .map(mo -> (EgressPort) mo)
                .collect(Collectors.toSet());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(buildCreateCommand(ports));
        command.append(EXIT);
        log.info("Stablenet command generated from Job Id{} on device{} for creating SD Egress Port is {}", job.getId(), job.getDevice().getId(), command);
        return command.toString();
    }
}
