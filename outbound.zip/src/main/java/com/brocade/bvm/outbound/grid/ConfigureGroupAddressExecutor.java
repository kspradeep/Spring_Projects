package com.brocade.bvm.outbound.grid;

import com.brocade.bvm.dao.grid.GridMatrixHistoryRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.grid.DestinationGroup;
import com.brocade.bvm.model.db.grid.GridMatrix;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Named
@Slf4j
public class ConfigureGroupAddressExecutor extends AbstractStablenetJobExecutor {

    //[no]pbf-destination-group NUMBER
    private static final String PBF_DESTINATION_GROUP = "pbf destination-group %d;";

    private static final String NO_PBF_DESTINATION_GROUP = "no pbf destination-group %d;";

    //[no]add pbf-destination [ID |]
    private static final String ADD_PBF_DESTINATION = "add destination %s;";

    private static final String REMOVE_PBF_DESTINATION = "remove destination %s;";

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridMatrixHistoryRepository gridMatrixHistoryRepository;

    /**
     * This method constructs CLI to configure the tool address on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();
        GridMatrix gridMatrix = (GridMatrix) getParentObject(job);
        Device device = job.getDevice();

        command.append(CONFIGURE_TERMINAL);
        if(gridMatrix != null) {
            if (job.getType() == Job.Type.GRID_TOOL_GROUP_UPDATE_ADD) {
                GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                command.append(updateToolGroupAddress(gridMatrix, gridMatrixHistory, device.getId(), true));
            } else if (job.getType() == Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE) {
                GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                command.append(updateToolGroupAddress(gridMatrix, gridMatrixHistory, device.getId(), false));
            } else {
                Map<Integer, Set<Integer>> groupToolAddressesMap = getToolGroupMap(gridMatrix.getDestinationGroups(), gridMatrix.getGridTopologyPaths(), device.getId());
                groupToolAddressesMap.forEach((groupId, toolAddressSet) -> {
                    if (job.getType() == Job.Type.GRID_TOOL_GROUP_CREATE) {
                        command.append(createToolGroupAddress(toolAddressSet, groupId));
                    } else if (job.getType() == Job.Type.GRID_TOOL_GROUP_DELETE) {
                        command.append(removeToolGroupAddress(toolAddressSet, groupId));
                    }
                });
            }
        }
        command.append(EXIT);
        log.debug("ConfigureToolGroupAddressExecutor on device: {} command:{} ", device.getId(), command.toString());
        return command.toString();
    }

    private String createToolGroupAddress(Set<Integer> toolAddressSet, Integer groupId) {
        StringBuilder command = new StringBuilder();
        if (toolAddressSet != null && !toolAddressSet.isEmpty()) {
            StringBuilder toolAddressStringBuilder = new StringBuilder();
            toolAddressSet.forEach(toolAddress -> toolAddressStringBuilder.append(toolAddress).append(","));
            if (toolAddressStringBuilder.length() > 0) {
                command.append(String.format(PBF_DESTINATION_GROUP, groupId));
                command.append(String.format(ADD_PBF_DESTINATION, toolAddressStringBuilder.deleteCharAt(toolAddressStringBuilder.length() - 1)));
                command.append(EXIT);
            }
        }
        return command.toString();
    }

    private String updateToolGroupAddress(GridMatrix gridMatrix, GridMatrix gridMatrixHistory, Long deviceId, boolean isAdd) {
        StringBuilder command = new StringBuilder();
        if (gridMatrix != null && gridMatrixHistory != null) {
            Map<Integer, Set<Integer>> groupToolAddressesMap = getToolGroupMap(gridMatrix.getDestinationGroups(), gridMatrix.getGridTopologyPaths(), deviceId);
            Map<Integer, Set<Integer>> groupToolAddressesHistoryMap = getToolGroupMap(gridMatrixHistory.getDestinationGroups(), gridMatrixHistory.getGridTopologyPaths(), deviceId);
            if (groupToolAddressesMap != null && groupToolAddressesHistoryMap != null) {
                if (!isAdd) {
                    groupToolAddressesHistoryMap.forEach((groupId, toolAddressSetExisting) -> {
                        Set<Integer> toolAddressSetUpdated = groupToolAddressesMap.get(groupId);
                        if (toolAddressSetUpdated != null && !toolAddressSetUpdated.isEmpty() && toolAddressSetExisting != null && !toolAddressSetExisting.isEmpty()) {
                            Set<Integer> toolAddressAdded = Sets.difference(toolAddressSetUpdated, toolAddressSetExisting);
                            Set<Integer> toolAddressDeleted = Sets.difference(toolAddressSetExisting, toolAddressSetUpdated);
                            command.append(updateToolGroupAddress(toolAddressAdded, toolAddressDeleted, groupId, isAdd));
                        }
                        if (toolAddressSetUpdated == null || toolAddressSetUpdated.isEmpty()) {
                            command.append(removeToolGroupAddress(toolAddressSetExisting, groupId));
                        }
                    });
                } else {
                    groupToolAddressesMap.forEach((groupId, toolAddressSetUpdated) -> {
                        Set<Integer> toolAddressSetExisting = groupToolAddressesHistoryMap.get(groupId);
                        if (toolAddressSetUpdated != null && !toolAddressSetUpdated.isEmpty() && toolAddressSetExisting != null && !toolAddressSetExisting.isEmpty()) {
                            Set<Integer> toolAddressAdded = Sets.difference(toolAddressSetUpdated, toolAddressSetExisting);
                            Set<Integer> toolAddressDeleted = Sets.difference(toolAddressSetExisting, toolAddressSetUpdated);
                            command.append(updateToolGroupAddress(toolAddressAdded, toolAddressDeleted, groupId, isAdd));
                        }
                        if (toolAddressSetExisting == null || toolAddressSetExisting.isEmpty()) {
                            command.append(createToolGroupAddress(toolAddressSetUpdated, groupId));
                        }
                    });
                }
            }
        }
        return command.toString();
    }

    private String updateToolGroupAddress(Set<Integer> toolAddressSetToAdd, Set<Integer> toolAddressSetToDelete, Integer groupId, boolean isAdd) {
        StringBuilder command = new StringBuilder();
        StringBuilder toolAddressStringToAdd = new StringBuilder();
        StringBuilder toolAddressStringToDelete = new StringBuilder();
        if (isAdd) {
            toolAddressSetToAdd.forEach(toolAddress -> toolAddressStringToAdd.append(toolAddress).append(","));
        } else {
            toolAddressSetToDelete.forEach(toolAddress -> toolAddressStringToDelete.append(toolAddress).append(","));
        }
        if (toolAddressStringToAdd.length() > 0 || toolAddressStringToDelete.length() > 0) {
            command.append(String.format(PBF_DESTINATION_GROUP, groupId));
            if (toolAddressStringToAdd.length() > 0)
                command.append(String.format(ADD_PBF_DESTINATION, toolAddressStringToAdd.deleteCharAt(toolAddressStringToAdd.length() - 1)));
            if (toolAddressStringToDelete.length() > 0)
                command.append(String.format(REMOVE_PBF_DESTINATION, toolAddressStringToDelete.deleteCharAt(toolAddressStringToDelete.length() - 1)));
            command.append(EXIT);
        }
        return command.toString();
    }

    private String removeToolGroupAddress(Set<Integer> toolAddressSet, Integer groupId) {
        StringBuilder command = new StringBuilder();
        if (toolAddressSet != null && !toolAddressSet.isEmpty()) {
            StringBuilder toolAddressStringBuilder = new StringBuilder();
            toolAddressSet.forEach(toolAddress -> toolAddressStringBuilder.append(toolAddress).append(","));
            if (toolAddressStringBuilder.length() > 0) {
                command.append(String.format(PBF_DESTINATION_GROUP, groupId));
                command.append(String.format(REMOVE_PBF_DESTINATION, toolAddressStringBuilder.deleteCharAt(toolAddressStringBuilder.length() - 1)));
                command.append(EXIT);
            }
            command.append(String.format(NO_PBF_DESTINATION_GROUP, groupId));
        }
        return command.toString();
    }

    private Map<Integer, Set<Integer>> getToolGroupMap(Set<DestinationGroup> destinationGroups, Set<GridTopologyPath> gridTopologyPaths, Long deviceId) {
        Map<Integer, Set<Integer>> groupToolAddressesMap = Maps.newHashMap();
        if (destinationGroups != null && gridTopologyPaths != null) {
            destinationGroups.stream().forEach(destinationGroup -> {
                Integer groupId = destinationGroup.getGroupId();
                destinationGroup.getGridTopologyPathIds().forEach(gridTopologyPathId -> {
                    Optional<GridTopologyPath> gridTopologyPathOptional = gridTopologyPaths.stream().filter(gridTopologyPath -> gridTopologyPath.getId() == gridTopologyPathId).findFirst();
                    if (gridTopologyPathOptional.isPresent()) {
                        GridTopologyPath gridTopologyPath = gridTopologyPathOptional.get();
                        if (gridTopologyPath != null && gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                            Set<Integer> toolAddressSet = Sets.newHashSet();
                            if (groupToolAddressesMap.containsKey(groupId)) {
                                toolAddressSet = groupToolAddressesMap.get(groupId);
                            }
                            toolAddressSet.add(gridTopologyPath.getToolAddress());
                            groupToolAddressesMap.put(groupId, toolAddressSet);
                        }
                    }
                });
            });
        }
        return groupToolAddressesMap;
    }

    private GridMatrix getGridMatrixFromHistory(Long matrixId) {
        GridMatrix gridMatrix = null;
        if(matrixId != null) {
            List<GridMatrixHistory> gridMatrixHistoryList = gridMatrixHistoryRepository.findByIdAndWorkflowStatus(matrixId, WorkflowParticipant.WorkflowStatus.ACTIVE);
            if (gridMatrixHistoryList.size() >= 1) {
                GridMatrixHistory gridMatrixHistory = gridMatrixHistoryList.get(0);
                gridMatrix = gridMatrixHistory.buildParent();
            }
        }
        return gridMatrix;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GRID_TOOL_GROUP_CREATE, Job.Type.GRID_TOOL_GROUP_DELETE, Job.Type.GRID_TOOL_GROUP_UPDATE_ADD, Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}