package com.brocade.bvm.outbound.stablenet.job;

/**
 * Created by kraikar on 8/10/2016.
 */
public abstract class AbstractGreTunnelJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String TUNNEL_CONFIG = "interface tunnel %s;";

    protected static final String TUNNEL_ENABLE = "enable;";

    protected static final String TUNNEL_DISABLE = "disable;";
}
