package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXPortLLDPCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * configure terminal
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is port id
     * eg: do show lldp interface Ethernet 0/1
     * </pre>
     */
    private static final String SHOW_CMD = "do show lldp interface ethernet %s";

    /**
     * <pre>
     * matching regex
     * </pre>
     */
    private static final String MATCH_CMD = "  State:                   Disabled";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: interface ethernet 1/1\n speed 100000\n no fec mode\n speed 40000;
     * </pre>
     */
    private static final String ACTION_CMD = "interface ethernet %s\nno lldp disable\nexit";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, port));
        args.add(String.format(MATCH_CMD, port));
        args.add(String.format(ACTION_CMD, port));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXPortLLDPCommandBlock [deviceId=" + deviceId + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
