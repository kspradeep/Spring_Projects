package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dneelapa on 10/25/2016.
 */
public class HeaderStrippingOs6CommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private boolean isPreserve;

    @Getter
    @Setter
    private HeaderStrippingModulePolicy.Headers header;

    @Getter
    @Setter
    private String processorNumber;

    @Getter
    @Setter
    private String moduleNumber;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "conf t;packet-encap-processing;";
    private static final String SHOW_802BR_CMD = "sh run | inc strip-802-1br";
    private static final String SHOW_VNTAG_CMD = "sh run | inc strip-vn-tag";
    private static final String SHOW_VXLAN_CMD = "sh run | inc strip-vxlan";
    private static final String SHOW_NVGRE_CMD = "sh run | in nvgre";
    private static final String MATCH_802BR_CMD = "strip-802-1br slot %s%s$";
    private static final String MATCH_VNTAG_CMD = "strip-vn-tag slot %s%s$";
    private static final String MATCH_VXLAN_CMD = "strip-vxlan slot %s%s$";
    private static final String MATCH_NVGRE_CMD = "strip-nvgre slot %s%s$";
    private static final String ACTION_802BR_CMD = "no strip-802-1br slot %s %s";
    private static final String ACTION_VNTAG_CMD = "no strip-vn-tag slot %s %s";
    private static final String ACTION_VXLAN_CMD = "no strip-vxlan slot %s %s";
    private static final String ACTION_NVGRE_CMD = "no strip-nvgre slot %s %s";

    private static final String SHOW_BYPASS_802BR_CMD = "sh run | inc bypass-802-1br";
    private static final String SHOW_BYPASS_VNTAG_CMD = "sh run | inc bypass-vn-tag";
    private static final String MATCH_BYPASS_802BR_CMD = "bypass-802-1br slot %s%s$";
    private static final String MATCH_BYPASS_VNTAG_CMD = "bypass-vn-tag slot %s%s$";
    private static final String ACTION_BYPASS_802BR_CMD = "no bypass-802-1br slot %s %s";
    private static final String ACTION_BYPASS_VNTAG_CMD = "no bypass-vn-tag slot %s %s";
    private static final String SPACE = " ";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        input.getArg().addAll(getCommand());
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    private List<String> getCommand() {
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        if (isPreserve()) {
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                args.add(SHOW_BYPASS_802BR_CMD);
                args.add(String.format(MATCH_BYPASS_802BR_CMD, moduleNumber, processorNumber.length() > 0 ? SPACE + processorNumber : processorNumber));
                args.add(String.format(ACTION_BYPASS_802BR_CMD, moduleNumber, processorNumber));
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                args.add(SHOW_BYPASS_VNTAG_CMD);
                args.add(String.format(MATCH_BYPASS_VNTAG_CMD, moduleNumber, processorNumber.length() > 0 ? SPACE + processorNumber : processorNumber));
                args.add(String.format(ACTION_BYPASS_VNTAG_CMD, moduleNumber, processorNumber));
            }
        } else { // if header stripping
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                args.add(SHOW_802BR_CMD);
                args.add(String.format(MATCH_802BR_CMD, moduleNumber, processorNumber.length() > 0 ? SPACE + processorNumber : processorNumber));
                args.add(String.format(ACTION_802BR_CMD, moduleNumber, processorNumber));
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                args.add(SHOW_VNTAG_CMD);
                args.add(String.format(MATCH_VNTAG_CMD, moduleNumber, processorNumber.length() > 0 ? SPACE + processorNumber : processorNumber));
                args.add(String.format(ACTION_VNTAG_CMD, moduleNumber, processorNumber));
            } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
                args.add(SHOW_VXLAN_CMD);
                args.add(String.format(MATCH_VXLAN_CMD, moduleNumber, processorNumber.length() > 0 ? SPACE + processorNumber : processorNumber));
                args.add(String.format(ACTION_VXLAN_CMD, moduleNumber, processorNumber));
            } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
                args.add(String.format(SHOW_NVGRE_CMD, moduleNumber));
                args.add(String.format(MATCH_NVGRE_CMD, moduleNumber, processorNumber));
                args.add(String.format(ACTION_NVGRE_CMD, moduleNumber, processorNumber));
            }
        }
        args.add(writeMem);
        return args;
    }

}
