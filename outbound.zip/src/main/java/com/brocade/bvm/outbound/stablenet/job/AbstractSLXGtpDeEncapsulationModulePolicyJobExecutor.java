package com.brocade.bvm.outbound.stablenet.job;


import com.brocade.bvm.model.db.Device;
import com.google.common.collect.Lists;

import java.util.List;

public abstract class AbstractSLXGtpDeEncapsulationModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    protected static final String GTP_DE_ENCAPSULATION = "gtp-de-encapsulation;exit;";

    protected static final String NO_GTP_DE_ENCAPSULATION = "no gtp-de-encapsulation;exit;";

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

}
