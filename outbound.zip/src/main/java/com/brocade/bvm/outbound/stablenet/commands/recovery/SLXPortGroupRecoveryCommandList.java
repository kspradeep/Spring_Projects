package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortHistory;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named
public class SLXPortGroupRecoveryCommandList {

    @Inject
    private PortHistoryRepository portHistoryRepository;

    public List<CommandBlock> constructCommandBlockList(PortGroup portGroup) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        for (Port port : portGroup.getPorts()) {
            List<PortHistory> portHistories = portHistoryRepository.findByIdAndWorkflowStatus(port.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);

            PortHistory portFromHistory = null;
            if (!portHistories.isEmpty() && portHistories.size() > 1) {
                portFromHistory = portHistories.get(1);
            } else {
                portHistories = portHistoryRepository.findByIdAndRevisionType(port.getId(), HistoryObject.RevisionType.CREATED);
                if (portHistories != null && portHistories.size() > 0) {
                    portFromHistory = portHistories.stream().findFirst().get();
                }
            }
            if (portFromHistory != null) {
                SLXPortRemoveFECModeCommandBlock slxPortRemoveFECModeCommandBlock = new SLXPortRemoveFECModeCommandBlock();
                slxPortRemoveFECModeCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
                slxPortRemoveFECModeCommandBlock.setPort(port.getPortNumber());
                slxPortRemoveFECModeCommandBlock.setLineSpeed(portFromHistory.getLineSpeed());
                slxPortRemoveFECModeCommandBlock.setMaxSpeed(port.getMaxSpeed());
                commandBlocks.add(slxPortRemoveFECModeCommandBlock);

                if (portFromHistory.getLineSpeed() > 0 && !portFromHistory.getName().contains(":")) {
                    SLXPortGroupRemoveSpeedCommandBlock slxPortGroupRemoveSpeedCommandBlock = new SLXPortGroupRemoveSpeedCommandBlock();
                    slxPortGroupRemoveSpeedCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
                    slxPortGroupRemoveSpeedCommandBlock.setName(portGroup.getName());
                    slxPortGroupRemoveSpeedCommandBlock.setPort(port.getPortNumber());
                    slxPortGroupRemoveSpeedCommandBlock.setLineSpeed(portFromHistory.getLineSpeed());
                    commandBlocks.add(slxPortGroupRemoveSpeedCommandBlock);
                }
            }

            SLXPortGroupDisablePortCommandBlock pgdpCommandBlock = new SLXPortGroupDisablePortCommandBlock();
            pgdpCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
            pgdpCommandBlock.setName(portGroup.getName());
            pgdpCommandBlock.setPort(port.getPortNumber());
            commandBlocks.add(pgdpCommandBlock);
        }

        SLXPortGroupRemoveCommandBlock pgRemoveCommandBlock = new SLXPortGroupRemoveCommandBlock();
        pgRemoveCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
        pgRemoveCommandBlock.setName(portGroup.getName());
        commandBlocks.add(pgRemoveCommandBlock);

        if (!commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("true");
        }
        return commandBlocks;
    }
}
