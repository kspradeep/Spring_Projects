package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.grid.DestinationGroupRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.DestinationGroup;
import com.brocade.bvm.outbound.stablenet.commands.BeanUtil;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetCommitSLXPolicyJobExecutor extends AbstractStablenetSLXPolicyJobExecutor {

    @Inject
    private DestinationGroupRepository destinationGroupRepository;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    public enum PortType {
        SOURCE, DESTINATION
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_CREATE);
    }

    /**
     * This method builds policy COMMIT commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Policy policyToSave = (Policy) getParentObject(job);
        String command = buildCommand(policyToSave);
        log.info("Stablenet SLX command generated from Job Id {} on device {} for policy id {} is {}", job.getId(), job.getDevice().getId(), policyToSave.getId(), command);
        return command;
    }

    private String buildCommand(Policy policy) {
        Policy policyToApply = BeanUtil.removeDuplicates(policy);
        boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(policyToApply.getFlows().first());
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> egressPorts = new HashSet<>();
        Set<PortGroup> egressPortGroups = new HashSet<>();
        Set<PortGroup> ingressPortGroups = new HashSet<>();

        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(buildUdaProfileOffset(policyToApply));
        List<String> uniqueListOfRulesetNameToUpdateRules = new ArrayList<>();
        for (Flow eachFlow : policyToApply.getFlows()) {
            Map<String, Integer> tvfDomainIdsWithPrecedence = new HashMap<>();
            if (eachFlow.getTvfDomain()) {
                eachFlow.getVlans().forEach(tvfDomainId -> {
                    command.append(String.format(CREATE_TVF_DOMAIN, tvfDomainId));
                    command.append(EXIT);
                    eachFlow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && tvfDomainId.equals(flowEgressManagedObject.getTvfDomainId())).forEach(flowEgressManagedObject -> {
                        command.append(String.format(INTERFACE_ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber()));
                        command.append(addPortToTvfDomain(Sets.newHashSet(tvfDomainId)));
                        command.append(EXIT);
                        tvfDomainIdsWithPrecedence.put(tvfDomainId, flowEgressManagedObject.getPrecedence());
                    });

                    eachFlow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && tvfDomainId.equals(flowEgressManagedObject.getTvfDomainId())).forEach(flowEgressManagedObject -> {
                        command.append(String.format(INTERFACE_PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName()));
                        command.append(addPortToTvfDomain(Sets.newHashSet(tvfDomainId)));
                        command.append(EXIT);
                        tvfDomainIdsWithPrecedence.put(tvfDomainId, flowEgressManagedObject.getPrecedence());
                    });
                });
            }
            // creating ruleSet and policy
            command.append(buildFlowCommand(eachFlow, tvfDomainIdsWithPrecedence, policyToApply.getComputedName(), uniqueListOfRulesetNameToUpdateRules));

            ingressPorts.addAll(eachFlow.getIngressPorts().stream().collect(Collectors.toSet()));
            egressPorts.addAll(eachFlow.getEgressPorts().stream().collect(Collectors.toSet()));
            egressPortGroups.addAll(eachFlow.getEgressPortGroups().stream().collect(Collectors.toSet()));

            ingressPortGroups.addAll(eachFlow.getIngressPortGroups());
        }

        Device device = policy.getDevice();
        ingressPorts.forEach(ingress -> {
            command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
            policy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName())));
            if (policy.isTimestamp() && policy.isIngressValid())
                command.append(INGRESS_VALID_TIMESTAMP);
            if (policy.isGtpHttpFiltered()) {
                command.append(DENY_GTP_HTTPS);
            }
            if (isDeviceSLX9850WithUda) {
                command.append(String.format(ENABLE_FLEX_PBR, policyToApply.getComputedName()));
            } else {
                command.append(String.format(CREATE_POLICY, policyToApply.getComputedName()));
            }
            command.append(EXIT);
        });

        ingressPortGroups.forEach(portGroup -> {
            command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
            policy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName())));
            if (policy.isTimestamp() && policy.isIngressValid())
                command.append(INGRESS_VALID_TIMESTAMP);
            if (policy.isGtpHttpFiltered())
                command.append(NO_DENY_GTP_HTTPS);
            if (isDeviceSLX9850WithUda) {
                command.append(String.format(ENABLE_FLEX_PBR, policyToApply.getComputedName()));
            } else {
                command.append(String.format(CREATE_POLICY, policyToApply.getComputedName()));
            }
            command.append(EXIT);
        });

        if (policy.isTimestamp()) {
            egressPorts.forEach(egress -> {
                command.append(String.format(INTERFACE_ETHERNET, egress.getPortNumber()));
                command.append(String.format(EGRESS_TIMESTAMP, policy.getEgressAction()));
                command.append(EXIT);
            });

            egressPortGroups.forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(String.format(EGRESS_TIMESTAMP, policy.getEgressAction()));
                command.append(EXIT);
            });
        }

        boolean isTelemetryConfigured = false;
        if (device.isProfileConfigured()) {
            isTelemetryConfigured = true;
        } else if (!Strings.isNullOrEmpty(device.getOs()) && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (isSLXSupportsTelemetry(device.getOs()) >= 0) {
                isTelemetryConfigured = true;
            }
        }
        if (isTelemetryConfigured) {
            String interfaceStatsPortsToAdd = ingressPorts.stream().map(port -> port.getPortNumber().trim()).collect(Collectors.joining(","));
            String interfaceStatsPortChannelsToAdd = ingressPortGroups.stream().map(PortGroup::getName).collect(Collectors.joining(","));

            command.append(applyInterfaceAndPbrStats(interfaceStatsPortsToAdd, interfaceStatsPortChannelsToAdd, "", ""));
        }
        command.append(EXIT);
        return command.toString();
    }

    private String buildFlowCommand(Flow flow, Map<String, Integer> tvfDomainIdsWithPrecedence, String name, List<String> uniqueListOfRulesetNameToUpdateRules) {
        StringBuilder command = new StringBuilder();
        String truncationProfile = null;
        Long policyId = flow.getPolicy().getId();
        if (flow != null && name != null && !name.isEmpty()) {
            boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(flow);
            Long deviceId = flow.getPolicy().getDevice().getId();
            // Creating ruleSet command 1st hand
            flow.getRuleSets().forEach(ruleSet -> {
                if (!uniqueListOfRulesetNameToUpdateRules.contains(ruleSet.getName())) {
                    if (isRuleSetChangesRequired(ruleSet, deviceId, flow.getPolicy().getId())) {
                        command.append(buildRuleSetCommand(ruleSet, isSLX9850WithUDA));
                    } else {
                        command.append(buildRuleSetCommandForExistingRulesetInDifferentPolicy(ruleSet, deviceId, policyId));
                    }
                    uniqueListOfRulesetNameToUpdateRules.add(ruleSet.getName());
                }
            });
            command.append(String.format(ROUTE_MAP, name, CMD_PERMIT, flow.getSequence()));
            // Adding ruleSet to policy

            for (RuleSet ruleSet : flow.getRuleSets()) {
                if (RuleSet.Type.UDA.equals(ruleSet.getType())) {
                    if (isSLX9850WithUDA) {
                        command.append(String.format(MATCH_UDA_ACL, ruleSet.getName()));
                    } else {
                        command.append(String.format(MATCH_ACL, UDA, ruleSet.getName()));
                    }
                }
                if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                    command.append(String.format(MATCH_ACL, IP, ruleSet.getName()));
                } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                    command.append(String.format(MATCH_ACL, IPV6, ruleSet.getName()));
                } else if (ruleSet.getType() == RuleSet.Type.L2) {
                    command.append(String.format(MATCH_ACL, MAC, ruleSet.getName()));
                }
            }
            boolean isVlanStrippingEnabled = flow.getVlanStripping();
            boolean isVlanTagged = flow.getTaggedVlanId() != null && flow.getTaggedVlanId() > 0;
            String vlanString = isVlanStrippingEnabled ? STRIP_VLAN_OUTER : (isVlanTagged ? String.format(ADD_VLAN_OUTER, flow.getTaggedVlanId()) : "");
            if (flow.getDestinationGroupId() != null) {
                DestinationGroup destinationGroup = destinationGroupRepository.findByGroupId(flow.getDestinationGroupId());
                if (destinationGroup != null) {
                    command.append(String.format(NEXT_HOP, PBF_DESTINATION_GROUP, destinationGroup.getGroupId(), vlanString));
                }
            } else {
                if (flow.getTvfDomain()) {
                    tvfDomainIdsWithPrecedence.forEach((tvfDomainId, precedence) -> {
                        if (precedence > 0) {
                            command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE, precedence, tvfDomainId, vlanString));
                        } else {
                            if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getPacketTruncation() != null && flow.getPacketTruncationMapping().getPacketTruncation().getName() != null) {
                                command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_TRUNCATION_PROFILE, tvfDomainId, vlanString, TRUNCATION_PROFILE, flow.getPacketTruncationMapping().getPacketTruncation().getName()));
                            } else {
                                command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN, tvfDomainId, vlanString));
                            }
                        }
                    });
                } else {
                    //NEXT_HOP_WITH_PRECEDENCE
                    flow.getFlowEgressPorts().forEach(flowEgressManagedObject -> {
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                        } else {
                            if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getPacketTruncation() != null && flow.getPacketTruncationMapping().getPacketTruncation().getName() != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString, TRUNCATION_PROFILE, flow.getPacketTruncationMapping().getPacketTruncation().getName()));
                            } else {
                                command.append(String.format(NEXT_HOP, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                            }
                        }
                    });

                    flow.getFlowEgressPortGroups().forEach(flowEgressManagedObject -> {
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                        } else {
                            if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getPacketTruncation() != null && flow.getPacketTruncationMapping().getPacketTruncation().getName() != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString, TRUNCATION_PROFILE, flow.getPacketTruncationMapping().getPacketTruncation().getName()));
                            } else {
                                command.append(String.format(NEXT_HOP, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                            }
                        }
                    });
                    if (isSLX9850WithUDA && flow.getIsDefaultRouteMapDrop()) {
                        command.append(SET_UDA_INTERFACE_NULL);
                    }
                }
            }
            command.append(EXIT);
        }
        return command.toString();
    }

    private String addPortToTvfDomain(Set<String> tvfDomains) {
        StringBuilder command = new StringBuilder();
        for (String tvfDomainId : tvfDomains) {
            command.append(String.format(ADD_INTERFACE_TO_TVF_DOMAIN, tvfDomainId));
        }
        return command.toString();
    }

}
