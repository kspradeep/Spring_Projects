
package com.brocade.bvm.outbound.firmware.job.util;

public class CliCommandConstraints {

    private CliConstants.AccessMode mode = CliConstants.AccessMode.PRIVILEGE_MODE;
    private boolean validateResponse = true;
    /**
     * Don't stop on error is the default.
     */
    private boolean stopOnError = false;
    private int timeout = 0;

    public CliConstants.AccessMode getMode() {
        return mode;
    }

    public void setMode(CliConstants.AccessMode mode) {
        this.mode = mode;
    }

    public boolean isValidateResponse() {
        return validateResponse;
    }

    public void setValidateResponse(boolean validateResponse) {
        this.validateResponse = validateResponse;
    }

    public boolean isStopOnError() {
        return stopOnError;
    }

    public void setStopOnError(boolean stopOnError) {
        this.stopOnError = stopOnError;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

}
