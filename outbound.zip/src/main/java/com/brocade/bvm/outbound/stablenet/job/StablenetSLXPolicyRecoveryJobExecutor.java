package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.outbound.stablenet.commands.recovery.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetSLXPolicyRecoveryJobExecutor extends AbstractSLXPolicyRecoveryJobExecutor {

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    /**
     * This method constructs policy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        Policy policyToDelete = (Policy) getParentObject(job);
        log.debug("SLX PolicyRecovery Job executor for policy id {}", policyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(policyToDelete);
        log.debug("Number of command blocks constructed for SLX policy recovery id {} is :{}", policyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs policy recovery command blocks for the given policy
     *
     * @param policyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(Policy policyToDelete) {
        List<CommandBlock> finalCommandBlocks = new ArrayList<>();
        //Created LinkedHashSet to remove duplicate command blocks and maintain insertion order
        //This is to check if it's a save/commit over commit scenario, then recover the last committed policy first.
        Policy policyFromHistory = getPolicyFromHistory(policyToDelete);
        boolean isIngressValid = policyToDelete.isIngressValid() || (policyFromHistory != null && policyFromHistory.isIngressValid());
        boolean isTimestamp = policyToDelete.isTimestamp() || (policyFromHistory != null && policyFromHistory.isTimestamp());
        /* This is to recover the user specified policy. */
        finalCommandBlocks.addAll(constructCommandBlock(policyToDelete, policyFromHistory, isIngressValid, isTimestamp));

        if (!finalCommandBlocks.isEmpty()) {
            finalCommandBlocks.get(finalCommandBlocks.size() - 1).setWriteMem("true");
        }

        return finalCommandBlocks;
    }

    /**
     * This method constructs command blocks to remove policy from the given device
     *
     * @param policy
     * @return List<CommandBlock>
     */
    private List<CommandBlock> constructCommandBlock(Policy policy, Policy policyFromHistory, boolean isIngressValid, boolean isEgressAction) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        commandBlocks.addAll(constructRouteMapUdaCommandBlocks(policy, isIngressValid, isEgressAction));
        if (policyFromHistory != null) {
            commandBlocks.addAll(constructRouteMapUdaCommandBlocks(policyFromHistory, isIngressValid, isEgressAction));
        } else {
            log.info("Entry is not found in SLX policy history.");
        }
        commandBlocks.addAll(constructRecoverCommandBlock(policy));
        if (policyFromHistory != null) {
            commandBlocks.addAll(constructRecoverCommandBlock(policyFromHistory));
        }
        return commandBlocks;
    }

    /**
     * This method constructs command blocks to remove route-maps and uda-profile from interface
     *
     * @param policy
     * @param ingressValid
     * @param egressAction
     * @return List<CommandBlock>
     */
    private List<CommandBlock> constructRouteMapUdaCommandBlocks(Policy policy, boolean ingressValid, boolean egressAction) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> egressPorts = new HashSet<>();
        Set<PortGroup> ingressPortGroups = new HashSet<>();
        Set<PortGroup> egressPortGroups = new HashSet<>();
        Integer stablenetDeviceId = policy.getDevice().getStablenetId().intValue();
        boolean isSLX9850 = policy.getDevice().getModel() != null && policy.getDevice().getModel().contains(FlexMatchProfile.SLX_9850);
        Set<FlexMatchProfile> flexMatchProfiles = policy.getFlexMatchProfiles();

        for (Flow flow : policy.getFlows()) {
            ingressPorts = flow.getIngressPorts();
            egressPorts = flow.getEgressPorts();
            ingressPortGroups = flow.getIngressPortGroups();
            egressPortGroups = flow.getEgressPortGroups();
        }

        //removing policy from ethernet
        for (Port port : ingressPorts) {
            SLXPolicyCommandBlock slxPolicyCommandBlock = new SLXPolicyCommandBlock();
            slxPolicyCommandBlock.setDeviceId(stablenetDeviceId);
            slxPolicyCommandBlock.setPort(port.getPortNumber());
            slxPolicyCommandBlock.setRouteMapName(policy.getComputedName());
            slxPolicyCommandBlock.setType(ETHERNET);
            slxPolicyCommandBlock.setIngressValid(ingressValid);
            slxPolicyCommandBlock.setEgressAction(false);
            slxPolicyCommandBlock.setPbrType(isSLX9850 ? UDA : NPB);
            commandBlocks.add(slxPolicyCommandBlock);
        }

        //removing policy from port-channel
        for (PortGroup portGroup : ingressPortGroups) {
            SLXPolicyCommandBlock slxPolicyCommandBlock = new SLXPolicyCommandBlock();
            slxPolicyCommandBlock.setDeviceId(stablenetDeviceId);
            slxPolicyCommandBlock.setPort(portGroup.getName());
            slxPolicyCommandBlock.setRouteMapName(policy.getComputedName());
            slxPolicyCommandBlock.setType(PORT_CHANNEL);
            slxPolicyCommandBlock.setIngressValid(ingressValid);
            slxPolicyCommandBlock.setPbrType(isSLX9850 ? UDA : NPB);
            commandBlocks.add(slxPolicyCommandBlock);
        }

        if (egressAction) {
            //removing policy from ethernet
            for (Port port : egressPorts) {
                SLXPolicyCommandBlock slxPolicyCommandBlock = new SLXPolicyCommandBlock();
                slxPolicyCommandBlock.setDeviceId(stablenetDeviceId);
                slxPolicyCommandBlock.setPort(port.getPortNumber());
                slxPolicyCommandBlock.setRouteMapName(policy.getComputedName());
                slxPolicyCommandBlock.setType(ETHERNET);
                slxPolicyCommandBlock.setEgressAction(egressAction);
                slxPolicyCommandBlock.setPbrType(isSLX9850 ? UDA : NPB);
                commandBlocks.add(slxPolicyCommandBlock);
            }

            //removing policy from port-channel
            for (PortGroup portGroup : egressPortGroups) {
                SLXPolicyCommandBlock slxPolicyCommandBlock = new SLXPolicyCommandBlock();
                slxPolicyCommandBlock.setDeviceId(stablenetDeviceId);
                slxPolicyCommandBlock.setPort(portGroup.getName());
                slxPolicyCommandBlock.setRouteMapName(policy.getComputedName());
                slxPolicyCommandBlock.setType(PORT_CHANNEL);
                slxPolicyCommandBlock.setEgressAction(egressAction);
                slxPolicyCommandBlock.setPbrType(isSLX9850 ? UDA : NPB);
                commandBlocks.add(slxPolicyCommandBlock);
            }
        }
        if (!flexMatchProfiles.isEmpty()) {
            for (FlexMatchProfile flexMatchProfile : flexMatchProfiles) {
                if (!ingressPorts.isEmpty()) {
                    SLXUdaProfileApplyCommandBlock slxUdaProfileApplyCommandBlock = new SLXUdaProfileApplyCommandBlock();
                    slxUdaProfileApplyCommandBlock.setDeviceId(stablenetDeviceId);
                    slxUdaProfileApplyCommandBlock.setProfileName(flexMatchProfile.getName());
                    slxUdaProfileApplyCommandBlock.setPortGroup(false);
                    slxUdaProfileApplyCommandBlock.setInterfaces(ingressPorts.stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                    commandBlocks.add(slxUdaProfileApplyCommandBlock);
                }
                if (!ingressPortGroups.isEmpty()) {
                    SLXUdaProfileApplyCommandBlock slxUdaProfileApplyCommandBlock = new SLXUdaProfileApplyCommandBlock();
                    slxUdaProfileApplyCommandBlock.setDeviceId(stablenetDeviceId);
                    slxUdaProfileApplyCommandBlock.setProfileName(flexMatchProfile.getName());
                    slxUdaProfileApplyCommandBlock.setPortGroup(true);
                    slxUdaProfileApplyCommandBlock.setInterfaces(ingressPortGroups.stream().map(PortGroup::getName).collect(Collectors.toSet()));
                    commandBlocks.add(slxUdaProfileApplyCommandBlock);
                }
            }
        }
        return commandBlocks;
    }

    /**
     * This method constructs command blocks to recover match statements, ACL, tvf-domain and Flex Match profile
     *
     * @param policy
     * @return List<CommandBlock>
     */
    private List<CommandBlock> constructRecoverCommandBlock(Policy policy) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        Integer stablenetDeviceId = policy.getDevice().getStablenetId().intValue();

        for (Flow flow : policy.getFlows()) {
            Map<String, Set<RuleSetIdNameMap>> aclTypeNameIdMap = constructAclTypeNameMap(flow);

            //removing next-hop settings
            boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(flow);
            if (flow.getDestinationGroupId() != null) {
                commandBlocks.add(buildNextHopCommand(policy, flow, String.format(NEXT_HOP, PBF_DESTINATION_GROUP, flow.getDestinationGroupId()), stablenetDeviceId, isDeviceSLX9850WithUda));
            } else {
                if (flow.getTvfDomain()) {
                    log.debug("is TVFDomainEnabled {}", flow.getTvfDomain());
                    if (flow.getVlans() != null) {
                        log.debug("list of tvf domain ids {}", flow.getVlans());
                        flow.getVlans().forEach(tvfDomainId -> {
                            commandBlocks.add(buildNextHopCommand(policy, flow, String.format(SET_NEXT_HOP_TVF_DOMAIN, tvfDomainId.trim()), stablenetDeviceId, false));
                        });
                    }
                } else {
                    flow.getEgressPorts().forEach(port -> {
                        commandBlocks.add(buildNextHopCommand(policy, flow, String.format(NEXT_HOP, ETHERNET, port.getPortNumber().trim()), stablenetDeviceId, isDeviceSLX9850WithUda));
                    });

                    flow.getEgressPortGroups().forEach(portGroup -> {
                        commandBlocks.add(buildNextHopCommand(policy, flow, String.format(NEXT_HOP, PORT_CHANNEL, portGroup.getName().trim()), stablenetDeviceId, isDeviceSLX9850WithUda));
                    });
                }
            }

            //removing tvf-domain
            if (flow.getTvfDomain() && flow.getVlans() != null && !flow.getVlans().isEmpty()) {
                String tvfDomainId = flow.getVlans().stream().findAny().get();
                SLXTvfDomainCommandBlock slxTvfDomainCommandBlock = new SLXTvfDomainCommandBlock();
                slxTvfDomainCommandBlock.setDeviceId(stablenetDeviceId);
                slxTvfDomainCommandBlock.setTvfDomainId(tvfDomainId);
                commandBlocks.add(slxTvfDomainCommandBlock);
            }

            //removing route-map
            SLXRouteMapCommandBlock slxRouteMapCommandBlock = new SLXRouteMapCommandBlock();
            slxRouteMapCommandBlock.setDeviceId(stablenetDeviceId);
            slxRouteMapCommandBlock.setRouteMapName(policy.getComputedName());
            slxRouteMapCommandBlock.setRouteMapPattern(CMD_PERMIT + " " + flow.getSequence());
            commandBlocks.add(slxRouteMapCommandBlock);

            //removing rules
            for (RuleSet ruleSet : flow.getRuleSets()) {
                String ruleType = getRuleSetType(ruleSet);
                RuleSetIdNameMap ruleSetIdNameMap = new RuleSetIdNameMap();
                ruleSetIdNameMap.setId(ruleSet.getId());
                ruleSetIdNameMap.setName(ruleSet.getName());
                if (isRuleSetChangesRequired(ruleSetIdNameMap, policy.getDevice().getId(), policy.getId())) {
                    SLXRuleCommandBlock slxRuleCommandBlock = new SLXRuleCommandBlock();
                    StringBuilder ruleStringBuilder = new StringBuilder();
                    ruleSet.getRules().forEach(rule -> ruleStringBuilder.append(String.format(NO_WITH_COMMAND, (SEQUENCE + SPACE + rule.getSequence()))));
                    if (ruleStringBuilder.toString().length() > 0) {
                        slxRuleCommandBlock.setDeviceId(stablenetDeviceId);
                        slxRuleCommandBlock.setAclName(ruleSet.getName());
                        switch (ruleType) {
                            case IP:
                                slxRuleCommandBlock.setType(IP);
                                break;
                            case IPV6:
                                slxRuleCommandBlock.setType(IPV6);
                                break;
                            case MAC:
                                slxRuleCommandBlock.setType(MAC);
                                break;
                            case UDA:
                                slxRuleCommandBlock.setType(UDA);
                                break;
                            default:
                                log.error("Invalid access-list type. (Allowed types are IP, IPv6, MAC and UDA)");
                                break;
                        }
                        slxRuleCommandBlock.setSequenceString(ruleStringBuilder.toString());
                        if (slxRuleCommandBlock.getType() != null) {
                            commandBlocks.add(slxRuleCommandBlock);
                        }
                    }
                }
            }

            //removing acls
            for (String type : aclTypeNameIdMap.keySet()) {
                if (aclTypeNameIdMap != null && !aclTypeNameIdMap.isEmpty()) {
                    for (RuleSetIdNameMap ruleSetIdName : aclTypeNameIdMap.get(type)) {
                        if (isRuleSetChangesRequired(ruleSetIdName, policy.getDevice().getId(), policy.getId())) {
                            SLXAclCommandBlock slxAclCommandBlock = new SLXAclCommandBlock();
                            slxAclCommandBlock.setDeviceId(stablenetDeviceId);
                            slxAclCommandBlock.setAclName(ruleSetIdName.getName());
                            switch (type) {
                                case IP:
                                    slxAclCommandBlock.setType(IP);
                                    break;
                                case IPV6:
                                    slxAclCommandBlock.setType(IPV6);
                                    break;
                                case MAC:
                                    slxAclCommandBlock.setType(MAC);
                                    break;
                                case UDA:
                                    slxAclCommandBlock.setType(UDA);
                                    break;
                                default:
                                    log.debug("Invalid access-list type. (Allowed types are IP, IPv6, MAC and UDA)");
                                    break;
                            }
                            commandBlocks.add(slxAclCommandBlock);
                        }
                    }
                }
            }
        }

        Set<FlexMatchProfile> flexMatchProfiles = policy.getFlexMatchProfiles();
        if (!flexMatchProfiles.isEmpty()) {
            for (FlexMatchProfile flexMatchProfile : flexMatchProfiles) {
                List<Policy> policyList = policyRepository.findByFMProfileIdInAndDevice(flexMatchProfile.getId(), policy.getDevice().getId());
                if (policyList != null) {
                    boolean isDeleteProfile = true;
                    policyList = policyList.stream().filter(policy1 -> policy1.getId() != policy.getId()).collect(Collectors.toList());
                    if (!policyList.isEmpty()) {
                        Iterator<Policy> iterator = policyList.iterator();
                        while (iterator.hasNext()) {
                            Policy policy1 = iterator.next();
                            if (policy1.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.DRAFT) {
                                isDeleteProfile = false;
                                break;
                            }
                            if (policy1.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                                List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy1.getId(),
                                        Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                                if (!policyHistoryList.isEmpty()) {
                                    PolicyHistory oldPolicy = policyHistoryList.get(0);
                                    if (oldPolicy != null && WorkflowParticipant.WorkflowStatus.ACTIVE == oldPolicy.getWorkflowStatus()) {
                                        isDeleteProfile = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    if (policyList.isEmpty() || isDeleteProfile) {
                        SLXUdaProfileCommandBlock slxUdaProfileCommandBlock = new SLXUdaProfileCommandBlock();
                        slxUdaProfileCommandBlock.setDeviceId(stablenetDeviceId);
                        slxUdaProfileCommandBlock.setProfileName(flexMatchProfile.getName());
                        commandBlocks.add(slxUdaProfileCommandBlock);
                    }
                }
            }
        }

        Device device = policy.getDevice();
        boolean isStatsConfigured = false;
        if (device.isProfileConfigured()) {
            isStatsConfigured = true;
        } else if (!Strings.isNullOrEmpty(device.getOs()) && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (isSLXSupportsTelemetry(device.getOs()) >= 0) {
                isStatsConfigured = true;
            }
        }
        if (isStatsConfigured) {
            Set<Port> ingressPorts = Sets.newHashSet();
            Set<PortGroup> ingressPortGroups = new HashSet<>();
            Optional<Flow> flowOptional = policy.getFlows().stream().findFirst();
            if (flowOptional.isPresent()) {
                Flow flow = flowOptional.get();
                ingressPorts.addAll(flow.getIngressPorts());
                ingressPortGroups.addAll(flow.getIngressPortGroups());
            }
            String interfacePortsToRecover = ingressPorts.stream().map(port -> port.getPortNumber().trim()).collect(Collectors.joining(","));
            String interfacePortChannelsToRecover = ingressPortGroups.stream().map(PortGroup::getName).collect(Collectors.joining(","));

            TelemetryPbrStatsCommandBlock telemetryPbrStatsCommandBlock = new TelemetryPbrStatsCommandBlock();
            telemetryPbrStatsCommandBlock.setDeviceId(stablenetDeviceId);
            telemetryPbrStatsCommandBlock.setInterfacesPorts(interfacePortsToRecover);
            telemetryPbrStatsCommandBlock.setInterfacesPortChannels(interfacePortChannelsToRecover);
            commandBlocks.add(telemetryPbrStatsCommandBlock);
        }

        return commandBlocks;
    }


    private SLXNextHopCommandBlock buildNextHopCommand(Policy policy, Flow flow, String nextHopString, Integer stablenetDeviceId, boolean isDeviceSLX9850WithUda) {
        SLXNextHopCommandBlock slxNextHopCommandBlock = new SLXNextHopCommandBlock();
        slxNextHopCommandBlock.setDeviceId(stablenetDeviceId);
        slxNextHopCommandBlock.setRouteMapName(policy.getComputedName());
        slxNextHopCommandBlock.setRouteMapPattern(CMD_PERMIT + " " + flow.getSequence());
        slxNextHopCommandBlock.setSetNextHopCommand(nextHopString);
        slxNextHopCommandBlock.setDeviceSLX9850WithUda(isDeviceSLX9850WithUda);
        slxNextHopCommandBlock.setSlxDefaultRouteEnabled(flow.getIsDefaultRouteMapDrop());
        return slxNextHopCommandBlock;
    }

    /**
     * This method returns the RuleSetType for the given RuleSet object
     *
     * @param ruleSet
     * @return String
     */
    private String getRuleSetType(RuleSet ruleSet) {
        String ruleSetType = "";
        if (RuleSet.Type.L2 == ruleSet.getType()) {
            ruleSetType = MAC;
        } else if (RuleSet.Type.L3 == ruleSet.getType() && RuleSet.IpVersion.V4 == ruleSet.getIpVersion()) {
            ruleSetType = IP;
        } else if (RuleSet.Type.L3 == ruleSet.getType() && RuleSet.IpVersion.V6 == ruleSet.getIpVersion()) {
            ruleSetType = IPV6;
        } else if (RuleSet.Type.UDA == ruleSet.getType()) {
            ruleSetType = UDA;
        }
        return ruleSetType;
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param policy
     * @return Policy returns latest ACTIVE policy
     */
    protected Policy getPolicyFromHistory(Policy policy) {
        Policy policyFromHistory = null;
        // get the previous policy name from the history.
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();

        }
        return policyFromHistory;
    }

    /*
    This method helps to know if the provided flow is of 9850 sLX and contains UDA RuleSet
     */
    protected boolean isDeviceSLX9850WithUda(Flow flow) {
        Device device = flow.getPolicy().getDevice();
        boolean isSLX9850 = Device.Type.SLX.equals(device.getType()) && device.getModel().contains(FlexMatchProfile.SLX_9850);
        RuleSet ruleSet = flow.getRuleSets().stream().filter(rules -> RuleSet.Type.UDA.equals(rules.getType())).findAny().orElse(null);
        boolean isUdaRuleSet = ruleSet != null;
        return isSLX9850 && isUdaRuleSet;
    }

    /**
     * This method constructs RuleSetType to ruleSet names map
     *
     * @param flow
     * @return Map<String       ,               Set               <       String>>
     */
    private Map<String, Set<RuleSetIdNameMap>> constructAclTypeNameMap(Flow flow) {
        Map<String, Set<RuleSetIdNameMap>> aclNameTypeMap = new HashMap<>();
        Set<RuleSet> ruleSets = flow.getRuleSets();
        if (ruleSets != null && !ruleSets.isEmpty()) {
            ruleSets.forEach(ruleSet -> {
                RuleSetIdNameMap ruleSetIdNameMap = new RuleSetIdNameMap();
                ruleSetIdNameMap.setId(ruleSet.getId());
                ruleSetIdNameMap.setName(ruleSet.getName());
                if (aclNameTypeMap.containsKey(getRuleSetType(ruleSet))) {
                    Set<RuleSetIdNameMap> ruleSetIdNameMaps = aclNameTypeMap.get(getRuleSetType(ruleSet));
                    ruleSetIdNameMaps.add(ruleSetIdNameMap);
                } else {
                    Set<RuleSetIdNameMap> ruleSetIdNameMaps = new HashSet<>();
                    ruleSetIdNameMaps.add(ruleSetIdNameMap);
                    aclNameTypeMap.put(getRuleSetType(ruleSet), ruleSetIdNameMaps);
                }
            });
        }
        return aclNameTypeMap;
    }
}
