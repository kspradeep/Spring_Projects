package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXPortRemoveFECModeCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private Long lineSpeed;

    @Getter
    @Setter
    private Long maxSpeed;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * configure terminal
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: do show running-config interface Ethernet 0/1
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config interface Ethernet %s";

    /**
     * <pre>
     * matching regex
     * </pre>
     */
    private static final String MATCH_CMD = " fec mode";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: interface ethernet 1/1\n speed 100000\n no fec mode\n speed 40000;
     * </pre>
     */
    private static final String ACTION_CMD_WITH_LINE_SPEED = "interface ethernet %s\nspeed %s\nno fec mode\nspeed %s\nexit";

    private static final String ACTION_CMD_WITH_MAX_SPEED = "interface ethernet %s\nspeed %s\nno fec mode\nexit";

    private static final String ACTION_CMD_WITHOUT_LINE_SPEED = "interface ethernet %s\nno fec mode\nexit";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, port));
        args.add(MATCH_CMD);
        if (!port.contains(":")) {
            if (lineSpeed > 0) {
                args.add(String.format(ACTION_CMD_WITH_LINE_SPEED, port, maxSpeed, lineSpeed));
            } else if (maxSpeed != null) {
                args.add(String.format(ACTION_CMD_WITH_MAX_SPEED, port, maxSpeed));
            } else {
                args.add(String.format(ACTION_CMD_WITHOUT_LINE_SPEED, port));
            }
        } else {
            args.add(String.format(ACTION_CMD_WITHOUT_LINE_SPEED, port));
        }
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXPortRemoveFECModeCommandBlock [deviceId=" + deviceId + ", port=" + port + ", maxSpeed=" + maxSpeed + ", lineSpeed=" + lineSpeed + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
