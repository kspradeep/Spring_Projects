
package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.PortHistory;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The BscPortAdminStatusJobExecutor class implements methods to enable/disable the selected port(s) as L2/L3/L23 on Open Flow device through BSC
 */
@Named
public class BscPortAdminStatusJobExecutor extends AbstractStablenetJobExecutor {

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String INTERFACE_ENTER = "interface ethernet %s;";
    private static final String ENABLE_OPENFLOW = "openflow enable %s;";
    private static final String DISABLE_OPENFLOW_WITH_MODE = "no openflow enable %s;";
    private static final String INTERFACE_STATUS = "%s;";
    private static final String INTERFACE_EXIT = "exit;";
    private static final String SAVE_RUNNING_CONFIG = "write memory;";

    @Inject
	private PortHistoryRepository portHistoryRepository;
	
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_ENABLE, Job.Type.PORT_DISABLE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    /**
     * This method is used to build commands to enable/disable the selected port(s) as L2/L3/L23 on Open Flow device
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
    @Override
    public String getCommands(Job job) {
        String portAdminStatus;
        switch (job.getType()) {
            case PORT_ENABLE:
                portAdminStatus = "enable";
                break;
            case PORT_DISABLE:
                portAdminStatus = "disable";
                break;
            default:
                portAdminStatus = "nooperation"; //TODO
        }

        StringBuilder commands = new StringBuilder(TERMINAL_ENTER);

        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        for (Port port : ports) {
            List<PortHistory>portHistoryList = portHistoryRepository.findByIdAndWorkflowStatus(port.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
            commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));

            if(job.getType() == Job.Type.PORT_ENABLE) {
                commands.append(String.format(INTERFACE_STATUS, portAdminStatus));
                if(portHistoryList != null && portHistoryList.size()>0 && portHistoryList.get(0).getMode()!=null){
                    commands.append(String.format(DISABLE_OPENFLOW_WITH_MODE, portHistoryList.get(0).getMode()));
                }
                commands.append(String.format(ENABLE_OPENFLOW, port.getMode()));
            }
            else if(job.getType() == Job.Type.PORT_DISABLE){
                if(portHistoryList != null && portHistoryList.size()>0 && portHistoryList.get(0).getMode()!=null){
                    commands.append(String.format(DISABLE_OPENFLOW_WITH_MODE, portHistoryList.get(0).getMode()));
                }
                commands.append(String.format(INTERFACE_STATUS, portAdminStatus));
            }
            commands.append(INTERFACE_EXIT);
        }
        commands.append(SAVE_RUNNING_CONFIG);
        return commands.toString();
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE, Device.Type.ICX);
    }

}
