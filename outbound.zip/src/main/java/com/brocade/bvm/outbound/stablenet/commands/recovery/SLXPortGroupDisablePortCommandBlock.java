package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXPortGroupDisablePortCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * configure terminal
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: show port-channel 100
     * </pre>
     */
    private static final String SHOW_CMD = "do show port-channel %s";

    /**
     * <pre>
     * matching regex
     * </pre>
     */
    private static final String MATCH_CMD = "Static Aggregator";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: interface ethernet 1/1;no channel-group;
     * </pre>
     */
    private static final String ACTION_CMD = "interface ethernet %s\nno channel-group";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, name));
        args.add(MATCH_CMD);
        args.add(String.format(ACTION_CMD, port));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXPortGroupDisablePortCommandBlock [deviceId=" + deviceId + ", name=" + name + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
