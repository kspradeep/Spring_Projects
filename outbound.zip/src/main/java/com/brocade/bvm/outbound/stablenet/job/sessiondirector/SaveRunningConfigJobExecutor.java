package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class SaveRunningConfigJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String SAVE_CONFIG = "save config;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SAVE_RUNNING_CONFIG);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    /**
     * This method constructs Save Running config on given SD device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        commands.append(SAVE_CONFIG);
        commands.append(EXIT);
        return commands.toString();
    }
}

