package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetPacketSlicingModulePolicyDeleteJobExecutor class implements methods to delete PacketSlicingModulePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetPacketSlicingModulePolicyDeleteJobExecutor extends AbstractPacketSlicingModulePolicyJobExecutor {

    /**
     * This method constructs delete PacketSlicingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketSlicingModulePolicy modulePolicy = (PacketSlicingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getPorts().stream().forEach(port -> {
            command.append(String.format(PORT_EGRESS_REVERT_TRUNCATE_FORMAT, port.getPortNumber()));
        });
        modulePolicy.getModules().forEach(module -> {
            command.append(String.format(MODULE_POLICY_REVERT_EGRESS_TRUNCATE_FORMAT, modulePolicy.getNumberOfBytes(), module.getModuleNumber()));
        });
        //command.append(END);
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_SLICING_MODULE_POLICY_DELETE);
    }
}
