package com.brocade.bvm.outbound.bsc.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import lombok.Getter;

public class BscPortRecoveryCommandList {

    @Getter
    private List<CommandBlock> commandBlocks = new ArrayList<>();

    private static final String LAYER2 = "Layer2";

    private static final String LAYER3 = "Layer3";

    private static final String LAYER23 = "Layer23";

    public void constructCommandBlock(Long deviceId,Port port) {
        BscPortModeDisableCommandBlock bscPortLayer2DisableCommandBlock = new BscPortModeDisableCommandBlock();
        bscPortLayer2DisableCommandBlock.setDeviceId(deviceId.intValue());
        bscPortLayer2DisableCommandBlock.setMode(LAYER2);
        bscPortLayer2DisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(bscPortLayer2DisableCommandBlock);

        BscPortModeDisableCommandBlock bscPortLayer3DisableCommandBlock = new BscPortModeDisableCommandBlock();
        bscPortLayer3DisableCommandBlock.setDeviceId(deviceId.intValue());
        bscPortLayer3DisableCommandBlock.setMode(LAYER3);
        bscPortLayer3DisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(bscPortLayer3DisableCommandBlock);

        BscPortModeDisableCommandBlock bscPortLayer23DisableCommandBlock = new BscPortModeDisableCommandBlock();
        bscPortLayer23DisableCommandBlock.setDeviceId(deviceId.intValue());
        bscPortLayer23DisableCommandBlock.setMode(LAYER23);
        bscPortLayer23DisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(bscPortLayer23DisableCommandBlock);

        BscPortDisableCommandBlock bscPortDisableCommandBlock = new BscPortDisableCommandBlock();
        bscPortDisableCommandBlock.setDeviceId(deviceId.intValue());
        bscPortDisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(bscPortDisableCommandBlock);


    }

}
