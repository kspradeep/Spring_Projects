package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.PacketSlicingModulePolicy;

/**
 * Created by dneelapa on 6/27/2016.
 */
public abstract class AbstractPacketSlicingModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String END = "end;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String MODULE_POLICY_EGRESS_TRUNCATE_FORMAT = "egress-truncate-size %s slot %s;";

    protected static final String MODULE_POLICY_REVERT_EGRESS_TRUNCATE_FORMAT = "no egress-truncate-size %s slot %s;";

    protected static final String PORT_EGRESS_TRUNCATE_FORMAT = "interface ethernet %s;egress-truncate;exit;";

    protected static final String PORT_EGRESS_REVERT_TRUNCATE_FORMAT = "interface ethernet %s;no egress-truncate;exit;";

}
