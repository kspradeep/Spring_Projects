package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;

public interface CommandBlock {
    DeployJobParameter getTemplateJobInput();
    void setWriteMem(String string);
}
