package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXPolicyCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String type;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String routeMapName;

    @Getter
    @Setter
    private String writeMem = "false";

    @Getter
    @Setter
    private boolean ingressValid;

    @Getter
    @Setter
    private boolean egressAction;

    @Getter
    @Setter
    private String pbrType;

    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is port name
     * eg: show running-config interface ethernet 1/1
     * eg: sh run int e 1/1
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config interface %s %s";

    /**
     * <pre>
     * argument #1 is route-map name
     * eg: npb policy route-map name
     * </pre>
     */
    private static final String MATCH_CMD = " %s policy route-map %s";

    /**
     * <pre>
     * argument #1 is interface type, #2 interface number, #3 is route-map name
     * eg: interface ethernet 1/2 \n no system packet-timestamp egress \n no npb policy route-map name
     * </pre>
     */
    private static final String ACTION_CMD_WITH_INGRESS_VALID = "interface %s %s\nno system packet-timestamp ingress\nno %s policy route-map %s";

    /**
     * <pre>
     * argument #1 is interface type, #2 interface number, #3 is no egress timestamp
     * eg: interface ethernet 1/2 \n no system packet-timestamp egress
     * </pre>
     */
    private static final String ACTION_CMD_WITH_EGRESS = "interface %s %s\nno system packet-timestamp egress\nno %s policy route-map %s";

    /**
     * <pre>
     * argument #1 is interface type, #2 interface number, #3 is no egress timestamp
     * eg: interface ethernet 1/2 \n no system packet-timestamp egress
     * </pre>
     */
    private static final String ACTION_CMD = "interface %s %s\nno %s policy route-map %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, type, port));
        args.add(String.format(MATCH_CMD, pbrType, routeMapName));
        if (ingressValid)
            args.add(String.format(ACTION_CMD_WITH_INGRESS_VALID, type, port, pbrType, routeMapName));
        else if (egressAction)
            args.add(String.format(ACTION_CMD_WITH_EGRESS, type, port, pbrType, routeMapName));
        else
            args.add(String.format(ACTION_CMD, type, port, pbrType, routeMapName));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXPolicyCommandBlock [deviceId=" + deviceId + ", type=" + type + ", pbrType=" + pbrType + ", port=" + port + ", routeMapName=" + routeMapName + ", getTemplateJobInput()="
                + getTemplateJobInput() + "]";
    }
}