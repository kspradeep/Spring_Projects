package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.MPLSDevicePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetMplsDevicePolicyCommitJobExecutor class implements methods to create MplsDevicePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetMplsDevicePolicyCommitJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String MPLS_UNKNOWN_LABEL_FORWARD = "mpls-unknown-label-forward ingress %s egress %s;";

    /**
     * This method constructs create MPLSDevicePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        // TODO :: Need to handle Reload of the System.
        MPLSDevicePolicy mplsDevicePolicy = (MPLSDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        mplsDevicePolicy.getMPLSPairs().forEach(mplsPair -> {
            command.append(String.format(MPLS_UNKNOWN_LABEL_FORWARD, mplsPair.getIngressPort().getPortNumber(), mplsPair.getEgressPort().getPortNumber()));
        });
        command.append(EXIT);
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_MPLS_POP_CREATE);
    }

}
