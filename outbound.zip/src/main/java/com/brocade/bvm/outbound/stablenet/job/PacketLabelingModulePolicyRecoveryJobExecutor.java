package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.PacketLabelingModulePolicy;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PacketLabelingCommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class PacketLabelingModulePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {
    private static final String DEVICE_ID = "device-id ";

    /**
     * This method constructs PacketLabelingModulePolicy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        PacketLabelingModulePolicy modulePolicyToDelete = (PacketLabelingModulePolicy) getParentObject(job);
        log.debug("PacketLabelingModulePolicyRecovery Job executor for policy id {}", modulePolicyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(modulePolicyToDelete);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", modulePolicyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs PacketLabelingModulePolicy recovery command blocks for the given policy
     *
     * @param modulePolicyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(PacketLabelingModulePolicy modulePolicyToDelete) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        modulePolicyToDelete.getModules().forEach(module -> {
            finalCommandBlocks.add(constructModuleCommandBlock(module, getProcessor(module.getDevice(), modulePolicyToDelete)));
        });
        return finalCommandBlocks;
    }

    /**
     * This method constructs PacketLabelingModulePolicy recovery command block for OS version 6 and above
     *
     * @param module
     * @param processorNumber
     * @return PacketStampingCommandBlock
     */
    private PacketLabelingCommandBlock constructModuleCommandBlock(Module module, String processorNumber) {
        PacketLabelingCommandBlock packetLabelingCommandBlock = new PacketLabelingCommandBlock();
        packetLabelingCommandBlock.setDeviceId(module.getDevice().getStablenetId().intValue());
        packetLabelingCommandBlock.setProcessorNumber(processorNumber);
        packetLabelingCommandBlock.setModuleNumber(String.valueOf(module.getModuleNumber()));
        return packetLabelingCommandBlock;
    }

    /**
     * This method returns processorNumber value to be applied on the device based on device OS and processor number
     *
     * @param device
     * @param modulePolicy
     * @return String returns processorVal
     */
    private String getProcessor(Device device, PacketLabelingModulePolicy modulePolicy) {
        String processorVal = modulePolicy.getProcessor().getProcessorNumber();
        if (PacketLabelingModulePolicy.ProcessorNumber.ALL == modulePolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = isOsVersion6(device) ? DEVICE_ID + processorVal : processorVal;
        }
        return processorVal;
    }

    /**
     * This method checks if the given device OS version is 6 and above
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        int osMajorVersion = device.getOsMajorVersion();
        return osMajorVersion >= MLXE_OS_MAJOR_VERSION;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_LABELING_MODULE_POLICY_ROLLBACK);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }
}
