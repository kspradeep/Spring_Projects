package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SdPortGroupRecoveryCommandList;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class RecoverSdPortGroupJobExecutor extends AbstractSdRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_PORT_GROUP_ROLLBACK);
    }

    /**
     * This method builds PortGroup RECOVER commands to be executed on the given SD device
     *
     * @param job
     * @return String This returns command block
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        SdPortGroup portGroupToRecover = (SdPortGroup) getParentObject(job);
        SdPortGroupRecoveryCommandList recoveryCommandList = new SdPortGroupRecoveryCommandList();
        List<CommandBlock> commandBlocks = recoveryCommandList.constructCommandBlockList(portGroupToRecover);
        return commandBlocks;
    }
}
