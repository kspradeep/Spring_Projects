package com.brocade.bvm.outbound.stablenet.commands;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
@NoArgsConstructor
public class TvfDiff {

    @Setter
    private boolean oldTvfDomain;

    @Setter
    private boolean newTvfDomain;

    @Setter
    //Tvf
    private Map<String, Set<String>> oldTvfMap = new HashMap<>();

    @Setter
    //Tvf
    private Map<String, Set<String>> newTvfMap = new HashMap<>();

    @Setter
    private Map<String, Set<String>> oldTvfPortChannelMap = new HashMap<>();

    @Setter
    private Map<String, Set<String>> newTvfPortChannelMap = new HashMap<>();

    @Setter
    // sequence - Tvf mapping
    private Map<Integer, Set<String>> deletedTvfsMap = new HashMap<>();

    @Setter
    // sequence - Tvf mapping
    private Map<Integer, Set<String>> addedTvfsMap = new HashMap<>();

    @Setter
    // sequence - Tvf mapping
    private Map<Integer, Set<String>> updatedTvfsMap = new HashMap<>();

    @Setter
    private List<String> deletedTvfs;

    @Setter
    private List<String> addedTvfs;

    @Setter
    private List<String> updatedTvfs;
}
