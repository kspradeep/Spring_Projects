package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.GTPDevicePolicyRepository;
import com.brocade.bvm.dao.PortGroupHistoryRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.history.PortGroupHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * The StablenetPortGroupUpdateJobExecutor class implements methods to update portGroup on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetPortGroupUpdateJobExecutor extends AbstractStablenetPortGroupJobExecutor {

    @Inject
    private PortGroupHistoryRepository portGroupHistoryRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private GTPDevicePolicyRepository gtpDevicePolicyRepository;

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.PORT_GROUP_UPDATE);
    }

    /**
     * This method constructs portGroup update commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        log.trace("Port Group Updation Input Object: {}", portGroup);
        StringBuilder cmd = new StringBuilder();
        if (portGroup != null) {
            PortGroup oldPortGroup = getPortGroupFromHistory(portGroup.getId());
            cmd.append(CONFIGURE_TERMINAL);
            cmd.append(buildUnMapPortFromGtpProfile(oldPortGroup));
            // Delete port group
            cmd.append(buildVlanCommandForModifiedPorts(portGroup, oldPortGroup.getPrimaryPort().getPortNumber(), false));
            cmd.append(buildDeleteCommand(oldPortGroup));
            // create port group
            cmd.append(buildCreateCommand(portGroup));
            cmd.append(buildVlanCommandForModifiedPorts(portGroup, oldPortGroup.getPrimaryPort().getPortNumber(), true));
            // To map/unmap primary port of port group to/from GTP profile.
            // cmd.append(buildMapOrUnMapPortFromGtpProfile(oldPortGroup, portGroup));
            cmd.append(buildMapPortToGtpProfile(portGroup));
            cmd.append(END);
            cmd.append(WRITE_MEMORY);
        } else {
            log.error("Port Group input object is null.");
        }
        log.debug("Port Group Updation CMD: {}", cmd);
        return cmd.toString();
    }

    /**
     * This method fetches the ACTIVE portGroup from history
     *
     * @param portGroupId
     * @return PortGroup This returns portGroup from history
     */
    private PortGroup getPortGroupFromHistory(Long portGroupId) {
    	List<PortGroupHistory> portGroupHistoryList = portGroupHistoryRepository.findByIdAndWorkflowStatus(portGroupId);
    	PortGroup portGroup = null;
    	if(portGroupHistoryList.size() >= 1){
    		PortGroupHistory portGroupHistory = portGroupHistoryList.get(0);
    		portGroup = portGroupHistory.buildParent();
            if(portGroup.getGtpProfileId() != null) {
                portGroup.setGtpProfile(gtpDevicePolicyRepository.findOne(portGroup.getGtpProfileId()));
            }
            List<Port> ports = (List<Port>) portRepository.findAll(portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toSet()));
            portGroup.setPorts(new TreeSet<>(ports));
    	}
    	return portGroup;
    }

}
