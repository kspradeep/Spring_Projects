package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortHistory;
import com.brocade.bvm.outbound.bsc.commands.recovery.SlxPortDescriptionRecoveryCommandBlock;
import com.brocade.bvm.outbound.bsc.commands.recovery.SlxPortDisableCommandBlock;
import com.brocade.bvm.outbound.bsc.commands.recovery.SlxPortModeDisableCommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SLXPortRestLineSpeedCommandBlock;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetRecoveryJobExecutor;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The SlxPortRecoveryJobExecutor class implements methods to recover the selected port(s) which are in error state on Open Flow SLX device
 */
@Named
public class SlxPortRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {
    @Inject
    private PortHistoryRepository portHistoryRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method used to build the port recovery command blocks
     *
     * @param job
     * @return List<CommandBlock> This returns list of commandBlocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        List<CommandBlock> commandBlocks = Lists.newArrayList();
        ports.forEach(port -> {
            constructCommandBlock(job.getDevice().getStablenetId(), port, commandBlocks);
        });
        if (commandBlocks!=null && !commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("true");
        }
        return commandBlocks;
    }

    /**
     * @param deviceId
     * @param port
     * @param commandBlocks
     */
    public void constructCommandBlock(Long deviceId, Port port, List<CommandBlock> commandBlocks) {
        List<PortHistory> portHistories = portHistoryRepository.findByIdAndWorkflowStatus(port.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        SlxPortModeDisableCommandBlock slxPortModeDisableCommandBlock = new SlxPortModeDisableCommandBlock();
        slxPortModeDisableCommandBlock.setDeviceId(deviceId.intValue());
        slxPortModeDisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(slxPortModeDisableCommandBlock);

        SlxPortDisableCommandBlock slxPortDisableCommandBlock = new SlxPortDisableCommandBlock();
        slxPortDisableCommandBlock.setDeviceId(deviceId.intValue());
        slxPortDisableCommandBlock.setPort(port.getPortNumber());
        commandBlocks.add(slxPortDisableCommandBlock);

        SlxPortDescriptionRecoveryCommandBlock slxPortDescriptionRecoveryCommandBlock = new SlxPortDescriptionRecoveryCommandBlock();
        slxPortDescriptionRecoveryCommandBlock.setDeviceId(deviceId.intValue());
        slxPortDescriptionRecoveryCommandBlock.setPort(port.getPortNumber());
        slxPortDescriptionRecoveryCommandBlock.setDescription(port.getCustomDescription());
        commandBlocks.add(slxPortDescriptionRecoveryCommandBlock);

        PortHistory portFromHistory = null;
        if (!portHistories.isEmpty() && portHistories.size() > 1) {
            portFromHistory = portHistories.get(1);
        } else {
            portHistories = portHistoryRepository.findByIdAndRevisionType(port.getId(), HistoryObject.RevisionType.CREATED);
            if (portHistories != null && portHistories.size() > 0) {
                portFromHistory = portHistories.stream().findFirst().get();
            }
        }
        if(portFromHistory != null && portFromHistory.getLineSpeed() != null && portFromHistory.getLineSpeed() > 0) {
            SLXPortRestLineSpeedCommandBlock slxPortRestLineSpeedCommandBlock = new SLXPortRestLineSpeedCommandBlock();
            slxPortRestLineSpeedCommandBlock.setDeviceId(port.getModule().getDevice().getStablenetId().intValue());
            slxPortRestLineSpeedCommandBlock.setPort(port.getPortNumber());
            slxPortRestLineSpeedCommandBlock.setLineSpeed(portFromHistory.getLineSpeed());
            commandBlocks.add(slxPortRestLineSpeedCommandBlock);
        }
    }

}
