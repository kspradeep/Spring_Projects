package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Status;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.exception.InterfaceMissingException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * The BscPolicyDeleteJobExecutor class implements methods to DELETE Policy through BSC on Open flow device
 */
@Slf4j
@Named
public class BscPolicyDeleteJobExecutor extends AbstractBscPolicyTransitionExecutor {

	@Override
	public List<Type> getSupportedJobTypes() {
		return Lists.newArrayList(Type.POLICY_DELETE);
	}

	@Override
	public Long startExternalJob(Job job) {
		// TODO Auto-generated method stub
		return null;
	}

    /**
     * This method is used to DELETE policy on device through BSC REST API
     *
     * @param job
     * @return
     */
	@Override
	public OutboundJobResponse execute(Job job) {
		Policy policyToDelete = (Policy) getParentObject(job);
        boolean jobExecutionStatus = deletePolicyOnDevice(job.getDevice(), policyToDelete);
        if (jobExecutionStatus) {
            return new OutboundJobResponse(Status.SUCCESS, "Delete Policy Successful on Device");
        } else {
            return new OutboundJobResponse(Status.FAILED, "Delete Policy Failed on Device");
        }
	}

    /**
     * This method is used to DELETE policy on Openflow device
     *
     * @param device
     * @param policy
     * @return
     */
    protected boolean deletePolicyOnDevice(Device device, Policy policy) {

        boolean isFlowDeletionSuccess= true;
        boolean isPGDeletionSuccess = true;

        List<String> flowsIdsAssociatedToPolicy = getFlowWithPolicyName(device.getOpenflowId(), policy.getName(), true);
		if(flowsIdsAssociatedToPolicy.size()>0) {
            // Added Parallel Stream which triggers multiple calls for deleting each rule in a Flow to Bsc as the flows on the BSC are independent.
            // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
            flowsIdsAssociatedToPolicy.parallelStream().forEach(eachFlow -> {
                log.info("Delete flows with id : " + eachFlow);
                deleteFlowOnDevice(device.getOpenflowId(), eachFlow);
            });
            isFlowDeletionSuccess = verifyFlow(device.getOpenflowId(), flowsIdsAssociatedToPolicy, false);
        }

		List<String> groupsIdsAssociatedToPolicy = getGroupNameWithPolicy(device.getOpenflowId(), policy.getId());
        if(groupsIdsAssociatedToPolicy.size()>0) {
            for (String groupId : groupsIdsAssociatedToPolicy) {
                log.info("Delete groups with id : " + groupId);
                if (!deleteGroupOnDevice(device.getOpenflowId(), groupId)) {
                    isPGDeletionSuccess = false;

                }
            }
        } else {
            groupsIdsAssociatedToPolicy = getGroupNameWithPolicy(device.getOpenflowId(), policy);
            if(groupsIdsAssociatedToPolicy.size()>0) {
                for (String groupId : groupsIdsAssociatedToPolicy) {
                    log.info("Delete groups with id : " + groupId);
                    if (!deleteGroupOnDevice(device.getOpenflowId(), groupId)) {
                        isPGDeletionSuccess = false;
                    }
                }
            }
        }

        boolean isPGCreationSuccess = true;
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            String openFlowDeviceId = policy.getDevice().getOpenflowId();
            for (Flow flow : policy.getFlows()) {
                Set<PortGroup> portGroups = flow.getEgressPortGroups();
                if (portGroups != null && portGroups.size() > 0) {
                    for (PortGroup portGroup : portGroups) {
                        Set<Port> ports = portGroup.getPorts();
                        // Converting port number to port name by prepending with 'eth'
                        List<String> portIds = ports.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toList());
                        Map<String, String> grpMap = getGroupNameIdMap(openFlowDeviceId);
                        Map<String, String> portIdNameMap = getPortNameIdMap(openFlowDeviceId);
                        List<String> portIdList = new ArrayList<>();
                        for (String portName : portIds) {
                            String portid = portIdNameMap.get(portName);
                            if (portid != null)
                                portIdList.add(portid);
                        }
                        String groupName = portGroup.getName() + "_select";
                        String groupId = grpMap.get(groupName);
                        String group = buildPortGroup(groupId, groupName.toString(), "group-select", portIdList);
                        isPGCreationSuccess = addGroupOnDevice(openFlowDeviceId, groupId, group);
                    }
                }
            }
        }


        if (isFlowDeletionSuccess && isPGDeletionSuccess && isPGCreationSuccess) {
            return true;
        }
        return false;
	}

    /**
     * This method used to get the existing group ids, group names on the Open Flow device
     *
     * @param deviceId
     * @return Map<String, List<String>> This returns map of groupIds and groupNames
     */
    protected Map<String, Set<String>> getPortGroupInfo(String deviceId) {
        Map<String, Set<String>> groupIdNameMap = new HashMap<>();
        Set<String> groupIdList = new HashSet<>();
        Set<String> groupNameList = new HashSet<>();
        try {
            Response res = bscConnection.get(configUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
            if (res != null && res.getStatus() == 200) {
                String xmlString = res.readEntity(String.class);
                JSONObject xmlJSONObj;
                try {
                    xmlJSONObj = XML.toJSONObject(xmlString);
                    String removeKey = "xmlns";
                    removeJSONField(xmlJSONObj, removeKey);
                    removeKey = "xmlns:x";
                    removeJSONField(xmlJSONObj, removeKey);
                    removeKey = "xmlns:s";
                    removeJSONField(xmlJSONObj, removeKey);
                    JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
                    if (realNode.has("group")) {
                        Object groupObj = realNode.get("group");
                        if (groupObj instanceof JSONObject) {// single group
                            JSONObject groupNode = (JSONObject) groupObj;
                            if (groupNode.has("group-name") && groupNode.has("group-id")) {
                                groupIdList.add(groupNode.get("group-id").toString());
                                groupNameList.add(groupNode.get("group-name").toString());
                            }
                        } else if (groupObj instanceof JSONArray) {
                            JSONArray groupNodes = (JSONArray) groupObj;
                            int size = groupNodes.length();
                            for (int i = 0; i < size; i++) {
                                JSONObject groupNode = groupNodes.getJSONObject(i);
                                if (groupNode.has("group-name") && groupNode.has("group-id")) {
                                    groupIdList.add(groupNode.get("group-id").toString());
                                    groupNameList.add(groupNode.get("group-name").toString());
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    log.error(e.getMessage());
                    return null;
                }
            }
        } catch (OutboundConnectionException e) {
            //TODO: Expected scenario as we are loading the groups from Config datastore.
            if (!e.getMessage().contains("404")) {
                throw e;
            }
        }
        groupIdNameMap.put("ids", groupIdList);
        groupIdNameMap.put("names", groupNameList);
        return groupIdNameMap;
    }

    /**
     * This method is used to remove the given JSON Field from the JSONObject
     *
     * @param obj
     * @param id
     */
    @SuppressWarnings("unchecked")
    protected void removeJSONField(JSONObject obj, String id) throws JSONException {
        obj.remove(id);
        Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            String key = it.next();
            Object childObj = obj.get(key);
            if (childObj instanceof JSONArray) {
                JSONArray arrayChildObjs = ((JSONArray) childObj);
                int size = arrayChildObjs.length();
                for (int i = 0; i < size; i++) {
                    try {
                        removeJSONField(arrayChildObjs.getJSONObject(i), id);
                    } catch (JSONException e) {
                        log.error(arrayChildObjs.toString());
                        e.printStackTrace();
                    }
                }
            }
            if (childObj instanceof JSONObject) {
                try {
                    removeJSONField(((JSONObject) childObj), id);
                } catch (JSONException e) {
                    log.error(childObj.toString());
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * This method is used to CREATE policy on Openflow device
     *
     * @param deviceId
     * @param openflowId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param grpIds
     * @param flowIds
     * @param egressSet
     * @param ingressSet
     * @param portGroups
     * @param ruleSet
     * @param flowPriority
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean addPolicyOnDecvice(Long deviceId, String openflowId, String policyName, Long policyId, Map<String, String> portIdNameMap,
                                         Set<String> grpIds, Set<String> flowIds, Set<String> egressSet, Set<String> ingressSet, Set<PortGroup> portGroups,
                                         Set<RuleSet> ruleSet, int flowPriority, String setVlan, String srcMacTag, String destMacTag, boolean vlanStripping) {
        boolean jobResult = false;
        List<Rule> flatRules = getFlatRules(ruleSet);

        if (ingressSet != null && ingressSet.size() > 0) {
            if (egressSet != null && egressSet.size() > 0) {
                if (ingressSet.size() == 1 && egressSet.size() == 1) {
                    jobResult = addFlowForSingleEgressAndIngress(openflowId, policyName,portIdNameMap,flatRules, flowPriority,flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(), setVlan,srcMacTag,destMacTag,policyId);
                } else if (ingressSet.size() > 1 && egressSet.size() == 1) {
                    jobResult = addFlowForSingleEgressAndMultipleIngress(grpIds,openflowId, policyName,policyId,portIdNameMap,flatRules, flowPriority,flowIds, egressSet.parallelStream().findAny().get(), ingressSet, setVlan,srcMacTag,destMacTag, deviceId, vlanStripping);
                } else if (egressSet.size() > 1) {
                    jobResult = addFlowForMultipleEgress(grpIds, openflowId, policyName,policyId,portIdNameMap, flatRules, flowPriority,flowIds, egressSet, ingressSet, setVlan,srcMacTag,destMacTag, deviceId, vlanStripping);
                }
            }
            else {
                jobResult = addFlowForPortGroups(deviceId, openflowId, flowIds, portIdNameMap, flatRules, flowPriority,policyName, portGroups, ingressSet, setVlan, grpIds, srcMacTag, destMacTag, vlanStripping, policyId);
            }
            //TODO: if any of the above add flow fails , should we set the job to fail?
        } else {
            log.info("ingress set invalid");
        }
        return jobResult;
    }

    /**
     * This method is used to create flow for Single Egress and Ingress
     *
     * @param deviceId
     * @param policyName
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egress
     * @param ingress
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean addFlowForSingleEgressAndIngress(String deviceId, String policyName, Map<String, String> portIdNameMap,
                                                       List<Rule> flatRules, int flowPriority, Set<String> flowIds, String egress, String ingress, String setVlan, String srcMacTag, String destMacTag, Long policyId) {
        log.info("Creating base flow...");
        boolean jobVerifyResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        String egressPortId = portIdNameMap.get(egress);
        String ingressPortId = portIdNameMap.get(ingress);

        // TODO: check if open flow id or db id?

        log.info("Check : {} - {}", ingressPortId, egressPortId);
        if (egressPortId != null && ingressPortId != null) {
            final String egressPortIdForOF = egressPortId.substring(egressPortId.lastIndexOf(":") + 1, egressPortId.length());
            log.info("Check : {} - {}", ingressPortId, egressPortIdForOF);
            // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
            // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
            flatRules.parallelStream().forEach(rule ->{
                boolean jobResult = false;
                String flowId = bscIdGenerator.getFlowId(flowIds);

                String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                log.info("Policy_{} : flowId : {}", policyId, flowId);
                String flow = buildFlow(flowId, flowName.toString(), ingressPortId, egressPortIdForOF, true, queueId, rule,
                        flowPriority, setVlan, srcMacTag, destMacTag);

                log.info("flow  : {} ", flow);
                jobResult = addFlowOnDevice(deviceId, flowId, flow);
                currentFlowIds.add(flowId);
                if(currentFlowIds.size()%1000 == 0){
                    waitForFlowToPushOnDevice();
                    log.debug("Sleeping after flow count reached : "+currentFlowIds.size());
                }
            });
            jobVerifyResult = verifyFlow(deviceId,currentFlowIds,true);

        }
        return jobVerifyResult;
    }

    /**
     * This method is used to create flow for single Egress and multiple Ingress
     *
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egress
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean addFlowForSingleEgressAndMultipleIngress(Set<String> grpIds, String deviceId, String policyName, Long policyId,
                                                               Map<String, String> portIdNameMap, List<Rule> flatRules, int flowPriority, Set<String> flowIds, String egress,
                                                               Set<String> ingressSet, String setVlan, String srcMacTag, String destMacTag, Long bvmDeviceId, boolean vlanStripping) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        List<String> portIds = new ArrayList<String>();
        List<String> portKeys = new ArrayList<String>();
        StringBuilder groupName = new StringBuilder(getGroupName(policyId,"ag", flowPriority));
        String portId = portIdNameMap.get(egress);
        portKeys.add(portId);
        portIds.add(portId);
        Collections.sort(portKeys);

        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }

        String groupId = bscIdGenerator.getGroupId(grpIds);

        String group = "";

        Device device = deviceRepository.findById(bvmDeviceId);
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            group = buildGroupWithVLan(groupId, groupName.toString(), "group-indirect", portIds, setVlan, "", "", vlanStripping);
            setVlan = "";
        } else {
            group = buildGroup(groupId, groupName.toString(), "group-indirect", portIds);
        }
        final String vlan = setVlan;
        if (addGroupOnDevice(deviceId, groupId, group)) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e1) {
                throw new ServerException(e1);
            }
            for (String port : ingressSet) {
                String ingressPortId = portIdNameMap.get(port);
                if (ingressPortId != null) {
                    // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
                    // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
                    flatRules.parallelStream().forEach(rule ->{
                        String flowId = bscIdGenerator.getFlowId(flowIds);
                        String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                        log.info("Policy_{} : flowId : {}", policyId, flowId);
                        String flow = buildFlow(flowId, flowName.toString(), ingressPortId, groupId, false, queueId,
                                rule, flowPriority,vlan,srcMacTag,destMacTag);
                        addFlowOnDevice(deviceId, flowId, flow);
                        currentFlowIds.add(flowId);
                    });
                }
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);
        } else {
            log.info("Add group on Device Failed");
        }
        return jobResult;
    }

    /**
     * This method is used to create flow for multiple Egress and multiple Ingress
     *
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egressSet
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean addFlowForMultipleEgress(Set<String> grpIds, String deviceId, String policyName, Long policyId,
                                               Map<String, String> portIdNameMap, List<Rule> flatRules, int flowPriority, Set<String> flowIds, Set<String> egressSet,
                                               Set<String> ingressSet, String setVlan, String srcMacTag, String destMacTag, Long bvmDeviceId, boolean vlanStripping) {
        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        List<String> portIds = new ArrayList<>();
        List<String> portKeys = new ArrayList<>();
        StringBuilder groupName = new StringBuilder(getGroupName(policyId,"lb", flowPriority));
        for (String port : egressSet) {
            String portid = portIdNameMap.get(port);
            portKeys.add(portid);
            portIds.add(portid);
        }
        Collections.sort(portKeys);
        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }

        String groupId = bscIdGenerator.getGroupId(grpIds);
        String group = "";

        Device device = deviceRepository.findById(bvmDeviceId);
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            group = buildGroupWithVLan(groupId, groupName.toString(), "group-all", portIds, setVlan, "", "", vlanStripping);
            setVlan = "";
        } else {
            group = buildGroup(groupId, groupName.toString(), "group-all", portIds);
        }
        final String vlan = setVlan;
        if (addGroupOnDevice(deviceId, groupId, group)) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e1) {
                throw new ServerException(e1);
            }
            for (String port : ingressSet) {
                String ingressPortId = portIdNameMap.get(port);
                if (ingressPortId != null) {
                    // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
                    // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
                    flatRules.parallelStream().forEach(rule ->{
                        String flowId = bscIdGenerator.getFlowId(flowIds);
                        String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                        log.info("Policy_{} : flowId : {}", policyId, flowId);
                        String flow = buildFlow(flowId, flowName.toString(), ingressPortId, groupId, false, queueId,
                                rule, flowPriority,vlan,srcMacTag,destMacTag);
                        addFlowOnDevice(deviceId, flowId, flow);
                        currentFlowIds.add(flowId);
                    });
                }
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        } else {
            log.info("Add group on Device Failed");
        }
        return jobResult;
    }

    /**
     * This method is used to create Flow with PortGroups on the device
     *
     * @param deviceId
     * @param openflowId
     * @param flowIds
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param policyName
     * @param portGroups
     * @param ingressSet
     * @param setVlan
     * @param grpIds
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean addFlowForPortGroups(Long deviceId, String openflowId,Set<String> flowIds,
                                         Map<String, String> portIdNameMap, List<Rule> flatRules,
                                         int flowPriority, String policyName, Set<PortGroup> portGroups,
                                         Set<String> ingressSet, String setVlan, Set<String> grpIds,String srcMacTag,String destMacTag, boolean vlanStripping, Long policyId) {

        boolean jobResult= false;
        Device device = deviceRepository.findById(deviceId);
        if (device != null && device.getOs().contains("08.0.50") && setVlan != null && setVlan.trim().length() > 0) {
            // ICX till 8.0.50 supports only 1 Port group on egress in policy

            if (portGroups != null && portGroups.size() > 0) {
                Set<String> egressSet = null;
                for (PortGroup portGroup : portGroups) {
                    Set<Port> ports = portGroup.getPorts();
                    egressSet = ports.stream().map(port -> port.getOpenFlowPortNumber())
                            .collect(Collectors.toSet());

                    jobResult = createFlowWithPortGroupAndVLan(grpIds, openflowId, policyName,
                            portIdNameMap, flatRules, flowPriority,flowIds, egressSet,
                            ingressSet, setVlan,srcMacTag,destMacTag, vlanStripping, policyId);
                }
            }
        } else if (device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW && ((setVlan != null && setVlan.trim().length() > 0) || vlanStripping)) {
            if (portGroups != null && portGroups.size() > 0) {
                Set<String> egressSet = null;
                for (PortGroup portGroup : portGroups) {
                    Set<Port> ports = portGroup.getPorts();
                    egressSet = ports.stream().map(port -> port.getOpenFlowPortNumber())
                            .collect(Collectors.toSet());

                    jobResult = createFlowWithPortGroupAndVLanForSLX(grpIds, openflowId, portGroup.getName(), policyName,
                            portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                            ingressSet, setVlan, srcMacTag, destMacTag, vlanStripping);
                }
            }
        } else
            jobResult = createFlowWithPortGroup(openflowId, flowIds, portIdNameMap,
                    flatRules, flowPriority,policyName, portGroups, ingressSet, setVlan,srcMacTag,destMacTag, policyId);

        return jobResult;
    }

    /**
     * This method is used to create flow with Port Group on the device
     *
     * @param deviceId
     * @param flowIds
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param policyName
     * @param portGroups
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
     */
    protected boolean createFlowWithPortGroup(String deviceId, Set<String> flowIds,
                                            Map<String, String> portIdNameMap, List<Rule> flatRules,
                                            int flowPriority,String policyName, Set<PortGroup> portGroups,
                                            Set<String> ingressSet, String setVlan,String srcMacTag,String destMacTag, Long policyId) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        if (portGroups != null && portGroups.size() > 0) { // add lag flow
            // here...
            Map<String, String> lagMap = getLagGroupNameIdMap(deviceId,
                    "group-select");
            log.info("Get lag Map : " + lagMap);
            for (PortGroup portGroup : portGroups) {
                String lagId = lagMap.get(portGroup.getName() + "_select");
                for (String port : ingressSet) {
                    String ingressPortId = portIdNameMap.get(port);
                    if (ingressPortId != null) {
                        // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
                        // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
                        flatRules.parallelStream().forEach(rule ->{
                            String flowId = bscIdGenerator.getFlowId(flowIds);
                            String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                            log.info("Policy_{} : flowId : {}", policyId, flowId);
                            String flow = buildFlow(flowId,
                                    flowName.toString(), ingressPortId, lagId,
                                    false, queueId, rule, flowPriority,setVlan,srcMacTag,destMacTag);
                            addFlowOnDevice(deviceId, flowId, flow);
                            currentFlowIds.add(flowId);
                        });
                    }
                }
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        }
        return jobResult;
    }

    /**
     * This method is used to create flow with Port Group and VLAN on the device
     *
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egressSet
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
             */
    protected boolean createFlowWithPortGroupAndVLan(Set<String> grpIds,
                                                     String deviceId, String policyName,
                                                     Map<String, String> portIdNameMap, List<Rule> flatRules,
                                                     int flowPriority,Set<String> flowIds, Set<String> egressSet,
                                                     Set<String> ingressSet, String setVlan,String srcMacTag,String destMacTag, boolean vlanStripping, Long policyId) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        List<String> portIds = new ArrayList<>();
        List<String> portKeys = new ArrayList<>();
        StringBuilder groupName = new StringBuilder(policyName);
        groupName.append("_lb");
        for (String port : egressSet) {
            String portid = portIdNameMap.get(port);
            portKeys.add(portid);
            if (portid != null)
                portIds.add(portid);
        }
        Collections.sort(portKeys);
        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }

        String groupId = bscIdGenerator.getGroupId(grpIds);
        String group = buildGroupWithVLan(groupId, groupName.toString(),
                "group-select", portIds, setVlan, srcMacTag, destMacTag, vlanStripping);
        if (addGroupOnDevice(deviceId, groupId, group)) {
            for (String port : ingressSet) {
                String ingressPortId = portIdNameMap.get(port);
                if (ingressPortId != null) {
                    // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
                    // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
                    flatRules.parallelStream().forEach(rule ->{
                        String flowId = bscIdGenerator.getFlowId(flowIds);
                        String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                        log.info("Policy_{} : flowId : {}", policyId, flowId);
                        String flow = buildFlow(flowId, flowName.toString(),
                                ingressPortId, groupId, false, queueId, rule,
                                flowPriority,null,null,null);
                        addFlowOnDevice(deviceId, flowId, flow);
                        currentFlowIds.add(flowId);
                    });
                }
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        } else {
            log.info("Add group on Device Failed");
        }
        return jobResult;
    }
    /*
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egressSet
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @return
             */
    protected boolean createFlowWithPortGroupAndVLanForSLX(Set<String> grpIds,
                                                     String deviceId, String portGroupName, String policyName,
                                                     Map<String, String> portIdNameMap, List<Rule> flatRules,
                                                     int flowPriority,Set<String> flowIds, Set<String> egressSet,
                                                     Set<String> ingressSet, String setVlan,String srcMacTag,String destMacTag, boolean vlanStripping) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        Map<String, String> grpMap = getGroupNameIdMap(deviceId);// not null check
        String groupName = portGroupName + "_select";
        String groupId = grpMap.get(groupName);
        if (groupId != null) {
            List<String> portIdList = new ArrayList<>();
            for (String portName : egressSet) {
                String portid = portIdNameMap.get(portName);
                if (portid != null)
                    portIdList.add(portid);
            }
            checkIfValidInterface(portIdNameMap, egressSet);
            log.info("Group Name : " + groupName);
            String group = buildGroupWithVLan(groupId, groupName.toString(), "group-select", portIdList, setVlan, srcMacTag, destMacTag, vlanStripping);
            jobResult = addGroupOnDevice(deviceId, groupId, group);
            if (!jobResult) {
                return false;
            }
        }
        for (String port : ingressSet) {
            String ingressPortId = portIdNameMap.get(port);
            if (ingressPortId != null) {
                // Added Parallel Stream which triggers multiple calls for each rule in a Flow to Bsc for creating flows as the rules are independent.
                // The number threads that are spanned by the parallel stream = number Host Machine's CPU.
                flatRules.parallelStream().forEach(rule ->{
                    String flowId = bscIdGenerator.getFlowId(flowIds);
                    String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                    String flow = buildFlow(flowId, flowName.toString(),
                            ingressPortId, groupId, false, queueId, rule,
                            flowPriority,null,null,null);
                    addFlowOnDevice(deviceId, flowId, flow);
                    currentFlowIds.add(flowId);
                });
            }
        }
        jobResult = verifyFlow(deviceId,currentFlowIds,true);
        return jobResult;
    }

    /**
     * This method is used to check participating port(Ingress/Egress) in Policy having openflow enabled or not
     * If not it will throw Exception
     *
     * @param portIdNameMap
     * @param ports
     * @throws InterfaceMissingException
     */
    protected void checkIfValidInterface(Map<String, String> portIdNameMap, Set<String> ports) throws InterfaceMissingException {
        List<String> nonOpenflowPorts=null;
        for (String port : ports) {
            if (!portIdNameMap.containsKey(port)) {
                nonOpenflowPorts = nonOpenflowPorts == null ? new ArrayList<>() : nonOpenflowPorts;
                log.error("Unable to get the Openflow id for the interface " + port);
                nonOpenflowPorts.add(port);
            }
        }
        if(nonOpenflowPorts !=null && nonOpenflowPorts.size() > 0){
            throw new InterfaceMissingException("Please check if openflow is enabled on interface(s). " + String.join(" / ", nonOpenflowPorts) +"\nNote: If OS upgrade is done please do re-discovery from stablenet.");
        }
    }
}
