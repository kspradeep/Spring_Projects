package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetPortTypeJobExecutor class implements methods to mark selected port(s) as ingress/egress/none on Non Open Flow device through Stablenet
 */
@Named
public class StablenetPortTypeJobExecutor extends AbstractStablenetJobExecutor {

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String INTERFACE_ENTER = "interface ethernet %s;";
    private static final String INTERFACE_EXIT = "exit;";
    private static final String TERMINAL_EXIT = "end;";
    private static final String SAVE_RUNNING_CONFIG = "write memory;";
    private static final String PORT_BLOCK_IN = "mac access-group DENY_ANY in;";
    private static final String PORT_UNBLOCK_IN = "no mac access-group DENY_ANY in;";
    private static final String PORT_BLOCK_OUT = "mac access-group DENY_ANY out;";
    private static final String PORT_UNBLOCK_OUT = "no mac access-group DENY_ANY out;";
    private static final String NO_LOOPBACK = "no loopback system;";

    /**
     * This method constructs commands to mark port as ingress/egress/none on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(TERMINAL_ENTER);
        getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .forEach(port -> {
                    commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));
                    if (port.getType() == Port.Type.EGRESS) {
                        //Set egress ports as uni-directional
                        commands.append(PORT_UNBLOCK_IN);
                        commands.append(PORT_UNBLOCK_OUT);
                        commands.append(PORT_BLOCK_IN);
                    } else if (port.getType() == Port.Type.INGRESS) {
                        //Set ingress ports as uni-directional
                        commands.append(PORT_UNBLOCK_IN);
                        commands.append(PORT_UNBLOCK_OUT);
                        commands.append(PORT_BLOCK_OUT);
                    } else {
                        commands.append(PORT_UNBLOCK_IN);
                        commands.append(PORT_UNBLOCK_OUT);
                    }
                    commands.append(NO_LOOPBACK);
                    commands.append(INTERFACE_EXIT);
                });
        commands.append(TERMINAL_EXIT);
        commands.append(SAVE_RUNNING_CONFIG);

        return commands.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_INGRESS, Job.Type.PORT_MARK_EGRESS, Job.Type.PORT_MARK_NONE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }
}
