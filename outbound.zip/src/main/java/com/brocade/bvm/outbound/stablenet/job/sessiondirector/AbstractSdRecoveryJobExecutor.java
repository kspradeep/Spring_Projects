package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetRecoveryJobExecutor;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * Abstract class for SD recover concrete classes.
 *
 */

public abstract class AbstractSdRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }
}
