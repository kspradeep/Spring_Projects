package com.brocade.bvm.outbound.grid;

import com.brocade.bvm.dao.grid.GridMatrixHistoryRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.GridMatrix;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.outbound.grid.model.ToolAddressInterface;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Named
@Slf4j
public class ConfigureToolAddressExecutor extends AbstractStablenetJobExecutor {

    //[no] pbf-destination UMBENR [count]
    private static final String PBF_DESTINATION = "pbf destination %d %s;";

    private static final String NO_PBF_DESTINATION = "no pbf destination %d %s;";

    //[no] [precedence NUMBER] set interface {ethernet SLOT/PORT | port-channel} [type-fabric]
    private static final String PBF_DESTINATION_SET_INTERFACE = "set interface %s %s %s;";

    private static final String NO_PBF_DESTINATION_SET_INTERFACE = "no set interface %s %s;";

    private static final String ETHERNET = "ethernet";
    private static final String PORT_CHANNEL = "port-channel";
    private static final String FABRIC = "type-fabric";
    private static final String EDGE = "EDGE";
    private static final String COUNT = "count";

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridMatrixHistoryRepository gridMatrixHistoryRepository;

    /**
     * This method constructs CLI to configure the tool address on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();
        GridMatrix gridMatrix = (GridMatrix) getParentObject(job);
        Device device = job.getDevice();
        command.append(CONFIGURE_TERMINAL);
        if (gridMatrix != null) {
            if (job.getType() == Job.Type.GRID_TOOL_ADDRESS_UPDATE) {
                GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                command.append(updateToolAddress(gridMatrix, gridMatrixHistory, device.getId()));
            } else if (job.getType() == Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE) {
                GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = getToolAddressMap(gridMatrix.getGridTopologyPaths(), device.getId());
                if (gridMatrixHistory != null) {
                    Map<Integer, ToolAddressInterface> groupToolInterfaceHistoryMap = getToolAddressMap(gridMatrixHistory.getGridTopologyPaths(), device.getId());
                    if (toolAddressInterfaceMap != null && groupToolInterfaceHistoryMap != null) {
                        groupToolInterfaceHistoryMap.forEach((toolAddress, toolAddressExisting) -> {
                            ToolAddressInterface toolAddressUpdated = toolAddressInterfaceMap.get(toolAddress);
                            if (toolAddressUpdated == null) {
                                command.append(removeToolAddress(toolAddressExisting));
                            }
                        });
                    }
                } else if (toolAddressInterfaceMap != null) {
                    toolAddressInterfaceMap.forEach((toolAddress, toolAddressInterface) -> {
                        command.append(removeToolAddress(toolAddressInterface));
                    });
                }
            } else {
                Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = getToolAddressMap(gridMatrix.getGridTopologyPaths(), device.getId());
                toolAddressInterfaceMap.forEach((toolAddress, toolAddressInterface) -> {
                    if (job.getType() == Job.Type.GRID_TOOL_ADDRESS_CREATE) {
                        command.append(createToolAddress(toolAddressInterface));
                    } else if (job.getType() == Job.Type.GRID_TOOL_ADDRESS_DELETE) {
                        command.append(removeToolAddress(toolAddressInterface));
                    }
                });
            }
        }
        command.append(EXIT);
        log.debug("ConfigureToolAddressExecutor on device:{} command:{} ", device.getId(), command.toString());
        return command.toString();
    }

    private String createToolAddress(ToolAddressInterface toolAddressInterface) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(PBF_DESTINATION, toolAddressInterface.getToolAddress(), toolAddressInterface.isCountEnabled() ? COUNT : ""));
        toolAddressInterface.getManagedObjects().forEach(managedObject -> {
            if (managedObject instanceof Port) {
                command.append(String.format(PBF_DESTINATION_SET_INTERFACE, ETHERNET, ((Port) managedObject).getPortNumber(), FABRIC.equals(toolAddressInterface.getType()) ? toolAddressInterface.getType() : ""));
            } else if (managedObject instanceof PortGroup) {
                command.append(String.format(PBF_DESTINATION_SET_INTERFACE, PORT_CHANNEL, managedObject.getName(), FABRIC.equals(toolAddressInterface.getType()) ? toolAddressInterface.getType() : ""));
            }
        });
        command.append(EXIT);
        return command.toString();
    }

    private String updateToolAddress(GridMatrix gridMatrix, GridMatrix gridMatrixHistory, Long deviceId) {
        StringBuilder command = new StringBuilder();
        if (gridMatrixHistory != null && gridMatrix != null) {
            Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = getToolAddressMap(gridMatrix.getGridTopologyPaths(), deviceId);
            Map<Integer, ToolAddressInterface> groupToolInterfaceHistoryMap = getToolAddressMap(gridMatrixHistory.getGridTopologyPaths(), deviceId);
            if (toolAddressInterfaceMap != null && groupToolInterfaceHistoryMap != null) {
                groupToolInterfaceHistoryMap.forEach((toolAddress, toolAddressExisting) -> {
                    ToolAddressInterface toolAddressUpdated = toolAddressInterfaceMap.get(toolAddress);
                    if (toolAddressUpdated == null) {
                        command.append(removeToolAddress(toolAddressExisting));
                    }
                });
                toolAddressInterfaceMap.forEach((toolAddress, toolAddressUpdated) -> {
                    ToolAddressInterface toolAddressExisting = groupToolInterfaceHistoryMap.get(toolAddress);
                    if (toolAddressExisting != null) {
                        if (!compare(toolAddressUpdated, toolAddressExisting)) {
                            command.append(updateToolAddress(toolAddressUpdated, toolAddressExisting));
                        }
                    } else {
                        command.append(createToolAddress(toolAddressUpdated));
                    }
                });
            }
        }
        return command.toString();
    }

    private String updateToolAddress(ToolAddressInterface toolAddressInterfaceUpdated, ToolAddressInterface toolAddressInterfaceExisting) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(PBF_DESTINATION, toolAddressInterfaceUpdated.getToolAddress(), toolAddressInterfaceUpdated.isCountEnabled() ? COUNT : ""));
        toolAddressInterfaceExisting.getManagedObjects().forEach(managedObject -> {
            if (managedObject instanceof Port) {
                command.append(String.format(NO_PBF_DESTINATION_SET_INTERFACE, ETHERNET, ((Port) managedObject).getPortNumber()));
            } else if (managedObject instanceof PortGroup) {
                command.append(String.format(NO_PBF_DESTINATION_SET_INTERFACE, PORT_CHANNEL, managedObject.getName()));
            }
        });
        toolAddressInterfaceUpdated.getManagedObjects().forEach(managedObject -> {
            if (managedObject instanceof Port) {
                command.append(String.format(PBF_DESTINATION_SET_INTERFACE, ETHERNET, ((Port) managedObject).getPortNumber(), FABRIC.equals(toolAddressInterfaceUpdated.getType()) ? toolAddressInterfaceUpdated.getType() : ""));
            } else if (managedObject instanceof PortGroup) {
                command.append(String.format(PBF_DESTINATION_SET_INTERFACE, PORT_CHANNEL, managedObject.getName(), FABRIC.equals(toolAddressInterfaceUpdated.getType()) ? toolAddressInterfaceUpdated.getType() : ""));
            }
        });
        command.append(EXIT);
        return command.toString();
    }

    private String removeToolAddress(ToolAddressInterface toolAddressInterface) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(NO_PBF_DESTINATION, toolAddressInterface.getToolAddress(), toolAddressInterface.isCountEnabled() ? COUNT : ""));
        return command.toString();
    }

    private Map<Integer, ToolAddressInterface> getToolAddressMap(Set<GridTopologyPath> gridTopologyPaths, Long deviceId) {
        Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = Maps.newHashMap();
        if (gridTopologyPaths != null) {
            gridTopologyPaths.forEach(gridTopologyPath -> {
                if (gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setType(FABRIC);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getSourceNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else if (gridTopologyPath.getDestinationNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setType(EDGE);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getDestinationNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else {
                    gridTopologyPath.getIntermediateNodes().forEach(intermediateNode -> {
                        if (intermediateNode.getDevice().getId() == deviceId) {
                            Integer toolAddress = gridTopologyPath.getToolAddress();
                            if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                                ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                                toolAddressInterface.setToolAddress(toolAddress);
                                toolAddressInterface.setManagedObjects(intermediateNode.getEgressPortsAndPortGroups());
                                toolAddressInterface.setType(FABRIC);
                                toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                            }
                        }
                    });
                }
            });
        }
        return toolAddressInterfaceMap;
    }

    private boolean compare(ToolAddressInterface toolAddressInterfaceUpdated, ToolAddressInterface toolAddressInterfaceExisting) {
        if (toolAddressInterfaceUpdated != null && toolAddressInterfaceExisting != null) {
            if (toolAddressInterfaceUpdated.getType() != null && toolAddressInterfaceUpdated.getType().equals(toolAddressInterfaceExisting.getType()) &&
                    toolAddressInterfaceUpdated.getToolAddress() != null && toolAddressInterfaceUpdated.getToolAddress() == toolAddressInterfaceExisting.getToolAddress() &&
                    toolAddressInterfaceUpdated.getManagedObjects().size() != 0 && toolAddressInterfaceUpdated.getManagedObjects().size() == toolAddressInterfaceExisting.getManagedObjects().size()) {
                Set<Long> updatedManagedObjectIds = toolAddressInterfaceUpdated.getManagedObjects().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                Set<Long> existingManagedObjectIds = toolAddressInterfaceExisting.getManagedObjects().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                Set<Long> differenceSet = Sets.difference(updatedManagedObjectIds, existingManagedObjectIds);
                if (differenceSet.isEmpty())
                    return true;
            }
        }
        return false;
    }

    private GridMatrix getGridMatrixFromHistory(Long matrixId) {
        List<GridMatrixHistory> gridMatrixHistoryList = gridMatrixHistoryRepository.findByIdAndWorkflowStatus(matrixId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GridMatrix gridMatrix = null;
        if (gridMatrixHistoryList.size() >= 1) {
            GridMatrixHistory gridMatrixHistory = gridMatrixHistoryList.get(0);
            gridMatrix = gridMatrixHistory.buildParent();
        }
        return gridMatrix;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GRID_TOOL_ADDRESS_CREATE, Job.Type.GRID_TOOL_ADDRESS_DELETE, Job.Type.GRID_TOOL_ADDRESS_UPDATE, Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}

