package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetPacketSlicingModulePolicyCommitJobExecutor class implements methods to create PacketSlicingModulePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetPacketSlicingModulePolicyCommitJobExecutor extends AbstractPacketSlicingModulePolicyJobExecutor {

    /**
     * This method constructs create PacketSlicingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketSlicingModulePolicy modulePolicy = (PacketSlicingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getModules().forEach(module -> {
            command.append(String.format(MODULE_POLICY_EGRESS_TRUNCATE_FORMAT, modulePolicy.getNumberOfBytes(), module.getModuleNumber()));
        });

        modulePolicy.getPorts().stream().forEach(port -> {
            command.append(String.format(PORT_EGRESS_TRUNCATE_FORMAT, port.getPortNumber()));
        });
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_SLICING_MODULE_POLICY_CREATE);
    }
}
