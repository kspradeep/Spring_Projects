package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Named;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
public abstract class AbstractSLXPolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    protected static final String SET_NEXT_HOP_TVF_DOMAIN = "set next-hop-tvf-domain %s";

    protected static final String NEXT_HOP = "set interface %s %s";

    protected static final String EXIT = "exit;";

    protected static final String IP = "ip";

    protected static final String IPV6 = "ipv6";

    protected static final String MAC = "mac";

    protected static final String UDA = "uda";

    protected static final String NPB = "npb";

    protected static final String CMD_PERMIT = "permit";

    protected static final String ETHERNET = "ethernet";

    protected static final String PBF_DESTINATION_GROUP = "pbf-destination-group";

    protected static final String PORT_CHANNEL = "port-channel";

    protected static final String SPACE = " ";

    protected static final String SEQUENCE = "seq";

    protected static final String NO_WITH_COMMAND = "no %s\n";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_ROLLBACK);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    protected int isSLXSupportsTelemetry(String deviceOs) {
        if (!Strings.isNullOrEmpty(deviceOs)) {
            Pattern pattern = Pattern.compile("^([A-Za-z\\s]*)([\\d]+)([a-z])([\\.])([\\d+])([\\.])([0-9]+)");
            Matcher matcher = pattern.matcher(String.valueOf(deviceOs));
            if (matcher.find() && matcher.groupCount() == 7) {
                if ("s".equals(matcher.group(3))) {
                    StringBuilder currentVersion = new StringBuilder();
                    currentVersion.append(matcher.group(2)).append(".").append(matcher.group(5)).append(".").append(matcher.group(7));
                    if (!currentVersion.toString().isEmpty()) {
                        int compareOutput = compareVersions(currentVersion.toString(), slxTelemetrySupportedVersion);
                        return compareOutput;
                    }
                }
            }
        }
        return -1;
    }

    private int compareVersions(String version1, String version2) {
        if (version1 != null && version2 != null) {
            String[] components1 = (version1.trim()).split("\\.");
            String[] components2 = (version2.trim()).split("\\.");
            int length = Math.min(components1.length, components2.length);
            for (int i = 0; i < length; i++) {
                int result = new Integer(components1[i]).compareTo(Integer.parseInt(components2[i]));
                if (result != 0) {
                    return result;
                }
            }
            return Integer.compare(components1.length, components2.length);
        } else {
            return -1;
        }
    }
}
