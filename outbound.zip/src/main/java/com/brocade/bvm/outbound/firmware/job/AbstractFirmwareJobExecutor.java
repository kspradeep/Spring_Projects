package com.brocade.bvm.outbound.firmware.job;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.outbound.FirmwareOutboundJobExecutor;
import com.brocade.bvm.outbound.stablenet.service.InitialDeviceConfiguration;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
public abstract class AbstractFirmwareJobExecutor implements FirmwareOutboundJobExecutor {

    @Value("${slx.tacacs.authorization.supported.os.version:18.1.03}")
    private String slxTacacsAuthorizationSupportedVersion;

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTacacsAuthenticationSupportedVersion;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private InitialDeviceConfiguration initialDeviceConfiguration;

    protected String getOsVersionFromResponse(String response) {
        String updatedOsVersion = "";
        try {
            if (response != null && response.contains("Firmware name:") && response.split("Firmware")[1].split(":")[1].split("\n")[0] != null)
                updatedOsVersion = response.split("Firmware")[1].split(":")[1].split("\n")[0].trim();
        } catch (Exception e) {
            log.error("Error while finding firmware version from device. {}", e.getMessage());
        }
        return updatedOsVersion;
    }

    protected void syncOsAndTacInfo(Device device, String ugradedDeviceOsVersion) {
        if (device != null && device.getId() != null) {
            StringBuilder logMessage = new StringBuilder();
            Device deviceFromDb = deviceRepository.findById(device.getId());
            String existingDeviceOsVersion = deviceFromDb.getOs();
            if (!Strings.isNullOrEmpty(existingDeviceOsVersion) && !Strings.isNullOrEmpty(ugradedDeviceOsVersion)) {
                Pattern patternVersion = Pattern.compile("^([A-Za-z\\s]*)([\\d]+)([a-z])([\\.])([\\d+])([\\.])([0-9]+)");
                Matcher matcherVersion = patternVersion.matcher(existingDeviceOsVersion);
                String existingOsVersionTrimmed = null;
                if (matcherVersion.find()) {
                    existingOsVersionTrimmed = matcherVersion.group();
                    existingOsVersionTrimmed = existingOsVersionTrimmed.replace("v", "").replace("s", "");
                }

                if (existingOsVersionTrimmed != null && initialDeviceConfiguration.isSLXSupportsTelemetry(ugradedDeviceOsVersion, existingOsVersionTrimmed) < 0) {
                    if (initialDeviceConfiguration.isSLXSupportsTelemetry(ugradedDeviceOsVersion, slxTacacsAuthenticationSupportedVersion) < 0) {
                        if (deviceFromDb.isProfileConfigured()) {
                            deviceFromDb.setProfileConfigured(false);
                            logMessage.append(" telemetry ");
                        }
                        if (deviceFromDb.isAuthenticationConfigured()) {
                            deviceFromDb.setAuthenticationConfigured(false);
                            logMessage.append(" authentication ");
                        }
                    }
                    if (deviceFromDb.isAuthorizationConfigured() && initialDeviceConfiguration.isSLXSupportsTelemetry(ugradedDeviceOsVersion, slxTacacsAuthorizationSupportedVersion) < 0) {
                        deviceFromDb.setAuthorizationConfigured(false);
                        logMessage.append(" authorization ");
                    }
                }
                deviceFromDb.setOs(ugradedDeviceOsVersion);
                logMessage.append(" OS version after upgrade/reboot to ");
                deviceRepository.save(deviceFromDb);
                log.debug("Device with id: {} updated, {} {}.", deviceFromDb.getId(), logMessage, ugradedDeviceOsVersion);
            }
        }
    }

}
