package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.GtpDeEncapsulationModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.GtpDeEncapsulationCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class GtpDeEncapsulationModulePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_ROLLBACK);
    }

    /**
     * This method constructs GtpDeEncapsulationModulePolicy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        GtpDeEncapsulationModulePolicy modulePolicyToDelete = (GtpDeEncapsulationModulePolicy) getParentObject(job);
        log.debug("StablenetGtpDeEncapsulationModulePolicyRecoveryJobExecutor Job executor for policy id {}", modulePolicyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(modulePolicyToDelete);
        log.debug("Number of command blocks constructed for module policy id {} is :{} and Device-ID is {}", modulePolicyToDelete.getId(), commandBlocks.size(), modulePolicyToDelete.getDevice().getId());
        return commandBlocks;
    }

    /**
     * This method constructs PacketSlicingModulePolicy recovery command blocks for the given policy
     *
     * @param modulePolicyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(GtpDeEncapsulationModulePolicy modulePolicyToDelete) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        modulePolicyToDelete.getPorts().forEach(port -> {
            finalCommandBlocks.add(constructPortCommandBlock(port));
        });
        return finalCommandBlocks;
    }

    /**
     * This method constructs GtpDeEncapsulationModulePolicyRecovery port recovery command block
     *
     * @param port
     * @return GtpDeEncapsulationCommandBlock
     */
    private GtpDeEncapsulationCommandBlock constructPortCommandBlock(Port port) {
        GtpDeEncapsulationCommandBlock gtpDeEncapsulationCommandBlock = new GtpDeEncapsulationCommandBlock();
        gtpDeEncapsulationCommandBlock.setDeviceId(port.getModule().getDevice().getStablenetId().intValue());
        gtpDeEncapsulationCommandBlock.setPortNumber(port.getPortNumber());
        return gtpDeEncapsulationCommandBlock;
    }
}
