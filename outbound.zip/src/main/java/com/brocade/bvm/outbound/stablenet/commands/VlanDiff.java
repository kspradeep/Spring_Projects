package com.brocade.bvm.outbound.stablenet.commands;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by dneelapa on 7/15/2016.
 */
@Getter
@NoArgsConstructor
public class VlanDiff {

    @Setter
    //vlan
    private Map<String, Set<String>> oldVlanMap = new HashMap<>();

    @Setter
    //vlan
    private Map<String, Set<String>> newVlanMap = new HashMap<>();

    @Setter
    // sequence - vlan mapping
    private Map<Integer, Set<String>> deletedVlansMap = new HashMap<>();

    @Setter
    // sequence - vlan mapping
    private Map<Integer, Set<String>> addedVlansMap = new HashMap<>();

    @Setter
    // sequence - vlan mapping
    private Map<Integer, Set<String>> updatedVlansMap = new HashMap<>();

    @Setter
    private List<String> deletedVlans;

    @Setter
    private List<String> addedVlans;

    @Setter
    private List<String> updatedVlans;

}
