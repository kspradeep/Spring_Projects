package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.model.db.Rule;
import com.brocade.bvm.model.db.RuleSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dneelapa on 7/15/2016.
 */

@Getter
@NoArgsConstructor
public class RuleDiff {

    @Setter
    private RuleSet ruleSet;

    @Setter
    private List<Rule> newRules = new ArrayList<>();

    @Setter
    private List<Rule> oldRules = new ArrayList<>();

    @Setter
    private List<Rule> deletedRules = new ArrayList<>();

    @Setter
    private List<Rule> addedRules = new ArrayList<>();

}
