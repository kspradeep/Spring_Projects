package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.EgressPortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.EgressPortHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.model.db.sessiondirector.SdPortVlanMapping;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class AbstractSdPortJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private EgressPortHistoryRepository egressPortHistoryRepository;

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String PORT = "port;";
    protected static final String EXIT = "exit;";
    protected static final String RETURN = "return;";

    protected static final String SET = "set %s;";
    protected static final String CLEAR = "clear %s;";

    protected static final String ADD_PORT = "add port=%s;";

    protected static final String DELETE_PORT = "del port=%s;";

    protected static final String EDIT_PORT = "edit port=%s;";

    protected static final String VLAN = "vlan-id=%s";

    protected static final String LOAD_BALANCE = "load-balance=%s";

    protected static final String IMSI_LIMIT = "imsi-limit=%s";
    protected static final String CLEAR_IMSI_LIMIT = "imsi-limit";

    /**
     * This method builds commands to create Egress Port
     *
     * @param portsToSave
     * @return
     */
    protected String buildCreateCommand(Set<EgressPort> portsToSave) {
        StringBuilder command = new StringBuilder();
        command.append(PORT);
        portsToSave.stream().forEach(portToSave -> {
            command.append(String.format(ADD_PORT, portToSave.getName()));
            command.append(setCommand(portToSave));
            command.append(RETURN);
        });
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method build the commands to update Egress Port
     *
     * @param portsToUpdate
     * @return
     */
    protected String buildUpdateCommand(Set<EgressPort> portsToUpdate) {
        StringBuilder command = new StringBuilder();
        StringBuilder commandVlanToAdd = new StringBuilder("");
        command.append(PORT);
        Map<EgressPort, List<Long>> portVlanIdMapToSet = Maps.newHashMap();
        Map<EgressPort, List<Long>> portVlanIdMapToClear = Maps.newHashMap();
        Map<EgressPort, List> portVlanHistoryMap = Maps.newHashMap();
        portsToUpdate.stream().forEach(portToUpdate -> {
            EgressPort portFromHistory = getPortHistory(portToUpdate.getId(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            if (portFromHistory != null) {
                if (!portToUpdate.isDefault() && portFromHistory.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    commandVlanToAdd.append(String.format(ADD_PORT, portToUpdate.getName()));
                    commandVlanToAdd.append(setCommand(portToUpdate));
                    commandVlanToAdd.append(RETURN);
                } else {
                    command.append(mergePort(portFromHistory, portToUpdate, portVlanIdMapToSet, portVlanIdMapToClear, portVlanHistoryMap));
                }
            } else {
                if (portToUpdate.isDefault()) {
                    EgressPort portHistory = getPortHistoryByRevisionTypes(portToUpdate.getId(), Arrays.asList(HistoryObject.RevisionType.CREATED));
                    if (portHistory != null) {
                        command.append(mergePort(portFromHistory, portToUpdate, portVlanIdMapToSet, portVlanIdMapToClear, portVlanHistoryMap));
                    }
                } else {
                    commandVlanToAdd.append(String.format(ADD_PORT, portToUpdate.getName()));
                    commandVlanToAdd.append(setCommand(portToUpdate));
                    commandVlanToAdd.append(RETURN);
                }
            }
        });

        Map<EgressPort, String> defaultPortVlanIdMapToSet = Maps.newHashMap();
        Map<EgressPort, String> defaultPortVlanIdMapToClear = Maps.newHashMap();
        if (!portVlanIdMapToClear.isEmpty()) {
            portVlanIdMapToClear.forEach((port, longs) -> {
                StringBuilder vlanStringDeleted = new StringBuilder();
                List<Long> vlanIdHisotry = portVlanHistoryMap.get(port);
                longs.forEach(aLong -> {
                    vlanStringDeleted.append(aLong).append(",");
                    if (vlanIdHisotry != null) {
                        vlanIdHisotry.remove(aLong);
                    }
                });
                if (vlanIdHisotry != null) {
                    portVlanHistoryMap.put(port, vlanIdHisotry);
                }
                if (vlanStringDeleted != null && vlanStringDeleted.length() != 0) {
                    if (!port.isDefault()) {
                        command.append(String.format(EDIT_PORT, port.getName()));
                        command.append(String.format(CLEAR, String.format(VLAN, vlanStringDeleted)));
                        command.append(RETURN);
                    } else {
                        defaultPortVlanIdMapToClear.put(port, vlanStringDeleted.toString());
                    }
                }
            });
        }

        if (!portVlanIdMapToSet.isEmpty()) {
            portVlanIdMapToSet.forEach((port, longs) -> {
                StringBuilder vlanStringAdded = new StringBuilder();
                longs.forEach(aLong ->
                        vlanStringAdded.append(aLong).append(",")
                );
                if (vlanStringAdded != null && vlanStringAdded.length() != 0) {
                    if (!port.isDefault()) {
                        List<Long> vlanIdHisotry = portVlanHistoryMap.get(port);
                        if (vlanIdHisotry != null && !vlanIdHisotry.isEmpty()) {
                            commandVlanToAdd.append(String.format(EDIT_PORT, port.getName()));
                        } else {
                            commandVlanToAdd.append(String.format(ADD_PORT, port.getName()));
                            commandVlanToAdd.append(String.format(SET, String.format(LOAD_BALANCE, port.getLoadBalance().getName())));
                            if (port.getImsiLimit() != null) {
                                commandVlanToAdd.append(String.format(SET, String.format(IMSI_LIMIT, port.getImsiLimit())));
                            }
                        }
                        commandVlanToAdd.append(String.format(SET, String.format(VLAN, vlanStringAdded)));
                        commandVlanToAdd.append(RETURN);
                    } else {
                        defaultPortVlanIdMapToSet.put(port, vlanStringAdded.toString());
                    }
                }
            });
        }
        if (!defaultPortVlanIdMapToSet.isEmpty()) {
            defaultPortVlanIdMapToSet.forEach((port, vlanStringAdded) -> {
                if (port.isDefault() && vlanStringAdded != null && vlanStringAdded.length() != 0) {
                    command.append(String.format(EDIT_PORT, port.getName()));
                    command.append(String.format(SET, String.format(VLAN, vlanStringAdded)));
                    command.append(RETURN);
                }
            });
        }
        if (!defaultPortVlanIdMapToClear.isEmpty()) {
            defaultPortVlanIdMapToClear.forEach((port, vlanStringDeleted) -> {
                if (port.isDefault() && vlanStringDeleted != null && vlanStringDeleted.length() != 0) {
                    command.append(String.format(EDIT_PORT, port.getName()));
                    command.append(String.format(CLEAR, String.format(VLAN, vlanStringDeleted)));
                    command.append(RETURN);
                }
            });
        }
        command.append(commandVlanToAdd);
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method builds update command by merging and comparing existingSdPort with updateSdPort
     *
     * @param existingSdPort
     * @param updatedSdPort
     * @return
     */
    private String mergePort(EgressPort existingSdPort, EgressPort updatedSdPort, Map<EgressPort, List<Long>> portVlanIdMapToSet, Map<EgressPort,
            List<Long>> portVlanIdMapToClear, Map<EgressPort, List> portVlanHistoryMap) {
        StringBuilder command = new StringBuilder();

        if (existingSdPort != null && updatedSdPort != null) {
            if (updatedSdPort.getImsiLimit() != null && existingSdPort.getImsiLimit() != null && !updatedSdPort.getImsiLimit().equals(existingSdPort.getImsiLimit())) {
                command.append(String.format(CLEAR, CLEAR_IMSI_LIMIT));
                command.append(String.format(SET, String.format(IMSI_LIMIT, updatedSdPort.getImsiLimit())));
            } else if (updatedSdPort.getImsiLimit() != null && existingSdPort.getImsiLimit() == null) {
                command.append(String.format(SET, String.format(IMSI_LIMIT, updatedSdPort.getImsiLimit())));
            } else if (updatedSdPort.getImsiLimit() == null && existingSdPort.getImsiLimit() != null) {
                command.append(String.format(CLEAR, CLEAR_IMSI_LIMIT));
            }

            if (updatedSdPort.getLoadBalance() != null && existingSdPort.getLoadBalance() != null &&
                    !(updatedSdPort.getLoadBalance().getName()).equals((existingSdPort.getLoadBalance().getName()))) {
                command.append(String.format(CLEAR, String.format(LOAD_BALANCE, existingSdPort.getLoadBalance().getName())));
                command.append(String.format(SET, String.format(LOAD_BALANCE, updatedSdPort.getLoadBalance().getName())));
            }
            if (updatedSdPort.getVlanMappings() != null && !updatedSdPort.getVlanMappings().isEmpty() &&
                    existingSdPort.getVlanMappings() != null && !existingSdPort.getVlanMappings().isEmpty()) {
                List<Long> updatedSdPortVlanIds = updatedSdPort.getVlanMappings().stream().map(SdPortVlanMapping::getVlanId).collect(Collectors.toList());
                List<Long> existingSdPortVlanIds = existingSdPort.getVlanMappings().stream().map(SdPortVlanMapping::getVlanId).collect(Collectors.toList());
                List<Long> vlanIdsAdded = Lists.newArrayList();
                List<Long> vlanIdsDeleded = Lists.newArrayList();
                if (updatedSdPortVlanIds != null && existingSdPortVlanIds != null &&
                        !updatedSdPortVlanIds.isEmpty() && !existingSdPortVlanIds.isEmpty()) {
                    updatedSdPortVlanIds.stream().forEach(vlan -> {
                        if (!existingSdPortVlanIds.contains(vlan)) {
                            vlanIdsAdded.add(vlan);
                        }
                    });
                    existingSdPortVlanIds.stream().forEach(vlan -> {
                        if (!updatedSdPortVlanIds.contains(vlan)) {
                            vlanIdsDeleded.add(vlan);
                        }
                    });
                } else if ((updatedSdPortVlanIds == null || updatedSdPortVlanIds.isEmpty()) && existingSdPortVlanIds != null &&
                        !existingSdPortVlanIds.isEmpty()) {
                    existingSdPortVlanIds.stream().forEach(vlan ->
                            vlanIdsDeleded.add(vlan)
                    );
                } else if ((existingSdPortVlanIds == null || existingSdPortVlanIds.isEmpty()) && updatedSdPortVlanIds != null &&
                        !updatedSdPortVlanIds.isEmpty()) {
                    updatedSdPortVlanIds.stream().forEach(vlan ->
                            vlanIdsAdded.add(vlan)
                    );
                }

                portVlanIdMapToSet.put(updatedSdPort, vlanIdsAdded);
                portVlanIdMapToClear.put(updatedSdPort, vlanIdsDeleded);
                portVlanHistoryMap.put(updatedSdPort, existingSdPortVlanIds);
            }
        }

        StringBuilder finalCommand = new StringBuilder();
        if (command.length() > 0) {
            finalCommand.append(String.format(EDIT_PORT, updatedSdPort.getName()));
            finalCommand.append(command);
            finalCommand.append(RETURN);
        }
        return finalCommand.toString();
    }

    /**
     * This method build the commands to delete Egress Port
     *
     * @param portsToDelete
     * @return
     */
    protected String buildDeleteCommand(Set<EgressPort> portsToDelete) {
        StringBuilder command = new StringBuilder();
        command.append(PORT);
        portsToDelete.stream().forEach(portToDelete -> {
            if (!portToDelete.isDefault()) {
                command.append(String.format(DELETE_PORT, portToDelete.getName()));
            }
        });
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method build the set commands for Egress Port
     *
     * @param portToUpdate
     * @return
     */
    protected String setCommand(EgressPort portToUpdate) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(SET, String.format(LOAD_BALANCE, portToUpdate.getLoadBalance().getName())));
        if (portToUpdate.getImsiLimit() != null) {
            command.append(String.format(SET, String.format(IMSI_LIMIT, portToUpdate.getImsiLimit())));
        }
        if (portToUpdate.getVlanMappings() != null && !portToUpdate.getVlanMappings().isEmpty()) {
            StringBuilder vlanString = new StringBuilder();
            portToUpdate.getVlanMappings().stream().forEach(vlan -> {
                vlanString.append(vlan.getVlanId()).append(",");
            });
            command.append(String.format(SET, String.format(VLAN, vlanString)));
        }
        return command.toString();
    }

    /**
     * This method build the clear commands for Egress Port
     *
     * @param portToUpdate
     * @return
     */
    protected String clearCommand(EgressPort portToUpdate) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(SET, String.format(LOAD_BALANCE, EgressPort.LoadBalanceAlgorithms.HASH.getName())));
        if (portToUpdate.getImsiLimit() != null) {
            command.append(String.format(CLEAR, CLEAR_IMSI_LIMIT));
        }
        if (portToUpdate.getVlanMappings() != null && !portToUpdate.getVlanMappings().isEmpty()) {
            StringBuilder vlanString = new StringBuilder();
            portToUpdate.getVlanMappings().stream().forEach(vlan -> {
                vlanString.append(vlan.getVlanId()).append(",");
            });
            command.append(String.format(CLEAR, String.format(VLAN, vlanString)));
        }
        return command.toString();
    }

    /**
     * This method fetches the ACTIVE Egress Port from history
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistory(Long portId, List<WorkflowParticipant.WorkflowStatus> workflowStatuses) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndWorkflowStatus(portId, workflowStatuses);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }

    /**
     * This method fetches the ACTIVE Egress Port from history using revision type
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistoryByRevisionTypes(Long portId, List<HistoryObject.RevisionType> revisionTypes) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndRevisionTypes(portId, revisionTypes);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }
}
