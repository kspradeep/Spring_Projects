/*-
 * UNPUBLISHED SOURCE CODE
 *
 * Copyright � 2013, Brocade Communications Systems, Incorporated.
 * ALL RIGHTS RESERVED.
 *
 * BROCADE HIGHLY CONFIDENTIAL TRADE SECRET INFORMATION
 *
 * Access or possession of this material grants you no right or license,
 * express, implied, statutory or otherwise, under any Brocade patent,
 * copyright, trade secret right or other intellectual property right.
 * Any such license must be contained in a written license agreement
 * signed by an authorized officer of Brocade.  Additionally, access or
 * possession of this material is limited to Brocade employees with a
 * need to know or named employees of Brocade vendors authorized by
 * Brocade in writing to access this material.
 *
 * Restricted Rights: Use, duplication, or disclosure by the U.S.
 * Government is subject to restrictions of FAR 52.227-19 and its
 * successors, or (c)(1)(ii) of the Rights in Technical Data and
 * Computer Software clause at DFAR 252.227-7013 and its successors.
 *
 * Brocade Communications Systems, Inc.,
 * 110 Holger Way, San Jose, CA 95134
 */
package com.brocade.bvm.outbound.firmware.job.util;

import org.springframework.beans.factory.annotation.Value;

/**
 * @author Ila Palanisamy
 * @version 1.0
 */
public class CliConstants {

    public static final int DEFAULT_BUFFER_SIZE = 8192;

    @Value("${default.firmware.login.timeout.milliseconds:60000}")
    public static Integer DEFAULT_LOGIN_TIMEOUT = 60000; //in milliseconds

    @Value("${default.firmware.idle.timeout.milliseconds:300000}")
    public static Integer DEFAULT_IDLE_TIMEOUT = 300000; //in milliseconds

    @Value("${default.firmware.response.timeout.milliseconds:120000}")
    public static Integer DEFAULT_CMD_RESPONSE_TIMEOUT = 120000; //in milliseconds

    public enum DeviceType {
        IOS, NOS
    }

    public enum Protocol {
        TELNET, SSH
    }

    public enum AccessMode {
        USER_MODE, PRIVILEGE_MODE, CONFIG_MODE
    }
}
