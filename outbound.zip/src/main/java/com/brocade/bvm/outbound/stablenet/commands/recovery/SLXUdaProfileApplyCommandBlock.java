package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SLXUdaProfileApplyCommandBlock implements CommandBlock {

    private final static String ETHERNET = "Ethernet";

    private final static String PORT_CHANNEL = "Port-channel";
    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";
    /**
     * <pre>
     * argument #1 is interface name
     * eg: do show running-config interface Ethernet 0/1
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config interface %s %s";
    /**
     * <pre>
     * argument #1 is interface name
     * interface Ethernet 0/1
     * </pre>
     */
    private static final String MATCH_CMD = "interface %s %s";
    /**
     * <pre>
     * argument #1 is uda-key profile name
     * no uda-profile-apply
     * </pre>
     */
    private static final String ACTION_CMD = "no uda-profile-apply\n";

    private static final String EXIT = "exit\n";

    private static final String INTERFACE = "interface %s %s\n";

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String profileName;

    @Getter
    @Setter
    private boolean portGroup;

    @Getter
    @Setter
    private Set<String> interfaces;

    @Getter
    @Setter
    private String writeMem = "false";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        String firstInterface = interfaces.stream().findFirst().get();
        String interfaceType = isPortGroup() ? PORT_CHANNEL : ETHERNET;
        args.add(String.format(SHOW_CMD, interfaceType, firstInterface != null ? firstInterface.trim() : firstInterface));
        args.add(String.format(MATCH_CMD, interfaceType, firstInterface != null ? firstInterface.trim() : firstInterface));
        StringBuilder stringBuilder = new StringBuilder();
        interfaces.stream().forEach(port -> {
            if (port != null) {
                stringBuilder.append(String.format(INTERFACE, interfaceType, port.trim()));
                stringBuilder.append(ACTION_CMD);
                stringBuilder.append(EXIT);
            }
        });
        args.add(stringBuilder.toString());
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXUdaProfileApplyCommandBlock [deviceId=" + deviceId + ", profileName=" + profileName + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
