package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dneelapa on 6/28/2016.
 */
public class PacketSlicingCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private int noOfBytes;

    @Getter
    @Setter
    private int moduleNumber;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "conf t;";
    private static final String SHOW_CMD = "sh run | inc ^egress-truncate-size %s slot %s$";
    private static final String MATCH_CMD = "egress-truncate-size %s slot %s";
    private static final String ACTION_CMD = "no egress-truncate-size %s slot %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, noOfBytes, moduleNumber));
        args.add(MATCH_CMD);
        args.add(String.format(ACTION_CMD, noOfBytes, moduleNumber));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "PacketSlicingCommandBlock [deviceId=" + deviceId + ", noOfBytes=" + noOfBytes + ", moduleNumber=" + moduleNumber + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
