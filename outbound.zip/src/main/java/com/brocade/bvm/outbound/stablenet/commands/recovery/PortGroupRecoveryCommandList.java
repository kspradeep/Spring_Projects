package com.brocade.bvm.outbound.stablenet.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;

/**
 * Class constructs the command list for recovering the SD port group
 *
 */
public class PortGroupRecoveryCommandList {
    private List<CommandBlock> commandBlocks = new ArrayList<>();
    
    public List<CommandBlock> constructCommandBlockList(PortGroup portGroup) {
        for (Port port : portGroup.getPorts()) {
            PortGroupDisablePortCommandBlock pgdpCommandBlock = new PortGroupDisablePortCommandBlock();
            pgdpCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
            pgdpCommandBlock.setName("\"" + portGroup.getName() + "\"");
            pgdpCommandBlock.setPort(port.getPortNumber());
            commandBlocks.add(pgdpCommandBlock);
        }

        PortGroupNoDeployCommandBlock pgNoDeployCommandBlock = new PortGroupNoDeployCommandBlock();
        pgNoDeployCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
        pgNoDeployCommandBlock.setName("\"" + portGroup.getName() + "\"");
        commandBlocks.add(pgNoDeployCommandBlock);
        PortGroupRemoveCommandBlock pgRemoveCommandBlock = new PortGroupRemoveCommandBlock();
        pgRemoveCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
        pgRemoveCommandBlock.setName("\"" + portGroup.getName() + "\"");
        commandBlocks.add(pgRemoveCommandBlock);

        if (portGroup.getGtpProfile() != null) {
            UnMapPortFromGTPProfileCommandBlock unMapPortFromGTPProfileCommandBlock = new UnMapPortFromGTPProfileCommandBlock();
            unMapPortFromGTPProfileCommandBlock.setDeviceId(portGroup.getDevice().getStablenetId().intValue());
            unMapPortFromGTPProfileCommandBlock.setPort(portGroup.getPrimaryPort().getPortNumber());
            unMapPortFromGTPProfileCommandBlock.setProfileName(portGroup.getGtpProfile().getName());
            unMapPortFromGTPProfileCommandBlock.setProfileId(portGroup.getGtpProfile().getProfileId());
            commandBlocks.add(unMapPortFromGTPProfileCommandBlock);
        }
        if (!commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("true");
        }
        return commandBlocks;
    }

}
