package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.DeDupePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class CommitDedupePolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_DEDUPE_POLICY_CREATE,Job.Type.SD_DEDUPE_POLICY_UPDATE);
    }

    protected static final String DEDUPE = "dedupe;";
    protected static final String DEDUPE_OPTIONS = "dedupe-options ";
    protected static final String TIMEOUT = "timeout=%d;";

    @Override
    public String getCommands(Job job) {
        DeDupePolicy deDupePolicy = (DeDupePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(DEDUPE);
        command.append(SET).append(DEDUPE_OPTIONS).append(String.format(TIMEOUT, deDupePolicy.getTimeout()));
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
