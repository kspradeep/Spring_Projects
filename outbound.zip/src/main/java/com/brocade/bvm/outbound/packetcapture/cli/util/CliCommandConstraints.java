package com.brocade.bvm.outbound.packetcapture.cli.util;

import com.brocade.bvm.outbound.firmware.job.util.CliConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CliCommandConstraints {

    private CliConstants.AccessMode mode = CliConstants.AccessMode.PRIVILEGE_MODE;
    /**
     * Don't stop on error is the default.
     */
    private boolean stopOnError = false;

    private int timeout = 0;
}
