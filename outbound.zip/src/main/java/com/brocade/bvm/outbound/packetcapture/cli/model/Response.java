package com.brocade.bvm.outbound.packetcapture.cli.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Response {

    private String cmd;

    private boolean errorOccurred = false;

    private String errorMessage;

    private String value;
}