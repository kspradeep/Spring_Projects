package com.brocade.bvm.outbound.grid.model;

import com.brocade.bvm.model.db.ManagedObject;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class ToolAddressInterface {
    private Integer toolAddress;

    private Set<ManagedObject> managedObjects;

    private String type;

    private Integer precedence = 1;

    private boolean countEnabled;
}
