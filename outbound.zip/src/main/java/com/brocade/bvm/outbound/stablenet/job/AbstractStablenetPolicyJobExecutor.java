package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Query;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The AbstractStablenetPolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE policy on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public abstract class AbstractStablenetPolicyJobExecutor extends AbstractStablenetJobExecutor {

    /*** Expect #1 ingress port #2 ip string **/
    protected static final String POLICYSET_INGRESS_RECORD_FORMAT = "interface ethernet %s;" + "%s" + "allow-all-vlan pbr;exit;";

    /*** Expect #1 ingress port #2 ip string **/
    protected static final String POLICYSET_INGRESS_ADD_FORMAT = "interface ethernet %s;%s%sallow-all-vlan pbr;exit;";

    /*** Expect #1 ingress port #2 ip string **/
    protected static final String POLICYSET_INGRESS_UPDATE_FORMAT = "interface ethernet %s;%sexit;";

    protected static final String POLICYSET_INGRESS_GTP_MAP_FORMAT = "loopback system;";

    protected static final String POLICYSET_INGRESS_GTP_UNMAP_FORMAT = "no loopback system;";

    protected static final String POLICYSET_GTP_ENTER_FORMAT = "gtp \"%s\" %s;";

    protected static final String POLICYSET_GTP_INGRESS_MAP_FORMAT = "ports ethernet %s;";

    protected static final String POLICYSET_GTP_INGRESS_UNMAP_FORMAT = "no ports ethernet %s;";

    /*** Expect #1 ingress port #2 ip string **/
    protected static final String POLICYSET_INGRESS_UNMAP_FORMAT = "interface ethernet %s;%sno allow-all-vlan pbr;exit;";

    /*** Expect #1 ingress port #2 ip string **/
    protected static final String POLICYSET_INGRESS_MAP_FORMAT = "interface ethernet %s;%sallow-all-vlan pbr;exit;";

    private static final String POLICYSET_ACL_TYPE_L2_INGRESS_RECORD_FORMAT = "l2 policy route-map %s;";

    private static final String POLICYSET_ACL_TYPE_V4_INGRESS_RECORD_FORMAT = "ip policy route-map %s;";

    private static final String POLICYSET_ACL_TYPE_V6_INGRESS_RECORD_FORMAT = "ipv6 policy route-map %s;";

    protected static final String POLICYSET_ACL_TYPE_UDA_INGRESS_RECORD_FORMAT = "uda policy route-map %s;";

    protected static final String POLICYSET_ACL_TYPE_UDA_OFFSET_RECORD_FORMAT = "uda-offsets %s %s %s %s;";

    private static final String POLICYSET_REVERT_ACL_L2_INGRESS_IP_TYPE_RECORD = "no l2 policy route-map %s;";

    private static final String POLICYSET_REVERT_ACL_V4_INGRESS_IP_TYPE_RECORD = "no ip policy route-map %s;";

    private static final String POLICYSET_REVERT_ACL_V6_INGRESS_IP_TYPE_RECORD = "no ipv6 policy route-map %s;";

    protected static final String POLICYSET_REVERT_ACL_UDA_OFFSET_TYPE_RECORD = "no uda-offsets %s %s %s %s;";

    protected static final String POLICYSET_REVERT_ACL_UDA_INGRESS_IP_TYPE_RECORD = "no uda policy route-map %s;";

    /***
     * Expect #1 as policy name #2 is permit and #3 as sequence
     **/
    protected static final String POLICY_REVERT_HEADER_FORMAT = "no route-map %s %s %s;";

    /***
     * Expect #1 as policy name #2 is permit
     **/
    protected static final String POLICY_REVERT_TAIL_FORMAT = "no route-map %s %s 999999999;";

    protected static final String POLICYSET_EGRESS_RECORD_HEADER_FORMAT = "vlan %s name EgressVLAN;";

    protected static final String POLICYSET_EGRESS_EDIT_RECORD_HEADER_FORMAT = "vlan %s;";

    protected static final String POLICYSET_REPLACE_VLAN_HEADER_FORMAT = "vlan %s name ReplaceVLAN;";

    protected static final String TVF_DOMAIN_HEADER_FORMAT = "tvf-domain %s;";

    /***
     * Expect #1 as vlan id
     **/
    protected static final String POLICYSET_REVERT_EGRESS_RECORD_TAG_FORMAT = "no tagged ethe %s;";

    /***
     * Expect #1 as vlan id
     **/
    protected static final String POLICYSET_REVERT_EGRESS_RECORD_UNTAG_FORMAT = "no untagged ethe %s;";

    protected static final String UNTAG_PORT = "untagged ethe %s;";

    protected static final String REVERT_UNTAG_PORT = "no untagged ethe %s;";

    protected static final String BIND_PORT = "ports ethe %s;";

    /***
     * Command to delete Vlan
     ***/
    protected static final String DELETE_VLAN_FORMAT = "no vlan %s;";

    protected static final String DELETE_TVF_FORMAT = "no tvf-domain %s;";

    /**
     * Required to start telnet session with device
     **/
    protected static final String START_CONFIG_TERMINAL = "configure terminal;";

    /***
     * #1 is policy name
     */
    protected static final String END_ROUTE_MAP = "route-map %s permit 999999999;match uda Catch_all_uda;match ip address Catch_all;match ipv6 address Catch_all_ipv6;match l2acl Catch_all_l2;set interface null0;exit;";

    /***
     * Expect #1 ingress port #2 Ingress IP type record
     **/
    protected static final String POLICYSET_REVERT_INGRESS_RECORD_FORMAT = "interface ethernet %s;%sno allow-all-vlan pbr;exit;";

    protected static final String POLICYSET_REVERT_PBR_FORMAT = "no allow-all-vlan pbr;";

    protected static final String POLICYSET_REVERT_INTERMEDIATE_PORT_RECORD_FORMAT = "interface ethernet %s;%s%sexit;";

    /***
     * Expect #1 ingress port #2 Ingress IP type record
     **/
    protected static final String POLICYSET_REVERT_INGRESS_UPDATE_FORMAT = "interface ethernet %s;%s%sno allow-all-vlan pbr;exit;";

    /*** Expect #1 as name for rule set */
    protected static final String RULE_SET_IP_REVERT_HEADER_FORMAT = "no ip access-list extended %s;";

    /*** Expect #1 as name for rule set */
    protected static final String RULE_SET_IPV6_REVERT_HEADER_FORMAT = "no ipv6 access-list %s;";

    /*** Expect #1 as name for rule set */
    protected static final String RULE_SET_MAC_REVERT_HEADER_FORMAT = "no mac access-list %s;";

    /*** Expect #1 as name for rule set */
    protected static final String RULE_SET_UDA_REVERT_HEADER_FORMAT = "no uda access-list %s;";

    protected static final String EXIT = "exit;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String CMD_PERMIT = "permit";

    protected static final String END = "end;";

    protected static final String MATCH_PAYLOAD_LENGTH = " match-payload-len";

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected PolicyHistoryRepository policyHistoryRepository;

    @Inject
    protected ReservedVlanDevicePolicyRepository reservedVlanRepository;

    @Inject
    protected HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    protected FlowRepository flowRepository;

    protected Policy getPolicyNameFromHistory(Policy policy) {
        return getPolicyNameFromHistoryByTypes(policy.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING));
    }

    protected Policy getPolicyHistoryForDiff(Policy policy) {
        Policy policyFromHistory = null;
        // get the previous policy name from the history.
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING));
        if ((policyHistoryList == null || policyHistoryList.isEmpty()) && policy.isLegacy()) {
            policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                    Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING, WorkflowParticipant.WorkflowStatus.ERROR));
        }
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }



    protected List<String> getVlansToDelete(Policy policy) {
        Set<String> currentVlan = new HashSet<>();
        Set<Flow> flows = policy.getFlows();
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                if (!flow.getTvfDomain()) {
                    currentVlan.addAll(getVlanOrTvfDomainList(policy, flow));
                }
            });
        }
        return new ArrayList<>(currentVlan);
    }

    protected List<String> getTvfDomainIdsToDelete(Policy policy) {
        Set<String> currentTvfDomainIds = new HashSet<>();
        Set<Flow> flows = policy.getFlows();
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                if (flow.getTvfDomain()) {
                    currentTvfDomainIds.addAll(getVlanOrTvfDomainList(policy, flow));
                }
            });
        }
        return new ArrayList<>(currentTvfDomainIds);
    }

    private Set<String> getVlanOrTvfDomainList(Policy policy, Flow flow) {
        Set<String> currentVlanOrTvfDomain = Sets.newHashSet();
        // querying db to get all policy by deviceid
        List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(policy.getDevice().getId(),
                Arrays.asList(WorkflowParticipant.WorkflowStatus.DRAFT, WorkflowParticipant.WorkflowStatus.ACTIVE), flow);
        currentVlanOrTvfDomain.addAll(policy.getFlows().stream().filter(flow1 -> flow1.getTvfDomain() == flow.getTvfDomain()).flatMap(f -> f.getVlans().stream()).collect(Collectors.toSet()));
        // Iterating on policy to find vlan id
        // Populating all distinct egress
        if (policies != null && !policies.isEmpty()) {
            for (Policy eachPolicy : policies) {
                //get the policy from history if the policy is in DRAFT state to get the actual parameters set on device (SAVED_OVER_COMMITTED)
                if (WorkflowParticipant.WorkflowStatus.DRAFT == eachPolicy.getWorkflowStatus()) {
                    //SAVE_OVER_COMMITED
                    Policy policyFromHistory = getPolicyNameFromHistory(eachPolicy);
                    if (policyFromHistory != null) {
                        eachPolicy = policyFromHistory;
                    }
                }
                //List<String> tmpVlan = eachPolicy.getFlows().stream().flatMap(f -> f.getVlans().stream()).collect(Collectors.toList());
                List<String> tmpVlan = eachPolicy.getFlows().stream().filter(flow1 -> flow1.getTvfDomain() == flow.getTvfDomain()).flatMap(flow1 -> flow1.getVlans().stream()).collect(Collectors.toList());
                for (String eachVlan : tmpVlan) {
                    if (currentVlanOrTvfDomain.contains(eachVlan)) {
                        currentVlanOrTvfDomain.remove(eachVlan);
                    }
                }
            }
        }
        return currentVlanOrTvfDomain;
    }

    protected Map<String, Set<Port>> getPortsUnbindedFromVlan(Policy policy) {
        Map<String, Set<Port>> currVlanEgressInUse = new HashMap<>();
        Device device = policy.getDevice();
        for (Flow flow : policy.getFlows()) {
            if (!flow.getTvfDomain()) {
                getPortsToUnbind(device, currVlanEgressInUse, flow);
            }
        }
        return currVlanEgressInUse;
    }

    protected Map<String, Set<Port>> getPortsUnbindedFromTvfDomain(Policy policy) {
        Map<String, Set<Port>> currTvfDomainEgressInUse = new HashMap<>();
        Device device = policy.getDevice();
        for (Flow flow : policy.getFlows()) {
            if (flow.getTvfDomain()) {
                getPortsToUnbindTvfDomain(device, currTvfDomainEgressInUse, flow);
            }
        }
        return currTvfDomainEgressInUse;
    }

    private void getPortsToUnbindTvfDomain(Device device, Map<String, Set<Port>> currVlanEgressInUse, Flow flow) {
        Set<Port> currEgressInUse = new HashSet<>();
        Set<String> currentTvfDomainIds = flow.getVlans();
        currentTvfDomainIds.forEach(tvfDomainId -> {
            currEgressInUse.addAll(flow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equalsIgnoreCase(tvfDomainId))
                    .map(flowEgressManagedObject -> (Port) flowEgressManagedObject.getManagedObject()).filter(po -> (po.getType() == Port.Type.EGRESS) || (po.getType() == Port.Type.SERVICE_PORT)).collect(Collectors.toSet()));
            currEgressInUse.addAll(flow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equalsIgnoreCase(tvfDomainId))
                    .map(flowEgressManagedObject -> ((PortGroup) flowEgressManagedObject.getManagedObject()).getPrimaryPort()).collect(Collectors.toSet()));
            Set<Port> egressPorts = currVlanEgressInUse.get(tvfDomainId);
            if (egressPorts != null) {
                currEgressInUse.addAll(egressPorts);
            }
            currVlanEgressInUse.put(tvfDomainId, currEgressInUse);
        });
        // querying db to get all policy by deviceid
        List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(device.getId(),
                Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.DRAFT), flow);

        // Iterating on policy to find vlan id
        if (policies != null && !policies.isEmpty()) {
            Map<String, Set<Port>> vlanEgressInUse = new HashMap<>();
            // Populating all distinct egress
            for (Policy pw : policies) {
                if (WorkflowParticipant.WorkflowStatus.DRAFT == pw.getWorkflowStatus()) {
                    //SAVE_OVER_COMMITED
                    Policy policyFromHistory = getPolicyNameFromHistory(pw);
                    if (policyFromHistory != null) {
                        pw = policyFromHistory;
                    }
                }
                for (Flow eachFlow : pw.getFlows()) {
                    if (flow.getTvfDomain() == eachFlow.getTvfDomain()) {
                        Set<String> tmpVlan = eachFlow.getVlans();
                        Set<Port> egressInUse = new HashSet<>();
                        tmpVlan.stream().filter(vlan -> currentTvfDomainIds.contains(vlan)).forEach(tvfDomainId -> {
                            egressInUse.addAll(eachFlow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equalsIgnoreCase(tvfDomainId))
                                    .map(flowEgressManagedObject -> (Port) flowEgressManagedObject.getManagedObject()).collect(Collectors.toSet()));
                            egressInUse.addAll(eachFlow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equalsIgnoreCase(tvfDomainId))
                                    .map(flowEgressManagedObject -> ((PortGroup) flowEgressManagedObject.getManagedObject()).getPrimaryPort()).collect(Collectors.toSet()));
                            Set<Port> egressPorts = vlanEgressInUse.get(tvfDomainId);
                            if (egressPorts != null) {
                                egressInUse.addAll(egressPorts);
                            }
                            // Creating a map of VLAN to EGRESS port(s)
                            vlanEgressInUse.put(tvfDomainId, egressInUse);
                        });
                    }
                }
                // removing egress to be deleted
                vlanEgressInUse.keySet().stream().forEach(eachVlan -> {
                    Set<Port> egressInUse = vlanEgressInUse.get(eachVlan);
                    for (Port egress : egressInUse) {
                        if (currVlanEgressInUse.get(eachVlan) != null) {
                            Set<Port> currentEgressToRemove = currVlanEgressInUse.get(eachVlan).stream().filter(port -> port.getId() == egress.getId()).collect(Collectors.toSet());
                            currVlanEgressInUse.get(eachVlan).removeAll(currentEgressToRemove);
                            if (currVlanEgressInUse.get(eachVlan) != null && currVlanEgressInUse.get(eachVlan).isEmpty()) {
                                currVlanEgressInUse.remove(eachVlan);
                            }
                        }
                    }
                });
            }
        }
    }

    private void getPortsToUnbind(Device device, Map<String, Set<Port>> currVlanEgressInUse, Flow flow) {
        Set<Port> currEgressInUse = new HashSet<>();
        Set<String> currentVlan = flow.getVlans();
        currentVlan.forEach(eachVlan -> {
            currEgressInUse.addAll(flow.getEgressPorts().stream().filter(po -> (po.getType() == Port.Type.EGRESS) || (po.getType() == Port.Type.SERVICE_PORT)).collect(Collectors.toSet()));
            // Get all the primary port from the port groups
            currEgressInUse.addAll(flow.getEgressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
            Set<Port> egressPorts = currVlanEgressInUse.get(eachVlan);
            if (egressPorts != null) {
                currEgressInUse.addAll(egressPorts);
            }
            currVlanEgressInUse.put(eachVlan, currEgressInUse);
        });
        // querying db to get all policy by deviceid
        List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(device.getId(),
                Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.DRAFT), flow);

        // Iterating on policy to find vlan id
        if (policies != null && !policies.isEmpty()) {
            Map<String, Set<Port>> vlanEgressInUse = new HashMap<>();
            // Populating all distinct egress
            for (Policy pw : policies) {
                if (WorkflowParticipant.WorkflowStatus.DRAFT == pw.getWorkflowStatus()) {
                    //SAVE_OVER_COMMITED
                    Policy policyFromHistory = getPolicyNameFromHistory(pw);
                    if (policyFromHistory != null) {
                        pw = policyFromHistory;
                    }
                }
                for (Flow eachFlow : pw.getFlows()) {
                    if (flow.getTvfDomain() == eachFlow.getTvfDomain()) {
                        Set<String> tmpVlan = eachFlow.getVlans();
                        Set<Port> egressInUse = new HashSet<>();
                        tmpVlan.stream().filter(vlan -> currentVlan.contains(vlan)).forEach(vlan -> {
                            egressInUse.addAll(eachFlow.getEgressPorts());
                            egressInUse.addAll(eachFlow.getEgressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
                            Set<Port> egressPorts = vlanEgressInUse.get(vlan);
                            if (egressPorts != null) {
                                egressInUse.addAll(egressPorts);
                            }
                            // Creating a map of VLAN to EGRESS port(s)
                            vlanEgressInUse.put(vlan, egressInUse);
                        });
                    }
                }
                // removing egress to be deleted
                vlanEgressInUse.keySet().stream().forEach(eachVlan -> {
                    Set<Port> egressInUse = vlanEgressInUse.get(eachVlan);
                    for (Port egress : egressInUse) {
                        if (currVlanEgressInUse.get(eachVlan) != null) {
                            Set<Port> currentEgressToRemove = currVlanEgressInUse.get(eachVlan).stream().filter(port -> port.getId() == egress.getId()).collect(Collectors.toSet());
                            currVlanEgressInUse.get(eachVlan).removeAll(currentEgressToRemove);
                            if (currVlanEgressInUse.get(eachVlan) != null && currVlanEgressInUse.get(eachVlan).isEmpty()) {
                                currVlanEgressInUse.remove(eachVlan);
                            }
                        }
                    }
                });
            }
        }
    }

    /**
     * This method builds the commands to be issued in interface to map policy to interface along with loopback
     *
     * @param policyName
     * @param ruleSetTypeList
     * @param ruleSetIpList
     * @param policy
     * @return String returns commands
     */
    protected static String getACLFormatForPolicy(String policyName, Set<RuleSet.Type> ruleSetTypeList, Set<RuleSet.IpVersion> ruleSetIpList, Policy policy, boolean loopback) {
        StringBuilder command = new StringBuilder();
        command.append(getACLFormat(policyName, ruleSetTypeList, ruleSetIpList, policy));
        if (loopback) {
            command.append(POLICYSET_INGRESS_GTP_MAP_FORMAT);
        }
        return command.toString();
    }

    /**
     * This method builds the commands to be issued in interface to map policy to interface
     *
     * @param policyName
     * @param ruleSetTypeList
     * @param ruleSetIpList
     * @param policy
     * @return String returns commands
     */
    protected static String getACLFormat(String policyName, Set<RuleSet.Type> ruleSetTypeList, Set<RuleSet.IpVersion> ruleSetIpList, Policy policy) {
        StringBuilder command = new StringBuilder();
        if (ruleSetTypeList.contains(RuleSet.Type.UDA)) {
            String fieldOffset1 = String.valueOf(policy.getFieldOffset1());
            String fieldOffset2 = String.valueOf(policy.getFieldOffset2());
            String fieldOffset3 = String.valueOf(policy.getFieldOffset3());
            String fieldOffset4 = String.valueOf(policy.getFieldOffset4());
            if ("-1".equals(fieldOffset1)) {
                fieldOffset1 = "ignore";
            }
            if ("-1".equals(fieldOffset2)) {
                fieldOffset2 = "ignore";
            }
            if ("-1".equals(fieldOffset3)) {
                fieldOffset3 = "ignore";
            }
            if ("-1".equals(fieldOffset4)) {
                fieldOffset4 = "ignore";
            }
            command.append(String.format(POLICYSET_ACL_TYPE_UDA_OFFSET_RECORD_FORMAT, fieldOffset1, fieldOffset2, fieldOffset3, fieldOffset4));
        }
        ruleSetTypeList.forEach(type -> {
            if (RuleSet.Type.UDA == type) {
                command.append(String.format(POLICYSET_ACL_TYPE_UDA_INGRESS_RECORD_FORMAT, policyName));
            } else if (RuleSet.Type.L2 == type) {
                command.append(String.format(POLICYSET_ACL_TYPE_L2_INGRESS_RECORD_FORMAT, policyName));
            }
        });

        ruleSetIpList.forEach(ipVersion -> {
            if (RuleSet.IpVersion.V4 == ipVersion) {
                command.append(String.format(POLICYSET_ACL_TYPE_V4_INGRESS_RECORD_FORMAT, policyName));
            }
            if (RuleSet.IpVersion.V6 == ipVersion) {
                command.append(String.format(POLICYSET_ACL_TYPE_V6_INGRESS_RECORD_FORMAT, policyName));
            }
        });
        return command.toString();
    }

    /**
     * This method builds the commands to be issued in interface to unmap policy to interface along with loopback
     *
     * @param policyName
     * @param ruleSetTypeList
     * @param ruleSetIpList
     * @param policy
     * @return String returns commands
     */
    protected static String getReverseACLFormatForPolicy(String policyName, Set<RuleSet.Type> ruleSetTypeList, Set<RuleSet.IpVersion> ruleSetIpList, Policy policy, boolean loopback) {
        StringBuilder command = new StringBuilder();
        command.append(getReverseACLFormat(policyName, ruleSetTypeList, ruleSetIpList, policy));
        if (loopback) {
            command.append(POLICYSET_INGRESS_GTP_UNMAP_FORMAT);
        }
        return command.toString();
    }

    /**
     * This method builds the commands to be issued in interface to unmap policy to interface
     *
     * @param policyName
     * @param ruleSetTypeList
     * @param ruleSetIpList
     * @param policy
     * @return String returns commands
     */
    protected static String getReverseACLFormat(String policyName, Set<RuleSet.Type> ruleSetTypeList, Set<RuleSet.IpVersion> ruleSetIpList, Policy policy) {
        StringBuilder command = new StringBuilder();
        ruleSetTypeList.forEach(type -> {
            if (RuleSet.Type.UDA == type) {
                command.append(String.format(POLICYSET_REVERT_ACL_UDA_INGRESS_IP_TYPE_RECORD, policyName));
            } else if (RuleSet.Type.L2 == type) {
                command.append(String.format(POLICYSET_REVERT_ACL_L2_INGRESS_IP_TYPE_RECORD, policyName));
            }
        });

        ruleSetIpList.forEach(ipVersion -> {
            if (RuleSet.IpVersion.V4 == ipVersion) {
                command.append(String.format(POLICYSET_REVERT_ACL_V4_INGRESS_IP_TYPE_RECORD, policyName));
            }
            if (RuleSet.IpVersion.V6 == ipVersion) {
                command.append(String.format(POLICYSET_REVERT_ACL_V6_INGRESS_IP_TYPE_RECORD, policyName));
            }
        });

        if (ruleSetTypeList.contains(RuleSet.Type.UDA)) {
            String fieldOffset1 = String.valueOf(policy.getFieldOffset1());
            String fieldOffset2 = String.valueOf(policy.getFieldOffset2());
            String fieldOffset3 = String.valueOf(policy.getFieldOffset3());
            String fieldOffset4 = String.valueOf(policy.getFieldOffset4());
            if ("-1".equals(fieldOffset1)) {
                fieldOffset1 = "ignore";
            }
            if ("-1".equals(fieldOffset2)) {
                fieldOffset2 = "ignore";
            }
            if ("-1".equals(fieldOffset3)) {
                fieldOffset3 = "ignore";
            }
            if ("-1".equals(fieldOffset4)) {
                fieldOffset4 = "ignore";
            }
            command.append(String.format(POLICYSET_REVERT_ACL_UDA_OFFSET_TYPE_RECORD, fieldOffset1, fieldOffset2, fieldOffset3, fieldOffset4));
        }
        return command.toString();
    }

    /***
     * provide way to build policy command
     *
     * @param policy
     * @param name
     * @return
     */
    protected String buildRevertFlowCommand(Policy policy, String name, Long deviceId, Job.Type jobType) {
        StringBuilder command = new StringBuilder();
        Set<Flow> flows = policy.getFlows();
        List<String> uniqueListOfRulesetNameTobeDeleted = new ArrayList<>();
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                // #2 reverting policy set
                command.append(String.format(POLICY_REVERT_HEADER_FORMAT, name, CMD_PERMIT, flow.getSequence()));
                // #3 Reverting ruleSet
                flow.getRuleSets().forEach(ruleSet -> command.append(buildRevertRuleSetCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameTobeDeleted, jobType)));
            });
        }
        return command.toString();
    }


    /**
     * Provide way to build rule set
     *
     * @param ruleSet
     * @return
     */
    protected String buildRevertRuleSetCommand(RuleSet ruleSet, Long deviceId, Long policyId, List<String> uniqueListOfRulesetNameTobeDeleted, Job.Type jobType) {
        StringBuilder command = new StringBuilder();
        boolean isRulesetFoundInOtherPolicy = !isRuleSetChangesRequired(ruleSet, deviceId, policyId);
        boolean isRulesetFoundInCurrentPolicy = isSameRulesetNameFoundInCurrentPolicy(ruleSet.getName(), policyId, ruleSet.getId());
        boolean isRulesetAlreadyAdded = uniqueListOfRulesetNameTobeDeleted.contains(ruleSet.getName());
        boolean isRulesetCommandRequired = (jobType == Job.Type.POLICY_DELETE ? (!isRulesetFoundInOtherPolicy && !isRulesetAlreadyAdded) : (!isRulesetFoundInOtherPolicy && !isRulesetFoundInCurrentPolicy && !isRulesetAlreadyAdded));
        if (isRulesetCommandRequired) {
            // #3 reverting rule set
            if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                command.append(String.format(RULE_SET_IP_REVERT_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                command.append(String.format(RULE_SET_IPV6_REVERT_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.L2) {
                command.append(String.format(RULE_SET_MAC_REVERT_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                command.append(String.format(RULE_SET_UDA_REVERT_HEADER_FORMAT, ruleSet.getName()));
            }
            uniqueListOfRulesetNameTobeDeleted.add(ruleSet.getName());
        }
        return command.toString();
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    protected List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    protected Set<String> getEgressPortsOfActivePolicies(Device device) {
        List<ManagedObject> egressPortsAndPortGroupsOfActivePolicies = policyRepository.getAllEgressPortsAndPortGroupsByDeviceId(device.getId());
        Set<String> outPortsOfActivePolicies = Sets.newHashSet();
        for (ManagedObject mo : egressPortsAndPortGroupsOfActivePolicies) {
            if (mo instanceof Port) {
                outPortsOfActivePolicies.add(((Port) mo).getPortNumber());
            } else if (mo instanceof PortGroup) {
                outPortsOfActivePolicies.add(((PortGroup) mo).getPrimaryPort().getPortNumber());
            }
        }
        return outPortsOfActivePolicies;
    }

    protected Set<String> getEgressPortsOfSavedOverActivePolicies(Device device) {
        Set<String> outPortsOfSavedActivePolicies = Sets.newHashSet();
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(device.getId(), 0l);
        for (Policy activePolicy : activePolicies) {
            for (Flow flow : activePolicy.getFlows()) {
                if (flow.getEgressPorts() != null) {
                    outPortsOfSavedActivePolicies.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                }
                if (flow.getEgressPortGroups() != null) {
                    outPortsOfSavedActivePolicies.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                }
            }
        }
        return outPortsOfSavedActivePolicies;
    }

    protected Set<String> getEgressPortsFromPolicy(Policy policy) {
        Set<String> outPortsOfCurrentPolicy = Sets.newHashSet();
        for (Flow flow : policy.getFlows()) {
            if (flow.getEgressPorts() != null) {
                outPortsOfCurrentPolicy.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
            }
            if (flow.getEgressPortGroups() != null) {
                outPortsOfCurrentPolicy.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
            }
        }
        return outPortsOfCurrentPolicy;
    }

    protected String getRmOrL2AclName(HeaderStrippingModulePolicy.Headers header) {
        String rmOrL2AclName = "";
        if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
            rmOrL2AclName = "only-br";
        } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
            rmOrL2AclName = "only-vntag";
        } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
            rmOrL2AclName = "only-br-vntag";
        }
        return rmOrL2AclName;
    }

    protected String getIntermediatePortNumber(Long intermediatePortId) {
        Port intermediatePort = null;
        ManagedObject managedObject = getManagedObject(intermediatePortId);
        if (managedObject instanceof Port) {
            intermediatePort = (Port) managedObject;
        } else if (managedObject instanceof PortGroup) {
            intermediatePort = ((PortGroup) managedObject).getPrimaryPort();
        }
        return intermediatePort.getPortNumber();
    }

    private ManagedObject getManagedObject(Long intermediatePortId) {
        Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
        List<Long> ids = new ArrayList<>();
        ids.add(intermediatePortId);
        query.setParameter("ids", ids);
        return (ManagedObject) query.getSingleResult();
    }
}
