package com.brocade.bvm.outbound;

import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.TargetHost;
import com.brocade.bvm.model.exception.ServerException;
import org.springframework.context.ApplicationContext;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collection;
import java.util.Optional;

@Named
public class OutboundJobExecutorBuilder {

    @Inject
    private ApplicationContext applicationContext;
    private Collection<OutboundJobExecutor> outboundJobExecutors;

    @Inject
    protected PolicyRepository policyRepository;

    @PostConstruct
    void init() {
        outboundJobExecutors = applicationContext.getBeansOfType(OutboundJobExecutor.class).values();
    }

    public OutboundJobExecutor build(Job job) {
        Device.Mode mode = job.getDevice().getMode();
        if (Device.Mode.PLAIN == mode) {
            Policy policy = policyRepository.findOne(job.getParentObjectId());
            final TargetHost.Mode[] modeToBeConsidered = {job.getTargetHost().getMode()};
            if (policy != null) {
                policy.getFlows().forEach(flow -> {
                    flow.getRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getType() == com.brocade.bvm.model.db.RuleSet.Type.UDA)
                            modeToBeConsidered[0] = TargetHost.Mode.PLAIN;
                    });
                });
            }
            Optional<OutboundJobExecutor> outboundJobExecutor = outboundJobExecutors.stream()
                    .filter(oje -> oje.getSupportedMode() == modeToBeConsidered[0] && oje.getSupportedJobTypes().contains(job.getType()) &&
                            //TODO to fix the cast issue for open stack device
                            (oje.getSupportedDeviceTypes().contains(job.getDevice().getType())))
                    .findFirst();
            if (outboundJobExecutor.isPresent()) {
                return outboundJobExecutor.get();
            } else {
                throw new ServerException(String.format("No supported OutboundJobExecutor found for job: %s, device: %s, %s ", job.getType(), job.getDevice().getType(), job.getDevice().getMode()));
            }
        } else {
            throw new ServerException(String.format("No supported OutboundJobExecutor found for job: %s, device: %s, %s ", job.getType(), job.getDevice().getType(), job.getDevice().getMode()));
        }
    }
}
