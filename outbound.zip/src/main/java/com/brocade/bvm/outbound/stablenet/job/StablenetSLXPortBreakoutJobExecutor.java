package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Named
public class StablenetSLXPortBreakoutJobExecutor extends AbstractStablenetJobExecutor {
    @Inject
    protected PortRepository portRepository;

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String HARDWARE = "hardware;";
    private static final String CONNECTOR = "connector %s;";
    private static final String ENABLE_BREAKOUT_10G = "breakout mode 4x10g;";
    private static final String ENABLE_BREAKOUT_25G = "breakout mode 4x25g;";
    private static final String DISABLE_BREAKOUT = "no breakout;";
    private static final String END = "end;";
    private static final String EXIT = "exit;";
    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";
    protected static final String SHUTDOWN = "shutdown;";

    @Inject
    private PortHistoryRepository portHistoryRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_BREAKOUT_ENABLE, Job.Type.PORT_BREAKOUT_DISABLE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method is used to build commands to enable/disable the selected port(s) as L2/L3/L23 on Open Flow device
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder();
        StringBuilder portBuilder = new StringBuilder(TERMINAL_ENTER);
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        commands.append(HARDWARE);

        if (job.getType() == Job.Type.PORT_BREAKOUT_ENABLE) {
            for (Port port : ports) {
                //Shutting down the selected ports before breaking out the ports
                portBuilder.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                portBuilder.append(SHUTDOWN);
                portBuilder.append(EXIT);
                //Commands under hardware
                commands.append(String.format(CONNECTOR, port.getPortNumber()));
                if (port.getLineSpeed() != null && Port.SPEED_10G == port.getLineSpeed().longValue()) {
                    commands.append(ENABLE_BREAKOUT_10G);
                } else if (port.getLineSpeed() != null && Port.SPEED_25G == port.getLineSpeed().longValue()) {
                    commands.append(ENABLE_BREAKOUT_25G);
                }
            }
        } else {
            Set<String> uniqueDisablePorts = new HashSet<>();
            for (Port port : ports) {
                if (port.getName() != null && port.getPortNumber() != null) {
                    String portName = port.getName().split(":")[0];
                    if (portName != null && !uniqueDisablePorts.contains(portName)) {
                        uniqueDisablePorts.add(portName);
                        List<String> allBreakOutPorts = StreamSupport.stream(portRepository.getPortsByNameAndDeviceId(portName + ":", job.getDevice().getId()).spliterator(), false).map(Port::getPortNumber).collect(Collectors.toList());
                        //Shutting down the selected ports and connected breakout ports for disabling the breakout ports
                        for (String breakoutPort : allBreakOutPorts) {
                            portBuilder.append(String.format(INTERFACE_ETHERNET, breakoutPort));
                            portBuilder.append(SHUTDOWN);
                            portBuilder.append(EXIT);
                        }
                        //Commands under hardware
                        commands.append(String.format(CONNECTOR, port.getPortNumber().split("[:]")[0]));
                        commands.append(DISABLE_BREAKOUT);
                    }
                }
            }
        }

        commands.append(END);
        if (!isReloadRequiredForSlxOsVersion(job.getDevice())) {
            commands.append(updateBreakoutCommand(job));
        }
        portBuilder.append(commands);
        return portBuilder.toString();
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
