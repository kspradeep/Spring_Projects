package com.brocade.bvm.outbound.bsc.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
public class FlowVerificationDetails {

    public enum ObjectType{
        OPERATIONAL,
        CONFIG
    }

    private List<String> unmatchedFlowIds = new ArrayList<>();
    private Map<String,List<FlowRule>> configurationObjects = new HashMap<>();
    private Map<String,List<FlowRule>>  operationalObjects = new HashMap<>();
    //openflow device id
    private String deviceId;


    public void addConfigurationObject(String key, FlowRule configObject){
        if(configurationObjects.get(key)==null){
            List<FlowRule> rules = new ArrayList<>();
            configurationObjects.put(key,rules);
        }
        configurationObjects.get(key).add(configObject);
    }

    public void addOperationalObject(String key, FlowRule configObject){
        if(operationalObjects.get(key)==null){
            List<FlowRule> rules = new ArrayList<>();
            operationalObjects.put(key,rules);
        }
        operationalObjects.get(key).add(configObject);
    }
}
