package com.brocade.bvm.outbound.firmware.job.util;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.connection.channel.direct.PTYMode;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.springframework.context.annotation.Scope;

import javax.inject.Named;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
@Scope(value = "prototype")
public class SshConnection {

    private InputStream inputStream;
    private PrintStream outputStream;
    private Socket socket;
    private Session sshSession;
    private SSHClient sshClient;
    private int defaultIdleTimeout = CliConstants.DEFAULT_IDLE_TIMEOUT;
    private static final Pattern PROMPT_REGEX = Pattern.compile(".*#\\s$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CONFIRMATION_REGEX = Pattern.compile(".*\\[y\\/n\\]:$", Pattern.CASE_INSENSITIVE);
    public static final String SLX_FIRMWARE_END = "SLX-OS Firmwaredownload End";
    public static final String SLX_FIRMWARE_DOWNLOAD_FAILED = "Firmware download failed";
    public static final String SLX_REBOOT_PROMPT = "The system is going down for reload NOW !!";

    public void connect(String host, String username, String password) throws Exception {
        try {
            sshClient = new SSHClient();
            int port = 22;
            // This is required when ip ssh permit-empty-password is enabled on the
            // device
            if ((username == null || username.equals("")) && (password == null || password.equals(""))) {
                username = "dummy";
            }
            sshClient.addHostKeyVerifier(new PromiscuousVerifier());
            sshClient.connect(host);

            if (!sshClient.isConnected()) {
                sshClient.disconnect();
                throw new CliConnectorException("Unable to connect to SSH server " + host);
            }
            sshClient.setConnectTimeout(CliConstants.DEFAULT_LOGIN_TIMEOUT);
            sshClient.getTransport().setTimeoutMs(CliConstants.DEFAULT_LOGIN_TIMEOUT);
            sshClient.authPassword(username, password);
            if (!sshClient.isAuthenticated()) {
                throw new CliConnectorException("Failed to authenticate to SSH host " + host);
            }

            // Connect to the host
            socket = sshClient.getSocket();

            if (!socket.isConnected() || socket.isClosed()) {
                throw new CliConnectorException("Unable to connect to SSH server " + host);
            }
            // set socket timeout to solve the blocking read issue
            socket.setSoTimeout(CliConstants.DEFAULT_LOGIN_TIMEOUT);

            final Session sshSession = sshClient.startSession();

            sshSession.allocatePTY("vt100", 80, 24, 0, 0, Collections.<PTYMode, Integer>emptyMap());
            sshSession.startShell();
            inputStream = new BufferedInputStream(sshSession.getInputStream(), CliConstants.DEFAULT_BUFFER_SIZE);
            outputStream = new PrintStream(sshSession.getOutputStream());
        } catch (IOException e) {
            log.error("Error in SSH connection with {}: {}", host, e.getMessage());
            throw new CliConnectorException("Error in SSH connection.");
        }
    }

    public SFTPClient getSftpClient() throws Exception {
        return sshClient.newSFTPClient();
    }

    private int read(byte[] b) throws CliConnectorException {
        if (inputStream == null) {
            return 0;
        }
        int dataRead = 0;
        try {
            dataRead = inputStream.read(b, 0, b.length);
        } catch (IOException e) {
            log.error("Unable to read data");
            return 0;
        }
        if (dataRead == -1) {
            disconnect();
            log.error("Connection to host lost");
        }
        return dataRead;
    }

    public void disconnect() throws CliConnectorException {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (sshSession != null) {
                sshSession.close();
            }
            if (sshClient != null) {
                sshClient.disconnect();
            }
            if (socket != null) {
                socket.close();
            }
            inputStream = null;
            outputStream = null;
            sshSession = null;
            socket = null;
            sshClient = null;
        } catch (IOException e) {
            log.error("Error in disconnect {}", e.getMessage());
            throw new CliConnectorException("Error in disconnect " + e.getMessage());
        }
    }

    public void write(String cmd) {
        if (outputStream != null) {
            outputStream.println(cmd);
            outputStream.flush();
        }
    }

    public void send(String cmd, boolean prefixNewLine) {
        if (prefixNewLine) {
            write(cmd + "\r");
        } else {
            write(cmd);
        }
    }

    private boolean isEndOfData(StringBuilder sb, int startIndex, boolean stripPrompt) {
        Matcher m = PROMPT_REGEX.matcher(sb);
        if (m.find(startIndex)) {
            if (stripPrompt) {
                sb.delete(m.start(), m.end());
            }
            return true;
        }
        return false;
    }

    private boolean isConfirmationCmd(StringBuilder sb, int startIndex) {
        Matcher m = CONFIRMATION_REGEX.matcher(sb);
        if (m.find(startIndex)) {
            return true;
        }
        return false;
    }

    public String readData() throws CliConnectorException {
        StringBuilder sb = new StringBuilder();
        readData(sb, false);
        return sb.toString();
    }

    public int readData(StringBuilder result, boolean stripPrompt) throws CliConnectorException {
        byte[] buf = new byte[CliConstants.DEFAULT_BUFFER_SIZE];
        int startIndex = 0;
        int totalCount = 0;
        while (true) {
            int dataRead = read(buf);
            if (dataRead > 0) {
                totalCount += dataRead;
                result.ensureCapacity(totalCount);
                // find end of line index in the result buffer starting from behind
                // Use that index as the start index to find the end of data marker
                for (int i = result.length() - 1; i >= 0; i--) {
                    if (result.charAt(i) == '\n' || result.charAt(i) == '\r') {
                        startIndex = i;
                        break;
                    }
                }
                StringBuilder resultLine = new StringBuilder();
                for (int i = 0; i < dataRead; i++) {
                    resultLine.append((char) buf[i]);
                    result.append((char) buf[i]);
                }
                String output = resultLine.toString();
                if (output != null && output.contains("firmware download scp")) {
                    Pattern pattern = Pattern.compile(".*password\\s+([^\\s]+)\\s+directory.*");
                    Matcher matcher = pattern.matcher(output.replaceAll("\r\n",""));
                    if (matcher.matches() && matcher.groupCount() > 0) {
                        int fromIndex = matcher.start(1);
                        int toIndex = matcher.end(1);

                        if (fromIndex > 0 && toIndex > fromIndex) {
                            String finalString = output.substring(0, fromIndex) + "********" + output.substring(toIndex);
                            log.debug("Device output: {}", finalString);
                        }
                    } else {
                        log.debug("Firmware download command sent to device..");
                    }
                } else {
                    log.debug("Device output: {}", output);
                }
                if (isEndOfData(result, startIndex, stripPrompt)) {
                    break;
                } else if (isConfirmationCmd(result, startIndex)) {
                    break;
                } else if (result.toString().contains(SLX_FIRMWARE_END)) {
                    break;
                } else if (result.toString().contains(SLX_REBOOT_PROMPT)) {
                    break;
                }
            } else {
                break;
            }
        }
        return totalCount;
    }

    public List<Response> executeCommand(List<String> cmds, CliConstants.AccessMode mode) throws CliConnectorException {
        CliCommandConstraints cons = new CliCommandConstraints();
        return executeCommand(cmds, cons);
    }

    public List<Response> executeCommand(List<String> cmds, CliCommandConstraints cons) throws CliConnectorException {
        setSocketTimeout(CliConstants.DEFAULT_CMD_RESPONSE_TIMEOUT);
        List<Response> responses = Lists.newArrayList();
        try {
            for (String cmd : cmds) {
                Response r = executeCommand(cmd, cons, true);
                responses.add(r);
                if (r.hasErrorOccurred()) {
                    if (cons.isStopOnError()) {
                        break;
                    }
                }
                if (r.getValue().contains("Do you want to continue") || r.getValue().contains("Are you sure you want to reload the switch")) {
                    Response newResponse = executeCommand("y", cons, true);
                    // object r still refers to the object in the arraylist
                    r.setErrorOccurred(newResponse.hasErrorOccurred());
                    r.setValue(newResponse.getValue());
                }
            }
        } catch (CliConnectorException e) {
            log.error("Error in executing cli commands {}", e.getMessage());
            throw new CliConnectorException("Error executing cli commands " + " : " + e.getMessage());
        }

        return responses;
    }

    public void setSocketTimeout(int to) throws CliConnectorException {
        try {
            if (null != socket) {
                socket.setSoTimeout(to);
            } else {
                log.error("Socket is already closed and deleted");
            }
        } catch (SocketException e) {
            log.error("Error setting socket timeout {}", e.getMessage());
            throw new CliConnectorException("Error setting socket timeout " + e.getMessage());
        }
    }

    private Response executeCommand(String cmd, CliCommandConstraints cons, boolean prefixNewLine)
            throws CliConnectorException {
        Response response = new Response();
        send(cmd, prefixNewLine);
        StringBuilder sb = new StringBuilder(10000);
        readData(sb, true);
        // the command that is sent is returned back while reading data.
        // so strip the echoed command
        stripCommandEcho(cmd, sb);
        String data = sb.toString().trim();
        response.setValue(data);

        return response;
    }

    private void stripCommandEcho(String cmd, StringBuilder sb) {
        int si = sb.indexOf(cmd);
        if (si >= 0) {
            int ei = si + cmd.length();
            sb.delete(si, ei);
        }
    }
}
