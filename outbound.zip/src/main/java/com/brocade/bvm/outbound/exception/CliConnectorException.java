package com.brocade.bvm.outbound.exception;

public class CliConnectorException extends Exception {

    public CliConnectorException(String msg) {
        super(msg);
    }
}
