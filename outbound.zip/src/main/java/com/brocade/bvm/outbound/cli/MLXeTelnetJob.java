package com.brocade.bvm.outbound.cli;

import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.Builder;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Queues;

@Builder(builderMethodName = "requiredArgsBuilder")
public class MLXeTelnetJob {

	private static final List<String> START_JOB_COMMANDS = Collections.singletonList("configure terminal");
	private static final List<String> END_JOB_COMMANDS = Lists.newArrayList("end", "write mem");
	
	private static final Pattern RESPONSE_FAILURE_PATTERN = Pattern.compile("error:|exception:|invalid|failed|failure|"
			+ "invalid|not supported|unable to add|unable to set|unable to remove|out of memory|ambiguous", Pattern.CASE_INSENSITIVE); 
	private static final Pattern RESPONSE_EXECUTED_COMMAND_PATTERN = Pattern.compile("(?:<\\d\\d:\\d\\d:\\d\\d>)\\s\\[(.*)\\]");

	private final ImmutableList<CommandBlock> commandBlocks;

	public static MLXeTelnetJobBuilder builder(ImmutableList<CommandBlock> commandBlocks) {
		return requiredArgsBuilder().commandBlocks(commandBlocks);
	}
	
	public List<String> getRunnableCommands(List<String> params) {
		List<String> runnableCommands = Lists.newArrayList(START_JOB_COMMANDS);
		int i = 0;
		for (CommandBlock commandBlock : commandBlocks) {
			for (CommandLet commandLet : commandBlock.getCommandLets()) {
				if (commandLet.isNeedsParam()) {
					try {
						runnableCommands.add(commandLet.getCommand() + " " + params.get(i++));
					} catch (IndexOutOfBoundsException e) {
						throw new RuntimeException("Invalid list of params!", e);
					}
				} else {
					runnableCommands.add(commandLet.getCommand());
				}
			}
		}
		
		runnableCommands.addAll(END_JOB_COMMANDS);
		
		return runnableCommands;
	}
	
	public Optional<List<String>> validateResponse(String response, List<String> params) {
		Pattern pattern = Pattern.compile("telnet@.*?#", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(response);

		//a responseBlock represents the response of one commandLet
		List<String> responseBlocks = Lists.newArrayList();
		int startIndex = 0;
		while (matcher.find()) {
			responseBlocks.add((response.substring(startIndex, matcher.start() - 1)));
			startIndex = matcher.end() + 1;
		}
		
		//Ignore the first 2 blocks representing "login" and "enable", and "terminal length 0"
		responseBlocks.remove(0);
		responseBlocks.remove(0);
		System.out.println(responseBlocks);
		
		Deque<String> undoCommands = Queues.newArrayDeque();
		
		int i = 0;
		int j = 0;
		boolean isValidResponse = true;

		//start block commands
		Matcher executedCommandMatcher = RESPONSE_EXECUTED_COMMAND_PATTERN.matcher(responseBlocks.get(i++));
		if (!executedCommandMatcher.find() || executedCommandMatcher.group().equals(START_JOB_COMMANDS.get(0))) {
			//TODO command not found in response!, ignore and move on?
		}
		for (CommandBlock commandBlock : commandBlocks) {
			for (CommandLet commandLet : commandBlock.getCommandLets()) {
				executedCommandMatcher = RESPONSE_EXECUTED_COMMAND_PATTERN.matcher(responseBlocks.get(i));
				if (executedCommandMatcher.find() && executedCommandMatcher.group().equals(commandLet.getCommand())) {
					undoCommands.addFirst(commandLet.isNeedsParam() ? commandLet.getUndoCommand() + " " + params.get(j++) : commandLet.getUndoCommand());
				} else {
					//TODO command not found in response!, ignore and move on?
				}

				Matcher failureMatcher = RESPONSE_FAILURE_PATTERN.matcher(responseBlocks.get(i++));
				if (failureMatcher.find()) {
					isValidResponse = false;
					break;
				}
			}
		}
		
		if (!isValidResponse) {
			return Optional.of(Lists.newArrayList(undoCommands.descendingIterator()));
		} else {
			return Optional.empty();
		}
		
	}
}
