package com.brocade.bvm.outbound.exception;

import com.brocade.bvm.model.exception.ServerException;

public class InterfaceMissingException extends OutboundApiException {

    public InterfaceMissingException(Throwable cause) {
        super(cause);
    }

    public InterfaceMissingException(String message) {
        super(message);
    }

    public InterfaceMissingException(String message, Throwable cause) {
        super(message, cause);
    }
}
