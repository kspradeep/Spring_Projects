package com.brocade.bvm.outbound;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.FirmwareJob;

import java.util.List;


public interface FirmwareOutboundJobExecutor {
    List<FirmwareJob.Type> getSupportedJobTypes();
    List<Device.Type> getSupportedDeviceTypes();
    FirmwareOutboundJobResponse executeOutboundJob(FirmwareJob firmwareJob);
}
