package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.bsc.util.BscPolicyComparator;
import com.brocade.bvm.outbound.bsc.util.BscPolicyDiff;
import com.brocade.bvm.outbound.exception.InterfaceMissingException;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The BscPolicyUpdateJobExecutor class implements methods to UPDATE Policy through BSC on Open flow device
 */
@Slf4j
@Named
public class BscPolicyUpdateJobExecutor extends BscPolicyDeleteJobExecutor {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private BscPolicyComparator bscPolicyComparator;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.POLICY_UPDATE, Type.POLICY_REVERT);
    }

    @Override
    public Long startExternalJob(Job job) {
        //not required for Bsc
        return null;
    }

    /**
     * This method is used to UPDATE policy on device through BSC REST API
     *
     * @param job
     * @return
     */
    @Override
    public OutboundJobResponse execute(Job job) {
        boolean jobResult = false;
        List<String> portGroupIds = new ArrayList<>();
        Policy policyToApply = (Policy) getParentObject(job);
        String openFlowId = job.getDevice().getOpenflowId();
        Long deviceId = job.getDevice().getId();
        Map<String, String> portIdNameMap = getPortNameIdMap(openFlowId);
        List<WorkflowParticipant.WorkflowStatus> statuses = Lists.newArrayList();
        statuses.add(WorkflowParticipant.WorkflowStatus.ACTIVE);
        if (job.getType() == Type.POLICY_REVERT) {
            statuses.add(WorkflowParticipant.WorkflowStatus.ERROR);
        }
        Policy oldPolicy = getPolicyFromHistory(policyToApply, statuses);

        // update
        Set<Long> flowToUpdate = new TreeSet<>();
        Set<Long> flowToDelete = new TreeSet<>();
        Set<Long> flowToCreate = new TreeSet<>();
        Set<Long> oldFlowIds = oldPolicy.getFlows().stream().map(Flow::getId).collect(Collectors.toSet());
        Set<Long> newFlowIds = policyToApply.getFlows().stream().map(Flow::getId).collect(Collectors.toSet());
        Map<String, Set<String>> flowIdNameMap = getFlowInfo(openFlowId);
        Map<String, Set<String>> grpIdNameMap = getGroupInfo(openFlowId);
        Set<String> grpIds = grpIdNameMap.get("ids");
        Set<String> flowIds = flowIdNameMap.get("ids");
        List<String> operationalFlowIds = getOperationalFlowInfo(openFlowId);
        flowIds.addAll(operationalFlowIds);

        Set<Long> oldPortGroupIds = Sets.newHashSet();
        oldPolicy.getFlows().forEach(flow -> {
            oldPortGroupIds.addAll(flow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
        });

        Set<Long> newPortGroupIds = Sets.newHashSet();
        policyToApply.getFlows().forEach(flow -> {
            newPortGroupIds.addAll(flow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
        });

        boolean isVlanStrippingUpdated = false;
        boolean isVlanUpdated = false;
        Device device = policyToApply.getDevice();
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {

            String oldVlan = oldPolicy.getFlows().stream().findAny().get().getVlans().stream().findAny().orElse(null);
            String newVlan = policyToApply.getFlows().stream().findAny().get().getVlans().stream().findAny().orElse(null);

            boolean oldVlanStripping = oldPolicy.getFlows().stream().findAny().get().getVlanStripping();
            boolean newVlanStripping = policyToApply.getFlows().stream().findAny().get().getVlanStripping();

            if (oldVlanStripping && !newVlanStripping) {
                isVlanStrippingUpdated = true;
            } else if (!oldVlanStripping && newVlanStripping) {
                isVlanStrippingUpdated = true;
            }

            //Deleted portGroups
            Set<Long> deletedPortGroupIds = Sets.newHashSet();
            oldPortGroupIds.forEach(aLong -> {
                if (!newPortGroupIds.contains(aLong)) {
                    deletedPortGroupIds.add(aLong);
                }
            });

            if (!updateGroupOnDevice(openFlowId, deletedPortGroupIds, null, false)) {
                return new OutboundJobResponse(Job.Status.FAILED, "Policy Updation Failed on Device");
            }

            //Added portGroups
            Set<Long> addedPortGroupIds = Sets.newHashSet();
            Set<Long> unchangedPortGroupIds = Sets.newHashSet();
            newPortGroupIds.forEach(aLong -> {
                if (!oldPortGroupIds.contains(aLong)) {
                    addedPortGroupIds.add(aLong);
                } else {
                    unchangedPortGroupIds.add(aLong);
                }
            });

            if (!updateGroupOnDevice(openFlowId, addedPortGroupIds, newVlan, newVlanStripping)) {
                return new OutboundJobResponse(Job.Status.FAILED, "Policy Updation Failed on Device");
            }

            if (oldVlan != null && newVlan == null) {
                isVlanUpdated = true;
            } else if (oldVlan == null && newVlan != null) {
                isVlanUpdated = true;
            } else if (oldVlan != null && newVlan != null && !oldVlan.equals(newVlan)) {
                isVlanUpdated = true;
            }

            // If VLAN is modified, applying new VLAN tagging to unchanged Groups
            if (isVlanUpdated || isVlanStrippingUpdated) {
                if (!updateGroupOnDevice(openFlowId, unchangedPortGroupIds, newVlan, newVlanStripping)) {
                    return new OutboundJobResponse(Job.Status.FAILED, "Policy Updation Failed on Device");
                }
            }
        }

        // collecting flows to create and update
        newFlowIds.stream().forEach(eachNewFlowId -> {
            if (oldFlowIds.contains(eachNewFlowId)) {
                flowToUpdate.add(eachNewFlowId);
            } else if (!oldFlowIds.contains(eachNewFlowId)) {
                flowToCreate.add(eachNewFlowId);
            }
        });

        // collecting flows to delete
        oldFlowIds.stream().forEach(eachOldFlowId -> {
            if (!newFlowIds.contains(eachOldFlowId)) {
                flowToDelete.add(eachOldFlowId);
            }
        });

        // updating the policy by deleting old flows
        oldPolicy.getFlows().stream().forEach(eachOldFlow -> {
            if (flowToDelete.contains(eachOldFlow.getId())) {
                //trigger for delete
                List<Long> toDeleteRuleIds = new ArrayList<>();
                eachOldFlow.getRuleSets().stream().forEach(ruleSet -> {
                    toDeleteRuleIds.addAll(ruleSet.getRules().stream().map(Rule::getId).collect(Collectors.toList()));
                });

                List<Port> oldIngressPortList = (List<Port>) portRepository.findAll(eachOldFlow.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
                Set<String> oldIngressSet = oldIngressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
                addServicePortsToIngress(eachOldFlow, oldIngressSet);

                List<Port> oldEgressPortList = (List<Port>) portRepository.findAll(eachOldFlow.getEgressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
                Set<String> oldEgressSet = oldEgressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

                deleteFlows(oldPolicy.getName(), oldIngressSet, toDeleteRuleIds, portIdNameMap, openFlowId);
                List<String> groupIds = getGroupIds(oldPolicy.getId(), oldEgressSet, portIdNameMap, openFlowId, eachOldFlow.getSequence());
                for (String groupId : groupIds) {
                    deleteGroupOnDevice(openFlowId, groupId);
                }
            }
        });

        // updating the policy by updating the updated flows and adding new flows
        for (Flow eachNewFlow : policyToApply.getFlows()) {
            if (flowToUpdate.contains(eachNewFlow.getId())) {
                //trigger for comparator and update
                Flow oldFlow = oldPolicy.getFlows().stream().filter(flow -> eachNewFlow.getId().equals(flow.getId())).findFirst().get();
                try {
                    jobResult = updateFlows(oldFlow, eachNewFlow, policyToApply.getName(), oldPolicy.getName(), policyToApply.getId(), openFlowId, portIdNameMap, grpIds, flowIds, portGroupIds, deviceId, eachNewFlow.getVlanStripping(), isVlanUpdated, isVlanStrippingUpdated);
                    BscPolicyDiff policyDiff = bscPolicyComparator.comparePolicy(oldFlow, eachNewFlow);
                    BscPolicyDiff.Transition newState = policyDiff.getNewCategory();
                    if (newState == BscPolicyDiff.Transition.SI_SE || newState == BscPolicyDiff.Transition.SI_PG || newState == BscPolicyDiff.Transition.MI_PG) {
                        BscPolicyDiff.Transition oldState = policyDiff.getOldCategory();
                        if (oldState == BscPolicyDiff.Transition.MI_ME || oldState == BscPolicyDiff.Transition.SI_ME || oldState == BscPolicyDiff.Transition.MI_SE) {
                            List<Port> oldEgressPortList = (List<Port>) portRepository.findAll(oldFlow.getEgressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
                            Set<String> oldEgressSet = oldEgressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
                            List<String> groupIds = getGroupIds(oldPolicy.getId(), oldEgressSet, portIdNameMap, openFlowId, oldFlow.getSequence());
                            if (groupIds != null)
                                for (String groupId : groupIds) {
                                    deleteGroupOnDevice(openFlowId, groupId);
                                }
                        }
                    }

                } catch (InterfaceMissingException e) {
                    return new OutboundJobResponse(Job.Status.FAILED, e.getMessage());
                }
            } else if (flowToCreate.contains(eachNewFlow.getId())) {
                //trigger for fresh create
                Flow newFlow = policyToApply.getFlows().stream().filter(flow -> eachNewFlow.getId().equals(flow.getId())).findFirst().get();
                try {
                    jobResult = createFlows(newFlow, deviceId, openFlowId, policyToApply.getName(), policyToApply.getId(), portIdNameMap, grpIds, flowIds, eachNewFlow.getVlanStripping());

                } catch (InterfaceMissingException e) {
                    return new OutboundJobResponse(Job.Status.FAILED, e.getMessage());
                }
            }
            if (!jobResult) {
                return new OutboundJobResponse(Job.Status.FAILED, "Policy Updation Failed on Device");
            }
        }
        if (!portGroupIds.isEmpty()) {
            deleteAllPG(openFlowId, portGroupIds);
            log.debug("Successfully deleted the port groups");
        }

        return new OutboundJobResponse(Job.Status.SUCCESS, "Policy Updation Successful on Device");
    }

    private boolean updateGroupOnDevice(String openFlowId, Set<Long> portGroupIds, String vlan, boolean vlanStripping) {
        boolean isPGCreationSuccess = true;
        for (Long portGroupId : portGroupIds) {
            PortGroup portGroup = portGroupRepository.findById(portGroupId);
            Set<Port> ports = portGroup.getPorts();
            // Converting port number to port name by prepending with 'eth'
            List<String> portIds = ports.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toList());

            Map<String, String> grpMap = getGroupNameIdMap(openFlowId);
            Map<String, String> portIdNameMap1 = getPortNameIdMap(openFlowId);
            List<String> portIdList = new ArrayList<>();
            for (String portName : portIds) {
                String portid = portIdNameMap1.get(portName);
                if (portid != null)
                    portIdList.add(portid);
            }
            String groupName = portGroup.getName() + "_select";
            String groupId = grpMap.get(groupName);
            String group = (vlan == null && !vlanStripping) ? buildPortGroup(groupId, groupName.toString(), "group-select", portIdList) : buildGroupWithVLan(groupId, groupName.toString(), "group-select", portIdList, vlan, "", "", vlanStripping);
            isPGCreationSuccess = addGroupOnDevice(openFlowId, groupId, group);
            if (!isPGCreationSuccess) {
                return false;
            }
        }
        return isPGCreationSuccess;
    }

    /**
     * @param newFlow
     * @param deviceId
     * @param openflowId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param grpIds
     * @param flowIds
     * @return
     */
    private boolean createFlows(Flow newFlow, Long deviceId, String openflowId, String policyName, Long policyId, Map<String, String> portIdNameMap,
                                Set<String> grpIds, Set<String> flowIds, boolean vlanStripping) throws InterfaceMissingException {
        boolean jobResult = false;
        int flowPriority = newFlow.getSequence();
        String vlan = newFlow.getVlans().size() > 0 ? newFlow.getVlans().stream().findFirst().get() : null;
        String srcMacTag = newFlow.getSourceMacTag();
        String destMacTag = newFlow.getDestinationMacTag();
        Set<String> egressSet = newFlow.getEgressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
        Set<String> ingressSet = newFlow.getIngressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

        Set<String> ports = new HashSet<String>(egressSet);
        ports.addAll(ingressSet);
        checkIfValidInterface(portIdNameMap, ports);

        // This is to support Service port group as ingress for openflow
        addServicePortsToIngress(newFlow, ingressSet);

        jobResult = addPolicyOnDecvice(deviceId, openflowId, policyName, policyId, portIdNameMap, grpIds, flowIds, egressSet,
                ingressSet, newFlow.getEgressPortGroups(), newFlow.getRuleSets(), flowPriority, vlan, srcMacTag, destMacTag, vlanStripping);

        return jobResult;
    }

    /**
     * This method is used to update flows on the device in granular way
     *
     * @param oldFlow
     * @param newFlow
     * @param newPolicyName
     * @param oldPolicyName
     * @param policyId
     * @param openFlowId
     * @param portIdNameMap
     * @param grpIds
     * @param flowIds
     * @param portGroupIds
     * @return
     */
    private boolean updateFlows(Flow oldFlow, Flow newFlow, String newPolicyName, String oldPolicyName, Long policyId,
                                String openFlowId, Map<String, String> portIdNameMap, Set<String> grpIds, Set<String> flowIds, List<String> portGroupIds, Long deviceId, boolean vlanStripping, boolean isVlanUpdated, boolean isVlanStrippingUpdated) throws InterfaceMissingException {
        boolean jobResult = false;
        bscPolicyComparator.setPortIdNameMap(portIdNameMap);
        BscPolicyDiff policyDiff = bscPolicyComparator.comparePolicy(oldFlow, newFlow);
        List<Rule> deletedRules = policyDiff.getDeletedRules();
        List<Rule> unchangedRules = policyDiff.getUnchangedRules();
        Set<Rule> addedRules = policyDiff.getAddedRules();
        BscPolicyDiff.Transition oldState = policyDiff.getOldCategory();
        BscPolicyDiff.Transition newState = policyDiff.getNewCategory();

        Map<String, BscPolicyDiff.RuleOperation> ruleOperationMap = policyDiff.getRuleOperationMap();

        // deleted rules
        if (deletedRules.size() > 0) {
            List<Long> deletedRuleIds = new ArrayList<>();
            deletedRules.forEach(rule -> {
                deletedRuleIds.add(rule.getId());
            });
            Flow deletedFlow = deletedRules.stream().findFirst().get().getRuleSet().getFlow();
            List<Port> deletedIngressPortList = (List<Port>) portRepository.findAll(deletedFlow.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            Set<String> oldIngressSet = deletedIngressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            addServicePortsToIngress(deletedFlow, oldIngressSet);
            deleteFlows(oldPolicyName, oldIngressSet, deletedRuleIds, portIdNameMap, openFlowId); // delete flows due to rule deletion
        }
        Map<String, String> usedFlowIds = Maps.newHashMap();
        List<String> toDeleteFlowIds = Lists.newArrayList(); // list of flowids to delete due to ingress removal
        List<String> usedGroupNameAndIds = Lists.newArrayList();

        // updated rules
        if (unchangedRules.size() > 0) {
            List<Long> unchangedRuleIds = new ArrayList<>();
            unchangedRules.forEach(rule -> {
                unchangedRuleIds.add(rule.getId());
            });
            Flow unchangedFlows = unchangedRules.stream().findFirst().get().getRuleSet().getFlow();
            String unchangedPolicyName = unchangedFlows.getPolicy().getName();

            List<Port> unchangedIngressPortList = (List<Port>) portRepository.findAll(unchangedFlows.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            Set<String> unchangedIngressSet = unchangedIngressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

            addServicePortsToIngress(unchangedFlows, unchangedIngressSet);

            List<Port> unchangedEgressPortList = (List<Port>) portRepository.findAll(unchangedFlows.getEgressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            Set<String> unchangedEgressSet = unchangedEgressPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            usedFlowIds = getFlowIds(unchangedPolicyName, unchangedIngressSet, unchangedRuleIds, portIdNameMap, openFlowId);
            toDeleteFlowIds = getFlowIdsToDelete(ruleOperationMap, usedFlowIds);
            usedGroupNameAndIds = getGroupIds(policyId, unchangedEgressSet, portIdNameMap, openFlowId, unchangedFlows.getSequence());
        }

        // added rules
        if (addedRules.size() > 0) {
            Flow addedFlow = addedRules.stream().findFirst().get().getRuleSet().getFlow();
            Set<String> addedEgressSet = addedFlow.getEgressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
            usedGroupNameAndIds = getGroupIds(policyId, addedEgressSet, portIdNameMap, openFlowId, addedFlow.getSequence());
        }

        int flowPriority = newFlow.getSequence();
        String vlan = newFlow.getVlans().size() > 0 ? newFlow.getVlans().stream().findFirst().get() : null;
        String srcMacTag = newFlow.getSourceMacTag();
        String destMacTag = newFlow.getDestinationMacTag();
        List<Rule> flatRules = getFlatRules(newFlow.getRuleSets());
        Set<PortGroup> portGroups = newFlow.getEgressPortGroups();
        Set<String> egressSet = newFlow.getEgressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());
        Set<String> ingressSet = newFlow.getIngressPorts().stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet());

        addServicePortsToIngress(newFlow, ingressSet);

        Set<String> ports = new HashSet<String>(egressSet);
        ports.addAll(ingressSet);
        checkIfValidInterface(portIdNameMap, ports);

        if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        }
        //TODO: Need to build a state manager
        if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet.parallelStream().findAny().get(), vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, false, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_SE && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(),
                    vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, true, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_ME && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(),
                    vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, true, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_SE && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(),
                    vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, true, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_ME && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, true, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(),
                    vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, false, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);

        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);

        } else if (oldState == BscPolicyDiff.Transition.SI_PG && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.SI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.MI_PG) {
            jobResult = addFlowWithPortGroup(openFlowId, flowIds, portIdNameMap, flatRules, flowPriority,
                    newPolicyName, portGroups,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, false, toDeleteFlowIds, ruleOperationMap, portGroupIds, deviceId);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.SI_SE) {
            jobResult = flowForSingleIngressAndSingleEgress(openFlowId, newPolicyName, policyId, portIdNameMap,
                    flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(), ingressSet.parallelStream().findAny().get(),
                    vlan, srcMacTag, destMacTag, usedFlowIds, oldPolicyName, false, toDeleteFlowIds, ruleOperationMap, portGroupIds);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.SI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.MI_SE) {
            jobResult = flowForMultipleIngressAndSingleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet.parallelStream().findAny().get(),
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), policyDiff.getIsPGAlterationNeeded(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        } else if (oldState == BscPolicyDiff.Transition.MI_PG && newState == BscPolicyDiff.Transition.MI_ME) {
            jobResult = flowForMultipleEgress(grpIds, openFlowId, newPolicyName, policyId,
                    portIdNameMap, flatRules, flowPriority, flowIds, egressSet,
                    ingressSet, vlan, srcMacTag, destMacTag, usedFlowIds, usedGroupNameAndIds, policyDiff.getIsEgressChanged(), toDeleteFlowIds, ruleOperationMap, deviceId, vlanStripping, isVlanUpdated, isVlanStrippingUpdated);
        }
        return jobResult;
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param policy
     * @param statuses
     * @return
     */
    private Policy getPolicyFromHistory(Policy policy, List<WorkflowParticipant.WorkflowStatus> statuses) {
        Policy policyFromHistory = null;
        // get the previous policy name from the history.
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findByIdAndWorkflowStatusses(policy.getId(),
                statuses);
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            if (HistoryObject.RevisionType.DELETED != oldPolicy.getRevisionType()) {
                log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
                policyFromHistory = oldPolicy.buildParent();
            }
        }
        return policyFromHistory;
    }

    /**
     * This method is used to delete flows on the device
     *
     * @param oldPolicyName
     * @param ingressSet
     * @param ruleIds
     * @param portIdNameMap
     * @param deviceId
     */
    private void deleteFlows(String oldPolicyName, Set<String> ingressSet, List<Long> ruleIds, Map<String, String> portIdNameMap, String deviceId) {
        for (String port : ingressSet) {
            String ingressPortId = portIdNameMap.get(port);
            if (ingressPortId != null) {
                for (Long ruleId : ruleIds) {
                    String flowName = constructBscFlowName(oldPolicyName, ingressPortId, ruleId);
                    List<String> flowIds = getFlowWithPolicyName(deviceId, flowName, false);
                    if (!flowIds.isEmpty()) {
                        deleteFlowOnDevice(deviceId, flowIds.get(0));
                    }
                }
            }
        }
    }

    /**
     * This method is used to get flow ids for the given data
     *
     * @param oldPolicyName
     * @param ingressSet
     * @param ruleIds
     * @param portIdNameMap
     * @param deviceId
     * @return
     */
    private Map<String, String> getFlowIds(String oldPolicyName, Set<String> ingressSet, List<Long> ruleIds, Map<String, String> portIdNameMap, String deviceId) {
        Map<String, String> usedFlowIds = new HashMap<>();
        for (String port : ingressSet) {
            String ingressPortId = portIdNameMap.get(port);
            if (ingressPortId != null) {
                for (Long ruleId : ruleIds) {
                    String flowName = constructBscFlowName(oldPolicyName, ingressPortId, ruleId);
                    List<String> flowIds = getFlowWithPolicyName(deviceId, flowName, false);
                    if (flowIds.size() > 0) {
                        usedFlowIds.put(constructPartialFlowName(ingressPortId, ruleId), flowIds.get(0));
                    }
                }
            }
        }
        return usedFlowIds;
    }

    /**
     * This method is used to get the Port Group ids for the given data
     *
     * @param policyId
     * @param egressSet
     * @param portIdNameMap
     * @param deviceId
     * @return
     */
    private List<String> getGroupIds(Long policyId, Set<String> egressSet, Map<String, String> portIdNameMap, String deviceId, int flowPriority) {

        List<String> portKeys = new ArrayList<>();
        StringBuilder groupName = new StringBuilder(getGroupName(policyId, "lb", flowPriority));

        for (String port : egressSet) {
            String portId = portIdNameMap.get(port);
            if (portId != null)
                portKeys.add(portId);
        }
        Collections.sort(portKeys);
        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }
        return (getGroupNameForFlow(groupName.toString(), deviceId));
    }

    /**
     * This method is used get flow ids to delete from given data
     *
     * @param ruleOperationMap
     * @param flowNameIdMap
     * @return
     */
    private List<String> getFlowIdsToDelete(Map<String, BscPolicyDiff.RuleOperation> ruleOperationMap, Map<String, String> flowNameIdMap) {
        List<String> flowIdsToDelete = new ArrayList<String>();
        for (Map.Entry<String, BscPolicyDiff.RuleOperation> entry : ruleOperationMap.entrySet()) {
            String key = entry.getKey();
            if ((flowNameIdMap.containsKey(key)) && entry.getValue() == BscPolicyDiff.RuleOperation.DELETE) {
                flowIdsToDelete.add(flowNameIdMap.get(key));
            }
        }
        return flowIdsToDelete;
    }

    /**
     * This method is used to get the SERVICE ports from Port Group and add them to INGRESS set
     *
     * @param flow
     * @param ingressSet
     */
    private void addServicePortsToIngress(Flow flow, Set<String> ingressSet) {
        Set<PortGroup> ingressPortGroups = flow.getIngressPortGroups();
        for (PortGroup portGroup : ingressPortGroups) {
            List<Port> oldPortList = (List<Port>) portRepository.findAll(portGroup.getPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()));
            ingressSet.addAll(oldPortList.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toSet()));
        }
    }
}