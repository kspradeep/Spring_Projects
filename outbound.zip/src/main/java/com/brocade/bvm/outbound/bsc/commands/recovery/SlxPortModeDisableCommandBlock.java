package com.brocade.bvm.outbound.bsc.commands.recovery;

import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SlxPortModeDisableCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "configure terminal;interface Ethernet%s;";

    private static final String SHOW_CMD = "do show openflow interface";

    private static final String MATCH_CMD = "^Eth%s";

    private static final String ACTION_CMD = "no openflow enable";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, port));
        args.add(SHOW_CMD);
        args.add(String.format(MATCH_CMD, port));
        args.add(ACTION_CMD);
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SlxPortModeDisableCommandBlock [deviceId=" + deviceId + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
