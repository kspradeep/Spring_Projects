package com.brocade.bvm.outbound.bsc.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;

import lombok.Getter;
import lombok.Setter;

public class BscPortModeDisableCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String mode;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "configure terminal;interface ethernet %s;";

    private static final String SHOW_CMD = "show interface ethernet %s";

    private static final String MATCH_CMD = "%s";

    private static final String ACTION_CMD = "no openflow enable %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD,port));
        args.add(String.format(SHOW_CMD,port));
        args.add(String.format(MATCH_CMD, mode));
        args.add(String.format(ACTION_CMD,mode));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "BscPortModeDisableCommandBlock [deviceId=" + deviceId + ",  mode=" + mode + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
