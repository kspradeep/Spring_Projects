package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXGtpDeEncapsulationCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String portNumber;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "configure terminal;";
    private static final String INTERFACE_ETHERNET = "interface ethernet %s \n%s";
    private static final String SHOW_CMD = "do show running-config interface ethernet %s %s";
    private static final String MATCH_CMD = "gtp-de-encapsulation";
    private static final String ACTION_CMD = "no gtp-de-encapsulation";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, portNumber, MATCH_CMD));
        args.add(MATCH_CMD);
        args.add(String.format(INTERFACE_ETHERNET, portNumber, ACTION_CMD));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXGtpDeEncapsulationCommandBlock [deviceId=" + deviceId + ", portNumber=" + portNumber + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
