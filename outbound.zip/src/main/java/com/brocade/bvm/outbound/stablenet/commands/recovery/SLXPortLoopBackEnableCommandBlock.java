package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import com.google.common.collect.ImmutableSet;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXPortLoopBackEnableCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * configure terminal
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is port number
     * eg: do show running-config interface ethernet 0/1
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config interface ethernet %s";

    /**
     * <pre>
     * matching regex
     * </pre>
     */
    private static final String MATCH_CMD = "loopback";

    /**
     * <pre>
     * argument #1 is port channel id
     * eg: interface ethernet 1/1;loopback phy;
     * </pre>
     */
    private static final String ACTION_CMD = "interface ethernet %s\nshutdown\nno loopback phy\nno shutdown\nexit";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, port));
        args.add(MATCH_CMD);
        args.add(String.format(ACTION_CMD, port));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXPortLoopBackEnableCommandBlock{" +
                "deviceId=" + deviceId +
                ", port=" + port +
                ", getTemplateJobInput()='" + getTemplateJobInput() + '\'' +
                '}';
    }
}
