package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.RuleSetRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.outbound.stablenet.commands.BeanUtil;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The StablenetCommitPolicyJobExecutor class implements methods used in COMMIT policy on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetCommitPolicyJobExecutor extends AbstractStablenetPolicyJobExecutor {

    public enum PortType {
        SOURCE, DESTINATION
    }

    private static final HashSet<String> portOperators = new HashSet<>(Arrays.asList("eq", "gt", "lt", "neq", "range"));

    private static final int MIN_PORT_NO = 0;

    private static final int MAX_PORT_NO = 65535;

    protected static final String MAC = "mac";

    private static final String MAC_MASK = "ffff.ffff.ffff";

    private static final String ETHER_TYPE = "etype";

    private static final String IP = "ip";

    private static final String IPV6 = "ipv6";

    private static final String SCTP = "sctp";

    private static final String TCP = "tcp";

    private static final String UDP = "udp";

    private static final String CMD_DENY = "deny";

    private static final String CMD_ANY = "any";

    private static final String CMD_HOST = "host";

    private static final String CMD_VLAN = "vlan";

    private static final String SPACE = " ";

    private static final String SEMI_COLON = ";";

    /***********************************************************************************/

    /*** Expect #1 as protocol and #2 as name for rule set */
    protected static final String IPV4_RULE_SET_HEADER_FORMAT = "ip access-list extended %s;";

    /*** Expect #1 as protocol and #2 as name for rule set */
    protected static final String IPV6_RULE_SET_HEADER_FORMAT = "ipv6 access-list %s;";

    /*** Expect #1 as protocol and #2 as name for rule set */
    protected static final String MAC_RULE_SET_HEADER_FORMAT = "mac access-list %s;";

    /*** Expect #1 as protocol and #2 as name for rule set */
    protected static final String UDA_RULE_SET_HEADER_FORMAT = "uda access-list %s;";

    /*** Expect #1 as policy name #2 is permit and #3 as sequence **/
    protected static final String POLICY_HEADER_FORMAT = "route-map %s %s %s;";

    /*** Expect #1 as flow name **/
    protected static final String FLOW_NAME_FORMAT = "rule-name %s ;";

    /*** Expect #1 as flow name **/
    protected static final String NO_FLOW_NAME_FORMAT = "no rule-name %s ;";

    /*** Expect #1 as protocol and #2 as rule set name **/
    protected static final String POLICY_RULESET_RECORD_FORMAT = "match %s address %s;";

    /*** Expect #1 as mac rule name **/
    protected static final String POLICY_RULESET_L2ACL_RECORD_FORMAT = "match l2acl %s;";

    /*** Expect #1 as mac rule name **/
    protected static final String POLICY_RULESET_UDAACL_RECORD_FORMAT = "match uda %s;";

    /*** Expect #1 as protocol and #2 as rule set name **/
    protected static final String POLICY_RULESET_REVERT_FORMAT = "no match %s address %s;";

    /*** Expect #1 as mac rule name **/
    protected static final String POLICY_RULESET_L2ACL_REVERT_FORMAT = "no match l2acl %s;";

    /*** Expect #1 as mac rule name **/
    protected static final String POLICY_RULESET_UDAACL_REVERT_FORMAT = "no match uda %s;";

    /*** Expect #1 as vlan id **/
    protected static final String POLICY_VLAN_RECORD_FORMAT = "set next-hop-flood-vlan %s;";

    protected static final String SET_TVF_DOMAIN_FORMAT = "set next-hop-tvf-domain %s;";

    protected static final String SET_TVF_DOMAIN_FORMAT_WITH_PRECEDENCE = "precedence %s set next-hop-tvf-domain %s;";

    protected static final String POLICY_VLAN_MAC_RECORD_FORMAT = "set next-hop-flood-vlan %s outgoing-da %s;";

    protected static final String SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT = "set next-hop-flood-vlan %s replace-vlan %s;";

    protected static final String SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT = "set next-hop-tvf-domain %s replace-vlan %s;";

    protected static final String SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT_WITH_PRECEDENCE = "precedence %s set next-hop-tvf-domain %s replace-vlan %s;";

    protected static final String POLICY_MPLS_TUNNEL_RECORD_FORMAT = "set next-hop-lsp \"%s\";";

    protected static final String POLICY_GRE_TUNNEL_RECORD_FORMAT = "set next-hop-ip-tunnel %s;";

    protected static final String POLICY_MPLS_TUNNEL_REVERT_FORMAT = "no set next-hop-lsp \"%s\";";

    protected static final String POLICY_GRE_TUNNEL_REVERT_FORMAT = "no set next-hop-ip-tunnel %s;";

    /*** Expect #1 as vlan id **/
    protected static final String POLICY_VLAN_MAC_REVERT_FORMAT = "no set next-hop-flood-vlan %s outgoing-da %s;";

    protected static final String REVERT_FLOOD_VLAN_REPLACE_VLAN_FORMAT = "no set next-hop-flood-vlan %s replace-vlan %s;";

    protected static final String REVERT_TVF_DOMAIN_REPLACE_VLAN_FORMAT = "no set next-hop-tvf-domain %s replace-vlan %s;";

    protected static final String POLICY_VLAN_REVERT_FORMAT = "no set next-hop-flood-vlan %s;";

    protected static final String POLICY_TVF_REVERT_FORMAT = "no set next-hop-tvf-domain %s;";

    protected static final String POLICY_VLAN_RECORD_FORMAT_TAIL = "set interface null0;exit;";

    protected static final String SET_INTERFACE_NULL0 = "set interface null0;";

    protected static final String POLICY_INT_FIND_FORMAT = ";set interface null0;";

    protected static final String POLICY_ROUTE_MAP_SET_FORMAT = "set";

    protected static final String POLICY_INT_REVERT_FORMAT = "no set interface null0;";

    protected static final String REVERT_RULE_FORMAT = "no %s";

    /***********************************************************************************
     * Commands to create VLan and mapping Egress port and lag to it
     **********************************************************************************/
    /*** Expect #1 as vlan id **/
    protected static final String POLICYSET_EGRESS_RECORD_TAG_FORMAT = "tagged ethe %s;";

    protected static final String POLICYSET_EGRESS_RECORD_UNTAG_FORMAT = "untagged ethe %s;";

    /*** Trailer record **/
    protected static final String POLICYSET_EGRESS_RECORD_TAILOR_FORMAT = "transparent-hw-flooding;exit;";

    protected static final String POLICYSET_EGRESS_RECORD_TAILOR_FORMAT_FOR_LAG = "transparent-hw-flooding lag-load-balancing;exit;";

    protected static final String POLICYSET_EGRESS_REVERT_TAILOR_FORMAT_FOR_LAG = "no transparent-hw-flooding lag-load-balancing;";

    private static final String SEQUENCE = "sequence";

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_CREATE);
    }

    /**
     * This method builds policy COMMIT commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Policy policyToSave = (Policy) getParentObject(job);
        String command = buildCommand(policyToSave);
        command = START_CONFIG_TERMINAL.concat(command.replace(START_CONFIG_TERMINAL, "").replace(END, "")).concat(END);
        log.info("Stablenet command generated from Job Id{} on devvice{} for policy id {} is {}", job.getId(), job.getDevice().getId(), policyToSave.getId(), command);
        return command;
    }

    /**
     * if preserve header flag is true,
     * 1. Collect all the out ports from existing committed policies, whose preserve header flag is enabled
     * 2. Collect all the out ports from existing saved policies for which is active on the device, whose preserve header flag is enabled
     * 3. Collect all the out ports from current policy
     * 4. Get the diff of out ports collected in step 3 which are not present in step 1 & 2
     * 5. Construct the untag ports commands for ports from the diff from step 4 and bind it to reserved VLAN.
     **/
    protected String buildReservedVlanCommand(Policy policy, int reservedVlanId) {
        Set<String> outPortsOfActivePolicies = Sets.newHashSet();
        Set<String> outPortsOfCurrentPolicy = Sets.newHashSet();
        // Step 1 - Collect all the out ports from existing committed policies, whose preserve header flag is enabled
        outPortsOfActivePolicies.addAll(getEgressPortsOfActivePolicies(policy.getDevice()));
        // Step 2 - Collect all the out ports from existing saved policies for which is active on the device, whose preserve header flag is enabled
        outPortsOfActivePolicies.addAll(getEgressPortsOfSavedOverActivePolicies(policy.getDevice()));
        // Step 3 - Collect all the out ports from current policy
        outPortsOfCurrentPolicy.addAll(getEgressPortsFromPolicy(policy));
        // Step 4 - Get the diff of out ports collected in step 3 which are not present in step 1 & 2
        Sets.SetView<String> outPortsToUnTagInReservedVlan = Sets.difference(outPortsOfCurrentPolicy, outPortsOfActivePolicies);
        // Step 5
        StringBuilder reservedVlanCommand = new StringBuilder();
        if (outPortsToUnTagInReservedVlan != null && !outPortsToUnTagInReservedVlan.isEmpty()) {
            reservedVlanCommand.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlanId));
            // untag port
            outPortsToUnTagInReservedVlan.forEach(port -> {
                reservedVlanCommand.append(String.format(UNTAG_PORT, port));
            });

            reservedVlanCommand.append(EXIT);

        }
        return reservedVlanCommand.toString();
    }

    protected String buildVlanCommand(Map<String, Set<String>> vlanMap) {
        StringBuilder command = new StringBuilder();
        vlanMap.forEach((vlan, portCommands) -> {
            if (!portCommands.isEmpty()) {
                command.append(String.format(POLICYSET_EGRESS_RECORD_HEADER_FORMAT, vlan));
                int portGroupCount = 0;
                if (vlan != null) {
                    for (String portCommand : portCommands) {
                        if (portCommand.indexOf("pg") > -1) {
                            portGroupCount++;
                        }
                        command.append(portCommand.replaceAll(" pg", "") + ";");
                    }
                    if (portGroupCount > 0) {
                        command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT_FOR_LAG);
                    } else {
                        command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT);
                    }
                }
            }
        });
        return command.toString();
    }

    /**
     * Construct tvf domain port binding command
     *
     * @param tvfDomainEgressMap
     * @return
     */
    protected String buildTvfDomainCommand(Map<String, Set<String>> tvfDomainEgressMap) {
        StringBuilder command = new StringBuilder();
        tvfDomainEgressMap.forEach((tvfDomainId, portCommands) -> {
            command.append(String.format(TVF_DOMAIN_HEADER_FORMAT, tvfDomainId));
            int portGroupCount = 0;
            for (String portCommand : portCommands) {
                if (portCommand.indexOf("pg") > -1) {
                    portGroupCount++;
                }
                command.append(portCommand.replaceAll(" pg", ""));
            }
            command.append(EXIT);
        });
        return command.toString();
    }

    private void buildVlanEgressMap(Flow flow, Map<String, Set<String>> vlanMap) {
        for (String vlan : flow.getVlans()) {
            Set<String> portCommand = vlanMap.get(vlan);
            if (portCommand == null) {
                portCommand = new HashSet<>();
            }
            String isTagged = flow.getIsTagged() ? "tagged" : "untagged";
            Set<Port> egressPorts = flow.getEgressPorts();
            if (egressPorts != null) {
                for (Port egress : egressPorts) {
                    List<Long> flowIds = flowRepository.findByVlanAndEgressPortsAndTaggedNotInCurrentPolicy(flow.getPolicy().getDevice().getId(), flow.getPolicy().getId(), vlan, Sets.newHashSet(egress.getId()), flow.getIsTagged());
                    if (flowIds.isEmpty()) {
                        portCommand.add(isTagged + " ethe " + egress.getPortNumber());
                    }
                }
            }
            Set<PortGroup> portGroups = flow.getEgressPortGroups();
            if (portGroups != null && !portGroups.isEmpty()) {
                // Iterating for lags
                for (PortGroup portGroup : portGroups) {
                    List<Long> flowIds = flowRepository.findByVlanAndEgressPortsAndTaggedNotInCurrentPolicy(flow.getPolicy().getDevice().getId(), flow.getPolicy().getId(), vlan, Sets.newHashSet(portGroup.getId()), flow.getIsTagged());
                    if (flowIds.isEmpty()) {
                        portCommand.add(isTagged + " ethe " + portGroup.getPrimaryPort().getPortNumber() + " pg");
                    }
                }
            }
            vlanMap.put(vlan, portCommand);
        }
    }

    private void buildTvfDomainEgressMap(Flow flow, Map<String, Set<String>> tvfDomainEgressMap) {
        for (String tvfDomainId : flow.getVlans()) {
            Set<String> portCommand = tvfDomainEgressMap.get(tvfDomainId);
            if (portCommand == null) {
                portCommand = new HashSet<>();
            }
            Set<Port> egressPorts = flow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> {
                List<String> tvfDomainIds = Arrays.asList(flowEgressManagedObject.getTvfDomainId().split(","));
                return flowEgressManagedObject.getTvfDomainId() != null && tvfDomainIds.contains(tvfDomainId);
            })
                    .map(flowEgressManagedObject -> (Port) flowEgressManagedObject.getManagedObject()).collect(Collectors.toSet());
            if (egressPorts != null) {
                for (Port egress : egressPorts) {
                    List<Long> flowIds = flowRepository.findByTvfDomainAndEgressPortsAndNotInCurrentPolicy(flow.getPolicy().getDevice().getId(), flow.getPolicy().getId(), tvfDomainId, Sets.newHashSet(egress.getId()));
                    if (flowIds.isEmpty()) {
                        portCommand.add(String.format(BIND_PORT, egress.getPortNumber()));
                    }
                }
            }
            Set<PortGroup> portGroups = flow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> {
                List<String> tvfDomainIds = Arrays.asList(flowEgressManagedObject.getTvfDomainId().split(","));
                return flowEgressManagedObject.getTvfDomainId() != null && tvfDomainIds.contains(tvfDomainId);
            })
                    .map(flowEgressManagedObject -> (PortGroup) flowEgressManagedObject.getManagedObject()).collect(Collectors.toSet());
            if (portGroups != null && !portGroups.isEmpty()) {
                // Iterating for lags
                for (PortGroup portGroup : portGroups) {
                    List<Long> flowIds = flowRepository.findByTvfDomainAndEgressPortsAndNotInCurrentPolicy(flow.getPolicy().getDevice().getId(), flow.getPolicy().getId(), tvfDomainId, Sets.newHashSet(portGroup.getId()));
                    if (flowIds.isEmpty()) {
                        portCommand.add(String.format(BIND_PORT, portGroup.getPrimaryPort().getPortNumber()) + " pg");
                    }
                }
            }
            tvfDomainEgressMap.put(tvfDomainId, portCommand);
        }
    }

    private String buildCommand(Policy policyToApply) {
        policyToApply = BeanUtil.removeDuplicates(policyToApply);
        StringBuilder command = new StringBuilder();
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> servicePorts = new HashSet<>();
        Set<PortGroup> portGroups = new HashSet<>();
        final Set<RuleSet.Type> ruleSetTypeList = Sets.newHashSet();
        final Set<RuleSet.IpVersion> ruleSetIpList = Sets.newHashSet();
        int reservedVlanId = 0;
        String reservedVlanCommand = "";
        // if preserve header flag is true

        HeaderStrippingModulePolicy headerStrippingModulePolicy = null;
        if (policyToApply.isPreserveHeader()) {
            headerStrippingModulePolicy = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(policyToApply.getDevice().getId()).stream().findFirst().get();
            if (headerStrippingModulePolicy != null) {
                reservedVlanId = headerStrippingModulePolicy.getReplaceVlan();
            } else {
                log.error("Replace VLAN Id is not configured for this device: {}, {}", policyToApply.getDevice().getId(), policyToApply.getDevice().getName());
            }
            // Construct the bind egress ports to reserved vlan command
            reservedVlanCommand = buildReservedVlanCommand(policyToApply, reservedVlanId);
        }

        command.append(START_CONFIG_TERMINAL);
        Map<String, Set<String>> vlanMap = new HashMap<>();
        Map<String, Set<String>> tvfDomainEgressMap = new HashMap<>();
        List<String> uniqueListOfRulesetNameToUpdateRules = new ArrayList<>();
        for (Flow eachFlow : policyToApply.getFlows()) {
            ruleSetTypeList.addAll(eachFlow.getRuleSets().stream().map(RuleSet::getType).collect(Collectors.toSet()));
            ruleSetIpList.addAll(eachFlow.getRuleSets().stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));
            // creating ruleSet and policy
            command.append(buildFlowCommand(eachFlow, policyToApply.getComputedName(), policyToApply.isPreserveHeader(), reservedVlanId, uniqueListOfRulesetNameToUpdateRules));
            if (eachFlow.getTvfDomain()) {
                buildTvfDomainEgressMap(eachFlow, tvfDomainEgressMap);
            } else {
                buildVlanEgressMap(eachFlow, vlanMap);
            }
            //collect all ingress ports
            ingressPorts.addAll(eachFlow.getIngressPorts().stream().collect(Collectors.toSet()));
            ingressPorts.addAll(eachFlow.getIngressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
            // Collect only the Service Ports
            servicePorts.addAll(eachFlow.getIngressPorts().stream().filter(port -> port.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet()));
            portGroups.addAll(eachFlow.getIngressPortGroups());
        }
        // Setting rules and route map
        command.append(String.format(END_ROUTE_MAP, policyToApply.getComputedName()));

        command.append(buildVlanCommand(vlanMap));
        command.append(buildTvfDomainCommand(tvfDomainEgressMap));
        command.append(reservedVlanCommand);

        String policyName = policyToApply.getComputedName();
        final Policy policy = policyToApply;

        // Mapping ingress ports to GTP profile
        GTPDevicePolicy gtpProfile = policy.getGtpProfile();
        if (gtpProfile != null) {
            StringBuilder portsToMapToGtpProfile = new StringBuilder();
            // To bind service port(s) to the selected GTP Profile in the policy.
            servicePorts.forEach(servicePort -> {
                portsToMapToGtpProfile.append(String.format(POLICYSET_GTP_INGRESS_MAP_FORMAT, servicePort.getPortNumber()));
            });
            // To bind primary port of port group to the selected GTP Profile in the policy, only if port group is not associated with GTP Profile.
            portGroups.forEach(portGroup -> {
                if (portGroup.getGtpProfile() == null) {
                    portsToMapToGtpProfile.append(String.format(POLICYSET_GTP_INGRESS_MAP_FORMAT, portGroup.getPrimaryPort().getPortNumber()));
                }
            });
            if (portsToMapToGtpProfile.length() > 0) {
                command.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
                command.append(portsToMapToGtpProfile);
                command.append(EXIT);
            }
        }

        if (policyToApply.isPreserveHeader()) {
            command.append(String.format(POLICYSET_INGRESS_RECORD_FORMAT, getIntermediatePortNumber(headerStrippingModulePolicy.getIntermediatePortId()), getACLFormatForPolicy(policyName, Sets.newHashSet(), ruleSetIpList, policy, true)));
            if (headerStrippingModulePolicy != null && headerStrippingModulePolicy.getStripHeaders() != null && !headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
                policyName = getRmOrL2AclName(headerStrippingModulePolicy.getStripHeaders().stream().findFirst().get());
            }
            ruleSetIpList.clear();
            ruleSetTypeList.clear();
            ruleSetTypeList.add(RuleSet.Type.L2);
        }

        for (Port ingress : ingressPorts) {
            command.append(String.format(POLICYSET_INGRESS_RECORD_FORMAT, ingress.getPortNumber(), getACLFormatForPolicy(policyName, ruleSetTypeList, ruleSetIpList, policy, policy.isLoopbackEnabled())));
        }

        command.append(WRITE_MEMORY);
        command.append(END);
        return command.toString();
    }

    protected String buildFlowCommand(Flow flow, String name, boolean isPreserveHeader, int reservedVlanId, List<String> uniqueListOfRulesetNameToUpdateRules) {
        StringBuilder command = new StringBuilder();
        Policy policy = flow.getPolicy();
        Long deviceId = policy.getDevice().getId();
        if (flow != null && name != null && !name.isEmpty()) {
            // Creating ruleSet command 1st hand
            flow.getRuleSets().forEach(ruleSet -> {
                command.append(buildRuleSetCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameToUpdateRules, Type.POLICY_CREATE, policy.isLegacy()));
            });
            // Creating policy header
            command.append(String.format(POLICY_HEADER_FORMAT, name, CMD_PERMIT, flow.getSequence()));
            // Creating policy flow-name
            if (!Strings.isNullOrEmpty(flow.getFlowName()))
                command.append(String.format(FLOW_NAME_FORMAT, flow.getFlowName()));
            // Adding ruleSet to policy
            for (RuleSet ruleSet : flow.getRuleSets()) {
                if (ruleSet.getType() == RuleSet.Type.L2) {
                    command.append(String.format(POLICY_RULESET_L2ACL_RECORD_FORMAT, ruleSet.getName()));
                } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                    command.append(String.format(POLICY_RULESET_UDAACL_RECORD_FORMAT, ruleSet.getName()));
                } else {
                    command.append(String.format(POLICY_RULESET_RECORD_FORMAT, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                }
            }

            flow.getTunnelPolicies().forEach(tunnelDevicePolicy -> command.append(String.format((tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) ? POLICY_MPLS_TUNNEL_RECORD_FORMAT : POLICY_GRE_TUNNEL_RECORD_FORMAT, tunnelDevicePolicy.getName())));
            // final int tempReservedVlanId = reservedVlanId;
            String destinationMac = flow.getDestinationMacTag();
            flow.getVlans().forEach(vlan -> {
                if (destinationMac != null && !destinationMac.isEmpty()) {
                    command.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destinationMac));
                } else if (isPreserveHeader && reservedVlanId > 0) {
                    if (flow.getTvfDomain()) {
                        if (flow.getTvfDomain()) {
                            Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flow.getFlowEgressPorts().stream()
                                    .filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == vlan).findAny();
                            if (!optionalFlowEgressManagedObject.isPresent()) {
                                optionalFlowEgressManagedObject = flow.getFlowEgressPortGroups().stream()
                                        .filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == vlan).findAny();
                            }
                            if (optionalFlowEgressManagedObject.isPresent() && optionalFlowEgressManagedObject.get() != null) {
                                command.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT_WITH_PRECEDENCE, optionalFlowEgressManagedObject.get().getPrecedence(), vlan, reservedVlanId));
                            } else {
                                command.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, vlan, reservedVlanId));
                            }
                        } else {
                            command.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                        }
                    } else {
                        command.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlanId));
                    }
                } else {
                    if (flow.getTvfDomain()) {
                        Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = flow.getFlowEgressPorts().stream()
                                .filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == vlan).findAny();
                        if (!optionalFlowEgressManagedObject.isPresent()) {
                            optionalFlowEgressManagedObject = flow.getFlowEgressPortGroups().stream()
                                    .filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == vlan).findAny();
                        }
                        if (optionalFlowEgressManagedObject.isPresent() && optionalFlowEgressManagedObject.get() != null) {
                            command.append(String.format(SET_TVF_DOMAIN_FORMAT_WITH_PRECEDENCE, optionalFlowEgressManagedObject.get().getPrecedence(), vlan));
                        } else {
                            command.append(String.format(SET_TVF_DOMAIN_FORMAT, vlan));
                        }
                    } else {
                        command.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                    }
                }
            });
            command.append(POLICY_VLAN_RECORD_FORMAT_TAIL);
        }
        return command.toString();
    }

    /**
     * This method builds access-list commands to be applied on the device
     *
     * @param ruleSet
     * @param deviceId
     * @param policyId
     * @param uniqueListOfRulesetNameTobeAdded
     * @param jobType                          //This method is called from different context create is for added Ruleset, update is for update ruleset and null when it is fresh policy commit
     * @return
     */
    protected String buildRuleSetCommand(RuleSet ruleSet, Long deviceId, Long policyId, List<String> uniqueListOfRulesetNameTobeAdded, Job.Type jobType, boolean isLegacy) {
        StringBuilder command = new StringBuilder();
        boolean isRulesetFoundInOtherPolicy = !isRuleSetChangesRequired(ruleSet, deviceId, policyId);
        boolean isRulesetFoundInCurrentPolicy = isSameRulesetNameFoundInCurrentPolicy(ruleSet.getName(), policyId, ruleSet.getId());
        boolean isRulesetAlreadyAdded = uniqueListOfRulesetNameTobeAdded.contains(ruleSet.getName());
        boolean isRulesetCommandRequired = !isRulesetFoundInOtherPolicy && !isRulesetAlreadyAdded; //This is for fresh commit case job type will be null for this.
        if (Type.POLICY_UPDATE == jobType) {
            isRulesetCommandRequired = !isRulesetAlreadyAdded; // If it is Ruleset update then irrespective of it being in current or other policy need to update the commands
        } else if (Type.POLICY_CREATE == jobType) {
            isRulesetCommandRequired = !isRulesetFoundInOtherPolicy && !isRulesetFoundInCurrentPolicy && !isRulesetAlreadyAdded;// In Case of Policy update with ruleset to be added
        }
        if (isRulesetCommandRequired) {
            if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                // creating first line for command IPisRuleSetChangesRequired
                command.append(String.format(IPV4_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                // creating first line for command for IPV6
                command.append(String.format(IPV6_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.L2) {
                // creating first line for command for MAC
                command.append(String.format(MAC_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                // creating first line for command for MAC
                command.append(String.format(UDA_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
            }
            // Appending rules
            ruleSet.getRules().forEach(rule -> {
                // Building l2 commands
                if (ruleSet.getType() == RuleSet.Type.L2) {
                    command.append(buildMACRuleCommand(rule, isLegacy));
                } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                    command.append(buildUDARuleCommand(rule, isLegacy));
                } else {
                    command.append(buildRuleCommand(rule, isLegacy));
                }
            });
            command.append(EXIT);
            uniqueListOfRulesetNameTobeAdded.add(ruleSet.getName());
        } else if (!isRulesetCommandRequired && Type.POLICY_CREATE == jobType) {
            command.append(buildRuleSetCommandForExistingRulesetInDifferentPolicy(ruleSet, deviceId, policyId, isLegacy));
            uniqueListOfRulesetNameTobeAdded.add(ruleSet.getName());
        }

        return command.toString();
    }

    /**
     * This method builds commands to create MAC rule on the device
     *
     * @param rule
     * @return String This returns command string
     */
    protected String buildMACRuleCommand(Rule rule, boolean isLegacyPolicy) {
        if (rule != null && rule.getCustomAcl() != null) {
            log.debug("Working on custom mac rule [" + rule.getCustomAcl() + "]");
            log.info("using custom mac rule as is.");
            return rule.getCustomAcl().endsWith(";") ? rule.getCustomAcl() : rule.getCustomAcl() + ";";
        }
        StringBuilder command = new StringBuilder();
        if (!isLegacyPolicy) {
            command.append(SEQUENCE + SPACE + rule.getSequence() + SPACE);
        }
        /* Section 1 (permit/deny) */
        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);
        // Section 2 Source (any/mac) (mask)
        if (rule.getSourceMac() != null && rule.getSourceMac().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getSourceMac() != null && rule.getSourceMacMask() != null
                && !rule.getSourceMacMask().trim().isEmpty()) {
            command.append(rule.getSourceMac()).append(SPACE).append(rule.getSourceMacMask()).append(SPACE);
        } else if (rule.getSourceMac() != null && (rule.getSourceMacMask() == null
                || (rule.getSourceMacMask() != null && rule.getSourceMacMask().trim().isEmpty()))) {
            command.append(rule.getSourceMac()).append(SPACE).append(MAC_MASK).append(SPACE);
        }
        // Section 3 Destination (any/mac) (mask)
        if (rule.getDestinationMac() != null && rule.getDestinationMac().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getDestinationMac() != null && rule.getDestinationMacMask() != null
                && !rule.getDestinationMacMask().trim().isEmpty()) {
            command.append(rule.getDestinationMac()).append(SPACE).append(rule.getDestinationMacMask()).append(SPACE);
        } else if (rule.getDestinationMac() != null && (rule.getDestinationMacMask() == null
                || (rule.getDestinationMacMask() != null && rule.getDestinationMacMask().trim().isEmpty()))) {
            command.append(rule.getDestinationMac()).append(SPACE).append(MAC_MASK).append(SPACE);
        }
        // Section 4 VLANID (any/vLan id)
        if (rule.getVlanId() > 0) {
            command.append(rule.getVlanId()).append(SPACE);
        } else if (rule.getVlanId() == -1) {
            command.append(CMD_ANY).append(SPACE);
        }
        // Section 5 Ether Type (etype any/etype arp/ipv4/ipv6/...) etype value
        // should be between 1536 and 65535
        if (rule.getEthType() != null && rule.getEthType().equals(CMD_ANY)) {
            command.append(ETHER_TYPE).append(SPACE).append(CMD_ANY);
        } else if (rule.getEthType() != null) {
            command.append(ETHER_TYPE).append(SPACE).append(rule.getEthType());
        }
        command.append(SEMI_COLON);
        return command.toString();
    }

    /**
     * This method builds commands to create L3 rule on the device
     *
     * @param rule
     * @return String This returns command string
     */
    protected String buildRuleCommand(Rule rule, boolean isLegacy) {
        if (rule != null && rule.getCustomAcl() != null) {
            log.debug("Working on custom rule [" + rule.getCustomAcl() + "]");
            log.info("using custom rule as is.");
            return rule.getCustomAcl().endsWith(";") ? rule.getCustomAcl() : rule.getCustomAcl() + ";";
        }
        StringBuilder command = new StringBuilder();
        if (!isLegacy) {
            command.append(SEQUENCE + SPACE + rule.getSequence() + SPACE);
        }
        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);
        if (rule.getVlanId() > 0) {
            command.append(CMD_VLAN + SPACE + rule.getVlanId() + SPACE);
        }
        command.append(rule.getProtocol() + SPACE);

        if (rule.getSourceIp() != null && rule.getSourceIp().equals(CMD_ANY)) {
            command.append(CMD_ANY);
        } else if (rule.getSourceIp() != null && rule.getSourceIp().contains("/")) {
            command.append(rule.getSourceIp());
        } else if (rule.getSourceIp() != null) {
            command.append(CMD_HOST + SPACE + rule.getSourceIp());
        }
        constructPartialRule(rule, PortType.SOURCE, command);
        command.append(SPACE);
        if (rule.getDestinationIp() != null && rule.getDestinationIp().equals(CMD_ANY)) {
            command.append(CMD_ANY);
        } else if (rule.getDestinationIp() != null && rule.getDestinationIp().contains("/")) {
            command.append(rule.getDestinationIp());
        } else if (rule.getDestinationIp() != null) {
            command.append(CMD_HOST + SPACE + rule.getDestinationIp());
        }
        constructPartialRule(rule, PortType.DESTINATION, command);
        if (rule.getMatchPayloadLength() != null && rule.getMatchPayloadLength())
            command.append(MATCH_PAYLOAD_LENGTH);
        command.append(SEMI_COLON);
        return command.toString();
    }

    /**
     * This method builds commands to create UDA rule on the device
     *
     * @param rule
     * @return String This returns command string
     */
    protected String buildUDARuleCommand(Rule rule, boolean isLegacy) {
        StringBuilder command = new StringBuilder();
        if (!isLegacy) {
            command.append(SEQUENCE + SPACE + rule.getSequence() + SPACE);
        }
        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);
        if (rule.getVlanId() > 0) {
            command.append(rule.getVlanId() + SPACE);
        } else if (rule.getVlanId() <= 0) {
            command.append(CMD_ANY + SPACE);
        }

        if (rule.getFieldmask1() != null && rule.getFieldValue1() != null) {
            if ("any".equalsIgnoreCase(rule.getFieldValue1())) {
                command.append(rule.getFieldValue1());
            } else {
                command.append(rule.getFieldValue1() + SPACE + rule.getFieldmask1());
            }
        }

        if (command.length() > 0) {
            command.append(SPACE);
        }

        if (rule.getFieldmask2() != null && rule.getFieldValue2() != null) {
            if ("any".equalsIgnoreCase(rule.getFieldValue2())) {
                command.append(rule.getFieldValue2());
            } else {
                command.append(rule.getFieldValue2() + SPACE + rule.getFieldmask2());
            }
        }

        if (command.length() > 0) {
            command.append(SPACE);
        }

        if (rule.getFieldmask3() != null && rule.getFieldValue3() != null) {
            if ("any".equalsIgnoreCase(rule.getFieldValue3())) {
                command.append(rule.getFieldValue3());
            } else {
                command.append(rule.getFieldValue3() + SPACE + rule.getFieldmask3());
            }
        }

        if (command.length() > 0) {
            command.append(SPACE);
        }

        if (rule.getFieldmask4() != null && rule.getFieldValue4() != null) {
            if ("any".equalsIgnoreCase(rule.getFieldValue4())) {
                command.append(rule.getFieldValue4());
            } else {
                command.append(rule.getFieldValue4() + SPACE + rule.getFieldmask4());
            }
        }
        command.append(SEMI_COLON);
        return command.toString();
    }

    /**
     * This method is used to construct rule base on protocol and port type selected
     *
     * @param rule
     * @param type
     * @param command
     */
    private void constructPartialRule(Rule rule, PortType type, StringBuilder command) {
        if (rule == null || rule.getProtocol() == null) {
            return;
        }
        switch (rule.getProtocol().toLowerCase()) {
            case SCTP:
            case TCP:
            case UDP:
                if (type.equals(PortType.SOURCE) && rule.getSourcePortOperator() != null
                        && portOperators.contains(rule.getSourcePortOperator().toLowerCase())
                        && rule.getSourcePort() > MIN_PORT_NO && rule.getSourcePort() < MAX_PORT_NO) {
                    command.append(SPACE).append(rule.getSourcePortOperator()).append(SPACE).append(rule.getSourcePort());
                }
                if (type.equals(PortType.DESTINATION) && rule.getDestinationPortOperator() != null
                        && portOperators.contains(rule.getDestinationPortOperator().toLowerCase())
                        && rule.getDestinationPort() > MIN_PORT_NO && rule.getDestinationPort() < MAX_PORT_NO) {
                    command.append(SPACE).append(rule.getDestinationPortOperator()).append(SPACE)
                            .append(rule.getDestinationPort());
                }
                break;
            default:
                // log.debug("Unsupported protocol: [{}] for applying port based
                // filters",
                // rule.getProtocol());
                break;
        }
    }

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    protected boolean compare(Rule rule, Rule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null)
            return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null)
            return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null)
            return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;

        if (!rule.getRuleSet().getFlow().getPolicy().isLegacy()) {
            if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
                return false;
        }

        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getMatchPayloadLength() != nRule.getMatchPayloadLength())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }

    /**
     * This method builds ACL command for rule update/delete/create for existing ACL mapped with other policy
     *
     * @param ruleSet
     * @param deviceId
     * @param policyId
     * @return
     */
    private String buildRuleSetCommandForExistingRulesetInDifferentPolicy(RuleSet ruleSet, Long deviceId, Long policyId, boolean isLegacy) {
        StringBuilder createRuleSetCommands = new StringBuilder();
        List<RuleSet> existingRulesets = ruleSetRepository.findByNameAndDeviceIdAndNotInPolicyId(ruleSet.getName(), deviceId, policyId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING));
        if (existingRulesets != null && !existingRulesets.isEmpty()) {
            RuleSet existingRuleset = existingRulesets.get(0);
            if (existingRuleset != null && existingRuleset.getRules() != null) {
                StringBuilder ruleCommands = new StringBuilder();
                List<Long> sequenceList = new ArrayList<>();
                ruleSet.getRules().stream().forEach(rule -> {
                    Long ruleSequence = rule.getSequence();
                    sequenceList.add(ruleSequence);
                    if (ruleSequence != null) {
                        Rule matchingRule = existingRuleset.getRules().stream().filter(rule1 -> ruleSequence.longValue() == rule1.getSequence().longValue()).findFirst().orElse(null);
                        if (matchingRule != null) {
                            //compare the rule if updated
                            if (!compare(rule, matchingRule)) {
                                //Only when updated need to build revert and add command
                                ruleCommands.append(buildRuleRevertAndUpdateCommand(matchingRule, rule, ruleSet, isLegacy));
                            }
                        } else {
                            // Rule is added
                            ruleCommands.append(buildRuleRevertAndUpdateCommand(null, rule, ruleSet, isLegacy));
                        }
                    }
                });
                existingRuleset.getRules().stream().forEach(existingRule -> {
                            if (!sequenceList.contains(existingRule.getSequence())) {
                                ruleCommands.append(buildRuleRevertAndUpdateCommand(existingRule, null, ruleSet, isLegacy));
                            }
                        }
                );
                if (!Strings.isNullOrEmpty(ruleCommands.toString())) {
                    RuleSet.Type type = ruleSet.getType();
                    if (type == RuleSet.Type.UDA) {
                        createRuleSetCommands.append(String.format(UDA_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
                    } else if (type == RuleSet.Type.L2) {
                        createRuleSetCommands.append(String.format(MAC_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
                    } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                        createRuleSetCommands.append(String.format(IPV4_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
                    } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                        createRuleSetCommands.append(String.format(IPV6_RULE_SET_HEADER_FORMAT, ruleSet.getName()));
                    }
                    createRuleSetCommands.append(ruleCommands.toString());
                    createRuleSetCommands.append(EXIT);
                }
            }
        }
        return createRuleSetCommands.toString();
    }

    /**
     * To build rule command for added ruleset which is already mapped with other policy
     *
     * @param matchingRule
     * @param rule
     * @param ruleSet
     * @return
     */
    private String buildRuleRevertAndUpdateCommand(Rule matchingRule, Rule rule, RuleSet ruleSet, boolean isLegacy) {
        StringBuilder command = new StringBuilder();
        if (ruleSet != null) {
            RuleSet.Type type = ruleSet.getType();
            RuleSet.IpVersion ipVersion = ruleSet.getIpVersion();
            if (type != null) {
                //For delete rule command
                if (matchingRule != null) {
                    String ruleCommand = "";
                    if (type == RuleSet.Type.L2) {
                        ruleCommand = buildMACRuleCommand(matchingRule, isLegacy);
                    } else if (type == RuleSet.Type.UDA) {
                        ruleCommand = buildUDARuleCommand(matchingRule, isLegacy);
                    } else {
                        ruleCommand = buildRuleCommand(matchingRule, isLegacy);
                    }
                    command.append(String.format(REVERT_RULE_FORMAT, ruleCommand));
                }
                //For added rule command
                if (rule != null) {
                    String ruleCommand = "";
                    if (type == RuleSet.Type.L2) {
                        ruleCommand = buildMACRuleCommand(rule, isLegacy);
                    } else if (type == RuleSet.Type.UDA) {
                        ruleCommand = buildUDARuleCommand(rule, isLegacy);
                    } else {
                        ruleCommand = buildRuleCommand(rule, isLegacy);
                    }
                    command.append(ruleCommand);
                }
            }
        }
        return command.toString();
    }

}
