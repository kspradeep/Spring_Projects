package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.dao.PacketLabelingModulePolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.PacketLabelingModulePolicy;
import com.brocade.bvm.model.db.history.PacketLabelingModulePolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Named
@Slf4j
public class PacketLabelingModulePolicyUpdateJobExecutor extends AbstractPacketLabelingModulePolicyJobExecutor {
    @Inject
    private PacketLabelingModulePolicyHistoryRepository modulePolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;

    /**
     * This method constructs update PacketLabelingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketLabelingModulePolicy modulePolicy = (PacketLabelingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        if (modulePolicy != null) {
            PacketLabelingModulePolicy oldModulePolicy = getPacketLabelingModulePolicyFromHistory(modulePolicy.getId());

            List<Module> oldModules = (List<Module>) moduleRepository.findAll(oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()));

            Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
            Set<Long> newModuleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());

            //removing packet-labeling from unselected modules during edit
            oldModules.forEach(oldModule -> {
                if (!newModuleIds.contains(oldModule.getId()) || !oldModulePolicy.getProcessor().name().equals(modulePolicy.getProcessor())) {
                    command.append(String.format(MODULE_POLICY_REVERT_SOURCE_PORT_LABELING_FORMAT, oldModule.getModuleNumber(), getProcessor(oldModule.getDevice(), oldModulePolicy)));
                }
            });

            //adding packet-stamping to newly selected modules during edit
            modulePolicy.getModules().forEach(newModule -> {
                if (!oldModuleIds.contains(newModule.getId()) || !oldModulePolicy.getProcessor().name().equals(modulePolicy.getProcessor())) {
                    command.append(String.format(MODULE_POLICY_SOURCE_PORT_LABELING_FORMAT, newModule.getModuleNumber(), getProcessor(newModule.getDevice(), modulePolicy)));
                }
            });
        }
        command.append(WRITE_MEMORY);
        log.debug("PacketLabelingModulePolicyUpdate command = " + command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestModulePolicyId
     * @return PacketLabelingModulePolicy returns latest ACTIVE policy
     */
    private PacketLabelingModulePolicy getPacketLabelingModulePolicyFromHistory(Long latestModulePolicyId) {
        List<PacketLabelingModulePolicyHistory> packetLabelingModulePolicyHistoryList = modulePolicyHistoryRepository.findByIdAndWorkflowStatus(latestModulePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        PacketLabelingModulePolicy modulePolicy = null;
        if (packetLabelingModulePolicyHistoryList.size() >= 1) {
            PacketLabelingModulePolicyHistory packetLabelingModulePolicyHistory = packetLabelingModulePolicyHistoryList.get(0);
            modulePolicy = packetLabelingModulePolicyHistory.buildParent();
        }
        return modulePolicy;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_LABELING_MODULE_POLICY_UPDATE);
    }
}
