/*-
 * UNPUBLISHED SOURCE CODE
 *
 * Copyright � 2013, Brocade Communications Systems, Incorporated.
 * ALL RIGHTS RESERVED.
 *
 * BROCADE HIGHLY CONFIDENTIAL TRADE SECRET INFORMATION
 *
 * Access or possession of this material grants you no right or license,
 * express, implied, statutory or otherwise, under any Brocade patent,
 * copyright, trade secret right or other intellectual property right.
 * Any such license must be contained in a written license agreement
 * signed by an authorized officer of Brocade.  Additionally, access or
 * possession of this material is limited to Brocade employees with a
 * need to know or named employees of Brocade vendors authorized by
 * Brocade in writing to access this material.
 *
 * Restricted Rights: Use, duplication, or disclosure by the U.S.
 * Government is subject to restrictions of FAR 52.227-19 and its
 * successors, or (c)(1)(ii) of the Rights in Technical Data and
 * Computer Software clause at DFAR 252.227-7013 and its successors.
 *
 * Brocade Communications Systems, Inc.,
 * 110 Holger Way, San Jose, CA 95134
 */
package com.brocade.bvm.outbound.firmware.job.util;

/**
 * @author Ila Palanisamy
 * @version 1.0
 */
public class CliConnectorException extends Exception {

    public CliConnectorException(String msg) {
        super(msg);
    }
}
