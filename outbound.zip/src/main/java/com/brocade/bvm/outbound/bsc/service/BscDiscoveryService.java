package com.brocade.bvm.outbound.bsc.service;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.bsc.BscConnection;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Get devices discovered by BSC
 */
@Slf4j
@Named
public class BscDiscoveryService {

    @Inject
    private BscConnection bscConnection;

    @Value("${bsc.resource-url.operational}")
    private String operationUrl;

    @Value("${bsc.resource-url.nodes}")
    private String resourceUrl;

    @Value("${bsc.resource-url.config}")
    private String configUrl;

    @Value("${bsc.resource-url.node}")
    private String nodeUrl;

    /**
     * This method is used to fetch devices details from BSC and populates the details into BVM device objects
     *
     * @return
     */
    public List<Device> getDevices() {
        List<Device> devices = new ArrayList<>();
        Response response = bscConnection.get(operationUrl, resourceUrl);
        String xmlString = response.readEntity(String.class);
        // append <capabilities with name tag to generate proper json obj>
        xmlString = xmlString.replace("<capabilities>", "<capabilities><name>");
        xmlString = xmlString.replace("</capabilities>", "</name></capabilities>");
        // append <max-groups with name tag to generate proper json obj>
        xmlString = xmlString.replace("<max-groups>", "<max-groups><name>");
        xmlString = xmlString.replace("</max-groups>", "</name></max-groups>");
        try {
            JSONObject xmlJSONObj = XML.toJSONObject(xmlString);
            if (xmlJSONObj != null) {
                String removeKey = "xmlns";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:x";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "meter-features";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "switch-features";
                removeJSONField(xmlJSONObj, removeKey);
                JSONArray nodeList = null;
                try {
                    JSONObject nodes = (JSONObject) xmlJSONObj.get("nodes");
                    if (nodes.has("node")) {
                        Object obj = nodes.get("node");
                        if (obj instanceof JSONObject) { // BSC 4.1 does not send controller-config in response, so added a check to find out if controller-config is present for BSE 3.2.1 and below
                            JSONObject realNode = (JSONObject) obj;
                            if (realNode.has("id") && realNode.get("id") != null && !realNode.get("id").toString().equalsIgnoreCase("controller-config")) {
                                nodeList = new JSONArray();
                                nodeList.put(realNode);
                            } else { // ignoring controller config node.
                                return devices;
                            }
                        } else {
                            nodeList = (JSONArray) obj;
                        }
                    }
                } catch (JSONException e) {
                    //Ignore error...can happen when no devices are configured with BSC
                    log.error("Error while parsing BSC response: {}", e.getMessage());
                }
                if (nodeList != null) {
                    int nodes = nodeList.length();
                    for (int nodeCount = 0; nodeCount < nodes; nodeCount++) {
                        JSONObject realNode = nodeList.getJSONObject(nodeCount);
                        // ignoring controller config node.
                        if (realNode.has("id") && realNode.has("ip-address") && realNode.get("id") != null && !realNode.get("id").toString().equalsIgnoreCase("controller-config")) {
                            // adding openflow properties to device and port objects
                            try{
                                Device device = new Device();
                                String ipAddress = getValue(realNode.get("ip-address"));
                                device.setOpenflowId(getValue(realNode.get("id")));
                                device.setIpAddress(ipAddress);
                                Map<String, String> physicalAddressAndFlowIdMap = getPhysicalAddressAndPortOpenFlowIdMap(realNode);
                                Module module = new Module();
                                for (Map.Entry<String, String> entry : physicalAddressAndFlowIdMap.entrySet()) {
                                    Port port = new Port();
                                    port.setPhysicalAddress(entry.getKey());
                                    port.setOpenflowId(entry.getValue());
                                    module.addPorts(Sets.newHashSet(port));
                                }
                                device.addModules(Sets.newHashSet(module));
                                devices.add(device);
                            }catch(Exception ex){
                                log.error("Failed to parse the device response for device {}",realNode.get("ip-address"));
                            }
                        }
                    }
                }
            }
        } catch (JSONException e) {
            throw new OutboundApiException(e);
        }
        return devices;
    }


    /**
     * This method is used to remove unwanted JSON data from XML JSON object
     * @param obj
     * @param id
     * @throws JSONException
     */
    @SuppressWarnings("unchecked")
    private void removeJSONField(JSONObject obj, String id) throws JSONException {
        obj.remove(id);
        Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            String key = it.next();
            Object childObj = obj.get(key);
            if (childObj instanceof JSONArray) {
                JSONArray arrayChildObjs = ((JSONArray) childObj);
                int size = arrayChildObjs.length();
                for (int i = 0; i < size; i++) {
                    removeJSONField(arrayChildObjs.getJSONObject(i), id);
                }
            }
            if (childObj instanceof JSONObject) {
                removeJSONField(((JSONObject) childObj), id);
            }
        }
    }

    /**
     * This method is used to fetch the value for the JSON property
     *
     * @param obj
     * @return
     * @throws JSONException
     */
    private String getValue(Object obj) throws JSONException {
        if (obj instanceof JSONObject) {
            if (((JSONObject) obj).has("content")) {
                return ((JSONObject) obj).get("content").toString();
            } else if (((JSONObject) obj).has("blocked")) { // ODL provides
                // state
                // {{link-down,blocked,live}
                // as boolean
                if (((JSONObject) obj).getBoolean("blocked")) {
                    return "blocked";
                } else {
                    return "unblocked";
                }
            } else {
                return "unknown";
            }
        } else if (obj instanceof String) {
            return (String) obj;
        } else {
            return "unknown";
        }
    }

    /**
     * This method is used to fetch the physical address and openflow id of a port
     *
     * @param realNode
     * @return
     * @throws JSONException
     */
    private HashMap<String, String> getPhysicalAddressAndPortOpenFlowIdMap(JSONObject realNode) throws JSONException {
        HashMap<String, String> physicalAddressAndPortFlowId = new HashMap<>();
        if (realNode.has("node-connector")) {
            Object portList = realNode.get("node-connector");
            if (portList instanceof JSONObject) {
                JSONObject realPort = (JSONObject) portList;
                physicalAddressAndPortFlowId.put(getValue(realPort.get("hardware-address")), getValue(realPort.get("id")));
            } else if (portList instanceof JSONArray) {
                int ports = ((JSONArray) portList).length();
                for (int portCount = 0; portCount < ports; portCount++) {
                    JSONObject realPort = ((JSONArray) portList).getJSONObject(portCount);
                    physicalAddressAndPortFlowId.put(getValue(realPort.get("hardware-address")), getValue(realPort.get("id")));
                }
            }
        }
        return physicalAddressAndPortFlowId;
    }
}