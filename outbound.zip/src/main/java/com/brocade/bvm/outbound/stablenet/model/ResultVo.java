package com.brocade.bvm.outbound.stablenet.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "result")
@Getter
@Setter
@ToString
public class ResultVo {
    @XmlAttribute(name = "info")
    private String info;
    @XmlAttribute(name = "state")
    private String state;
} 
