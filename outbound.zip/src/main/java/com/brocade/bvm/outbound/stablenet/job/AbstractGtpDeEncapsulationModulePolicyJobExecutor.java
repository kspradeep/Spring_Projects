package com.brocade.bvm.outbound.stablenet.job;


public abstract class AbstractGtpDeEncapsulationModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String GTP_DE_ENCAPSULATION = "gtp-de-encapsulation;exit;";

    protected static final String NO_GTP_DE_ENCAPSULATION = "no gtp-de-encapsulation;exit;";

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";
}
