package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Named
public class DeleteSdFilterPolicyJobExecutor extends AbstractSdPolicyJobExecutor {

    protected static final String DELETE_ALL_RULE = "del rule all;";
    protected static final String DELETE_FILTER_POLICY = "del filter-policy=%s;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_FILTER_POLICY_DELETE);
    }

    @Override
    public String getCommands(Job job) {
        List<FilterPolicy> filterPolicies = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof FilterPolicy)
                .map(mo -> (FilterPolicy) mo)
                .collect(Collectors.toList());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(FILTER);
        filterPolicies.forEach(filterPolicy -> {
            command.append(String.format(DELETE_FILTER_POLICY, filterPolicy.getName()));
        });
        command.append(EXIT);
        command.append(EXIT);
        for (FilterPolicy filterPolicy : filterPolicies) {
            deleteFiles(filterPolicy);
        }
        return command.toString();
    }

    /**
     * this methos is used to delete assocated files with FilterPolicy from SD box
     *
     * @param filterPolicy
     */
    private void deleteFiles(FilterPolicy filterPolicy) {
        List<String> files = new ArrayList<>();
        filterPolicy.getRules().forEach(rule -> {
            if (rule.getImsiFileName() != null) {
                files.add(rule.getImsiFileName());
            } else if (rule.getImeiFileName() != null) {
                files.add(rule.getImeiFileName());
            } else if (rule.getApnFileName() != null) {
                files.add(rule.getApnFileName());
            } else if (rule.getSipCallingPartyFileName() != null) {
                files.add(rule.getSipCallingPartyFileName());
            } else if (rule.getSipCalledPartyFileName() != null) {
                files.add(rule.getSipCalledPartyFileName());
            }
        });
        if (!files.isEmpty()) {
            deleteFilesFromSD(filterPolicy.getDevice(), files);
        }
    }
}
