package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dneelapa on 6/28/2016.
 */
public class UDAAclCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String aclName;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "conf t;";
    private static final String SHOW_CMD = "sh access-list uda %s";
    private static final String MATCH_CMD = "entries";
    private static final String ACTION_CMD = "no uda access-list %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, aclName));
        args.add(MATCH_CMD);
        args.add(String.format(ACTION_CMD, aclName));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "UDAAclCommandBlock [deviceId=" + deviceId + ", aclName=" + aclName + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UDAAclCommandBlock)) return false;

        UDAAclCommandBlock that = (UDAAclCommandBlock) o;

        if (getDeviceId() != null ? !getDeviceId().equals(that.getDeviceId()) : that.getDeviceId() != null)
            return false;
        if (getAclName() != null ? !getAclName().equals(that.getAclName()) : that.getAclName() != null) return false;
        return getWriteMem() != null ? getWriteMem().equals(that.getWriteMem()) : that.getWriteMem() == null;

    }

    @Override
    public int hashCode() {
        int result = getDeviceId() != null ? getDeviceId().hashCode() : 0;
        result = 31 * result + (getAclName() != null ? getAclName().hashCode() : 0);
        result = 31 * result + (getWriteMem() != null ? getWriteMem().hashCode() : 0);
        return result;
    }
}
