package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Policy;

import javax.inject.Named;
import java.util.List;

@Named
public class StablenetDeleteExistingPolicyJobExecutor extends StablenetDeletePolicyJobExecutor {

	@Override
	public String getCommands(Job job) {
		Policy policy = (Policy) getParentObject(job);
		//Identify if any untaggale policies exists
		//List<Policy> untaggablePolicies = getUntaggablePolicies(policy);
		String command = null;
		//if (untaggablePolicies.isEmpty()) {
			command = buildCommand(policy);
		/*} else {
			//if no, call build command
			command = buildComplexCommand(policy, untaggablePolicies);
		}*/
		return command;
	}
}
