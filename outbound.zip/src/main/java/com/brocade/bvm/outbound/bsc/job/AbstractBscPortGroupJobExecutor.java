package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.bsc.BscConnection;
import com.brocade.bvm.outbound.bsc.util.BscIdGenerator;
import com.brocade.bvm.outbound.exception.InterfaceMissingException;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.concurrent.TimeUnit;


/**
 * Below are various scenarios where the 404 exception is considered as valid:
 * After attaching the device to the BSC , only the operational data store entry is created , but nothing is created for config data store for the device.
 * In general, from BVM before we execute any REST API in BSC  we query for Operational and Config data stores inorder to
 * a. identify the groups already created on the device.
 * b. identify all the open flow ports present in the device and create a map between BVM port database id and openflow port id.
 * So we ought to get the 404 exception on config data store. The current code suppress this , and continues.
 * But a 404 on a operational data store is not an expected scenario , this indicates that the device got detached. We should stop the execution and put the entity for re-try.
 * Currently we dont support a new state , so the entity (PortGroup/Policy) is put into Error State and we support only recovery operation on it which on invocation clears the PortGroup/Policy on device and re-submits freshly.
 */
@Named
@Slf4j
public abstract class AbstractBscPortGroupJobExecutor extends BaseOutboundJobExecutor {

    @Value("${bsc.resource-url.config}")
    protected String configUrl;

    @Value("${bsc.resource-url.nodes}")
    protected String resourceNodesUrl;

    @Value("${bsc.resource-url.node}")
    protected String resourceNodeUrl;

    protected String resourceUrl = resourceNodesUrl + resourceNodeUrl;

    @Value("${bsc.resource-url.group}")
    protected String groupUrl;

    @Value("${bsc.resource-url.operational}")
    protected String operationUrl;

    @Value("${validation.retry-count:20}")
    private int retryCount;

    @Value("${validation.wait.seconds:5}")
    private long retrySleepSeconds;

    @Inject
    protected BscIdGenerator bscIdGenerator;

    @Inject
    protected BscConnection bscConnection;

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE, Device.Type.ICX, Device.Type.SLX);
    }

    @Override
    public Long startExternalJob(Job job) {
        return null;
    }

    /**
     * This method used to build portGroup xml
     *
     * @param id
     * @param name
     * @param type
     * @param portIds
     * @return String This returns portGroup xml as a String
     */
    protected String buildPortGroup(String id, String name, String type, List<String> portIds) {

        StringBuilder resultXml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        resultXml.append("<group xmlns=\"urn:opendaylight:flow:inventory\">");
        resultXml.append("<group-type>");
        resultXml.append(type);
        resultXml.append("</group-type>");
        resultXml.append("<buckets>");

        int i = 1;
        for (String portid : portIds) {

            resultXml.append("<bucket>");
            resultXml.append("<weight>1</weight>");
            resultXml.append("<action>");
            resultXml.append("<output-action>");
            resultXml.append("<output-node-connector>");
            resultXml.append(portid);
            resultXml.append("</output-node-connector>");
            resultXml.append("</output-action>");
            resultXml.append("<order>1</order>");
            resultXml.append("</action>");
            resultXml.append("<bucket-id>");
            resultXml.append(Integer.toString(i));
            resultXml.append("</bucket-id>");
            resultXml.append("</bucket>");
            i++;
        }

        resultXml.append("</buckets>");
        resultXml.append("<barrier>false</barrier>");
        resultXml.append("<group-name>");
        resultXml.append(name);
        resultXml.append("</group-name>");
        resultXml.append("<group-id>");
        resultXml.append(id);
        resultXml.append("</group-id>");
        resultXml.append("</group>");

        return resultXml.toString();
    }

    /**
     * This method used to create portGroup on Open Flow device
     *
     * @param deviceId
     * @param groupId
     * @param groupData
     * @return boolean This returns true/false based on portGroup creation success/failure status
     */
    protected boolean addGroupOnDevice(String deviceId, String groupId, String groupData, List<String> portIds, Device.Type type) {
        try {
            log.info("Group Entity : " + groupData);
            Response res = bscConnection.put(Entity.entity(groupData, org.springframework.http.MediaType.APPLICATION_XML_VALUE), configUrl, resourceNodesUrl + resourceNodeUrl, deviceId, groupUrl, groupId);
            log.info("response :{} ", res);
            if (res != null && (res.getStatus() == 200 || res.getStatus() == 201)) {
                for (int i = 0; i < retryCount; i++) {
                    Map<String, List<String>> operationalGroupIds = getOperationalGroupInfo(deviceId);
                    /* Checking if the given portGroup id is present in the operationalGroupIds and selected ports are present in group data from operational URL, to mark portGroup creation as success/failure */
                    if (operationalGroupIds.size() > 0 && operationalGroupIds.containsKey(groupId)) {
                        if (Device.Type.ICX != type) {
                            List<String> operationalPortIds = operationalGroupIds.get(groupId);
                            if (operationalPortIds != null && portIds.size() == operationalPortIds.size() && portIds.containsAll(operationalPortIds)) {
                                return true;
                            }
                        } else {
                            return true;
                        }
                    }
                    try {
                        TimeUnit.SECONDS.sleep(retrySleepSeconds);
                    } catch (InterruptedException e1) {
                        throw new ServerException(e1);
                    }
                }
                return false;
            } else {
                return false;
            }
        } catch (Exception e) {
            log.error("Error when creating group on device with xml {}", groupData, e);
            throw new OutboundApiException(e.getMessage());
        }
    }

    /**
     * This method used to delete portGroup on Open Flow device
     *
     * @param deviceId
     * @param groupId
     * @return boolean This returns true/false based on portGroup deletion success/failure status
     */
    protected boolean deleteGroupOnDevice(String deviceId, String groupId) {
        try {
            Response res = bscConnection.delete(configUrl, resourceNodesUrl + resourceNodeUrl, deviceId, groupUrl, groupId);
            log.info("response : " + res);
            if (res != null && res.getStatus() == 200) {
                bscIdGenerator.removeGroupId(groupId);
                try {
                    TimeUnit.SECONDS.sleep(5);
                } catch (InterruptedException e1) {
                }
                return true;

            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * This method used to get existing group-name to group-id map from the config URL
     *
     * @param deviceId
     * @return Map<String, String> This returns map of group-name to group-id
     */
    protected Map<String, String> getGroupNameIdMap(String deviceId) {
        Map<String, String> groupNameIdMap = new HashMap<>();
        Response res = bscConnection.get(configUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
        log.info("Get Group Name-ID Map : " + res);
        if (res != null && res.getStatus() == 200) {
            String xmlString = res.readEntity(String.class);
            JSONObject xmlJSONObj;
            try {
                xmlJSONObj = XML.toJSONObject(xmlString); // To Optimize
                String removeKey = "xmlns";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:x";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:s";
                removeJSONField(xmlJSONObj, removeKey);
                JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
                if (realNode.has("group")) {
                    Object groupObj = realNode.get("group");
                    if (groupObj instanceof JSONObject) {// single group
                        JSONObject groupNode = (JSONObject) groupObj;
                        if (groupNode.has("group-name") && groupNode.has("group-id")) {
                            groupNameIdMap.put(groupNode.get("group-name").toString(), groupNode.get("group-id").toString());
                        }
                    } else if (groupObj instanceof JSONArray) {
                        JSONArray groupNodes = (JSONArray) groupObj;
                        int size = groupNodes.length();
                        for (int i = 0; i < size; i++) {
                            JSONObject groupNode = groupNodes.getJSONObject(i);
                            if (groupNode.has("group-name") && groupNode.has("group-id")) {
                                groupNameIdMap.put(groupNode.get("group-name").toString(), groupNode.get("group-id").toString());
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                log.error(e.getMessage());
                return null;
            }
        } else if (res != null && res.getStatus() == 404) {
            //TODO: Expected scenario as we are loading the groups from Config datastore.
            log.info("Expected 404 response on the first call of a device");
        } else {
            return null;
        }
        return groupNameIdMap;
    }

    /**
     * This method used fetch the groupIds and associated portIds present in the operational URL
     *
     * @param deviceId
     * @return Map<String, List<String>> This returns map of groupId to ports present in the operational URL
     */
    protected Map<String, List<String>> getOperationalGroupInfo(String deviceId) {
        Map<String, List<String>> groupIdMap = new HashMap<>();
        Response res = bscConnection.get(operationUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
        log.info("Get Group ID List via Operational : " + res);
        if (res != null && res.getStatus() == 200) {
            String xmlString = res.readEntity(String.class);
            xmlString = xmlString.replace("<capabilities>", "<capabilities><name>");
            xmlString = xmlString.replace("</capabilities>", "</name></capabilities>");
            xmlString = xmlString.replace("<max-groups>", "<max-groups><name>");
            xmlString = xmlString.replace("</max-groups>", "</name></max-groups>");
            try {
                JSONObject xmlJSONObj = XML.toJSONObject(xmlString); // To Optimize
                String removeKey = "xmlns";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:x";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:s";
                removeJSONField(xmlJSONObj, removeKey);
                JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
                if (realNode.has("group")) {
                    Object groupObj = realNode.get("group");
                    if (groupObj instanceof JSONObject) {// single group
                        JSONObject groupNode = (JSONObject) groupObj;
                        if (groupNode.has("group-id")) {
                            groupIdMap.put(groupNode.get("group-id").toString(), getOperationalPortInfo(deviceId, groupNode));
                        }
                    } else if (groupObj instanceof JSONArray) {
                        JSONArray groupNodes = (JSONArray) groupObj;
                        int size = groupNodes.length();
                        for (int i = 0; i < size; i++) {
                            JSONObject groupNode = groupNodes.getJSONObject(i);
                            if (groupNode.has("group-id")) {
                                groupIdMap.put(groupNode.get("group-id").toString(), getOperationalPortInfo(deviceId, groupNode));
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                log.error(e.getMessage());
                return null;
            }
        }
        return groupIdMap;
    }

    /**
     * This method fetches member portIds of PortGroup from operational URL
     *
     * @param deviceId
     * @param groupNode
     * @return
     * @throws JSONException
     */
    private List<String> getOperationalPortInfo(String deviceId, JSONObject groupNode) throws JSONException {
        List<String> portIdList = new ArrayList<>();
        if (groupNode.has("buckets")) {
            JSONObject buckets = (JSONObject) groupNode.get("buckets");
            if (buckets.has("bucket")) {
                Object bucketObj = buckets.get("bucket");
                if (bucketObj instanceof JSONObject) {
                    JSONObject bucketNode = (JSONObject) bucketObj;
                    JSONObject actionNode = (JSONObject) bucketNode.get("action");
                    JSONObject outPutActionNode = (JSONObject) actionNode.get("output-action");
                    Integer portId = (Integer) outPutActionNode.get("output-node-connector");
                    portIdList.add(String.valueOf(deviceId + ":" + portId.intValue()));
                } else if (bucketObj instanceof JSONArray) {
                    JSONArray bucketArray = (JSONArray) bucketObj;
                    int size = bucketArray.length();
                    for (int i = 0; i < size; i++) {
                        JSONObject bucketNode = bucketArray.getJSONObject(i);
                        JSONObject actionNode = (JSONObject) bucketNode.get("action");
                        JSONObject outPutActionNode = (JSONObject) actionNode.get("output-action");
                        Integer portId = (Integer) outPutActionNode.get("output-node-connector");
                        portIdList.add(String.valueOf(deviceId + ":" + portId.intValue()));
                    }
                }
            }
        }
        return portIdList;
    }

    /**
     * This method is used to build the portName and Id map from the operational URL
     *
     * @param deviceId
     * @return Map<String, String> This returns map of portName to portId
     */
    protected Map<String, String> getPortNameIdMap(String deviceId) {
        Map<String, String> ports = new HashMap<>();
        try {
            Response res = bscConnection.get(operationUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
            if (res != null && res.getStatus() == 200) {
                ports = getPortMap(res);
            }
        } catch (OutboundConnectionException e) {
            log.error("Failed to get Port Name ID map", e);
            if (e.getMessage().contains("404")) {
                log.info("Received a 404 as this could be the first call on the device:{}", e.getMessage());
                //do nothing
                //FixMe: As we are querying on Operational and got 404 which means Device got detached we should not allow to go further.
            } else {
                throw e;
            }
        }
        return ports;
    }

    /**
     * This method is used to build the portName to portId map from XML response
     *
     * @param response
     * @return HashMap<String, String> This returns map of portName to portId
     */
    private HashMap<String, String> getPortMap(Response response) {
        HashMap<String, String> portNameIdMap = new HashMap<>();
        String xmlString = response.readEntity(String.class);
        xmlString = xmlString.replace("<capabilities>", "<capabilities><name>");
        xmlString = xmlString.replace("</capabilities>", "</name></capabilities>");
        xmlString = xmlString.replace("<max-groups>", "<max-groups><name>");
        xmlString = xmlString.replace("</max-groups>", "</name></max-groups>");
        try {
            JSONObject xmlJSONObj = XML.toJSONObject(xmlString);
            String removeKey = "xmlns";
            removeJSONField(xmlJSONObj, removeKey);
            removeKey = "xmlns:x";
            removeJSONField(xmlJSONObj, removeKey);
            removeKey = "meter-features";
            removeJSONField(xmlJSONObj, removeKey);
            removeKey = "switch-features";
            removeJSONField(xmlJSONObj, removeKey);
            JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
            if (realNode.has("node-connector")) {
                Object portList = realNode.get("node-connector");
                if (portList instanceof JSONObject) {
                    JSONObject realPort = (JSONObject) portList;
                    portNameIdMap.put(getValue(realPort.get("name")).toLowerCase(), getValue(realPort.get("id")));
                } else if (portList instanceof JSONArray) {
                    int ports = ((JSONArray) portList).length();
                    for (int portCount = 0; portCount < ports; portCount++) {
                        JSONObject realPort = ((JSONArray) portList).getJSONObject(portCount); // handle
                        portNameIdMap.put(getValue(realPort.get("name")).toLowerCase(), getValue(realPort.get("id")));
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return portNameIdMap;
    }

    private String getValue(Object obj) throws JSONException {
        if (obj instanceof JSONObject) {
            if (((JSONObject) obj).has("content")) {
                return ((JSONObject) obj).get("content").toString();
            } else if (((JSONObject) obj).has("link-down")) {
                if (((JSONObject) obj).getBoolean("link-down")) {
                    return "Down";
                } else {
                    return "Up";
                }
            } else {
                return "unknown";
            }

        } else if (obj instanceof String) {
            return (String) obj;
        } else {
            return "unknown";
        }
    }

    /**
     * This method is used to remove the given JSON Field from the JSONObject
     *
     * @param obj
     * @param id
     */
    @SuppressWarnings("unchecked")
    protected void removeJSONField(JSONObject obj, String id) throws JSONException {
        obj.remove(id);
        Iterator<String> it = obj.keys();
        while (it.hasNext()) {
            String key = it.next();
            Object childObj = obj.get(key);
            if (childObj instanceof JSONArray) {
                JSONArray arrayChildObjs = ((JSONArray) childObj);
                int size = arrayChildObjs.length();
                for (int i = 0; i < size; i++) {
                    try {
                        removeJSONField(arrayChildObjs.getJSONObject(i), id);
                    } catch (JSONException e) {
                        log.error(arrayChildObjs.toString());
                        e.printStackTrace();
                    }
                }
            }
            if (childObj instanceof JSONObject) {
                try {
                    removeJSONField(((JSONObject) childObj), id);
                } catch (JSONException e) {
                    log.error(childObj.toString());
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * This method is used to check participating column in PortGroup having openflow enabled or not
     * If not it will throw Exception
     *
     * @param portIdNameMap
     * @param ports
     * @throws InterfaceMissingException
     */
    protected void checkIfValidInterface(Map<String, String> portIdNameMap, List<String> ports) throws InterfaceMissingException {
        List<String> nonOpenflowPorts = null;
        for (String port : ports) {
            if (!portIdNameMap.containsKey(port)) {
                nonOpenflowPorts = nonOpenflowPorts == null ? new ArrayList<>() : nonOpenflowPorts;
                log.error("Unable to get the Openflow id for the interface " + port);
                nonOpenflowPorts.add(port);
            }
        }
        if (nonOpenflowPorts != null && nonOpenflowPorts.size() > 0) {
            throw new InterfaceMissingException("Please check if openflow is enabled on interface(s) " + String.join(" / ", nonOpenflowPorts) + "\nNote: If OS upgrade is done please do re-discovery from stablenet.");
        }
    }
}
