package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PacketTruncationRemoveProfileCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Named
public class StablenetPacketTruncationRecoveryJobExecutor extends AbstractSLXPacketTruncationRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_TRUNCATION_ROLLBACK);
    }

    /**
     * This method constructs PacketTruncation recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        PacketTruncationMapping packetTruncationMappingToDelete = (PacketTruncationMapping) getParentObject(job);
        log.debug("PacketTruncationRecovery Job executor for PacketTruncation id {}", packetTruncationMappingToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(packetTruncationMappingToDelete);
        log.debug("Number of command blocks constructed for PacketTruncation id {} is :{}", packetTruncationMappingToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs PacketTruncation recovery command blocks list
     *
     * @param packetTruncationMappingToDelete
     * @return
     */
    private List<CommandBlock> constructCommandBlockList(PacketTruncationMapping packetTruncationMappingToDelete) {
        List<CommandBlock> finalCommandBlocks = new ArrayList<>();
        Integer stablenetDeviceId = packetTruncationMappingToDelete.getDevice().getStablenetId().intValue();
        String profileName = packetTruncationMappingToDelete.getPacketTruncation() != null ? packetTruncationMappingToDelete.getPacketTruncation().getName() : null;
        finalCommandBlocks.add(constructPacketTruncationRemoveProfileCommandBlock(stablenetDeviceId, profileName));
        return finalCommandBlocks;
    }

    /**
     * This method constructs PacketTruncation profile removal CommandBlock
     *
     * @param stablenetDeviceId
     * @param profileName
     * @return
     */
    public PacketTruncationRemoveProfileCommandBlock constructPacketTruncationRemoveProfileCommandBlock(Integer stablenetDeviceId, String profileName) {
        PacketTruncationRemoveProfileCommandBlock packetTruncationRemoveProfileCommandBlock = new PacketTruncationRemoveProfileCommandBlock();
        packetTruncationRemoveProfileCommandBlock.setDeviceId(stablenetDeviceId);
        if (profileName != null) {
            packetTruncationRemoveProfileCommandBlock.setProfileName(profileName);
        }
        return packetTruncationRemoveProfileCommandBlock;
    }
}
