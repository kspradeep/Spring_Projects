package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class SdStatusJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String SD_STATUS = "status sd;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_STATUS);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    /**
     * This method gets the status of Session Director
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        return SD_STATUS;
    }

}
