package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.EgressPortGroupHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.EgressPortGroupHistory;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractSdPortGroupJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private EgressPortGroupHistoryRepository portGroupHistoryRepository;

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String PORT_GROUP = "port-group;";
    protected static final String EXIT = "exit;";
    protected static final String RETURN = "return;";

    protected static final String SET = "set %s;";
    protected static final String CLEAR = "clear %s;";

    protected static final String ADD_PORT_GROUP = "add port-group=%s;";

    protected static final String DELETE_PORT_GROUP = "del port-group=%s;";

    protected static final String EDIT_PORT_GROUP = "edit port-group=%s;";

    protected static final String LOAD_BALANCE = "load-balance=%s";

    protected static final String PORT = "port=%s";

    /**
     * This method builds commands to create PortGroup
     *
     * @param portGroupToSave
     * @return
     */
    protected String buildCreateCommand(SdPortGroup portGroupToSave) {
        StringBuilder command = new StringBuilder();
        command.append(PORT_GROUP);
        command.append(String.format(ADD_PORT_GROUP, portGroupToSave.getName()));
        command.append(setCommand(portGroupToSave));
        command.append(RETURN);
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method build the commands to update PortGroup
     *
     * @param portGroupToUpdate
     * @return
     */
    protected String buildUpdateCommand(SdPortGroup portGroupToUpdate) {
        StringBuilder command = new StringBuilder();
        command.append(PORT_GROUP);
        command.append(String.format(EDIT_PORT_GROUP, portGroupToUpdate.getName()));
        SdPortGroup portGroupFromHistory = getPortGroupFromHistory(portGroupToUpdate.getId());
        if (portGroupFromHistory != null && portGroupFromHistory.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            command.append(mergePortGroup(portGroupFromHistory, portGroupToUpdate));
        } else {
            command.append(setCommand(portGroupToUpdate));
        }
        command.append(RETURN);
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method builds update command by merging and comparing existingPortGroup with updatePortGroup
     *
     * @param existingPortGroup
     * @param updatedPortGroup
     * @return
     */
    private String mergePortGroup(SdPortGroup existingPortGroup, SdPortGroup updatedPortGroup) {
        StringBuilder command = new StringBuilder();

        if (existingPortGroup != null && updatedPortGroup != null) {
            if (!updatedPortGroup.isDefault() && updatedPortGroup.getLoadBalance() != null && existingPortGroup.getLoadBalance() != null &&
                    !(updatedPortGroup.getLoadBalance().getName()).equals((existingPortGroup.getLoadBalance().getName()))) {
                command.append(String.format(CLEAR, String.format(LOAD_BALANCE, existingPortGroup.getLoadBalance().getName())));
                command.append(String.format(SET, String.format(LOAD_BALANCE, updatedPortGroup.getLoadBalance().getName())));
            }

            if (updatedPortGroup.getEgressPorts() != null && !updatedPortGroup.getEgressPorts().isEmpty() &&
                    existingPortGroup.getEgressPorts() != null && !existingPortGroup.getEgressPorts().isEmpty()) {
                List<String> updatedPortNames = updatedPortGroup.getEgressPorts().stream().map(EgressPort::getName).collect(Collectors.toList());
                List<String> existingPortNames = existingPortGroup.getEgressPorts().stream().map(EgressPort::getName).collect(Collectors.toList());

                StringBuilder portsAdded = new StringBuilder();
                StringBuilder portsDeleted = new StringBuilder();
                if (updatedPortNames != null && existingPortNames != null &&
                        !updatedPortNames.isEmpty() && !existingPortNames.isEmpty()) {
                    updatedPortNames.stream().forEach(port -> {
                        if (!existingPortNames.contains(port)) {
                            portsAdded.append(port).append(",");
                        }
                    });
                    existingPortNames.stream().forEach(port -> {
                        if (!updatedPortNames.contains(port)) {
                            portsDeleted.append(port).append(",");
                        }
                    });
                } else if ((updatedPortNames == null || updatedPortNames.isEmpty()) && existingPortNames != null &&
                        !existingPortNames.isEmpty()) {
                    existingPortNames.stream().forEach(port ->
                            portsDeleted.append(port).append(",")
                    );
                } else if ((existingPortNames == null || existingPortNames.isEmpty()) && updatedPortNames != null &&
                        !updatedPortNames.isEmpty()) {
                    updatedPortNames.stream().forEach(port ->
                            portsAdded.append(port).append(",")
                    );
                }
                if (portsAdded != null && !portsAdded.toString().isEmpty()) {
                    command.append(String.format(SET, String.format(PORT, portsAdded)));
                }
                if (portsDeleted != null && !portsDeleted.toString().isEmpty()) {
                    command.append(String.format(CLEAR, String.format(PORT, portsDeleted)));
                }
            }
        }
        return command.toString();
    }


    /**
     * This method build the commands to delete PortGroup
     *
     * @param portGroupToDelete
     * @return
     */
    protected String buildDeleteCommand(SdPortGroup portGroupToDelete) {
        StringBuilder command = new StringBuilder();
        if (!portGroupToDelete.isDefault()) {
            command.append(PORT_GROUP);
            command.append(String.format(DELETE_PORT_GROUP, portGroupToDelete.getName()));
            command.append(EXIT);
        } else {
            command.append(PORT_GROUP);
            command.append(String.format(EDIT_PORT_GROUP, portGroupToDelete.getName()));
            if (portGroupToDelete.getEgressPorts() != null && !portGroupToDelete.getEgressPorts().isEmpty() && portGroupToDelete.getEgressPorts().size() > 1) {
                StringBuilder portString = new StringBuilder();
                portGroupToDelete.getEgressPorts().stream().forEach(port -> {
                    if (!port.isDefault()) {
                        portString.append(port.getName()).append(",");
                    }
                });
                if (!portString.toString().isEmpty()) {
                    command.append(String.format(CLEAR, String.format(PORT, portString)));
                }
            }
            command.append(RETURN);
            command.append(EXIT);
        }
        return command.toString();
    }

    /**
     * This method build the set commands for Egress Port group
     *
     * @param portGroupToUpdate
     * @return
     */
    protected String setCommand(SdPortGroup portGroupToUpdate) {
        StringBuilder command = new StringBuilder();
        if (!portGroupToUpdate.isDefault()) {
            command.append(String.format(SET, String.format(LOAD_BALANCE, portGroupToUpdate.getLoadBalance().getName())));
        }
        if (portGroupToUpdate.getEgressPorts() != null && !portGroupToUpdate.getEgressPorts().isEmpty()) {
            StringBuilder portString = new StringBuilder();
            portGroupToUpdate.getEgressPorts().stream().forEach(port -> {
                if (!port.isDefault()) {
                    portString.append(port.getName()).append(",");
                }
            });
            if (!portString.toString().isEmpty()) {
                command.append(String.format(SET, String.format(PORT, portString)));
            }
        }
        return command.toString();
    }

    /**
     * This method build the clear commands for Egress Port group
     *
     * @param portGroupToUpdate
     * @return
     */
    protected String clearCommand(SdPortGroup portGroupToUpdate) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(SET, String.format(LOAD_BALANCE, SdPortGroup.LoadBalanceAlgorithms.HASH.getName())));
        if (portGroupToUpdate.getEgressPorts() != null && !portGroupToUpdate.getEgressPorts().isEmpty()) {
            StringBuilder portString = new StringBuilder();
            portGroupToUpdate.getEgressPorts().stream().forEach(port -> {
                portString.append(port.getName()).append(",");
            });
            command.append(String.format(CLEAR, String.format(PORT, portString)));
        }
        return command.toString();
    }

    /**
     * This method fetches the ACTIVE PortGroup from history
     *
     * @param portGroupId
     * @return PortGroup This returns PortGroup from history
     */
    protected SdPortGroup getPortGroupFromHistory(Long portGroupId) {
        List<EgressPortGroupHistory> portGroupHistoryList = portGroupHistoryRepository.findByIdAndWorkflowStatus(portGroupId, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        SdPortGroup portGroup = null;
        if (portGroupHistoryList != null && portGroupHistoryList.size() > 0) {
            EgressPortGroupHistory portGroupHistory = portGroupHistoryList.get(0);
            portGroup = portGroupHistory.buildParent();
        }
        return portGroup;
    }
}
