package com.brocade.bvm.outbound.cli;

import com.google.common.collect.ImmutableList;

public class ChangePortNameCommandBlock implements CommandBlock {
	
	@Override
	public ImmutableList<CommandLet> getCommandLets() {
		return ImmutableList.of(
				CommandLet.builder("interface ethernet").needsParam(true).build(), 
				CommandLet.builder("port-name").needsParam(true).build());
	}
}
