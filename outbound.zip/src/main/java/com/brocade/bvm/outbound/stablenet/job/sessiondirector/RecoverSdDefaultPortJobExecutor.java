package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.EgressPortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.EgressPortHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Named
public class RecoverSdDefaultPortJobExecutor extends AbstractSdPortJobExecutor {

    @Inject
    private EgressPortHistoryRepository egressPortHistoryRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_DEFAULT_PORT_ROLLBACK);
    }

    @Override
    public String getCommands(Job job) {
        EgressPort portToRecover = (EgressPort) getParentObject(job);
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        if (portToRecover != null && portToRecover.isDefault()) {
            command.append(PORT);
            EgressPort portFromHistory = getPortHistory(portToRecover.getId(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
            if (portFromHistory == null) {
                portFromHistory = getPortHistoryByRevisionTypes(portToRecover.getId(), Arrays.asList(HistoryObject.RevisionType.CREATED));
            }
            if (portFromHistory != null) {
                command.append(String.format(EDIT_PORT, portFromHistory.getName()));
                StringBuilder vlanStringForClear = new StringBuilder();
                StringBuilder vlanStringForSet = new StringBuilder();
                List<Long> vlanIdsAdded = Lists.newArrayList();
                if (portFromHistory.getVlanMappings() != null && !portFromHistory.getVlanMappings().isEmpty()) {
                    portFromHistory.getVlanMappings().stream().forEach(vlan -> {
                        vlanStringForSet.append(vlan.getVlanId()).append(",");
                        vlanIdsAdded.add(vlan.getVlanId());
                    });
                }
                if (portToRecover.getVlanMappings() != null && !portToRecover.getVlanMappings().isEmpty()) {
                    portToRecover.getVlanMappings().stream().forEach(vlan -> {
                        if (!vlanIdsAdded.contains(vlan.getVlanId())) {
                            vlanStringForClear.append(vlan.getVlanId()).append(",");
                        }
                    });
                }
                if (vlanStringForSet.length() != 0) {
                    command.append(String.format(SET, String.format(VLAN, vlanStringForSet)));
                }
                if (vlanStringForClear.length() != 0) {
                    command.append(String.format(CLEAR, String.format(VLAN, vlanStringForClear)));
                }

                command.append(RETURN);
            }
            command.append(EXIT);
        }
        command.append(EXIT);
        log.info("Stablenet command generated from Job Id {} on device {} for recovering SD default Port, command is {}", job.getId(), job.getDevice().getId(), command);
        return command.toString();
    }

    /**
     * This method fetches the ACTIVE Egress Port from history
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistory(Long portId, List<WorkflowParticipant.WorkflowStatus> workflowStatuses) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndWorkflowStatus(portId, workflowStatuses);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }

    /**
     * This method fetches the ACTIVE Egress Port from history using revision type
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistoryByRevisionTypes(Long portId, List<HistoryObject.RevisionType> revisionTypes) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndRevisionTypes(portId, revisionTypes);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }

}
