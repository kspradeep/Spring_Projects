package com.brocade.bvm.outbound.stablenet.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;

import lombok.Getter;
import lombok.Setter;

public class PortGroupDisablePortCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String port;

    @Getter
    @Setter
    private String writeMem = "false";
    /**
     * <pre>
     * argument #1 is port name
     * int e 1/1
     * </pre>
     */
    private static final String PRE_CMD = "conf t;lag %s;";
    /**
     * <pre>
     * argument #1 is lag name
     * eg: show lag lagname
     * </pre>
     */
    private static final String SHOW_CMD = "show lag %s";
    /**
     * <pre>
     * argument #1 is port name
     * eg: 1/1
     * </pre>
     */
    private static final String MATCH_CMD = "(static Deployed)";
    /**
     * <pre>
     * argument #1 is port name
     * eg: disable ethernet 1/1
     * </pre>
     */
    private static final String ACTION_CMD = "disable ethernet %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, name));
        args.add(String.format(SHOW_CMD, name));
        args.add(String.format(MATCH_CMD, port));
        args.add(String.format(ACTION_CMD, port));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "PortGroupDisablePortCommandBlock [deviceId=" + deviceId + ", name=" + name + ", port=" + port + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
