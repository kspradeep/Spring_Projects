package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.model.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXB;
import java.io.StringReader;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Named
@Slf4j
public abstract class AbstractStablenetMultipleCommandsExecutor extends BaseOutboundJobExecutor {
    @Inject
    private StablenetAdminConnection stablenetConnection;

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String userGroupsUrl;

    @Value("${stablenet.resource-url.jobs.deploy}")
    private String jobDeployUrl;

    @Value("${stablenet.resource-url.jobs.start}")
    private String jobStartUrl;

    @Value("${stablenet.resource-url.jobs.isrunning}")
    private String jobStatusUrl;

    @Value("${stablenet.resource-url.jobs.jobresult}")
    private String jobResultUrl;

    @Value("${stablenet.resource-url.jobs.jobresultlist}")
    private String jobResultListUrl;

    @Value("${stablenet.resource-url.jobs.jobresultdevice}")
    private String jobResultDeviceUrl;

    @Value("${stablenet-response.timeout.minutes}")
    private int timeoutMinutes;

    private List<Map.Entry<Integer, Integer>> sleepTimeouts = Lists.newArrayList();

    @PostConstruct
    public void intilizeExecutorTimeouts() {
        sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(5, 5 * 60 * 1000));//5 secs poll for first 5 mins(5*60*1000 ms)
        if (timeoutMinutes > 5) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(30, 30 * 60 * 1000)); //30 secs poll for the next 30 mins
        }
        if (timeoutMinutes > 30) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(60, timeoutMinutes * 60 * 1000)); //60 secs poll for the rest till timeoutMinutes
        }
    }

    @Inject
    private ConfigRepository configRepository;

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    @Override
    public Long startExternalJob(Job job) {
        return null;
    }

    @Override
    public OutboundJobResponse execute(Job job) {
        //Put request and get stablenet's job id (this is a clone id of parent template job)
        log.debug("Starting Stablenet job for jobId {}", job.getId());
        OutboundJobResponse jobResponse = null;

        UserVO user = null;
        if (!Strings.isNullOrEmpty(job.getCreatedByUser()) && job.getDevice().isAuthenticationConfigured()) {
            user = JAXB.unmarshal(
                    new StringReader(stablenetConnection.get(userGroupsUrl, job.getCreatedByUser()).readEntity(String.class)),
                    UserVO.class);
        }
        CliCapabilityVO cli = new CliCapabilityVO();
        if (user != null && "true".equals(user.getExternalauthentication())) {
            cli.setUser(job.getCreatedByUser() != null
                    ? job.getCreatedByUser() : configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
            cli.setPassword(job.getCreatedByUserPassword() != null
                    ? decryptPassword(job.getCreatedByUserPassword()) : configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue());
        }
        ApplicationConfig applicationConfig  = configRepository.findByKey(ApplicationConfig.Key.StablenetJobId);
        String stablenetPushJobId = null;
        if (applicationConfig != null && applicationConfig.getValue() != null) {
            stablenetPushJobId = applicationConfig.getValue();
        } else {
            log.error("StableNet job ID is not configured!");
            throw new OutboundApiException("StableNet job ID is not configured!");
        }
        List<String> commandSet = getCommands(job);
        for (String commands : commandSet) {
            if (commands != null) {
                Input input = new Input();
                List<String> args = new ArrayList<>();
                args.add(commands.replaceAll(";", "\n"));
                input.setArg(args);

                Devices devices = new Devices();
                devices.setDeviceid(job.getDevice().getStablenetId().toString());
                Deployparameter deployparameter = new Deployparameter();
                deployparameter.setInput(input);
                deployparameter.setDevices(devices);
                deployparameter.setSingletrigger(new SingleTrigger());
                if (user != null && "true".equals(user.getExternalauthentication())) {
                    deployparameter.setCredentialsetting("override");
                    deployparameter.setCli(cli);
                }

                String jobTemplateCloneId = stablenetConnection
                        .put(Entity.entity(deployparameter, MediaType.APPLICATION_XML_TYPE),
                                jobDeployUrl, stablenetPushJobId)
                        .readEntity(ScheduledJobBaseVO.class)
                        .getObid();

                if (Strings.isNullOrEmpty(jobTemplateCloneId) ||
                        !stablenetConnection.get(jobStartUrl, jobTemplateCloneId).readEntity(ResultVo.class)
                                .getState().equalsIgnoreCase(RestResultStateEnum.SUCCESS.value())) {
                    throw new OutboundApiException("Unable to start job");
                }

                log.debug("Executing job for jobId {}", job.getId());
                // Checking status of tmp job in infosim
                boolean isComplete = false;

                int i = 0;
                long startTime = System.currentTimeMillis();
                while (true) {
                    try {
                        Result result = JAXB.unmarshal(new StringReader(stablenetConnection.get(jobStatusUrl, jobTemplateCloneId).readEntity(String.class)), Result.class);
                        isComplete = result != null && result.getInfo().equalsIgnoreCase("not found");
                        if (isComplete) {
                            break;
                        }
                    } catch (OutboundApiException e) {
                        log.debug(e.getMessage());
                    }
                    try {
                        TimeUnit.SECONDS.sleep(sleepTimeouts.get(i).getKey());
                    } catch (InterruptedException e1) {
                        throw new ServerException(e1);
                    }

                    long elapsedTime = System.currentTimeMillis() - startTime;
                    if (elapsedTime >= timeoutMinutes * 60 * 1000) {
                        log.warn("Job timeout! Exhausted the timeout staggered timeout intervals");
                        break;
                    } else if (elapsedTime >= sleepTimeouts.get(i).getValue()) {
                        i++;
                        log.info("Staggering to the next timeout interval:{}", i);
                    }
                }
                log.debug("StableNet Job Id:{} for EVM Job Id:{} is complete: {}  for commandBlock {}", jobTemplateCloneId, job.getId(), isComplete, commands);
                if (!isComplete) {
                    throw new OutboundApiException("Job timed out for jobId: " + job.getId());
                }

                // Getting list of all Available jobs
                //15. get a list of results of all clone jobs of template id
                List<JobResultVO> jobResultList = stablenetConnection.get(jobResultListUrl, stablenetPushJobId).readEntity(new GenericType<List<JobResultVO>>() {
                });
                Optional<JobResultVO> jobResultVO = jobResultList.stream()
                        .filter(jobInput -> String.format("Deployed Object ID: %s", jobTemplateCloneId)
                                .equalsIgnoreCase(jobInput.getLabel()))
                        .findFirst();

                if (!jobResultVO.isPresent()) {
                    throw new OutboundApiException("Unable to find job result for jobId: " + job.getId());
                }

                JobResult jobResult = stablenetConnection.get(jobResultUrl, jobResultVO.get().getObid()).readEntity(JobResult.class);
                if (jobResult != null && jobResult.getJobresultdevices() != null && jobResult.getJobresultdevices().getJobresultdevice() != null
                        && !jobResult.getJobresultdevices().getJobresultdevice().isEmpty()) {
                    Optional<JobResultDeviceVO> first = jobResult.getJobresultdevices().getJobresultdevice().stream().findFirst();

                    if (first.isPresent()) {
                        JobResultDeviceVO jobResultDevice = stablenetConnection.get(jobResultDeviceUrl, first.get().getObid())
                                .readEntity(JobResultDeviceVO.class);

                        String commandStatus = jobResultDevice.getState().toString();
                        if ("SUCCESS".equalsIgnoreCase(commandStatus)) {
                            log.debug("EVM Job Id:{} is successful", job.getId());
                            jobResponse = new OutboundJobResponse(Job.Status.SUCCESS, jobResultDevice.getContent());
                        } else {
                            log.debug("EVM Job Id:{} is failed", job.getId());
                            jobResponse = new OutboundJobResponse(Job.Status.FAILED, jobResultDevice.getContent());
                        }
                    }
                }
            } else {
                log.error("Error occurred in recovery command builder!");
            }
        }
        return jobResponse;

    }

    public abstract List<String> getCommands(Job job);
}

