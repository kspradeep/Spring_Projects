package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.IpPayloadLengthPolicy;

public abstract class AbstractIpPayloadLengthPolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String IPV4 = "IPV4";

    protected static final String IPV6 = "IPV6";

    protected static final String IPV4_IP_PAYLOAD_LENGHT = "ip match-payload-len slot %s %s %s;";

    protected static final String IPV6_IP_PAYLOAD_LENGHT = "ipv6 match-payload-len slot %s %s %s;";

    private static final String DEVICE_ID = "device-id ";

    private static final String RANGE = "range ";

    private static final String SPACE = " ";

    /**
     * This method returns processorNumber value to be applied on the device based on processor number
     *
     * @param payloadLengthPolicy
     * @return String returns processorVal
     */
    protected String getProcessorCommand(IpPayloadLengthPolicy payloadLengthPolicy) {
        String processorVal = payloadLengthPolicy.getProcessor().getProcessorNumber();
        if (IpPayloadLengthPolicy.ProcessorNumber.ALL == payloadLengthPolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = DEVICE_ID + processorVal;
        }
        return processorVal;
    }

    /**
     * This method returns range value to be applied on the device
     *
     * @param payloadLengthPolicy
     * @return String returns rangeCmd
     */
    protected String getRangeCommand(IpPayloadLengthPolicy payloadLengthPolicy) {
        StringBuilder rangeCmd = new StringBuilder();
        rangeCmd.append(RANGE).append(payloadLengthPolicy.getMinRange()).append(SPACE).append(payloadLengthPolicy.getMaxRange());
        return rangeCmd.toString();
    }

}
