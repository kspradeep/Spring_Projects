package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * This class is used for building update command for Sampling Policy
 */
@Slf4j
@Named
public class UpdateSdSamplingPolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    protected static final String SAMPLING = "sampling;";
    protected static final String SAMPLING_POLICY = "sampling-policy=%s;";
    protected static final String SAMPLIE = "sample=%s;";
    protected static final String SAMPLE = "sample;";
    protected static final String DEFFERED = "deferred";
    protected static final String ACTION_DEFFERED = "action=%s;";
    protected static final String ACTION = "action;";
    protected static final String ALGO = "algo=hash;";
    protected static final String CLEAR_ALGO = "clear algo;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SAMPLING_POLICY_UPDATE);
    }

    @Override
    public String getCommands(Job job) {
        SamplingPolicy samplingPolicy = (SamplingPolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(SAMPLING);
        command.append(EDIT).append(String.format(SAMPLING_POLICY, samplingPolicy.getName()));
        SamplingPolicy samplePolicyFromHistory = getSamplingPolicyFromHistory(samplingPolicy.getId());
        command = getUpdateCommand(samplePolicyFromHistory, samplingPolicy, command);
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method is used for building update sampling command based on old object comparison with new one
     *
     * @param oldPolicy
     * @param newPolicy
     * @param command
     * @return
     */
    private StringBuilder getUpdateCommand(SamplingPolicy oldPolicy, SamplingPolicy newPolicy, StringBuilder command) {
        if (newPolicy.getRate() != oldPolicy.getRate()) {
            command.append(CLEAR).append(SAMPLE);
            command.append(SET).append(String.format(SAMPLIE, newPolicy.getRate()));
        }
        if (oldPolicy.isPreserveCplane() && !newPolicy.isPreserveCplane()) {
            command.append(CLEAR).append(PRESERVE_CPLANE);
        } else if (newPolicy.isPreserveCplane() && (oldPolicy.isPreserveCplane() != newPolicy.isPreserveCplane())) {
            command.append(SET).append(PRESERVE_CPLANE);
        }

        if (DEFFERED.equalsIgnoreCase(oldPolicy.getAction()) && !DEFFERED.equalsIgnoreCase(newPolicy.getAction())) {
            command.append(CLEAR).append(ACTION);
        } else if (newPolicy.getAction() != null && newPolicy.getAction() != oldPolicy.getAction()) {
            command.append(SET).append(String.format(ACTION_DEFFERED, newPolicy.getAction()));
        }
        if (!newPolicy.getLoadBalanceAlgo().getName().equals(oldPolicy.getLoadBalanceAlgo().getName())) {
            if (newPolicy.getLoadBalanceAlgo().getName().equals(SamplingPolicy.LoadBalanceAlgorithms.HASH.getName())) {
                command.append(SET).append(ALGO);
            } else {
                command.append(CLEAR_ALGO);
            }

        }
        return command;
    }
}
