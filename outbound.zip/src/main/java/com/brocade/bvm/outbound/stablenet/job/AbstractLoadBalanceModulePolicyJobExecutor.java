package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.LoadBalanceModulePolicy;
import com.brocade.bvm.model.db.Module;

/**
 * The AbstractLoadBalanceModulePolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE of LoadBalanceModulePolicy on Non Open Flow device through Stablenet
 */
public abstract class AbstractLoadBalanceModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    /**
     * Command to enter into configuration mode
     */
    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String GTP = " gtp";

    protected static final String PRE_SYMMETRIC = "%s";

    protected static final String LOAD_BALANCE_MASK_GTP_TEID = "load-balance mask gtp teid %s;";

    protected static final String EMPTY = "";

    protected static final String NO = "no ";

    /* #1 is for no, #2 is for slot number */
    protected static final String LOAD_BALANCE_SYMMETRIC_PACKET = "%sload-balance symmetric packet %s;";

    protected static final String LOAD_BALANCE_SYMMETRIC_IP = "load-balance symmetric ip %s;";

    protected static final String LOAD_BALANCE_SYMMETRIC_IPV6 = "load-balance symmetric ipv6 %s;";

    protected static final String LOAD_BALANCE_SYMMETRIC_L4_IP = "load-balance symmetric l4_ip %s;";

    protected static final String LOAD_BALANCE_SYMMETRIC_L4_IPV6 = "load-balance symmetric l4_ipv6 %s;";

    /********************************************** IPV4 ***************************************************/
    /**
     * <pre>
     * CMD: load-balance mask ip dst-ip slotnumber.
     * 1st parameter is (if inner ip is selected then fill this parameter with protocol as gtp else "").
     * 2nd parameter is slot number.
     * </pre>
     */
    protected static final String LOAD_BALANCE_MASK_IPV4_DST_IP = "load-balance mask%s ip dst-ip %s;";

    protected static final String LOAD_BALANCE_MASK_IPV4_DST_L4_PORT = "load-balance mask%s ip dst-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_IPV4_SOURCE_IP = "load-balance mask%s ip src-ip %s;";

    protected static final String LOAD_BALANCE_MASK_IPV4_SOURCE_L4_PORT = "load-balance mask%s ip src-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_IPV4_PROTOCOL = "load-balance mask%s ip protocol %s;";

    protected static final String LOAD_BALANCE_MASK_GTP_IPV4_DST_IP = "load-balance mask%s ipv4 dst-ip %s;";

    protected static final String LOAD_BALANCE_MASK_GTP_IPV4_DST_L4_PORT = "load-balance mask%s ipv4 dst-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_IP = "load-balance mask%s ipv4 src-ip %s;";

    protected static final String LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_L4_PORT = "load-balance mask%s ipv4 src-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_GTP_IPV4_PROTOCOL = "load-balance mask%s ipv4 protocol %s;";
    /********************************************** IPV4 ***************************************************/

    /********************************************** IPV6 ***************************************************/
    protected static final String LOAD_BALANCE_MASK_IPV6_DST_IP = "load-balance mask%s ipv6 dst-ip %s;";

    protected static final String LOAD_BALANCE_MASK_IPV6_DST_L4_PORT = "load-balance mask%s ipv6 dst-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_IPV6_SOURCE_IP = "load-balance mask%s ipv6 src-ip %s;";

    protected static final String LOAD_BALANCE_MASK_IPV6_SOURCE_L4_PORT = "load-balance mask%s ipv6 src-l4-port %s;";

    protected static final String LOAD_BALANCE_MASK_IPV6_NEXT_HEADER = "load-balance mask%s ipv6 next-hdr %s;";
    /********************************************** IPV6 ***************************************************/

    /**
     * Command to exit from configuration mode
     */
    protected static final String END = "end;";

    protected static final String WRITE_MEMORY = "write memory;";


    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method builds delete commands to be applied on the device
     *
     * @param modulePolicy
     * @param module
     * @return String
     */
    protected String buildDeleteModulePolicyForModule(LoadBalanceModulePolicy modulePolicy, Module module) {

        StringBuilder cmd = new StringBuilder();
        Integer moduleNumber = module.getModuleNumber();
        if (modulePolicy.isBiDirectional()
                && !modulePolicy.isDestinationIpIncluded()
                && !modulePolicy.isDestinationPortIncluded()
                && !modulePolicy.isSourceIpIncluded()
                && !modulePolicy.isSourcePortIncluded()
                && !modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isTeIdIncluded() && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_PACKET, NO, moduleNumber));
        } else {
            /** if inner IP option is selected */
            if (modulePolicy.isInnerIpIncluded()) {
                if (!modulePolicy.isDestinationIpIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_IPV4_DST_IP, GTP, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_DST_IP, GTP, moduleNumber));
                }
                if (!modulePolicy.isDestinationPortIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_IPV4_DST_L4_PORT, GTP, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_DST_L4_PORT, GTP, moduleNumber));
                }
                if (!modulePolicy.isSourceIpIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_IP, GTP, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_SOURCE_IP, GTP, moduleNumber));
                }
                if (!modulePolicy.isSourcePortIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_L4_PORT, GTP, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_SOURCE_L4_PORT, GTP, moduleNumber));
                }
                if (!modulePolicy.isProtocolMaskIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_IPV4_PROTOCOL, GTP, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_NEXT_HEADER, GTP, moduleNumber));
                }
                if (!modulePolicy.isTeIdIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_GTP_TEID, moduleNumber));
                }
            } else {
                String symmetricSlot = (modulePolicy.isBiDirectional()) ? String
                        .format(PRE_SYMMETRIC, moduleNumber) : String
                        .valueOf(moduleNumber);
                if (!modulePolicy.isDestinationIpIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV4_DST_IP, EMPTY, symmetricSlot));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_DST_IP, EMPTY, symmetricSlot));
                }
                if (!modulePolicy.isDestinationPortIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV4_DST_L4_PORT, EMPTY, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_DST_L4_PORT, EMPTY, moduleNumber));
                }
                if (!modulePolicy.isSourceIpIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV4_SOURCE_IP, EMPTY, symmetricSlot));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_SOURCE_IP, EMPTY, symmetricSlot));
                }
                if (!modulePolicy.isSourcePortIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV4_SOURCE_L4_PORT, EMPTY, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_SOURCE_L4_PORT, EMPTY, moduleNumber));
                }
                if (!modulePolicy.isProtocolMaskIncluded()) {
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV4_PROTOCOL, EMPTY, moduleNumber));
                    cmd.append(String.format(NO + LOAD_BALANCE_MASK_IPV6_NEXT_HEADER, EMPTY, moduleNumber));
                }
            }
        }

        if (modulePolicy.isBiDirectional()
                && modulePolicy.isDestinationIpIncluded()
                && modulePolicy.isSourceIpIncluded()
                && !modulePolicy.isDestinationPortIncluded()
                && !modulePolicy.isSourcePortIncluded()
                && !modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_IP, moduleNumber));
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_IPV6, moduleNumber));
        } else if (modulePolicy.isBiDirectional()
                && !modulePolicy.isDestinationIpIncluded()
                && !modulePolicy.isSourceIpIncluded()
                && modulePolicy.isDestinationPortIncluded()
                && modulePolicy.isSourcePortIncluded()
                && modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_L4_IP, moduleNumber));
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_L4_IPV6, moduleNumber));
        } else if (modulePolicy.isBiDirectional()
                && modulePolicy.isDestinationIpIncluded()
                && modulePolicy.isSourceIpIncluded()
                && modulePolicy.isDestinationPortIncluded()
                && modulePolicy.isSourcePortIncluded()
                && modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_IP, moduleNumber));
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_IPV6, moduleNumber));
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_L4_IP, moduleNumber));
            cmd.append(String.format(NO + LOAD_BALANCE_SYMMETRIC_L4_IPV6, moduleNumber));
        }
        return cmd.toString();
    }

    /**
     * This method builds create commands to be applied on the device
     *
     * @param modulePolicy
     * @param module
     * @return String
     */
    protected String buildCreateModulePolicyForModule(LoadBalanceModulePolicy modulePolicy, Module module) {

        StringBuilder cmd = new StringBuilder();
        Integer moduleNumber = module.getModuleNumber();
        if (modulePolicy.isBiDirectional()
                && (!modulePolicy.isDestinationIpIncluded())
                && (!modulePolicy.isDestinationPortIncluded())
                && (!modulePolicy.isSourceIpIncluded())
                && (!modulePolicy.isSourcePortIncluded())
                && (!modulePolicy.isProtocolMaskIncluded())
                && (!modulePolicy.isTeIdIncluded())
                && (!modulePolicy.isInnerIpIncluded())) {
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_PACKET, EMPTY,
                    moduleNumber));
        } else {
            /** if inner IP option is selected */
            if (modulePolicy.isInnerIpIncluded()) {
                if (!modulePolicy.isDestinationIpIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_IPV4_DST_IP, GTP, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_DST_IP, GTP, moduleNumber));
                }
                if (!modulePolicy.isDestinationPortIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_IPV4_DST_L4_PORT, GTP, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_DST_L4_PORT, GTP, moduleNumber));
                }
                if (!modulePolicy.isSourceIpIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_IP, GTP, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_SOURCE_IP, GTP, moduleNumber));
                }
                if (!modulePolicy.isSourcePortIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_IPV4_SOURCE_L4_PORT, GTP, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_SOURCE_L4_PORT, GTP, moduleNumber));
                }
                if (!modulePolicy.isProtocolMaskIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_IPV4_PROTOCOL, GTP, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_NEXT_HEADER, GTP, moduleNumber));
                }
                if (!modulePolicy.isTeIdIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_GTP_TEID, moduleNumber));
                }
            } else {
                String symmetricSlot = (modulePolicy.isBiDirectional()) ? String
                        .format(PRE_SYMMETRIC, moduleNumber) : String
                        .valueOf(moduleNumber);
                if (!modulePolicy.isDestinationIpIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV4_DST_IP, EMPTY, symmetricSlot));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_DST_IP, EMPTY, symmetricSlot));
                }
                if (!modulePolicy.isDestinationPortIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV4_DST_L4_PORT, EMPTY, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_DST_L4_PORT, EMPTY, moduleNumber));
                }
                if (!modulePolicy.isSourceIpIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV4_SOURCE_IP, EMPTY, symmetricSlot));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_SOURCE_IP, EMPTY, symmetricSlot));
                }
                if (!modulePolicy.isSourcePortIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV4_SOURCE_L4_PORT, EMPTY, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_SOURCE_L4_PORT, EMPTY, moduleNumber));
                }
                if (!modulePolicy.isProtocolMaskIncluded()) {
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV4_PROTOCOL, EMPTY, moduleNumber));
                    cmd.append(String.format(LOAD_BALANCE_MASK_IPV6_NEXT_HEADER, EMPTY, moduleNumber));
                }
            }
        }
        if (modulePolicy.isBiDirectional()
                && modulePolicy.isDestinationIpIncluded()
                && modulePolicy.isSourceIpIncluded()
                && !modulePolicy.isDestinationPortIncluded()
                && !modulePolicy.isSourcePortIncluded()
                && !modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_IP, moduleNumber));
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_IPV6, moduleNumber));
        } else if (modulePolicy.isBiDirectional()
                && !modulePolicy.isDestinationIpIncluded()
                && !modulePolicy.isSourceIpIncluded()
                && modulePolicy.isDestinationPortIncluded()
                && modulePolicy.isSourcePortIncluded()
                && modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_L4_IP, moduleNumber));
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_L4_IPV6, moduleNumber));
        } else if (modulePolicy.isBiDirectional()
                && modulePolicy.isDestinationIpIncluded()
                && modulePolicy.isSourceIpIncluded()
                && modulePolicy.isDestinationPortIncluded()
                && modulePolicy.isSourcePortIncluded()
                && modulePolicy.isProtocolMaskIncluded()
                && !modulePolicy.isInnerIpIncluded()) {
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_IP, moduleNumber));
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_IPV6, moduleNumber));
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_L4_IP, moduleNumber));
            cmd.append(String.format(LOAD_BALANCE_SYMMETRIC_L4_IPV6, moduleNumber));
        }
        return cmd.toString();
    }
}
