package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * This class is used to handle Update Active Interface request
 */
@Slf4j
@Named
public class UpdateActiveInterfaceJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_ACTIVE_INTERFACE_UPDATE);
    }

    @Override
    public String getCommands(Job job) {
        ActiveInterface activeInterface = (ActiveInterface) getParentObject(job);
        ActiveInterface historyActiveInterface = getActiveInterfaceFromHistory(activeInterface.getId());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(INTERFACE);

        if (historyActiveInterface != null && !activeInterface.getProfileInterfaceMapping().getName().equalsIgnoreCase(historyActiveInterface.getProfileInterfaceMapping().getName())) {
            command.append(String.format(EDIT_INTERFACE, historyActiveInterface.getProfileInterfaceMapping().getName()));
            if (historyActiveInterface.getPortGroup() != null) {
                command.append(CLEAR).append(CPG).append(END);
            }
            if (historyActiveInterface.getReplicatePortGroup() != null) {
                command.append(CLEAR).append(CRPG).append(END);
            }
            if (historyActiveInterface.getSamplingPolicy() != null) {
                command.append(CLEAR).append(SP).append(END);
            }
            if (historyActiveInterface.getDeDupePolicy() != null) {
                command.append(CLEAR).append(DP).append(END);
            }
            if (historyActiveInterface.getFilterPolicy() != null) {
                command.append(CLEAR).append(FP).append(END);
            }
            command.append(RETURN);
        }
        command.append(String.format(EDIT_INTERFACE, activeInterface.getProfileInterfaceMapping().getName()));
        if (isPropertyChanged(activeInterface.getPortGroup(), historyActiveInterface.getPortGroup())) {
            if (historyActiveInterface.getPortGroup() != null)
                command.append(CLEAR).append(CPG).append(END);
            if (activeInterface.getPortGroup() != null)
                command.append(SET).append(String.format(PG, activeInterface.getPortGroup().getName())).append(END);
        }
        if (isPropertyChanged(activeInterface.getReplicatePortGroup(), historyActiveInterface.getReplicatePortGroup())) {
            if (historyActiveInterface.getReplicatePortGroup() != null)
                command.append(CLEAR).append(CRPG).append(END);
            if (activeInterface.getReplicatePortGroup() != null)
                command.append(SET).append(String.format(RPG, activeInterface.getReplicatePortGroup().getName())).append(END);
        }
        if (isPropertyChanged(activeInterface.getSamplingPolicy(), historyActiveInterface.getSamplingPolicy())) {
            if (historyActiveInterface.getSamplingPolicy() != null)
                command.append(CLEAR).append(SP).append(END);
            if (activeInterface.getSamplingPolicy() != null)
                command.append(SET).append(String.format(SAMPLING_POLICY, activeInterface.getSamplingPolicy().getName())).append(END);
        }
        if (isPropertyChanged(activeInterface.getDeDupePolicy(), historyActiveInterface.getDeDupePolicy())) {
            if (historyActiveInterface.getDeDupePolicy() != null)
                command.append(CLEAR).append(DP).append(END);
            if (activeInterface.getDeDupePolicy() != null)
                command.append(SET).append(String.format(DEDUPE_POLICY, activeInterface.getDeDupePolicy().getName()));
        }
        if (isPropertyChanged(activeInterface.getFilterPolicy(), historyActiveInterface.getFilterPolicy())) {
            if (historyActiveInterface.getFilterPolicy() != null)
                command.append(CLEAR).append(FP).append(END);
            if (activeInterface.getFilterPolicy() != null)
                command.append(SET).append(String.format(FILTER_POLICY, activeInterface.getFilterPolicy().getName()));
        }
        command.append(EXIT);
        command.append(EXIT);

        return command.toString();
    }

    protected boolean isPropertyChanged(Object newObject, Object oldObject) {
        boolean isChanged = false;
        if (newObject instanceof SdPortGroup || oldObject instanceof SdPortGroup) {
            SdPortGroup oldPortGroup = (SdPortGroup) oldObject;
            SdPortGroup newPortGroup = (SdPortGroup) newObject;
            isChanged = (oldPortGroup != null && newPortGroup == null) ||
                    (oldPortGroup == null && newPortGroup != null) ||
                    (oldPortGroup != null && newPortGroup != null && oldPortGroup.getId().longValue() != newPortGroup.getId().longValue());
        } else if (newObject instanceof SamplingPolicy || oldObject instanceof SamplingPolicy) {
            SamplingPolicy oldSamplingPolicy = (SamplingPolicy) oldObject;
            SamplingPolicy newSamplingPolicy = (SamplingPolicy) newObject;
            isChanged = (oldSamplingPolicy != null && newSamplingPolicy == null) ||
                    (oldSamplingPolicy == null && newSamplingPolicy != null) ||
                    (oldSamplingPolicy != null && newSamplingPolicy != null && oldSamplingPolicy.getId().longValue() != newSamplingPolicy.getId().longValue());
        } else if (newObject instanceof DeDupePolicy || oldObject instanceof DeDupePolicy) {
            DeDupePolicy oldDedupePolicy = (DeDupePolicy) oldObject;
            DeDupePolicy newDedupePolicy = (DeDupePolicy) newObject;
            isChanged = (oldDedupePolicy != null && newDedupePolicy == null) ||
                    (oldDedupePolicy == null && newDedupePolicy != null) ||
                    (oldDedupePolicy != null && newDedupePolicy != null && oldDedupePolicy.getId().longValue() != newDedupePolicy.getId().longValue());
        } else if (newObject instanceof FilterPolicy || oldObject instanceof FilterPolicy) {
            FilterPolicy oldFilterPolicy = (FilterPolicy) oldObject;
            FilterPolicy newFilterPolicy = (FilterPolicy) newObject;
            isChanged = (oldFilterPolicy != null && newFilterPolicy == null) ||
                    (oldFilterPolicy == null && newFilterPolicy != null) ||
                    (oldFilterPolicy != null && newFilterPolicy != null && oldFilterPolicy.getId().longValue() != newFilterPolicy.getId().longValue());
        }
        return isChanged;
    }
}
