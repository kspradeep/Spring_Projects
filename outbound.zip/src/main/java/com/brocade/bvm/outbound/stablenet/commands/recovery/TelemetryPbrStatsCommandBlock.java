package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import com.google.common.base.Strings;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class TelemetryPbrStatsCommandBlock implements CommandBlock {

    private static final String ETHERNET = "ethernet";
    private static final String PORT_CHANNEL = "port-channel";
    private static final String EXIT = "exit";

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String interfacesPorts;

    @Getter
    @Setter
    private String interfacesPortChannels;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * eg: do show running-config telemetry profile pbr default_pbr_statistics
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config telemetry profile pbr default_pbr_statistics";

    /**
     * <pre>
     * interval 30
     * </pre>
     */
    private static final String MATCH_CMD = " interval (\\d+)";

    /**
     * <pre>
     * argument #1 interface type ETHERNET or PORT-CHANNEL
     * interface ETHERNET remove 0/1,0/3
     * interface PORT-CHANNEL remove 5,8
     * </pre>
     */
    private static final String INTERFACE_REMOVE_RANGE = "interface %s remove %s\n";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(SHOW_CMD);
        args.add(MATCH_CMD);
        StringBuilder interfacesCommand = new StringBuilder("telemetry profile pbr default_pbr_statistics\n");
        if (!Strings.isNullOrEmpty(interfacesPorts)) {
            interfacesCommand.append(String.format(INTERFACE_REMOVE_RANGE, ETHERNET, interfacesPorts));
        }
        if (!Strings.isNullOrEmpty(interfacesPortChannels)) {
            interfacesCommand.append(String.format(INTERFACE_REMOVE_RANGE, PORT_CHANNEL, interfacesPortChannels));
        }
        interfacesCommand.append(EXIT);
        args.add(interfacesCommand.toString());
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "TelemetryPbrStatsCommandBlock [deviceId=" + deviceId + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
