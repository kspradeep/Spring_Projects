package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * This class is used to build command for Sampling policy
 */
@Slf4j
@Named
public class CommitSdSamplingPolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    protected static final String SAMPLING = "sampling;";
    protected static final String SAMPLE = "sample=%d;";
    protected static final String ALGO = "algo=hash;";
    protected static final String ACTION = "action=%s;";
    protected static final String DEFFERED = "deferred";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SAMPLING_POLICY_CREATE);
    }

    @Override
    public String getCommands(Job job) {
        SamplingPolicy samplingPolicy = (SamplingPolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(SAMPLING);
        command.append(ADD).append(String.format(SAMPLING_POLICY, samplingPolicy.getName())).append(END);
        if (DEFFERED.equalsIgnoreCase(samplingPolicy.getAction())) {
            command.append(SET).append(String.format(ACTION, samplingPolicy.getAction()));
        }
        if (samplingPolicy.isPreserveCplane()) {
            command.append(SET).append(PRESERVE_CPLANE);
        }
        if (samplingPolicy.getRate() != 0) {
            command.append(SET).append(String.format(SAMPLE, samplingPolicy.getRate()));
        }
        if(samplingPolicy.getLoadBalanceAlgo().getName().equals(SamplingPolicy.LoadBalanceAlgorithms.HASH.getName())){
            command.append(SET).append(ALGO);
        }
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
