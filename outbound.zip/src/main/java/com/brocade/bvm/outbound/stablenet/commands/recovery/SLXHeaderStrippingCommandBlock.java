package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXHeaderStrippingCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String portNo;

    @Getter
    @Setter
    private boolean isPreserve;

    @Getter
    @Setter
    private HeaderStrippingModulePolicy.Headers header;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "configure terminal";
    private static final String INTERFACE_ETHERNET = "interface ethernet %s \n%s";
    private static final String SHOW_CMD = "do show running-config interface ethernet %s %s";
    private static final String END = "$";

    private static final String MATCH_802BR_CMD = "strip-802-1br";
    private static final String MATCH_ERSPAN_CMD = "strip-erspan";
    private static final String MATCH_MPLS_CMD = "strip-mpls";
    private static final String MATCH_NVGRE_CMD = "strip-nvgre";
    private static final String MATCH_VN_TAG_CMD = "strip-vn-tag";
    private static final String MATCH_VXLAN_CMD = "strip-vxlan";

    private static final String ACTION_802BR_CMD = "no strip-802-1br";
    private static final String ACTION_VNTAG_CMD = "no strip-vn-tag\nno allow-vn-tag";
    private static final String ACTION_VXLAN_CMD = "no strip-vxlan";
    private static final String ACTION_NVGRE_CMD = "no strip-nvgre";
    private static final String ACTION_MPLS_CMD = "no strip-mpls";
    private static final String ACTION_ERSPAN_CMD = "no strip-erspan";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        input.getArg().addAll(getCommand());
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    private List<String> getCommand() {
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_802BR_CMD));
            args.add(MATCH_802BR_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_802BR_CMD));
        } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_VN_TAG_CMD));
            args.add(MATCH_VN_TAG_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_VNTAG_CMD));
        } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_VXLAN_CMD));
            args.add(MATCH_VXLAN_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_VXLAN_CMD));
        } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_NVGRE_CMD));
            args.add(MATCH_NVGRE_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_NVGRE_CMD));
        } else if (HeaderStrippingModulePolicy.Headers.ERSPAN == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_ERSPAN_CMD));
            args.add(MATCH_ERSPAN_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_ERSPAN_CMD));
        } else if (HeaderStrippingModulePolicy.Headers.MPLS == header) {
            args.add(String.format(SHOW_CMD, getPortNo(), MATCH_MPLS_CMD));
            args.add(MATCH_MPLS_CMD + END);
            args.add(String.format(INTERFACE_ETHERNET,portNo,ACTION_MPLS_CMD));
        }
        args.add(writeMem);
        return args;
    }
}
