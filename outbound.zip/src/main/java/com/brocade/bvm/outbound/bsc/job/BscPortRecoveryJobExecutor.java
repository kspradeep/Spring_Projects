package com.brocade.bvm.outbound.bsc.job;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Named;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.OutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.bsc.commands.recovery.BscPortRecoveryCommandList;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.PortGroupRecoveryCommandList;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetRecoveryJobExecutor;
import com.google.common.collect.Lists;

/**
 * The BscPortRecoveryJobExecutor class implements methods to recover the selected port(s) which are in error state on Open Flow device
 */
@Named
public class BscPortRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    /**
     * This method used to build the port recovery command blocks
     *
     * @param job
     * @return List<CommandBlock> This returns list of commandBlocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        BscPortRecoveryCommandList recoveryCommandList = new BscPortRecoveryCommandList();

        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        for(Port port: ports) {
            recoveryCommandList.constructCommandBlock(job.getDevice().getStablenetId(), port);
        }

        List<CommandBlock> commandBlocks = recoveryCommandList.getCommandBlocks();
        if (commandBlocks!=null && !commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("true");
        }
        return commandBlocks;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE, Device.Type.ICX);
    }

}
