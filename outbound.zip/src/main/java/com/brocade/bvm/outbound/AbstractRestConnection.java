package com.brocade.bvm.outbound;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.function.Function;

@Slf4j
public abstract class AbstractRestConnection {
    @Value("${stablenet.resource-url.agent.sync.all}")
    private String agentSyncAllUrl;

    @Inject
    private ConfigRepository configRepository;

    private static final String AGENT_NOT_CONFIGURED_ERROR = "ForbiddenException: Required modules for the requested endpoint are not licensed.";

    protected TrustManager[] trustAllCerts() {
        return new TrustManager[]{new X509TrustManager() {

            @Override
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            @Override
            public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
            }

            @Override
            public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
            }
        }};
    }

    protected HostnameVerifier hostnameVerifier() {
        return (hostname, session) -> true;
    }

    protected SSLContext sslContext() {
        try {
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts(), new SecureRandom());
            return sslContext;
        } catch (KeyManagementException | NoSuchAlgorithmException e) {
            throw new ServerException(e);
        }
    }

    public Response get(MediaType mediaType, String... paths) {
        return invoke(target -> target.request().accept(mediaType).get(), paths);
    }

    public Response get(String... paths) {
        return invoke(target -> target.request().accept(MediaType.APPLICATION_XML).get(), paths);
    }

    public Response getWithoutAcceptType(String... paths) {
        return invoke(target -> target.request().get(), paths);
    }

    public Response post(Entity<?> entity, String... paths) {
        return invoke(target -> target.request().accept(MediaType.APPLICATION_XML).post(entity), paths);
    }

    public Response post(Entity<?> entity, MediaType mediaType, String... paths) {
        return invoke(target -> target.request().accept(mediaType).post(entity), paths);
    }

    public Response put(Entity<?> entity, String... paths) {
        return invoke(target -> target.request().accept(MediaType.APPLICATION_XML).put(entity), paths);
    }

    public Response put(Entity<?> entity, MediaType mediaType, String... paths) {
        return invoke(target -> target.request().accept(mediaType).put(entity), paths);
    }

    public Response delete(String... paths) {
        return invoke(target -> target.request().delete(), paths);
    }

    private Response invoke(Function<WebTarget, Response> function, String... paths) {
        WebTarget target = getTarget(paths);
        Response response;
        try {
            response = function.apply(target);
        } catch (Exception e) {
            if (e instanceof ProcessingException && (e.getCause() instanceof SocketException || e.getCause() instanceof UnknownHostException)) {
                throw new OutboundConnectionException(e.getMessage());
            } else {
                throw e;
            }
        }
        if (response == null || response.getStatusInfo() == null) {
            throw new OutboundApiException("Null response status");
        } else {
            switch (response.getStatusInfo().getFamily()) {
                case SUCCESSFUL:
                    break;
                case SERVER_ERROR:
                case CLIENT_ERROR: {
                    String errorMessage = getErrorMessage(target, response, paths);
                    log.error("Unexpected response status: {}", response.getStatus());
                    throw new OutboundConnectionException(errorMessage);
                }
                default: {
                    String errorMessage = getErrorMessage(target, response, paths);
                    log.error("Unexpected response status: {}", response.getStatus());
                    throw new OutboundApiException(errorMessage);
                }
            }
        }
        return response;
    }

    private WebTarget getTarget(String... paths) {
        WebTarget target = getClient().target(getBaseUrl());
        for (String path : paths) {
            target = target.path(path);
        }
        if (paths != null && paths.length > 0) {
            if (paths[0].equals("/jobs/jobresultdevice")) {
                target = target.queryParam("outputformat", "job_result_device");
            } else if (paths[0].equals(agentSyncAllUrl)) {
                target = target.queryParam("forcerestart", "true");
            }
        }
        log.debug("Calling url {}", target.getUri());
        return target;
    }

    protected abstract Client getClient();

    protected abstract String getBaseUrl();

    private String getErrorMessage(WebTarget target, Response response, String... paths) {
        String message = "Service endpoint unavailable! Please try after sometime.";
        String errorResponse = response.readEntity(String.class);
        if (errorResponse != null && errorResponse.contains(AGENT_NOT_CONFIGURED_ERROR)) {
            message = "StableNet Agent is not configured. Configure the agent and try again.";
            log.error("StableNet Agent is not configured. Configure the agent and try again.");
        } else {
            String url = null;
            if (target != null && target.getUri() != null) {
                url = target.getUri().toString();
            } else if (paths != null && paths.length > 0) {
                url = paths[0];
            }
            if (url != null) {
                ApplicationConfig applicationConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetRestUrl);
                if (applicationConfig.getValue() != null && url.contains(applicationConfig.getValue())) {
                    message = "Connection with StableNet is failed. Possible causes:<br>1. Failed to connect to device.<br>2. Job Id configuration missing or job template not added in StableNet.";
                } else if (url.contains("/session_director")) {
                    message = "Connection with Session Director is failed. Please try after sometime.";
                }
                log.error("Failed to connect to endpoint {},  error: {}", url, message);
            }
        }

        return message;
    }
}
