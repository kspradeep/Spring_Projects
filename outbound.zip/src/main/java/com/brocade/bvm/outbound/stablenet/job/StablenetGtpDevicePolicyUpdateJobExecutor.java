package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.GTPDevicePolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.GTPDevicePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketStampingModulePolicy;
import com.brocade.bvm.model.db.history.GTPDevicePolicyHistory;
import com.brocade.bvm.model.db.history.PacketStampingModulePolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

/**
 * The StablenetGtpDevicePolicyUpdateJobExecutor class implements methods to update GTPDevicePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetGtpDevicePolicyUpdateJobExecutor extends AbstractGtpDevicePolicyJobExecutor {

    @Inject
    private GTPDevicePolicyHistoryRepository gtpDevicePolicyHistoryRepository;

    /**
     * This method constructs update GTPDevicePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        GTPDevicePolicy newGtpDevicePolicy = (GTPDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        if (newGtpDevicePolicy != null) {
            GTPDevicePolicy oldGtpDevicePolicy = getGtpDevicePolicyFromHistory(newGtpDevicePolicy.getId());
            command.append(CONFIGURE_TERMINAL);
            if (!newGtpDevicePolicy.getName().equals(oldGtpDevicePolicy.getName()) || !newGtpDevicePolicy.getProfileId().equals(oldGtpDevicePolicy.getProfileId())) {
                command.append(buildDeleteCommand(oldGtpDevicePolicy));
                command.append(buildCreateCommand(newGtpDevicePolicy));
            } else {
                command.append(String.format(CREATE_GTP_PROFILE_CONFIG, newGtpDevicePolicy.getName(), newGtpDevicePolicy.getProfileId()));
                if (oldGtpDevicePolicy.isGTPCTeIdEnabled() != newGtpDevicePolicy.isGTPCTeIdEnabled()) {
                    if (oldGtpDevicePolicy.isGTPCTeIdEnabled()) {
                        command.append(DISABLE_LOAD_BALANCE_GTPC_TEID_HASH);
                    } else {
                        command.append(ENABLE_LOAD_BALANCE_GTPC_TEID_HASH);
                    }
                }
                if (oldGtpDevicePolicy.isGTPUTeIdEnabled() != newGtpDevicePolicy.isGTPUTeIdEnabled()) {
                    if (oldGtpDevicePolicy.isGTPUTeIdEnabled()) {
                        command.append(DISABLE_LOAD_BALANCE_GTPU_TEID_HASH);
                    } else {
                        command.append(ENABLE_LOAD_BALANCE_GTPU_TEID_HASH);
                    }
                }
                if (oldGtpDevicePolicy.isGTPUInnerL3Enabled() != newGtpDevicePolicy.isGTPUInnerL3Enabled()) {
                    if (oldGtpDevicePolicy.isGTPUInnerL3Enabled()) {
                        command.append(DISABLE_LOAD_BALANCE_GTPU_INNERL3_HASH);
                    } else {
                        command.append(ENABLE_LOAD_BALANCE_GTPU_INNERL3_HASH);
                    }
                }
            }
            command.append(EXIT);
            command.append(WRITE_MEMORY);
        } else {
            log.error("GTP Profile entity is null!");
        }
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_PROFILE_UPDATE);
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestGtpDevicePolicyId
     * @return GTPDevicePolicy returns latest ACTIVE policy
     */
    private GTPDevicePolicy getGtpDevicePolicyFromHistory(Long latestGtpDevicePolicyId) {
        List<GTPDevicePolicyHistory> GTPDevicePolicyHistoryList = gtpDevicePolicyHistoryRepository.findByIdAndWorkflowStatus(latestGtpDevicePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GTPDevicePolicy gtpDevicePolicy = null;
        if (GTPDevicePolicyHistoryList.size() >= 1) {
            GTPDevicePolicyHistory gtpDevicePolicyHistory = GTPDevicePolicyHistoryList.get(0);
            gtpDevicePolicy = gtpDevicePolicyHistory.buildParent();
        }
        return gtpDevicePolicy;
    }
}
