package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;


@Named
public class SdFilterPolicyRecoveryCommandList {
    /**
     * This method is used to construct recovery command block for Filter Policy
     *
     * @param filterPolicy
     * @return
     */
    public List<CommandBlock> constructCommandBlockList(FilterPolicy filterPolicy) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        SdFilterPolicyCommandBlock filterPolicyCommandBlock = new SdFilterPolicyCommandBlock();
        filterPolicyCommandBlock.setDeviceId(Math.toIntExact(filterPolicy.getDevice().getStablenetId()));
        filterPolicyCommandBlock.setName(filterPolicy.getName());
        commandBlocks.add(filterPolicyCommandBlock);
        if (!commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("false");
        }
        return commandBlocks;
    }
}
