package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class SLXHeaderStripModulePolicyDeleteJobExecutor extends AbstractSLXHeaderStripModulePolicyJobExecutor {
    /**
     * This method constructs delete HeaderStripping module policy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        HeaderStrippingModulePolicy modulePolicy = (HeaderStrippingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getStripHeaders().forEach(header -> {
            command.append(buildDeleteCommand(modulePolicy.getPorts(), header));
        });
        command.append(EXIT);
        log.debug("SLXHeaderStrippingModulePolicyDelete command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_SLX_DELETE);
    }
}
