package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The BscPortGroupUpdateJobExecutor class implements methods to update portGroup on Open Flow device through BSC
 */
@Named
@Slf4j
public class BscPortGroupUpdateJobExecutor extends AbstractBscPortGroupJobExecutor {

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.PORT_GROUP_UPDATE);
    }

    @Override
    public OutboundJobResponse execute(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        Device device = portGroup.getDevice();
        String openFlowDeviceId = device.getOpenflowId();
        Map<String, String> grpMap = getGroupNameIdMap(openFlowDeviceId);// not null check
        String groupName = portGroup.getName()+ "_select";
        String groupId = grpMap.get(groupName);
        if (groupId != null) {
            Map<String, String> portIdNameMap = getPortNameIdMap(openFlowDeviceId);
            Set<Port> ports = portGroup.getPorts();
            // Converting port number to port name by prepending with 'eth'
            List<String> portIds = ports.stream().map(port -> port.getOpenFlowPortNumber())
                    .collect(Collectors.toList());
            List<String> portIdList = new ArrayList<>();
            for (String portName : portIds) {
                String portid = portIdNameMap.get(portName);
                if (portid != null)
                    portIdList.add(portid);
            }
            checkIfValidInterface(portIdNameMap,portIds);
            log.info("Group Name : " + groupName);
            String group = buildPortGroup(groupId, groupName, "group-select", portIdList);
            boolean jobResult = addGroupOnDevice(openFlowDeviceId, groupId, group, portIdList, device.getType());
            if (jobResult) {
                return new OutboundJobResponse(Job.Status.SUCCESS, "Port Group Updation Successful on Device");
            } else {
                return new OutboundJobResponse(Job.Status.FAILED, "Port Group Updation Failed on Device");
            }

        }
        return new OutboundJobResponse(Job.Status.FAILED, "Port Group does not exist on device");
    }

}
