package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PacketSlicingModulePolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PacketSlicingModulePolicyHistory;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.outbound.stablenet.commands.recovery.*;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The StablenetPacketSlicingModulePolicyRecoveryJobExecutor class implements methods to recover PacketSlicingModulePolicy which is in ERROR state on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetPacketSlicingModulePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_SLICING_MODULE_POLICY_ROLLBACK);
    }

    /**
     * This method constructs PacketSlicingModulePolicy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        PacketSlicingModulePolicy modulePolicyToDelete = (PacketSlicingModulePolicy) getParentObject(job);
        log.debug("PacketSlicingModulePolicyRecovery Job executor for policy id {}", modulePolicyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(modulePolicyToDelete);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", modulePolicyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs PacketSlicingModulePolicy recovery command blocks for the given policy
     *
     * @param modulePolicyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(PacketSlicingModulePolicy modulePolicyToDelete) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        modulePolicyToDelete.getModules().forEach(module -> {
            finalCommandBlocks.add(constructModuleCommandBlock(module, modulePolicyToDelete.getNumberOfBytes()));
        });
        modulePolicyToDelete.getPorts().forEach(port -> {
            finalCommandBlocks.add(constructPortCommandBlock(port));
        });
        return finalCommandBlocks;
    }

    /**
     * This method constructs PacketSlicingModulePolicy module recovery command block
     *
     * @param module
     * @param noOfBytes
     * @return PacketSlicingCommandBlock
     */
    private PacketSlicingCommandBlock constructModuleCommandBlock(Module module, Integer noOfBytes) {
        PacketSlicingCommandBlock packetSlicingCommandBlock = new PacketSlicingCommandBlock();
        packetSlicingCommandBlock.setDeviceId(module.getDevice().getStablenetId().intValue());
        packetSlicingCommandBlock.setNoOfBytes(noOfBytes);
        packetSlicingCommandBlock.setModuleNumber(module.getModuleNumber());
        return packetSlicingCommandBlock;
    }

    /**
     * This method constructs PacketSlicingModulePolicy port recovery command block
     *
     * @param port
     * @return PacketSlicingPortCommandBlock
     */
    private PacketSlicingPortCommandBlock constructPortCommandBlock(Port port) {
        PacketSlicingPortCommandBlock packetSlicingPortCommandBlock = new PacketSlicingPortCommandBlock();
        packetSlicingPortCommandBlock.setDeviceId(port.getModule().getDevice().getStablenetId().intValue());
        packetSlicingPortCommandBlock.setPortNumber(port.getPortNumber());
        return packetSlicingPortCommandBlock;
    }
}
