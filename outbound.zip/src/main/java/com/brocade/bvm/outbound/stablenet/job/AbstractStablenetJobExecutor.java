package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.RuleSetRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.TargetHost.Mode;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.model.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXB;
import java.io.StringReader;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Named
public abstract class AbstractStablenetJobExecutor extends BaseOutboundJobExecutor {

    @Value("${slx.telemetry.supported.os.version}")
    protected String slxTelemetrySupportedVersion;

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String INTERFACE_ETHERNET_ENABLE_BREAKOUT = "interface ethernet %s:%s;";

    protected static final String INTERFACE_ETHERNET_DISABLE_BREAKOUT = "interface ethernet %s;";

    protected static final String NO_SHUTDOWN = "no shutdown;";

    protected static final String SHUTDOWN = "shutdown;";

    protected static final String EXIT = "exit;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String REVERT = "no ";

    @Inject
    private StablenetAdminConnection stablenetConnection;

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String userGroupsUrl;

    @Value("${stablenet.resource-url.jobs.deploy}")
    private String jobDeployUrl;

    @Value("${stablenet.resource-url.jobs.start}")
    private String jobStartUrl;

    @Value("${stablenet.resource-url.jobs.isrunning}")
    private String jobStatusUrl;

    @Value("${stablenet.resource-url.jobs.jobresult}")
    private String jobResultUrl;

    @Value("${stablenet.resource-url.jobs.jobresultlist}")
    private String jobResultListUrl;

    @Value("${stablenet.resource-url.jobs.jobresultdevice}")
    private String jobResultDeviceUrl;

    @Value("${stablenet-response.timeout.minutes}")
    private int timeoutMinutes;

    private List<Map.Entry<Integer, Integer>> sleepTimeouts = Lists.newArrayList();

    protected static final int MLXE_OS_MAJOR_VERSION = 6;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @PostConstruct
    public void intilizeExecutorTimeouts() {
        sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(5, 5 * 60 * 1000));//5 secs poll for first 5 mins(5*60*1000 ms)
        if (timeoutMinutes > 5) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(30, 30 * 60 * 1000)); //30 secs poll for the next 30 mins
        }
        if (timeoutMinutes > 30) {
            sleepTimeouts.add(new AbstractMap.SimpleImmutableEntry(60, timeoutMinutes * 60 * 1000)); //60 secs poll for the rest till timeoutMinutes
        }
    }

    @Override
    public Mode getSupportedMode() {
        return Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE, Device.Type.SD);
    }

    @Override
    public Long startExternalJob(Job job) {
        //Put request and get stablenet's job id (this is a clone id of parent template job)
        log.debug("Starting Stablnet job for jobId {}", job.getId());
        Input input = new Input();
        List<String> args = new ArrayList<>();
        String commands = getCommands(job);
        boolean isSetFcr = false;
        boolean isClearFcr = false;
        //Removing the set FCR and clear FCR identifiers in command and removing it
        if (Device.Type.SD == job.getDevice().getType()) {
            if (job.getType() == Job.Type.SD_GLOBAL_CONFIG_UPDATE) {
                if (commands.contains("setFCR")) {
                    isSetFcr = true;
                    commands = commands.replace("setFCR;exit;", "");
                } else if (commands.contains("clearFCR")) {
                    isClearFcr = true;
                    commands = commands.replace("clearFCR;exit;", "");
                }
            }
        }
        // Need to set arguments like saveConfig, breakoutCommand etc., in the same order as defined in "Brocade MLXe Commands.xml"
        args.add(commands.replaceAll(";", "\n"));
        if (Device.Type.SLX == job.getDevice().getType()) {
            if (Job.Type.TELEMETRY_CLEAR_COUNTER != job.getType()) {
                args.add("true"); // Required to save running config
            } else {
                args.add("false"); // save running config not required for TELEMETRY_CLEAR_COUNTER
            }
            if (job.getType() == Job.Type.PORT_BREAKOUT_ENABLE || job.getType() == Job.Type.PORT_BREAKOUT_DISABLE) {
                if (isReloadRequiredForSlxOsVersion(job.getDevice())) {
                    args.add(updateBreakoutCommand(job));
                } else {
                    args.add("");
                }
            }
        } else { // Need to send default values to arguments if the device type is SD
            args.add("false"); // Required to save running config
            args.add(""); // Required for Break out
        }
        if (Device.Type.SD == job.getDevice().getType()) {
            if (job.getType() == Job.Type.SD_CLEAR_CONFIG) {
                args.add("true"); // Required for clear config
            } else {
                args.add("false"); // Required for clear config
            }
            if (job.getType() == Job.Type.SD_GLOBAL_CONFIG_UPDATE) {
                if (isSetFcr) {
                    args.add("setFCR");
                    args.add("");
                } else if (isClearFcr) {
                    args.add("");
                    args.add("clearFCR");
                } else {
                    args.add("");
                    args.add("");
                }
            }
        }
        input.setArg(args);

        UserVO user = null;
        if (!Strings.isNullOrEmpty(job.getCreatedByUser()) && job.getDevice().isAuthenticationConfigured()) {
            user = JAXB.unmarshal(
                    new StringReader(stablenetConnection.get(userGroupsUrl, job.getCreatedByUser()).readEntity(String.class)),
                    UserVO.class);
        }
        if (Job.Type.DELETE_TELEMETRY_PROFILE == job.getType() || Job.Type.DELETE_TACACS_SERVER == job.getType()
                || Job.Type.RECONFIG_TELEMETRY_PROFILE == job.getType() || Job.Type.CONFIG_TELEMETRY_PROFILE == job.getType()) {
            user = null;
        }

        Devices devices = new Devices();
        devices.setDeviceid(job.getDevice().getStablenetId().toString());
        Deployparameter deployparameter = new Deployparameter();
        deployparameter.setInput(input);
        deployparameter.setDevices(devices);
        deployparameter.setSingletrigger(new SingleTrigger());
        if (user != null && "true".equals(user.getExternalauthentication())) {
            deployparameter.setCredentialsetting("override");
            CliCapabilityVO cli = new CliCapabilityVO();
            cli.setUser(job.getCreatedByUser() != null
                    ? job.getCreatedByUser() : configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
            cli.setPassword(job.getCreatedByUserPassword() != null
                    ? decryptPassword(job.getCreatedByUserPassword()) : configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue());
            deployparameter.setCli(cli);
        }

        ApplicationConfig applicationConfig = getRestJobIdUsingJobType(job.getType());
        String stablenetPushJobId = null;
        if (applicationConfig != null && applicationConfig.getValue() != null) {
            stablenetPushJobId = applicationConfig.getValue();
        } else {
            log.error("StableNet job ID is not configured!");
            throw new OutboundApiException("StableNet job ID is not configured!");
        }
        String jobTemplateCloneId = stablenetConnection
                .put(Entity.entity(deployparameter, MediaType.APPLICATION_XML_TYPE),
                        jobDeployUrl, stablenetPushJobId)
                .readEntity(ScheduledJobBaseVO.class)
                .getObid();

        log.debug("StableNet jobTemplateCloneId {} created for jobId {}", jobTemplateCloneId, job.getId());
        if (Strings.isNullOrEmpty(jobTemplateCloneId) ||
                !stablenetConnection.get(jobStartUrl, jobTemplateCloneId).readEntity(ResultVo.class)
                        .getState().equalsIgnoreCase(RestResultStateEnum.SUCCESS.value())) {
            throw new OutboundApiException("Unable to start job");
        }

        return Long.valueOf(jobTemplateCloneId);
    }

    @Override
    public OutboundJobResponse execute(Job job) {
        OutboundJobResponse jobResponse = null;
        log.debug("Executing job for jobId {}", job.getId());
        // Checking status of tmp job in infosim
        boolean isComplete = false;

        int i = 0;
        long startTime = System.currentTimeMillis();
        while (true) {
            try {
                Result result = JAXB.unmarshal(new StringReader(stablenetConnection.get(jobStatusUrl, job.getExternalJobId().toString()).readEntity(String.class)), Result.class);
                isComplete = result != null && result.getInfo().equalsIgnoreCase("not found");
                if (isComplete) {
                    break;
                }
            } catch (OutboundApiException e) {
                log.debug(e.getMessage());
            }
            try {
                TimeUnit.SECONDS.sleep(sleepTimeouts.get(i).getKey());
            } catch (InterruptedException e1) {
                throw new ServerException(e1);
            }

            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= timeoutMinutes * 60 * 1000) {
                log.warn("Job timeout! Exhausted the timeout staggered timeout intervals");
                break;
            } else if (elapsedTime >= sleepTimeouts.get(i).getValue()) {
                i++;
                log.info("Staggering to the next timeout interval:{}", i);
            }
        }

        if (!isComplete) {
            throw new OutboundApiException("Job timed out for jobId: " + job.getId());
        }

        // Getting list of all Available jobs
        //15. get a list of results of all clone jobs of template id
        ApplicationConfig applicationConfig = getRestJobIdUsingJobType(job.getType());
        List<JobResultVO> jobResultList = stablenetConnection.get(jobResultListUrl, applicationConfig.getValue()).readEntity(new GenericType<List<JobResultVO>>() {
        });
        Optional<JobResultVO> jobResultVO = jobResultList.stream()
                .filter(input -> String.format("Deployed Object ID: %s", job.getExternalJobId())
                        .equalsIgnoreCase(input.getLabel()))
                .findFirst();

        if (!jobResultVO.isPresent()) {
            throw new OutboundApiException("Unable to find job result for jobId: " + job.getId());
        }

        JobResult jobResult = stablenetConnection.get(jobResultUrl, jobResultVO.get().getObid()).readEntity(JobResult.class);
        if (jobResult != null && jobResult.getJobresultdevices() != null && jobResult.getJobresultdevices().getJobresultdevice() != null
                && !jobResult.getJobresultdevices().getJobresultdevice().isEmpty()) {
            Optional<JobResultDeviceVO> first = jobResult.getJobresultdevices().getJobresultdevice().stream().findFirst();

            if (first.isPresent()) {
                JobResultDeviceVO jobResultDevice = stablenetConnection.get(jobResultDeviceUrl, first.get().getObid())
                        .readEntity(JobResultDeviceVO.class);

                String commandStatus = jobResultDevice.getState().toString();
                if ("SUCCESS".equalsIgnoreCase(commandStatus)) {
                    log.debug("EVM Job Id:{} is successful", job.getId());
                    jobResponse = new OutboundJobResponse(Job.Status.SUCCESS, jobResultDevice.getContent());
                } else {
                    log.debug("EVM Job Id:{} is failed", job.getId());
                    jobResponse = new OutboundJobResponse(Job.Status.FAILED, jobResultDevice.getContent());
                }
            }
        }
        return jobResponse;
    }

    public abstract String getCommands(Job job);

    private ApplicationConfig getRestJobIdUsingJobType(Job.Type type) {
        ApplicationConfig applicationConfig = null;
        if (type != null) {
            if (Job.Type.PORT_SPEED_UPDATE == type || Job.Type.PORT_BREAKOUT_ENABLE == type || Job.Type.PORT_BREAKOUT_DISABLE == type) {
                applicationConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetRediscoverJobId);
            }
        }
        if (applicationConfig == null || applicationConfig.getValue() == null || applicationConfig.getValue().isEmpty()) {
            applicationConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetJobId);
        }
        return applicationConfig;
    }

    /**
     * This is used for appending No shutdown command after reload
     *
     * @param job
     * @return
     */
    protected String updateBreakoutCommand(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        Set<String> uniquePortNos = new HashSet<>();
        for (Port port : ports) {
            if (job.getType() == Job.Type.PORT_BREAKOUT_ENABLE) {
                for (int i = 1; i < 5; i++) {
                    commands.append(String.format(INTERFACE_ETHERNET_ENABLE_BREAKOUT, port.getPortNumber(), i));
                    commands.append(NO_SHUTDOWN);
                }
            } else {
                if (port.getPortNumber() != null) {
                    String portNo = port.getPortNumber().split("[:]")[0];
                    if (portNo != null && !uniquePortNos.contains(portNo)) {
                        uniquePortNos.add(port.getPortNumber().split("[:]")[0]);
                        commands.append(String.format(INTERFACE_ETHERNET_DISABLE_BREAKOUT, portNo));
                        commands.append(NO_SHUTDOWN);
                    }
                }
            }
        }
        commands.append("end");
        return commands.toString().replaceAll(";", "\n");
    }

    public boolean isReloadRequiredForSlxOsVersion(Device device) {
        boolean isReloadRequired = true;
        if (!Strings.isNullOrEmpty(device.getOs()) && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (isSLXSupportsTelemetry(device.getOs()) >= 0) {
                isReloadRequired = false;
            }
        }
        return isReloadRequired;
    }

    protected int isSLXSupportsTelemetry(String deviceOs) {
        if (!Strings.isNullOrEmpty(deviceOs)) {
            Pattern pattern = Pattern.compile("^([A-Za-z\\s]*)([\\d]+)([a-z])([\\.])([\\d+])([\\.])([0-9]+)");
            Matcher matcher = pattern.matcher(String.valueOf(deviceOs));
            if (matcher.find() && matcher.groupCount() == 7) {
                if ("s".equals(matcher.group(3))) {
                    StringBuilder currentVersion = new StringBuilder();
                    currentVersion.append(matcher.group(2)).append(".").append(matcher.group(5)).append(".").append(matcher.group(7));
                    if (!currentVersion.toString().isEmpty()) {
                        int compareOutput = compareVersions(currentVersion.toString(), slxTelemetrySupportedVersion);
                        return compareOutput;
                    }
                }
            }
        }
        return -1;
    }

    private int compareVersions(String version1, String version2) {
        if (version1 != null && version2 != null) {
            String[] components1 = version1.split("\\.");
            String[] components2 = version2.split("\\.");
            int length = Math.min(components1.length, components2.length);
            for (int i = 0; i < length; i++) {
                int result = new Integer(components1[i]).compareTo(Integer.parseInt(components2[i]));
                if (result != 0) {
                    return result;
                }
            }
            return Integer.compare(components1.length, components2.length);
        } else {
            return -1;
        }
    }

    /**
     * To find if the Ruleset needs to be created or deleted based on the shared acl Policy status.Does not include the Policy submitted
     *
     * @param ruleSet
     * @param deviceId
     * @return
     */
    protected boolean isRuleSetChangesRequired(RuleSet ruleSet, Long deviceId, Long currentPolicyId) {
        List<Long> matchingRuleSetIds = ruleSetRepository.findIdsByNameAndDeviceIdAndNotInPolicyId(ruleSet.getName(), ruleSet.getId(), deviceId, currentPolicyId);
        AtomicBoolean isRuleSetChangesRequired = new AtomicBoolean(false);
        if (!matchingRuleSetIds.isEmpty()) {
            List<Long> matchingPolicyIdInWarningOrActiveState = ruleSetRepository.findPolicyByRuleSetIdAndWorkFlowStatus(matchingRuleSetIds, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING, WorkflowParticipant.WorkflowStatus.ERROR));
            if (matchingPolicyIdInWarningOrActiveState == null || matchingPolicyIdInWarningOrActiveState.isEmpty()) {
                List<Long> matchingPolicyIdInDraftState = ruleSetRepository.findPolicyByRuleSetIdAndWorkFlowStatus(matchingRuleSetIds, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.DRAFT));
                if (matchingPolicyIdInDraftState != null && !matchingPolicyIdInDraftState.isEmpty()) {
                    for (Long policyId : matchingPolicyIdInDraftState) {
                        Policy policyHistory = getPolicyNameFromHistoryByTypes(policyId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING, WorkflowParticipant.WorkflowStatus.ERROR));
                        if (policyHistory == null || (policyHistory != null && WorkflowParticipant.WorkflowStatus.ERROR == policyHistory.getWorkflowStatus())) {
                            isRuleSetChangesRequired.set(true);
                        } else if (policyHistory != null && isPolicyInActiveOrWarnningState(policyHistory.getWorkflowStatus())) {
                            isRuleSetChangesRequired.set(false);
                            break;
                        }
                    }
                }
            }
        } else {
            isRuleSetChangesRequired.set(true);
        }
        return isRuleSetChangesRequired.get();
    }

    /**
     * Fetches the policy history object
     *
     * @param policyId
     * @param status
     * @return
     */
    protected Policy getPolicyNameFromHistoryByTypes(Long policyId, List<WorkflowParticipant.WorkflowStatus> status) {
        Policy policyFromHistory = null;
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policyId, status);
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policy history entity with oldName {} and latest Policy Id {}", oldPolicy.getName(), policyId);
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * To know if the given policy is in warning or  active state
     *
     * @param policyWorkflowStatus
     * @return
     */
    protected boolean isPolicyInActiveOrWarnningState(WorkflowParticipant.WorkflowStatus policyWorkflowStatus) {
        return WorkflowParticipant.WorkflowStatus.ACTIVE == policyWorkflowStatus || WorkflowParticipant.WorkflowStatus.WARNING == policyWorkflowStatus;
    }

    /**
     * To check if the ruleset
     */
    protected boolean isSameRulesetNameFoundInCurrentPolicy(String ruleSetName, Long policyId, Long rulesetId) {
        Set<RuleSet> ruleSets = ruleSetRepository.findByNameAndPolicyIdAndNotInRulesetId(ruleSetName, policyId, rulesetId);
        return (ruleSets != null & !ruleSets.isEmpty());
    }
}
