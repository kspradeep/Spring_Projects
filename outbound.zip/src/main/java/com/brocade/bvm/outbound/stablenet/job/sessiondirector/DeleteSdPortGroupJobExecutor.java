package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class DeleteSdPortGroupJobExecutor extends AbstractSdPortGroupJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_PORT_GROUP_DELETE, Job.Type.SD_DEFAULT_PORT_GROUP_DELETE);
    }

    /**
     * This method builds PortGroup DELETE commands to be executed on the given SD device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        SdPortGroup portGroupToDelete = (SdPortGroup) getParentObject(job);
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(buildDeleteCommand(portGroupToDelete));
        command.append(EXIT);
        log.info("Stablenet command generated from Job Id{} on device{} for deleting SD PortGroup id {} is {}", job.getId(), job.getDevice().getId(), portGroupToDelete.getId(), command);
        return command.toString();
    }
}
