package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetDeleteSLXPolicyJobExecutor extends AbstractStablenetSLXPolicyJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_DELETE, Job.Type.POLICY_DELETE_DRAFT);
    }

    /**
     * This method builds policy DELETE commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Policy policyToDelete = (Policy) getParentObject(job);
        String command = buildCommand(policyToDelete);
        log.info("Stablenet SLX command generated from Job Id {} on device {} for policy id {} is {}", job.getId(), job.getDevice().getId(), policyToDelete.getId(), command);
        return command;
    }

    protected String buildCommand(Policy policyToDelete) {
        StringBuilder command = new StringBuilder();
        boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(policyToDelete.getFlows().first());
        command.append(CONFIGURE_TERMINAL);
        Set<Port> ingressPorts = Sets.newHashSet();
        Set<PortGroup> ingressPortGroups = new HashSet<>();

        Set<Port> egressPorts = Sets.newHashSet();
        Set<PortGroup> egressPortGroups = new HashSet<>();

        Optional<Flow> flowOptional = policyToDelete.getFlows().stream().findFirst();
        if (flowOptional.isPresent()) {
            Flow flow = flowOptional.get();
            ingressPorts.addAll(flow.getIngressPorts());
            ingressPortGroups.addAll(flow.getIngressPortGroups());
        }
        policyToDelete.getFlows().forEach(flow -> {
            egressPorts.addAll(flow.getEgressPorts());
            egressPortGroups.addAll(flow.getEgressPortGroups());
        });

        Device device = policyToDelete.getDevice();
        ingressPorts.forEach(ingress -> {
            command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
            if (policyToDelete.isIngressValid())
                command.append(NO_INGRESS_VALID_TIMESTAMP);
            if (policyToDelete.isGtpHttpFiltered())
                command.append(NO_DENY_GTP_HTTPS);
            command.append(String.format(isDeviceSLX9850WithUda ? DISABLE_FLEX_PBR : DELETE_POLICY, policyToDelete.getComputedName()));

            //to add delay
            if (!policyToDelete.getFlexMatchProfiles().isEmpty()) {
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));

                policyToDelete.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(NO_WITH_COMMAND, String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName()))));
            }
            command.append(EXIT);
        });

        ingressPortGroups.forEach(portGroup -> {
            command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
            if (policyToDelete.isIngressValid())
                command.append(NO_INGRESS_VALID_TIMESTAMP);
            if (policyToDelete.isGtpHttpFiltered())
                command.append(NO_DENY_GTP_HTTPS);
            command.append(String.format(isDeviceSLX9850WithUda ? DISABLE_FLEX_PBR : DELETE_POLICY, policyToDelete.getComputedName()));

            //to add delay
            if (!policyToDelete.getFlexMatchProfiles().isEmpty()) {
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));

                policyToDelete.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(NO_WITH_COMMAND, String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName()))));
            }
            command.append(EXIT);
        });

        command.append(buildRevertUdaProfileOffset(policyToDelete));

        if (policyToDelete.isTimestamp()) {
            egressPorts.forEach(ingress -> {
                command.append(String.format(INTERFACE_ETHERNET, ingress.getPortNumber()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });

            egressPortGroups.forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });
        }
        List<String> uniqueListOfRulesetNameTobeDeleted = new ArrayList<>();
        policyToDelete.getFlows().forEach(flow -> {
            Set<String> tvfDomainIds = new HashSet<>();
            if (flow.getTvfDomain()) {
                flow.getVlans().forEach(tvfDomainId -> {
                    tvfDomainIds.add(tvfDomainId);
                    flow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == tvfDomainId).forEach(flowEgressManagedObject -> {
                        command.append(String.format(INTERFACE_ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber()));
                        command.append(removePortFromTvfDomain(Sets.newHashSet(tvfDomainId)));
                        command.append(EXIT);
                    });
                    flow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId() == tvfDomainId).forEach(flowEgressManagedObject -> {
                        command.append(String.format(INTERFACE_PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName()));
                        command.append(removePortFromTvfDomain(Sets.newHashSet(tvfDomainId)));
                        command.append(EXIT);
                    });
                });
            }

            command.append(buildRevertFlowCommand(flow, tvfDomainIds, policyToDelete.getComputedName(), uniqueListOfRulesetNameTobeDeleted));

            if (!tvfDomainIds.isEmpty()) {
                tvfDomainIds.forEach(tvfDomainId -> command.append(String.format(REMOVE_TVF_DOMAIN, tvfDomainId)));
            }
        });

        boolean isTelemetryConfigured = false;
        if (device.isProfileConfigured()) {
            isTelemetryConfigured = true;
        } else if (!Strings.isNullOrEmpty(device.getOs()) && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (isSLXSupportsTelemetry(device.getOs()) >= 0) {
                isTelemetryConfigured = true;
            }
        }
        if (isTelemetryConfigured) {
            String interfaceStatsPortsToDelete = ingressPorts.stream().map(port -> port.getPortNumber().trim()).collect(Collectors.joining(","));
            String interfaceStatsPortChannelsToDelete = ingressPortGroups.stream().map(PortGroup::getName).collect(Collectors.joining(","));

            command.append(applyInterfaceAndPbrStats("", "", interfaceStatsPortsToDelete, interfaceStatsPortChannelsToDelete));
        }
        command.append(EXIT);
        return command.toString();
    }

    private String removePortFromTvfDomain(Set<String> tvfDomains) {
        StringBuilder command = new StringBuilder();
        for (String tvfDomainId : tvfDomains) {
            command.append(String.format(REMOVE_INTERFACE_FROM_TVF_DOMAIN, tvfDomainId));
        }
        return command.toString();
    }
}
