package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SdRecoveryPortCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This class builds commands to recover the Egress Port
 */

@Slf4j
@Named
public class RecoverSdPortJobExecutor extends AbstractSdRecoveryJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_EGRESS_PORT_ROLLBACK);
    }

    /**
     * This method builds commands to reoover the Egress Port in error state
     *
     * @param job
     * @return
     */
    public List<CommandBlock> getCommands(Job job) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        Set<EgressPort> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof EgressPort)
                .map(mo -> (EgressPort) mo)
                .collect(Collectors.toSet());
        Integer deviceId = job.getDevice().getStablenetId().intValue();
        if (!ports.isEmpty()) {
            ports.forEach(egressPort -> {
                SdRecoveryPortCommandBlock sdRecoveryPortCommandBlock = new SdRecoveryPortCommandBlock();
                sdRecoveryPortCommandBlock.setDeviceId(deviceId);
                sdRecoveryPortCommandBlock.setName(egressPort.getName());
                commandBlocks.add(sdRecoveryPortCommandBlock);
            });
            if (!commandBlocks.isEmpty()) {
                commandBlocks.get(commandBlocks.size() - 1).setWriteMem("false");
            }
        }
        return commandBlocks;
    }

}
