package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SdSamplingPolicyRecoveryCommandList;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetRecoveryJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class RecoverSdSamplingPolicyJobExecutor extends AbstractSdRecoveryJobExecutor {

    @Inject
    protected SdSamplingPolicyRecoveryCommandList sdSamplingPolicyRecoveryCommandList;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SAMPLING_POLICY_RECOVER);
    }

    /**
     * This method constructs SamplingPolicy recovery commands to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    public List<CommandBlock> getCommands(Job job) {
        SamplingPolicy samplingPolicy = (SamplingPolicy) getParentObject(job);
        List<CommandBlock> commandBlocks = sdSamplingPolicyRecoveryCommandList.constructCommandBlockList(samplingPolicy);
        return commandBlocks;
    }
}
