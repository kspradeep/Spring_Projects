package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;

import javax.inject.Named;

import java.util.List;

/**
 * The StablenetPortRecoveryJobExecutor class implements methods to recover port(s) which are error state on Non Open Flow device through Stablenet
 */
@Named
public class StablenetPortRecoveryJobExecutor extends AbstractStablenetJobExecutor {

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String INTERFACE_ENTER = "interface ethernet %s;";
    private static final String INTERFACE_STATUS = "%s;";
    private static final String INTERFACE_EXIT = "exit;";
    private static final String TERMINAL_EXIT = "end;";
    private static final String SAVE_RUNNING_CONFIG = "write memory;";
    private static final String PORT_UNBLOCK_IN = "no mac access-group DENY_ANY in;";
    private static final String PORT_LOOPBACK_DISABLE = "no loopback system;";
    private static final String PORT_UNBLOCK_OUT = "no mac access-group DENY_ANY out;";
    private static final String PORT_ADMIN_STATUS = "disable";
    private static final String REMOVE_DESCRIPTION = "no port-name;";

    /**
     * This method constructs commands to recover port(s) on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(TERMINAL_ENTER);
        getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .forEach(port -> {
                    commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));
                    commands.append(REMOVE_DESCRIPTION);
                    commands.append(PORT_UNBLOCK_IN);
                    commands.append(PORT_UNBLOCK_OUT);
                    if(port.isLoopbackEnabled()){
                        commands.append(PORT_LOOPBACK_DISABLE);
                    }
                    commands.append(String.format(INTERFACE_STATUS, PORT_ADMIN_STATUS));
                    commands.append(INTERFACE_EXIT);
                });
        commands.append(TERMINAL_EXIT);
        commands.append(SAVE_RUNNING_CONFIG);

        return commands.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }
}
