package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.Rule;
import com.brocade.bvm.model.db.TargetHost;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.bsc.util.BscPolicyDiff;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * The AbstractBscPolicyTransitionExecutor class implements the methods to UPDATE policy based on transitions through BSC
 */
@Slf4j
@Named
public abstract class AbstractBscPolicyTransitionExecutor extends AbstractBscPolicyJobExecutor {

    /**
     * This method is used to update policy if the transition is to multiple EGRESS
     *
     * SI-SE to SI-ME
     * SI-ME to SI-ME
     * MI-SE to SI-ME
     * MI-ME to SI-ME

     * SI-SE to MI-ME
     * SI-ME to MI-ME
     * MI-ME to MI-ME
     * MI-SE to MI-ME
     *
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egressSet
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @param usedFlowIds
     * @param usedGroupNameAndIds
     * @param isEgressChanged
     * @param deleteFlowIds
     * @param ruleOperationMap
     * @return
     */
    protected boolean flowForMultipleEgress(Set<String> grpIds, String deviceId, String policyName, Long policyId,
                                            Map<String, String> portIdNameMap, List<Rule> flatRules, int flowPriority, Set<String> flowIds, Set<String> egressSet,
                                            Set<String> ingressSet, String setVlan, String srcMacTag, String destMacTag, Map<String,String> usedFlowIds, List<String> usedGroupNameAndIds, Boolean isEgressChanged, List<String> deleteFlowIds, Map<String,BscPolicyDiff.RuleOperation> ruleOperationMap, Long bvmDeviceId, boolean vlanStripping, boolean isVlanUpdated, boolean isVlanStrippingUpdated) {
        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        List<String> portIds = new ArrayList<>();
        List<String> portKeys = new ArrayList<>();
        StringBuilder groupName = new StringBuilder(getGroupName(policyId,"lb", flowPriority));

        for (String port : egressSet) {
            String portId = portIdNameMap.get(port);
            portKeys.add(portId);
            if (portId != null)
                portIds.add(portId);
        }
        Collections.sort(portKeys);
        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }
        String groupId = null;
        if(usedGroupNameAndIds.size()>0){
            groupId = usedGroupNameAndIds.get(0);
        }
        else{
            groupId = bscIdGenerator.getGroupId(grpIds);
        }
        grpIds.add(groupId);
        boolean isGroupCreated = true;
        String vlan = setVlan;
        Device device = deviceRepository.findById(bvmDeviceId);
        if (isEgressChanged || isVlanUpdated || isVlanStrippingUpdated) {
            String group = "";
            if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
                group = buildGroupWithVLan(groupId, groupName.toString(), "group-all", portIds, vlan, "", "", vlanStripping);
            } else {
                group = buildGroup(groupId, groupName.toString(), "group-all", portIds);
            }
            isGroupCreated = addGroupOnDevice(deviceId, groupId, group);
        }
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e1) {
            throw new ServerException(e1);
        }
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            vlan = "";
        }
        if (isGroupCreated) {
            for (String port : ingressSet) {
                String ingressPortId = portIdNameMap.get(port);
                if (ingressPortId != null) {
                    for (Rule rule : flatRules) {
                        String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                        String partialFlowName = constructPartialFlowName(ingressPortId,rule.getId());
                        String flowId = null;
                        if(ruleOperationMap.containsKey(partialFlowName)) {
                            BscPolicyDiff.RuleOperation operation = ruleOperationMap.get(partialFlowName);
                            if(operation == BscPolicyDiff.RuleOperation.PUT) {
                                if(usedFlowIds.containsKey(partialFlowName)){
                                    flowId = usedFlowIds.get(partialFlowName);
                                }
                                else{
                                    flowId = bscIdGenerator.getFlowId(flowIds);
                                }
                                String flow = buildFlow(flowId, flowName, ingressPortId, groupId, false, queueId,
                                        rule, flowPriority, vlan, srcMacTag, destMacTag);
                                jobResult = addFlowOnDevice(deviceId, flowId, flow);
                                if (jobResult) {
                                    currentFlowIds.add(flowId);
                                } else {
                                    return false;
                                }
                                if(currentFlowIds.size()%1000 == 0){
                                    waitForFlowToPushOnDevice();
                                    log.debug("Sleeping after flow count reached : "+currentFlowIds.size());
                                }
                            }
                            else if(operation == BscPolicyDiff.RuleOperation.NO_OP){
                                log.info("it is no_operation for flowname "+partialFlowName);
                            }
                        }
                        else{
                            log.info("Key "+partialFlowName+" not present in RuleOperationMap");
                        }
                    }
                }
            }

            for(String deleteFlowId: deleteFlowIds){
                deleteFlowOnDevice(deviceId, deleteFlowId);
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        } else {
            log.info("Add group on Device Failed");
        }
        return jobResult;
    }

    /**
     * This method is used to update policy if the transition is to single EGRESS
     *
     * SI-SE to MI-SE
     * SI-ME to MI-SE
     * MI-SE TO MI-SE
     * MI-ME to MI-SE
     *
     * @param grpIds
     * @param deviceId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egress
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @param usedFlowIds
     * @param usedGroupNameAndIds
     * @param isEgressChanged
     * @param isPGCreationNeeded
     * @param deleteFlowIds
     * @param ruleOperationMap
     * @return
     */
    protected boolean flowForMultipleIngressAndSingleEgress(Set<String> grpIds, String deviceId, String policyName, Long policyId,
                                                            Map<String, String> portIdNameMap, List<Rule> flatRules, int flowPriority, Set<String> flowIds, String egress,
                                                            Set<String> ingressSet, String setVlan, String srcMacTag, String destMacTag, Map<String,String> usedFlowIds, List<String> usedGroupNameAndIds, Boolean isEgressChanged, Boolean isPGCreationNeeded, List<String> deleteFlowIds, Map<String,BscPolicyDiff.RuleOperation> ruleOperationMap, Long bvmDeviceId, boolean vlanStripping, boolean isVlanUpdated, boolean isVlanStrippingUpdated) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        List<String> portIds = new ArrayList<String>();
        List<String> portKeys = new ArrayList<String>();
        StringBuilder groupName = new StringBuilder(getGroupName(policyId,"ag", flowPriority));

        String portId = portIdNameMap.get(egress);
        portKeys.add(portId);
        if (portId != null)
            portIds.add(portId);
        Collections.sort(portKeys);

        for (String key : portKeys) {
            groupName.append("_");
            groupName.append(key);
        }
        String groupId = null;

        if(usedGroupNameAndIds.size()>0){
            groupId = usedGroupNameAndIds.get(0);
        }
        else{
            groupId = bscIdGenerator.getGroupId(grpIds);
        }
        boolean isGroupCreated = true;
        String vlan = setVlan;
        Device device = deviceRepository.findById(bvmDeviceId);
        if (isEgressChanged || isPGCreationNeeded || isVlanUpdated || isVlanStrippingUpdated) {
            String group = "";
            if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
                group = buildGroupWithVLan(groupId, groupName.toString(), "group-indirect", portIds, vlan, "", "", vlanStripping);
            } else {
                group = buildGroup(groupId, groupName.toString(), "group-indirect", portIds);
            }
            isGroupCreated = addGroupOnDevice(deviceId, groupId, group);
        }
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e1) {
            throw new ServerException(e1);
        }
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            vlan = "";
        }
        if (isGroupCreated) {
            for (String port : ingressSet) {
                String ingressPortId = portIdNameMap.get(port);
                if (ingressPortId != null) {
                    for (Rule rule : flatRules) {
                        String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                        String partialFlowName = constructPartialFlowName(ingressPortId,rule.getId());
                        String flowId = null;
                        if(ruleOperationMap.containsKey(partialFlowName)) {
                            BscPolicyDiff.RuleOperation operation = ruleOperationMap.get(partialFlowName);
                            if (operation == BscPolicyDiff.RuleOperation.PUT) {
                                if (usedFlowIds.containsKey(partialFlowName)) {
                                    flowId = usedFlowIds.get(partialFlowName);
                                } else {
                                    flowId = bscIdGenerator.getFlowId(flowIds);
                                }
                                String flow = buildFlow(flowId, flowName, ingressPortId, groupId, false, queueId,
                                        rule, flowPriority, vlan, srcMacTag, destMacTag);
                                jobResult = addFlowOnDevice(deviceId, flowId, flow);
                                if (jobResult) {
                                    currentFlowIds.add(flowId);
                                } else {
                                    return false;
                                }
                                if(currentFlowIds.size()%1000 == 0){
                                    waitForFlowToPushOnDevice();
                                    log.debug("Sleeping after flow count reached : "+currentFlowIds.size());
                                }
                            } else if (operation == BscPolicyDiff.RuleOperation.NO_OP) {
                                log.info("it is no_operation for flowname " + partialFlowName);
                            }
                        }
                        else{
                            log.info("Key "+partialFlowName+" not present in RuleOperationMap");
                        }
                    }
                }
            }
            for(String deleteFlowId: deleteFlowIds){
                deleteFlowOnDevice(deviceId, deleteFlowId);
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        } else {
            log.info("Add group on Device Failed");
        }
        return jobResult;
    }

    /**
     * This method is used to update policy if the transition is to single INGRESS and single EGRESS
     *
     * SI-SE to SI-SE
     * SI-ME to SI-SE
     * MI-SE to SI-SE
     * MI-ME to SI-SE
     *
     * @param deviceId
     * @param policyName
     * @param policyId
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param flowIds
     * @param egress
     * @param ingress
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @param usedFlowIds
     * @param oldPolicyName
     * @param isPGAlreadyPresent
     * @param deleteFlowIds
     * @param ruleOperationMap
     * @param portGroupIds
     * @return
     */
    protected boolean flowForSingleIngressAndSingleEgress(String deviceId, String policyName, Long policyId, Map<String, String> portIdNameMap,
                                                          List<Rule> flatRules, int flowPriority, Set<String> flowIds, String egress, String ingress, String setVlan, String srcMacTag, String destMacTag, Map<String,String> usedFlowIds, String oldPolicyName, boolean isPGAlreadyPresent, List<String> deleteFlowIds, Map<String,BscPolicyDiff.RuleOperation> ruleOperationMap, List<String> portGroupIds) {
        log.info("Creating base flow...");
        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        String egressPortId = portIdNameMap.get(egress);
        String ingressPortId = portIdNameMap.get(ingress);
        log.info("Check : {} - {}", ingressPortId, egressPortId);
        if (egressPortId != null && ingressPortId != null) {
            egressPortId = egressPortId.substring(egressPortId.lastIndexOf(":") + 1, egressPortId.length());
            log.info("Check : {} - {}", ingressPortId, egressPortId);
            for (Rule rule : flatRules) {
                String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                String partialFlowName = constructPartialFlowName(ingressPortId,rule.getId());
                String flowId = null;
                if(ruleOperationMap.containsKey(partialFlowName)) {
                    BscPolicyDiff.RuleOperation operation = ruleOperationMap.get(partialFlowName);
                    if (operation == BscPolicyDiff.RuleOperation.PUT) {
                        if (usedFlowIds.containsKey(partialFlowName)) {
                            flowId = usedFlowIds.get(partialFlowName);
                        } else {
                            flowId = bscIdGenerator.getFlowId(flowIds);
                        }
                        String flow = buildFlow(flowId, flowName, ingressPortId, egressPortId, true, queueId, rule,
                        flowPriority, setVlan, srcMacTag, destMacTag);
                        log.info("flow  : {} ", flow);
                        jobResult = addFlowOnDevice(deviceId, flowId, flow);
                        if(jobResult) {
                            currentFlowIds.add(flowId);
                        }
                        else{
                            return false;
                        }
                        if(currentFlowIds.size()%1000 == 0){
                            waitForFlowToPushOnDevice();
                            log.debug("Sleeping after flow count reached : "+currentFlowIds.size());
                        }
                    }
                    else if (operation == BscPolicyDiff.RuleOperation.NO_OP) {
                        log.info("it is no_operation for flowname " + partialFlowName);
                    }
                }
                else{
                    log.info("Key "+partialFlowName+" not present in RuleOperationMap");
                }
            }
            if(isPGAlreadyPresent) {
                //TODO: Delete port group should be done based on flow id and policy id. Below line is commented because it deletes all the groups in case of multiple flows in a policy.
               // portGroupIds.addAll(getGroupNameWithPolicy(deviceId, policyId));
            }

            for(String deleteFlowId: deleteFlowIds){
                deleteFlowOnDevice(deviceId, deleteFlowId);
            }
            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        }
        return jobResult;
    }

    protected void deletePGAssociatedWithOldPolicy(String deviceId,Long policyId){
        List<String> groupsIdsAssociatedToPolicy = getGroupNameWithPolicy(deviceId, policyId);
        for (String groupId : groupsIdsAssociatedToPolicy) {
            log.info("Delete groups with id : " + groupId);
            deleteGroupOnDevice(deviceId, groupId);
        }
    }

    /**
     * This method is used to delete all PortGroups on the given device
     *
     * @param deviceId
     * @param portGroupIds
     */
    protected void deleteAllPG(String deviceId,List<String> portGroupIds){
        for (String groupId : portGroupIds) {
            log.info("Delete groups with id : " + groupId);
            deleteGroupOnDevice(deviceId, groupId);
        }
    }

    /**
     * This method is used to create flow with Port Group
     * @param deviceId
     * @param flowIds
     * @param portIdNameMap
     * @param flatRules
     * @param flowPriority
     * @param policyName
     * @param portGroups
     * @param ingressSet
     * @param setVlan
     * @param srcMacTag
     * @param destMacTag
     * @param usedFlowIds
     * @param isPGAlreadyPresent
     * @param deleteFlowIds
     * @param ruleOperationMap
     * @param portGroupIds
     * @return
     */
    protected boolean addFlowWithPortGroup(String deviceId, Set<String> flowIds,
                                           Map<String, String> portIdNameMap, List<Rule> flatRules,
                                           int flowPriority, String policyName, Set<PortGroup> portGroups,
                                           Set<String> ingressSet, String setVlan, String srcMacTag, String destMacTag, Map<String,String> usedFlowIds, boolean isPGAlreadyPresent, List<String> deleteFlowIds, Map<String,BscPolicyDiff.RuleOperation> ruleOperationMap, List<String> portGroupIds, Long bvmDeviceId) {

        boolean jobResult = false;
        List<String> currentFlowIds = new ArrayList<>();
        Device device = deviceRepository.findById(bvmDeviceId);
        String vlan = setVlan;
        if (device != null && device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.OPENFLOW) {
            vlan = "";
        }

        if (portGroups != null && portGroups.size() > 0) { // add lag flow
            // here...
            Map<String, String> lagMap = getLagGroupNameIdMap(deviceId,
                    "group-select");
            log.info("Get lag Map : " + lagMap);
            for (PortGroup portGroup : portGroups) {
                String lagId = lagMap.get(portGroup.getName() + "_select");
                for (String port : ingressSet) {
                    String ingressPortId = portIdNameMap.get(port);
                    if (ingressPortId != null) { // add contains ":" check
                        for (Rule rule : flatRules) {
                            String flowId = null;
                            String flowName = constructBscFlowName(policyName,ingressPortId,rule.getId());
                            String partialFlowName = constructPartialFlowName(ingressPortId,rule.getId());
                            if(ruleOperationMap.containsKey(partialFlowName)) {
                                BscPolicyDiff.RuleOperation operation = ruleOperationMap.get(partialFlowName);
                                if (operation == BscPolicyDiff.RuleOperation.PUT) {
                                    if (usedFlowIds.containsKey(partialFlowName)) {
                                        flowId = usedFlowIds.get(partialFlowName);
                                    } else {
                                        flowId = bscIdGenerator.getFlowId(flowIds);
                                    }
                                    String flow = buildFlow(flowId,
                                                    flowName.toString(), ingressPortId, lagId,
                                                    false, queueId, rule, flowPriority,vlan,srcMacTag,destMacTag);
                                    jobResult = addFlowOnDevice(deviceId, flowId, flow);
                                    if(jobResult){
                                        currentFlowIds.add(flowId);
                                    }
                                    else {
                                        return false;
                                    }
                                    if(currentFlowIds.size()%1000 == 0){
                                        waitForFlowToPushOnDevice();
                                        log.debug("Sleeping after flow count reached : "+currentFlowIds.size());
                                    }
                                }
                                else if (operation == BscPolicyDiff.RuleOperation.NO_OP) {
                                    log.info("it is no_operation for flowname " + partialFlowName);
                                }
                            }
                            else{
                                log.info("Key "+partialFlowName+" not present in RuleOperationMap");
                            }
                        }
                    }
                }
            }
            if(isPGAlreadyPresent) {
                //TODO: Delete port group should be done based on flow id and policy id. Below line is commented because it deletes all the groups in case of multiple flows in a policy.
             //   portGroupIds.addAll(getGroupNameWithPolicy(deviceId, policyId));
            }

            for(String deleteFlowId: deleteFlowIds){
                deleteFlowOnDevice(deviceId, deleteFlowId);
            }

            jobResult = verifyFlow(deviceId,currentFlowIds,true);

        }
        return jobResult;
    }

    /**
     * This method used to build portGroup xml
     *
     * @param id
     * @param name
     * @param type
     * @param portIds
     * @return String This returns portGroup xml as a String
     */
    protected String buildPortGroup(String id, String name, String type, List<String> portIds) {

        StringBuilder resultXml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        resultXml.append("<group xmlns=\"urn:opendaylight:flow:inventory\">");
        resultXml.append("<group-type>");
        resultXml.append(type);
        resultXml.append("</group-type>");
        resultXml.append("<buckets>");

        int i = 1;
        for (String portid : portIds) {

            resultXml.append("<bucket>");
            resultXml.append("<weight>1</weight>");
            resultXml.append("<action>");
            resultXml.append("<output-action>");
            resultXml.append("<output-node-connector>");
            resultXml.append(portid);
            resultXml.append("</output-node-connector>");
            resultXml.append("</output-action>");
            resultXml.append("<order>1</order>");
            resultXml.append("</action>");
            resultXml.append("<bucket-id>");
            resultXml.append(Integer.toString(i));
            resultXml.append("</bucket-id>");
            resultXml.append("</bucket>");
            i++;
        }

        resultXml.append("</buckets>");
        resultXml.append("<barrier>false</barrier>");
        resultXml.append("<group-name>");
        resultXml.append(name);
        resultXml.append("</group-name>");
        resultXml.append("<group-id>");
        resultXml.append(id);
        resultXml.append("</group-id>");
        resultXml.append("</group>");

        return resultXml.toString();
    }
}
