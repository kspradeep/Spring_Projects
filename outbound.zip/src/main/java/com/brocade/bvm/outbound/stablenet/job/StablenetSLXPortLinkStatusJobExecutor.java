package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetSLXPortLinkStatusJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    private static final String SHOW_INTERFACE_ETHERNET = "show interface ethernet %s;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_LINK_STATUS);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX, Device.Type.MLXE);
    }

    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder();
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        StringBuilder portBuilder = new StringBuilder();
        portBuilder.append(CONFIGURE_TERMINAL);
        ports.stream().forEach(port -> {
            portBuilder.append(String.format(INTERFACE_ETHERNET_DISABLE_BREAKOUT, port.getPortNumber().trim()));
            portBuilder.append(EXIT);
        });
        portBuilder.append(EXIT);
        ports.stream().forEach(port -> {
            portBuilder.append(String.format(SHOW_INTERFACE_ETHERNET, port.getPortNumber().trim()));
        });
        commands.append(portBuilder.toString());
        log.info("StablenetSLXPortLinkStatusJobExecutor command generated from Job Id {} on device {}  command: {}", job.getId(), job.getDevice().getId(), commands.toString());
        return commands.toString();
    }
}
