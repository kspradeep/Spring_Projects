package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class StablenetCommitSLXPacketTruncationJobExecutor extends AbstractStablenetSLXPacketTruncationJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_TRUNCATION_PROFILE_CREATE, Job.Type.PACKET_TRUNCATION_PROFILE_UPDATE);
    }

    /**
     * This method builds packet truncation COMMIT commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();
        PacketTruncationMapping packetTruncationMapping = (PacketTruncationMapping) getParentObject(job);
        if (job.getType() == Job.Type.PACKET_TRUNCATION_PROFILE_CREATE) {
            command.append(buildCommandForCreateTruncationProfile(packetTruncationMapping));
        } else if (job.getType() == Job.Type.PACKET_TRUNCATION_PROFILE_UPDATE) {
            command.append(buildCommandForUpdateTruncationProfile(packetTruncationMapping));
        }
        log.info("Stablenet SLX command generated from Job Id {} on device {} for packet truncation id {} is {}", job.getId(), job.getDevice().getId(), packetTruncationMapping.getId(), command.toString());
        return command.toString();
    }

    /**
     * Commands to create packet truncation profile
     *
     * @param packetTruncationMapping
     * @return
     */
    public String buildCommandForCreateTruncationProfile(PacketTruncationMapping packetTruncationMapping) {
        StringBuilder command = new StringBuilder();
        if (packetTruncationMapping.getPacketTruncation() != null) {
            command.append(CONFIGURE_TERMINAL);
            Port port = packetTruncationMapping.getPort();
            PortGroup portGroup = packetTruncationMapping.getPortGroup();
            if ((port != null && !port.isLoopbackEnabled()) || (portGroup != null && !portGroup.isMinimumLinkEnabled())) {
                if (port != null) {
                    command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                } else if (portGroup != null) {
                    command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                }
                command.append(buildCommandForLoopBack());
            }
            command.append(String.format(TRUNCATION_PROFILE_NAME, packetTruncationMapping.getPacketTruncation().getName()));
            command.append(String.format(FRAME_SIZE, packetTruncationMapping.getPacketTruncation().getFrameSize()));
            if (packetTruncationMapping.getPort() != null) {
                command.append(String.format(SET_INTERFACE_ETHERNET, packetTruncationMapping.getPort().getPortNumber()));
            } else {
                command.append(String.format(SET_INTERFACE_PORT_CHANNEL, packetTruncationMapping.getPortGroup().getName()));
            }
            command.append(EXIT);
            command.append(EXIT);
        }
        return command.toString();
    }

    /**
     * Commands to update packet truncation profile
     *
     * @param packetTruncationMapping
     * @return
     */
    public String buildCommandForUpdateTruncationProfile(PacketTruncationMapping packetTruncationMapping) {
        StringBuilder command = new StringBuilder();
        Long oldInterfaceChannel = null;
        Long interfaceChannel = null;
        PacketTruncationMapping oldPacketTruncationMapping = null;
        if (packetTruncationMapping != null && packetTruncationMapping.getPacketTruncation() != null) {
            command.append(CONFIGURE_TERMINAL);
            if (packetTruncationMapping.getId() != null) {
                oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMapping.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                if (oldPacketTruncationMapping.getPort() != null && oldPacketTruncationMapping.getPort().getId() != null) {
                    oldInterfaceChannel = oldPacketTruncationMapping.getPort().getId();
                } else if (oldPacketTruncationMapping.getPortGroup() != null && oldPacketTruncationMapping.getPortGroup().getId() != null) {
                    oldInterfaceChannel = oldPacketTruncationMapping.getPortGroup().getId();
                }
            }
            if (oldPacketTruncationMapping != null) {
                Port port = packetTruncationMapping.getPort();
                PortGroup portGroup = packetTruncationMapping.getPortGroup();
                if (port != null && port.getId() != null) {
                    interfaceChannel = port.getId();
                } else if (portGroup != null && portGroup.getId() != null) {
                    interfaceChannel = portGroup.getId();
                }
                if (interfaceChannel != null && oldInterfaceChannel != null && !interfaceChannel.equals(oldInterfaceChannel)) {
                    if (port != null && !port.isLoopbackEnabled()) {
                        command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                        command.append(buildCommandForLoopBack());
                    } else if (portGroup != null && !portGroup.isLoopbackEnabled()) {
                        command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                        command.append(buildCommandForLoopBack());
                    }
                }
                command.append(String.format(TRUNCATION_PROFILE_NAME, packetTruncationMapping.getPacketTruncation().getName()));
                if (packetTruncationMapping.getPacketTruncation() != null && oldPacketTruncationMapping.getPacketTruncation() != null && !packetTruncationMapping.getPacketTruncation().getFrameSize().equals(oldPacketTruncationMapping.getPacketTruncation().getFrameSize())) {
                    command.append(String.format(FRAME_SIZE, packetTruncationMapping.getPacketTruncation().getFrameSize()));
                }
            }
            if (interfaceChannel != null && oldInterfaceChannel != null && !interfaceChannel.equals(oldInterfaceChannel)) {
                Port port = packetTruncationMapping.getPort();
                PortGroup portGroup = packetTruncationMapping.getPortGroup();
                if (port != null) {
                    command.append(NO_INTERFACE_ETHERNET);
                    command.append(String.format(SET_INTERFACE_ETHERNET, port.getPortNumber()));
                } else if (portGroup != null) {
                    command.append(NO_INTERFACE_PORT_CHANNEL);
                    command.append(String.format(SET_INTERFACE_PORT_CHANNEL, portGroup.getName()));
                }
            }
            command.append(EXIT);
            command.append(EXIT);
        }
        return command.toString();
    }

    private String buildCommandForLoopBack() {
        StringBuilder command = new StringBuilder();
        command.append(SHUTDOWN);
        command.append(CONVERT_LOOPBACK_PORT);
        command.append(NO_SHUTDOWN);
        command.append(EXIT);
        return command.toString();
    }
}
