package com.brocade.bvm.outbound.stablenet.commands.recovery;

import java.util.ArrayList;
import java.util.List;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;

import lombok.Getter;
import lombok.Setter;

public class L2AclCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String aclName;

    @Getter
    @Setter
    private String writeMem = "false";
    
    private static final String PRE_CMD = "conf t;";
    private static final String SHOW_CMD = "show access-list l2 %s";
    private static final String MATCH_CMD = "entries";
    private static final String ACTION_CMD = "no mac access-list %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, aclName));
        args.add(MATCH_CMD);
        args.add(String.format(ACTION_CMD, aclName));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "L2AclCommandBlock [deviceId=" + deviceId + ", aclName=" + aclName + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof L2AclCommandBlock)) return false;

        L2AclCommandBlock that = (L2AclCommandBlock) o;

        if (getDeviceId() != null ? !getDeviceId().equals(that.getDeviceId()) : that.getDeviceId() != null)
            return false;
        if (getAclName() != null ? !getAclName().equals(that.getAclName()) : that.getAclName() != null) return false;
        return getWriteMem() != null ? getWriteMem().equals(that.getWriteMem()) : that.getWriteMem() == null;

    }

    @Override
    public int hashCode() {
        int result = getDeviceId() != null ? getDeviceId().hashCode() : 0;
        result = 31 * result + (getAclName() != null ? getAclName().hashCode() : 0);
        result = 31 * result + (getWriteMem() != null ? getWriteMem().hashCode() : 0);
        return result;
    }
}
