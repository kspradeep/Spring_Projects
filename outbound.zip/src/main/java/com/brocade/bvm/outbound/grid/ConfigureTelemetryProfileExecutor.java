package com.brocade.bvm.outbound.grid;

import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.ManagedObjectRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigInteger;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Class configures the telemetry default profiles on the device
 */
@Named
@Slf4j
public class ConfigureTelemetryProfileExecutor extends AbstractStablenetJobExecutor {

    @Value("${telemetry.collector.interval.seconds:30}")
    private Integer telemetryCollectorInterval;

    @Value("${telemetry.system.utilization.collector.interval.seconds:60}")
    private Integer telemetrySystemUtilizationCollectorInterval;

    @Value("${telemetry.pbr.collector.interval.seconds:60}")
    private Integer telemetryPbrCollectorInterval;

    @Value("${telemetry.collector.default.port:54322}")
    private Integer telemetryCollectorPort;

    @Value("${telemetry.collector.ip.address}")
    private String telemetryCollectorIpAddress;

    @Value("${telemetry.collector.name:telemetryCollector}")
    private String telemetryCollectorName;

    private static final String TELEMETRY_COLLECTOR_NAME = "telemetry collector %s;";

    private static final String TELEMETRY_COLLECTOR_IPV4_PORT = "ip %s port %d;";

    private static final String TELEMETRY_COLLECTOR_IPV6_PORT = "ipv6 %s port %d;";

    private static final String TELEMETRY_COLLECTOR_PROFILE = "telemetry profile %s %s;";

    private static final String PROFILE = "profile %s %s;";

    private static final String TELEMETRY_PROFILE = "telemetry profile %s %s;";

    private static final String TELEMETRY_COLLECTOR_INTERVAL = "interval %d;";

    private static final String ENCODING_JSON = "encoding json;";

    private static final String TELEMETRY_COLLECTOR_ACTIVATE = "activate;";

    private static final String TELEMETRY_COLLECTOR_NO_ACTIVATE = "no activate;";

    private static final String NO = "no ";

    private static final String TELEMETRY_SYNC = "sync %s;";

    private static final String PROTOCOL_LLDP = "protocol lldp;";

    private static final String ADVERTISE_DOT1_TLV = "advertise dot1-tlv;";

    private static final String ADVERTISE_DOT3_TLV = "advertise dot3-tlv;";

    private static final String SYSTEM_DESCRIPTION = "system-description %s;";

    private static final String INTERFACE_ETHERNET_ALL = "interface ethernet all;";
    private static final String INTERFACE_PORT_CHANNEL_ALL = "interface port-channel all;";
    private static final String LLDP = "lldp";
    private static final String NO_IP = "no ip;";
    private static final String NO_IPV6 = "no ipv6;";
    private static final String SYSTEM_UTILIZATION = "system-utilization";
    private static final String INTERFACE = "interface";
    private static final String EVENT_PROFILE = "event-profile";
    private static final String INTERFACE_PROFILE = "interface-profile";
    private static final String PBR = "pbr";
    private static final String SYSTEM_PROFILE = "system-profile";
    private static final String DEFAULT_LLDP_STATISTICS = "default_lldp_statistics";
    private static final String DEFAULT_SYSTEM_UTILIZATION_STATISTICS = "default_system_utilization_statistics";
    private static final String DEFAULT_INTERFACE_STATISTICS = "default_interface_statistics";
    private static final String DEFAULT_EVENT_STATISTICS = "default_event_statistics";
    private static final String DEFAULT_PBR_STATISTICS = "default_pbr_statistics";
    private static final String INTERFACE_ADD_RANGE = "interface %s add %s;";
    private static final String PORT_CHANNEL = "port-channel";
    private static final String ETHERNET = "ethernet";

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    private ManagedObjectRepository managedObjectRepository;

    /**
     * This method constructs CLI to configure the telemetry profile on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();

        Device device = job.getDevice();
        if (Job.Type.CONFIG_TELEMETRY_PROFILE == job.getType() || Job.Type.UPDATE_TELEMETRY_PROFILE == job.getType()) {
            command.append(configTelemetryCollector(device));
        } else if (Job.Type.RECONFIG_TELEMETRY_PROFILE == job.getType()) {
            command.append(reconfigTelemetryCollector());
        } else if (Job.Type.DELETE_TELEMETRY_PROFILE == job.getType()) {
            command.append(CONFIGURE_TERMINAL);
            command.append(deleteTelemetryCollector());
            command.append(EXIT);
        }
        log.debug("ConfigureTelemetryProfileExecutor {} on device: {} command: {} ", job.getType(), device.getId(), command);
        return command.toString();
    }

    public String configTelemetryCollector(Device device) {
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(deleteTelemetryCollector());
        command.append(String.format(TELEMETRY_COLLECTOR_PROFILE, LLDP, DEFAULT_LLDP_STATISTICS));
        command.append(String.format(TELEMETRY_SYNC, true));
        command.append(INTERFACE_ETHERNET_ALL);
        command.append(EXIT);
        command.append(String.format(TELEMETRY_COLLECTOR_PROFILE, SYSTEM_UTILIZATION, DEFAULT_SYSTEM_UTILIZATION_STATISTICS));
        if (telemetrySystemUtilizationCollectorInterval != null) {
            command.append(String.format(TELEMETRY_COLLECTOR_INTERVAL, telemetrySystemUtilizationCollectorInterval));
        }
        command.append(EXIT);
        command.append(String.format(TELEMETRY_COLLECTOR_PROFILE, INTERFACE, DEFAULT_INTERFACE_STATISTICS));
        if (telemetryCollectorInterval != null) {
            command.append(String.format(TELEMETRY_COLLECTOR_INTERVAL, telemetryCollectorInterval));
        }
        command.append(EXIT);
        command.append(String.format(TELEMETRY_COLLECTOR_PROFILE, PBR, DEFAULT_PBR_STATISTICS));
        if (telemetryPbrCollectorInterval != null) {
            command.append(String.format(TELEMETRY_COLLECTOR_INTERVAL, telemetryPbrCollectorInterval));
        }
        command.append(EXIT);

        command.append(buildCollectorConfigCommands());

        command.append(PROTOCOL_LLDP);
        command.append(ADVERTISE_DOT1_TLV);
        command.append(ADVERTISE_DOT3_TLV);
        if (device.getModel() != null) {
            command.append(String.format(SYSTEM_DESCRIPTION, device.getModel()));
        }
        command.append(EXIT);

        command.append(String.format(TELEMETRY_PROFILE, INTERFACE, DEFAULT_INTERFACE_STATISTICS));
        command.append(INTERFACE_ETHERNET_ALL);
        command.append(INTERFACE_PORT_CHANNEL_ALL);
        command.append(EXIT);
        command.append(configurePbrInterfaces(device));
        command.append(EXIT);
        return command.toString();
    }

    private String reconfigTelemetryCollector() {
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(buildCollectorConfigCommands());
        command.append(EXIT);
        return command.toString();
    }

    private String buildCollectorConfigCommands() {
        StringBuilder command = new StringBuilder();
        if (telemetryCollectorName != null && telemetryCollectorIpAddress != null && telemetryCollectorPort != null) {
            command.append(String.format(TELEMETRY_COLLECTOR_NAME, telemetryCollectorName));
            command.append(TELEMETRY_COLLECTOR_NO_ACTIVATE);
            command.append(NO_IP);
            command.append(NO_IPV6);
            String telemetryIPConfig = String.format(telemetryCollectorIpAddress.contains(":") ? TELEMETRY_COLLECTOR_IPV6_PORT : TELEMETRY_COLLECTOR_IPV4_PORT, telemetryCollectorIpAddress, telemetryCollectorPort);
            if (telemetryIPConfig != null) {
                command.append(telemetryIPConfig);
                command.append(String.format(PROFILE, LLDP, DEFAULT_LLDP_STATISTICS));
                command.append(String.format(PROFILE, SYSTEM_PROFILE, DEFAULT_SYSTEM_UTILIZATION_STATISTICS));
                command.append(String.format(PROFILE, INTERFACE_PROFILE, DEFAULT_INTERFACE_STATISTICS));
                command.append(String.format(PROFILE, EVENT_PROFILE, DEFAULT_EVENT_STATISTICS));
                command.append(String.format(PROFILE, PBR, DEFAULT_PBR_STATISTICS));
                command.append(ENCODING_JSON);
                command.append(TELEMETRY_COLLECTOR_ACTIVATE);
            }
            command.append(EXIT);
        }
        return command.toString();
    }

    /**
     * Deleting the telemetry collector configuration from device
     *
     * @return
     */
    public String deleteTelemetryCollector() {
        StringBuilder command = new StringBuilder();
        command.append(String.format(TELEMETRY_COLLECTOR_NAME, telemetryCollectorName));
        command.append(TELEMETRY_COLLECTOR_NO_ACTIVATE);
        command.append(EXIT);
        command.append(NO).append(String.format(TELEMETRY_COLLECTOR_NAME, telemetryCollectorName));
        return command.toString();
    }

    /**
     * Configure PBR interfaces on device.
     *
     * @param device
     */
    public String configurePbrInterfaces(Device device) {
        StringBuilder command = new StringBuilder();
        if (device != null && isSLXSupportsTelemetry(device.getOs()) >= 0) {
            List<BigInteger> ingressInterfaces = flowRepository.findManagedObjectIdsByDeviceId(device.getId());
            if (!ingressInterfaces.isEmpty()) {
                Set<ManagedObject> managedObjectSet = Sets.newHashSet(managedObjectRepository.findAll(ingressInterfaces.stream().map(id -> id.longValue()).collect(Collectors.toSet())));
                if (!managedObjectSet.isEmpty()) {
                    Set<String> portNames = Sets.newHashSet();
                    Set<String> portChannelNames = Sets.newHashSet();
                    managedObjectSet.forEach(managedObject -> {
                        if (managedObject instanceof Port) {
                            portNames.add((((Port) managedObject).getPortNumber()).trim());
                        } else if (managedObject instanceof PortGroup) {
                            portChannelNames.add(managedObject.getName().trim());
                        }
                    });
                    String interfacePortsToAdd = portNames.stream().collect(Collectors.joining(","));
                    String interfacePortChannelsToAdd = portChannelNames.stream().collect(Collectors.joining(","));
                    command.append(String.format(TELEMETRY_PROFILE, PBR, DEFAULT_PBR_STATISTICS));
                    if (!interfacePortsToAdd.isEmpty())
                        command.append(String.format(INTERFACE_ADD_RANGE, ETHERNET, interfacePortsToAdd));
                    if (!interfacePortChannelsToAdd.isEmpty())
                        command.append(String.format(INTERFACE_ADD_RANGE, PORT_CHANNEL, interfacePortChannelsToAdd));
                    command.append(EXIT);
                }
            }
        }
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.CONFIG_TELEMETRY_PROFILE, Job.Type.RECONFIG_TELEMETRY_PROFILE, Job.Type.UPDATE_TELEMETRY_PROFILE, Job.Type.DELETE_TELEMETRY_PROFILE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
