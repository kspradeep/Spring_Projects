package com.brocade.bvm.outbound.cli;

import lombok.Builder;
import lombok.Getter;

/**
 * Represent an executable command and its corresponding command to undo the operation.
 */
@Builder(builderMethodName = "requiredArgsBuilder")
@Getter
public class CommandLet {
	private final String command;
	private String undoCommand;
	private boolean needsParam;
	
	public static CommandLetBuilder builder(String command) {
		return requiredArgsBuilder().command(command);
	}
	
	public String getUndoCommand() {
		return undoCommand != null ? undoCommand : command;
	}
}
