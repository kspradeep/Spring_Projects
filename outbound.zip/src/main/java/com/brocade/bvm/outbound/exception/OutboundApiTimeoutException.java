package com.brocade.bvm.outbound.exception;

import lombok.Getter;

@Getter
public class OutboundApiTimeoutException extends OutboundApiException {
    private String apiResponse;
    public OutboundApiTimeoutException(String message, String apiResponse) {
        super(message);
        this.apiResponse = apiResponse;
    }
}
