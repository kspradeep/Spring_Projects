package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.GtpDeEncapsulationModulePolicyHistoryRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.GtpDeEncapsulationModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.GtpDeEncapsulationModulePolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Named
@Slf4j
public class GtpDeEncapsulationModulePolicyUpdateJobExecutor extends AbstractGtpDeEncapsulationModulePolicyJobExecutor {
    @Inject
    private GtpDeEncapsulationModulePolicyHistoryRepository modulePolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;

    /**
     * This method constructs update GtpDeEncapsulationModulePolicyUpdate commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        GtpDeEncapsulationModulePolicy modulePolicy = (GtpDeEncapsulationModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        if (modulePolicy != null) {
            GtpDeEncapsulationModulePolicy oldModulePolicy = getGtpDeEncapsulationModulePolicyFromHistory(modulePolicy.getId());

            Set<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> newPortIds = modulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());

            //removing GtpDeEncapsulation from unselected ports during edit
            oldModulePolicy.getPorts().forEach(oldPort -> {
                if (!newPortIds.contains(oldPort.getId())) {
                    command.append(String.format(INTERFACE_ETHERNET, oldPort.getPortNumber()));
                    command.append(NO_GTP_DE_ENCAPSULATION);
                }
            });

            //adding GtpDeEncapsulation to newly selected ports during edit
            modulePolicy.getPorts().forEach(newPort -> {
                if (!oldPortIds.contains(newPort.getId())) {
                    command.append(String.format(INTERFACE_ETHERNET, newPort.getPortNumber()));
                    command.append(GTP_DE_ENCAPSULATION);
                }
            });
        }
        command.append(EXIT);
        command.append(WRITE_MEMORY);
        log.debug("GtpDeEncapsulationUPDATE on Device-ID {} Command  {}", modulePolicy.getDevice().getId(), command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestModulePolicyId
     * @return GtpDeEncapsulationModulePolicy returns latest ACTIVE policy
     */
    private GtpDeEncapsulationModulePolicy getGtpDeEncapsulationModulePolicyFromHistory(Long latestModulePolicyId) {
        List<GtpDeEncapsulationModulePolicyHistory> gtpDeEncapsulationModulePolicyHistoryList = modulePolicyHistoryRepository.findByIdAndWorkflowStatus(latestModulePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GtpDeEncapsulationModulePolicy modulePolicy = null;
        if (gtpDeEncapsulationModulePolicyHistoryList.size() >= 1) {
            GtpDeEncapsulationModulePolicyHistory gtpDeEncapsulationModulePolicyHistory = gtpDeEncapsulationModulePolicyHistoryList.get(0);
            modulePolicy = gtpDeEncapsulationModulePolicyHistory.buildParent();
        }
        return modulePolicy;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_UPDATE);
    }
}
