package com.brocade.bvm.outbound.firmware.job;

import com.brocade.bvm.dao.DeviceFirmwareInfoRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.FirmwareJobRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.model.db.FirmwareJob;
import com.brocade.bvm.outbound.FirmwareOutboundJobResponse;
import com.brocade.bvm.outbound.firmware.job.util.CliConstants;
import com.brocade.bvm.outbound.firmware.job.util.Response;
import com.brocade.bvm.outbound.firmware.job.util.SshConnection;
import com.brocade.bvm.outbound.stablenet.service.StablenetRediscoveryService;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
public class SLXRebootJobExecutor extends AbstractFirmwareJobExecutor {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private DeviceFirmwareInfoRepository deviceFirmwareInfoRepository;

    @Inject
    private StablenetRediscoveryService stablenetRediscoveryService;

    @Inject
    private FirmwareJobRepository firmwareJobRepository;

    @Inject
    private ApplicationContext applicationContext;

    private static final Pattern SLX_VERSION_REGEX = Pattern.compile("(slxos)(\\d+)([a-z])(\\.)(\\d+)(\\.)(\\d+)(_)(bld)(\\d+)", Pattern.CASE_INSENSITIVE);

    private static final String SLX_RELOAD_CMD = "reload";

    private static final String SLX_SHOW_VERSION_CMD = "show version";

    @Override
    public List<FirmwareJob.Type> getSupportedJobTypes() {
        return Lists.newArrayList(FirmwareJob.Type.DEVICE_RELOAD);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    @Override
    public FirmwareOutboundJobResponse executeOutboundJob(FirmwareJob firmwareJob) {
        log.debug("SLX Reboot executeOutboundJob");
        FirmwareJob firmwareJob1 = firmwareJobRepository.findOne(firmwareJob.getId());
        if (firmwareJob1 != null) {
            firmwareJob1.setStatus(FirmwareJob.Status.SUBMITTED);
            firmwareJobRepository.save(firmwareJob1);
        }

        DeviceFirmwareInfo deviceFirmwareInfo = deviceFirmwareInfoRepository.findOne(firmwareJob.getParentObjectId());
        FirmwareOutboundJobResponse firmwareOutboundJobResponse = new FirmwareOutboundJobResponse();
        Device device = deviceFirmwareInfo.getDevice();
        if (deviceFirmwareInfo != null) {
            log.debug("Reboot of {}", device.getIpAddress());
            try {
                String firmware = deviceFirmwareInfo.getFirmwareName();
                List<String> cmds = new ArrayList<>();
                cmds.add(SLX_RELOAD_CMD);
                /* connect and execute reload command*/
                SshConnection sshConnection = applicationContext.getBean(SshConnection.class);
                List<Response> responses = connectAndExecuteCommand(deviceFirmwareInfo, cmds, sshConnection);
                if (responses != null && !responses.isEmpty()) {
                    responses.forEach(response -> {
                        if (response.getValue().contains(sshConnection.SLX_REBOOT_PROMPT)) {
                            try {
                                Thread.sleep(300000); // wait for 4 mins to let SLX restart
                            } catch (Exception e) {
                                log.error("Reboot of {} device failed due to {}", device.getIpAddress(), e.getMessage());
                            }
                            try {
                                List<String> cmds1 = new ArrayList<>();
                                cmds1.add(SLX_SHOW_VERSION_CMD);
                                /*connect again and check for the upgraded slx version*/
                                List<Response> responses1 = connectAndExecuteCommand(deviceFirmwareInfo, cmds1, sshConnection);
                                if (responses1 != null && !responses1.isEmpty()) {
                                    responses1.forEach(response1 -> {
                                        if (response1.getValue().contains(getFirmwareVersion(firmware))) {
                                            String updatedOsVersion = getOsVersionFromResponse(response1.getValue());
                                            firmwareOutboundJobResponse.setStatus(FirmwareJob.Status.SUCCESS);
                                            firmwareOutboundJobResponse.setJobResult(response1.getValue());
                                            if (Strings.isNullOrEmpty(updatedOsVersion)) {
                                                updatedOsVersion = deviceFirmwareInfo.getFirmwareName();
                                            }
                                            syncOsAndTacInfo(device, updatedOsVersion);
                                            stablenetRediscoveryService.rediscoverStablenetDevice(device);
                                        } else {
                                            firmwareOutboundJobResponse.setStatus(FirmwareJob.Status.FAILED);
                                            firmwareOutboundJobResponse.setJobResult(response1.getValue());
                                        }
                                    });
                                }
                            } catch (Exception e) {
                                log.error("Reboot of {} device failed due to {}", device.getIpAddress(), e.getMessage());
                            }
                        } else {
                            firmwareOutboundJobResponse.setStatus(FirmwareJob.Status.FAILED);
                            firmwareOutboundJobResponse.setJobResult(response.getValue());
                        }
                    });
                }
                sshConnection.disconnect();
            } catch (Exception e) {
                log.error("Reboot of {} device failed due to {}", device.getIpAddress(), e.getMessage());
                firmwareOutboundJobResponse.setStatus(FirmwareJob.Status.FAILED);
                firmwareOutboundJobResponse.setJobResult(e.getMessage());
            }
        }
        log.debug("Reboot of {} device {}", device.getIpAddress(), firmwareOutboundJobResponse.getStatus());
        return firmwareOutboundJobResponse;
    }

    private List<Response> connectAndExecuteCommand(final DeviceFirmwareInfo deviceFirmwareInfo, List<String> cmds, SshConnection sshConnection) throws Exception {
        sshConnection.connect(deviceFirmwareInfo.getDevice().getIpAddress(), deviceFirmwareInfo.getUsername(), deviceFirmwareInfo.getPassword());
        sshConnection.readData();
        List<Response> responses = sshConnection.executeCommand(cmds, CliConstants.AccessMode.CONFIG_MODE);
        return responses;
    }

    private String getFirmwareVersion(String firmware) {
        Matcher m = SLX_VERSION_REGEX.matcher(firmware);
        StringBuilder sb = new StringBuilder();
        if (m.find()) {
            sb.append(m.group(2));
            sb.append(m.group(3));
            sb.append(m.group(4));
            sb.append(m.group(5));
            sb.append(m.group(6));
            sb.append(m.group(7));
            sb.append(m.group(8));
            sb.append(m.group(9));
            sb.append(m.group(10));
        }
        return sb.toString();
    }

}
