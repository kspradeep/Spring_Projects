package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterRule;
import com.google.common.collect.Lists;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This class is used to build command for Update SD Filter Policy
 */
@Slf4j
@Named
public class UpdateSdFilterPolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_FILTER_POLICY_UPDATE);
    }

    @Override
    public String getCommands(Job job) {
        FilterPolicy newFilterPolicy = (FilterPolicy) getParentObject(job);
        FilterPolicy filterPolicyFromHistory = getFilterPolicyFromHistory(newFilterPolicy.getId());
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(FILTER);
        command.append(EDIT).append(String.format(FILTER_POLICY, newFilterPolicy.getName()));
        if (filterPolicyFromHistory.isPreserveCplane() && !newFilterPolicy.isPreserveCplane()) {
            command.append(CLEAR).append(PRESERVE_CPLANE);
        } else {
            command.append(SET).append(PRESERVE_CPLANE);
        }
        command.append(SET).append(String.format(TRAFFICTYPE, newFilterPolicy.getTrafficType()));


        List<FilterRule> oldFilterPolicyRules = getFilterRules(filterPolicyFromHistory);
        List<FilterRule> newFilterPolicyRules = getFilterRules(newFilterPolicy);
        command = getUpdateCommand(oldFilterPolicyRules, newFilterPolicyRules, command, newFilterPolicy.getDevice());
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
