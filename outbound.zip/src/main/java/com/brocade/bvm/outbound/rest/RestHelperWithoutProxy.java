package com.brocade.bvm.outbound.rest;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.outbound.AbstractRestConnection;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;

@Slf4j
@Named
public class RestHelperWithoutProxy extends AbstractRestConnection {

    @Value("${rest.connection.timeout.seconds:120}")
    private Integer restConnectionTimeoutSeconds;

    @Inject
    private ConfigRepository configRepository;

    protected String getBaseUrl() {
        return "";
    }

    protected Client getClient() {

        Client client = new JerseyClientBuilder()
                .sslContext(sslContext())
                .hostnameVerifier(hostnameVerifier()).build()
                .register(HttpAuthenticationFeature.basic(configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue(),
                        configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue()));
        client.property(ClientProperties.CONNECT_TIMEOUT, (restConnectionTimeoutSeconds * 1000));
        client.property(ClientProperties.READ_TIMEOUT, (restConnectionTimeoutSeconds * 1000));
        return client;
    }
}
