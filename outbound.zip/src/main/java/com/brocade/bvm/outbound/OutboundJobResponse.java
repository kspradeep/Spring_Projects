package com.brocade.bvm.outbound;

import com.brocade.bvm.model.db.Job;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
@AllArgsConstructor
public class OutboundJobResponse {
    private Job.Status status;
    private String jobResult;
}
