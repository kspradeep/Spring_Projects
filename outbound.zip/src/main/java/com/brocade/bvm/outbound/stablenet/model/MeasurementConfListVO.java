package com.brocade.bvm.outbound.stablenet.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "collection")
@Getter
@Setter
@ToString
public class MeasurementConfListVO {
    List<SnmpInterface> snmpinterface;
    Ping ping;
}
