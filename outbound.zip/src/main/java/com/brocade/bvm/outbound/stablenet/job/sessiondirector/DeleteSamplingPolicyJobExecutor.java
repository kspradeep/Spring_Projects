package com.brocade.bvm.outbound.stablenet.job.sessiondirector;


import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Named
public class DeleteSamplingPolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SAMPLING_POLICY_DELETE);
    }

    protected static final String SAMPLING = "sampling;";
    protected static final String DELETE_SAMPLING_POLICY = "del sampling-policy=%s;";

    @Override
    public String getCommands(Job job) {
        List<SamplingPolicy> samplingPolicies = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof SamplingPolicy)
                .map(mo -> (SamplingPolicy) mo)
                .collect(Collectors.toList());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(SAMPLING);
        samplingPolicies.forEach(samplingPolicy -> {
            command.append(String.format(DELETE_SAMPLING_POLICY, samplingPolicy.getName()));
        });
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
