package com.brocade.bvm.outbound;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@PropertySource("classpath:outbound.properties")
@Configuration
public class OutboundConfiguration {
}
