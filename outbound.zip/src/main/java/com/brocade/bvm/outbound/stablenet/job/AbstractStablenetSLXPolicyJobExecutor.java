package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.DestinationGroupRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.DestinationGroup;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.googlecode.ipv6.IPv6Address;
import com.googlecode.ipv6.IPv6Network;
import com.googlecode.ipv6.IPv6NetworkMask;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.net.util.SubnetUtils;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Named
public abstract class AbstractStablenetSLXPolicyJobExecutor extends AbstractStablenetJobExecutor {

    //Byte alignment value for SLX UDA fields (match and mask)
    protected static final Integer UDA_FIELD_BYTE_SIZE_ALIGNED = 4;

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String INTERFACE_PORT_CHANNEL = "interface port-channel %s;";

    protected static final String NO_NPB_POLICY = "no npb policy;";

    protected static final String MAC_ACCESS_LIST = "mac access-list extended %s;";

    protected static final String NO_MAC_ACCESS_LIST = "no mac access-list extended %s;";

    protected static final String IP_ACCESS_LIST = "ip access-list extended %s;";

    protected static final String NO_IP_ACCESS_LIST = "no ip access-list extended %s;";

    protected static final String UDA_ACCESS_LIST = "uda access-list extended %s;";

    protected static final String NO_UDA_ACCESS_LIST = "no uda access-list extended %s;";

    protected static final String IPV6_ACCESS_LIST = "ipv6 access-list extended %s;";

    protected static final String NO_IPV6_ACCESS_LIST = "no ipv6 access-list extended %s;";

    protected static final String ROUTE_MAP = "route-map %s %s %s;";

    protected static final String MATCH_ACL = "match %s address acl %s;";

    protected static final String NO_MATCH_ACL = "no match %s address acl %s;";

    protected static final String MATCH_UDA_ACL = "match uda %s;";

    protected static final String NO_MATCH_UDA_ACL = "no match uda %s;";

    protected static final String NEXT_HOP = "set interface %s %s %s;";

    protected static final String NEXT_HOP_TRUNCATION_PROFILE = "set interface %s %s %s %s %s;";

    protected static final String NEXT_HOP_WITH_PRECEDENCE = "precedence %s set interface %s %s %s;";

    protected static final String NO_NEXT_HOP = "no set interface %s %s;";

    protected static final String NO_NPB_POLICY_ROUTE_MAP = "no npb policy route-map;";

    protected static final String NO_ROUTE_MAP = "no route-map %s %s %s;";

    protected static final String CREATE_POLICY = "npb policy route-map %s;";

    protected static final String DELETE_POLICY = "no npb policy route-map %s;";

    protected static final String ENABLE_FLEX_PBR = "uda policy route-map %s;";

    protected static final String DISABLE_FLEX_PBR = "no uda policy route-map %s;";

    protected static final String NO_UDA_POLICY_ROUTE_MAP = "no uda policy route-map;";

    protected static final String CREATE_TVF_DOMAIN = "tvf-domain %s;";

    protected static final String REMOVE_TVF_DOMAIN = "no tvf-domain %s;";

    protected static final String ADD_INTERFACE_TO_TVF_DOMAIN = "tvf-domain add %s;";

    protected static final String REMOVE_INTERFACE_FROM_TVF_DOMAIN = "tvf-domain remove %s;";

    protected static final String SET_NEXT_HOP_TVF_DOMAIN = "set next-hop-tvf-domain %s %s;";

    protected static final String SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE = "precedence %s set next-hop-tvf-domain %s %s;";

    protected static final String SET_NEXT_HOP_TVF_DOMAIN_TRUNCATION_PROFILE = "set next-hop-tvf-domain %s %s %s %s;";

    protected static final String NO_SET_NEXT_HOP_TVF_DOMAIN = "no set next-hop-tvf-domain %s;";

    protected static final String NO_WITH_COMMAND = "no %s";

    protected static final String CMD_SEQUENCE = "seq %d";

    protected static final HashSet<String> portOperators = new HashSet<>(Arrays.asList("eq", "gt", "lt", "neq", "range"));

    protected static final int MIN_PORT_NO = 0;

    protected static final int MAX_PORT_NO = 65535;

    protected static final String IP = "ip";

    protected static final String IPV6 = "ipv6";

    protected static final String MAC = "mac";

    protected static final String UDA = "uda";

    protected static final String TCP = "tcp";

    protected static final String UDP = "udp";

    protected static final String CMD_PERMIT = "permit";

    protected static final String CMD_DENY = "deny";

    protected static final String COUNT = "count;";

    protected static final String CMD_ANY = "any";

    protected static final String CMD_HOST = "host";

    protected static final String ETHERNET = "ethernet";

    protected static final String PORT_CHANNEL = "port-channel";

    protected static final String CMD_VLAN = "vlan";

    protected static final String MAC_MASK = "ffff.ffff.ffff";

    protected static final String SPACE = " ";

    protected static final String EGRESS_TIMESTAMP = "system packet-timestamp egress %s;";

    protected static final String NO_EGRESS_TIMESTAMP = "no system packet-timestamp egress;";

    protected static final String INGRESS_VALID_TIMESTAMP = "system packet-timestamp ingress valid;";

    protected static final String NO_INGRESS_VALID_TIMESTAMP = "no system packet-timestamp ingress;";

    protected static final String UDA_KEY_PROFILE = "uda-key profile %s;";

    protected static final String DENY_GTP_HTTPS = "deny inner-gtp-https;";

    protected static final String NO_DENY_GTP_HTTPS = "no deny inner-gtp-https;";

    protected static final String STRIP_VLAN_OUTER = "strip-vlan outer";

    protected static final String ADD_VLAN_OUTER = "add-vlan outer %s";

    protected static final String UDA_OFFSET = "uda-offsets ";

    protected static final String NEGATIVE = "negative ";

    protected static final String IGNORE = "ignore ";

    protected static final String UDA_RULE = "%s %s %s %s";

    protected static final String OFFSET_HEADER_BASE_ONE = "first-header";

    protected static final String OFFSET_HEADER_BASE_TWO = "second-header";

    protected static final String OFFSET_HEADER_BASE_THREE = "third-header";

    protected static final String OFFSET_HEADER_BASE_FOUR = "fourth-header";

    protected static final String SEMI_COLON = ";";

    //flow header0 ETHERNET header1 IPV4 header2 UDP header3 PAYLOAD32
    protected static final String FLOW_HEADER_STACK = "flow %s;";

    protected static final String NO_FLOW_HEADER_STACK = "no flow;";

    protected static final String NO_UDA_KEY_FIELD = "no uda-key%d;";

    protected static final String HEADER_STACK = "header%d %s";

    protected static final String UDA_PROFILE_APPLY = "uda-profile-apply %s;";

    //uda-key0 header0 ETHER_TYPE
    protected static final String UDA_KEY_FIELD = "uda-key%d header%d %s;";

    protected static final String HEXADECIMAL = "0x";

    protected static final String SET_UDA_INTERFACE_NULL = "set uda interface null0;";

    protected static final String NO_SET_UDA_INTERFACE_NULL = "no set uda interface null0;";

    protected static final String SEPARATOR_COMMA = ",";

    protected static final String PBF_DESTINATION_GROUP = "pbf-destination-group";

    private static final String TELEMETRY_PROFILE = "telemetry profile %s %s;";

    private static final String INTERFACE_ADD_RANGE = "interface %s add %s;";

    private static final String INTERFACE_REMOVE_RANGE = "interface %s remove %s;";

    private static final String DEFAULT_PBR_STATISTICS = "default_pbr_statistics";

    private static final String PBR = "pbr";

    protected static final String TRUNCATION_PROFILE = "truncation-profile";

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected PolicyHistoryRepository policyHistoryRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    private DestinationGroupRepository destinationGroupRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    protected String applyInterfaceAndPbrStats(String interfacePortsToAdd, String interfacePortChannelsToAdd,
                                               String interfacePortsToDelete, String interfacePortChannelsToDelete) {
        StringBuilder command = new StringBuilder();
        if (!interfacePortsToDelete.isEmpty() || !interfacePortChannelsToDelete.isEmpty()) {
            command.append(String.format(TELEMETRY_PROFILE, PBR, DEFAULT_PBR_STATISTICS));
            if (!interfacePortsToDelete.isEmpty())
                command.append(String.format(INTERFACE_REMOVE_RANGE, ETHERNET, interfacePortsToDelete));
            if (!interfacePortChannelsToDelete.isEmpty())
                command.append(String.format(INTERFACE_REMOVE_RANGE, PORT_CHANNEL, interfacePortChannelsToDelete));
            command.append(EXIT);
        }
        if (!interfacePortsToAdd.isEmpty() || !interfacePortChannelsToAdd.isEmpty()) {
            command.append(String.format(TELEMETRY_PROFILE, PBR, DEFAULT_PBR_STATISTICS));
            if (!interfacePortsToAdd.isEmpty())
                command.append(String.format(INTERFACE_ADD_RANGE, ETHERNET, interfacePortsToAdd));
            if (!interfacePortChannelsToAdd.isEmpty())
                command.append(String.format(INTERFACE_ADD_RANGE, PORT_CHANNEL, interfacePortChannelsToAdd));
            command.append(EXIT);
        }
        return command.toString();
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    protected Policy getPolicyNameFromHistory(Policy policy) {
        Policy policyFromHistory = null;
        // get the previous policy name from the history.
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if ((policyHistoryList == null || policyHistoryList.isEmpty()) && policy.isLegacy()) {
            policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                    Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.WARNING));
        }
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /***
     * provide way to build policy command
     *
     * @param flow
     * @param tvfDomainIds
     * @param name
     * @return
     */
    protected String buildRevertFlowCommand(Flow flow, Set<String> tvfDomainIds, String name, List<String> uniqueListOfRulesetNameTobeDeleted) {
        StringBuilder command = new StringBuilder();
        StringBuilder noNextHopCommand = new StringBuilder();
        boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(flow);
        if (flow.getDestinationGroupId() != null) {
            DestinationGroup destinationGroup = destinationGroupRepository.findByGroupId(flow.getDestinationGroupId());
            if (destinationGroup != null) {
                noNextHopCommand.append(String.format(NO_NEXT_HOP, PBF_DESTINATION_GROUP, destinationGroup.getGroupId()));
                if (isSLX9850WithUDA && flow.getIsDefaultRouteMapDrop()) {
                    noNextHopCommand.append(NO_SET_UDA_INTERFACE_NULL);
                }
            }
        } else {
            if (flow.getTvfDomain()) {
                tvfDomainIds.forEach(tvfDomainId -> noNextHopCommand.append(String.format(NO_SET_NEXT_HOP_TVF_DOMAIN, tvfDomainId)));
            } else {
                flow.getEgressPorts().forEach(port -> noNextHopCommand.append(String.format(NO_NEXT_HOP, ETHERNET, port.getPortNumber())));
                flow.getEgressPortGroups().forEach(portGroup -> noNextHopCommand.append(String.format(NO_NEXT_HOP, PORT_CHANNEL, portGroup.getName())));

                if (isSLX9850WithUDA && flow.getIsDefaultRouteMapDrop()) {
                    noNextHopCommand.append(NO_SET_UDA_INTERFACE_NULL);
                }
            }
        }

        flow.getRuleSets().forEach(ruleSet ->
                command.append(buildRevertRuleSetCommand(ruleSet, name, noNextHopCommand.toString(), flow.getSequence(), isSLX9850WithUDA, flow, uniqueListOfRulesetNameTobeDeleted))
        );
        return command.toString();
    }

    protected boolean isDeviceSLX9850WithUda(Flow flow) {
        Device device = flow.getPolicy().getDevice();
        boolean isSLX9850 = Device.Type.SLX.equals(device.getType()) && device.getModel().contains(FlexMatchProfile.SLX_9850);
        RuleSet ruleSet = flow.getRuleSets().stream().filter(rules -> RuleSet.Type.UDA.equals(rules.getType())).findAny().orElse(null);
        boolean isUdaRuleSet = ruleSet != null;
        return isSLX9850 && isUdaRuleSet;
    }

    /**
     * Provide way to build rule set
     *
     * @param ruleSet
     * @return
     */
    protected String buildRevertRuleSetCommand(RuleSet ruleSet, String name, String noNextHopCommand, Integer routeMapId, boolean isSLX9850WithUDA, Flow flow, List<String> uniqueListOfRulesetNameTobeDeleted) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(ROUTE_MAP, name, CMD_PERMIT, routeMapId));
        command.append(noNextHopCommand);
        if (RuleSet.Type.UDA.equals(ruleSet.getType())) {
            if (isSLX9850WithUDA) {
                command.append(String.format(NO_MATCH_UDA_ACL, ruleSet.getName()));
            } else {
                command.append(String.format(NO_MATCH_ACL, UDA, ruleSet.getName()));
            }
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
            command.append(String.format(NO_MATCH_ACL, IP, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
            command.append(String.format(NO_MATCH_ACL, IPV6, ruleSet.getName()));
        } else if (ruleSet.getType() == RuleSet.Type.L2) {
            command.append(String.format(NO_MATCH_ACL, MAC, ruleSet.getName()));
        }
        command.append(EXIT);
        command.append(String.format(NO_ROUTE_MAP, name, CMD_PERMIT, routeMapId));
        if (isRuleSetChangesRequired(ruleSet, flow.getPolicy().getDevice().getId(), flow.getPolicy().getId()) && !uniqueListOfRulesetNameTobeDeleted.contains(ruleSet.getName())) {
            command.append(buildRevertRule(ruleSet));
            uniqueListOfRulesetNameTobeDeleted.add(ruleSet.getName());
        }
        return command.toString();
    }


    /**
     * Provide way to build rule
     *
     * @param ruleSet
     * @return
     */
    protected String buildRevertRule(RuleSet ruleSet) {
        StringBuilder command = new StringBuilder();

        if (ruleSet.getType() == RuleSet.Type.UDA) {
            // creating first line for UDA
            command.append(String.format(UDA_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getType() == RuleSet.Type.L2) {
            command.append(String.format(MAC_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
            command.append(String.format(IP_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
            command.append(String.format(IPV6_ACCESS_LIST, ruleSet.getName()));
        }

        // Appending rules
        ruleSet.getRules().forEach(rule -> {
            if (ruleSet.getType() == RuleSet.Type.UDA) {
                command.append(String.format(NO_WITH_COMMAND, buildRevertUDARuleCommand(rule)));
            }
            // Building l2 commands
            else if (ruleSet.getType() == RuleSet.Type.L2) {
                command.append(String.format(NO_WITH_COMMAND, buildMACRuleCommand(rule, true)));
            } else {
                command.append(String.format(NO_WITH_COMMAND, buildRuleCommand(rule, ruleSet.getIpVersion(), true)));
            }
        });
        command.append(EXIT);
        //introduced delay
        command.append(buildAccessList(ruleSet));
        command.append(buildAccessList(ruleSet));
        command.append(buildAccessList(ruleSet));

        // #3 reverting rule set
        if (ruleSet.getType() == RuleSet.Type.UDA) {
            command.append(String.format(NO_UDA_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getType() == RuleSet.Type.L2) {
            command.append(String.format(NO_MAC_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
            command.append(String.format(NO_IP_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
            command.append(String.format(NO_IPV6_ACCESS_LIST, ruleSet.getName()));
        }

        return command.toString();
    }

    private String buildAccessList(RuleSet ruleSet) {
        StringBuilder command = new StringBuilder();
        if (ruleSet.getType() == RuleSet.Type.UDA) {
            // creating first line for UDA
            command.append(String.format(UDA_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getType() == RuleSet.Type.L2) {
            command.append(String.format(MAC_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
            command.append(String.format(IP_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
            command.append(String.format(IPV6_ACCESS_LIST, ruleSet.getName()));
        }
        command.append(EXIT);
        return command.toString();
    }

    protected String buildUDARuleCommand(Rule rule, boolean isSLX9850) {
        StringBuilder command = new StringBuilder();
        /* Section 1 (permit/deny) */
        if (rule.getSequence() != null) {
            command.append(String.format(CMD_SEQUENCE, rule.getSequence()));
            command.append(SPACE);
        }
        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);
        /* Section 2 Fields and masks */
        command.append(String.format(UDA_RULE, getUdaFieldMaskCmnd(rule.getFieldValue1(), rule.getFieldmask1(), rule.getByteSize1(), rule.getIsHexadecimalType1(), isSLX9850),
                getUdaFieldMaskCmnd(rule.getFieldValue2(), rule.getFieldmask2(), rule.getByteSize2(), rule.getIsHexadecimalType2(), isSLX9850),
                getUdaFieldMaskCmnd(rule.getFieldValue3(), rule.getFieldmask3(), rule.getByteSize3(), rule.getIsHexadecimalType3(), isSLX9850),
                getUdaFieldMaskCmnd(rule.getFieldValue4(), rule.getFieldmask4(), rule.getByteSize4(), rule.getIsHexadecimalType4(), isSLX9850)));
        if (rule.getIsCountEnabled() != null && rule.getIsCountEnabled()) {
            command.append(SPACE).append(COUNT);
        } else {
            command.append(SEMI_COLON);
        }
        return command.toString();
    }

    protected String buildRevertUDARuleCommand(Rule rule) {
        StringBuilder command = new StringBuilder();
        if (rule.getSequence() != null) {
            command.append(String.format(CMD_SEQUENCE, rule.getSequence())).append(SEMI_COLON);
        }
        return command.toString();
    }

    private String getUdaFieldMaskCmnd(String fieldValue, String fieldMask, Integer byteSize, boolean isHexadecimal, boolean isSLX9850) {
        StringBuilder command = new StringBuilder();
        if (fieldMask != null && fieldValue != null) {
            if (CMD_ANY.equalsIgnoreCase(fieldValue)) {
                command.append(fieldValue);
            } else {
                if (isSLX9850) {
                    if (isHexadecimal) {
                        command.append(HEXADECIMAL + makeByteAlignedAsPrefix(fieldValue, UDA_FIELD_BYTE_SIZE_ALIGNED) + SPACE + HEXADECIMAL + makeByteAlignedAsPrefix(fieldMask, UDA_FIELD_BYTE_SIZE_ALIGNED));
                    } else {
                        try {
                            command.append(HEXADECIMAL + makeByteAlignedAsPrefix(Integer.toHexString(Integer.parseInt(fieldValue)), UDA_FIELD_BYTE_SIZE_ALIGNED) + SPACE + HEXADECIMAL + makeByteAlignedAsPrefix(fieldMask, UDA_FIELD_BYTE_SIZE_ALIGNED));
                        } catch (NumberFormatException e) {
                            command.append(HEXADECIMAL + makeByteAlignedAsPrefix(fieldValue, UDA_FIELD_BYTE_SIZE_ALIGNED) + SPACE + HEXADECIMAL + makeByteAlignedAsPrefix(fieldMask, UDA_FIELD_BYTE_SIZE_ALIGNED));
                        }
                    }
                } else {
                    if (isHexadecimal) {
                        command.append(HEXADECIMAL + fieldValue + SPACE + HEXADECIMAL + fieldMask);
                    } else {
                        try {
                            if (byteSize != null) {
                                command.append(HEXADECIMAL + makeByteAlignedAsSuffix(Integer.toHexString(Integer.parseInt(fieldValue)), byteSize) + SPACE + HEXADECIMAL + fieldMask);
                            } else {
                                command.append(HEXADECIMAL + Integer.toHexString(Integer.parseInt(fieldValue)) + SPACE + HEXADECIMAL + fieldMask);
                            }
                        } catch (NumberFormatException e) {
                            command.append(HEXADECIMAL + fieldValue + SPACE + HEXADECIMAL + fieldMask);
                        }
                    }
                }
            }
        }
        return command.toString();
    }

    /**
     * Method return the byte aligned string(add zeros as prefix)
     *
     * @param value
     * @param byteSize
     * @return
     */
    protected String makeByteAlignedAsPrefix(String value, int byteSize) {
        StringBuilder resultString = new StringBuilder();
        if (value != null) {
            resultString.append(value);
            int filedLength = value.length();
            if (filedLength < (byteSize * 2)) {
                if (filedLength % 2 != 0) {
                    resultString.append("0");
                    filedLength = resultString.length();
                }
                for (int i = (filedLength / 2); i < byteSize; i++) {
                    resultString.append("00");
                }
            }
        }
        return resultString.toString();
    }

    /**
     * Method return the byte aligned string(add zeros as suffix)
     *
     * @param value
     * @param byteSize
     * @return
     */
    protected String makeByteAlignedAsSuffix(String value, int byteSize) {
        StringBuilder resultString = new StringBuilder();
        if (value != null) {
            resultString.append(value);
            int filedLength = value.length();
            if (filedLength < (byteSize * 2)) {
                if (filedLength % 2 != 0) {
                    resultString.insert(0, "0");
                    filedLength = resultString.length();
                }
                for (int i = (filedLength / 2); i < byteSize; i++) {
                    resultString.insert(0, "00");
                }
            }
        }
        return resultString.toString();
    }


    protected String buildMACRuleCommand(Rule rule, boolean isRevert) {
        StringBuilder command = new StringBuilder();
        if (!isRevert) {
            command.append(String.format(CMD_SEQUENCE, rule.getSequence()));
            command.append(SPACE);
        }
        /* Section 1 (permit/deny) */
        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);
        // Section 2 Source (any/mac) (mask)
        if (rule.getSourceMac() != null && rule.getSourceMac().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getSourceMac() != null && rule.getSourceMacMask() != null
                && !rule.getSourceMacMask().trim().isEmpty()) {
            command.append(rule.getSourceMac()).append(SPACE).append(rule.getSourceMacMask()).append(SPACE);
        } else if (rule.getSourceMac() != null && (rule.getSourceMacMask() == null
                || (rule.getSourceMacMask() != null && rule.getSourceMacMask().trim().isEmpty()))) {
            command.append(rule.getSourceMac()).append(SPACE).append(MAC_MASK).append(SPACE);
        }
        // Section 3 Destination (any/mac) (mask)
        if (rule.getDestinationMac() != null && rule.getDestinationMac().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getDestinationMac() != null && rule.getDestinationMacMask() != null
                && !rule.getDestinationMacMask().trim().isEmpty()) {
            command.append(rule.getDestinationMac()).append(SPACE).append(rule.getDestinationMacMask()).append(SPACE);
        } else if (rule.getDestinationMac() != null && (rule.getDestinationMacMask() == null
                || (rule.getDestinationMacMask() != null && rule.getDestinationMacMask().trim().isEmpty()))) {
            command.append(rule.getDestinationMac()).append(SPACE).append(MAC_MASK).append(SPACE);
        }
        // Section 4 Ether Type (etype etype arp/ipv4/ipv6/...) etype value
        if (rule.getEthType() != null && !rule.getEthType().equals(CMD_ANY)) {
            command.append(rule.getEthType()).append(SPACE);
        }
        // Section 5 VLANID (any/vLan id)
        if (rule.getVlanId() > 0) {
            command.append(CMD_VLAN + SPACE + rule.getVlanId()).append(SPACE);
        }

        command.append(COUNT);
        return command.toString();
    }

    protected String buildRuleSetCommand(RuleSet ruleSet, boolean isSLX9850) {
        StringBuilder command = new StringBuilder();
        if (RuleSet.Type.UDA.equals(ruleSet.getType())) {
            // creating first line for UDA
            command.append(String.format(UDA_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
            // creating first line for command IP
            command.append(String.format(IP_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
            // creating first line for command for IPV6
            command.append(String.format(IPV6_ACCESS_LIST, ruleSet.getName()));
        } else if (ruleSet.getType() == RuleSet.Type.L2) {
            // creating first line for command for MAC
            command.append(String.format(MAC_ACCESS_LIST, ruleSet.getName()));
        }

        // Appending rules
        ruleSet.getRules().forEach(rule -> {
            if (RuleSet.Type.UDA.equals(ruleSet.getType())) {
                command.append(buildUDARuleCommand(rule, isSLX9850));
            }
            // Building l2 commands
            else if (ruleSet.getType() == RuleSet.Type.L2) {
                command.append(buildMACRuleCommand(rule, false));
            } else {
                command.append(buildRuleCommand(rule, ruleSet.getIpVersion(), false));
            }
        });
        command.append(EXIT);
        return command.toString();
    }

    protected String buildRuleCommand(Rule rule, RuleSet.IpVersion ipVersion, boolean isRevert) {
        if (rule != null && rule.getCustomAcl() != null) {
            log.debug("Working on custom rule [" + rule.getCustomAcl() + "]");
            log.info("using custom rule as is.");
            return rule.getCustomAcl().endsWith(";") ? rule.getCustomAcl() : rule.getCustomAcl() + ";";
        }
        StringBuilder command = new StringBuilder();
        if (!isRevert) {
            command.append(String.format(CMD_SEQUENCE, rule.getSequence()));
            command.append(SPACE);
        }

        if (rule.getIsPermit()) {
            command.append(CMD_PERMIT);
        } else {
            command.append(CMD_DENY);
        }
        command.append(SPACE);

        if (rule.getProtocol() != null) {
            command.append(rule.getProtocol());
        }
        command.append(SPACE);

        if (rule.getSourceIp() != null && rule.getSourceIp().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getSourceIp() != null) {
            if (rule.getSourceIp().contains("/")) {
                command.append(getNetworkAddress(rule.getSourceIp())).append(SPACE);
            } else {
                command.append(CMD_HOST + SPACE + rule.getSourceIp()).append(SPACE);
            }
        }
        constructPartialRule(rule, StablenetCommitSLXPolicyJobExecutor.PortType.SOURCE, command);
        if (rule.getDestinationIp() != null && rule.getDestinationIp().equals(CMD_ANY)) {
            command.append(CMD_ANY).append(SPACE);
        } else if (rule.getDestinationIp() != null) {
            if (rule.getDestinationIp().contains("/")) {
                command.append(getNetworkAddress(rule.getDestinationIp())).append(SPACE);
            } else {
                command.append(CMD_HOST + SPACE + rule.getDestinationIp()).append(SPACE);
            }
        }
        constructPartialRule(rule, StablenetCommitSLXPolicyJobExecutor.PortType.DESTINATION, command);
        if (rule.getVlanId() > 0) {
            command.append(CMD_VLAN + SPACE + rule.getVlanId()).append(SPACE);
        }
        command.append(COUNT);
        return command.toString();
    }

    private void constructPartialRule(Rule rule, StablenetCommitSLXPolicyJobExecutor.PortType type, StringBuilder command) {
        if (rule == null || rule.getProtocol() == null) {
            return;
        }
        switch (rule.getProtocol().toLowerCase()) {
            case TCP:
            case UDP:
                if (type.equals(StablenetCommitSLXPolicyJobExecutor.PortType.SOURCE) && rule.getSourcePortOperator() != null
                        && portOperators.contains(rule.getSourcePortOperator().toLowerCase())
                        && rule.getSourcePort() > MIN_PORT_NO && rule.getSourcePort() < MAX_PORT_NO) {
                    command.append(rule.getSourcePortOperator()).append(SPACE).append(rule.getSourcePort()).append(SPACE);
                }
                if (type.equals(StablenetCommitSLXPolicyJobExecutor.PortType.DESTINATION) && rule.getDestinationPortOperator() != null
                        && portOperators.contains(rule.getDestinationPortOperator().toLowerCase())
                        && rule.getDestinationPort() > MIN_PORT_NO && rule.getDestinationPort() < MAX_PORT_NO) {
                    command.append(rule.getDestinationPortOperator()).append(SPACE)
                            .append(rule.getDestinationPort()).append(SPACE);
                }
                break;
            default:
                break;
        }
    }

    protected String getNetworkAddress(String addressString) {
        if (addressString != null) {
            if (addressString.contains(":")) {
                return getNetworkAddressIpv6(addressString);
            } else if (addressString.contains(".")) {
                return getNetworkAddressIpv4(addressString);
            }
        }
        return "";
    }

    private String getNetworkAddressIpv4(String addressString) {
        StringBuilder addressBuilder = new StringBuilder();
        try {
            SubnetUtils utils = new SubnetUtils(addressString);
            String mask = addressString.substring((addressString.indexOf("/")) + 1);
            addressBuilder.append(utils.getInfo().getNetworkAddress());
            addressBuilder.append("/").append(mask);
        } catch (Exception e) {
            log.error("failed to convert the network address (Ipv4) {}", addressString);
        }
        return addressBuilder.toString();
    }

    private String getNetworkAddressIpv6(String addressString) {
        try {
            String address = addressString.substring(0, addressString.indexOf("/"));
            String mask = addressString.substring((addressString.indexOf("/")) + 1);
            IPv6Network iPv6Network = IPv6Network.fromAddressAndMask(IPv6Address.fromString(address), IPv6NetworkMask.fromPrefixLength(Integer.parseInt(mask)));
            return iPv6Network.toString();
        } catch (NumberFormatException e) {
            log.error("failed to convert the network address (Ipv6) {}", addressString);
        }
        return "";
    }

    private String getEachOffsetCmnd(SortedSet<FlexHeader> flexHeaders, FlexHeader slxFlexOffset) {
        StringBuilder command = new StringBuilder();
        if (slxFlexOffset.getHeaderLevel() != null && slxFlexOffset.getFlexHeaderFields().size() > 0) {
            slxFlexOffset.getFlexHeaderFields().forEach(flexHeaderField -> {
                int validOffsetValue = flexHeaderField.getCustomOffset() > -1 ? flexHeaderField.getCustomOffset() + flexHeaderField.getOffset() : flexHeaderField.getOffset();
                switch (slxFlexOffset.getHeaderLevel()) {
                    case 1:
                        command.append(OFFSET_HEADER_BASE_ONE + SPACE);
                        break;
                    case 2:
                        command.append(OFFSET_HEADER_BASE_TWO + SPACE);
                        break;
                    case 3:
                        command.append(OFFSET_HEADER_BASE_THREE + SPACE);
                        break;
                    case 4:
                        command.append(OFFSET_HEADER_BASE_FOUR + SPACE);
                        break;
                    default:
                        if (slxFlexOffset.getHeaderLevel() > 4) {
                            command.append(OFFSET_HEADER_BASE_FOUR + SPACE);
                        }
                        break;
                }

                if (!flexHeaderField.getIsPositive()) {
                    command.append(NEGATIVE);
                }

                if (slxFlexOffset.getHeaderLevel() > 4) {
                    for (FlexHeader flexHeader : flexHeaders) {
                        if (flexHeader.getHeaderLevel() > 3 && flexHeader.getHeaderLevel() < slxFlexOffset.getHeaderLevel()) {
                            FlexHeader.HEADER_BYTE_LENGTH header_byte_length = FlexHeader.HEADER_BYTE_LENGTH.valueOf(flexHeader.getHeaderName().value());
                            if (header_byte_length != null) {
                                validOffsetValue += header_byte_length.getByteLength();
                            }
                        }
                    }
                }
                command.append(validOffsetValue + SPACE + SEPARATOR_COMMA);
            });
        }
        return command.toString().trim();
    }

    /**
     * Method constructs the flex match header CLIs based on the device model
     *
     * @param policy
     * @return
     */
    protected String buildUdaProfileOffset(Policy policy) {
        StringBuilder command = new StringBuilder();
        Device device = policy.getDevice();
        policy.getFlexMatchProfiles().forEach(flexMatchProfile -> {
            List<Policy> policyList = policyRepository.findByFMProfileIdAndStatusInAndDevice(flexMatchProfile.getId(), policy.getDevice().getId(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
            if (policyList != null && policyList.isEmpty()) {
                command.append(String.format(UDA_KEY_PROFILE, flexMatchProfile.getName()));
                if (device.getModel().contains(FlexMatchProfile.SLX_9240) || device.getModel().contains(FlexMatchProfile.SLX_9140)) {
                    AtomicInteger atomicInteger = new AtomicInteger(0);
                    StringBuilder headerStack = new StringBuilder();
                    StringBuilder headerFields = new StringBuilder();
                    flexMatchProfile.getFlexHeaders().forEach(flexHeader -> {
                        headerStack.append(SPACE).append(String.format(HEADER_STACK, flexHeader.getSequence(), flexHeader.getHeaderName().value()));
                        flexHeader.getFlexHeaderFields().forEach(headerField -> {
                            headerFields.append(String.format(UDA_KEY_FIELD, atomicInteger.getAndAdd(1), flexHeader.getHeaderLevel(), headerField.getHeaderField().value()));
                        });
                    });
                    command.append(String.format(FLOW_HEADER_STACK, headerStack.toString()));
                    command.append(String.format(NO_UDA_KEY_FIELD, 0));
                    command.append(String.format(NO_UDA_KEY_FIELD, 1));
                    command.append(String.format(NO_UDA_KEY_FIELD, 2));
                    command.append(String.format(NO_UDA_KEY_FIELD, 3));
                    command.append(NO_FLOW_HEADER_STACK);
                    command.append(String.format(FLOW_HEADER_STACK, headerStack.toString()));
                    command.append(headerFields.toString());
                    command.append(EXIT);
                } else if (device.getModel().contains(FlexMatchProfile.SLX_9850)) {
                    command.append(UDA_OFFSET);
                    flexMatchProfile.getFlexHeaders().forEach(offsetHeader -> {
                        command.append(getEachOffsetCmnd(flexMatchProfile.getFlexHeaders(), offsetHeader) + SPACE);
                    });
                    int offsetSize = command.toString().split(",").length;
                    //Appending Ignore for rest of the offsets to make it 4 offsets
                    while (offsetSize < 5) {
                        command.append(IGNORE + SPACE);
                        offsetSize++;
                    }
                    command.append(SEMI_COLON);
                    command.append(EXIT);
                }
            }
        });
        return command.toString().replace(",", "");
    }

    /**
     * Method constructs the revert flex match header CLIs based on the device model
     *
     * @param policy
     * @return
     */
    protected String buildRevertUdaProfileOffset(Policy policy) {
        StringBuilder command = new StringBuilder();
        policy.getFlexMatchProfiles().forEach(flexMatchProfile -> {
            List<Policy> policyList = policyRepository.findByFMProfileIdInAndDevice(flexMatchProfile.getId(), policy.getDevice().getId());
            if (policyList != null) {
                boolean isDeleteProfile = true;
                policyList = policyList.stream().filter(policy1 -> policy1.getId() != policy.getId()).collect(Collectors.toList());
                if (!policyList.isEmpty()) {
                    Iterator<Policy> iterator = policyList.iterator();
                    while (iterator.hasNext()) {
                        Policy policy1 = iterator.next();
                        if (policy1.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.DRAFT) {
                            isDeleteProfile = false;
                            break;
                        }
                        if (policy1.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                            List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy1.getId(),
                                    Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                            if (!policyHistoryList.isEmpty()) {
                                PolicyHistory oldPolicy = policyHistoryList.get(0);
                                if (oldPolicy != null && WorkflowParticipant.WorkflowStatus.ACTIVE == oldPolicy.getWorkflowStatus()) {
                                    isDeleteProfile = false;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (policyList.isEmpty() || isDeleteProfile) {
                    command.append(String.format(NO_WITH_COMMAND, String.format(UDA_KEY_PROFILE, flexMatchProfile.getName())));
                }
            }
        });
        return command.toString();
    }

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    protected boolean compare(Rule rule, Rule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null)
            return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null)
            return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null)
            return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getIsCountEnabled() != nRule.getIsCountEnabled()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getProtocolType() != null ? !rule.getProtocolType().equals(nRule.getProtocolType()) : nRule.getProtocolType() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;
        if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
            return false;
        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getMatchPayloadLength() != nRule.getMatchPayloadLength())
            return false;
        if (rule.getIsHexadecimalType1() != nRule.getIsHexadecimalType1())
            return false;
        if (rule.getIsHexadecimalType2() != nRule.getIsHexadecimalType2())
            return false;
        if (rule.getIsHexadecimalType3() != nRule.getIsHexadecimalType3())
            return false;
        if (rule.getIsHexadecimalType4() != nRule.getIsHexadecimalType4())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }

    /**
     * This method builds ACL command for rule update/delete/create for existing ACL mapped with other policy
     *
     * @param ruleSet
     * @param deviceId
     * @param policyId
     * @return
     */
    protected String buildRuleSetCommandForExistingRulesetInDifferentPolicy(RuleSet ruleSet, Long deviceId, Long policyId) {
        StringBuilder createRuleSetCommands = new StringBuilder();
        List<RuleSet> existingRulesets = ruleSetRepository.findByNameAndDeviceIdAndNotInPolicyId(ruleSet.getName(), deviceId, policyId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING));
        if (existingRulesets != null && !existingRulesets.isEmpty()) {
            RuleSet existingRuleset = existingRulesets.get(0);
            if (existingRuleset != null && existingRuleset.getRules() != null) {
                StringBuilder ruleCommands = new StringBuilder();
                List<Long> sequenceList = new ArrayList<>();
                ruleSet.getRules().stream().forEach(rule -> {
                    Long ruleSequence = rule.getSequence();
                    sequenceList.add(ruleSequence);
                    if (ruleSequence != null) {
                        Rule matchingRule = existingRuleset.getRules().stream().filter(rule1 -> ruleSequence.longValue() == rule1.getSequence().longValue()).findFirst().orElse(null);
                        if (matchingRule != null) {
                            //compare the rule if updated
                            if (!compare(rule, matchingRule)) {
                                //Only when updated need to build revert and add command
                                ruleCommands.append(buildRuleRevertAndUpdateCommand(matchingRule, rule, ruleSet));
                            }
                        } else {
                            // Rule is added
                            ruleCommands.append(buildRuleRevertAndUpdateCommand(null, rule, ruleSet));
                        }
                    }
                });
                existingRuleset.getRules().stream().forEach(existingRule -> {
                            if (!sequenceList.contains(existingRule.getSequence())) {
                                ruleCommands.append(buildRuleRevertAndUpdateCommand(existingRule, null, ruleSet));
                            }
                        }
                );
                if (!Strings.isNullOrEmpty(ruleCommands.toString())) {
                    RuleSet.Type type = ruleSet.getType();
                    if (RuleSet.Type.UDA == type) {
                        createRuleSetCommands.append(String.format(UDA_ACCESS_LIST, ruleSet.getName()));
                    } else if (RuleSet.Type.L2 == type) {
                        createRuleSetCommands.append(String.format(MAC_ACCESS_LIST, ruleSet.getName()));
                    } else if (RuleSet.IpVersion.V4 == ruleSet.getIpVersion()) {
                        createRuleSetCommands.append(String.format(IP_ACCESS_LIST, ruleSet.getName()));
                    } else if (RuleSet.IpVersion.V6 == ruleSet.getIpVersion()) {
                        createRuleSetCommands.append(String.format(IPV6_ACCESS_LIST, ruleSet.getName()));
                    }
                    createRuleSetCommands.append(ruleCommands.toString());
                    createRuleSetCommands.append(EXIT);
                }
            }
        }

        return createRuleSetCommands.toString();
    }

    /**
     * To build rule command for added ruleset which is already mapped with other policy
     *
     * @param matchingRule
     * @param rule
     * @param ruleSet
     * @return
     */
    private String buildRuleRevertAndUpdateCommand(Rule matchingRule, Rule rule, RuleSet ruleSet) {
        StringBuilder command = new StringBuilder();
        if (ruleSet != null) {
            RuleSet.Type type = ruleSet.getType();
            RuleSet.IpVersion ipVersion = ruleSet.getIpVersion();
            if (type != null) {
                //For delete rule command
                if (matchingRule != null) {
                    String ruleCommand = "";
                    if (type == RuleSet.Type.UDA) {
                        ruleCommand = buildRevertUDARuleCommand(matchingRule);
                    } else if (type == RuleSet.Type.L2) {
                        ruleCommand = buildMACRuleCommand(matchingRule, true);
                    } else {
                        if (ipVersion != null)
                            ruleCommand = buildRuleCommand(matchingRule, ipVersion, true);
                    }
                    command.append(String.format(NO_WITH_COMMAND, ruleCommand));
                }
                //For added rule command
                if (rule != null) {
                    String ruleCommand = "";
                    if (type == RuleSet.Type.UDA) {
                        boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(ruleSet.getFlow());
                        ruleCommand = buildUDARuleCommand(rule, isSLX9850WithUDA);
                    } else if (type == RuleSet.Type.L2) {
                        ruleCommand = buildMACRuleCommand(rule, false);
                    } else {
                        ruleCommand = buildRuleCommand(rule, ipVersion, false);
                    }
                    command.append(ruleCommand);
                }
            }
        }
        return command.toString();
    }
}
