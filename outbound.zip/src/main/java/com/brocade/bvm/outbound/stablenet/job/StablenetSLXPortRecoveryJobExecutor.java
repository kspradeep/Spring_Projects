package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SLXPortRecoveryCommandList;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The StablenetSLXPortRecoveryJobExecutor class implements methods to recover SLX(Non Open Flow) port(s) which are in error state through Stablenet
 */
@Named
public class StablenetSLXPortRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Inject
    private SLXPortRecoveryCommandList slxPortRecoveryCommandList;

    /**
     * This method constructs port recovery commands to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    public List<CommandBlock> getCommands(Job job) {
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        List<CommandBlock> commandBlocks = slxPortRecoveryCommandList.constructCommandBlockList(ports, job.getDevice());
        return commandBlocks;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
