package com.brocade.bvm.outbound.exception;

import com.brocade.bvm.model.exception.ServerException;

public class OutboundApiException extends ServerException {
    public OutboundApiException(Throwable cause) {
        super(cause);
    }

    public OutboundApiException(String message) {
        super(message);
    }

    public OutboundApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
