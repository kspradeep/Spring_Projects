package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.LoadBalanceModulePolicyHistoryRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.TargetHost.Mode;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.LoadBalanceModulePolicy;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The StablenetLoadBalanceModulePolicyDeleteJobExecutor class implements methods to update LoadBalanceModulePolicy on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetLoadBalanceModulePolicyUpdateJobExecutor extends AbstractLoadBalanceModulePolicyJobExecutor {

	@Inject
	private LoadBalanceModulePolicyHistoryRepository modulePolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;
	 
	@Override
	public List<Type> getSupportedJobTypes() {
		return Lists.newArrayList(Job.Type.LOAD_BALANCE_MODULE_POLICY_UPDATE);
	}

	@Override
	public Mode getSupportedMode() {
		return Mode.PLAIN;
	}

    /**
     * This method constructs update LoadBalanceModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
	@Override
    public String getCommands(Job job) {
        LoadBalanceModulePolicy modulePolicy = (LoadBalanceModulePolicy) getParentObject(job);
        LoadBalanceModulePolicy modulePolicyFromHistory = getModulePolicyFromHistory(modulePolicy);
        List<Module> modules = (List<Module>) moduleRepository.findAll(modulePolicyFromHistory.getModules().stream().map(Module::getId).collect(Collectors.toList()));
        Set<Module> listModulesFromHistoryAndDB = new HashSet<>(modules);
        Set<Module> listOfModulesFromLatest = modulePolicy.getModules();
        StringBuilder cmd = new StringBuilder();
        cmd.append(CONFIGURE_TERMINAL);
        //deleted modulepolicies
        listModulesFromHistoryAndDB.stream().forEach(module -> {
            cmd.append(buildDeleteModulePolicyForModule(modulePolicyFromHistory, module));
        });
        //new modulepolicies
        listOfModulesFromLatest.stream().forEach(module -> {
            cmd.append(buildCreateModulePolicyForModule(modulePolicy, module));
        });
        cmd.append(END);
        cmd.append(WRITE_MEMORY);
        log.trace("cmd = " + cmd.toString());
        return cmd.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestModulePolicy
     * @return Policy returns latest ACTIVE policy
     */
    private LoadBalanceModulePolicy getModulePolicyFromHistory(LoadBalanceModulePolicy latestModulePolicy) {
        List<LoadBalanceModulePolicyHistory> modulePolicyHistoryList = modulePolicyHistoryRepository.findByIdAndWorkflowStatus(latestModulePolicy.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        if (!modulePolicyHistoryList.isEmpty()) {
            LoadBalanceModulePolicyHistory lastActivePolicy = modulePolicyHistoryList.get(0);
            LoadBalanceModulePolicy policyFromHistory = lastActivePolicy.buildParent();
            return policyFromHistory;
        }
        return null;
    }

}
