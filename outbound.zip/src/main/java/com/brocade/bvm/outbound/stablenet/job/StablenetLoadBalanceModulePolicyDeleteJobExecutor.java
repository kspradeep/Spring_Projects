package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.LoadBalanceModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetLoadBalanceModulePolicyDeleteJobExecutor class implements methods to delete LoadBalanceModulePolicy on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetLoadBalanceModulePolicyDeleteJobExecutor extends AbstractLoadBalanceModulePolicyJobExecutor {

    /**
     * This method constructs delete LoadBalanceModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        LoadBalanceModulePolicy modulePolicy = (LoadBalanceModulePolicy) getParentObject(job);
        StringBuilder cmd = new StringBuilder();
        cmd.append(CONFIGURE_TERMINAL);
        modulePolicy.getModules().stream().forEach(module -> {
            cmd.append(buildDeleteModulePolicyForModule(modulePolicy, module));
        });
        cmd.append(END);
        cmd.append(WRITE_MEMORY);
        log.trace("cmd = " + cmd.toString());
        return cmd.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.LOAD_BALANCE_MODULE_POLICY_DELETE);
    }

}
