package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.HeaderStrippingModulePolicyHistoryRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.HeaderStrippingModulePolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Named
@Slf4j
public class SLXHeaderStripModulePolicyUpdateJobExecutor extends AbstractSLXHeaderStripModulePolicyJobExecutor {
    @Inject
    private HeaderStrippingModulePolicyHistoryRepository headerStrippingModulePolicyHistoryRepository;

    @Inject
    private PortRepository portRepository;

    /**
     * This method constructs update HeaderStripping module policy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        HeaderStrippingModulePolicy modulePolicy = (HeaderStrippingModulePolicy) getParentObject(job);
        HeaderStrippingModulePolicy modulePolicyFromHistory = getModulePolicyFromHistory(modulePolicy);

        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);

        Set<String> oldHeaders = modulePolicyFromHistory.getStripHeaders().stream().map(HeaderStrippingModulePolicy.Headers::name).collect(Collectors.toSet());
        Set<String> newHeaders = modulePolicy.getStripHeaders().stream().map(HeaderStrippingModulePolicy.Headers::name).collect(Collectors.toSet());
        List<Port> oldPorts = (List<Port>) portRepository.findAll(modulePolicyFromHistory.getPorts().stream().map(Port::getId).collect(Collectors.toList()));
        List<Port> newPorts = (List<Port>) portRepository.findAll(modulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList()));
        Set<Long> oldPortIds = oldPorts.stream().map(Port::getId).collect(Collectors.toSet());
        Set<Long> newPortIds = newPorts.stream().map(Port::getId).collect(Collectors.toSet());
        if (!oldHeaders.containsAll(newHeaders) || oldHeaders.size() != newHeaders.size()) {
            Set<HeaderStrippingModulePolicy.Headers> headersDeleted = new HashSet<>();
            Set<HeaderStrippingModulePolicy.Headers> headersAdded = new HashSet<>();
            modulePolicyFromHistory.getStripHeaders().forEach(oldHeader -> {
                if (!newHeaders.contains(oldHeader.name()))
                    headersDeleted.add(oldHeader);
            });

            modulePolicy.getStripHeaders().forEach(newHeader -> {
                if (!oldHeaders.contains((newHeader.name())))
                    headersAdded.add(newHeader);
            });

            if (!oldPorts.containsAll(newPorts) || oldPorts.size() != newPorts.size()) {
                headersDeleted.addAll(modulePolicyFromHistory.getStripHeaders());
                headersAdded.addAll(modulePolicy.getStripHeaders());
            }

            /* Issuing delete command for deleted Headers*/
            headersDeleted.forEach(header -> {
                command.append(buildDeleteCommand(Sets.newHashSet(oldPorts), header));
            });

            /* Issuing create command for added Headers*/
            headersAdded.forEach(header -> {
                command.append(buildCreateCommand(Sets.newHashSet(newPorts), header));
            });
        } else if (!oldPorts.containsAll(newPorts) || oldPorts.size() != newPorts.size()) {
            /* Finding the diff of modules between old module policy and new module policy*/
            Set<Port> portDeleted = new HashSet<>();
            Set<Port> portAdded = new HashSet<>();
            oldPorts.forEach(oldPort -> {
                if (!newPortIds.contains(oldPort.getId()))
                    portDeleted.add(oldPort);
            });

            newPorts.forEach(newPort -> {
                if (!oldPortIds.contains((newPort.getId())))
                    portAdded.add(newPort);
            });
            /* Issuing delete command for deleted modules*/
            modulePolicyFromHistory.getStripHeaders().forEach(header -> {
                command.append(buildDeleteCommand(Sets.newHashSet(portDeleted), header));
            });
            /* Issuing create command for added modules*/
            modulePolicy.getStripHeaders().forEach(header -> {
                command.append(buildCreateCommand(Sets.newHashSet(portAdded), header));
            });
        }
        command.append(EXIT);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param modulePolicy
     * @return HeaderStrippingModulePolicy returns latest ACTIVE policy
     */
    private HeaderStrippingModulePolicy getModulePolicyFromHistory(HeaderStrippingModulePolicy modulePolicy) {
        List<HeaderStrippingModulePolicyHistory> modulePolicyHistoryList = headerStrippingModulePolicyHistoryRepository.findByIdAndWorkflowStatus(modulePolicy.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        if (!modulePolicyHistoryList.isEmpty()) {
            HeaderStrippingModulePolicyHistory lastActivePolicy = modulePolicyHistoryList.get(0);
            HeaderStrippingModulePolicy policyFromHistory = lastActivePolicy.buildParent();
            return policyFromHistory;
        }
        return null;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_SLX_UPDATE);
    }
}
