package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetSLXPortStatusJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private PortGroupRepository portGroupRepository;

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String NO_SHUTDOWN = "no shutdown;";

    protected static final String SHUTDOWN = "shutdown;";


    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_ENABLE, Job.Type.PORT_DISABLE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);

        String portAdminStatus;
        switch (job.getType()) {
            case PORT_ENABLE:
                portAdminStatus = NO_SHUTDOWN;
                break;
            case PORT_DISABLE:
                portAdminStatus = SHUTDOWN;
                break;
            default:
                portAdminStatus = SHUTDOWN;
                break;
        }

        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        //Filter Ports which are not part of a port group
        ports.stream()
                .filter(port -> getPortGroup(port.getId()) == null)
                .forEach(port -> {
                    commands.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    commands.append(portAdminStatus);
                    commands.append(EXIT);
                });

        //Ports part of an active part group
        Multimap<PortGroup, Port> portGroupMap = ArrayListMultimap.create();
        for (Port port : ports) {
            PortGroup portGroup = getPortGroup(port.getId());
            if (portGroup != null && portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                portGroupMap.put(portGroup, port);
            }
        }

        for (PortGroup portGroup : portGroupMap.keys()) {
            portGroupMap.get(portGroup).stream().forEach(port -> {
                commands.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                commands.append(portAdminStatus);
                commands.append(EXIT);
            });
        }

        commands.append(EXIT);
        log.info("StablenetSLXPortStatusJobExecutor command generated from Job Id {} on device {}  command: {}", job.getId(), job.getDevice().getId(), commands.toString());
        return commands.toString();
    }

    private PortGroup getPortGroup(Long portId) {
        Long portGroupId = portGroupRepository.findByPortId(portId);
        PortGroup portGroup = null;
        if (portGroupId != null) {
            portGroup = portGroupRepository.findOne(portGroupId);
        }
        return portGroup;
    }
}
