package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.utility.GenericOutboundHelper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Named
public abstract class AbstractStablenetSLXPortGroupJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String INTERFACE_CHANNEL_GROUP = "interface port-channel %s;";

    protected static final String NO_INTERFACE_CHANNEL_GROUP = "no interface port-channel %s;";

    protected static final String CHANNEL_GROUP = "channel-group %s mode on type standard;";

    protected static final String NO_CHANNEL_GROUP = "no channel-group;";

    protected static final String SET_SPEED = "speed %s;";

    protected static final String NO_SHUTDOWN = "no shutdown;";

    protected static final String SHUTDOWN = "shutdown;";

    protected static final String MINIMUM_LINKS = "minimum-links %s;";

    protected static final String NO_MINIMUM_LINKS = "no minimum-links;";

    private static final String LOOP_BACK_ENABLED = "loopback phy;";

    private static final String LOOP_BACK_DISABLED = "no loopback phy;";

    @Inject
    protected PortHistoryRepository portHistoryRepository;

    @Inject
    protected GenericOutboundHelper genericOutboundHelper;

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }


    /**
     * This method builds command to create portGroup
     *
     * @param portGroup
     * @return String returns delete commands
     */
    protected String createPortGroup(PortGroup portGroup) {
        StringBuilder portChannelCommand = new StringBuilder();
        StringBuilder command = new StringBuilder();
        StringBuilder portCommand = new StringBuilder();
        boolean isLoopBackSupported = genericOutboundHelper.isSlxLoopBackSupported(portGroup.getDevice());
        if (portGroup != null) {
            Set<Port> ports = portGroup.getPorts();
            if (ports != null && !ports.isEmpty()) {
                portChannelCommand.append(String.format(INTERFACE_CHANNEL_GROUP, portGroup.getName()));
                if (portGroup.getLineSpeed() != null && portGroup.getLineSpeed() > 0) {
                    portChannelCommand.append(SHUTDOWN);
                    portChannelCommand.append(String.format(SET_SPEED, portGroup.getLineSpeed()));
                }
                if (isLoopBackSupported && Port.Type.SERVICE_PORT == portGroup.getType() && portGroup.isLoopbackEnabled()) {
                    portChannelCommand.append(SHUTDOWN);
                    portChannelCommand.append(LOOP_BACK_ENABLED);
                    portChannelCommand.append(NO_SHUTDOWN);
                }
                if (portGroup.isMinimumLinkEnabled()) {
                    portChannelCommand.append(String.format(MINIMUM_LINKS, ports.size()));
                }
                portChannelCommand.append(NO_SHUTDOWN);
                portChannelCommand.append(EXIT);
                for (Port port : ports) {
                    if (isLoopBackSupported && Port.Type.SERVICE_PORT == portGroup.getType() && port.isLoopbackEnabled()) {
                        portCommand.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                        portCommand.append(SHUTDOWN);
                        portCommand.append(LOOP_BACK_DISABLED);
                        portCommand.append(NO_SHUTDOWN);
                        portCommand.append(EXIT);
                    }
                    portChannelCommand.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    portChannelCommand.append(NO_CHANNEL_GROUP);
                    if (portGroup.getLineSpeed() != null && !port.getPortNumber().contains(":") && portGroup.getLineSpeed() > 0) {
                        portChannelCommand.append(String.format(SET_SPEED, portGroup.getLineSpeed()));
                    }
                    portChannelCommand.append(String.format(CHANNEL_GROUP, portGroup.getName()));
                    portChannelCommand.append(NO_SHUTDOWN);
                    portChannelCommand.append(EXIT);
                }
                command.append(portCommand);
                command.append(portChannelCommand);
            } else {
                log.error("Please provide the participating port(s).");
            }
        } else {
            log.error("SLX Port Channel object is null.");
        }
        return command.toString();
    }


    /**
     * This method builds command to delete portGroup
     *
     * @param portGroup
     * @return String returns delete commands
     */
    protected String deletePortGroup(PortGroup portGroup) {
        StringBuilder command = new StringBuilder();
        StringBuilder portLoopBackEnableCommand = new StringBuilder();
        if (portGroup != null) {
            Set<Port> ports = portGroup.getPorts();
            if (ports != null && !ports.isEmpty()) {
                for (Port port : ports) {
                    command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    command.append(NO_CHANNEL_GROUP);
                    command.append(EXIT);
                }
                command.append(String.format(NO_INTERFACE_CHANNEL_GROUP, portGroup.getName()));
                command.append(portLoopBackEnableCommand);
            } else {
                log.error("Please provide the participating port(s).");
            }
        } else {
            log.error("SLX Port Group object is null.");
        }
        return command.toString();
    }

    protected String updatePortGroup(PortGroup portGroup, PortGroup portGroupFromDb) {
        StringBuilder portChannelCommand = new StringBuilder();
        StringBuilder postPortCommand = new StringBuilder();
        StringBuilder prePortCommand = new StringBuilder();
        StringBuilder command = new StringBuilder();
        boolean isLoopBackSupported = genericOutboundHelper.isSlxLoopBackSupported(portGroup.getDevice());
        if (portGroup != null && portGroupFromDb != null) {
            Set<Port> ports = portGroup.getPorts();
            Set<Port> portsDb = portGroupFromDb.getPorts();

            if (ports != null && !ports.isEmpty() && portsDb != null && !portsDb.isEmpty()) {
                if (portGroup.getLineSpeed() != null && portGroup.getLineSpeed() > 0) {
                    if ((portGroup.getLineSpeed() != null && portGroupFromDb.getLineSpeed() == null) || (portGroup.getLineSpeed().longValue() != portGroupFromDb.getLineSpeed().longValue())) {
                        portChannelCommand.append(String.format(INTERFACE_CHANNEL_GROUP, portGroup.getName()));
                        portChannelCommand.append(SHUTDOWN);
                        portChannelCommand.append(String.format(SET_SPEED, portGroup.getLineSpeed()));
                        portChannelCommand.append(NO_SHUTDOWN);
                        portChannelCommand.append(EXIT);
                    }

                    ports.stream().forEach(port -> {
                        portChannelCommand.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                        if (!port.getPortNumber().contains(":")) {
                            portChannelCommand.append(String.format(SET_SPEED, portGroup.getLineSpeed()));
                        }
                        portChannelCommand.append(NO_SHUTDOWN);
                        portChannelCommand.append(EXIT);
                    });
                }
                portChannelCommand.append(String.format(INTERFACE_CHANNEL_GROUP, portGroup.getName()));
                if (portGroup.isMinimumLinkEnabled()) {
                    portChannelCommand.append(String.format(MINIMUM_LINKS, ports.size()));
                } else {
                    portChannelCommand.append(NO_MINIMUM_LINKS);
                }

                if (portGroup.isLoopbackEnabled() != portGroupFromDb.isLoopbackEnabled()) {
                    portChannelCommand.append(SHUTDOWN);
                    if (!portGroup.isLoopbackEnabled()) {
                        portChannelCommand.append(LOOP_BACK_DISABLED);
                    } else {
                        portChannelCommand.append(LOOP_BACK_ENABLED);
                    }
                    portChannelCommand.append(NO_SHUTDOWN);

                }
                portChannelCommand.append(EXIT);
                ports.stream().forEach(port -> {
                    Optional<Port> portOptionalDb = portsDb.stream().filter(portDb -> portDb.getId() == port.getId()).findAny();
                    if (!portOptionalDb.isPresent()) {
                        portChannelCommand.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                        portChannelCommand.append(NO_CHANNEL_GROUP);
                        portChannelCommand.append(String.format(CHANNEL_GROUP, portGroup.getName()));
                        portChannelCommand.append(NO_SHUTDOWN);
                        portChannelCommand.append(EXIT);
                        if (isLoopBackSupported && port.loopbackEnabled) {
                            prePortCommand.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                            prePortCommand.append(SHUTDOWN);
                            prePortCommand.append(LOOP_BACK_DISABLED);
                            prePortCommand.append(NO_SHUTDOWN);
                            prePortCommand.append(EXIT);
                        }
                    }
                });

                portsDb.stream().forEach(portDb -> {
                    Optional<Port> portOptional = ports.stream().filter(port -> port.getId() == portDb.getId()).findAny();
                    if (!portOptional.isPresent()) {
                        portChannelCommand.append(String.format(INTERFACE_ETHERNET, portDb.getPortNumber()));
                        portChannelCommand.append(NO_CHANNEL_GROUP);
                        portChannelCommand.append(EXIT);
                    }
                });
            } else {
                log.error("Please provide the participating port(s).");
            }
        } else {
            log.error("SLX Port Group object is null.");
        }
        command.append(prePortCommand);
        command.append(portChannelCommand);
        command.append(postPortCommand);
        return command.toString();
    }
}
