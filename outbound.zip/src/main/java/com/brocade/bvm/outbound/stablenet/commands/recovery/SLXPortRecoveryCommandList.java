package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortHistory;
import com.brocade.bvm.outbound.bsc.commands.recovery.SlxPortDescriptionRecoveryCommandBlock;
import com.brocade.bvm.outbound.utility.GenericOutboundHelper;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named
public class SLXPortRecoveryCommandList {

    @Inject
    private PortHistoryRepository portHistoryRepository;

    @Inject
    protected GenericOutboundHelper genericOutboundHelper;

    public List<CommandBlock> constructCommandBlockList(List<Port> ports, Device device) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        boolean isLoopBackSupported = genericOutboundHelper.isSlxLoopBackSupported(device);
        if (ports != null) {
            ports.stream().forEach(port -> {
                Integer deviceId = device.getStablenetId().intValue();
                List<PortHistory> portHistories = portHistoryRepository.findByIdAndWorkflowStatus(port.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);

                SlxPortDescriptionRecoveryCommandBlock slxPortDescriptionRecoveryCommandBlock = new SlxPortDescriptionRecoveryCommandBlock();
                slxPortDescriptionRecoveryCommandBlock.setDeviceId(deviceId);
                slxPortDescriptionRecoveryCommandBlock.setPort(port.getPortNumber());
                slxPortDescriptionRecoveryCommandBlock.setDescription(port.getDescription());
                commandBlocks.add(slxPortDescriptionRecoveryCommandBlock);

                SLXPortLLDPCommandBlock slxPortLLDPCommandBlock = new SLXPortLLDPCommandBlock();
                slxPortLLDPCommandBlock.setDeviceId(deviceId);
                slxPortLLDPCommandBlock.setPort(port.getPortNumber());
                commandBlocks.add(slxPortLLDPCommandBlock);

                if(isLoopBackSupported){
                    SLXPortLoopBackEnableCommandBlock slxPortLoopBackEnableCommandBlock = new SLXPortLoopBackEnableCommandBlock();
                    slxPortLoopBackEnableCommandBlock.setDeviceId(deviceId);
                    slxPortLoopBackEnableCommandBlock.setPort(port.getPortNumber());
                    commandBlocks.add(slxPortLoopBackEnableCommandBlock);
                }

                PortHistory portFromHistory = null;
                if (!portHistories.isEmpty() && portHistories.size() > 1) {
                    portFromHistory = portHistories.get(1);
                } else {
                    portHistories = portHistoryRepository.findByIdAndRevisionType(port.getId(), HistoryObject.RevisionType.CREATED);
                    if (portHistories != null && portHistories.size() > 0) {
                        portFromHistory = portHistories.stream().findFirst().get();
                    }
                }
                if (portFromHistory != null) {
                    SLXPortRemoveFECModeCommandBlock slxPortRemoveFECModeCommandBlock = new SLXPortRemoveFECModeCommandBlock();
                    slxPortRemoveFECModeCommandBlock.setDeviceId(deviceId);
                    slxPortRemoveFECModeCommandBlock.setPort(port.getPortNumber());
                    slxPortRemoveFECModeCommandBlock.setLineSpeed(portFromHistory.getLineSpeed());
                    slxPortRemoveFECModeCommandBlock.setMaxSpeed(port.getMaxSpeed());
                    commandBlocks.add(slxPortRemoveFECModeCommandBlock);

                    if (portFromHistory.getLineSpeed() > 0 && !portFromHistory.getName().contains(":")) {
                        SLXPortRestLineSpeedCommandBlock slxPortRestLineSpeedCommandBlock = new SLXPortRestLineSpeedCommandBlock();
                        slxPortRestLineSpeedCommandBlock.setDeviceId(deviceId);
                        slxPortRestLineSpeedCommandBlock.setPort(port.getPortNumber());
                        slxPortRestLineSpeedCommandBlock.setLineSpeed(portFromHistory.getLineSpeed());
                        commandBlocks.add(slxPortRestLineSpeedCommandBlock);
                    }
                }
            });
        }
        return commandBlocks;
    }
}
