package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetSLXPortSpeedJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private PortGroupRepository portGroupRepository;

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String SET_SPEED = "speed %d;";

    protected static final String NO_SHUTDOWN = "no shutdown;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_SPEED_UPDATE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method constructs set speed commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);

        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        //Filter Ports which are not part of a port group
        ports.stream()
                .filter(port -> getPortGroup(port.getId()) == null)
                .forEach(port -> {
                    if (port.getLineSpeed() > Port.SPEED_0) {
                        commands.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                        commands.append(String.format(SET_SPEED, port.getLineSpeed()));
                        commands.append(NO_SHUTDOWN);
                        commands.append(EXIT);
                    }
                });

        commands.append(EXIT);
        return commands.toString();
    }

    /**
     * This method returns PortGroup, which the selected port is part of
     *
     * @param portId
     * @return PortGroup This returns portGroup
     */
    private PortGroup getPortGroup(Long portId) {
        Long portGroupId = portGroupRepository.findByPortId(portId);
        PortGroup portGroup = null;
        if (portGroupId != null) {
            portGroup = portGroupRepository.findOne(portGroupId);
        }
        return portGroup;
    }
}
