package com.brocade.bvm.outbound.bsc.util;

import com.google.common.collect.Sets;

import javax.inject.Named;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

@Named
public class BscIdGenerator {

    private Set<String> usedFlowIds = Collections.synchronizedSet(Sets.newHashSet());
    private Set<String> usedGroupIds = Collections.synchronizedSet(Sets.newHashSet());

    //Method has to be synchronized as this is invoked my parallel threads.
    public synchronized String getFlowId(Set<String> bscFlowIds) {
        if (usedFlowIds.isEmpty()) {
            usedFlowIds.addAll(bscFlowIds);
        }
        String flowId = Integer.toString(5);
        if (!bscFlowIds.isEmpty()) {
            AtomicInteger atomicInteger = new AtomicInteger(1);
            while (bscFlowIds.contains(flowId) || usedFlowIds.contains(flowId)) {
                flowId = atomicInteger.toString();
                atomicInteger.incrementAndGet();
            }
        }
        usedFlowIds.add(flowId);
        bscFlowIds.add(flowId);
        return flowId;
    }

    public synchronized void removeFlowId(String flowId) {
        if (!usedFlowIds.isEmpty()) {
            usedFlowIds.remove(flowId);
        }
    }

    //Method has to be synchronized as this is invoked my parallel threads.
    public synchronized String getGroupId(Set<String> bscGroupIds) {
        if (usedGroupIds.isEmpty()) {
            usedGroupIds.addAll(bscGroupIds);
        }
        String gruopId = Integer.toString(5);
        if (!bscGroupIds.isEmpty()) {
            AtomicInteger atomicInteger = new AtomicInteger(1);
            while (bscGroupIds.contains(gruopId) || usedGroupIds.contains(gruopId)) {
                gruopId = atomicInteger.toString();
                atomicInteger.incrementAndGet();
            }
        }
        usedGroupIds.add(gruopId);
        bscGroupIds.add(gruopId);
        return gruopId;
    }

    public synchronized void removeGroupId(String flowId) {
        if (!usedGroupIds.isEmpty()) {
            usedGroupIds.remove(flowId);
        }
    }
}
