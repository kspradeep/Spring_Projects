package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class CommitActiveInterfaceJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_ACTIVE_INTERFACE_CREATE);
    }

    @Override
    public String getCommands(Job job) {
        ActiveInterface activeInterface = (ActiveInterface) getParentObject(job);
        ActiveInterface activeInterfaceHistory = getActiveInterfaceFromHistory(job.getParentObjectId());
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(INTERFACE);
        command.append(String.format(EDIT_INTERFACE, activeInterface.getProfileInterfaceMapping().getName()));
        if (activeInterface.getPortGroup() != null) {
            if(activeInterfaceHistory != null && activeInterfaceHistory.getPortGroup() != null){
                command.append(CLEAR).append(CPG).append(END);
            }
            command.append(SET).append(String.format(PG, activeInterface.getPortGroup().getName())).append(END);
        }
        if (activeInterface.getReplicatePortGroup() != null) {
            if(activeInterfaceHistory != null && activeInterfaceHistory.getReplicatePortGroup() != null){
                command.append(CLEAR).append(CRPG).append(END);
            }
            command.append(SET).append(String.format(RPG, activeInterface.getReplicatePortGroup().getName())).append(END);
        }
        if (activeInterface.getSamplingPolicy() != null) {
            if(activeInterfaceHistory != null && activeInterfaceHistory.getSamplingPolicy() != null){
                command.append(CLEAR).append(SP).append(END);
            }
            command.append(SET).append(String.format(SAMPLING_POLICY, activeInterface.getSamplingPolicy().getName())).append(END);
        }
        if (activeInterface.getDeDupePolicy() != null) {
            if(activeInterfaceHistory != null && activeInterfaceHistory.getDeDupePolicy() != null){
                command.append(CLEAR).append(DP).append(END);
            }
            command.append(SET).append(String.format(DEDUPE_POLICY, activeInterface.getDeDupePolicy().getName()));
        }
        if (activeInterface.getFilterPolicy() != null) {
            if(activeInterfaceHistory != null && activeInterfaceHistory.getFilterPolicy() != null){
                command.append(CLEAR).append(FP).append(END);
            }
            command.append(SET).append(String.format(FILTER_POLICY, activeInterface.getFilterPolicy().getName()));
        }
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }

}
