package com.brocade.bvm.outbound.cli;

import com.google.common.collect.ImmutableList;

/**
 * Represents a block of commands
 * If the block needs to contain multiple hierarchy, split them into multiple command blocks
 * @author ralexand
 *
 */
public interface CommandBlock {
	/**
	 * 
	 * @return a {@link ImmutableList} of block of commands that need to executed together.
	 */
	ImmutableList<CommandLet> getCommandLets();
}
