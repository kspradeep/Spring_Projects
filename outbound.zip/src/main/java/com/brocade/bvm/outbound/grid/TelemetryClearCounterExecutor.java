package com.brocade.bvm.outbound.grid;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class TelemetryClearCounterExecutor extends AbstractStablenetJobExecutor {

    private static final String CLEAR_COUNTERS_ALL = "clear counters all";

    /**
     * This method constructs CLI to reset the telemetry counters on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Device device = job.getDevice();
        StringBuilder command = new StringBuilder();
        command.append(CLEAR_COUNTERS_ALL);

        log.debug("TelemetryClearCounterExecutor on device {} command {} ", device.getId(), command);
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.TELEMETRY_CLEAR_COUNTER);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
