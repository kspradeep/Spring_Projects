package com.brocade.bvm.outbound.packetcapture.cli;

import com.brocade.bvm.outbound.exception.CliConnectorException;
import com.brocade.bvm.outbound.packetcapture.cli.model.Response;
import com.brocade.bvm.outbound.packetcapture.cli.util.CliCommandConstraints;
import com.brocade.bvm.outbound.packetcapture.cli.util.CliConstants;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.connection.channel.direct.PTYMode;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.springframework.context.annotation.Scope;

import javax.inject.Named;
import javax.xml.bind.ValidationException;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
@Scope(value = "prototype")
public class PCSshConnection {

    private static final Pattern PROMPT_REGEX = Pattern.compile(".*#\\s$", Pattern.CASE_INSENSITIVE);
    private static final Pattern CONFIRMATION_REGEX = Pattern.compile(".*\\[y\\/n\\]:$", Pattern.CASE_INSENSITIVE);
    private static final int PORT_NUMBER = 22;
    //e.g root@10.37.130.38's password:"
    private static final String destPasswordVal = "%s@%s's password:";
    private InputStream inputStream;
    private PrintStream outputStream;
    private Socket socket;
    private Session sshSession;
    private SSHClient sshClient;

    public void connect(String host, String username, String password) throws Exception {
        try {
            sshClient = new SSHClient();
            int port = PORT_NUMBER;
            // This is required when ip ssh permit-empty-password is enabled on the
            // device
            if ((username == null || username.equals("")) && (password == null || password.equals(""))) {
                username = "dummy";
            }
            sshClient.addHostKeyVerifier(new PromiscuousVerifier());
            sshClient.connect(host);

            if (!sshClient.isConnected()) {
                sshClient.disconnect();
                throw new CliConnectorException("Unable to connect to SSH server " + host);
            }
            sshClient.setConnectTimeout(CliConstants.DEFAULT_LOGIN_TIMEOUT);
            sshClient.getTransport().setTimeoutMs(CliConstants.DEFAULT_LOGIN_TIMEOUT);
            sshClient.authPassword(username, password);
            if (!sshClient.isAuthenticated()) {
                throw new CliConnectorException("Failed to authenticate to SSH host " + host);
            }

            // Connect to the host
            socket = sshClient.getSocket();

            if (!socket.isConnected() || socket.isClosed()) {
                throw new CliConnectorException("Unable to connect to SSH server " + host);
            }
            // set socket timeout to solve the blocking read issue
            socket.setSoTimeout(CliConstants.DEFAULT_LOGIN_TIMEOUT);

            final Session sshSession = sshClient.startSession();

            sshSession.allocatePTY("vt100", 80, 24, 0, 0, Collections.<PTYMode, Integer>emptyMap());
            sshSession.startShell();
            inputStream = new BufferedInputStream(sshSession.getInputStream(), CliConstants.DEFAULT_BUFFER_SIZE);
            outputStream = new PrintStream(sshSession.getOutputStream());
        } catch (IOException e) {
            log.error("Error in SSH connection with {}: {}", host, e.getMessage());
            throw new CliConnectorException("Error in SSH connection.");
        }
    }


    public List<Response> executeCommand(List<String> cmds, CliConstants.AccessMode mode, Map<String, String> copyPcapFileReq) throws CliConnectorException, ValidationException, InterruptedException {
        CliCommandConstraints cons = new CliCommandConstraints();

        return executeCommand(cmds, cons, copyPcapFileReq);
    }

    public List<Response> executeCommand(List<String> cmds, CliCommandConstraints cons, Map<String, String> copyPcapFileReq) throws CliConnectorException, ValidationException, InterruptedException {
        setSocketTimeout(CliConstants.DEFAULT_CMD_RESPONSE_TIMEOUT);
        List<Response> responses = Lists.newArrayList();
        String destIpValue = copyPcapFileReq.get("destIp");
        String destUserName = copyPcapFileReq.get("destUserName");
        String destPassword = copyPcapFileReq.get("destPassword");
        try {
            for (String cmd : cmds) {
                Response response = executeCommand(cmd, cons, true, destIpValue, destUserName);
                responses.add(response);
                if (response.isErrorOccurred()) {
                    if (cons.isStopOnError()) {
                        break;
                    }
                }
                if (response.getValue().contains("Do you want to continue") || response.getValue().contains("Are you sure you want to reload the switch")) {
                    Response newResponse = executeCommand("y", cons, true, destIpValue, destUserName);
                    // object r still refers to the object in the arraylist
                    response.setErrorOccurred(newResponse.isErrorOccurred());
                    response.setValue(newResponse.getValue());
                }
                if (response.getValue().contains("Are you sure you want to continue connecting")) {
                    Response newResponse = executeCommand("yes", cons, true, destIpValue, destUserName);
                    // object r still refers to the object in the arraylist
                    response.setErrorOccurred(newResponse.isErrorOccurred());
                    response.setValue(newResponse.getValue());
                }
                //e.g root@10.37.130.38's password:"

                if (response.getValue().contains(String.format(destPasswordVal, destUserName, destIpValue))) {
                    Response newResponse = executeCommand(destPassword, cons, true, destIpValue, destUserName);
                    // object r still refers to the object in the arraylist
                    response.setErrorOccurred(newResponse.isErrorOccurred());
                    response.setValue(newResponse.getValue());
                }
                if (response.getValue().contains("No such file or directory")) {
                    throw new ValidationException("No file available for download.");
                }
                if (response.getValue().contains("capture is enabled on interface")) {
                    throw new ValidationException("No file available for download.");
                }
                if (response.getValue().toLowerCase().contains("permission denied")) {
                    throw new ValidationException("Invalid credentials!");
                }
                if (response.getValue().toLowerCase().contains("connection timed out")) {
                    throw new ValidationException("Connection timed out");
                }
                if (response.getValue().toLowerCase().contains("invalid argument")) {
                    throw new ValidationException("Invalid argument!");
                }
            }
        } catch (CliConnectorException e) {
            log.error("Error in executing cli commands {}", e.getMessage());
            throw new CliConnectorException("Error executing cli commands " + " : " + e.getMessage());
        }
        return responses;
    }

    private Response executeCommand(String cmd, CliCommandConstraints cons, boolean prefixNewLine, String destIp, String destUserName)
            throws CliConnectorException, InterruptedException {
        Response response = new Response();
        send(cmd, prefixNewLine);
        StringBuilder sb = new StringBuilder(10000);
        readData(sb, true, destIp, destUserName);
        // the command that is sent is returned back while reading data.
        // so strip the echoed command
        stripCommandEcho(cmd, sb);
        String data = sb.toString().trim();
        response.setValue(data);
        return response;
    }

    public void send(String cmd, boolean prefixNewLine) throws InterruptedException {
        if (prefixNewLine) {
            write(cmd + "\r");
        } else {
            write(cmd);
        }
    }

    public void write(String cmd) throws InterruptedException {
        if (outputStream != null) {
            outputStream.println(cmd);
            outputStream.flush();

        }
    }

    public String readData() throws CliConnectorException {
        StringBuilder sb = new StringBuilder();
        readData(sb, false, null, null);
        return sb.toString();
    }

    public int readData(StringBuilder result, boolean stripPrompt, String destIpValue, String destUserName) throws CliConnectorException {
        byte[] buf = new byte[CliConstants.DEFAULT_BUFFER_SIZE];
        int startIndex = 0;
        int totalCount = 0;
        while (true) {
            int dataRead = read(buf);
            if (dataRead > 0) {
                totalCount += dataRead;
                result.ensureCapacity(totalCount);
                // find end of line index in the result buffer starting from behind
                // Use that index as the start index to find the end of data marker
                for (int i = result.length() - 1; i >= 0; i--) {
                    if (result.charAt(i) == '\n' || result.charAt(i) == '\r') {
                        startIndex = i;
                        break;
                    }
                }
                StringBuilder resultLine = new StringBuilder();
                for (int i = 0; i < dataRead; i++) {
                    resultLine.append((char) buf[i]);
                    result.append((char) buf[i]);
                }
                log.debug("Device output: {}", resultLine.toString());
                if (isEndOfData(result, startIndex, stripPrompt)) {
                    break;
                } else if (isConfirmationCmd(result, startIndex)) {
                    break;
                } else if (result.toString().contains("Are you sure you want to continue connecting (yes/no)")) {
                    break;
                } else if (result.toString().contains(String.format(destPasswordVal, destUserName, destIpValue))) {
                    break;
                } else if (result.toString().contains("No such file or directory")) {
                    break;
                } else if (result.toString().contains("capture is enabled on interface")) {
                    break;
                } else if (result.toString().toLowerCase().contains("permission denied")) {
                    break;
                } else if (result.toString().toLowerCase().contains("connection timed out")) {
                    break;
                } else if (result.toString().toLowerCase().contains("invalid argument")) {
                    break;
                }

            } else {
                break;
            }
        }
        return totalCount;
    }

    private void stripCommandEcho(String cmd, StringBuilder sb) {
        int si = sb.indexOf(cmd);
        if (si >= 0) {
            int ei = si + cmd.length();
            sb.delete(si, ei);
        }
    }

    public boolean isConnected() {
        return sshClient.isConnected();

    }

    private int read(byte[] b) throws CliConnectorException {
        if (inputStream == null) {
            return 0;
        }
        int dataRead = 0;
        try {
            dataRead = inputStream.read(b, 0, b.length);
        } catch (IOException e) {
            log.error("Unable to read data");
            return 0;
        }
        if (dataRead == -1) {
            disconnect();
            log.error("Connection to host lost");
        }
        return dataRead;
    }

    public void disconnect() throws CliConnectorException {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (sshSession != null) {
                sshSession.close();
            }
            if (sshClient != null) {
                sshClient.disconnect();
            }
            inputStream = null;
            outputStream = null;
            sshSession = null;
            socket = null;
            sshClient = null;
        } catch (IOException e) {
            log.error("Error in disconnect {}", e.getMessage());
            throw new CliConnectorException("Error in disconnect " + e.getMessage());
        }
    }


    private boolean isEndOfData(StringBuilder sb, int startIndex, boolean stripPrompt) {
        Matcher m = PROMPT_REGEX.matcher(sb);
        if (m.find(startIndex)) {
            if (stripPrompt) {
                sb.delete(m.start(), m.end());
            }
            return true;
        }
        return false;
    }

    private boolean isConfirmationCmd(StringBuilder sb, int startIndex) {
        Matcher m = CONFIRMATION_REGEX.matcher(sb);
        if (m.find(startIndex)) {
            return true;
        }
        return false;
    }


    public void setSocketTimeout(int to) throws CliConnectorException {
        try {
            if (null != socket) {
                socket.setSoTimeout(to);
            } else {
                log.error("Socket is already closed and deleted");
            }
        } catch (SocketException e) {
            log.error("Error setting socket timeout {}", e.getMessage());
            throw new CliConnectorException("Error setting socket timeout " + e.getMessage());
        }
    }

}
