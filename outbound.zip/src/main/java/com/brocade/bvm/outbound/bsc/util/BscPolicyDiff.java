
package com.brocade.bvm.outbound.bsc.util;

import com.brocade.bvm.model.db.Rule;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by dneelapa on 7/13/2016.
 */

@Getter
@NoArgsConstructor
public class BscPolicyDiff {
    @Setter
    private List<Rule> deletedRules;

    @Setter
    private List<Rule> unchangedRules;

    @Setter
    private Map<String,RuleOperation> ruleOperationMap;


    @Setter
    private Set<Rule> addedRules;

    @Setter
    private Transition oldCategory;

    @Setter
    private Transition newCategory;

    @Setter
    Boolean isEgressChanged = false;

    @Setter
    Boolean isPGAlterationNeeded = false;

    @Setter
    Boolean isPGChanged = false;

    @Setter
    @Enumerated(EnumType.STRING)
    private Transition transition;

    public enum Transition {
        SI_SE, SI_ME, MI_SE, MI_ME, SI_PG, MI_PG
    }

    public enum RuleOperation {
        NO_OP,
        PUT,
        DELETE
    }


    public void addToRuleOperationMap(String ruleVerifyString,RuleOperation operation){
        ruleOperationMap.put(ruleVerifyString,operation);
    }

}




