package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class PacketTruncationRemoveProfileCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String profileName;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is profile name
     * eg: do show running-config truncation-profile test_name
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config truncation-profile %s";

    /**
     * <pre>
     * eg: truncation-profile test_name
     * </pre>
     */
    private static final String MATCH_CMD = "truncation-profile %s";

    /**
     * <pre>
     * eg: no truncation-profile test_name
     * </pre>
     */
    private static final String ACTION_CMD = "no truncation-profile %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, profileName));
        args.add(String.format(MATCH_CMD, profileName));
        args.add(String.format(ACTION_CMD, profileName));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "PacketTruncationRemoveProfileCommandBlock{" +
                "deviceId=" + deviceId +
                ", profileName='" + profileName + '\'' +
                ", writeMem='" + writeMem + '\'' +
                '}';
    }
}
