package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXNextHopCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String routeMapPattern;

    @Getter
    @Setter
    private String routeMapName;

    @Getter
    @Setter
    private String setNextHopCommand;

    @Getter
    @Setter
    private String writeMem = "false";

    @Getter
    @Setter
    private boolean isDeviceSLX9850WithUda;

    @Getter
    @Setter
    private boolean isSlxDefaultRouteEnabled;

    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is interface type  #2 interface name/id
     * eg: do show running-config interface ethernet 1/1
     * eg: do show running-config interface port-channel 20
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config route-map %s";

    /**
     * <pre>
     * argument #1 is set-next-hop command
     *  precedence 10 set interface ethernet 0/28
     * </pre>
     */
    private static final String MATCH_CMD = " precedence (\\d+) %s";

    /**
     * <pre>
     * argument #1 is route-map name, #2 is route-map pattern, #3 is set next hop command
     * eg: no set interface ethernet 0/2 \n no set interface ethernet  0/2
     * </pre>
     */
    private static final String ACTION_CMD = "route-map %s %s\n%s\nexit";

    /**
     * <pre>
     * argument #1 is route-map name, #2 is route-map pattern, #3 is set next hop command
     * eg: no set interface ethernet 0/2 \n no set interface ethernet  0/2
     * </pre>
     */
    private static final String ACTION_CMD_FOR_9850_UDA = "route-map %s %s\n%s\n%s\nexit";

    protected static final String NO_WITH_COMMAND = "no %s";

    protected static final String NO_SET_UDA_INTERFACE_NULL = "no set uda interface null0;";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, routeMapName));
        args.add(String.format(MATCH_CMD, setNextHopCommand));
        if(isDeviceSLX9850WithUda){
            args.add(String.format(ACTION_CMD_FOR_9850_UDA, routeMapName, routeMapPattern, (String.format(NO_WITH_COMMAND, setNextHopCommand)), isSlxDefaultRouteEnabled ? NO_SET_UDA_INTERFACE_NULL : ""));
        } else{
            args.add(String.format(ACTION_CMD, routeMapName, routeMapPattern, (String.format(NO_WITH_COMMAND, setNextHopCommand))));
        }
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXNextHopCommandBlock [deviceId=" + deviceId + ", routeMapName=" + routeMapName + ", routeMapPattern=" + routeMapPattern + ", getTemplateJobInput()="
                + getTemplateJobInput() + "]";
    }
}
