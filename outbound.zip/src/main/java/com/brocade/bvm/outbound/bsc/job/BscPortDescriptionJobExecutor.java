package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.brocade.bvm.outbound.stablenet.job.StablenetPortDescriptionJobExecutor;
import com.google.common.collect.Lists;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by dneelapa on 6/21/2016.
 */
@Named
public class BscPortDescriptionJobExecutor  extends StablenetPortDescriptionJobExecutor {

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.MLXE, Device.Type.ICX);
    }
}
