
package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.PortHistory;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The SlxPortAdminStatusJobExecutor class implements methods to enable/disable the selected port(s) as L2/L3/L23 on Open Flow SLX device through Stablenet
 */
@Named
public class SlxPortAdminStatusJobExecutor extends AbstractStablenetJobExecutor {

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String INTERFACE_ENTER = "interface Ethernet %s;";
    private static final String ENABLE_OPENFLOW = "openflow enable %s;no shutdown;";
    private static final String DISABLE_OPENFLOW = "no openflow enable;shutdown;";
    private static final String INTERFACE_EXIT = "exit;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_ENABLE, Job.Type.PORT_DISABLE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method is used to build commands to enable/disable the selected port(s) as L2/L3/L23 on Open Flow SLX device
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(TERMINAL_ENTER);
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());
        ports.forEach(port -> {
            commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));
            if (job.getType() == Job.Type.PORT_ENABLE) {
                commands.append(DISABLE_OPENFLOW);
                commands.append(String.format(ENABLE_OPENFLOW, port.getMode()));
            } else if (job.getType() == Job.Type.PORT_DISABLE) {
                commands.append(DISABLE_OPENFLOW);
            }
            commands.append(INTERFACE_EXIT);
        });
        commands.append(INTERFACE_EXIT);
        return commands.toString();
    }

}
