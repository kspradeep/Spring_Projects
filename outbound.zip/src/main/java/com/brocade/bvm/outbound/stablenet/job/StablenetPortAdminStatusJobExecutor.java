package com.brocade.bvm.outbound.stablenet.job;

import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.inject.Named;

import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;

/**
 * The StablenetPortAdminStatusJobExecutor class implements methods to change the AdminStatus(enable/disable) of port on Non Open Flow device through Stablenet
 */
@Named
public class StablenetPortAdminStatusJobExecutor extends AbstractStablenetJobExecutor {

    private static final String TERMINAL_ENTER = "configure terminal;";
    private static final String INTERFACE_ENTER = "interface ethernet %s;";
    private static final String INTERFACE_STATUS = "%s;";
    private static final String INTERFACE_EXIT = "exit;";
    private static final String TERMINAL_EXIT = "end;";
    private static final String SAVE_RUNNING_CONFIG = "write memory;";
    private static final String LAG_ENTER = "lag \"%s\";";
    private static final String LAG_ENABLE_DISABLE_PORT = "%s ethernet %s;";
    private static final String LAG_EXIT = "exit;";
    
    @Inject
    private PortGroupRepository portGroupRepository;

    /**
     * This method constructs port enable/disable commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {

        String portAdminStatus;
        switch (job.getType()) {
            case PORT_ENABLE:
                portAdminStatus = "enable";
                break;
            case PORT_DISABLE:
                portAdminStatus = "disable";
                break;
            default:
                portAdminStatus = "nooperation"; //TODO
        }

        StringBuilder commands = new StringBuilder(TERMINAL_ENTER);
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        //Ports not part of a port group
        ports.stream()
                .filter(port -> getPortGroup(port.getId()) == null)
                .forEach(port -> {
                    commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));
                    commands.append(String.format(INTERFACE_STATUS, portAdminStatus));
                    commands.append(INTERFACE_EXIT);
                });

        //Ports part of an active part group
        Multimap<PortGroup, Port> portGroupMap = ArrayListMultimap.create();
        for(Port port : ports) {
        	PortGroup portGroup = getPortGroup(port.getId());
        	if(portGroup != null && portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
        		portGroupMap.put(portGroup, port);
        	}
        }

        for (PortGroup portGroup : portGroupMap.keys()) {
            commands.append(String.format(LAG_ENTER, portGroup.getName()));
            portGroupMap.get(portGroup).stream()
                    .forEach(port -> commands.append(String.format(LAG_ENABLE_DISABLE_PORT, portAdminStatus, port.getPortNumber())));
            commands.append(LAG_EXIT);
        }

        commands.append(TERMINAL_EXIT);
        commands.append(SAVE_RUNNING_CONFIG);

        return commands.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_ENABLE, Job.Type.PORT_DISABLE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method returns PortGroup, which the selected port is part of
     *
     * @param portId
     * @return PortGroup This returns portGroup
     */
    private PortGroup getPortGroup(Long portId) {
    	Long portGroupId = portGroupRepository.findByPortId(portId);
        PortGroup portGroup = null;
        if(portGroupId!=null) {
        	portGroup = portGroupRepository.findOne(portGroupId);
        }
        return portGroup;
    }
}
