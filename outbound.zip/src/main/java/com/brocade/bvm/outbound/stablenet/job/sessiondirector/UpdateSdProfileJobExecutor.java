package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.ProfileMappingRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.ProfileMapping;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class UpdateSdProfileJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private ProfileMappingRepository profileMappingRepository;

    private static final String PROFILES = "profiles;";

    private static final String SET_PROFILE = "set profile id=%d;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_PROFILE_UPDATE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    /**
     * This method constructs set speed commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(job.getDevice().getId());
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        commands.append(PROFILES);
        commands.append(String.format(SET_PROFILE, profileMapping.getProfile().getProfileId()));
        commands.append(EXIT);
        commands.append(EXIT);
        return commands.toString();
    }
}
