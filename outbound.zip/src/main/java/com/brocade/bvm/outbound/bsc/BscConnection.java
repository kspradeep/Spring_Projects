package com.brocade.bvm.outbound.bsc;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.outbound.AbstractRestConnection;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;

@Named
public class BscConnection extends AbstractRestConnection {
	
	private Client client;

	@Inject
	private ConfigRepository configRepository;

	protected String getBaseUrl() {
		return configRepository.findByKey(ApplicationConfig.Key.OdlRestUrl).getValue();
	}

    protected Client getClient() {
        return new JerseyClientBuilder()
                .sslContext(sslContext())
                .hostnameVerifier(hostnameVerifier()).build().register(HttpAuthenticationFeature.basic(
                        configRepository.findByKey(ApplicationConfig.Key.OdlUsername).getValue(), configRepository.findByKey(ApplicationConfig.Key.OdlPassword).getValue()));
    }
}
