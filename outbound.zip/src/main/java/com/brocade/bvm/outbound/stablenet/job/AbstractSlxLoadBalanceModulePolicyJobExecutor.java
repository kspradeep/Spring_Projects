package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.SlxLoadBalanceModulePolicy;
import com.google.common.collect.Lists;

import java.util.List;

/**
 * The AbstractSlxLoadBalanceModulePolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE of LoadBalanceModulePolicy on Non Open Flow SLX device through Stablenet
 */
public abstract class AbstractSlxLoadBalanceModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    /**
     * Command to enter into configuration mode
     */
    protected static final String CONFIGURE_TERMINAL = "configure terminal;";
    protected static final String APPLY_LOAD_BALANCE_POLICY = "load-balance %s;";

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method builds delete commands to be applied on the device
     *
     * @param modulePolicy
     * @param module
     * @return String
     */
    protected String buildDeleteModulePolicyForModule(SlxLoadBalanceModulePolicy modulePolicy, Module module) {
        StringBuilder cmd = new StringBuilder();
        Integer moduleNumber = module.getModuleNumber();
        cmd.append(String.format(APPLY_LOAD_BALANCE_POLICY, SlxLoadBalanceModulePolicy.LoadBalancePolicy.SRC_DST_IP_MAC_VID_PORT.getloadBalancePolicy()));
        return cmd.toString();
    }

    /**
     * This method builds create commands to be applied on the device
     *
     * @param modulePolicy
     * @param module
     * @return String
     */
    protected String buildCreateModulePolicyForModule(SlxLoadBalanceModulePolicy modulePolicy, Module module) {
        StringBuilder cmd = new StringBuilder();
        Integer moduleNumber = module.getModuleNumber();
        cmd.append(String.format(APPLY_LOAD_BALANCE_POLICY, modulePolicy.getSelectedLoadBalancePolicy().getloadBalancePolicy()));
        return cmd.toString();
    }
}
