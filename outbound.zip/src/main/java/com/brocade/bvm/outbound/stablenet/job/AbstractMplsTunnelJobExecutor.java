package com.brocade.bvm.outbound.stablenet.job;

/**
 * Created by kraikar on 8/10/2016.
 */
public abstract class AbstractMplsTunnelJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String ROUTER_MPLS = "router mpls;";

    protected static final String MPLS_TUNNEL_CONFIG = "lsp \"%s\";";

    protected static final String TUNNEL_ENABLE = "enable;";

    protected static final String TUNNEL_DISABLE = "disable;";
}
