package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.SlxLoadBalanceModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetLoadBalanceModulePolicyCommitJobExecutor class implements methods to create LoadBalanceModulePolicy on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetSlxLoadBalanceModulePolicyDeleteJobExecutor extends AbstractSlxLoadBalanceModulePolicyJobExecutor {

    /**
     * This method constructs create LoadBalanceModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        SlxLoadBalanceModulePolicy modulePolicy = (SlxLoadBalanceModulePolicy) getParentObject(job);
        StringBuilder cmd = new StringBuilder();
        cmd.append(CONFIGURE_TERMINAL);
        modulePolicy.getModules().stream().forEach(module -> {
            cmd.append(buildDeleteModulePolicyForModule(modulePolicy, module));
        });
        cmd.append(EXIT);
        log.trace("cmd = " + cmd.toString());
        return cmd.toString();
    }

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.LOAD_BALANCE_MODULE_POLICY_DELETE);
    }

}
