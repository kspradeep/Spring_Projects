package com.brocade.bvm.outbound.bsc.job;

import java.util.List;
import java.util.Map;

import javax.inject.Named;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Status;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

/**
 * The BscPortGroupDeleteJobExecutor class implements methods to delete portGroup on Open Flow device through BSC
 */
@Named
@Slf4j
public class BscPortGroupDeleteJobExecutor extends AbstractBscPortGroupJobExecutor {

	@Override
	public List<Type> getSupportedJobTypes() {
		return Lists.newArrayList(Type.PORT_GROUP_DELETE);
	}

    /**
     * This method used to delete portGroup on Open Flow device
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
	@Override
	public OutboundJobResponse execute(Job job) {
		PortGroup portGroup = (PortGroup)getParentObject(job);
		String openFlowDeviceId = portGroup.getDevice().getOpenflowId();
        Map<String,String> grpMap = getGroupNameIdMap(openFlowDeviceId);// not null check
        String grpName = portGroup.getName();
        log.info("delete lag : "+grpName);
        log.info("delete device lag : "+openFlowDeviceId);
        log.info("delete map : "+grpMap);
        String grpkey = grpName+"_select";
        String groupId = grpMap.get(grpkey);
        log.info("delete grpkey : "+grpkey);
        log.info("delete grpid : "+groupId);
        if (groupId != null) {
            boolean jobResult = deleteGroupOnDevice(openFlowDeviceId, groupId);
            if (jobResult) {
                return new OutboundJobResponse(Status.SUCCESS, "Port Group Deletion Successful on Device");
            } else {
                return new OutboundJobResponse(Status.FAILED, "Port Group Deletion Failed on Device");
            }
        } else {
            return new OutboundJobResponse(Status.SUCCESS, "Port Group Deletion Successful on Device");
        }
    }
}
