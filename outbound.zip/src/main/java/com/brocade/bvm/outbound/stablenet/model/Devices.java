package com.brocade.bvm.outbound.stablenet.model;

import lombok.Data;

/**
 * To Construct XML Content for StableNet Rest Job Template (For Job Deploy).
 */
@Data
public class Devices {
    private String deviceid;
}
