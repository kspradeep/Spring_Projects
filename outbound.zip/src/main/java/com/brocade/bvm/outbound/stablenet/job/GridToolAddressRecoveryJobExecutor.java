package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.grid.GridMatrixHistoryRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.grid.GridMatrix;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.GridToolAddressCommandBlock;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@Named
public class GridToolAddressRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Inject
    private GridMatrixHistoryRepository gridMatrixHistoryRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Override
    public List<CommandBlock> getCommands(Job job) {
        GridMatrix gridMatrix = (GridMatrix) getParentObject(job);
        return constructCommandBlockList(gridMatrix, job.getDevice());
    }

    private List<CommandBlock> constructCommandBlockList(GridMatrix gridMatrix, Device device) {
        List<CommandBlock> finalCommandBlocks = new ArrayList<>();
        if(gridMatrix != null) {
            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
            if (gridMatrix.getGridTopologyPaths() != null) {
                Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = getToolAddressMap(gridMatrix.getGridTopologyPaths(), device.getId());
                toolAddressInterfaceMap.forEach((toolAddress, toolAddressInterface) -> {
                    GridToolAddressCommandBlock gridToolAddressCommandBlock = new GridToolAddressCommandBlock();
                    gridToolAddressCommandBlock.setDeviceId(device.getStablenetId().intValue());
                    gridToolAddressCommandBlock.setPbfDestinationId(toolAddress);
                    finalCommandBlocks.add(gridToolAddressCommandBlock);
                });
            }
            if (gridMatrixHistory != null && gridMatrixHistory.getGridTopologyPaths() != null) {
                Map<Integer, ToolAddressInterface> toolAddressInterfaceMapHistory = getToolAddressMap(gridMatrixHistory.getGridTopologyPaths(), device.getId());
                toolAddressInterfaceMapHistory.forEach((toolAddress, toolAddressInterface) -> {
                    GridToolAddressCommandBlock gridToolAddressCommandBlock = new GridToolAddressCommandBlock();
                    gridToolAddressCommandBlock.setDeviceId(device.getStablenetId().intValue());
                    gridToolAddressCommandBlock.setPbfDestinationId(toolAddress);
                    finalCommandBlocks.add(gridToolAddressCommandBlock);
                });
            }
        }
        if (!finalCommandBlocks.isEmpty()) {
            finalCommandBlocks.get(finalCommandBlocks.size() - 1).setWriteMem("true");
        }
        log.debug("Number of command blocks constructed for GridToolAddressRecoveryJobExecutor id {} is :{}", gridMatrix.getId(), finalCommandBlocks.size());
        return finalCommandBlocks;
    }

    private Map<Integer, ToolAddressInterface> getToolAddressMap(Set<GridTopologyPath> gridTopologyPaths, Long deviceId) {
        Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = Maps.newHashMap();
        gridTopologyPaths.forEach(gridTopologyPathCurrent -> {
            GridTopologyPath gridTopologyPath = gridTopologyPathRepository.findOne(gridTopologyPathCurrent.getId());
            if (gridTopologyPath != null) {
                if (gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getSourceNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else if (gridTopologyPath.getDestinationNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getDestinationNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else {
                    gridTopologyPath.getIntermediateNodes().forEach(intermediateNode -> {
                        if (intermediateNode.getDevice().getId() == deviceId) {
                            Integer toolAddress = gridTopologyPath.getToolAddress();
                            if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                                ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                                toolAddressInterface.setToolAddress(toolAddress);
                                toolAddressInterface.setManagedObjects(intermediateNode.getEgressPortsAndPortGroups());
                                toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                            }
                        }
                    });
                }
            }
        });
        return toolAddressInterfaceMap;
    }

    private GridMatrix getGridMatrixFromHistory(Long matrixId) {
        List<GridMatrixHistory> gridMatrixHistoryList = gridMatrixHistoryRepository.findByIdAndWorkflowStatus(matrixId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GridMatrix gridMatrix = null;
        if (gridMatrixHistoryList.size() >= 1) {
            GridMatrixHistory gridMatrixHistory = gridMatrixHistoryList.get(0);
            gridMatrix = gridMatrixHistory.buildParent();
        }
        return gridMatrix;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GRID_TOOL_ADDRESS_ROLLBACK);
    }

    @Getter
    @Setter
    class ToolAddressInterface {
        private Integer toolAddress;

        private Set<ManagedObject> managedObjects;

        private boolean countEnabled;
    }
}
