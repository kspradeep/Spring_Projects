package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.Rule;
import com.brocade.bvm.model.db.RuleSet;
import lombok.extern.slf4j.Slf4j;

import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Slf4j
public final class BeanUtil {

    public static final Policy removeDuplicates(Policy policy) {
        if (policy == null) {
            log.info("Policy is empty");
            return policy;
        }

        policy.getFlows().forEach(flow -> {
            SortedSet<RuleSet> distinctRuleSets = new TreeSet<>();
            Set<Long> ids = new HashSet<>();
            for (RuleSet ruleSet : flow.getRuleSets()) {
                if (ruleSet.getId() == null || ruleSet.getId().longValue() == 0) {
                    break;
                } else if (!ids.contains(ruleSet.getId().longValue())) {
                    distinctRuleSets.add(ruleSet);
                    ids.add(ruleSet.getId().longValue());

                    // removing duplicate rules
                    SortedSet<Rule> distinctRuleSet = new TreeSet<>();
                    Set<Long> ruleIds = new HashSet<Long>();
                    for (Rule rule : ruleSet.getRules()) {
                        if (rule.getId() == null || rule.getId().longValue() == 0) {
                            break;
                        } else if (!ruleIds.contains(rule.getId().longValue())) {
                            distinctRuleSet.add(rule);
                            ruleIds.add(rule.getId().longValue());
                        }
                    }
                    if (!distinctRuleSet.isEmpty()) {
                        ruleSet.setRules(distinctRuleSet);
                    }
                }
            }
            if (!distinctRuleSets.isEmpty()) {
                flow.setRuleSets(distinctRuleSets);
            }
            // Removing duplicate egressPorts
            ids.clear();
            Set<Port> egressSet = new HashSet<>();
            Set<Port> egressPorts = flow.getEgressPorts();
            if (egressPorts != null) {
                for (Port egress : egressPorts) {
                    if (egress.getId() == null || egress.getId().longValue() == 0) {
                        break;
                    } else if (!ids.contains(egress.getId().longValue())) {
                        ids.add(egress.getId().longValue());
                        egressSet.add(egress);
                    }
                }
            }
            if (!egressSet.isEmpty()) {
                flow.setEgressPorts(egressSet);
            }
        });

        return policy;
    }
}
