package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The BscPortGroupCreateJobExecutor class implements methods to create portGroup on Open Flow device through BSC
 */
@Named
@Slf4j
public class BscPortGroupCreateJobExecutor extends AbstractBscPortGroupJobExecutor {

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.PORT_GROUP_CREATE);
    }

    /**
     * This method used to create portGroup on Open Flow device
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
    @Override
    public OutboundJobResponse execute(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        Set<Port> ports = portGroup.getPorts();
        // Converting port number to port name by prepending with 'eth'
        List<String> portIds = ports.stream().map(port -> port.getOpenFlowPortNumber()).collect(Collectors.toList());
        Device device = portGroup.getDevice();
        String openFlowDeviceId = device.getOpenflowId();
        Map<String, List<String>> groupIdNameMap = getGroupInfo(openFlowDeviceId);
        List<String> grpIds = groupIdNameMap.get("ids");
        Map<String, String> portIdNameMap = getPortNameIdMap(openFlowDeviceId);
        List<String> portIdList = new ArrayList<>();
        for (String portName : portIds) {
            String portid = portIdNameMap.get(portName);
            if (portid != null)
                portIdList.add(portid);
        }
        checkIfValidInterface(portIdNameMap,portIds);
        StringBuilder groupName = new StringBuilder(portGroup.getName());
        groupName.append("_select");
        Set<String> groupIds = Sets.newHashSet(grpIds);
        String groupId = bscIdGenerator.getGroupId(groupIds);
        String group = buildPortGroup(groupId, groupName.toString(), "group-select", portIdList);
        boolean jobResult = addGroupOnDevice(openFlowDeviceId, groupId, group, portIdList, device.getType());
        if (jobResult) {
            return new OutboundJobResponse(Job.Status.SUCCESS, "Port Group Creation Successful on Device");
        } else {
            return new OutboundJobResponse(Job.Status.FAILED, "Port Group Creation Failed on Device");
        }

    }

    /**
     * This method used to get the existing group ids, group names on the Open Flow device
     *
     * @param deviceId
     * @return Map<String, List<String>> This returns map of groupIds and groupNames
     */
    private Map<String, List<String>> getGroupInfo(String deviceId) {
        Map<String, List<String>> groupIdNameMap = new HashMap<>();
        List<String> groupIdList = new ArrayList<>();
        List<String> groupNameList = new ArrayList<>();
        try {
            Response res = bscConnection.get(configUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
            if (res != null && res.getStatus() == 200) {
                String xmlString = res.readEntity(String.class);
                JSONObject xmlJSONObj;
                try {
                    xmlJSONObj = XML.toJSONObject(xmlString);
                    String removeKey = "xmlns";
                    removeJSONField(xmlJSONObj, removeKey);
                    removeKey = "xmlns:x";
                    removeJSONField(xmlJSONObj, removeKey);
                    removeKey = "xmlns:s";
                    removeJSONField(xmlJSONObj, removeKey);
                    JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
                    if (realNode.has("group")) {
                        Object groupObj = realNode.get("group");
                        if (groupObj instanceof JSONObject) {// single group
                            JSONObject groupNode = (JSONObject) groupObj;
                            if (groupNode.has("group-name") && groupNode.has("group-id")) {
                                groupIdList.add(groupNode.get("group-id").toString());
                                groupNameList.add(groupNode.get("group-name").toString());
                            }
                        } else if (groupObj instanceof JSONArray) {
                            JSONArray groupNodes = (JSONArray) groupObj;
                            int size = groupNodes.length();
                            for (int i = 0; i < size; i++) {
                                JSONObject groupNode = groupNodes.getJSONObject(i);
                                if (groupNode.has("group-name") && groupNode.has("group-id")) {
                                    groupIdList.add(groupNode.get("group-id").toString());
                                    groupNameList.add(groupNode.get("group-name").toString());
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    log.error(e.getMessage());
                    return null;
                }
            }
        } catch (OutboundConnectionException e) {
            //TODO: Expected scenario as we are loading the groups from Config datastore.
            if (!e.getMessage().contains("404")) {
                throw e;
            }
        }
        groupIdNameMap.put("ids", groupIdList);
        groupIdNameMap.put("names", groupNameList);
        return groupIdNameMap;
    }

}
