package com.brocade.bvm.outbound;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.TargetHost;

import java.util.List;


public interface OutboundJobExecutor {
    List<Job.Type> getSupportedJobTypes();
    TargetHost.Mode getSupportedMode();
    List<Device.Type> getSupportedDeviceTypes();
    Long startExternalJob(Job job);
    OutboundJobResponse execute(Job job);
}
