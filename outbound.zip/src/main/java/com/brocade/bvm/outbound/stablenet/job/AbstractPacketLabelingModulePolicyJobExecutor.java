package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PacketLabelingModulePolicy;


public abstract class AbstractPacketLabelingModulePolicyJobExecutor extends AbstractStablenetJobExecutor {
    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String END = "end;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String MODULE_POLICY_SOURCE_PORT_LABELING_FORMAT = "source-port-label slot %s %s;";

    protected static final String MODULE_POLICY_REVERT_SOURCE_PORT_LABELING_FORMAT = "no source-port-label slot %s %s;";

    private static final String DEVICE_ID = "device-id ";

    /**
     * This method returns processorNumber value to be applied on the device based on device OS and processor number
     *
     * @param device
     * @param modulePolicy
     * @return String returns processorVal
     */
    protected String getProcessor(Device device, PacketLabelingModulePolicy modulePolicy) {
        String processorVal = modulePolicy.getProcessor().getProcessorNumber();
        if (PacketLabelingModulePolicy.ProcessorNumber.ALL == modulePolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = isOsVersion6(device) ? DEVICE_ID + processorVal : processorVal;
        }
        return processorVal;
    }

    /**
     * This method checks if the given device OS version is above 6
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        int osMajorVersion = device.getOsMajorVersion();
        return osMajorVersion >= MLXE_OS_MAJOR_VERSION;
    }
}
