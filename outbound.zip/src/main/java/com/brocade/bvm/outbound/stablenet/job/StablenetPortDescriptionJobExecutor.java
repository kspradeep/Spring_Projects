package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by dneelapa on 6/21/2016.
 * <p>
 * The StablenetPortDescriptionJobExecutor class implements methods to create/update/delete port description on Non Open Flow device through Stablenet
 */
@Named
public class StablenetPortDescriptionJobExecutor extends AbstractStablenetJobExecutor {

    private static final String CONFIGURE_TERMINAL = "configure terminal;";
    private static final String EXIT = "exit;";
    private static final String WRITE_MEMORY = "write memory;";
    private static final String INTERFACE_ENTER = "interface ethernet %s;";
    private static final String REMOVE_DESCRIPTION = "no port-name;";
    private static final String ADD_DESCRIPTION = "port-name %s;";

    /**
     * This method constructs create/update/delete port description commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        List<Port> ports = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toList());

        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        ports.stream().forEach(port -> {
                    commands.append(String.format(INTERFACE_ENTER, port.getPortNumber()));
                    if (port.getCustomDescription() != null && !port.getCustomDescription().trim().isEmpty()) {
                        commands.append(String.format(ADD_DESCRIPTION, port.getCustomDescription()));
                    } else {
                        commands.append(REMOVE_DESCRIPTION);
                    }
                    commands.append(EXIT);
                });
        commands.append(WRITE_MEMORY);
        return commands.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_DESCRIPTION);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }
}
