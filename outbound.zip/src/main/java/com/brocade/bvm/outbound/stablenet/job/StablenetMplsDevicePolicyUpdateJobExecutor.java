package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.MPLSDevicePolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.MPLSDevicePolicy;
import com.brocade.bvm.model.db.MPLSPair;
import com.brocade.bvm.model.db.PacketStampingModulePolicy;
import com.brocade.bvm.model.db.history.MPLSDevicePolicyHistory;
import com.brocade.bvm.model.db.history.PacketStampingModulePolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The StablenetMplsDevicePolicyUpdateJobExecutor class implements methods to update MplsDevicePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetMplsDevicePolicyUpdateJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String MPLS_UNKNOWN_LABEL_FORWARD = "mpls-unknown-label-forward ingress %s egress %s;";
    protected static final String REMOVE_MPLS_UNKNOWN_LABEL_FORWARD = "no mpls-unknown-label-forward ingress %s egress %s;";

    @Inject
    private MPLSDevicePolicyHistoryRepository mplsDevicePolicyHistoryRepository;

    /**
     * This method constructs update MPLSDevicePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        // TODO :: Need to handle Reload of the System.
        MPLSDevicePolicy newMplsDevicePolicy = (MPLSDevicePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        if (newMplsDevicePolicy != null) {
            MPLSDevicePolicy oldMplsDevicePolicy = getMplsDevicePolicyFromHistory(newMplsDevicePolicy.getId());
            Set<Long> oldMplsPairIds = oldMplsDevicePolicy.getMPLSPairs().stream().map(MPLSPair::getId).collect(Collectors.toSet());
            Set<Long> newMplsPairIds = newMplsDevicePolicy.getMPLSPairs().stream().map(MPLSPair::getId).collect(Collectors.toSet());

            Set<MPLSPair> addMplsPairs = new HashSet<>();
            Set<MPLSPair> deleteMplsPairs = new HashSet<>();

            oldMplsDevicePolicy.getMPLSPairs().forEach(mplsPair -> {
                if (!newMplsPairIds.contains(mplsPair.getId())) {
                    deleteMplsPairs.add(mplsPair);
                } else {
                    MPLSPair newPair = newMplsDevicePolicy.getMPLSPairs().stream().filter(mplsPair1 -> mplsPair.getId().equals(mplsPair1.getId())).findFirst().orElse(null);
                    if (newPair != null) {
                        if (!compareMPLSPair(mplsPair, newPair)) {
                            deleteMplsPairs.add(mplsPair);
                            addMplsPairs.add(newPair);
                        }
                    }
                }
            });

            newMplsDevicePolicy.getMPLSPairs().forEach(mplsPair -> {
                if (!oldMplsPairIds.contains(mplsPair.getId())) {
                    addMplsPairs.add(mplsPair);
                }
            });

            deleteMplsPairs.forEach(mplsPair -> {
                command.append(String.format(REMOVE_MPLS_UNKNOWN_LABEL_FORWARD, mplsPair.getIngressPort().getPortNumber(), mplsPair.getEgressPort().getPortNumber()));
            });

            addMplsPairs.forEach(mplsPair -> {
                command.append(String.format(MPLS_UNKNOWN_LABEL_FORWARD, mplsPair.getIngressPort().getPortNumber(), mplsPair.getEgressPort().getPortNumber()));
            });
        }

        command.append(EXIT);
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    /**
     * This method compare if oldMplsPair and newMplsPair are same
     *
     * @param oldMplsPair
     * @param newMplsPair
     * @return boolean
     */
    private boolean compareMPLSPair(MPLSPair oldMplsPair, MPLSPair newMplsPair) {
        if(oldMplsPair.getIngressPort().getId().equals(newMplsPair.getIngressPort().getId()) && oldMplsPair.getEgressPort().getId().equals(newMplsPair.getEgressPort().getId())){
            return true;
        }
        return false;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_MPLS_POP_UPDATE);
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestMplsDevicePolicyId
     * @return MPLSDevicePolicy returns latest ACTIVE policy
     */
    private MPLSDevicePolicy getMplsDevicePolicyFromHistory(Long latestMplsDevicePolicyId) {
        List<MPLSDevicePolicyHistory> mplsDevicePolicyHistoryList = mplsDevicePolicyHistoryRepository.findByIdAndWorkflowStatus(latestMplsDevicePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        MPLSDevicePolicy mplsDevicePolicy = null;
        if (mplsDevicePolicyHistoryList.size() >= 1) {
            MPLSDevicePolicyHistory mplsDevicePolicyHistory = mplsDevicePolicyHistoryList.get(0);
            mplsDevicePolicy = mplsDevicePolicyHistory.buildParent();
        }
        return mplsDevicePolicy;
    }

}
