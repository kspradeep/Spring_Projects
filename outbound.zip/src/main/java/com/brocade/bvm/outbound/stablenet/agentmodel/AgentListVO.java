package com.brocade.bvm.outbound.stablenet.agentmodel;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "collection")
@Getter
@Setter
@ToString

public class AgentListVO {
    List<AgentVO> agent;
}
