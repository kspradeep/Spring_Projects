package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class CommitSdFilterPolicyJobExecutor extends AbstractSdPolicyJobExecutor {
    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_FILTER_POLICY_CREATE);
    }

    @Override
    public String getCommands(Job job) {
        FilterPolicy filterPolicy = (FilterPolicy) getParentObject(job);
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(FILTER);
        command.append(ADD).append(String.format(FILTER_POLICY, filterPolicy.getName()));
        if (filterPolicy.isPreserveCplane()) {
            command.append(SET).append(PRESERVE_CPLANE);
        }
        command.append(SET).append(String.format(TRAFFICTYPE, filterPolicy.getTrafficType()));
        if (!filterPolicy.getRules().isEmpty()) {
            filterPolicy.getRules().forEach(rule -> {
                command.append(buildCreateCommand(rule, filterPolicy.getDevice()));
            });
        }
        command.append(EXIT);
        command.append(EXIT);
        return command.toString();
    }
}
