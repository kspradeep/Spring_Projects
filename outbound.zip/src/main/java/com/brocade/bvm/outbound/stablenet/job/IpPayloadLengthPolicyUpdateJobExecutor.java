package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.IpPayloadLengthPolicyHistoryRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.history.IpPayloadLengthPolicyHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Named
@Slf4j
public class IpPayloadLengthPolicyUpdateJobExecutor extends AbstractIpPayloadLengthPolicyJobExecutor {
    @Inject
    private IpPayloadLengthPolicyHistoryRepository payloadLengthPolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;

    /**
     * This method constructs update IpPayloadLengthPolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        IpPayloadLengthPolicy newPayloadPolicy = (IpPayloadLengthPolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        if (newPayloadPolicy != null) {
            IpPayloadLengthPolicy oldPayloadPolicy = getIpPayloadLengthPolicyFromHistory(newPayloadPolicy.getId());

            List<Module> oldModules = (List<Module>) moduleRepository.findAll(oldPayloadPolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()));

            Set<Long> oldModuleIds = oldPayloadPolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
            Set<Long> newModuleIds = newPayloadPolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());

            //removing IpPayloadLengthPolicy from unselected modules during edit
            oldModules.forEach(oldModule -> {
                if (!newModuleIds.contains(oldModule.getId())
                        || !oldPayloadPolicy.getProcessor().name().equals(newPayloadPolicy.getProcessor())
                        || !oldPayloadPolicy.getIpType().name().equals(newPayloadPolicy.getIpType().name())
                        || !oldPayloadPolicy.getMinRange().equals(newPayloadPolicy.getMinRange()) || !oldPayloadPolicy.getMaxRange().equals(newPayloadPolicy.getMaxRange())) {
                    if (IPV4.equals(oldPayloadPolicy.getIpType().name()))
                        command.append(String.format(REVERT + IPV4_IP_PAYLOAD_LENGHT, oldModule.getModuleNumber(), getProcessorCommand(oldPayloadPolicy), ""));
                    else if (IPV6.equals(oldPayloadPolicy.getIpType().name()))
                        command.append(String.format(REVERT + IPV6_IP_PAYLOAD_LENGHT, oldModule.getModuleNumber(), getProcessorCommand(oldPayloadPolicy), ""));
                }
            });

            //adding IpPayloadLengthPolicy to newly selected modules during edit
            newPayloadPolicy.getModules().forEach(newModule -> {
                if (!oldModuleIds.contains(newModule.getId())
                        || !oldPayloadPolicy.getProcessor().name().equals(newPayloadPolicy.getProcessor())
                        || !oldPayloadPolicy.getIpType().name().equals(newPayloadPolicy.getIpType().name())
                        || !oldPayloadPolicy.getMinRange().equals(newPayloadPolicy.getMinRange()) || !oldPayloadPolicy.getMaxRange().equals(newPayloadPolicy.getMaxRange())) {
                    if (IPV4.equals(newPayloadPolicy.getIpType().name()))
                        command.append(String.format(IPV4_IP_PAYLOAD_LENGHT, newModule.getModuleNumber(), getProcessorCommand(newPayloadPolicy), getRangeCommand(newPayloadPolicy)));
                    else if (IPV6.equals(newPayloadPolicy.getIpType().name()))
                        command.append(String.format(IPV6_IP_PAYLOAD_LENGHT, newModule.getModuleNumber(), getProcessorCommand(newPayloadPolicy), getRangeCommand(newPayloadPolicy)));
                }
            });
        }
        command.append(WRITE_MEMORY);
        log.debug("IpPayloadLengthPolicyUpdate on Device-ID {} and command {}", newPayloadPolicy.getDevice().getId(), command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestModulePolicyId
     * @return IpPayloadLengthPolicy returns latest ACTIVE policy
     */
    private IpPayloadLengthPolicy getIpPayloadLengthPolicyFromHistory(Long latestModulePolicyId) {
        List<IpPayloadLengthPolicyHistory> payloadLengthPolicyHistories = payloadLengthPolicyHistoryRepository.findByIdAndWorkflowStatus(latestModulePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        IpPayloadLengthPolicy modulePolicy = null;
        if (payloadLengthPolicyHistories.size() >= 1) {
            IpPayloadLengthPolicyHistory packetLabelingModulePolicyHistory = payloadLengthPolicyHistories.get(0);
            modulePolicy = packetLabelingModulePolicyHistory.buildParent();
        }
        return modulePolicy;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.IP_PAYLOAD_LENGTH_POLICY_UPDATE);
    }
}
