package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.GTPDevicePolicy;

/**
 * The AbstractGtpDevicePolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE of GTPDevicePolicy on Non Open Flow device through Stablenet
 */
public abstract class AbstractGtpDevicePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CREATE_GTP_PROFILE_CONFIG = "gtp \"%s\" %s;";
    protected static final String DELETE_GTP_PROFILE_CONFIG = "no gtp \"%s\" %s;";

    protected static final String ENABLE_GTP_INGRESS_INNER_FILTER = "ingress-inner-filter;";
    protected static final String DISABLE_GTP_INGRESS_INNER_FILTER = "no ingress-inner-filter;";

    protected static final String ENABLE_LOAD_BALANCE_GTPC_TEID_HASH = "load-balance port-gtpc-teid-hash-ena;";
    protected static final String ENABLE_LOAD_BALANCE_GTPU_TEID_HASH = "load-balance port-gtpu-teid-hash-ena;";
    protected static final String ENABLE_LOAD_BALANCE_GTPU_INNERL3_HASH = "load-balance port-gtpu-innerl3-hash-ena;";

    protected static final String DISABLE_LOAD_BALANCE_GTPC_TEID_HASH = "no load-balance port-gtpc-teid-hash-ena;";
    protected static final String DISABLE_LOAD_BALANCE_GTPU_INNERL3_HASH = "no load-balance port-gtpu-innerl3-hash-ena;";
    protected static final String DISABLE_LOAD_BALANCE_GTPU_TEID_HASH = "no load-balance port-gtpu-teid-hash-ena;";

    /**
     * This method builds create commands to be applied on the device
     *
     * @param gtpDevicePolicy
     * @return String
     */
    protected String buildCreateCommand(GTPDevicePolicy gtpDevicePolicy) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(CREATE_GTP_PROFILE_CONFIG, gtpDevicePolicy.getName(), gtpDevicePolicy.getProfileId()));
        command.append(ENABLE_GTP_INGRESS_INNER_FILTER);
        if (gtpDevicePolicy.isGTPCTeIdEnabled()) {
            command.append(ENABLE_LOAD_BALANCE_GTPC_TEID_HASH);
        }
        if (gtpDevicePolicy.isGTPUTeIdEnabled()) {
            command.append(ENABLE_LOAD_BALANCE_GTPU_TEID_HASH);
        }
        if (gtpDevicePolicy.isGTPUInnerL3Enabled()) {
            command.append(ENABLE_LOAD_BALANCE_GTPU_INNERL3_HASH);
        }
        return command.toString();
    }

    /**
     * This method builds delete commands to be applied on the device
     *
     * @param gtpDevicePolicy
     * @return String
     */
    protected String buildDeleteCommand(GTPDevicePolicy gtpDevicePolicy) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(DELETE_GTP_PROFILE_CONFIG, gtpDevicePolicy.getName(), gtpDevicePolicy.getProfileId()));
        return command.toString();
    }

}
