package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.grid.GridMatrixHistoryRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.grid.DestinationGroup;
import com.brocade.bvm.model.db.grid.GridMatrix;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.GridToolGroupCommandBlock;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Named
@Slf4j
public class GridToolGroupRecoveryExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Inject
    private GridMatrixHistoryRepository gridMatrixHistoryRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Override
    public List<CommandBlock> getCommands(Job job) {
        GridMatrix gridMatrix = (GridMatrix) getParentObject(job);
        return constructCommandBlockList(gridMatrix, job.getDevice());
    }

    private List<CommandBlock> constructCommandBlockList(GridMatrix gridMatrix, Device device) {
        List<CommandBlock> finalCommandBlocks = new ArrayList<>();
        GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());

        if (gridMatrix != null && gridMatrix.getDestinationGroups() != null) {
            Map<Integer, Set<Integer>> groupToolGroupsMap = getToolGroupMap(gridMatrix.getDestinationGroups(), device.getId());
            groupToolGroupsMap.forEach((groupId, toolAddressSet) -> {
                GridToolGroupCommandBlock gridToolGroupCommandBlock = new GridToolGroupCommandBlock();
                gridToolGroupCommandBlock.setDeviceId(device.getStablenetId().intValue());
                gridToolGroupCommandBlock.setPbfDestinationGroupId(groupId);
                finalCommandBlocks.add(gridToolGroupCommandBlock);
            });
        }
        if (gridMatrixHistory != null && gridMatrixHistory.getDestinationGroups() != null) {
            Map<Integer, Set<Integer>> groupToolGroupsMapHistory = getToolGroupMap(gridMatrixHistory.getDestinationGroups(), device.getId());
            groupToolGroupsMapHistory.forEach((groupId, toolAddressSet) -> {
                GridToolGroupCommandBlock gridToolGroupCommandBlock = new GridToolGroupCommandBlock();
                gridToolGroupCommandBlock.setDeviceId(device.getStablenetId().intValue());
                gridToolGroupCommandBlock.setPbfDestinationGroupId(groupId);
                finalCommandBlocks.add(gridToolGroupCommandBlock);
            });
        }
        if (!finalCommandBlocks.isEmpty()) {
            finalCommandBlocks.get(finalCommandBlocks.size() - 1).setWriteMem("true");
        }
        log.debug("Number of command blocks constructed for GridToolGroupRecoveryExecutor id {} is :{}", gridMatrix.getId(), finalCommandBlocks.size());
        return finalCommandBlocks;
    }

    private Map<Integer, Set<Integer>> getToolGroupMap(Set<DestinationGroup> destinationGroups, Long deviceId) {
        Map<Integer, Set<Integer>> groupToolAddressesMap = Maps.newHashMap();
        destinationGroups.stream().forEach(destinationGroup -> {
            Integer groupId = destinationGroup.getGroupId();
            destinationGroup.getGridTopologyPathIds().forEach(gridTopologyPathId -> {
                GridTopologyPath gridTopologyPath = gridTopologyPathRepository.findOne(gridTopologyPathId);
                if (gridTopologyPath != null && gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                    Set<Integer> toolAddressSet = Sets.newHashSet();
                    if (groupToolAddressesMap.containsKey(groupId)) {
                        toolAddressSet = groupToolAddressesMap.get(groupId);
                    }
                    toolAddressSet.add(gridTopologyPath.getToolAddress());
                    groupToolAddressesMap.put(groupId, toolAddressSet);
                }
            });
        });
        return groupToolAddressesMap;
    }

    private GridMatrix getGridMatrixFromHistory(Long matrixId) {
        List<GridMatrixHistory> gridMatrixHistoryList = gridMatrixHistoryRepository.findByIdAndWorkflowStatus(matrixId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GridMatrix gridMatrix = null;
        if (gridMatrixHistoryList.size() >= 1) {
            GridMatrixHistory gridMatrixHistory = gridMatrixHistoryList.get(0);
            gridMatrix = gridMatrixHistory.buildParent();
        }
        return gridMatrix;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GRID_TOOL_GROUP_ROLLBACK);
    }
}

