package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterRule;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SdFilterPolicyRecoveryCommandList;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetRecoveryJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.common.IOUtils;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Named
public class RecoverSdFilterPolicyJobExecutor extends AbstractSdRecoveryJobExecutor {

    @Inject
    private SdFilterPolicyRecoveryCommandList filterPolicyRecoveryCommandList;

    private static final int SD_DEVICE_PORT = 22;
    private static final String SD_DEVICE_USER = "root";
    private static final String SD_DEVICE_PASSWORD = "password";

    @Value("${sd.server.file.path}")
    public String sdServerFilePath;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_FILTER_POLICY_RECOVER);
    }

    /**
     * This method constructs FilterPolicy recovery commands to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    public List<CommandBlock> getCommands(Job job) {
        FilterPolicy filterPolicy = (FilterPolicy) getParentObject(job);
        List<CommandBlock> commandBlocks = filterPolicyRecoveryCommandList.constructCommandBlockList(filterPolicy);
        List<String> files = new ArrayList<>();
        filterPolicy.getRules().forEach(rule -> {
            if (rule.getImsiFileName() != null) {
                files.add(rule.getImsiFileName());
            } else if (rule.getImeiFileName() != null) {
                files.add(rule.getImeiFileName());
            } else if (rule.getApnFileName() != null) {
                files.add(rule.getApnFileName());
            } else if (rule.getSipCallingPartyFileName() != null) {
                files.add(rule.getSipCallingPartyFileName());
            } else if (rule.getSipCalledPartyFileName() != null) {
                files.add(rule.getSipCalledPartyFileName());
            }
        });
        if (!files.isEmpty()) {
            deleteFilesFromSD(filterPolicy.getDevice(), files);
        }

        return commandBlocks;
    }

    /**
     * This method is used to delete uploaded file from SD box
     *
     * @param device
     * @param files
     */
    public void deleteFilesFromSD(Device device, List<String> files) {
        String deviceIp = device.getIpAddress();
        final SSHClient client = new SSHClient();
        client.addHostKeyVerifier(new PromiscuousVerifier());
        try {
            client.connect(deviceIp);
            client.authPassword(SD_DEVICE_USER, SD_DEVICE_PASSWORD);
            final Session session = client.startSession();
            try {
                String fileName = "";
                for (String file : files) {
                    fileName = fileName.concat(file).concat(" ");
                }
                final Session.Command cmd = session.exec("cd /opt/sd_upload_dir;rm -rf " + fileName.trim() + ";");
                log.debug("Command output: " + IOUtils.readFully(cmd.getInputStream()).toString());
                cmd.join(5, TimeUnit.SECONDS);
            } finally {
                if (session != null) {
                    session.close();
                }
            }
        } catch (Exception e) {
            log.error("Error while deleting file from SD while recovery ", e.getMessage());
        } finally {
            try {
                client.disconnect();
                client.close();
            } catch (IOException e) {
                log.error("Error while closing connection " + e.getLocalizedMessage());
            }
        }
    }
}
