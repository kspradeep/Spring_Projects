package com.brocade.bvm.outbound;

import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.exception.ServerException;
import sun.misc.BASE64Decoder;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public abstract class BaseOutboundJobExecutor implements OutboundJobExecutor {

    private static java.security.Key PRIVATE_KEY;

    static {
        try {
            /*
            128bits (16bytes) key is used and not 256.
            See https://github.com/spring-projects/spring-security/issues/2917 and https://en.wikipedia.org/wiki/Restrictions_on_the_import_of_cryptography
            to understand why it's not easy to ship with a 256 bit key.
            Spring Encryptors has a much easier interface for AES encryption, but provides only a 256 bit key encryption.
             */
            byte[] keyBytes = Arrays.copyOf("v3@F_Fww6}_As~BV".getBytes("UTF-8"), 16);
            PRIVATE_KEY = new SecretKeySpec(keyBytes, "AES");
        } catch (UnsupportedEncodingException e) {
            throw new ServerException(e);
        }
    }

    //TODO: Used Entity manager to overcome the 61+ join issue in Mysql
    @Inject
    protected EntityManager entityManager;

    @Inject
    private JobRepository jobRepository;

    public ManagedObject getParentObject(Job job) {
        if (job.getParentObjectId() != null) {
            Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
            List<Long> ids = new ArrayList<>();
            ids.add(job.getParentObjectId());
            query.setParameter("ids", ids);
            ManagedObject parentObject = (ManagedObject) query.getSingleResult();
            return parentObject;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public List<ManagedObject> getImpactedObjects(Job job) {
        if (job.getImpactedObjectsIds() != null && !job.getImpactedObjectsIds().isEmpty()) {
            List<Long> ids = new ArrayList<>();
            Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
            ids.addAll(job.getImpactedObjectIds());
            query.setParameter("ids", ids);
            return (List<ManagedObject>) query.getResultList();
        }
        return Collections.emptyList();
    }

    public String decryptPassword(String encryptedPassword) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, PRIVATE_KEY);
            byte[] decoded = new BASE64Decoder().decodeBuffer(encryptedPassword);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted, "UTF-8");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | IOException e) {
            throw new ServerException(e);
        }
    }
}
