package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class SLXRouteMapCommandBlock implements CommandBlock {

    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String routeMapPattern;

    @Getter
    @Setter
    private String routeMapName;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * </pre>
     */
    private static final String PRE_CMD = "configure terminal";

    /**
     * <pre>
     * argument #1 is interface type  #2 interface name/id
     * eg: do show running-config interface ethernet 1/1
     * eg: do show running-config interface port-channel 20
     * </pre>
     */
    private static final String SHOW_CMD = "do show running-config route-map %s";

    /**
     * <pre>
     * argument #1 is route-map name, #2 is route-map pattern
     * route-map name permit 100
     * </pre>
     */
    private static final String MATCH_CMD = "route-map %s %s";

    /**
     * <pre>
     * argument #1 is route-map name, #2 is route-map pattern
     * no route-map name permit 100
     * </pre>
     */
    private static final String ACTION_CMD = "no route-map %s %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);
        args.add(String.format(SHOW_CMD, routeMapName));
        args.add(String.format(MATCH_CMD, routeMapName, routeMapPattern));
        args.add(String.format(ACTION_CMD, routeMapName, routeMapPattern));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "SLXRouteMapCommandBlock [deviceId=" + deviceId + ", routeMapName=" + routeMapName + ", routeMapPattern=" + routeMapPattern + ", getTemplateJobInput()="
                + getTemplateJobInput() + "]";
    }
}
