package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.RuleSetRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.vlan.VlanTaggingStripping;
import com.brocade.bvm.outbound.stablenet.commands.RuleDiff;
import com.brocade.bvm.outbound.stablenet.commands.StablenetSLXPolicyComparator;
import com.brocade.bvm.outbound.stablenet.commands.StablenetSLXPolicyDiff;
import com.brocade.bvm.outbound.stablenet.commands.TvfDiff;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetCommitExistingSLXPolicyJobExecutor extends AbstractStablenetSLXPolicyJobExecutor {

    @Inject
    private StablenetSLXPolicyComparator stablenetSLXPolicyComparator;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_UPDATE);
    }

    /**
     * This method builds policy UPDATE commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Policy policyToSave = (Policy) getParentObject(job);
        Policy oldPolicy = getPolicyNameFromHistory(policyToSave);
        String command = buildUpdatePolicyCommand(oldPolicy, policyToSave);
        log.info("Stablenet SLX update command generated from Job Id {} on device {} for policy id {} is :: {}", job.getId(), job.getDevice().getId(), policyToSave.getId(), command);
        return command;
    }

    /**
     * This method is used to build the Policy update commands
     *
     * @param oldPolicy
     * @param newPolicy
     * @return
     */
    private String buildUpdatePolicyCommand(Policy oldPolicy, Policy newPolicy) {
        StringBuilder command = new StringBuilder();
        Map<String, String> routeMapNextHopMap = Maps.newHashMap();

        StablenetSLXPolicyDiff stablenetPolicyDiff = stablenetSLXPolicyComparator.comparePolicy(oldPolicy, newPolicy);
        command.append(CONFIGURE_TERMINAL);
        command.append(buildUnMapIngressCommand(stablenetPolicyDiff, newPolicy, oldPolicy));
        command.append(buildUnMapUdaCommand(stablenetPolicyDiff, newPolicy, oldPolicy));
        command.append(buildUpdateTvfCommand(stablenetPolicyDiff, routeMapNextHopMap));
        command.append(buildRuleUpdateCommand(stablenetPolicyDiff));
        command.append(buildUpdateFlowCommand(stablenetPolicyDiff, newPolicy, routeMapNextHopMap, oldPolicy));
        command.append(buildUnMapUdaProfileCommand(stablenetPolicyDiff, newPolicy, oldPolicy));
        command.append(buildMapUdaCommand(stablenetPolicyDiff, newPolicy, oldPolicy));
        command.append(buildMapIngressCommand(newPolicy, oldPolicy, stablenetPolicyDiff));
        command.append(buildMapEgressTSCommand(newPolicy, oldPolicy, stablenetPolicyDiff));
        command.append(buildUnMapEgressTSCommand(stablenetPolicyDiff, newPolicy, oldPolicy));
        command.append(updateTelemetryStatsProfile(stablenetPolicyDiff, newPolicy));
        command.append(EXIT);
        return command.toString();
    }

    /**
     * This method is used to build ingress UNMAP commands based on the policyDiff
     *
     * @param stablenetPolicyDiff
     * @param newPolicy
     * @param oldPolicy
     * @return
     */
    private String buildUnMapIngressCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(oldPolicy.getFlows().first());
        // Unmapping removed ingress ports
        stablenetPolicyDiff.getDeletedIngressPorts().forEach(port -> {
            command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
            if (oldPolicy.isIngressValid())
                command.append(NO_INGRESS_VALID_TIMESTAMP);
            if (oldPolicy.isGtpHttpFiltered())
                command.append(NO_DENY_GTP_HTTPS);
            command.append(isDeviceSLX9850WithUda ? String.format(DISABLE_FLEX_PBR, oldPolicy.getComputedName()) : NO_NPB_POLICY_ROUTE_MAP);

            if (!oldPolicy.getFlexMatchProfiles().isEmpty()) {
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));

                oldPolicy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(NO_WITH_COMMAND, String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName()))));
            }
            command.append(EXIT);
        });

        stablenetPolicyDiff.getDeletedIngressPortChannels().forEach(portGroup -> {
            command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
            if (oldPolicy.isIngressValid())
                command.append(NO_INGRESS_VALID_TIMESTAMP);
            if (oldPolicy.isGtpHttpFiltered())
                command.append(NO_DENY_GTP_HTTPS);
            command.append(isDeviceSLX9850WithUda ? String.format(DISABLE_FLEX_PBR, oldPolicy.getComputedName()) : NO_NPB_POLICY_ROUTE_MAP);

            if (!oldPolicy.getFlexMatchProfiles().isEmpty()) {
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(EXIT);
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));

                oldPolicy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(NO_WITH_COMMAND, String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName()))));
            }
            command.append(EXIT);
        });
        if (!newPolicy.isIngressValid() && oldPolicy.isIngressValid()) {
            stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                if (!newPolicy.isIngressValid() && oldPolicy.isIngressValid()) {
                    command.append(NO_INGRESS_VALID_TIMESTAMP);
                }
                command.append(EXIT);
            });


            stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                if (!newPolicy.isIngressValid() && oldPolicy.isIngressValid()) {
                    command.append(NO_INGRESS_VALID_TIMESTAMP);
                }
                command.append(EXIT);
            });
        }
        if (newPolicy.isGtpHttpFiltered() != oldPolicy.isGtpHttpFiltered()) {
            stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                if (!newPolicy.isGtpHttpFiltered() && oldPolicy.isGtpHttpFiltered()) {
                    command.append(NO_DENY_GTP_HTTPS);
                } else {
                    command.append(DENY_GTP_HTTPS);
                }
                command.append(EXIT);
            });
            stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                if (!newPolicy.isGtpHttpFiltered() && oldPolicy.isGtpHttpFiltered()) {
                    command.append(NO_DENY_GTP_HTTPS);
                } else {
                    command.append(DENY_GTP_HTTPS);
                }
                command.append(EXIT);
            });
        }
        return command.toString();
    }


    /**
     * This method is used to build UDA UNMAP commands based on the policyDiff
     *
     * @param stablenetPolicyDiff
     * @param newPolicy
     * @param oldPolicy
     * @return
     */
    private String buildUnMapUdaCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        if (oldPolicy.getFlexMatchProfiles() != null && newPolicy.getFlexMatchProfiles() != null) {
            boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(newPolicy.getFlows().first());
            if ((oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() == 0)) {
                if (isDeviceSLX9850WithUda) {
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getComputedName(), true));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getComputedName(), true));
                }
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), oldPolicy.getFlexMatchProfiles(), true));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), oldPolicy.getFlexMatchProfiles(), true));
            } else if (oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() > 0 &&
                    oldPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != newPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                if (isDeviceSLX9850WithUda) {
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getComputedName(), true));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getDeletedIngressPorts(), newPolicy.getComputedName(), true));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getComputedName(), true));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getDeletedIngressPortChannels(), newPolicy.getComputedName(), true));
                }
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), oldPolicy.getFlexMatchProfiles(), true));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getDeletedIngressPorts(), oldPolicy.getFlexMatchProfiles(), true));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), oldPolicy.getFlexMatchProfiles(), true));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getDeletedIngressPortChannels(), oldPolicy.getFlexMatchProfiles(), true));
            }
        }
        return command.toString();
    }


    /**
     * This method is used to build UDA profile UNMAP commands based on the policyDiff
     *
     * @param stablenetPolicyDiff
     * @param newPolicy
     * @param oldPolicy
     * @return
     */
    private String buildUnMapUdaProfileCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        if (oldPolicy.getFlexMatchProfiles() != null && newPolicy.getFlexMatchProfiles() != null) {
            if ((oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() == 0) || (oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() > 0 &&
                    oldPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != newPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue())) {
                command.append(buildRevertUdaProfileOffset(oldPolicy));
            }
        }
        return command.toString();
    }

    /**
     * This method is used to build UDA MAP commands based on the policyDiff
     *
     * @param stablenetPolicyDiff
     * @param newPolicy
     * @param oldPolicy
     * @return
     */
    private String buildMapUdaCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        if (oldPolicy.getFlexMatchProfiles() != null && newPolicy.getFlexMatchProfiles() != null) {
            boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(newPolicy.getFlows().first());
            if ((oldPolicy.getFlexMatchProfiles().size() == 0 && newPolicy.getFlexMatchProfiles().size() > 0)) {
                command.append(buildUdaProfileOffset(newPolicy));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getFlexMatchProfiles(), false));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getFlexMatchProfiles(), false));
                if (isDeviceSLX9850WithUda) {
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getComputedName(), false));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getComputedName(), false));
                }
            } else if (oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() > 0 &&
                    oldPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != newPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                command.append(buildUdaProfileOffset(newPolicy));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getFlexMatchProfiles(), false));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getAddedIngressPorts(), newPolicy.getFlexMatchProfiles(), false));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getFlexMatchProfiles(), false));
                command.append(generateUdaProfileCommand(stablenetPolicyDiff.getAddedIngressPortChannels(), newPolicy.getFlexMatchProfiles(), false));
                if (isDeviceSLX9850WithUda) {
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPorts(), newPolicy.getComputedName(), false));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getAddedIngressPorts(), newPolicy.getComputedName(), false));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getUnchangedIngressPortChannels(), newPolicy.getComputedName(), false));
                    command.append(generateUdaPolicyCommand(stablenetPolicyDiff.getAddedIngressPortChannels(), newPolicy.getComputedName(), false));
                }
            }
        }
        return command.toString();
    }

    /**
     * Helper method to generate command to add/remove uda policy pbr to/from port(s)/port-channel(s)
     *
     * @param managedObjects
     * @param isNoCommand
     * @return
     */
    private String generateUdaPolicyCommand(Set<? extends ManagedObject> managedObjects, String computeName, boolean isNoCommand) {
        StringBuilder command = new StringBuilder();
        managedObjects.forEach(managedObject -> {
            if (managedObject instanceof Port) {
                command.append(String.format(INTERFACE_ETHERNET, ((Port) managedObject).getPortNumber()));
            } else if (managedObject instanceof PortGroup) {
                command.append(String.format(INTERFACE_PORT_CHANNEL, managedObject.getName()));
            }
            if (managedObject instanceof Port || managedObject instanceof PortGroup) {
                if (isNoCommand) {
                    command.append(NO_UDA_POLICY_ROUTE_MAP);
                } else {
                    command.append(String.format(ENABLE_FLEX_PBR, computeName));
                }
                command.append(EXIT);
            }
        });
        return command.toString();
    }

    /**
     * Helper method to generate command to add/remove flex match profile to/from port(s)/port-channel(s)
     *
     * @param managedObjects
     * @param flexMatchProfiles
     * @param isNoCommand
     * @return
     */
    private String generateUdaProfileCommand(Set<? extends ManagedObject> managedObjects, Set<FlexMatchProfile> flexMatchProfiles, boolean isNoCommand) {
        StringBuilder command = new StringBuilder();
        managedObjects.forEach(managedObject -> {
            if (managedObject instanceof Port) {
                command.append(String.format(INTERFACE_ETHERNET, ((Port) managedObject).getPortNumber()));
            } else if (managedObject instanceof PortGroup) {
                command.append(String.format(INTERFACE_PORT_CHANNEL, managedObject.getName()));
            }
            if (managedObject instanceof Port || managedObject instanceof PortGroup) {
                if (isNoCommand) {
                    flexMatchProfiles.forEach(flexMatchProfile -> command.append(String.format(NO_WITH_COMMAND, String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName()))));
                } else {
                    flexMatchProfiles.forEach(flexMatchProfile -> command.append(String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName())));
                }
                command.append(EXIT);
            }
        });
        return command.toString();
    }

    private String removePortFromTvfDomain(Set<String> tvfDomains) {
        StringBuilder command = new StringBuilder();
        for (String tvfDomainId : tvfDomains) {
            command.append(String.format(REMOVE_INTERFACE_FROM_TVF_DOMAIN, tvfDomainId));
        }
        return command.toString();
    }

    private String addPortToTvfDomain(Set<String> tvfDomains) {
        StringBuilder command = new StringBuilder();
        for (String tvfDomainId : tvfDomains) {
            command.append(String.format(ADD_INTERFACE_TO_TVF_DOMAIN, tvfDomainId));
        }
        return command.toString();
    }

    private String buildUpdateTvfCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Map<String, String> routeMapNextHopMap) {
        StringBuilder command = new StringBuilder();
        TvfDiff tvfDiff = stablenetPolicyDiff.getTvfDiff();

        Map<String, Set<String>> oldTvfMap = tvfDiff.getOldTvfMap();
        Map<String, Set<String>> newTvfMap = tvfDiff.getNewTvfMap();

        Map<String, Set<String>> oldTvfEgressPortChannelMap = tvfDiff.getOldTvfPortChannelMap();
        Map<String, Set<String>> newTvfEgressPortChannelMap = tvfDiff.getNewTvfPortChannelMap();

        // Un bind deleted destination ports from TVF domain
        tvfDiff.getDeletedTvfs().forEach(deletedTvf -> {
            Set<String> unMapEgressMap = oldTvfMap.get(deletedTvf);
            if (unMapEgressMap != null) {
                command.append(buildTvfDomainCommand(unMapEgressMap, INTERFACE_ETHERNET, deletedTvf, false));
            }
            command.append(buildTvfDomainCommand(oldTvfEgressPortChannelMap.get(deletedTvf), INTERFACE_PORT_CHANNEL, deletedTvf, false));

            if (!newTvfMap.containsKey(deletedTvf)) {
                command.append(String.format(REMOVE_TVF_DOMAIN, deletedTvf));
                routeMapNextHopMap.put(stablenetPolicyDiff.getRouteMapName(), String.format(NO_SET_NEXT_HOP_TVF_DOMAIN, deletedTvf));
            }
        });

        // Un bind deleted destination ports from TVF domain, and bind added destination ports to TVF domain
        tvfDiff.getUpdatedTvfs().forEach(unchangedVlan -> {
            Set<String> unMapEgressMap = oldTvfMap.get(unchangedVlan);
            Set<String> mapEgressMap = newTvfMap.get(unchangedVlan);

            Set<String> unMapEgressPortChannelMap = oldTvfEgressPortChannelMap.get(unchangedVlan);
            Set<String> mapEgressPortChannelMap = newTvfEgressPortChannelMap.get(unchangedVlan);

            List<String> unChangedEgressPorts = unMapEgressMap.stream().filter(mapEgressMap::contains).collect(Collectors.toList());
            List<String> unChangedEgressPortChannel = unMapEgressPortChannelMap.stream().filter(mapEgressPortChannelMap::contains).collect(Collectors.toList());

            unChangedEgressPorts.forEach(s -> {
                unMapEgressMap.remove(s);
                mapEgressMap.remove(s);
            });

            unChangedEgressPortChannel.forEach(s -> {
                unMapEgressPortChannelMap.remove(s);
                mapEgressPortChannelMap.remove(s);
            });

            command.append(buildTvfDomainCommand(unMapEgressMap, INTERFACE_ETHERNET, unchangedVlan, false));
            command.append(buildTvfDomainCommand(mapEgressMap, INTERFACE_ETHERNET, unchangedVlan, true));
            command.append(buildTvfDomainCommand(unMapEgressPortChannelMap, INTERFACE_PORT_CHANNEL, unchangedVlan, false));
            command.append(buildTvfDomainCommand(mapEgressPortChannelMap, INTERFACE_PORT_CHANNEL, unchangedVlan, true));
        });
        // Bind added destination ports to TVF domain
        tvfDiff.getAddedTvfs().forEach(addedTvf -> {
            Set<String> mapEgressMap = newTvfMap.get(addedTvf);
            command.append(String.format(CREATE_TVF_DOMAIN, addedTvf));
            command.append(EXIT);
            if (mapEgressMap != null) {
                command.append(buildTvfDomainCommand(mapEgressMap, INTERFACE_ETHERNET, addedTvf, true));
            }
            command.append(buildTvfDomainCommand(newTvfEgressPortChannelMap.get(addedTvf), INTERFACE_PORT_CHANNEL, addedTvf, true));

            routeMapNextHopMap.put(stablenetPolicyDiff.getRouteMapName(), String.format(SET_NEXT_HOP_TVF_DOMAIN, addedTvf, ""));
//            routeMapNextHopMap.put(stablenetPolicyDiff.getRouteMapName(), String.format(SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE, addedTvf, ""));
        });
        return command.toString();
    }

    private String buildTvfDomainCommand(Set<String> inputMap, String interfaceType, String vlanString, boolean isAdd) {
        StringBuilder command = new StringBuilder();
        if (inputMap != null) {
            for (String interfaceName : inputMap) {
                command.append(String.format(interfaceType, interfaceName));
                if (isAdd) {
                    command.append(addPortToTvfDomain(Sets.newHashSet(vlanString)));
                } else {
                    command.append(removePortFromTvfDomain(Sets.newHashSet(vlanString)));
                }
                command.append(EXIT);
            }
        }
        return command.toString();
    }

    private String buildUpdateFlowCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy policy, Map<String, String> routeMapNextHopMap, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        StringBuilder finalCommand = new StringBuilder();
        StringBuilder removeRouteMapCommand = new StringBuilder();
        StringBuilder removeRuleSetCommands = new StringBuilder();
        List<String> uniqueListOfRulesetNameTobeDeleted = new ArrayList<>();
        List<String> uniqueListOfRulesetNameToRevertRule = new ArrayList<>();
        Long deviceId = policy.getDevice().getId();
        stablenetPolicyDiff.getFlowMap().forEach((sequence, ruleSetDiff) -> {
            //set the truncation profile if it is there
            String truncationProfile = null;
            if (ruleSetDiff.getPacketTruncationMapping() != null && ruleSetDiff.getPacketTruncationMapping().getPacketTruncation() != null && ruleSetDiff.getPacketTruncationMapping().getPacketTruncation().getName() != null) {
                truncationProfile = ruleSetDiff.getPacketTruncationMapping().getPacketTruncation().getName();
            }
            // deleting route-map if sequence is changed
            if (stablenetPolicyDiff.getDeletedSeqs().contains(sequence)) {
                if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    removeRouteMapCommand.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                    removeRouteMapCommand.append(setNoNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence));

                    // reverting the deleted ruleSets
                    ruleSetDiff.getDeletedRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getType() == RuleSet.Type.UDA) {
                            if (isDeviceSLX9850WithUda(ruleSet.getFlow())) {
                                removeRouteMapCommand.append(String.format(NO_WITH_COMMAND, String.format(MATCH_UDA_ACL, ruleSet.getName())));
                            } else {
                                removeRouteMapCommand.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, UDA, ruleSet.getName())));
                            }
                        } else if (ruleSet.getType() == RuleSet.Type.L2) {
                            removeRouteMapCommand.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, MAC, ruleSet.getName())));
                        } else {
                            removeRouteMapCommand.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, ruleSet.getIpVersion().getValue(), ruleSet.getName())));
                        }
                        removeRouteMapCommand.append(EXIT);
                        // removing acls for deleted rulesets
                        removeRouteMapCommand.append(buildRevertRuleSetRuleCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameToRevertRule));

                        removeRouteMapCommand.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRouteMapCommand.append(EXIT);
                        removeRouteMapCommand.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRouteMapCommand.append(EXIT);
                        removeRouteMapCommand.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRouteMapCommand.append(EXIT);

                        removeRouteMapCommand.append(buildRevertAclCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameTobeDeleted));
                    });
                    removeRouteMapCommand.append(String.format(NO_ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                }
                StringBuilder builder = new StringBuilder();
                StringBuilder createRuleSetCommands = new StringBuilder();
                if (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty()) {
                    // Adding ruleSet to policy
                    ruleSetDiff.getAddedRuleSets().forEach(ruleSet -> {
                        boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(ruleSet.getFlow());
                        // creating acls for newly added rulesets
                        if (isRuleSetChangesRequired(ruleSet, deviceId, policy.getId())) {
                            createRuleSetCommands.append(buildRuleSetCommand(ruleSet, isSLX9850WithUDA));
                        } else {
                            createRuleSetCommands.append(buildRuleSetCommandForExistingRulesetInDifferentPolicy(ruleSet, deviceId, policy.getId()));

                        }
                        if (ruleSet.getType() == RuleSet.Type.UDA) {
                            if (isSLX9850WithUDA) {
                                builder.append(String.format(MATCH_UDA_ACL, ruleSet.getName()));
                            } else {
                                builder.append(String.format(MATCH_ACL, UDA, ruleSet.getName()));
                            }
                        } else if (ruleSet.getType() == RuleSet.Type.L2) {
                            builder.append(String.format(MATCH_ACL, MAC, ruleSet.getName()));
                        } else {
                            builder.append(String.format(MATCH_ACL, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                        }
                    });
                }

                command.append(createRuleSetCommands.toString());

                if (builder.toString().trim().length() > 0 || isNextHopToBeUpdated(stablenetPolicyDiff, sequence)) {
                    String nextHopcommand = setNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence, truncationProfile);
                    if (builder.toString().trim().length() > 0 || nextHopcommand.length() > 0) {
                        command.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        command.append(builder.toString());
                        command.append(nextHopcommand);
                        command.append(EXIT);
                    }
                }
            } else if ((ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty())
                    || (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty())
                    || (ruleSetDiff.getUpdatedRuleSets() != null && !ruleSetDiff.getUpdatedRuleSets().isEmpty() && !stablenetPolicyDiff.isRulesUpdatedForPolicy())) {

                StringBuilder builder = new StringBuilder();
                List<String> uniqueListOfRulesetNameToBeDeleted = new ArrayList<>();
                List<String> uniqueListOfRulesetNameToRemoveRules = new ArrayList<>();
                if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    // reverting the deleted ruleSets
                    ruleSetDiff.getDeletedRuleSets().forEach(ruleSet -> {
                        // removing acls for deleted rulesets
                        removeRuleSetCommands.append(buildRevertRuleSetRuleCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameToRemoveRules));
                        removeRuleSetCommands.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        if (ruleSet.getType() == RuleSet.Type.UDA) {
                            if (isDeviceSLX9850WithUda(ruleSet.getFlow())) {
                                removeRuleSetCommands.append(String.format(NO_WITH_COMMAND, String.format(MATCH_UDA_ACL, ruleSet.getName())));
                            } else {
                                removeRuleSetCommands.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, UDA, ruleSet.getName())));
                            }
                        } else if (ruleSet.getType() == RuleSet.Type.L2) {
                            removeRuleSetCommands.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, MAC, ruleSet.getName())));
                        } else {
                            removeRuleSetCommands.append(String.format(NO_WITH_COMMAND, String.format(MATCH_ACL, ruleSet.getIpVersion().getValue(), ruleSet.getName())));
                        }
                        removeRuleSetCommands.append(EXIT);

                        removeRuleSetCommands.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRuleSetCommands.append(EXIT);
                        removeRuleSetCommands.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRuleSetCommands.append(EXIT);
                        removeRuleSetCommands.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        removeRuleSetCommands.append(EXIT);

                        removeRuleSetCommands.append(buildRevertAclCommand(ruleSet, deviceId, policy.getId(), uniqueListOfRulesetNameToBeDeleted));
                    });
                }

                StringBuilder createRuleSetCommands = new StringBuilder();
                // tvf/vlan to tvfIds/vlanIds map
                if (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty()) {
                    // Adding ruleSet to policy
                    ruleSetDiff.getAddedRuleSets().forEach(ruleSet -> {
                        boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(ruleSet.getFlow());
                        // creating acls for newly added rulesets
                        if(isRuleSetChangesRequired(ruleSet, deviceId, policy.getId())){
                            createRuleSetCommands.append(buildRuleSetCommand(ruleSet, isSLX9850WithUDA));
                        } else {
                            createRuleSetCommands.append(buildRuleSetCommandForExistingRulesetInDifferentPolicy(ruleSet, deviceId, policy.getId()));
                        }
                        if (ruleSet.getType() == RuleSet.Type.UDA) {
                            if (isSLX9850WithUDA) {
                                builder.append(String.format(MATCH_UDA_ACL, ruleSet.getName()));
                            } else {
                                builder.append(String.format(MATCH_ACL, UDA, ruleSet.getName()));
                            }
                        } else if (ruleSet.getType() == RuleSet.Type.L2) {
                            builder.append(String.format(MATCH_ACL, MAC, ruleSet.getName()));
                        } else {
                            builder.append(String.format(MATCH_ACL, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                        }
                    });
                }

                StringBuilder updateRuleSetCommands = new StringBuilder();
                if (ruleSetDiff.getUpdatedRuleSets() != null && !ruleSetDiff.getUpdatedRuleSets().isEmpty() && !stablenetPolicyDiff.isRulesUpdatedForPolicy()) {
                    /*If same sequence no is deleted in one flow and used in other flow*/
                    if (ruleSetDiff.isSeqChanged()) {
                        // Adding ruleSet to policy
                        ruleSetDiff.getUpdatedRuleSets().forEach(ruleSet -> {
                            boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(ruleSet.getFlow());
                            updateRuleSetCommands.append(buildRuleSetCommand(ruleSet, isSLX9850WithUDA));
                            if (ruleSet.getType() == RuleSet.Type.UDA) {
                                if (isSLX9850WithUDA) {
                                    builder.append(String.format(MATCH_UDA_ACL, ruleSet.getName()));
                                } else {
                                    builder.append(String.format(MATCH_ACL, UDA, ruleSet.getName()));
                                }
                            } else if (ruleSet.getType() == RuleSet.Type.L2) {
                                builder.append(String.format(MATCH_ACL, MAC, ruleSet.getName()));
                            } else {
                                builder.append(String.format(MATCH_ACL, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                            }
                        });
                    }
                }

                command.append(createRuleSetCommands.toString());
                command.append(updateRuleSetCommands.toString());

                if (builder.toString().trim().length() > 0 || isNextHopToBeUpdated(stablenetPolicyDiff, sequence)) {
                    String noNextHopcommand = setNoNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence);
                    String nextHopcommand = setNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence, truncationProfile);

                    if (builder.toString().trim().length() > 0 || noNextHopcommand.length() > 0 || nextHopcommand.length() > 0) {
                        command.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                        command.append(builder.toString());
                        command.append(noNextHopcommand);
                        command.append(nextHopcommand);
                        command.append(EXIT);
                    }
                }
            } else if (isNextHopToBeUpdated(stablenetPolicyDiff, sequence)) {
                String noNextHopcommand = setNoNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence);
                String nextHopcommand = setNextHop(stablenetPolicyDiff, routeMapNextHopMap, sequence, truncationProfile);
                if (!noNextHopcommand.isEmpty() || !nextHopcommand.isEmpty()) {
                    command.append(String.format(ROUTE_MAP, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                    command.append(noNextHopcommand);
                    command.append(nextHopcommand);
                    command.append(EXIT);
                }
            }
            if (stablenetPolicyDiff.getUpdatedFlowDefaultRouteMapDrop() != null && !stablenetPolicyDiff.getUpdatedFlowDefaultRouteMapDrop().isEmpty()) {
                boolean isDeviceSLX9850WithUda = stablenetPolicyDiff.getRuleSetTypeMap().get(RuleSet.Type.UDA) != null && policy.getDevice().getModel().contains(FlexMatchProfile.SLX_9850);
                if (isDeviceSLX9850WithUda && !stablenetPolicyDiff.getDeletedSeqs().contains(sequence)) {
                    stablenetPolicyDiff.getUpdatedFlowDefaultRouteMapDrop().entrySet().forEach(entry -> {
                        command.append(String.format(ROUTE_MAP, entry.getValue().getPolicy().getComputedName(), CMD_PERMIT, sequence));
                        if (entry.getValue().getIsDefaultRouteMapDrop()) {
                            command.append(SET_UDA_INTERFACE_NULL);
                        } else {
                            command.append(NO_SET_UDA_INTERFACE_NULL);
                        }
                        command.append(EXIT);
                    });
                }
            }
        });

        StringBuilder addPolicy = new StringBuilder();
        StringBuilder deletePolicy = new StringBuilder();
        boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(policy.getFlows().first());
        if (removeRouteMapCommand.length() > 0 || removeRuleSetCommands.length() > 0) {
            if (!isDeviceSLX9850WithUda) {
                stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                    deletePolicy.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    deletePolicy.append(NO_NPB_POLICY_ROUTE_MAP);
                    deletePolicy.append(EXIT);
                });
                stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                    deletePolicy.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                    deletePolicy.append(NO_NPB_POLICY_ROUTE_MAP);
                    deletePolicy.append(EXIT);
                });
            } else {
                stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                    deletePolicy.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    deletePolicy.append(String.format(DISABLE_FLEX_PBR, oldPolicy.getComputedName()));//Not removing the UDA profile
                    deletePolicy.append(EXIT);
                });
                stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                    deletePolicy.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                    deletePolicy.append(String.format(DISABLE_FLEX_PBR, oldPolicy.getComputedName()));//Not removing the UDA profile
                    deletePolicy.append(EXIT);
                });
            }
            deletePolicy.append(removeRuleSetCommands);
            deletePolicy.append(removeRouteMapCommand);

            if (!isDeviceSLX9850WithUda) {
                stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                    addPolicy.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    addPolicy.append(String.format(CREATE_POLICY, policy.getComputedName()));
                    addPolicy.append(EXIT);
                });
                stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                    addPolicy.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                    addPolicy.append(String.format(CREATE_POLICY, policy.getComputedName()));
                    addPolicy.append(EXIT);
                });
            } else {
                stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                    addPolicy.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    addPolicy.append(String.format(ENABLE_FLEX_PBR, policy.getComputedName()));//Not adding the UDA profile as it already exists
                    addPolicy.append(EXIT);
                });
                stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                    addPolicy.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                    addPolicy.append(String.format(ENABLE_FLEX_PBR, policy.getComputedName()));//Not removing the UDA profile as it already exists
                    addPolicy.append(EXIT);
                });
            }
        }

        finalCommand.append(deletePolicy);
        finalCommand.append(command);
        finalCommand.append(addPolicy);
        return finalCommand.toString();
    }

    private boolean isNextHopToBeUpdated(StablenetSLXPolicyDiff stablenetPolicyDiff, int sequence) {
        Set<String> oldEgressPortGroups = stablenetPolicyDiff.getOldEgressPortGroupsMap().get(sequence);
        Set<String> newEgressPortGroups = stablenetPolicyDiff.getNewEgressPortGroupsMap().get(sequence);
        Set<String> oldEgressPorts = stablenetPolicyDiff.getOldEgressPortsMap().get(sequence);
        Set<String> newEgressPorts = stablenetPolicyDiff.getNewEgressPortsMap().get(sequence);

        if (compareOldAndNewPortAndPortGroup(oldEgressPorts, newEgressPorts)) return true;
        if (compareOldAndNewPortAndPortGroup(oldEgressPortGroups, newEgressPortGroups)) return true;

        Set<FlowEgressManagedObject> oldFlowEgressPortGroups = stablenetPolicyDiff.getOldFlowEgressPortGroupsMap().get(sequence);
        Set<FlowEgressManagedObject> newFlowEgressPortGroups = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence);
        Set<FlowEgressManagedObject> oldFlowEgressPorts = stablenetPolicyDiff.getOldFlowEgressPortsMap().get(sequence);
        Set<FlowEgressManagedObject> newFlowEgressPorts = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence);

        if (compareOldAndNewFlowPortAndPortGroup(oldFlowEgressPorts, newFlowEgressPorts)) return true;
        if (compareOldAndNewFlowPortAndPortGroup(oldFlowEgressPortGroups, newFlowEgressPortGroups)) return true;

        //Next Hop to be updated even when there is change in VLAN stripping or Tagging
        VlanTaggingStripping vlanTaggingStripping = stablenetPolicyDiff.getAddedUpdatedFlowVlanTaggingStripping().get(sequence);
        if (vlanTaggingStripping != null && (vlanTaggingStripping.isValnStrippingUpdated() || vlanTaggingStripping.isVlanTaggedUpdated()))
            return true;

        return false;
    }

    private boolean compareOldAndNewFlowPortAndPortGroup(Set<FlowEgressManagedObject> oldEgressPortGroups, Set<FlowEgressManagedObject> newEgressPortGroups) {
        if (oldEgressPortGroups != null && newEgressPortGroups != null) {
            if (oldEgressPortGroups.size() != newEgressPortGroups.size()) {
                return true;
            } else {
                Set<FlowEgressManagedObject> unavailableInOld = returnDiffBetweenFlowSets(oldEgressPortGroups, newEgressPortGroups);
                Set<FlowEgressManagedObject> unavailableInNew = returnDiffBetweenFlowSets(newEgressPortGroups, oldEgressPortGroups);

                if (unavailableInOld != null && unavailableInOld.size() > 0 || unavailableInNew != null && unavailableInNew.size() > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    private Set<FlowEgressManagedObject> returnDiffBetweenFlowSets(Set<FlowEgressManagedObject> srcSets, Set<FlowEgressManagedObject> destSets) {
        Set<FlowEgressManagedObject> diffSet = srcSets.stream()
                .filter(e -> (destSets.stream()
                        .filter(d -> d.getTvfDomainId() != null && !d.getTvfDomainId().equals(e.getTvfDomainId())).count()) > 0)
                .collect(Collectors.toSet());

        return diffSet;
    }

    private boolean compareOldAndNewPortAndPortGroup(Set<String> oldEgressPortGroups, Set<String> newEgressPortGroups) {
        if (oldEgressPortGroups != null && newEgressPortGroups != null) {
            if (oldEgressPortGroups.size() != newEgressPortGroups.size()) {
                return true;
            } else {
                Set<String> unavailableInOld = returnDiffBetweenSets(oldEgressPortGroups, newEgressPortGroups);
                Set<String> unavailableInNew = returnDiffBetweenSets(newEgressPortGroups, oldEgressPortGroups);

                if (unavailableInOld != null && unavailableInOld.size() > 0 || unavailableInNew != null && unavailableInNew.size() > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    private Set<String> returnDiffBetweenSets(Set<String> srcSets, Set<String> destSets) {
        Set<String> diffSet = srcSets.stream()
                .filter(e -> (destSets.stream()
                        .filter(d -> d.equals(e)).count()) < 1)
                .collect(Collectors.toSet());
        return diffSet;
    }

    private String setNoNextHop(StablenetSLXPolicyDiff stablenetPolicyDiff, Map<String, String> routeMapNextHopMap, int sequence) {
        StringBuilder command = new StringBuilder();
        if (stablenetPolicyDiff.isGridPolicy()) {
            VlanTaggingStripping vlanTaggingStripping = stablenetPolicyDiff.getAddedUpdatedFlowVlanTaggingStripping().get(sequence);
            String vlanString = vlanTaggingStripping != null && vlanTaggingStripping.isVlanStripping() ? STRIP_VLAN_OUTER : (vlanTaggingStripping != null && vlanTaggingStripping.getTaggedVlanId() != null ? String.format(ADD_VLAN_OUTER, vlanTaggingStripping.getTaggedVlanId()) : "");
            if (stablenetPolicyDiff.getOldDestinationGroupMap() != null && !stablenetPolicyDiff.getOldDestinationGroupMap().isEmpty()) {
                stablenetPolicyDiff.getOldDestinationGroupMap().forEach((flowSequence, groupId) -> {
                    if (flowSequence == sequence && groupId != null) {
                        command.append(String.format(NO_NEXT_HOP, PBF_DESTINATION_GROUP, groupId));
                    }
                });
            } else if (vlanString != null && stablenetPolicyDiff.getExitingDestinationGroupMap() != null) {
                if ((vlanTaggingStripping.isVlanStripping() == false && ((vlanTaggingStripping.getTaggedVlanId() != null && vlanTaggingStripping.getTaggedVlanIdDeleted() == null) ||
                        (vlanTaggingStripping.getTaggedVlanId() == null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null) ||
                        (vlanTaggingStripping.getTaggedVlanId() != null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null && vlanTaggingStripping.getTaggedVlanId().intValue() != vlanTaggingStripping.getTaggedVlanIdDeleted().intValue()))) ||
                        (vlanTaggingStripping.isVlanStripping() == true && vlanTaggingStripping.getTaggedVlanId() == null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null) ||
                        (vlanTaggingStripping.getIsVlanStrippingOld() != null && vlanTaggingStripping.getIsVlanStrippingOld() != vlanTaggingStripping.isVlanStripping())) {
                    stablenetPolicyDiff.getExitingDestinationGroupMap().forEach((flowSequence, groupId) -> {
                        if (flowSequence == sequence && groupId != null) {
                            command.append(String.format(NO_NEXT_HOP, PBF_DESTINATION_GROUP, groupId));
                        }
                    });
                }
            }
        } else if (stablenetPolicyDiff.getOldSequenceTvfDomainIdMap() != null && stablenetPolicyDiff.getOldSequenceTvfDomainIdMap().size() > 0 && stablenetPolicyDiff.getOldSequenceTvfDomainIdMap().containsKey(sequence)) {
            stablenetPolicyDiff.getOldSequenceTvfDomainIdMap().forEach((flowSequence, tvfDomainIdSet) -> {
                if (flowSequence == sequence) {
                    if (tvfDomainIdSet != null) {
                        tvfDomainIdSet.forEach(id -> command.append(String.format(NO_SET_NEXT_HOP_TVF_DOMAIN, id)));
                    } else {
                        if (stablenetPolicyDiff.getOldEgressPortGroupsMap() != null) {
                            stablenetPolicyDiff.getOldEgressPortGroupsMap().forEach((flowSeq, portGroups) -> {
                                if (flowSeq == sequence) {
                                    portGroups.stream().forEach(portGroup -> command.append(String.format(NO_NEXT_HOP, PORT_CHANNEL, portGroup)));
                                }
                            });
                        }
                        if (stablenetPolicyDiff.getOldEgressPortsMap() != null) {
                            stablenetPolicyDiff.getOldEgressPortsMap().forEach((flowSeq, ports) -> {
                                if (flowSeq == sequence) {
                                    ports.stream().forEach(port -> command.append(String.format(NO_NEXT_HOP, ETHERNET, port)));
                                }
                            });
                        }
                    }
                }
            });
        } else if (routeMapNextHopMap.size() > 0) {
            Set<String> tvfDomainIdSet = stablenetPolicyDiff.getExistingSequenceTvfDomainIdMap().get(sequence);
            if (tvfDomainIdSet != null) {
                tvfDomainIdSet.forEach(id -> command.append(String.format(NO_SET_NEXT_HOP_TVF_DOMAIN, id)));
            } else {
                Set<String> oldEgressPortGroups = stablenetPolicyDiff.getOldEgressPortGroupsMap().get(sequence);
                Set<String> newEgressPortGroups = stablenetPolicyDiff.getNewEgressPortGroupsMap().get(sequence);
                Set<String> oldEgressPorts = stablenetPolicyDiff.getOldEgressPortsMap().get(sequence);
                Set<String> newEgressPorts = stablenetPolicyDiff.getNewEgressPortsMap().get(sequence);

                if (oldEgressPortGroups != null && newEgressPortGroups != null && (oldEgressPortGroups.size() != newEgressPortGroups.size() || routeMapNextHopMap.size() > 0)) {
                    oldEgressPortGroups.stream().forEach(portGroup -> command.append(String.format(NO_NEXT_HOP, PORT_CHANNEL, portGroup)));
                }
                if (oldEgressPorts != null && newEgressPorts != null && (oldEgressPorts.size() != newEgressPorts.size() || routeMapNextHopMap.size() > 0)) {
                    oldEgressPorts.stream().forEach(port -> command.append(String.format(NO_NEXT_HOP, ETHERNET, port)));
                }
            }
        }
        return command.toString();
    }

    private String setNextHop(StablenetSLXPolicyDiff stablenetPolicyDiff, Map<String, String> routeMapNextHopMap, int sequence, String truncationProfile) {
        StringBuilder command = new StringBuilder();
        VlanTaggingStripping vlanTaggingStripping = stablenetPolicyDiff.getAddedUpdatedFlowVlanTaggingStripping().get(sequence);
        String vlanString = vlanTaggingStripping != null && vlanTaggingStripping.isVlanStripping() ? STRIP_VLAN_OUTER : (vlanTaggingStripping != null && vlanTaggingStripping.getTaggedVlanId() != null ? String.format(ADD_VLAN_OUTER, vlanTaggingStripping.getTaggedVlanId()) : "");
        if (stablenetPolicyDiff.isGridPolicy()) {
            if (stablenetPolicyDiff.getNewDestinationGroupMap() != null && !stablenetPolicyDiff.getNewDestinationGroupMap().isEmpty()) {
                stablenetPolicyDiff.getNewDestinationGroupMap().forEach((flowSequence, groupId) -> {
                    if (flowSequence == sequence && groupId != null) {
                        command.append(String.format(NEXT_HOP, PBF_DESTINATION_GROUP, groupId, vlanString));
                    }
                });
            } else if (vlanString != null && stablenetPolicyDiff.getExitingDestinationGroupMap() != null) {
                if ((vlanTaggingStripping.isVlanStripping() == false && ((vlanTaggingStripping.getTaggedVlanId() != null && vlanTaggingStripping.getTaggedVlanIdDeleted() == null) ||
                        (vlanTaggingStripping.getTaggedVlanId() == null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null) ||
                        (vlanTaggingStripping.getTaggedVlanId() != null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null && vlanTaggingStripping.getTaggedVlanId().intValue() != vlanTaggingStripping.getTaggedVlanIdDeleted().intValue()))) ||
                        (vlanTaggingStripping.isVlanStripping() == true && vlanTaggingStripping.getTaggedVlanId() == null && vlanTaggingStripping.getTaggedVlanIdDeleted() != null) ||
                        (vlanTaggingStripping.getIsVlanStrippingOld() != null && vlanTaggingStripping.getIsVlanStrippingOld() != vlanTaggingStripping.isVlanStripping())) {
                    stablenetPolicyDiff.getExitingDestinationGroupMap().forEach((flowSequence, groupId) -> {
                        if (flowSequence == sequence && groupId != null) {
                            command.append(String.format(NEXT_HOP, PBF_DESTINATION_GROUP, groupId, vlanString));
                        }
                    });
                }
            }
        } else if (stablenetPolicyDiff.getNewSequenceTvfDomainIdMap() != null && stablenetPolicyDiff.getNewSequenceTvfDomainIdMap().size() > 0 && stablenetPolicyDiff.getNewSequenceTvfDomainIdMap().containsKey(sequence)) {
            stablenetPolicyDiff.getNewSequenceTvfDomainIdMap().forEach((flowSequence, tvfDomainIdSet) -> {
                if (flowSequence == sequence) {
                    if (tvfDomainIdSet != null) {
                        tvfDomainIdSet.forEach(id -> {
                            Optional<FlowEgressManagedObject> flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                            if (flowEgressManagedObjectOption == null || !flowEgressManagedObjectOption.isPresent()) {
                                flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                            }
                            FlowEgressManagedObject flowEgressManagedObject;
                            if (flowEgressManagedObjectOption != null && flowEgressManagedObjectOption.isPresent() && (flowEgressManagedObject = flowEgressManagedObjectOption.get()).getPrecedence() > 0) {
                                command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), id, vlanString));
                            } else {
                                if (truncationProfile != null) {
                                    command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_TRUNCATION_PROFILE, id, vlanString, TRUNCATION_PROFILE, truncationProfile));
                                } else {
                                    command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN, id, vlanString));
                                }
                            }
                        });
                    } else {
                        if (stablenetPolicyDiff.getNewFlowEgressPortGroupsMap() != null) {
                            stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().forEach((flowSeq, flowEgressManagedObjects) -> {
                                if (flowSeq == sequence) {
                                    flowEgressManagedObjects.stream().forEach(flowEgressManagedObject -> {
                                                if (flowEgressManagedObject.getPrecedence() > 0) {
                                                    command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                                                } else {
                                                    if (truncationProfile != null) {
                                                        command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                                                    } else {
                                                        command.append(String.format(NEXT_HOP, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                                                    }
                                                }
                                            }
                                    );
                                }
                            });
                        }
                        if (stablenetPolicyDiff.getNewFlowEgressPortsMap() != null) {
                            stablenetPolicyDiff.getNewFlowEgressPortsMap().forEach((flowSeq, flowEgressManagedObjects) -> {
                                if (flowSeq == sequence) {
                                    flowEgressManagedObjects.stream().forEach(flowEgressManagedObject -> {
                                        if (flowEgressManagedObject.getPrecedence() > 0) {
                                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                                        } else {
                                            if (truncationProfile != null) {
                                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                                            } else {
                                                command.append(String.format(NEXT_HOP, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                }
            });
        } else if (routeMapNextHopMap.size() > 0) {
            Set<String> tvfDomainIdSet = stablenetPolicyDiff.getExistingSequenceTvfDomainIdMap().get(sequence);
            if (tvfDomainIdSet != null) {
                tvfDomainIdSet.forEach(id -> {
                    Optional<FlowEgressManagedObject> flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                    if (flowEgressManagedObjectOption == null || !flowEgressManagedObjectOption.isPresent()) {
                        flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                    }
                    FlowEgressManagedObject flowEgressManagedObject;
                    if (flowEgressManagedObjectOption != null && flowEgressManagedObjectOption.isPresent() && (flowEgressManagedObject = flowEgressManagedObjectOption.get()).getPrecedence() > 0) {
                        command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), id, vlanString));
                    } else {
                        if (truncationProfile != null) {
                            command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_TRUNCATION_PROFILE, id, vlanString, TRUNCATION_PROFILE, truncationProfile));
                        } else {
                            command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN, id, vlanString));
                        }
                    }
                });
            } else {
                Set<FlowEgressManagedObject> oldEgressPortGroups = stablenetPolicyDiff.getOldFlowEgressPortGroupsMap().get(sequence);
                Set<FlowEgressManagedObject> newEgressPortGroups = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence);
                Set<FlowEgressManagedObject> oldEgressPorts = stablenetPolicyDiff.getOldFlowEgressPortsMap().get(sequence);
                Set<FlowEgressManagedObject> newEgressPorts = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence);

                if (oldEgressPortGroups != null && newEgressPortGroups != null && (oldEgressPortGroups.size() != newEgressPortGroups.size() || routeMapNextHopMap.size() > 0)) {
                    newEgressPortGroups.stream().forEach(flowEgressManagedObject -> {
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                        } else {
                            if (truncationProfile != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                            } else {
                                command.append(String.format(NEXT_HOP, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                            }
                        }
                    });
                }
                if (oldEgressPorts != null && newEgressPorts != null && (oldEgressPorts.size() != newEgressPorts.size() || routeMapNextHopMap.size() > 0)) {
                    newEgressPorts.stream().forEach(flowEgressManagedObject -> {
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                        } else {
                            if (truncationProfile != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                            } else {
                                command.append(String.format(NEXT_HOP, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                            }
                        }
                    });
                }
            }
        } else if (vlanTaggingStripping.isVlanTaggedUpdated() || vlanTaggingStripping.isValnStrippingUpdated()) {
            Set<String> tvfDomainIdSet = stablenetPolicyDiff.getExistingSequenceTvfDomainIdMap().get(sequence);
            if (tvfDomainIdSet != null) {
                tvfDomainIdSet.forEach(id -> {
                    command.append(String.format(NO_SET_NEXT_HOP_TVF_DOMAIN, id));
                    Optional<FlowEgressManagedObject> flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                    if (flowEgressManagedObjectOption == null || !flowEgressManagedObjectOption.isPresent()) {
                        flowEgressManagedObjectOption = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence).stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getTvfDomainId() != null && flowEgressManagedObject.getTvfDomainId().equals(id)).findAny();
                    }
                    FlowEgressManagedObject flowEgressManagedObject;
                    if (flowEgressManagedObjectOption != null && flowEgressManagedObjectOption.isPresent() && (flowEgressManagedObject = flowEgressManagedObjectOption.get()).getPrecedence() > 0) {
                        command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), id, vlanString));
                    } else {
                        if (truncationProfile != null) {
                            command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN_TRUNCATION_PROFILE, id, vlanString, TRUNCATION_PROFILE, truncationProfile));
                        } else {
                            command.append(String.format(SET_NEXT_HOP_TVF_DOMAIN, id, vlanString));
                        }
                    }
                });
            } else {
                Set<FlowEgressManagedObject> oldEgressPortGroups = stablenetPolicyDiff.getOldFlowEgressPortGroupsMap().get(sequence);
                Set<FlowEgressManagedObject> newEgressPortGroups = stablenetPolicyDiff.getNewFlowEgressPortGroupsMap().get(sequence);
                Set<FlowEgressManagedObject> oldEgressPorts = stablenetPolicyDiff.getOldFlowEgressPortsMap().get(sequence);
                Set<FlowEgressManagedObject> newEgressPorts = stablenetPolicyDiff.getNewFlowEgressPortsMap().get(sequence);
                if (oldEgressPortGroups != null && newEgressPortGroups == null && (oldEgressPortGroups.size() != newEgressPortGroups.size())) {
                    oldEgressPortGroups.stream().forEach(flowEgressManagedObject -> {
                        command.append(String.format(NO_NEXT_HOP, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName()));
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                        } else {
                            if (truncationProfile != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                            } else {
                                command.append(String.format(NEXT_HOP, PORT_CHANNEL, flowEgressManagedObject.getManagedObject().getName(), vlanString));
                            }
                        }
                    });
                }
                if (oldEgressPorts != null && newEgressPorts == null && (oldEgressPorts.size() != newEgressPorts.size())) {
                    oldEgressPorts.stream().forEach(flowEgressManagedObject -> {
                        command.append(String.format(NO_NEXT_HOP, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber()));
                        if (flowEgressManagedObject.getPrecedence() > 0) {
                            command.append(String.format(NEXT_HOP_WITH_PRECEDENCE, flowEgressManagedObject.getPrecedence(), ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                        } else {
                            if (truncationProfile != null) {
                                command.append(String.format(NEXT_HOP_TRUNCATION_PROFILE, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString, TRUNCATION_PROFILE, truncationProfile));
                            } else {
                                command.append(String.format(NEXT_HOP, ETHERNET, ((Port) flowEgressManagedObject.getManagedObject()).getPortNumber(), vlanString));
                            }
                        }
                    });
                }
            }
        }
        return command.toString();
    }


    /**
     * Provide way to build rule set
     *
     * @param ruleSet
     * @return
     */
    protected String buildRevertRuleSetRuleCommand(RuleSet ruleSet, Long deviceId, Long policyId, List<String> uniqueListOfRulesetNameToRevertRule) {
        StringBuilder command = new StringBuilder();
        boolean isRulesetFoundInCurrentPolicy = isSameRulesetNameFoundInCurrentPolicy(ruleSet.getName(), policyId, ruleSet.getId());
        boolean isRuleSetDeletable = isRuleSetChangesRequired(ruleSet, deviceId, policyId) && !isRulesetFoundInCurrentPolicy && !uniqueListOfRulesetNameToRevertRule.contains(ruleSet.getName());
        if (isRuleSetDeletable) {
            if (ruleSet.getType() == RuleSet.Type.UDA) {
                command.append(String.format(UDA_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.L2) {
                command.append(String.format(MAC_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                command.append(String.format(IP_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                command.append(String.format(IPV6_ACCESS_LIST, ruleSet.getName()));
            }

            // Appending rules
            ruleSet.getRules().forEach(rule -> {
                // Building l2 commands
                if (ruleSet.getType() == RuleSet.Type.UDA) {
                    command.append(String.format(NO_WITH_COMMAND, buildRevertUDARuleCommand(rule)));
                } else if (ruleSet.getType() == RuleSet.Type.L2) {
                    command.append(String.format(NO_WITH_COMMAND, buildMACRuleCommand(rule, true)));
                } else {
                    command.append(String.format(NO_WITH_COMMAND, buildRuleCommand(rule, ruleSet.getIpVersion(), true)));
                }
            });
            command.append(EXIT);
        }
        return command.toString();
    }

    protected String buildRevertAclCommand(RuleSet ruleSet, Long deviceId, Long policyId, List<String> uniqueListOfRulesetNameTobeDeleted) {
        StringBuilder command = new StringBuilder();
        boolean isRulesetFoundInOtherPolicy = !isRuleSetChangesRequired(ruleSet, deviceId, policyId);
        boolean isRulesetFoundInCurrentPolicy = isSameRulesetNameFoundInCurrentPolicy(ruleSet.getName(), policyId, ruleSet.getId());
        boolean isRulesetAlreadyAdded = uniqueListOfRulesetNameTobeDeleted.contains(ruleSet.getName());
        //reverting rule set
        if (!isRulesetFoundInOtherPolicy && !isRulesetFoundInCurrentPolicy && !isRulesetAlreadyAdded) {
            if (ruleSet.getType() == RuleSet.Type.UDA) {
                command.append(String.format(NO_UDA_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                command.append(String.format(NO_IP_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                command.append(String.format(NO_IPV6_ACCESS_LIST, ruleSet.getName()));
            } else if (ruleSet.getType() == RuleSet.Type.L2) {
                command.append(String.format(NO_MAC_ACCESS_LIST, ruleSet.getName()));
            }
        }
        return command.toString();
    }

    private String buildRuleUpdateCommand(StablenetSLXPolicyDiff stablenetPolicyDiff) {
        StringBuilder command = new StringBuilder();
        List<String> uniqueListOfRulesetNameToUpdateRules = new ArrayList<>();
        if ((stablenetPolicyDiff.isRulesUpdatedForPolicy() || stablenetPolicyDiff.isRulesDeletedForPolicy() || stablenetPolicyDiff.isRulesAddedForPolicy()) && stablenetPolicyDiff.getDeletedSeqs().isEmpty()) {
            stablenetPolicyDiff.getRuleSetTypeMap().forEach((type, ruleDiffs) -> {
                ruleDiffs.forEach(ruleDiff -> {
                    if (ruleDiff != null) {
                        String rulesetName = ruleDiff.getRuleSet().getName();
                        StringBuilder builder = new StringBuilder();
                        if (type == RuleSet.Type.UDA) {
                            // creating first line for command for UDA
                            builder.append(String.format(UDA_ACCESS_LIST, ruleDiff.getRuleSet().getName()));
                        } else if (type == RuleSet.Type.L2) {
                            // creating first line for command for MAC
                            builder.append(String.format(MAC_ACCESS_LIST, ruleDiff.getRuleSet().getName()));
                        }
                        String ruleCmd = buildRuleCommand(type, ruleDiff, null);
                        // entering into acl, only if rule is updated
                        if (ruleCmd.length() > 0) {
                            command.append(builder.toString());
                            command.append(ruleCmd);
                            command.append(EXIT);
                        }
                        uniqueListOfRulesetNameToUpdateRules.add(rulesetName);
                    }
                });
            });

            stablenetPolicyDiff.getRuleSetIpVersionMap().forEach((ipVersion, ruleDiffs) -> {
                ruleDiffs.forEach(ruleDiff -> {
                    if (ruleDiff != null) {
                        String rulesetName = ruleDiff.getRuleSet().getName();
                        StringBuilder builder = new StringBuilder();
                        if (ipVersion == RuleSet.IpVersion.V4) {
                            // creating first line for command IP
                            builder.append(String.format(IP_ACCESS_LIST, ruleDiff.getRuleSet().getName()));
                        } else if (ipVersion == RuleSet.IpVersion.V6) {
                            // creating first line for command for IPV6
                            builder.append(String.format(IPV6_ACCESS_LIST, ruleDiff.getRuleSet().getName()));
                        }
                        String ruleCmd = buildRuleCommand(null, ruleDiff, ipVersion);
                        if (ruleCmd.trim().length() > 0) {
                            command.append(builder.toString());
                            command.append(ruleCmd);
                            command.append(EXIT);
                        }
                        uniqueListOfRulesetNameToUpdateRules.add(rulesetName);
                    }
                });
            });
        }
        return command.toString();
    }


    /**
     * This method is used to build ingress MAP commands based on the policyDiff
     *
     * @param newPolicy
     * @param stablenetPolicyDiff
     * @return
     */
    private String buildMapIngressCommand(Policy newPolicy, Policy oldPolicy, StablenetSLXPolicyDiff stablenetPolicyDiff) {
        StringBuilder command = new StringBuilder();
        boolean isDeviceSLX9850WithUda = isDeviceSLX9850WithUda(oldPolicy.getFlows().first());
        // Mapping added/unchanged rulesets to newly added ingress ports
        stablenetPolicyDiff.getAddedIngressPorts().forEach(port -> {
            command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
            newPolicy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName())));
            if (newPolicy.isTimestamp() && newPolicy.isIngressValid())
                command.append(INGRESS_VALID_TIMESTAMP);
            if (isDeviceSLX9850WithUda) {
                command.append(String.format(ENABLE_FLEX_PBR, newPolicy.getComputedName()));
            } else {
                command.append(NO_NPB_POLICY);
                command.append(String.format(CREATE_POLICY, newPolicy.getComputedName()));
            }
            command.append(EXIT);
        });

        stablenetPolicyDiff.getAddedIngressPortChannels().forEach(portGroup -> {
            command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
            newPolicy.getFlexMatchProfiles().forEach(flexMatchProfile -> command.append(String.format(UDA_PROFILE_APPLY, flexMatchProfile.getName())));
            if (newPolicy.isTimestamp() && newPolicy.isIngressValid())
                command.append(INGRESS_VALID_TIMESTAMP);
            if (isDeviceSLX9850WithUda) {
                command.append(String.format(ENABLE_FLEX_PBR, newPolicy.getComputedName()));
            } else {
                command.append(String.format(CREATE_POLICY, newPolicy.getComputedName()));
            }
            command.append(EXIT);
        });
        if (newPolicy.isTimestamp() && newPolicy.isIngressValid() && !oldPolicy.isIngressValid()) {
            stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(INGRESS_VALID_TIMESTAMP);
                command.append(EXIT);
            });

            stablenetPolicyDiff.getUnchangedIngressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(INGRESS_VALID_TIMESTAMP);
                command.append(EXIT);
            });
        }
        return command.toString();
    }

    /**
     * This method is used to build egress timestamp commands based on the policyDiff
     *
     * @param newPolicy
     * @param stablenetPolicyDiff
     * @return
     */
    private String buildMapEgressTSCommand(Policy newPolicy, Policy oldPolicy, StablenetSLXPolicyDiff stablenetPolicyDiff) {
        StringBuilder command = new StringBuilder();
        if (newPolicy.isTimestamp()) {
            stablenetPolicyDiff.getAddedEgressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(String.format(EGRESS_TIMESTAMP, newPolicy.getEgressAction()));
                command.append(EXIT);
            });

            stablenetPolicyDiff.getAddedEgressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(String.format(EGRESS_TIMESTAMP, newPolicy.getEgressAction()));
                command.append(EXIT);
            });
        }
        if (newPolicy.isTimestamp() && !oldPolicy.getEgressAction().equals(newPolicy.getEgressAction())) {
            stablenetPolicyDiff.getUnchangedEgressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(String.format(EGRESS_TIMESTAMP, newPolicy.getEgressAction()));
                command.append(EXIT);
            });
            stablenetPolicyDiff.getUnchangedEgressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(String.format(EGRESS_TIMESTAMP, newPolicy.getEgressAction()));
                command.append(EXIT);
            });
        }
        return command.toString();
    }

    /**
     * This method is used to build egress UNMAP commands based on the policyDiff
     *
     * @param stablenetPolicyDiff
     * @param newPolicy
     * @param oldPolicy
     * @return
     */
    private String buildUnMapEgressTSCommand(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();

        // Unmapping removed egress ports
        if (oldPolicy.isTimestamp()) {
            stablenetPolicyDiff.getDeletedEgressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });

            stablenetPolicyDiff.getDeletedEgressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });
        }
        if (!newPolicy.isTimestamp() && oldPolicy.isTimestamp()) {
            stablenetPolicyDiff.getUnchangedEgressPorts().forEach(port -> {
                command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });

            stablenetPolicyDiff.getUnchangedEgressPortChannels().forEach(portGroup -> {
                command.append(String.format(INTERFACE_PORT_CHANNEL, portGroup.getName()));
                command.append(NO_EGRESS_TIMESTAMP);
                command.append(EXIT);
            });
        }
        return command.toString();
    }

    /**
     * This method is used to build Rules update command
     *
     * @param type
     * @param ruleDiff
     * @return
     */
    private String buildRuleCommand(RuleSet.Type type, RuleDiff ruleDiff, RuleSet.IpVersion ipVersion) {
        StringBuilder command = new StringBuilder();
        if (ruleDiff.getDeletedRules() != null) {
            ruleDiff.getDeletedRules().forEach(rule -> {
                String ruleCommand = "";
                if (type == RuleSet.Type.UDA) {
                    ruleCommand = buildRevertUDARuleCommand(rule);
                } else if (type == RuleSet.Type.L2) {
                    ruleCommand = buildMACRuleCommand(rule, true);
                } else {
                    ruleCommand = buildRuleCommand(rule, ipVersion, true);
                }
                command.append(String.format(NO_WITH_COMMAND, ruleCommand));
            });
        }

        if (ruleDiff.getAddedRules() != null) {
            ruleDiff.getAddedRules().forEach(rule -> {
                String ruleCommand = "";
                if (type == RuleSet.Type.UDA) {
                    boolean isSLX9850WithUDA = isDeviceSLX9850WithUda(ruleDiff.getRuleSet().getFlow());
                    ruleCommand = buildUDARuleCommand(rule, isSLX9850WithUDA);
                } else if (type == RuleSet.Type.L2) {
                    ruleCommand = buildMACRuleCommand(rule, false);
                } else {
                    ruleCommand = buildRuleCommand(rule, ipVersion, false);
                }
                command.append(ruleCommand);
            });
        }
        return command.toString();
    }

    private String updateTelemetryStatsProfile(StablenetSLXPolicyDiff stablenetPolicyDiff, Policy policy) {
        StringBuilder command = new StringBuilder();
        Device device = policy.getDevice();
        boolean isTelemetryConfigured = false;
        if (device.isProfileConfigured()) {
            isTelemetryConfigured = true;
        } else if (!Strings.isNullOrEmpty(device.getOs()) && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (isSLXSupportsTelemetry(device.getOs()) >= 0) {
                isTelemetryConfigured = true;
            }
        }
        if (isTelemetryConfigured) {
            String addedPorts = stablenetPolicyDiff.getAddedIngressPorts().stream().map(port -> port.getPortNumber().trim()).collect(Collectors.joining(","));
            String addedPortChannels = stablenetPolicyDiff.getAddedIngressPortChannels().stream().map(PortGroup::getName).collect(Collectors.joining(","));

            String deletedPorts = stablenetPolicyDiff.getDeletedIngressPorts().stream().map(port -> port.getPortNumber().trim()).collect(Collectors.joining(","));
            String deletedPortChannels = stablenetPolicyDiff.getDeletedIngressPortChannels().stream().map(PortGroup::getName).collect(Collectors.joining(","));

            if (!addedPorts.isEmpty() || !addedPortChannels.isEmpty() || !deletedPorts.isEmpty() || !deletedPortChannels.isEmpty()) {
                command.append(applyInterfaceAndPbrStats(addedPorts, addedPortChannels, deletedPorts, deletedPortChannels));
            }
        }
        return command.toString();
    }
}
