package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.GtpDeEncapsulationModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class GtpDeEncapsulationModulePolicyDeleteJobExecutor extends AbstractGtpDeEncapsulationModulePolicyJobExecutor {
    /**
     * This method constructs delete GtpDeEncapsulationModulePolicyDelete commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        GtpDeEncapsulationModulePolicy modulePolicy = (GtpDeEncapsulationModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getPorts().stream().forEach(port -> {
            command.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
            command.append(NO_GTP_DE_ENCAPSULATION);
        });
        command.append(EXIT);
        command.append(WRITE_MEMORY);
        log.debug("GtpDeEncapsulationModulePolicyDelete on Device-ID {} Command {}", modulePolicy.getDevice().getId(), command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_DELETE);
    }
}
