package com.brocade.bvm.outbound.bsc.job;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.Rule;
import com.brocade.bvm.model.db.RuleSet;
import com.brocade.bvm.model.db.TargetHost.Mode;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.bsc.BscConnection;
import com.brocade.bvm.outbound.bsc.model.FlowRule;
import com.brocade.bvm.outbound.bsc.model.FlowVerificationDetails;
import com.brocade.bvm.outbound.bsc.util.BscIdGenerator;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * The AbstractBscPolicyJobExecutor class implements the methods to CREATE/UPDATE/DELETE/RECOVER policy through BSC
 * Below are various scenarios where the 404 exception is considered as valid:
 * After attaching the device to the BSC , only the operational data store entry is created , but nothing is created for config data store for the device.
 * In general, from BVM before we execute any REST API in BSC  we query for Operational and Config data stores inorder to
 *   a. identify the groups already created on the device.
 *   b. identify all the open flow ports present in the device and create a map between BVM port database id and openflow port id.
 * So we ought to get the 404 exception on config data store. The current code suppress this , and continues.
 * But a 404 on a operational data store is not an expected scenario , this indicates that the device got detached. We should stop the execution and put the entity for re-try.
 * Currently we dont support a new state , so the entity (PortGroup/Policy) is put into Error State and we support only recovery operation on it which on invocation clears the PortGroup/Policy on device and re-submits freshly.
 */
@Slf4j
@Named
public abstract class AbstractBscPolicyJobExecutor extends BaseOutboundJobExecutor {

	@Value("${bsc.resource-url.operational}")
	protected String operationUrl;

	@Value("${bsc.resource-url.config}")
	protected String configUrl;

	@Value("${bsc.resource-url.nodes}")
	protected String resourceNodesUrl;

	@Value("${bsc.resource-url.node}")
	protected String resourceNodeUrl;

	@Value("${bsc.resource-url.table}")
	protected String tableURL;

	@Value("${bsc.resource-url.flow}")
	protected String flowURL;

	@Value("${bsc.resource-url.group}")
	protected String groupURL;

	@Value("${bsc.queue-id:#{null}}")
	protected String queueId;

    @Value("${validation.retry-count:20}")
	protected int retryCount;

    @Value("${validation.wait.seconds:5}")
	protected long retrySleepSeconds;

	@Value("${bsc.policy.verification}")
	protected Boolean isVerificationNeeded;

	private String resourceUrl;

	@Inject
	protected BscConnection bscConnection;

	@Inject
	protected PolicyHistoryRepository policyHistoryRepository;

    protected FlowVerificationDetails flowVerificationDetails;

	@Inject
	protected DeviceRepository deviceRepository;

	@Inject
	protected BscIdGenerator bscIdGenerator;

	@Override
	public Mode getSupportedMode() {
		//TODO: move it to bean post processor
		resourceUrl = resourceNodesUrl + resourceNodeUrl;
		return Mode.OPENFLOW;
	}

	@Override
	public List<Device.Type> getSupportedDeviceTypes() {
		return Lists.newArrayList(Device.Type.MLXE, Device.Type.ICX, Device.Type.SLX);
	}

	public Map<String, String> getLagGroupNameIdMap(String deviceId, String lagkey) {
		Map<String, String> lagMap = new HashMap<>();
		try{
			Response res = bscConnection.get(configUrl, resourceUrl, deviceId);
			log.info("response : {}", res);
			String xmlString = res.readEntity(String.class);
			JSONObject xmlJSONObj;
			try {
				xmlJSONObj = XML.toJSONObject(xmlString);
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);
				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
				if (realNode.has("group")) {
					Object groupObj = realNode.get("group");
					if (groupObj instanceof JSONObject) {
						JSONObject groupNode = (JSONObject) groupObj;
						if (groupNode.has("group-name") && groupNode.has("group-id") && groupNode.has("group-type")) {
							String groupType = groupNode.get("group-type").toString();

							if (groupType.contains(lagkey)) {
								lagMap.put(groupNode.get("group-name").toString(),
										groupNode.get("group-id").toString());
							}
						}

					} else if (groupObj instanceof JSONArray) {
						JSONArray groupNodes = (JSONArray) groupObj;
						int size = groupNodes.length();
						for (int i = 0; i < size; i++) {
							JSONObject groupNode = groupNodes.getJSONObject(i);
							if (groupNode.has("group-name") && groupNode.has("group-id")
									&& groupNode.has("group-type")) {
								String groupType = groupNode.get("group-type").toString();

								if (groupType.contains(lagkey)) {
									lagMap.put(groupNode.get("group-name").toString(),
											groupNode.get("group-id").toString());
								}
							}
						}
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
				return null;
			}
		}catch (OutboundConnectionException e) {
			if(e.getMessage().contains("404")){
				//TODO: Expected scenario as we are loading the groups from Config datastore.
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
				//do nothing
				//TODO: Need to handle in a better way
			}else{
				throw e;
			}
		}

		return lagMap;
	}

	/**
	 * This method returns all the Rules in single List from given RuleSets
	 *
	 * @param ruleSetList
	 * @return
	 */
	protected List<Rule> getFlatRules(Set<RuleSet> ruleSetList) {
		List<Rule> rules = new ArrayList<>();
		for (RuleSet ruleSet : ruleSetList) {
			Set<Rule> ruleList = ruleSet.getRules();
			for (Rule rule : ruleList) {
				// L2 case - any, ip4, ip6,others
				// L3/L4 case - ip4 ip6
				// L23 case - ipv4,ipv6

				// NO NEED OF THIS TRANSFORMATION
				/*if ("any".equals(rule.getEthType()) || rule.getEthType() == null) {
					if (ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
						rule.setEthType("ipv4");
					} else if (ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
						rule.setEthType("ipv6");
					} else {
						//L2 case
						rule.setEthType("ipv4");
					}
				}*/
				rules.add(rule);
			}
		}
		return rules;
	}

	/**
	 * This method is used to construct BSC Flow name
	 *
	 * @param policyName
	 * @param ingressPort
	 * @param ruleId
	 * @return
	 */
	protected String constructBscFlowName(String policyName,String ingressPort,Long ruleId) {
		StringBuilder flowName = new StringBuilder(policyName);
		flowName.append("_").append(ingressPort).append("_").append(ruleId);
		return flowName.toString();
	}

	/**
	 * This method builds and returns Group name
	 *
	 * @param policyId
	 * @param appender
	 * @return
	 */
	protected String getGroupName(Long policyId, String appender, int flowPriority) {
		StringBuilder groupName = new StringBuilder("policy_");
        groupName.append(policyId).append("_").append(appender);
        groupName.append("_flow_priority_"+flowPriority);
		return groupName.toString();
	}

	/**
	 * This method builds partial flow name
	 *
	 * @param ingressPort
	 * @param ruleId
	 * @return
	 */
	protected String constructPartialFlowName(String ingressPort,Long ruleId) {
		StringBuilder flowName = new StringBuilder(ingressPort);
		flowName.append("_").append(ruleId);
		return flowName.toString();
	}

	/**
	 * This method returns Int value for the given Ethernet type
	 *
	 * @param etherType
	 * @return
	 */
	private int getIntValueEtherType(String etherType) {
		int i;
		if (etherType.equalsIgnoreCase("ipv4")) {
            i = 2048;
        }
		else if (etherType.equalsIgnoreCase("ipv6")) {
            i = 34525;
        }
		else if (etherType.equalsIgnoreCase("arp")) {
            i = 2054;
        }
		else {
			i = Integer.parseInt(etherType);
        }
		return i;
	}

	/**
	 * This method is used to build flow to applied on device in XML format
	 *
	 * @param id
	 * @param name
	 * @param ingressPort
	 * @param groupPortId
	 * @param isPort
	 * @param queueId
	 * @param rule
	 * @param flowPriority
	 * @param vLanId
	 * @param srcMacTag
	 * @param destMacTag
	 * @return
	 */
	protected String buildFlow(String id, String name, String ingressPort, String groupPortId, boolean isPort,
                               String queueId, Rule rule, int flowPriority, String vLanId, String srcMacTag, String destMacTag) {
		StringBuilder resultXml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
		resultXml.append("<flow xmlns=\"urn:opendaylight:flow:inventory\">");
		resultXml.append("<strict>false</strict>");
		resultXml.append("<hard-timeout>0</hard-timeout>");
		resultXml.append("<idle-timeout>0</idle-timeout>");
		resultXml.append("<instructions>");
		resultXml.append("<instruction>");
		resultXml.append("<order>0</order>");
		resultXml.append("<apply-actions>");

		/*
		 * <action> <push-vlan-action> <ethernet-type>33024</ethernet-type>
		 * </push-vlan-action> <order>0</order> </action>
		 */
		 int orderNumber = 1;
		 if (vLanId != null && vLanId.trim().length() > 0) {
			resultXml.append("<action>");
			resultXml.append("<set-field>");
			resultXml.append("<vlan-match>");
			resultXml.append("<vlan-id>");
			resultXml.append("<vlan-id>");
			resultXml.append(vLanId);
			resultXml.append("</vlan-id>");
			resultXml.append("<vlan-id-present>true</vlan-id-present>");
			resultXml.append("</vlan-id>");
			resultXml.append("</vlan-match>");
			resultXml.append("</set-field>");
			resultXml.append("<order>");
			resultXml.append(orderNumber);
			orderNumber++;
			resultXml.append("</order>");
			resultXml.append("</action>");
		 }

		 if (srcMacTag != null && srcMacTag.trim().length() > 0) {
			resultXml.append("<action>");
			resultXml.append("<set-field>");
			resultXml.append("<ethernet-match>");
			resultXml.append("<ethernet-source>");
			resultXml.append("<address>");
			resultXml.append(srcMacTag);
			resultXml.append("</address>");
			resultXml.append("</ethernet-source>");
			resultXml.append("</ethernet-match>");
			resultXml.append("</set-field>");
			resultXml.append("<order>");
			resultXml.append(orderNumber);
			orderNumber++;
			resultXml.append("</order>");
			resultXml.append("</action>");
		 }
		 if (destMacTag != null && destMacTag.trim().length() > 0) {
			resultXml.append("<action>");
			resultXml.append("<set-field>");
			resultXml.append("<ethernet-match>");
			resultXml.append("<ethernet-destination>");
			resultXml.append("<address>");
			resultXml.append(destMacTag);
			resultXml.append("</address>");
			resultXml.append("</ethernet-destination>");
			resultXml.append("</ethernet-match>");
			resultXml.append("</set-field>");
			resultXml.append("<order>");
			resultXml.append(orderNumber);
			orderNumber++;
			resultXml.append("</order>");
			resultXml.append("</action>");

		 }

		 if (rule.getIsPermit()) {
			 resultXml.append("<action>");
			 if (isPort) {
				resultXml.append("<output-action>");
				resultXml.append("<output-node-connector>");
				resultXml.append(groupPortId);
				resultXml.append("</output-node-connector>");
				resultXml.append("</output-action>");
			 } else {
				resultXml.append("<group-action>");
				resultXml.append("<group-id>");
				resultXml.append(groupPortId);
				resultXml.append("</group-id>");
				resultXml.append("</group-action>");
			 }
			 resultXml.append("<order>");
			 resultXml.append(orderNumber);
			 orderNumber++;
			 resultXml.append("</order>");
			 resultXml.append("</action>");
		} else {
			resultXml.append("<action>");
			resultXml.append("<order>");
			resultXml.append(orderNumber);
			orderNumber++;
			resultXml.append("</order>");
			resultXml.append("<drop-action/>");
			resultXml.append("</action>");
		}
		if (queueId != null && queueId.length() > 0 && rule.getIsPermit()) {
			resultXml.append("<action>");
			resultXml.append("<order>");
			resultXml.append(0);
			resultXml.append("</order>");
			resultXml.append("<set-queue-action>");
			resultXml.append("<queue-id>");
			resultXml.append(queueId);
			resultXml.append("</queue-id>");
			resultXml.append("</set-queue-action>");
			resultXml.append("</action>");
		}
		resultXml.append("</apply-actions>");
		resultXml.append("</instruction>");
		resultXml.append("</instructions>");
		resultXml.append("<table_id>0</table_id>");// use table 0 by default
		resultXml.append("<id>");
		resultXml.append(id);
		resultXml.append("</id>");
		resultXml.append("<match>");

		//////////////////////////////////////////////////////////////////////////

		/// match builder /////

		String srcMac = rule.getSourceMac();
		String destMac = rule.getDestinationMac();
		String srcMacMask = rule.getSourceMacMask();
		String destMacMask = rule.getDestinationMacMask();
		String etherType = rule.getEthType();
		String srcIp = rule.getSourceIp();
		String destIP = rule.getDestinationIp();
		String protocol = rule.getProtocol();
		String protocolType = rule.getProtocolType();
		int srcPort = rule.getSourcePort();
		int destPort = rule.getDestinationPort();
		Long priority = rule.getSequence() + flowPriority;
		// check empty String
		if (srcMac == null || srcMac.length() == 0 || srcMac.trim().length() == 0)
			srcMac = null;
		if (destMac == null || destMac.length() == 0 || destMac.trim().length() == 0)
			destMac = null;
		if (srcMacMask == null || srcMacMask.length() == 0 || srcMacMask.trim().length() == 0)
			srcMacMask = null;
		if (destMacMask == null || destMacMask.length() == 0 || destMacMask.trim().length() == 0)
			destMacMask = null;
		if (destIP == null || destIP.length() == 0 || destIP.trim().length() == 0)
			destIP = null;

		if ((srcMac != null && !(srcMac.equalsIgnoreCase("any")))
				|| (destMac != null && !(destMac.equalsIgnoreCase("any")))
				|| (etherType != null && !(etherType.equalsIgnoreCase("any")))) {

			resultXml.append("<ethernet-match>");
			if (etherType != null && !(etherType.equalsIgnoreCase("any"))) {
				resultXml.append("<ethernet-type>");
				resultXml.append("<type>");
                resultXml.append(getIntValueEtherType(etherType));
                resultXml.append("</type>");
				resultXml.append("</ethernet-type>");
			}
			if (srcMac != null && !(srcMac.equalsIgnoreCase("any"))) {
				resultXml.append("<ethernet-source>");
				resultXml.append("<address>");
				resultXml.append(srcMac);
				resultXml.append("</address>");
				if (srcMacMask != null) {
					resultXml.append("<mask>");
					resultXml.append(srcMacMask);
					resultXml.append("</mask>");
				}
				resultXml.append("</ethernet-source>");
			}
			if (destMac != null && !(destMac.equalsIgnoreCase("any"))) {
				resultXml.append("<ethernet-destination>");
				resultXml.append("<address>");
				resultXml.append(destMac);
				resultXml.append("</address>");
				if (destMacMask != null) {
					resultXml.append("<mask>");
					resultXml.append(destMacMask);
					resultXml.append("</mask>");
				}
				resultXml.append("</ethernet-destination>");
			}
			resultXml.append("</ethernet-match>");
		}
		int vlanId = rule.getVlanId();
		if (vlanId > 0) {
			resultXml.append("<vlan-match>");
			resultXml.append("<vlan-id><vlan-id>");
			resultXml.append(vlanId);
			resultXml.append("</vlan-id>");
			resultXml.append("<vlan-id-present>true</vlan-id-present>");
			resultXml.append("</vlan-id>");
			resultXml.append("</vlan-match>");
		}
		if (etherType != null && !(etherType.equalsIgnoreCase("any"))) {
			if (etherType.equalsIgnoreCase("ipv4")) {
				if (srcIp != null && !(srcIp.equalsIgnoreCase("any"))) {
					resultXml.append("<ipv4-source>");
					resultXml.append(srcIp);
					resultXml.append("</ipv4-source>");
				}
				if (destIP != null && !(destIP.equalsIgnoreCase("any"))) {
					resultXml.append("<ipv4-destination>");
					resultXml.append(destIP);
					resultXml.append("</ipv4-destination>");
				}

			} else if (etherType.equalsIgnoreCase("ipv6")) {
				if (srcIp != null && !(srcIp.equalsIgnoreCase("any"))) {
					resultXml.append("<ipv6-source>");
					resultXml.append(srcIp);
					resultXml.append("</ipv6-source>");
				}
				if (destIP != null && !(destIP.equalsIgnoreCase("any"))) {
					resultXml.append("<ipv6-destination>");
					resultXml.append(destIP);
					resultXml.append("</ipv6-destination>");
				}

			}
			//commented because L3/L23 supports only IPV4/IPV6
			/*else if (etherType.equalsIgnoreCase("arp")) {
				if (srcIp != null && !(srcIp.equalsIgnoreCase("any"))) {
					resultXml.append("<arp-source-transport-address>");
					resultXml.append(srcIp);
					resultXml.append("</arp-source-transport-address>");
				}
				if (destIP != null && !(destIP.equalsIgnoreCase("any"))) {
					resultXml.append("<arp-target-transport-address>");
					resultXml.append(destIP);
					resultXml.append("</arp-target-transport-address>");
				}
			} else {

			}*/

		}
		if (protocol != null && !(protocol.equalsIgnoreCase("any"))) {
			if (!protocol.equalsIgnoreCase("ip"))
				resultXml.append("<ip-match><ip-protocol>");
			if (protocol.equalsIgnoreCase("tcp")) {
				resultXml.append(6);
			} else if (protocol.equalsIgnoreCase("udp")) {
				resultXml.append(17);
			} else if (protocol.equalsIgnoreCase("ip")) {
				// need clarification on this IP protocol type.
			} else if (protocol.equalsIgnoreCase("sctp")) {
				resultXml.append(132);
			} else if (protocol.equalsIgnoreCase("icmp")) {
				if (etherType != null && (etherType.equalsIgnoreCase("ipv6")))
					resultXml.append(58);
				else
					resultXml.append(1);
			} else if (protocol.equalsIgnoreCase("igmp")) {
				resultXml.append(2);
			} else {
				resultXml.append(protocol);
				// This is for user entered protocol value
			}

			resultXml.append("</ip-protocol></ip-match>");
		}
		if (protocol != null && !(protocol.equalsIgnoreCase("any"))) {
			if (protocolType !=null && protocolType.equalsIgnoreCase("tcp")) {
				if (srcPort > 0) {
					resultXml.append("<tcp-source-port>");
					resultXml.append(srcPort);
					resultXml.append("</tcp-source-port>");
				}
				if (destPort > 0) {
					resultXml.append("<tcp-destination-port>");
					resultXml.append(destPort);
					resultXml.append("</tcp-destination-port>");
				}

			} else if (protocolType !=null && protocolType.equalsIgnoreCase("udp")) {
				if (srcPort > 0) {
					resultXml.append("<udp-source-port>");
					resultXml.append(srcPort);
					resultXml.append("</udp-source-port>");
				}
				if (destPort > 0) {
					resultXml.append("<udp-destination-port>");
					resultXml.append(destPort);
					resultXml.append("</udp-destination-port>");
				}
			}
			else if (protocolType !=null && protocolType.equalsIgnoreCase("sctp")) {
				if (srcPort > 0) {
					resultXml.append("<sctp-source-port>");
					resultXml.append(srcPort);
					resultXml.append("</sctp-source-port>");
				}
				if (destPort > 0) {
					resultXml.append("<sctp-destination-port>");
					resultXml.append(destPort);
					resultXml.append("</sctp-destination-port>");
				}
			}
			else {
				/// TODO check other cases.....
			}
		}
		resultXml.append("<in-port>");
		resultXml.append(ingressPort);
		resultXml.append("</in-port>");
		resultXml.append("</match>");
		resultXml.append("<flow-name>");
		resultXml.append(name);
		resultXml.append("</flow-name>");
		resultXml.append("<priority>");
		resultXml.append(priority);
        resultXml.append("</priority>");
		resultXml.append("</flow>");
		return resultXml.toString();
	}

	/**
	 * This method used to add flow on the device through BSC
	 *
	 * @param deviceId
	 * @param flowId
	 * @param flowData
	 * @return
	 */
	protected boolean addFlowOnDevice(String deviceId, String flowId, String flowData) {
		try {
			log.info("Flow Entity : " + flowData);
			Response res = bscConnection.put(Entity.xml(flowData),configUrl, resourceUrl, deviceId, tableURL, flowURL, flowId);
			log.info("response :{} ", res);
			if (res != null && (res.getStatus() == 200 || res.getStatus() == 201)) {
                return true;
            }
            return false;

		} catch (Exception e) {
			log.error("Error when creating flow on device with xml {}",flowData,e);
			throw new OutboundApiException(e.getMessage());
		}
	}

	/**
	 * This method is used to verify if the flow visible through operational URL
	 *
	 * @param deviceId
	 * @param flowIds
	 * @param isCreate
	 * @return
	 */
	protected boolean verifyFlow(String deviceId, List<String> flowIds, boolean isCreate) {
		log.info("Verification requied:{}", isVerificationNeeded);
		if (isVerificationNeeded) {
			try {
				for (int i = 0; i < retryCount; i++) {
					flowVerificationDetails = new FlowVerificationDetails();
					flowVerificationDetails.setDeviceId(deviceId);
					List<String> operationalFlowIds = getOperationalFlowInfo(deviceId);
					if (isCreate) {
						if (operationalFlowIds.size() > 0) {
							for (int cnt = 0; cnt < flowIds.size(); cnt++) {
								String flowId = flowIds.get(cnt);
								if (operationalFlowIds.contains(flowId)) {
									log.debug("matched flowId " + flowId);
								}
							}
							boolean result = verifyAttributesForFlow(flowIds);
							if (result) {
								return true;
							} else {
								log.debug("Re-trying {}/{} time to validate the flow", i, retryCount);
							}
						}
					} else {
						if (!operationalFlowIds.containsAll(flowIds)) {
							return true;
						}
					}
					try {
						TimeUnit.SECONDS.sleep(retrySleepSeconds);
					} catch (InterruptedException e1) {
						throw new ServerException(e1);
					}
				}
				return false;
			} catch (Exception e) {
				log.error("Error when verifying flows in Operational Url", e);
				throw new OutboundApiException(e.getMessage());
			}
		} else
			return true;
	}

	/**
	 * This method builds the XML to
	 *
	 * @param id
	 * @param name
	 * @param type
	 * @param portIds
	 * @return
	 */
    protected String buildGroup(String id, String name, String type, List<String> portIds) {

		StringBuilder resultXml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
		resultXml.append("<group xmlns=\"urn:opendaylight:flow:inventory\">");
		resultXml.append("<group-type>");
		resultXml.append(type);
		resultXml.append("</group-type>");
		resultXml.append("<buckets>");

		int i = 1;
		for (String portid : portIds) {

			resultXml.append("<bucket>");
			resultXml.append("<weight>1</weight>");
			resultXml.append("<action>");
			resultXml.append("<output-action>");
			resultXml.append("<output-node-connector>");
			resultXml.append(portid);
			resultXml.append("</output-node-connector>");
			resultXml.append("</output-action>");
			resultXml.append("<order>1</order>");
			resultXml.append("</action>");
			resultXml.append("<bucket-id>");
			resultXml.append(Integer.toString(i));
			resultXml.append("</bucket-id>");
			resultXml.append("</bucket>");
			i++;
		}

		resultXml.append("</buckets>");
		resultXml.append("<barrier>false</barrier>");
		resultXml.append("<group-name>");
		resultXml.append(name);
		resultXml.append("</group-name>");
		resultXml.append("<group-id>");
		resultXml.append(id);
		resultXml.append("</group-id>");
		resultXml.append("</group>");

		return resultXml.toString();
	}

	/**
	 * This method is used build XML to create PortGroup with VLAN
	 *
	 * @param id
	 * @param name
	 * @param type
	 * @param portIds
	 * @param vLanId
	 * @param srcMacTag
	 * @param destMacTag
	 * @return
	 */
	protected String buildGroupWithVLan(String id, String name, String type, List<String> portIds, String vLanId, String srcMacTag, String destMacTag, boolean vlanStripping) {
		StringBuilder resultXml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
		resultXml.append("<group xmlns=\"urn:opendaylight:flow:inventory\">");
		resultXml.append("<group-type>");
		resultXml.append(type);
		resultXml.append("</group-type>");
		resultXml.append("<buckets>");

		int i = 1;
		for (String portid : portIds) {
			resultXml.append("<bucket>");
			resultXml.append("<weight>1</weight>");
			if (vlanStripping) {
				resultXml.append("<action>");
				resultXml.append("<pop-vlan-action/>");
				resultXml.append("<order>0</order>");
				resultXml.append("</action>");
			}
			resultXml.append("<action>");
			resultXml.append("<output-action>");
			resultXml.append("<output-node-connector>");
			resultXml.append(portid);
			resultXml.append("</output-node-connector>");
			resultXml.append("</output-action>");
			resultXml.append("<order>1</order>");
			resultXml.append("</action>");
			int orderNumber = 2;

			if (vLanId != null && vLanId.trim().length() > 0) {

				resultXml.append("<action>");
				resultXml.append("<push-vlan-action>");
				resultXml.append("<ethernet-type>");
				resultXml.append("33024");
				resultXml.append("</ethernet-type>");
				resultXml.append("</push-vlan-action>");
				resultXml.append("<order>0</order>");
				resultXml.append("</action>");

				resultXml.append("<action>");
				resultXml.append("<set-field>");
				resultXml.append("<vlan-match>");
				resultXml.append("<vlan-id>");
				resultXml.append("<vlan-id>");
				resultXml.append(vLanId);
				resultXml.append("</vlan-id>");
				resultXml.append("<vlan-id-present>");
				resultXml.append("true");
				resultXml.append("</vlan-id-present>");
				resultXml.append("</vlan-id>");
				resultXml.append("</vlan-match>");
				resultXml.append("</set-field>");
				resultXml.append("<order>");
				resultXml.append(orderNumber);
				orderNumber++;
				resultXml.append("</order>");
				resultXml.append("</action>");
			}
			if (srcMacTag != null && srcMacTag.trim().length() > 0) {
				resultXml.append("<action>");
				resultXml.append("<set-field>");
				resultXml.append("<ethernet-match>");
				resultXml.append("<ethernet-source>");
				resultXml.append("<address>");
				resultXml.append(srcMacTag);
				resultXml.append("</address>");
				resultXml.append("</ethernet-source>");
				resultXml.append("</ethernet-match>");
				resultXml.append("</set-field>");
				resultXml.append("<order>");
				resultXml.append(orderNumber);
				orderNumber++;
				resultXml.append("</order>");
				resultXml.append("</action>");
			}
			if (destMacTag != null && destMacTag.trim().length() > 0) {
				resultXml.append("<action>");
				resultXml.append("<set-field>");
				resultXml.append("<ethernet-match>");
				resultXml.append("<ethernet-destination>");
				resultXml.append("<address>");
				resultXml.append(destMacTag);
				resultXml.append("</address>");
				resultXml.append("</ethernet-destination>");
				resultXml.append("</ethernet-match>");
				resultXml.append("</set-field>");
				resultXml.append("<order>");
				resultXml.append(orderNumber);
				orderNumber++;
				resultXml.append("</order>");
				resultXml.append("</action>");

			}
			resultXml.append("<bucket-id>");
			resultXml.append(Integer.toString(i));
			resultXml.append("</bucket-id>");
			resultXml.append("</bucket>");
			i++;
		}

		resultXml.append("</buckets>");
		resultXml.append("<barrier>false</barrier>");
		resultXml.append("<group-name>");
		resultXml.append(name);
		resultXml.append("</group-name>");
		resultXml.append("<group-id>");
		resultXml.append(id);
		resultXml.append("</group-id>");
		resultXml.append("</group>");
		return resultXml.toString();

	}

	/**
	 * This method is used to create Group on device
	 *
	 * @param deviceId
	 * @param groupId
	 * @param groupData
	 * @return
	 */
	protected boolean addGroupOnDevice(String deviceId, String groupId, String groupData) {
		try {
			log.info("Group Entity :{} ", groupData);
			Response res = bscConnection.put(Entity.xml(groupData),configUrl, resourceUrl, deviceId, groupURL, groupId);
			log.info("response :{}", res);
			if (res != null && (res.getStatus() == 200 || res.getStatus() == 201)) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			log.error("Error when creating groupe on device for flow with xml {}",groupData,e);
			throw new OutboundApiException(e.getMessage());
		}
	}

	/**
	 * This method is used to get the PortNameIdMap from operation URL
	 *
	 * @param deviceId
	 * @return
	 */
	protected Map<String, String> getPortNameIdMap(String deviceId) {

		Map<String, String> ports = new HashMap<>();
		try {
			log.info("Get Port ID MAP Url");
			Response res = bscConnection.get(operationUrl, resourceUrl, deviceId);
			log.info("response : ", res);
			if (res != null && res.getStatus() == 200) {
				ports = getPortMap(res);
			}
		} catch (OutboundConnectionException e) {
			log.error("Failed to get Port Name ID map", e);
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
				//do nothing
                //FixMe: As we are quering on Operational and got 404 which means Device got detached we should not allow to go further.
			}else{
				throw e;
			}
		}
		return ports;
	}

	/**
	 * This method is used to process the response and get the Port name and id map
	 *
	 * @param response
	 * @return
	 */
	private HashMap<String, String> getPortMap(Response response) {
		HashMap<String, String> portNameIdMap = new HashMap<>();
		String xmlString = response.readEntity(String.class);
		xmlString = xmlString.replace("<capabilities>", "<capabilities><name>");
		xmlString = xmlString.replace("</capabilities>", "</name></capabilities>");
		xmlString = xmlString.replace("<max-groups>", "<max-groups><name>");
		xmlString = xmlString.replace("</max-groups>", "</name></max-groups>");
		try {
			JSONObject xmlJSONObj = XML.toJSONObject(xmlString);
			String removeKey = "xmlns";
			removeJSONField(xmlJSONObj, removeKey);
			removeKey = "xmlns:x";
			removeJSONField(xmlJSONObj, removeKey);
			removeKey = "meter-features";
			removeJSONField(xmlJSONObj, removeKey);
			removeKey = "switch-features";
			removeJSONField(xmlJSONObj, removeKey);
			JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
			if (realNode.has("node-connector")) {
				Object portList = realNode.get("node-connector");
				if (portList instanceof JSONObject) {
					JSONObject realPort = (JSONObject) portList;
					portNameIdMap.put(getValue(realPort.get("name")).toLowerCase(), getValue(realPort.get("id")));
				} else if (portList instanceof JSONArray) {
					int ports = ((JSONArray) portList).length();
					for (int portCount = 0; portCount < ports; portCount++) {
						JSONObject realPort = ((JSONArray) portList).getJSONObject(portCount);
						portNameIdMap.put(getValue(realPort.get("name")).toLowerCase(), getValue(realPort.get("id")));
					}
				}
			}
		} catch (JSONException e) {
			log.error("Failed to build port name id map: {}",xmlString,e);
			throw new OutboundApiException("Failed to extract openflow ports from BSC ",e);
		}
		return portNameIdMap;
	}

	/**
	 * This method is used to get string value out of object
	 *
	 * @param obj
	 * @return
	 * @throws JSONException
	 */
	private String getValue(Object obj) throws JSONException {
		if (obj instanceof JSONObject) {
			if (((JSONObject) obj).has("content")) {
				return ((JSONObject) obj).get("content").toString();
			} else if (((JSONObject) obj).has("link-down")) { // ODL provides
																// state
																// {link-down,blocked,live}
																// in boolean
				if (((JSONObject) obj).getBoolean("link-down")) {
					return "Down";
				} else {
					return "Up";
				}
			} else {
				return "unknown";
			}

		} else if (obj instanceof String) {
			return (String) obj;
		} else {
			return "unknown";
		}
	}

	/**
	 * This method is used to find the FLOW info from the given Open flow device
	 *
	 * @param deviceId
	 * @return
	 */
	protected synchronized Map<String, Set<String>> getFlowInfo(String deviceId) {
		Map<String, Set<String>> flowIdNameMap = new HashMap<>();
		Set<String> flowIdList = new TreeSet<>();
		Set<String> flowNameList = new TreeSet<>();
		flowIdNameMap.put("ids", flowIdList);
		flowIdNameMap.put("names", flowNameList);
		try{
            Response res = bscConnection.get(MediaType.APPLICATION_JSON_TYPE,configUrl, resourceUrl, deviceId);
            log.info("response : ", res);
            String xmlString = res.readEntity(String.class);
            try {
                JSONObject completeResponse = new JSONObject(xmlString);
                if (completeResponse.has("node")) {
                    JSONArray nodeArray = (JSONArray) completeResponse.get("node");
                    if (nodeArray.length() > 0) {
                        JSONObject realNode = (JSONObject) nodeArray.get(0);
                        if (realNode.has("flow-node-inventory:table")) {
                            JSONArray tableNode = (JSONArray) realNode.get("flow-node-inventory:table");
                            if (tableNode.length() > 0) {
                                JSONObject table = (JSONObject) tableNode.get(0);
                                if (table.has("flow")) {
                                    JSONArray flows = (JSONArray) table.get("flow");
                                    for (int i = 0; i < flows.length(); i++) {
                                        JSONObject flowNode = flows.getJSONObject(i);
                                        if (flowNode.has("flow-name") && flowNode.has("id")) {
                                            flowIdList.add(flowNode.get("id").toString());
                                            flowNameList.add(flowNode.get("flow-name").toString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                log.error("Failed to build FlowInfo");
                throw new OutboundApiException(e.getMessage());
            }
        }catch (OutboundConnectionException e) {
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the flows from Config datastore.
			}else{
				throw e;
			}
		}

		return flowIdNameMap;
	}

	/**
	 * This method is used to fetch the FLOW info from operation URL
	 *
	 * @param deviceId
	 * @return
	 */
    protected synchronized List<String> getOperationalFlowInfo(String deviceId) {
        List<String> flowIds = new ArrayList<>();
        try {
            Response operationalResponse = bscConnection.get(MediaType.APPLICATION_JSON_TYPE,operationUrl, resourceUrl, deviceId);
            log.info("response : ", operationalResponse);
            String xmlString = operationalResponse.readEntity(String.class);
            try {
                JSONObject completeResponse = new JSONObject(xmlString);
                if (completeResponse.has("node")) {
                    JSONArray nodeArray = (JSONArray) completeResponse.get("node");
                    if (nodeArray.length() > 0) {
                        JSONObject realNode = (JSONObject) nodeArray.get(0);
                        if (realNode.has("flow-node-inventory:table")) {
                            JSONArray tableNode = (JSONArray) realNode.get("flow-node-inventory:table");
                            if (tableNode.length() > 0) {
                                JSONObject table = (JSONObject) tableNode.get(0);
                                if (table.has("flow")) {
                                    JSONArray flows = (JSONArray) table.get("flow");
                                    for (int i = 0; i < flows.length(); i++) {
                                        JSONObject flowNode = flows.getJSONObject(i);
                                        if (flowNode.has("id")) {
                                            flowIds.add(flowNode.get("id").toString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                log.error("Failed to build Operational FlowInfo");
                throw new OutboundApiException(e.getMessage());
            }
        }catch (OutboundConnectionException e) {
            if(e.getMessage().contains("404")){
                log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //FixMe: As we are querying on Operational and got 404 which means Device got detached we should not allow to go further.
            }else{
                throw e;
            }
        }
        return flowIds;
    }

	/**
	 * This method is used to find out Port Group info from the given device
	 *
	 * @param deviceId
	 * @return
	 */
	protected Map<String, Set<String>> getGroupInfo(String deviceId) {
		Map<String, Set<String>> groupIdNameMap = new HashMap<>();
		Set<String> groupIdList = new TreeSet<>();
		Set<String> groupNameList = new TreeSet<>();
		groupIdNameMap.put("ids", groupIdList);
		groupIdNameMap.put("names", groupNameList);
		try{
			Response res = bscConnection.get(configUrl, resourceUrl, deviceId);
			log.info("response : ", res);
			try {
				String xmlString = res.readEntity(String.class);
				JSONObject xmlJSONObj;
				xmlJSONObj = XML.toJSONObject(xmlString);
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);

				log.info(xmlJSONObj.toString());

				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");

				if (realNode.has("group")) {

					Object groupObj = realNode.get("group");
					if (groupObj instanceof JSONObject) {// single group

						JSONObject groupNode = (JSONObject) groupObj;

						if (groupNode.has("group-name") && groupNode.has("group-id")) {
							groupIdList.add(groupNode.get("group-id").toString());
							groupNameList.add(groupNode.get("group-name").toString());
						}

					} else if (groupObj instanceof JSONArray) {
						JSONArray groupNodes = (JSONArray) groupObj;
						int size = groupNodes.length();
						for (int i = 0; i < size; i++) {

							JSONObject groupNode = groupNodes.getJSONObject(i);

							if (groupNode.has("group-name") && groupNode.has("group-id")) {
								groupIdList.add(groupNode.get("group-id").toString());
								groupNameList.add(groupNode.get("group-name").toString());
							}

						}
					}

				}
			} catch (JSONException e) {
				return null;
			}
		}catch(OutboundConnectionException e){
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the groups from Config datastore.
			}else{
				throw e;
			}
		}

		return groupIdNameMap;
	}

	/**
	 * This method is used to fetch the Group name associated with the policy
	 *
	 * @param deviceId
	 * @param policy
	 * @return
	 */
	public List<String> getGroupNameWithPolicy(String deviceId, Policy policy) {
		List<String> groupIdList = new ArrayList<>();
		String policyName = policy.getName();
		Response res = bscConnection.get(configUrl, resourceUrl, deviceId);
		try{
			log.info("response : {}", res);
			String xmlString = res.readEntity(String.class);
			JSONObject xmlJSONObj;
			try {
				xmlJSONObj = XML.toJSONObject(xmlString);
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);
				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
				List<PolicyHistory> policyHistories = policyHistoryRepository.findByIdAndWorkflowStatus(policy.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
				HashSet<String> uniquePolicyNames = new HashSet<String>();
				for ( PolicyHistory policyHistory:policyHistories) {
					uniquePolicyNames.add(policyHistory.getName());
				}

				if (realNode.has("group")) {
					Object groupObj = realNode.get("group");
					if (groupObj instanceof JSONObject) {// single group
						JSONObject groupNode = (JSONObject) groupObj;
						if (groupNode.has("group-name") && groupNode.has("group-id") && groupNode.has("group-type")) {
							String groupName = groupNode.get("group-name").toString();
							if (groupName.startsWith(policyName+"_lb") || groupName.startsWith(policyName+"_ag")) {
								groupIdList.add(groupNode.get("group-id").toString());
							} else {
								String[] grpPartName = groupName.split("_");
								String name = "";
								if (grpPartName.length > 0){
									name = grpPartName[0];
								}

								for (String ploicyName: uniquePolicyNames) {
									if (groupName.startsWith(ploicyName+"_lb")|| groupName.startsWith(policyName+"_ag")) {
										if (policyHistoryRepository.findByNameAndNotParentId(name, policy.getId()).size() == 0) {
											groupIdList.add(groupNode.get("group-id").toString());
											break;
										}
									}
								}
							}
						}
					} else if (groupObj instanceof JSONArray) {
						JSONArray groupNodes = (JSONArray) groupObj;
						int size = groupNodes.length();
						for (int i = 0; i < size; i++) {
							JSONObject groupNode = groupNodes.getJSONObject(i);
							if (groupNode.has("group-name") && groupNode.has("group-id")
									&& groupNode.has("group-type")) {
								String groupName = groupNode.get("group-name").toString();
								if (groupName.startsWith(policyName+"_lb") || groupName.startsWith(policyName+"_ag")) {
									groupIdList.add(groupNode.get("group-id").toString());
									continue;
								}
								String[] grpPartName = groupName.split("_");
								String name = "";
								if (grpPartName.length > 0){
									name = grpPartName[0];
								}
								for (String ploicyName: uniquePolicyNames) {
									if (groupName.startsWith(policyName+"_lb") || groupName.startsWith(policyName+"_ag")){
										if( policyHistoryRepository.findByNameAndNotParentId(name, policy.getId()).size() == 0) {
											groupIdList.add(groupNode.get("group-id").toString());
											break;
										}
									}

								}
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error("Failed to get group on policyName {} ",policyName);
				return null;
			}
		}catch (OutboundConnectionException e) {
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the flows from Config datastore.
			}else{
				throw e;
			}
		}

		return groupIdList;
	}

	/**
	 * This method is used to fetch the Group name associated with the policyId
	 *
	 * @param deviceId
	 * @param policyId
	 * @return
	 */
	public List<String> getGroupNameWithPolicy(String deviceId, Long policyId) {
		List<String> groupIdList = new ArrayList<>();
		Response res = bscConnection.get(configUrl, resourceUrl, deviceId);
		try{
			log.info("response : {}", res);
			String xmlString = res.readEntity(String.class);
			JSONObject xmlJSONObj;
			try {
				xmlJSONObj = XML.toJSONObject(xmlString);
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);
				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
				if (realNode.has("group")) {
					Object groupObj = realNode.get("group");
					if (groupObj instanceof JSONObject) {// single group
						JSONObject groupNode = (JSONObject) groupObj;
						if (groupNode.has("group-name") && groupNode.has("group-id") && groupNode.has("group-type")) {
							String groupName = groupNode.get("group-name").toString();
							if (groupName.startsWith("policy_"+policyId+"_lb") || groupName.startsWith("policy_"+policyId+"_ag")) {
								groupIdList.add(groupNode.get("group-id").toString());
							}
						}
					} else if (groupObj instanceof JSONArray) {
						JSONArray groupNodes = (JSONArray) groupObj;
						int size = groupNodes.length();
						for (int i = 0; i < size; i++) {
							JSONObject groupNode = groupNodes.getJSONObject(i);
							if (groupNode.has("group-name") && groupNode.has("group-id")
									&& groupNode.has("group-type")) {
								String groupName = groupNode.get("group-name").toString();
								if (groupName.startsWith("policy_"+policyId+"_lb") || groupName.startsWith("policy_"+policyId+"_ag")) {
									groupIdList.add(groupNode.get("group-id").toString());
								}
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error("Failed to get group on PolicyId {} ",policyId);
				return null;
			}
		}catch (OutboundConnectionException e) {
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the flows from Config datastore.
			}else{
				throw e;
			}
		}

		return groupIdList;
	}

	/**
	 * This method fetches the Port Group Ids from the given device
	 *
	 * @param groupName
	 * @param deviceId
	 * @return
	 */
    public List<String> getGroupNameForFlow(String groupName,String deviceId) {
        List<String> groupIdList = new ArrayList<>();

        String groupNameForAG = groupName.replace("_lb","_ag");
        Response res = bscConnection.get(configUrl, resourceUrl, deviceId);
        try{
            log.info("response : {}", res);
            String xmlString = res.readEntity(String.class);
            JSONObject xmlJSONObj;
            try {
                xmlJSONObj = XML.toJSONObject(xmlString);
                String removeKey = "xmlns";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:x";
                removeJSONField(xmlJSONObj, removeKey);
                removeKey = "xmlns:s";
                removeJSONField(xmlJSONObj, removeKey);
                JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
                if (realNode.has("group")) {
                    Object groupObj = realNode.get("group");
                    if (groupObj instanceof JSONObject) {// single group
                        JSONObject groupNode = (JSONObject) groupObj;
                        if (groupNode.has("group-name") && groupNode.has("group-id") && groupNode.has("group-type")) {
                            String groupNameOnBSC = groupNode.get("group-name").toString();
                            if (groupNameOnBSC.equalsIgnoreCase(groupName)|| groupNameOnBSC.equalsIgnoreCase(groupNameForAG)) {
                                groupIdList.add(groupNode.get("group-id").toString());
                            }
                        }
                    } else if (groupObj instanceof JSONArray) {
                        JSONArray groupNodes = (JSONArray) groupObj;
                        int size = groupNodes.length();
                        for (int i = 0; i < size; i++) {
                            JSONObject groupNode = groupNodes.getJSONObject(i);
                            if (groupNode.has("group-name") && groupNode.has("group-id")
                                    && groupNode.has("group-type")) {
                                String groupNameOnBSC = groupNode.get("group-name").toString();
                                if (groupNameOnBSC.equalsIgnoreCase(groupName)|| groupNameOnBSC.equalsIgnoreCase(groupNameForAG)) {
                                    groupIdList.add(groupNode.get("group-id").toString());
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                log.error("Failed to get groupId on BSC for ",groupName);
                return null;
            }
        }catch (OutboundConnectionException e) {
            if(e.getMessage().contains("404")){
                log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the groups from Config datastore.
            }else{
                throw e;
            }
        }

        return groupIdList;
    }

	/**
	 * This method is used to delete flow on device
	 *
	 * @param deviceId
	 * @param flowId
	 * @return
	 */
	protected boolean deleteFlowOnDevice(String deviceId, String flowId) {
		try {
			Response res = bscConnection.delete(configUrl, resourceUrl, deviceId, tableURL, flowURL, flowId);
			log.info("response : " + res);
			if (res != null && res.getStatus() == 200) {
				bscIdGenerator.removeFlowId(flowId);
                return true;
            }
            return false;
        } catch (Exception e) {
            log.error("Failed to delete policy : {}",e.getMessage());
			return false;
		}
	}

	/**
	 * This method is used to delete Group on device
	 *
	 * @param deviceId
	 * @param groupId
	 * @return
	 */
	protected boolean deleteGroupOnDevice(String deviceId, String groupId) {
		try {
			Response res = bscConnection.delete(configUrl, resourceUrl, deviceId,groupURL, groupId);
			log.info("response : {}", res);
			if (res != null && res.getStatus() == 200) {
				bscIdGenerator.removeGroupId(groupId);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method is used fetch the Flows associated with Policy name
	 *
	 * @param deviceId
	 * @param policyName
	 * @param isPolicyName
	 * @return
	 */
	public List<String> getFlowWithPolicyName(String deviceId, String policyName, boolean isPolicyName) {
		List<String> flowIdList = new ArrayList<String>();
		Response res = bscConnection.get(configUrl, resourceUrl, deviceId);

		try{
			log.info("response : {}", res);
			String xmlString = res.readEntity(String.class);
			JSONObject xmlJSONObj;
			try {
				xmlJSONObj = XML.toJSONObject(xmlString);
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);
				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
				if (realNode.has("table") && ((JSONObject) realNode.get("table")).has("flow")) {
					Object flowObj = ((JSONObject) realNode.get("table")).get("flow");
					if (flowObj instanceof JSONObject) {
						JSONObject flowNode = (JSONObject) flowObj;
						if (flowNode.has("flow-name") && flowNode.has("id")) {
							String flowName = flowNode.get("flow-name").toString();
							if (isPolicyName) {
								if (flowName.startsWith(policyName + "_")) {
									flowIdList.add(flowNode.get("id").toString());
								}
							} else{
								if (flowName.equals(policyName)) {
									flowIdList.add(flowNode.get("id").toString());
								}
							}
						}

					} else if (flowObj instanceof JSONArray) {
						JSONArray flowNodes = (JSONArray) flowObj;
						int size = flowNodes.length();
						for (int i = 0; i < size; i++) {
							JSONObject flowNode = flowNodes.getJSONObject(i);
							if (flowNode.has("flow-name") && flowNode.has("id")) {
								String flowName = flowNode.get("flow-name").toString();
								if (isPolicyName) {
									if (flowName.startsWith(policyName + "_")) {
										flowIdList.add(flowNode.get("id").toString());
									}
								} else{
									if (flowName.equals(policyName)) {
										flowIdList.add(flowNode.get("id").toString());
									}
								}
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error("Failed ",e);
				return null;
			}
		}catch (OutboundConnectionException e) {
			if(e.getMessage().contains("404")){
				log.info("Received a 404 as this could be the first call on the device:{}",e.getMessage());
                //TODO: Expected scenario as we are loading the flows from Config datastore.
			}else{
				throw e;
			}
		}
		return flowIdList;
	}

	/**
	 * This method is used to remove given key from JSONObject
	 *
	 * @param obj
	 * @param id
	 * @throws JSONException
	 */
	private void removeJSONField(JSONObject obj, String id) throws JSONException {
		obj.remove(id);
		@SuppressWarnings("rawtypes")
		Iterator it = obj.keys();
		while (it.hasNext()) {
			String key = it.next().toString();
			Object childObj = obj.get(key);
			if (childObj instanceof JSONArray) {
				JSONArray arrayChildObjs = ((JSONArray) childObj);
				int size = arrayChildObjs.length();
				for (int i = 0; i < size; i++) {
					try {
						removeJSONField(arrayChildObjs.getJSONObject(i), id);
					} catch (JSONException e) {
						log.info(arrayChildObjs.toString());
						e.printStackTrace();
					}
				}
			}
			if (childObj instanceof JSONObject) {
				try {
					removeJSONField(((JSONObject) childObj), id);
				} catch (JSONException e) {
					log.error("Failed {}",childObj.toString(),e);
				}
			}
		}
	}

	/**
	 * This method is used to validates attributes of operational flow
	 *
	 * @return
	 */
	protected boolean verifyAttributesForFlow(List<String> flowIds) {
		getConfigFlowInfoForVerification(flowIds);
		getOperationalFlowInfoForVerification(flowIds);
		log.debug("Config Flow objects:{}, Operational Flow Objects:{}", flowVerificationDetails.getConfigurationObjects().size(), flowVerificationDetails.getOperationalObjects().size());
		for (String key : flowVerificationDetails.getConfigurationObjects().keySet()) {
			//key in inport:outport
			log.debug("Verifying for Config Flow object:{}", key);
			List<FlowRule> configurationFlows = flowVerificationDetails.getConfigurationObjects().get(key);
			List<FlowRule> operationalFlows = flowVerificationDetails.getOperationalObjects().get(key);
			//check for all config flow rules in operational bucket
			if ((configurationFlows != null && !configurationFlows.isEmpty()) && (operationalFlows != null && !operationalFlows.isEmpty())) {
				for (FlowRule eachConfigRule : configurationFlows) {
					if (operationalFlows != null) {
						if (!operationalFlows.contains(eachConfigRule)) {
							log.error("Failed to find the config flow with id {} in operational flows {}", eachConfigRule, operationalFlows.toString());
							return false;
						} else {
							log.debug("Found the config flow with id {} in operational flows {}", eachConfigRule, operationalFlows);
						}
					} else {
						log.debug("No Operational flows found of the config flow with id {} ", eachConfigRule, operationalFlows);
						return false;
					}
				}
			} else {
				log.error("Failed to match the config flows with operational flows {}", flowVerificationDetails.getConfigurationObjects().size(), flowVerificationDetails.getOperationalObjects().size());
				return false;
			}
		}
		return true;
	}

	/**
	 * This method is used to build map between Ingress port and FlowRule
	 *
	 * @param flowObj
	 * @param objectType
	 * @throws JSONException
	 */
    private void buildKeyAndBscFlowObject(JSONObject flowObj, FlowVerificationDetails.ObjectType objectType) throws JSONException{
        //TODO: check for controller out port , if yes donot add the flow
        FlowRule flowRule = new FlowRule();
        //only if out port is populated , else it is a controller flows
		parseMatchData(flowObj,flowRule);
		String key=flowRule.getInPort();//+"_"+flowRule.getOutPort();
		if(objectType == FlowVerificationDetails.ObjectType.CONFIG){
			flowVerificationDetails.addConfigurationObject(key,flowRule);
		}else{
			flowVerificationDetails.addOperationalObject(key,flowRule);
		}
    }

	/**
	 * This method is used to parse the flow data which is matching
	 *
	 * @param flowNode
	 * @param flowRule
	 * @throws JSONException
	 */
    @VisibleForTesting
	void parseMatchData(JSONObject flowNode, FlowRule flowRule) throws JSONException {
        flowRule.setPriority(getNodeData("priority",flowNode));
		if (flowNode.has("match")) {
			JSONObject matchNode = (JSONObject) flowNode.get("match");

            flowRule.setDestinationIp4(getNodeData("ipv4-destination",matchNode));
            flowRule.setSourceIp4(getNodeData("ipv4-source",matchNode));
            flowRule.setDestinationIp6(getNodeData("ipv6-destination",matchNode));
            flowRule.setSourceIp6(getNodeData("ipv6-source",matchNode));

            if(matchNode.has("ethernet-match")){
                JSONObject ethernetMatch = (JSONObject) matchNode.get("ethernet-match");
                if(ethernetMatch.has("ethernet-type")){
                    JSONObject ethernetType = (JSONObject) ethernetMatch.get("ethernet-type");
                    if(ethernetType.has("type")){
                        flowRule.setEthType(getNodeData("type",ethernetType));
                    }
                }
                if(ethernetMatch.has("ethernet-source")){
                    JSONObject ethernetSource = (JSONObject) ethernetMatch.get("ethernet-source");
                    flowRule.setSourceMac(getNodeData("address",ethernetSource));
                    flowRule.setSourceMacMask(getNodeData("mask",ethernetSource));
                }
                if(ethernetMatch.has("ethernet-destination")){
                    JSONObject ethernetDest = (JSONObject) ethernetMatch.get("ethernet-destination");
                    flowRule.setDestinationMac(getNodeData("address",ethernetDest));
                    flowRule.setDestinationMacMask(getNodeData("mask",ethernetDest));
                }
            }

            if(matchNode.has("vlan-match")){
                JSONObject vlanMatch = (JSONObject) matchNode.get("vlan-match");
                if(vlanMatch.has("vlan-id")){
                    JSONObject vlanId = (JSONObject) vlanMatch.get("vlan-id");
                    flowRule.setVlanId(getNodeData("vlan-id",vlanId));
                }
            }
            flowRule.setInPort(getNodeData("in-port",matchNode));
            flowRule.setProtocol(getNodeData("ip-protocol",matchNode));
		}
	}

	/**
	 * This method is used get the node data based given JSON key
	 *
	 * @param key
	 * @param nodeObject
	 * @return
	 * @throws JSONException
	 */
    private String getNodeData(String key, JSONObject nodeObject) throws JSONException{
        String returnData = null;
        if(nodeObject.has(key)){
            Object tempReturnData  = nodeObject.get(key);
            returnData = tempReturnData.toString();
        }
        return returnData;
    }

	/**
	 * This method validates if given operational flow id is valid
	 *
	 * @param str
	 * @return
	 */
    public static boolean isNotValidOperationFlowId(String str) {
        //check if it is number
        try {
            Integer.parseInt(str);
            return false;
        } catch (NumberFormatException nfe) {}
        return true;
    }

	/**
	 * This method is used to get the Flow information from CONFIG url for verification
	 */
	protected void getOperationalFlowInfoForVerification(List<String> flowIds) {
		String deviceId = flowVerificationDetails.getDeviceId();
		try {
			Response operationalResponse = bscConnection.get(MediaType.APPLICATION_JSON_TYPE, operationUrl, resourceUrl, deviceId);
			log.info("response : ", operationalResponse);
			String xmlString = operationalResponse.readEntity(String.class);
			try {
				JSONObject completeResponse = new JSONObject(xmlString);
				if (completeResponse.has("node")) {
					JSONArray nodeArray = (JSONArray) completeResponse.get("node");
					if (nodeArray.length() > 0) {
						JSONObject realNode = (JSONObject) nodeArray.get(0);
						if (realNode.has("flow-node-inventory:table")) {
							JSONArray tableNode = (JSONArray) realNode.get("flow-node-inventory:table");
							if (tableNode.length() > 0) {
								JSONObject table = (JSONObject) tableNode.get(0);
								if (table.has("flow")) {
									JSONArray flows = (JSONArray) table.get("flow");
									for (int i = 0; i < flows.length(); i++) {
										JSONObject flowNode = flows.getJSONObject(i);
										if (flowNode.has("id")) {
											//check if valid number
											String flowId = flowNode.get("id").toString();
											if (flowIds.contains(flowId)) {
												log.debug("Operational flowId :{}", flowId);
												buildKeyAndBscFlowObject(flowNode, FlowVerificationDetails.ObjectType.OPERATIONAL);
											}
										}
									}
								}
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error("Failed to build Operational FlowInfo", e);
				throw new OutboundApiException(e.getMessage());
			}
		} catch (OutboundConnectionException e) {
			if (e.getMessage().contains("404")) {
				log.info("Received a 404 as this could be the first call on the device:{}", e.getMessage());
				//TODO: As we are querying on Operational and got 404 which means Device got detached we should not allow to go further.
			} else {
				throw e;
			}
		}
	}

	/**
	 * This method is used to get the Flow information from CONFIG url for verification
	 */
    protected void getConfigFlowInfoForVerification(List<String> flowIds) {
		String deviceId = flowVerificationDetails.getDeviceId();
		try {
			Response res = bscConnection.get(MediaType.APPLICATION_JSON_TYPE, configUrl, resourceUrl, deviceId);
			log.info("response : ", res);
			String xmlString = res.readEntity(String.class);
			try {
				JSONObject completeResponse = new JSONObject(xmlString);
				if (completeResponse.has("node")) {
					JSONArray nodeArray = (JSONArray) completeResponse.get("node");
					if (nodeArray.length() > 0) {
						JSONObject realNode = (JSONObject) nodeArray.get(0);
						if (realNode.has("flow-node-inventory:table")) {
							JSONArray tableNode = (JSONArray) realNode.get("flow-node-inventory:table");
							if (tableNode.length() > 0) {
								JSONObject table = (JSONObject) tableNode.get(0);
								if (table.has("flow")) {
									JSONArray flows = (JSONArray) table.get("flow");
									for (int i = 0; i < flows.length(); i++) {
										JSONObject flowNode = flows.getJSONObject(i);
										if (flowNode.has("flow-name") && flowNode.has("id")) {
											String flowId = flowNode.get("id").toString();
											if (flowIds.contains(flowId)) {
												log.info("Adding config object to bucket:{}", flowNode.get("id"));
												buildKeyAndBscFlowObject(flowNode, FlowVerificationDetails.ObjectType.CONFIG);
											}
										}
									}
								}
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error("Failed to build FlowInfo", e);
				throw new OutboundApiException(e.getMessage());
			}
		} catch (OutboundConnectionException e) {
			if (e.getMessage().contains("404")) {
				log.info("Received a 404 as this could be the first call on the device:{}", e.getMessage());
				//TODO: Expected scenario as we are loading the flows from Config datastore.
			} else {
				throw e;
			}
		}
	}

	@VisibleForTesting
	boolean parseInstructionData(JSONObject flowObj, FlowRule flowRule) throws JSONException {
		//output port is missing in case of drop action in config and in operational no action is present
		//indentify only controller flows and say true if it is controller
		if (flowObj.has("instructions")) {
			JSONObject instructions = (JSONObject) flowObj.get("instructions");
			JSONObject firstInstruction = (JSONObject) ((JSONArray) instructions.get("instruction")).get(0);
			JSONObject applyActions = (JSONObject) firstInstruction.get("apply-actions");
			if (applyActions.has("action")) {
				JSONArray actions = (JSONArray) applyActions.get("action");
				for (int i = 0; i < actions.length(); i++) {
					JSONObject action = (JSONObject) actions.get(i);
					if (action.has("output-action")) {
						JSONObject outputNode = (JSONObject) action.get("output-action");
						String outPort = (String) outputNode.get("output-node-connector");
						if ("CONTROLLER".equalsIgnoreCase(outPort)) {
							log.debug("adding the flow to the list: {}", outPort);
							return false;
						} else {
							//flowRule.setOutPort(outPort);
							return true;
						}
					} else if (action.has("drop-action")) {
						//flowRule.setOutPort("drop");
						return true;
					}
				}
			}
			return true;
		}
		log.debug("Not adding the flow to the list: {}", flowObj.get("id"));
		return false;
	}

	/**
	 * This method is used to break continuous flow addition on device
	 * After each 1K flow it break time will be 5 sec
	 */
    public void waitForFlowToPushOnDevice(){
		try {
			TimeUnit.SECONDS.sleep(retrySleepSeconds);
		} catch (InterruptedException e1) {
			throw new ServerException(e1);
		}
	}

	/**
	 * This method used to get existing group-name to group-id map from the config URL
	 *
	 * @param deviceId
	 * @return Map<String, String> This returns map of group-name to group-id
	 */
	protected Map<String, String> getGroupNameIdMap(String deviceId) {
		Map<String, String> groupNameIdMap = new HashMap<>();
		Response res = bscConnection.get(configUrl, resourceNodesUrl + resourceNodeUrl, deviceId);
		log.info("Get Group Name-ID Map : "+res);
		if (res != null && res.getStatus() == 200) {
			String xmlString = res.readEntity(String.class);
			JSONObject xmlJSONObj;
			try {
				xmlJSONObj = XML.toJSONObject(xmlString); // To Optimize
				String removeKey = "xmlns";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:x";
				removeJSONField(xmlJSONObj, removeKey);
				removeKey = "xmlns:s";
				removeJSONField(xmlJSONObj, removeKey);
				JSONObject realNode = (JSONObject) xmlJSONObj.get("node");
				if (realNode.has("group")) {
					Object groupObj = realNode.get("group");
					if (groupObj instanceof JSONObject) {// single group
						JSONObject groupNode = (JSONObject) groupObj;
						if (groupNode.has("group-name") && groupNode.has("group-id")) {
							groupNameIdMap.put(groupNode.get("group-name").toString(), groupNode.get("group-id").toString());
						}
					} else if (groupObj instanceof JSONArray) {
						JSONArray groupNodes = (JSONArray) groupObj;
						int size = groupNodes.length();
						for (int i = 0; i < size; i++) {
							JSONObject groupNode = groupNodes.getJSONObject(i);
							if (groupNode.has("group-name") && groupNode.has("group-id")) {
								groupNameIdMap.put(groupNode.get("group-name").toString(), groupNode.get("group-id").toString());
							}
						}
					}
				}
			} catch (JSONException e) {
				log.error(e.getMessage());
				return null;
			}
		} else if (res != null && res.getStatus() == 404) {
			//TODO: Expected scenario as we are loading the groups from Config datastore.
			log.info("Expected 404 response on the first call of a device");
		} else {
			return null;
		}
		return groupNameIdMap;
	}
}
