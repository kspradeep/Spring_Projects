package com.brocade.bvm.outbound.sessiondirector;

import com.brocade.bvm.outbound.AbstractRestConnection;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import javax.inject.Named;
import javax.ws.rs.client.Client;

@Named
public class SessionDirectorConnection extends AbstractRestConnection {
	
	private Client client;

	protected static final String URL = "http://%s:8080/session_director";
	protected static String baseUrl;

	public void setBaseUrl(String ip) {
		baseUrl = String.format(URL, ip);
	}

    public Client getClient() {
        return new JerseyClientBuilder()
                .sslContext(sslContext())
                .hostnameVerifier(hostnameVerifier()).build().register(HttpAuthenticationFeature.basic("root", "password"));
    }

	@Override
	protected String getBaseUrl() {
		return baseUrl;
	}
}
