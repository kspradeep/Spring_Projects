package com.brocade.bvm.outbound.stablenet.job;

import java.util.List;

import javax.inject.Named;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

/**
 * The StablenetPortGroupCreateJobExecutor class implements methods to create portGroup on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetPortGroupCreateJobExecutor extends AbstractStablenetPortGroupJobExecutor {

	@Override
	public List<Type> getSupportedJobTypes() {
		return Lists.newArrayList(Type.PORT_GROUP_CREATE);
	}

	/**
	 * This method constructs portGroup create commands to be executed on the given device
	 *
	 * @param job
	 * @return String This returns command string
	 */
	@Override
	public String getCommands(Job job) {
	    PortGroup portGroup = (PortGroup)getParentObject(job);
		log.trace("Port Group Creation Input Object: {}", portGroup);
		StringBuilder cmd = new StringBuilder();
		if (portGroup != null) {
			cmd.append(CONFIGURE_TERMINAL);
			cmd.append(buildCreateCommand(portGroup));
			cmd.append(buildMapPortToGtpProfile(portGroup));
			cmd.append(buildVlanCommandForModifiedPorts(portGroup, portGroup.getPrimaryPort().getPortNumber(), true));
			cmd.append(END);
			cmd.append(WRITE_MEMORY);
		} else {
			log.error("Port Group input object is null.");
		}
		log.debug("Port Group Creation CMD: {}", cmd);
		return cmd.toString();
	}

}
