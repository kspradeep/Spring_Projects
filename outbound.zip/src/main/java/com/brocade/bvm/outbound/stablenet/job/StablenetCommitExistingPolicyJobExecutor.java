package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.RuleSetRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.outbound.stablenet.commands.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * The StablenetCommitExistingPolicyJobExecutor class implements methods used in UPDATE policy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetCommitExistingPolicyJobExecutor extends StablenetCommitPolicyJobExecutor {

    @Inject
    private StablenetPolicyComparator stablenetPolicyComparator;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Type.POLICY_UPDATE);
    }

    /**
     * This method builds policy UPDATE commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        Policy policyToSave = (Policy) getParentObject(job);
        Policy oldPolicy = getPolicyHistoryForDiff(policyToSave);
        String command = buildUpdatePolicyCommand(oldPolicy, policyToSave);
        command = START_CONFIG_TERMINAL.concat(command.replace(START_CONFIG_TERMINAL, "").replace(END, "")).concat(WRITE_MEMORY).concat(END);
        log.info("Stablenet command generated from Job Id{} on device{} for policy id {} is {}", job.getId(), job.getDevice().getId(), policyToSave.getId(), command);
        return command;
    }

    /**
     * This method is used to build the Policy update commands
     *
     * @param oldPolicy
     * @param newPolicy
     * @return
     */
    private String buildUpdatePolicyCommand(Policy oldPolicy, Policy newPolicy) {
        StringBuilder command = new StringBuilder();
        StablenetPolicyDiff stablenetPolicyDiff = stablenetPolicyComparator.comparePolicy(oldPolicy, newPolicy);

        Integer reservedVlan = 0;
        if (oldPolicy.isPreserveHeader() || newPolicy.isPreserveHeader()) {
            reservedVlan = getReservedVlan(oldPolicy.getDevice().getId());
        }
        Device device = newPolicy.getDevice();
        command.append(buildUnMapIngressCommand(oldPolicy, newPolicy, stablenetPolicyDiff));
        command.append(buildUpdateFlowCommand(stablenetPolicyDiff, reservedVlan, device.getId(), newPolicy.getId(), newPolicy.isLegacy()));
        command.append(buildUpdateVlanCommand(oldPolicy, stablenetPolicyDiff,device.getId()));
        command.append(buildUpdateTvfCommand(stablenetPolicyDiff,device.getId()));
        command.append(buildUpdateReservedVlanCommand(oldPolicy, newPolicy, reservedVlan));
        command.append(buildRuleUpdateCommand(stablenetPolicyDiff, newPolicy));
        command.append(buildMapIngressCommand(oldPolicy, newPolicy, stablenetPolicyDiff));
        command.append(buildUpdateFlowName(newPolicy, oldPolicy));
        command.append(buildUpdateSetInterfaceNull0(newPolicy, oldPolicy));
        return command.toString();
    }

    /**
     * To add set interface null0 if not present, if the field is exposed to user need to take care upgrade case
     *
     * @param newPolicy
     * @return
     */
    private String buildUpdateSetInterfaceNull0(Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        if (oldPolicy != null && oldPolicy.getFlows() != null && newPolicy != null && newPolicy.getFlows() != null) {
            newPolicy.getFlows().stream().forEach(flow -> {
                Flow oldFlow = oldPolicy.getFlows().stream().filter(flowOld -> flow.getId() != null && flowOld.getId() != null && flow.getId().longValue() == flowOld.getId().longValue()).findAny().orElse(null);
                if (oldFlow != null && oldFlow.getIsDefaultRouteMapDrop() != null && !oldFlow.getIsDefaultRouteMapDrop()) {
                    command.append(String.format(POLICY_HEADER_FORMAT, newPolicy.getComputedName(), CMD_PERMIT, flow.getSequence()));
                    command.append(SET_INTERFACE_NULL0);
                    command.append(EXIT);
                }
            });
        }

        return command.toString();
    }

    private String buildUpdateFlowName(Policy newPolicy, Policy oldPolicy) {
        StringBuilder command = new StringBuilder();
        for (Flow flow : newPolicy.getFlows()) {
            List<String> oldFlowNames = oldPolicy.getFlows().stream().filter(oldFlow -> (oldFlow.getId() != null && (oldFlow.getId().longValue() == flow.getId().longValue()))).map(oldFlow -> oldFlow.getFlowName()).collect(Collectors.toList());
            String oldFlowName = oldFlowNames != null && !oldFlowNames.isEmpty() && oldFlowNames.get(0) != null ? oldFlowNames.get(0) : null;
            if ((oldFlowName != null && !oldFlowName.equals(flow.getFlowName()) || (flow.getFlowName() != null && !flow.getFlowName().equals(oldFlowName)))) {
                command.append(String.format(POLICY_HEADER_FORMAT, newPolicy.getComputedName(), CMD_PERMIT, flow.getSequence()));
                if (!Strings.isNullOrEmpty(oldFlowName)) {
                    command.append(String.format(NO_FLOW_NAME_FORMAT, oldFlowName));
                }
                if (!Strings.isNullOrEmpty(flow.getFlowName())) {
                    command.append(String.format(FLOW_NAME_FORMAT, flow.getFlowName()));
                }
                command.append(EXIT);
            }
        }
        return command.toString();
    }

    /**
     * This method is used to build ingress UNMAP commands based on the policyDiff
     *
     * @param oldPolicy
     * @param newPolicy
     * @param stablenetPolicyDiff
     * @return
     */
    private String buildUnMapIngressCommand(Policy oldPolicy, Policy newPolicy, StablenetPolicyDiff stablenetPolicyDiff) {
        StringBuilder command = new StringBuilder();

        StringBuilder gtpCmdBuilder = new StringBuilder();
        GTPDevicePolicy gtpProfile = oldPolicy.getGtpProfile();
        if (stablenetPolicyDiff.getDeletedIngressPorts() != null && !stablenetPolicyDiff.getDeletedIngressPorts().isEmpty() && gtpProfile != null) {
            gtpCmdBuilder.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
        }

        String oldPolicyName = stablenetPolicyDiff.getRouteMapName();
        final Set<RuleSet.Type> deletedRuleSetTypeList = Sets.newHashSet();
        deletedRuleSetTypeList.addAll(stablenetPolicyDiff.getDeletedRuleSetTypeList());
        final Set<RuleSet.IpVersion> deletedRuleSetIpList = Sets.newHashSet();
        deletedRuleSetIpList.addAll(stablenetPolicyDiff.getDeletedRuleSetIpList());

        final Set<RuleSet.Type> updatedRuleSetTypeList = Sets.newHashSet();
        updatedRuleSetTypeList.addAll(stablenetPolicyDiff.getUpdatedRuleSetTypeList());
        final Set<RuleSet.IpVersion> updatedRuleSetIpList = Sets.newHashSet();
        updatedRuleSetIpList.addAll(stablenetPolicyDiff.getUpdatedRuleSetIpList());

        // If old preserve header is enabled, need to unmap IPv4/IPv6 route-map acl from intermediate port
        if (stablenetPolicyDiff.isOldPreserveHeader()) {
            HeaderStrippingModulePolicy headerStrippingModulePolicy = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(oldPolicy.getDevice().getId()).stream().findFirst().get();
            // validate if multiple policies created for Preserve Header, then do not unmap loopback
            List<Long> preserveHeaderPolicies = policyRepository.findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(oldPolicy.getDevice().getId(), true, oldPolicy.getId());
            boolean isLoopBackEnabled = true;
            if (!preserveHeaderPolicies.isEmpty()) {
                isLoopBackEnabled = false;
            }
            if (!deletedRuleSetIpList.isEmpty()) {
                command.append(String.format(POLICYSET_REVERT_INTERMEDIATE_PORT_RECORD_FORMAT, getIntermediatePortNumber(headerStrippingModulePolicy.getIntermediatePortId()), getReverseACLFormatForPolicy(stablenetPolicyDiff.getRouteMapName(), Sets.newHashSet(), deletedRuleSetIpList, oldPolicy, (!isLoopBackEnabled && !updatedRuleSetIpList.isEmpty()) ? false : true), !updatedRuleSetIpList.isEmpty() ? "" : POLICYSET_REVERT_PBR_FORMAT));
            }
            if (headerStrippingModulePolicy != null && headerStrippingModulePolicy.getStripHeaders() != null && !headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
                oldPolicyName = getRmOrL2AclName(headerStrippingModulePolicy.getStripHeaders().stream().findFirst().get());
            }
            // to unmap from deleted ingress ports
            deletedRuleSetIpList.clear();
            deletedRuleSetTypeList.clear();
            deletedRuleSetTypeList.add(RuleSet.Type.L2);

            updatedRuleSetIpList.clear();
            updatedRuleSetTypeList.clear();
        }

        StringBuilder gtpPortUnMapCmd = new StringBuilder();

        // Unmapping removed ingress ports
        for (Port port : stablenetPolicyDiff.getDeletedIngressPorts()) {
            command.append(String.format(POLICYSET_REVERT_INGRESS_UPDATE_FORMAT, port.getPortNumber(), getReverseACLFormatForPolicy(oldPolicyName, deletedRuleSetTypeList, deletedRuleSetIpList, oldPolicy, oldPolicy.isLoopbackEnabled()), getReverseACLFormat(oldPolicyName, updatedRuleSetTypeList, updatedRuleSetIpList, oldPolicy)));
            if (gtpProfile != null) {
                List<Long> portGroupIds = portGroupRepository.findByPrimaryPortAndGTPProfile(oldPolicy.getDevice().getId(), port.getId(), gtpProfile.getId());
                if (portGroupIds.isEmpty()) {
                    gtpPortUnMapCmd.append(String.format(POLICYSET_GTP_INGRESS_UNMAP_FORMAT, port.getPortNumber()));
                }
            }
        }

        if (gtpPortUnMapCmd.length() > 0) {
            gtpCmdBuilder.append(gtpPortUnMapCmd.toString());
        }

        if (stablenetPolicyDiff.getDeletedIngressPorts() != null && !stablenetPolicyDiff.getDeletedIngressPorts().isEmpty() && gtpProfile != null) {
            gtpCmdBuilder.append(EXIT);
        }

        command.append((gtpPortUnMapCmd.length() > 0 && gtpCmdBuilder.length() > 0) ? gtpCmdBuilder.toString() : "");

        StringBuilder gtpUpdateCmd = new StringBuilder();
        if (stablenetPolicyDiff.getUnchangedIngressPorts() != null && !stablenetPolicyDiff.getUnchangedIngressPorts().isEmpty() && gtpProfile != null && (stablenetPolicyDiff.getGtpFlag().equals("deleted") || stablenetPolicyDiff.getGtpFlag().equals("updated"))) {
            gtpUpdateCmd.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
        }

        StringBuilder gtpPortCmd = new StringBuilder();

        if (stablenetPolicyDiff.isOldPreserveHeader()) {
            updatedRuleSetTypeList.add(RuleSet.Type.L2);
        }

        if (stablenetPolicyDiff.isOldPreserveHeader()) {
            deletedRuleSetTypeList.clear();
        }

        // Unmapping deleted rulesets from Unchanged ingress ports
        stablenetPolicyDiff.getUnchangedIngressPorts().forEach(port -> {
            StringBuilder stringBuilder = new StringBuilder();
            if (deletedRuleSetTypeList.size() > 0 || deletedRuleSetIpList.size() > 0) {
                stringBuilder.append(getReverseACLFormatForPolicy(stablenetPolicyDiff.getRouteMapName(), deletedRuleSetTypeList, deletedRuleSetIpList, oldPolicy, oldPolicy.isLoopbackEnabled()));
            }
            if (!stablenetPolicyDiff.getDeletedSeqs().isEmpty() && !stablenetPolicyDiff.getAddedSeqs().isEmpty() && (!updatedRuleSetTypeList.isEmpty() || !updatedRuleSetIpList.isEmpty())) {
                stringBuilder.append(getReverseACLFormatForPolicy(stablenetPolicyDiff.getRouteMapName(), updatedRuleSetTypeList, updatedRuleSetIpList, oldPolicy, oldPolicy.isLoopbackEnabled()));
            } else if (stablenetPolicyDiff.isRulesUpdatedForPolicy() && (!stablenetPolicyDiff.getRuleSetsTypeToUnmap().isEmpty() || !stablenetPolicyDiff.getRuleSetsIpVersionToUnmap().isEmpty())) {
                stringBuilder.append(getReverseACLFormatForPolicy(stablenetPolicyDiff.getRouteMapName(), stablenetPolicyDiff.getRuleSetsTypeToUnmap(), stablenetPolicyDiff.getRuleSetsIpVersionToUnmap(), oldPolicy, oldPolicy.isLoopbackEnabled()));
            } else if (stablenetPolicyDiff.isRulesUpdatedForPolicy() && (!updatedRuleSetTypeList.isEmpty() || !updatedRuleSetIpList.isEmpty())) {
                stringBuilder.append(getReverseACLFormatForPolicy(stablenetPolicyDiff.getRouteMapName(), updatedRuleSetTypeList, updatedRuleSetIpList, oldPolicy, oldPolicy.isLoopbackEnabled()));
            } else if (oldPolicy.isLoopbackEnabled() && !newPolicy.isLoopbackEnabled()) {
                stringBuilder.append(POLICYSET_INGRESS_GTP_UNMAP_FORMAT);
            }

            command.append(stringBuilder.toString().trim().length() > 0 ? String.format(POLICYSET_INGRESS_UPDATE_FORMAT, port.getPortNumber(), stringBuilder.toString()) : "");
            if ((stablenetPolicyDiff.getGtpFlag().equals("deleted") || stablenetPolicyDiff.getGtpFlag().equals("updated")) && gtpProfile != null) {
                List<Long> portGroupIds = portGroupRepository.findByPrimaryPortAndGTPProfile(port.getModule().getDevice().getId(), port.getId(), gtpProfile.getId());
                if (portGroupIds.isEmpty()) {
                    gtpPortCmd.append(String.format(POLICYSET_GTP_INGRESS_UNMAP_FORMAT, port.getPortNumber()));
                }
            }
        });

        if (gtpPortCmd.length() > 0) {
            gtpUpdateCmd.append(gtpPortCmd.toString());
        }

        if (stablenetPolicyDiff.getUnchangedIngressPorts() != null && !stablenetPolicyDiff.getUnchangedIngressPorts().isEmpty() && ((stablenetPolicyDiff.getGtpFlag().equals("deleted") || stablenetPolicyDiff.getGtpFlag().equals("updated")) && gtpProfile != null)) {
            gtpUpdateCmd.append(EXIT);
        }
        command.append((gtpPortCmd.length() > 0 && gtpUpdateCmd.length() > 0) ? gtpUpdateCmd.toString() : "");
        return command.toString();
    }

    /**
     * This method is used to build ingress MAP commands based on the policyDiff
     *
     * @param oldPolicy
     * @param newPolicy
     * @param stablenetPolicyDiff
     * @return
     */
    private String buildMapIngressCommand(Policy oldPolicy, Policy newPolicy, StablenetPolicyDiff stablenetPolicyDiff) {
        StringBuilder command = new StringBuilder();

        StringBuilder gtpUpdateCmd = new StringBuilder();
        GTPDevicePolicy gtpProfile = newPolicy.getGtpProfile();
        if (gtpProfile != null && stablenetPolicyDiff.getUnchangedIngressPorts() != null && !stablenetPolicyDiff.getUnchangedIngressPorts().isEmpty() &&
                (stablenetPolicyDiff.getGtpFlag().equals("added") || stablenetPolicyDiff.getGtpFlag().equals("updated"))) {
            gtpUpdateCmd.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
        }

        String newPolicyName = stablenetPolicyDiff.getRouteMapName();
        final Set<RuleSet.Type> addedRuleSetTypeList = Sets.newHashSet();
        addedRuleSetTypeList.addAll(stablenetPolicyDiff.getAddedRuleSetTypeList());
        final Set<RuleSet.IpVersion> addedRuleSetIpList = Sets.newHashSet();
        addedRuleSetIpList.addAll(stablenetPolicyDiff.getAddedRuleSetIpList());

        final Set<RuleSet.Type> updatedRuleSetTypeList = Sets.newHashSet();
        updatedRuleSetTypeList.addAll(stablenetPolicyDiff.getUpdatedRuleSetTypeList());
        final Set<RuleSet.IpVersion> updatedRuleSetIpList = Sets.newHashSet();
        updatedRuleSetIpList.addAll(stablenetPolicyDiff.getUpdatedRuleSetIpList());

        // If new preserve header is enabled, need to map IPv4/IPv6 route-map acl to intermediate port
        if (stablenetPolicyDiff.isNewPreserveHeader()) {
            HeaderStrippingModulePolicy headerStrippingModulePolicy = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(oldPolicy.getDevice().getId()).stream().findFirst().get();
            // validate if multiple policies created for Preserve Header, then do not unmap loopback
            List<Long> preserveHeaderPolicies = policyRepository.findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(oldPolicy.getDevice().getId(), true, oldPolicy.getId());
            boolean isLoopBackEnabled = true;
            if (!preserveHeaderPolicies.isEmpty()) {
                isLoopBackEnabled = false;
            }
            if (!addedRuleSetIpList.isEmpty()) {
                command.append(String.format(POLICYSET_INGRESS_ADD_FORMAT, getIntermediatePortNumber(headerStrippingModulePolicy.getIntermediatePortId()), getACLFormatForPolicy(newPolicyName, Sets.newHashSet(), addedRuleSetIpList, oldPolicy, isLoopBackEnabled),
                        !stablenetPolicyDiff.isOldPreserveHeader() ? getACLFormat(stablenetPolicyDiff.getRouteMapName(), Sets.newHashSet(), updatedRuleSetIpList, oldPolicy) : ""));
            }

            if (headerStrippingModulePolicy != null && headerStrippingModulePolicy.getStripHeaders() != null && !headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
                newPolicyName = getRmOrL2AclName(headerStrippingModulePolicy.getStripHeaders().stream().findFirst().get());
            }

            // to map to added ingress ports
            addedRuleSetIpList.clear();
            addedRuleSetTypeList.clear();

            updatedRuleSetIpList.clear();
            updatedRuleSetTypeList.clear();
            updatedRuleSetTypeList.add(RuleSet.Type.L2);
        }

        // Mapping added rulesets to unchanged ingress ports
        for (Port port : stablenetPolicyDiff.getUnchangedIngressPorts()) {
            StringBuilder stringBuilder = new StringBuilder();
            if (addedRuleSetTypeList.size() > 0 || addedRuleSetIpList.size() > 0) {
                stringBuilder.append(getACLFormatForPolicy(newPolicyName, addedRuleSetTypeList, addedRuleSetIpList, newPolicy, newPolicy.isLoopbackEnabled()));
            }
            if (!stablenetPolicyDiff.getDeletedSeqs().isEmpty() && !stablenetPolicyDiff.getAddedSeqs().isEmpty() && (!updatedRuleSetTypeList.isEmpty() || !updatedRuleSetIpList.isEmpty())) {
                stringBuilder.append(getACLFormatForPolicy(newPolicyName, updatedRuleSetTypeList, updatedRuleSetIpList, newPolicy, newPolicy.isLoopbackEnabled()));
            } else if (stablenetPolicyDiff.isRulesUpdatedForPolicy() && (!stablenetPolicyDiff.getRuleSetsTypeToUnmap().isEmpty() || !stablenetPolicyDiff.getRuleSetsIpVersionToUnmap().isEmpty())) {
                stringBuilder.append(getACLFormatForPolicy(newPolicyName, stablenetPolicyDiff.getRuleSetsTypeToUnmap(), stablenetPolicyDiff.getRuleSetsIpVersionToUnmap(), newPolicy, newPolicy.isLoopbackEnabled()));
            } else if (stablenetPolicyDiff.isRulesUpdatedForPolicy() && (!updatedRuleSetTypeList.isEmpty() || !updatedRuleSetIpList.isEmpty())) {
                stringBuilder.append(getACLFormatForPolicy(newPolicyName, updatedRuleSetTypeList, updatedRuleSetIpList, newPolicy, newPolicy.isLoopbackEnabled()));
            } else if (!oldPolicy.isLoopbackEnabled() && newPolicy.isLoopbackEnabled()) {
                stringBuilder.append(POLICYSET_INGRESS_GTP_MAP_FORMAT);
            }
            command.append(stringBuilder.toString().trim().length() > 0 ? String.format(POLICYSET_INGRESS_UPDATE_FORMAT, port.getPortNumber(), stringBuilder.toString()) : "");
            if ((stablenetPolicyDiff.getGtpFlag().equals("added") || stablenetPolicyDiff.getGtpFlag().equals("updated")) && gtpProfile != null) {
                List<Long> portGroupIds = portGroupRepository.findByPrimaryPortAndGTPProfile(port.getModule().getDevice().getId(), port.getId(), gtpProfile.getId());
                if (portGroupIds.isEmpty()) {
                    gtpUpdateCmd.append(String.format(POLICYSET_GTP_INGRESS_MAP_FORMAT, port.getPortNumber()));
                }
            }
        }

        if (stablenetPolicyDiff.getUnchangedIngressPorts() != null && !stablenetPolicyDiff.getUnchangedIngressPorts().isEmpty() && (stablenetPolicyDiff.getGtpFlag().equals("added") || stablenetPolicyDiff.getGtpFlag().equals("updated"))) {
            gtpUpdateCmd.append(EXIT);
        }
        command.append((gtpUpdateCmd.length() > 0) ? gtpUpdateCmd.toString() : "");

        StringBuilder gtpCmdBuilder = new StringBuilder();
        if (stablenetPolicyDiff.getAddedIngressPorts() != null && !stablenetPolicyDiff.getAddedIngressPorts().isEmpty() && gtpProfile != null) {
            gtpCmdBuilder.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
        }

        StringBuilder gtpMapCmd = new StringBuilder();

        // Mapping added/unchanged rulesets to newly added ingress ports
        for (Port port : stablenetPolicyDiff.getAddedIngressPorts()) {
            command.append(String.format(POLICYSET_INGRESS_ADD_FORMAT, port.getPortNumber(), getACLFormatForPolicy(newPolicyName, addedRuleSetTypeList, addedRuleSetIpList, newPolicy, newPolicy.isLoopbackEnabled()), getACLFormat(newPolicyName, updatedRuleSetTypeList, updatedRuleSetIpList, newPolicy)));
            if (gtpProfile != null) {
                List<Long> portGroupIds = portGroupRepository.findByPrimaryPortAndGTPProfile(port.getModule().getDevice().getId(), port.getId(), gtpProfile.getId());
                if (portGroupIds.isEmpty()) {
                    gtpMapCmd.append(String.format(POLICYSET_GTP_INGRESS_MAP_FORMAT, port.getPortNumber()));
                }
            }
        }

        if (gtpMapCmd.length() > 0) {
            gtpCmdBuilder.append(gtpMapCmd.toString());
        }

        if (stablenetPolicyDiff.getAddedIngressPorts() != null && !stablenetPolicyDiff.getAddedIngressPorts().isEmpty() && gtpProfile != null) {
            gtpCmdBuilder.append(EXIT);
        }
        command.append((gtpMapCmd.length() > 0 && gtpCmdBuilder.length() > 0) ? gtpCmdBuilder.toString() : "");
        return command.toString();
    }

    /**
     * This method is used to build UPDATE UDA offset commands
     *
     * @param policy
     * @return
     */
    private String buildUpdateUdaOffSetCommand(Policy policy) {
        String fieldOffset1 = String.valueOf(policy.getFieldOffset1());
        String fieldOffset2 = String.valueOf(policy.getFieldOffset2());
        String fieldOffset3 = String.valueOf(policy.getFieldOffset3());
        String fieldOffset4 = String.valueOf(policy.getFieldOffset4());
        if ("-1".equals(fieldOffset1)) {
            fieldOffset1 = "ignore";
        }
        if ("-1".equals(fieldOffset2)) {
            fieldOffset2 = "ignore";
        }
        if ("-1".equals(fieldOffset3)) {
            fieldOffset3 = "ignore";
        }
        if ("-1".equals(fieldOffset4)) {
            fieldOffset4 = "ignore";
        }
        return String.format(POLICYSET_ACL_TYPE_UDA_OFFSET_RECORD_FORMAT, fieldOffset1, fieldOffset2, fieldOffset3, fieldOffset4);
    }

    private String buildUpdateFlowCommand(StablenetPolicyDiff stablenetPolicyDiff, Integer reservedVlan, Long deviceId, Long policyId, boolean isLegacy) {
        StringBuilder command = new StringBuilder();
        List<String> uniqueListOfRulesetNameToBeAdded = new ArrayList<>();
        List<String> uniqueListOfRulesetNameToBeUpdated = new ArrayList<>();
        List<String> uniqueListOfRulesetNameToBeDeleted = new ArrayList<>();
        stablenetPolicyDiff.getFlowMap().forEach((sequence, ruleSetDiff) -> {
            // deleting route-map if sequence is changed
            if (stablenetPolicyDiff.getDeletedSeqs().contains(sequence)) {
                command.append(String.format(POLICY_REVERT_HEADER_FORMAT, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
            } else if ((ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty())
                    || (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty())
                    || (ruleSetDiff.getUpdatedRuleSets() != null && !ruleSetDiff.getUpdatedRuleSets().isEmpty() && !stablenetPolicyDiff.isRulesUpdatedForPolicy())) {
                StringBuilder builder = new StringBuilder();
                if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    // reverting the deleted ruleSets
                    ruleSetDiff.getDeletedRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getType() == RuleSet.Type.L2) {
                            builder.append(String.format(POLICY_RULESET_L2ACL_REVERT_FORMAT, ruleSet.getName()));
                        } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                            builder.append(String.format(POLICY_RULESET_UDAACL_REVERT_FORMAT, ruleSet.getName()));
                        } else {
                            builder.append(String.format(POLICY_RULESET_REVERT_FORMAT, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                        }
                    });
                }
                // tvf/vlan to tvfIds/vlanIds map
                Map<String, Set<String>> vlanTypeToIdMap = Maps.newHashMap();
                if (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty()) {
                    // Adding ruleSet to policy
                    ruleSetDiff.getAddedRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getType() == RuleSet.Type.L2) {
                            builder.append(String.format(POLICY_RULESET_L2ACL_RECORD_FORMAT, ruleSet.getName()));
                        } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                            builder.append(String.format(POLICY_RULESET_UDAACL_RECORD_FORMAT, ruleSet.getName()));
                        } else {
                            builder.append(String.format(POLICY_RULESET_RECORD_FORMAT, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                        }
                        Set<String> vlanIds = Sets.newHashSet();
                        Set<String> tvfIds = Sets.newHashSet();
                        if (vlanTypeToIdMap.containsKey("tvf")) {
                            tvfIds = vlanTypeToIdMap.get("tvf");
                        } else if (vlanTypeToIdMap.containsKey("vlan")) {
                            vlanIds = vlanTypeToIdMap.get("vlan");
                        }

                        if (tvfIds.isEmpty() && ruleSet.getFlow().getTvfDomain()) {
                            tvfIds.addAll(ruleSet.getFlow().getVlans());
                        } else {
                            vlanIds.addAll(ruleSet.getFlow().getVlans());
                        }
                        vlanTypeToIdMap.put("tvf", tvfIds);
                        vlanTypeToIdMap.put("vlan", vlanIds);

                    });
                    /*If same sequence no is deleted in one flow and used in other flow*/
                    if (ruleSetDiff.isSeqChanged()) {
                        if (ruleSetDiff.getAddedTunnels() != null) {
                            ruleSetDiff.getAddedTunnels().forEach(tunnelDevicePolicy -> builder.append(String.format((tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) ? POLICY_MPLS_TUNNEL_RECORD_FORMAT : POLICY_GRE_TUNNEL_RECORD_FORMAT, tunnelDevicePolicy.getName())));
                        }

                        // applying tvf domain command in route-map, if sequence is changed
                        vlanTypeToIdMap.get("tvf").forEach(tvfId -> {
                            if (stablenetPolicyDiff.isNewPreserveHeader()) {
                                builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                            } else {
                                builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                            }
                        });

                        // applying VLAN command in route-map, if sequence is changed
                        vlanTypeToIdMap.get("vlan").forEach(vlan -> {
                            String destMac = ruleSetDiff.getAddedDestinationMac();
                            if (destMac != null && !destMac.isEmpty()) {
                                builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                            } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                                builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                            } else {
                                builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                            }
                        });
                        builder.append(SET_INTERFACE_NULL0);
                    }
                }

                if (ruleSetDiff.getUpdatedRuleSets() != null && !ruleSetDiff.getUpdatedRuleSets().isEmpty() && !stablenetPolicyDiff.isRulesUpdatedForPolicy()) {
                    /*If same sequence no is deleted in one flow and used in other flow*/
                    if (ruleSetDiff.isSeqChanged()) {
                        // Adding ruleSet to policy
                        ruleSetDiff.getUpdatedRuleSets().forEach(ruleSet -> {
                            if (ruleSet.getType() == RuleSet.Type.L2) {
                                builder.append(String.format(POLICY_RULESET_L2ACL_RECORD_FORMAT, ruleSet.getName()));
                            } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                                builder.append(String.format(POLICY_RULESET_UDAACL_RECORD_FORMAT, ruleSet.getName()));
                            } else {
                                builder.append(String.format(POLICY_RULESET_RECORD_FORMAT, ruleSet.getIpVersion().getValue(), ruleSet.getName()));
                            }
                            Set<String> vlanIds = Sets.newHashSet();
                            Set<String> tvfIds = Sets.newHashSet();
                            if (vlanTypeToIdMap.containsKey("tvf")) {
                                tvfIds = vlanTypeToIdMap.get("tvf");
                            } else if (vlanTypeToIdMap.containsKey("vlan")) {
                                vlanIds = vlanTypeToIdMap.get("vlan");
                            }

                            if (tvfIds.isEmpty() && ruleSet.getFlow().getTvfDomain()) {
                                tvfIds.addAll(ruleSet.getFlow().getVlans());
                            } else {
                                vlanIds.addAll(ruleSet.getFlow().getVlans());
                            }
                            vlanTypeToIdMap.put("tvf", tvfIds);
                            vlanTypeToIdMap.put("vlan", vlanIds);
                        });

                        // applying tvf domain command in route-map, if sequence is changed
                        vlanTypeToIdMap.get("tvf").forEach(tvfId -> {
                            if (stablenetPolicyDiff.isNewPreserveHeader()) {
                                builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                            } else {
                                builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                            }
                        });

                        // applying VLAN command in route-map, if sequence is changed
                        vlanTypeToIdMap.get("vlan").forEach(vlan -> {
                            String destMac = ruleSetDiff.getUpdatedDestinationMac();
                            if (destMac != null && !destMac.isEmpty()) {
                                builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                            } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                                builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                            } else {
                                builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                            }
                        });
                        builder.append(SET_INTERFACE_NULL0);
                    }
                }

                // updating vlans and tunnel profiles to route-map
                if (!ruleSetDiff.isSeqChanged()) {
                    buildTunnelAndVlanUpdateCommand(ruleSetDiff, builder, stablenetPolicyDiff, sequence, reservedVlan);
                    if (builder.toString().trim().length() > 0) {
                        builder.append(builder.indexOf(POLICY_ROUTE_MAP_SET_FORMAT) > -1 ? POLICY_INT_REVERT_FORMAT : "");
                    }
                }

                if (builder.toString().trim().length() > 0) {
                    command.append(String.format(POLICY_HEADER_FORMAT, stablenetPolicyDiff.getRouteMapName(), CMD_PERMIT, sequence));
                    command.append(builder.toString());
                    command.append(builder.indexOf(POLICY_INT_FIND_FORMAT) > -1 ? EXIT : POLICY_VLAN_RECORD_FORMAT_TAIL);
                }
            }

            // removing acls for deleted rulesets
            if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                ruleSetDiff.getDeletedRuleSets().forEach(ruleSet -> command.append(buildRevertRuleSetCommand(ruleSet, deviceId, policyId, uniqueListOfRulesetNameToBeDeleted, Type.POLICY_UPDATE)));
            }

            // creating acls for newly added rulesets
            if (ruleSetDiff.getAddedRuleSets() != null && !ruleSetDiff.getAddedRuleSets().isEmpty()) {
                //If in a policy a ruleset is added and aldo updated in other flows the changes will be taken care in update excluding the ruleset for adding
                AtomicBoolean ruleSetWithSameNameFoundForUpdate = new AtomicBoolean(false);
                ruleSetDiff.getAddedRuleSets().forEach(ruleSet -> {
                            if (stablenetPolicyDiff.getFlowMap() != null) {
                                stablenetPolicyDiff.getFlowMap().forEach((sequence1, ruleSetDif) -> {
                                    if (ruleSetDif.getUpdatedRuleSets() != null && !ruleSetDif.getUpdatedRuleSets().isEmpty()) {
                                        RuleSet foundRuleSet = ruleSetDif.getUpdatedRuleSets().stream().filter(ruleSet1 -> ruleSet1.getName().equals(ruleSet.getName())).findAny().orElse(null);
                                        if (foundRuleSet != null) {
                                            ruleSetWithSameNameFoundForUpdate.set(true);
                                        }
                                    }
                                });
                            }
                            if (!ruleSetWithSameNameFoundForUpdate.get()) {
                                command.append(buildRuleSetCommand(ruleSet, deviceId, policyId, uniqueListOfRulesetNameToBeAdded, Type.POLICY_CREATE, isLegacy));
                            }
                        }
                );

            }

            if (ruleSetDiff.isSeqChanged() && ruleSetDiff.getUpdatedRuleSets() != null && !ruleSetDiff.getUpdatedRuleSets().isEmpty()) {
                ruleSetDiff.getUpdatedRuleSets().forEach(ruleSet -> command.append(buildRuleSetCommand(ruleSet, deviceId, policyId, uniqueListOfRulesetNameToBeUpdated, Type.POLICY_UPDATE, isLegacy)));
            }
        });
        return command.toString();
    }

    private void buildTunnelAndVlanUpdateCommand(RuleSetDiff ruleSetDiff, StringBuilder builder, StablenetPolicyDiff stablenetPolicyDiff, Integer sequence, Integer reservedVlan) {

        //handle only deleted
        if (ruleSetDiff.getNewFlowTunnels() == null || ruleSetDiff.getNewFlowTunnels().isEmpty()) {
            ruleSetDiff.getDeletedTunnels().forEach(tunnelDevicePolicy -> builder.append(String.format((tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) ? POLICY_MPLS_TUNNEL_REVERT_FORMAT : POLICY_GRE_TUNNEL_REVERT_FORMAT, tunnelDevicePolicy.getName())));
        }

        // revert set VLAN command in route-map, if VLAN is deleted
        if (!stablenetPolicyDiff.getVlanDiff().getDeletedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getDeletedVlansMap().get(sequence) != null) {
            stablenetPolicyDiff.getVlanDiff().getDeletedVlansMap().get(sequence).forEach(vlan -> {
                if (ruleSetDiff.getFlowVlans() == null || !ruleSetDiff.getFlowVlans().contains(vlan)) {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_REVERT_FORMAT, vlan));
                    }
                }
            });
        }

        // revert set TVF domain command in route-map, if tvfId is deleted
        if (!stablenetPolicyDiff.getTvfDiff().getDeletedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getDeletedTvfsMap().get(sequence) != null) {
            stablenetPolicyDiff.getTvfDiff().getDeletedTvfsMap().get(sequence).forEach(tvfId -> {
                if (ruleSetDiff.getFlowTvfs() == null || !ruleSetDiff.getFlowTvfs().contains(tvfId)) {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_TVF_REVERT_FORMAT, tvfId));
                    }
                }
            });
        }

        if (ruleSetDiff.getNewFlowTunnels() != null && !ruleSetDiff.getNewFlowTunnels().isEmpty()) {
            ruleSetDiff.getOldFlowTunnels().forEach(tunnelDevicePolicy -> builder.append(String.format((tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) ? POLICY_MPLS_TUNNEL_REVERT_FORMAT : POLICY_GRE_TUNNEL_REVERT_FORMAT, tunnelDevicePolicy.getName())));
            // revert set VLAN command in route-map to maintain the GUI selection order, if new tunnels are added
            if (!stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence) != null) {
                stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence).forEach(vlan -> {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_REVERT_FORMAT, vlan));
                    }
                });
            }
            // revert set TVF command in route-map to maintain the GUI selection order, if new tunnels are added
            if (!stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence) != null) {
                stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence).forEach(tvfId -> {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_TVF_REVERT_FORMAT, tvfId));
                    }
                });
            }

            ruleSetDiff.getNewFlowTunnels().forEach(tunnelDevicePolicy -> builder.append(String.format((tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.MPLS) ? POLICY_MPLS_TUNNEL_RECORD_FORMAT : POLICY_GRE_TUNNEL_RECORD_FORMAT, tunnelDevicePolicy.getName())));
            // Add back the set VLAN command in route-map to maintain the GUI selection order, if new tunnels are added
            if (!stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence) != null) {
                stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence).forEach(vlan -> {
                    String destMac = ruleSetDiff.getUpdatedDestinationMac() != null ? ruleSetDiff.getUpdatedDestinationMac() : ruleSetDiff.getAddedDestinationMac();
                    if (destMac != null && !destMac.isEmpty()) {
                        builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                    } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                    }
                });
            }

            // Add back the set TVF command in route-map to maintain the GUI selection order, if new tunnels are added
            if (!stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence) != null) {
                stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence).forEach(tvfId -> {
                    if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }
                });
            }
        } else if (ruleSetDiff.getDeletedDestinationMac() != null || (stablenetPolicyDiff.isOldPreserveHeader() && !stablenetPolicyDiff.isNewPreserveHeader())) {
            // Revert the set VLAN command in route-map to remove replace vlan, if Preserve header is disabled during update
            if (!stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence) != null) {
                stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence).forEach(vlan -> {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_REVERT_FORMAT, vlan));
                    }
                    String destMac = ruleSetDiff.getUpdatedDestinationMac() != null ? ruleSetDiff.getUpdatedDestinationMac() : ruleSetDiff.getAddedDestinationMac();
                    if (destMac != null && !destMac.isEmpty()) {
                        builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                    } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                    }
                });
            }

            // Revert the set TVF command in route-map to remove replace vlan, if Preserve header is disabled during update
            if (!stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence) != null) {
                stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence).forEach(tvfId -> {
                    if (stablenetPolicyDiff.isOldPreserveHeader()) {
                        builder.append(String.format(REVERT_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }

                    if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }
                });
            }
        }

        if (ruleSetDiff.getAddedDestinationMac() != null || (!stablenetPolicyDiff.isOldPreserveHeader() && stablenetPolicyDiff.isNewPreserveHeader())) {
            // Add the set VLAN command in route-map to add replace vlan, if Preserve header is enabled during update
            if (!stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence) != null) {
                stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence).forEach(vlan -> {
                    String destMac = ruleSetDiff.getAddedDestinationMac();
                    if (destMac != null && !destMac.isEmpty()) {
                        builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                    } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                    }
                });
            }

            // Add the set TVF command in route-map to add replace vlan, if Preserve header is enabled during update
            if (!stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence) != null) {
                stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence).forEach(tvfId -> {
                    if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }
                });
            }

        } else if (ruleSetDiff.isDestinationMacUpdated() || (stablenetPolicyDiff.isOldPreserveHeader() && stablenetPolicyDiff.isNewPreserveHeader())) {
            if (!stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence) != null) {
                stablenetPolicyDiff.getVlanDiff().getUpdatedVlansMap().get(sequence).forEach(vlan -> {
                    if (ruleSetDiff.isDestinationMacUpdated()) {
                        if (stablenetPolicyDiff.isOldPreserveHeader()) {
                            builder.append(String.format(REVERT_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                        } else {
                            builder.append(String.format(POLICY_VLAN_REVERT_FORMAT, vlan));
                        }
                        String destMac = ruleSetDiff.getUpdatedDestinationMac();
                        if (destMac != null && !destMac.isEmpty()) {
                            builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                        } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                            builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                        } else {
                            builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                        }
                    }
                });
            }

            if (!stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence) != null) {
                stablenetPolicyDiff.getTvfDiff().getUpdatedTvfsMap().get(sequence).forEach(tvfId -> {
                    if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }
                });
            }
        }

        // adding newly added vlans to route-map
        if (!stablenetPolicyDiff.getVlanDiff().getAddedVlansMap().isEmpty() && stablenetPolicyDiff.getVlanDiff().getAddedVlansMap().get(sequence) != null) {
            stablenetPolicyDiff.getVlanDiff().getAddedVlansMap().get(sequence).forEach(vlan -> {
                if (ruleSetDiff.getFlowVlans() == null || ruleSetDiff.getFlowVlans().contains(vlan)) {
                    String destMac = ruleSetDiff.getAddedDestinationMac() != null ? ruleSetDiff.getAddedDestinationMac() : ruleSetDiff.getUpdatedDestinationMac();
                    if (destMac != null && !destMac.isEmpty()) {
                        builder.append(String.format(POLICY_VLAN_MAC_RECORD_FORMAT, vlan, destMac));
                    } else if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_FLOOD_VLAN_REPLACE_VLAN_FORMAT, vlan, reservedVlan));
                    } else {
                        builder.append(String.format(POLICY_VLAN_RECORD_FORMAT, vlan));
                    }
                }
            });
        }

        // adding newly added tvfIds to route-map
        if (!stablenetPolicyDiff.getTvfDiff().getAddedTvfsMap().isEmpty() && stablenetPolicyDiff.getTvfDiff().getAddedTvfsMap().get(sequence) != null) {
            stablenetPolicyDiff.getTvfDiff().getAddedTvfsMap().get(sequence).forEach(tvfId -> {
                if (ruleSetDiff.getFlowTvfs() == null || ruleSetDiff.getFlowTvfs().contains(tvfId)) {
                    if (stablenetPolicyDiff.isNewPreserveHeader()) {
                        builder.append(String.format(SET_TVF_DOMAIN_REPLACE_VLAN_FORMAT, tvfId, reservedVlan));
                    } else {
                        builder.append(String.format(SET_TVF_DOMAIN_FORMAT, tvfId));
                    }
                }
            });
        }
    }

    /**
     * This method is used to build VLAN update commands
     *
     * @param oldPolicy
     * @param stablenetPolicyDiff
     * @return
     */
    private String buildUpdateVlanCommand(Policy oldPolicy, StablenetPolicyDiff stablenetPolicyDiff, Long deviceId) {

        List<String> vlansToDelete = getVlansToDelete(oldPolicy);
        Map<String, Set<Port>> egressPortToBeUnMapped = getPortsUnbindedFromVlan(oldPolicy);

        StringBuilder command = new StringBuilder();

        VlanDiff vlanDiff = stablenetPolicyDiff.getVlanDiff();

        Map<String, Set<String>> oldVlanMap = vlanDiff.getOldVlanMap();

        Map<String, Set<String>> newVlanMap = vlanDiff.getNewVlanMap();

        vlanDiff.getDeletedVlans().forEach(deletedVlan -> {
            if (egressPortToBeUnMapped != null && !egressPortToBeUnMapped.isEmpty()) {
                Set<String> unMapEgressMap = oldVlanMap.get(deletedVlan);
                if (unMapEgressMap != null) {
                    Set<Port> egressPorts = egressPortToBeUnMapped.get(deletedVlan);
                    if (egressPorts != null) {
                        command.append(String.format(POLICYSET_EGRESS_EDIT_RECORD_HEADER_FORMAT, deletedVlan));
                        unMapEgressMap.forEach(unMapCmd -> {
                            command.append("no " + unMapCmd.replaceAll(" pg", "") + ";");
                        });
                        // exiting from vlan
                        command.append(EXIT);
                    }
                }
            }

            if (vlansToDelete.contains(deletedVlan) && flowRepository.findFlowVlansByDeviceIdAndVlan(deviceId,deletedVlan).isEmpty()) {
                command.append(String.format(DELETE_VLAN_FORMAT, deletedVlan));
            }
        });

        vlanDiff.getUpdatedVlans().forEach(unchangedVlan -> {
            Set<String> unMapEgressMap = oldVlanMap.get(unchangedVlan);
            Set<String> mapEgressMap = newVlanMap.get(unchangedVlan);

            List<String> unChangedEgress = unMapEgressMap.stream().filter(mapEgressMap::contains).collect(Collectors.toList());

            int portGroupExistingCount = 0;
            for (String unMapCmd : unMapEgressMap) {
                if (unMapCmd.indexOf("pg") > -1) {
                    portGroupExistingCount++;
                }
            }
            int portGroupCount = 0;
            for (String mapCmd : mapEgressMap) {
                if (mapCmd.indexOf("pg") > -1) {
                    portGroupCount++;
                }
            }

            unChangedEgress.forEach(s -> {
                unMapEgressMap.remove(s);
                mapEgressMap.remove(s);
            });

            if (unMapEgressMap.size() > 0 || mapEgressMap.size() > 0) {
                command.append(String.format(POLICYSET_EGRESS_EDIT_RECORD_HEADER_FORMAT, unchangedVlan));
            }

            for (String unMapCmd : unMapEgressMap) {
                command.append("no " + unMapCmd.replaceAll(" pg", "") + ";");
            }

            for (String mapCmd : mapEgressMap) {
                if (mapCmd.indexOf("pg") > -1) {
                    portGroupCount++;
                }
                command.append(mapCmd.replaceAll(" pg", "") + ";");
            }

            /* building exit VLAN command based on EGRESS is of port group or port*/
            if (unMapEgressMap.size() > 0 || mapEgressMap.size() > 0) {
                if (portGroupExistingCount == 0 && portGroupCount > 0) {
                    command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT_FOR_LAG);
                } else if (portGroupExistingCount > 0 && portGroupCount == 0) {
                    command.append(POLICYSET_EGRESS_REVERT_TAILOR_FORMAT_FOR_LAG);
                    command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT);
                } else if (portGroupExistingCount == 0 && portGroupCount == 0) {
                    command.append(EXIT);
                } else if (portGroupExistingCount > 0 && portGroupCount > 0) {
                    command.append(EXIT);
                }
            }
        });

        vlanDiff.getAddedVlans().forEach(addedVlan -> {
            Set<String> mapEgressMap = newVlanMap.get(addedVlan);
            command.append(String.format(POLICYSET_EGRESS_EDIT_RECORD_HEADER_FORMAT, addedVlan));
            int portGroupCount = 0;
            if (mapEgressMap != null) {
                for (String mapCmd : mapEgressMap) {
                    if (mapCmd.indexOf("pg") > -1) {
                        portGroupCount++;
                    }
                    command.append(mapCmd.replaceAll(" pg", "") + ";");
                }

                if (portGroupCount > 0) {
                    command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT_FOR_LAG);
                } else {
                    command.append(POLICYSET_EGRESS_RECORD_TAILOR_FORMAT);
                }
            }
        });
        return command.toString();
    }

    private String buildUpdateTvfCommand(StablenetPolicyDiff stablenetPolicyDiff, Long deviceId) {

        StringBuilder command = new StringBuilder();

        TvfDiff tvfDiff = stablenetPolicyDiff.getTvfDiff();

        Map<String, Set<String>> oldTvfMap = tvfDiff.getOldTvfMap();

        Map<String, Set<String>> newTvfMap = tvfDiff.getNewTvfMap();

        // Un bind deleted destination ports from TVF domain
        tvfDiff.getDeletedTvfs().forEach(deletedTvf -> {
            Set<String> unMapEgressMap = oldTvfMap.get(deletedTvf);
            if (unMapEgressMap != null) {
                command.append(String.format(TVF_DOMAIN_HEADER_FORMAT, deletedTvf));
                unMapEgressMap.forEach(unMapCmd -> {
                    command.append("no " + unMapCmd.replaceAll(" pg", "") + ";");
                });
                // exiting from TVF
                command.append(EXIT);
            }
            //check the tvf domains is associated to any other policies then remove it else not.
            if (!newTvfMap.containsKey(deletedTvf) && flowRepository.findTvfVlansByDeviceIdAndVlan(deviceId,deletedTvf).isEmpty()) {
                command.append(String.format(DELETE_TVF_FORMAT, deletedTvf));
            }
        });

        // Un bind deleted destination ports from TVF domain, and bind added destination ports to TVF domain
        tvfDiff.getUpdatedTvfs().forEach(unchangedVlan -> {
            Set<String> unMapEgressMap = oldTvfMap.get(unchangedVlan);
            Set<String> mapEgressMap = newTvfMap.get(unchangedVlan);

            List<String> unChangedEgress = unMapEgressMap.stream().filter(mapEgressMap::contains).collect(Collectors.toList());

            unChangedEgress.forEach(s -> {
                unMapEgressMap.remove(s);
                mapEgressMap.remove(s);
            });

            if (unMapEgressMap.size() > 0 || mapEgressMap.size() > 0) {
                command.append(String.format(TVF_DOMAIN_HEADER_FORMAT, unchangedVlan));
            }

            for (String unMapCmd : unMapEgressMap) {
                command.append("no " + unMapCmd.replaceAll(" pg", "") + ";");
            }

            for (String mapCmd : mapEgressMap) {
                command.append(mapCmd.replaceAll(" pg", "") + ";");
            }

            // exiting from TVF
            if (unMapEgressMap.size() > 0 || mapEgressMap.size() > 0) {
                command.append(EXIT);
            }
        });

        // Bind added destination ports to TVF domain
        tvfDiff.getAddedTvfs().forEach(addedTvf -> {
            Set<String> mapEgressMap = newTvfMap.get(addedTvf);
            command.append(String.format(TVF_DOMAIN_HEADER_FORMAT, addedTvf));
            if (mapEgressMap != null) {
                for (String mapCmd : mapEgressMap) {
                    command.append(mapCmd.replaceAll(" pg", "") + ";");
                }
            }
            command.append(EXIT);
        });
        return command.toString();
    }

    private String buildUpdateReservedVlanCommand(Policy oldPolicy, Policy newPolicy, Integer reservedVlan) {
        StringBuilder command = new StringBuilder();

        boolean oldPreserveHeader = oldPolicy.isPreserveHeader();
        boolean newPreserveHeader = newPolicy.isPreserveHeader();

        if (oldPreserveHeader || newPreserveHeader) {
            List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(newPolicy.getDevice().getId(), newPolicy.getId());
            activePolicies.addAll(policyRepository.findAllActivePoliciesByDeviceIdNotCurrentPolicy(newPolicy.getDevice().getId(), newPolicy.getId()));

            // ACTIVE policies with preserve header enabled
            List<Policy> activePolicyList = activePolicies.stream().filter(policy -> policy.isPreserveHeader()).collect(Collectors.toList());

            Set<String> outPortsOfActivePolicies = Sets.newHashSet();
            // Collecting the destination ports from active policies(excluding the current policy) on the device
            activePolicyList.forEach(activePolicy -> {
                activePolicy.getFlows().forEach(flow -> {
                    outPortsOfActivePolicies.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                    outPortsOfActivePolicies.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                });
            });

            if (!oldPreserveHeader && newPreserveHeader) {
                // Collecting the destination ports from updated policy
                Set<String> outPortsOfUpdatedPolicy = getOutPortsOfPolicy(newPolicy);

                Sets.SetView<String> outPortsToUnTagInReservedVlan = Sets.difference(outPortsOfUpdatedPolicy, outPortsOfActivePolicies);
                if (outPortsToUnTagInReservedVlan != null && !outPortsToUnTagInReservedVlan.isEmpty()) {
                    command.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlan));
                    // untag port
                    outPortsToUnTagInReservedVlan.forEach(port -> {
                        command.append(String.format(UNTAG_PORT, port));
                    });
                    command.append(EXIT);
                }
            } else if (oldPreserveHeader && !newPreserveHeader) {
                // Collecting the destination ports from old policy
                Set<String> outPortsOfOldPolicy = getOutPortsOfPolicy(oldPolicy);

                Sets.SetView<String> outPortsToUnMapInReservedVlan = Sets.difference(outPortsOfOldPolicy, outPortsOfActivePolicies);
                if (outPortsToUnMapInReservedVlan != null && !outPortsToUnMapInReservedVlan.isEmpty()) {
                    command.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlan));
                    // unmap untagged ports from reserved vlan
                    outPortsToUnMapInReservedVlan.forEach(port -> {
                        command.append(String.format(REVERT_UNTAG_PORT, port));
                    });
                    command.append(EXIT);
                    if (outPortsOfActivePolicies.isEmpty()) {
                        command.append(String.format(DELETE_VLAN_FORMAT, reservedVlan));
                    }
                }
            } else if (oldPreserveHeader && newPreserveHeader) {
                // Collecting the destination ports from old policy
                Set<String> outPortsOfOldPolicy = getOutPortsOfPolicy(oldPolicy);
                // Collecting the destination ports from updated policy
                Set<String> outPortsOfUpdatedPolicy = getOutPortsOfPolicy(newPolicy);

                Sets.SetView<String> deletedOutPorts = Sets.difference(outPortsOfOldPolicy, outPortsOfUpdatedPolicy);
                Sets.SetView<String> addedOutPorts = Sets.difference(outPortsOfUpdatedPolicy, outPortsOfOldPolicy);

                Sets.SetView<String> outPortsToUnMapInReservedVlan = Sets.difference(deletedOutPorts, outPortsOfActivePolicies);
                Sets.SetView<String> outPortsToUnTagInReservedVlan = Sets.difference(addedOutPorts, outPortsOfActivePolicies);

                if (outPortsToUnMapInReservedVlan != null && !outPortsToUnMapInReservedVlan.isEmpty()) {
                    command.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlan));
                    // unmap untagged ports from reserved vlan
                    outPortsToUnMapInReservedVlan.forEach(port -> {
                        command.append(String.format(REVERT_UNTAG_PORT, port));
                    });
                    command.append(EXIT);
                    if (outPortsOfActivePolicies.isEmpty()) {
                        command.append(String.format(DELETE_VLAN_FORMAT, reservedVlan));
                    }
                }

                if (outPortsToUnTagInReservedVlan != null && !outPortsToUnTagInReservedVlan.isEmpty()) {
                    command.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlan));
                    // untag port
                    outPortsToUnTagInReservedVlan.forEach(port -> {
                        command.append(String.format(UNTAG_PORT, port));
                    });
                    command.append(EXIT);
                }
            }
        }
        return command.toString();
    }

    private Set<String> getOutPortsOfPolicy(Policy policy) {
        Set<String> outPortsOfPolicy = Sets.newHashSet();
        for (Flow flow : policy.getFlows()) {
            outPortsOfPolicy.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
            outPortsOfPolicy.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
        }
        return outPortsOfPolicy;
    }

    private Integer getReservedVlan(Long deviceId) {
        Integer reservedVlanId = null;
        HeaderStrippingModulePolicy headerStrippingModulePolicy = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(deviceId).stream().findFirst().get();
        if (headerStrippingModulePolicy != null) {
            reservedVlanId = headerStrippingModulePolicy.getReplaceVlan();
        } else {
            log.error("Replace VLAN Id is not configured for this device: {}, {}", deviceId, "");
        }
        return reservedVlanId;
    }

    private String buildRuleUpdateCommand(StablenetPolicyDiff stablenetPolicyDiff, Policy policy) {
        StringBuilder command = new StringBuilder();
        List<String> uniqueListOfRulesetNameToUpdateRules = new ArrayList<>();
        if ((stablenetPolicyDiff.isRulesUpdatedForPolicy() || stablenetPolicyDiff.isRulesDeletedForPolicy() || stablenetPolicyDiff.isRulesAddedForPolicy()) && stablenetPolicyDiff.getDeletedSeqs().isEmpty()) {
            stablenetPolicyDiff.getRuleSetTypeMap().forEach((type, ruleDiffs) -> {
                ruleDiffs.forEach(ruleDiff -> {
                    if (ruleDiff != null) {
                        String rulesetName = ruleDiff.getRuleSet().getName();
                        if (!uniqueListOfRulesetNameToUpdateRules.contains(rulesetName)) {
                            StringBuilder builder = new StringBuilder();
                            if (type == RuleSet.Type.L2) {
                                // creating first line for command for MAC
                                builder.append(String.format(MAC_RULE_SET_HEADER_FORMAT, ruleDiff.getRuleSet().getName()));
                            } else if (type == RuleSet.Type.UDA) {
                                // creating first line for command for UDA
                                builder.append(String.format(UDA_RULE_SET_HEADER_FORMAT, ruleDiff.getRuleSet().getName()));
                            }
                            String ruleCmd = buildRuleCommand(type, ruleDiff, policy.isLegacy());
                            // entering into acl, only if rule is updated
                            if (ruleCmd.length() > 0) {
                                command.append(builder.toString());
                                command.append(ruleCmd);
                                command.append(EXIT);
                            }
                            uniqueListOfRulesetNameToUpdateRules.add(rulesetName);
                        }
                    }
                });
            });

            stablenetPolicyDiff.getRuleSetIpVersionMap().forEach((ipVersion, ruleDiffs) -> {
                ruleDiffs.forEach(ruleDiff -> {
                    if (ruleDiff != null) {
                        String rulesetName = ruleDiff.getRuleSet().getName();
                        if (!uniqueListOfRulesetNameToUpdateRules.contains(rulesetName)) {
                            StringBuilder builder = new StringBuilder();
                            if (ipVersion == RuleSet.IpVersion.V4) {
                                // creating first line for command IP
                                builder.append(String.format(IPV4_RULE_SET_HEADER_FORMAT, ruleDiff.getRuleSet().getName()));
                            } else if (ipVersion == RuleSet.IpVersion.V6) {
                                // creating first line for command for IPV6
                                builder.append(String.format(IPV6_RULE_SET_HEADER_FORMAT, ruleDiff.getRuleSet().getName()));
                            }
                            String ruleCmd = buildRuleCommand(null, ruleDiff, policy.isLegacy());
                            if (ruleCmd.trim().length() > 0) {
                                command.append(builder.toString());
                                command.append(ruleCmd);
                                command.append(EXIT);
                            }
                            uniqueListOfRulesetNameToUpdateRules.add(rulesetName);
                        }
                    }
                });
            });
        }
        return command.toString();
    }

    /**
     * This method is used to build Rules update command
     *
     * @param type
     * @param ruleDiff
     * @return
     */
    private String buildRuleCommand(RuleSet.Type type, RuleDiff ruleDiff, boolean isLegacy) {
        StringBuilder command = new StringBuilder();
        if (ruleDiff.getDeletedRules() != null) {
            ruleDiff.getDeletedRules().forEach(rule -> {
                String ruleCommand = "";
                if (type == RuleSet.Type.L2) {
                    ruleCommand = buildMACRuleCommand(rule, isLegacy);
                } else if (type == RuleSet.Type.UDA) {
                    ruleCommand = buildUDARuleCommand(rule, isLegacy);
                } else {
                    ruleCommand = buildRuleCommand(rule, isLegacy);
                }
                command.append(String.format(REVERT_RULE_FORMAT, ruleCommand));
            });
        }

        if (ruleDiff.getAddedRules() != null) {
            ruleDiff.getAddedRules().forEach(rule -> {
                String ruleCommand = "";
                if (type == RuleSet.Type.L2) {
                    ruleCommand = buildMACRuleCommand(rule, isLegacy);
                } else if (type == RuleSet.Type.UDA) {
                    ruleCommand = buildUDARuleCommand(rule, isLegacy);
                } else {
                    ruleCommand = buildRuleCommand(rule, isLegacy);
                }
                command.append(ruleCommand);
            });
        }
        return command.toString();
    }


}
