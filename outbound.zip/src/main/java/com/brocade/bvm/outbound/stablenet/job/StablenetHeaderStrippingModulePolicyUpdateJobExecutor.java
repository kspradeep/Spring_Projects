package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.HeaderStrippingModulePolicyHistoryRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.history.HeaderStrippingModulePolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The StablenetHeaderStrippingModulePolicyUpdateJobExecutor class implements methods to update HeaderStripping module policy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetHeaderStrippingModulePolicyUpdateJobExecutor extends AbstractHeaderStrippingModulePolicyJobExecutor {

    @Inject
    private HeaderStrippingModulePolicyHistoryRepository headerStrippingModulePolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;

    /**
     * This method constructs update HeaderStripping module policy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        HeaderStrippingModulePolicy modulePolicy = (HeaderStrippingModulePolicy) getParentObject(job);
        HeaderStrippingModulePolicy modulePolicyFromHistory = getModulePolicyFromHistory(modulePolicy);

        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(HEADER_STRIPPING_BLOCK_FORMAT);

        Set<String> oldHeaders = modulePolicyFromHistory.getStripHeaders().stream().map(HeaderStrippingModulePolicy.Headers::name).collect(Collectors.toSet());
        Set<String> newHeaders = modulePolicy.getStripHeaders().stream().map(HeaderStrippingModulePolicy.Headers::name).collect(Collectors.toSet());
        if (!oldHeaders.containsAll(newHeaders) || oldHeaders.size() != newHeaders.size()) {
            Set<HeaderStrippingModulePolicy.Headers> headersDeleted = new HashSet<>();
            Set<HeaderStrippingModulePolicy.Headers> headersAdded = new HashSet<>();
            modulePolicyFromHistory.getStripHeaders().forEach(oldHeader -> {
                if (!newHeaders.contains(oldHeader.name()))
                    headersDeleted.add(oldHeader);
            });

            modulePolicy.getStripHeaders().forEach(newHeader -> {
                if (!oldHeaders.contains((newHeader.name())))
                    headersAdded.add(newHeader);
            });

            List<Module> oldModules = (List<Module>) moduleRepository.findAll(modulePolicyFromHistory.getModules().stream().map(Module::getId).collect(Collectors.toList()));
            List<Module> newModules = (List<Module>) moduleRepository.findAll(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()));

            Set<Long> oldModuleIds = modulePolicyFromHistory.getModules().stream().map(Module::getId).collect(Collectors.toSet());
            Set<Long> newModuleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());

            if (!modulePolicyFromHistory.getProcessor().getProcessorNumber().equals(modulePolicy.getProcessor().getProcessorNumber())
                    || !oldModuleIds.containsAll(newModuleIds)
                    || oldModuleIds.size() != newModuleIds.size()) {
                headersDeleted.addAll(modulePolicyFromHistory.getStripHeaders());
                headersAdded.addAll(modulePolicyFromHistory.getStripHeaders());
            }

            /* Issuing delete command for deleted Headers*/
            headersDeleted.forEach(header -> {
                command.append(buildDeleteCommand(Sets.newHashSet(oldModules), header, modulePolicyFromHistory.getProcessor(), modulePolicyFromHistory.isPreserve()));
            });

            /* Issuing create command for added Headers*/
            headersAdded.forEach(header -> {
                command.append(buildCreateCommand(Sets.newHashSet(newModules), header, modulePolicy.getProcessor(), modulePolicy.isPreserve()));
            });
            command.append(EXIT);
        } else if (modulePolicyFromHistory.getProcessor() == modulePolicy.getProcessor()) {
            /* Finding the diff of modules between old module policy and new module policy*/
            Set<Long> oldModuleIds = modulePolicyFromHistory.getModules().stream().map(Module::getId).collect(Collectors.toSet());
            Set<Long> newModuleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());

            Set<Module> modulesDeleted = new HashSet<>();
            Set<Module> modulesAdded = new HashSet<>();

            modulePolicyFromHistory.getModules().forEach(oldModule -> {
                if (!newModuleIds.contains(oldModule.getId())) {
                    modulesDeleted.add(oldModule);
                }
            });

            modulePolicy.getModules().forEach(newModule -> {
                if (!oldModuleIds.contains(newModule.getId())) {
                    modulesAdded.add(newModule);
                }
            });

            List<Module> oldModules = (List<Module>) moduleRepository.findAll(modulesDeleted.stream().map(Module::getId).collect(Collectors.toList()));
            List<Module> newModules = (List<Module>) moduleRepository.findAll(modulesAdded.stream().map(Module::getId).collect(Collectors.toList()));

            /* Issuing delete command for deleted modules*/
            modulePolicyFromHistory.getStripHeaders().forEach(header -> {
                command.append(buildDeleteCommand(Sets.newHashSet(oldModules), header, modulePolicyFromHistory.getProcessor(), modulePolicyFromHistory.isPreserve()));
            });
            /* Issuing create command for added modules*/
            modulePolicy.getStripHeaders().forEach(header -> {
                command.append(buildCreateCommand(Sets.newHashSet(newModules), header, modulePolicy.getProcessor(), modulePolicy.isPreserve()));
            });
            command.append(EXIT);
        } else { /*if processor is different from history, delete with old processor, old modules and create with new processor, new modules*/
            List<Module> oldModules = (List<Module>) moduleRepository.findAll(modulePolicyFromHistory.getModules().stream().map(Module::getId).collect(Collectors.toList()));
            List<Module> newModules = (List<Module>) moduleRepository.findAll(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()));
            modulePolicyFromHistory.getStripHeaders().forEach(header -> {
                command.append(buildDeleteCommand(Sets.newHashSet(oldModules), header, modulePolicyFromHistory.getProcessor(), modulePolicyFromHistory.isPreserve()));
            });
            modulePolicy.getStripHeaders().forEach(header -> {
                command.append(buildCreateCommand(Sets.newHashSet(newModules), header, modulePolicy.getProcessor(), modulePolicy.isPreserve()));
            });
            command.append(EXIT);
        }
        command.append(buildRemovePreserveHeaderCommand(modulePolicyFromHistory));
        command.append(buildPreserveHeaderCommand(modulePolicy));
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param modulePolicy
     * @return HeaderStrippingModulePolicy returns latest ACTIVE policy
     */
    private HeaderStrippingModulePolicy getModulePolicyFromHistory(HeaderStrippingModulePolicy modulePolicy) {
        List<HeaderStrippingModulePolicyHistory> modulePolicyHistoryList = headerStrippingModulePolicyHistoryRepository.findByIdAndWorkflowStatus(modulePolicy.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        if (!modulePolicyHistoryList.isEmpty()) {
            HeaderStrippingModulePolicyHistory lastActivePolicy = modulePolicyHistoryList.get(0);
            HeaderStrippingModulePolicy policyFromHistory = lastActivePolicy.buildParent();
            return policyFromHistory;
        }
        return null;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_UPDATE);
    }
}
