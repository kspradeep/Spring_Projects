package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.outbound.stablenet.commands.recovery.*;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetHeaderStrippingModulePolicyRecoveryJobExecutor class implements methods to recover headerStripping module policy which is in ERROR state on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetHeaderStrippingModulePolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    private static final String DEVICE_ID = "device-id ";

    private static final String ROUTE_MAP_NAME_WITH_SEQUENCE = "only%s";

    private static final String L2_NAME_WITH_SEQUENCE = "match%s";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_ROLLBACK);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method constructs headerStripping module policy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        HeaderStrippingModulePolicy headerStrippingModulePolicy = (HeaderStrippingModulePolicy) getParentObject(job);
        log.debug("HeaderStrippingModulePolicyRecovery Job executor for policy id {}", headerStrippingModulePolicy.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(headerStrippingModulePolicy);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", headerStrippingModulePolicy.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs headerStripping module policy recovery command blocks for the given policy
     *
     * @param headerStrippingModulePolicy
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(HeaderStrippingModulePolicy headerStrippingModulePolicy) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        headerStrippingModulePolicy.getModules().forEach(module -> {
            Device device = module.getDevice();
            if (isOsVersion6(device)) {
                headerStrippingModulePolicy.getStripHeaders().forEach(header -> {
                    finalCommandBlocks.add(constructModuleCommandBlockForOs6(module, header, getProcessor(module.getDevice(), headerStrippingModulePolicy), headerStrippingModulePolicy.isPreserve()));
                });
            } else {
                headerStrippingModulePolicy.getStripHeaders().forEach(header -> {
                    finalCommandBlocks.add(constructModuleCommandBlock(module, header, headerStrippingModulePolicy.isPreserve()));
                });

            }
        });

        if (headerStrippingModulePolicy.isPreserve()) {
            headerStrippingModulePolicy.getStripHeaders().forEach(header -> {
                String rmOrAclName = "";
                if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                    rmOrAclName = "-br";
                } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                    rmOrAclName = "-vntag";
                } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
                    rmOrAclName = "-br-vntag";
                }
                int stablenetDeviceId = headerStrippingModulePolicy.getModules().stream().findFirst().get().getDevice().getStablenetId().intValue();
                finalCommandBlocks.add(constructDeleteRouteMapCommandBlock(stablenetDeviceId, rmOrAclName));
                finalCommandBlocks.add(constructDeleteL2ACLCommandBlock(stablenetDeviceId, rmOrAclName));
                finalCommandBlocks.add(constructDeleteVlanCommandBlock(stablenetDeviceId, headerStrippingModulePolicy.getIntermediateVlan()));
            });
        }
        return finalCommandBlocks;
    }

    private InterfaceUnMapCommandBlock constructInterfaceUnMapCMDBlock(Integer deviceId, String port, String rmName, String type) {
        InterfaceUnMapCommandBlock interfaceUnMapCMDBlock = new InterfaceUnMapCommandBlock();
        interfaceUnMapCMDBlock.setDeviceId(deviceId);
        interfaceUnMapCMDBlock.setPort(port);
        interfaceUnMapCMDBlock.setRouteMapName(rmName);
        interfaceUnMapCMDBlock.setType(type);
        return interfaceUnMapCMDBlock;
    }

    /**
     * This method constructs headerStripping module policy recovery command block for OS version 6 and above
     *
     * @param module
     * @param header
     * @param processorNumber
     * @return HeaderStrippingOs6CommandBlock
     */
    private HeaderStrippingOs6CommandBlock constructModuleCommandBlockForOs6(Module module, HeaderStrippingModulePolicy.Headers header, String processorNumber, Boolean isPreserveHeader) {
        HeaderStrippingOs6CommandBlock headerStrippingCommandBlock = new HeaderStrippingOs6CommandBlock();
        headerStrippingCommandBlock.setDeviceId(module.getDevice().getStablenetId().intValue());
        headerStrippingCommandBlock.setHeader(header);
        headerStrippingCommandBlock.setProcessorNumber(processorNumber);
        headerStrippingCommandBlock.setModuleNumber(String.valueOf(module.getModuleNumber()));
        headerStrippingCommandBlock.setPreserve(isPreserveHeader);
        return headerStrippingCommandBlock;
    }

    /**
     * This method constructs headerStripping module policy recovery command block for OS version below 6
     *
     * @param module
     * @param header
     * @return HeaderStrippingCommandBlock
     */
    private HeaderStrippingCommandBlock constructModuleCommandBlock(Module module, HeaderStrippingModulePolicy.Headers header, Boolean isPreserveHeader) {
        HeaderStrippingCommandBlock headerStrippingCommandBlock = new HeaderStrippingCommandBlock();
        headerStrippingCommandBlock.setDeviceId(module.getDevice().getStablenetId().intValue());
        headerStrippingCommandBlock.setHeader(header);
        headerStrippingCommandBlock.setPreserve(isPreserveHeader);
        return headerStrippingCommandBlock;
    }

    /**
     * This method returns processorNumber value to be applied on the device based on device OS and processor number
     *
     * @param device
     * @param modulePolicy
     * @return String returns processorVal
     */
    private String getProcessor(Device device, HeaderStrippingModulePolicy modulePolicy) {
        String processorVal = modulePolicy.getProcessor().getProcessorNumber();
        if (HeaderStrippingModulePolicy.ProcessorNumber.ALL == modulePolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = isOsVersion6(device) ? DEVICE_ID + processorVal : "";
        }
        return processorVal;
    }

    /**
     * This method checks if the given device OS version is 6 and above
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        int osMajorVersion = device.getOsMajorVersion();
        return osMajorVersion >= MLXE_OS_MAJOR_VERSION;
    }

    /**
     * This method constructs delete route-map command block
     *
     * @param stablenetDeviceId
     * @param rmName
     * @return CommandBlock
     */
    private CommandBlock constructDeleteRouteMapCommandBlock(int stablenetDeviceId, String rmName) {
        RouteMapCommandBlock routeMapCommandBlock = new RouteMapCommandBlock();
        routeMapCommandBlock.setDeviceId(stablenetDeviceId);
        routeMapCommandBlock.setRouteMapName(String.format(ROUTE_MAP_NAME_WITH_SEQUENCE, rmName));
        routeMapCommandBlock.setRouteMapNameAndPermitSeq(String.format(ROUTE_MAP_NAME_WITH_SEQUENCE, rmName));
        return routeMapCommandBlock;
    }

    /**
     * This method constructs delete L2 ACL command block
     *
     * @param stablenetDeviceId
     * @param aclName
     * @return
     */
    private CommandBlock constructDeleteL2ACLCommandBlock(int stablenetDeviceId, String aclName) {
        L2AclCommandBlock l2AclCommandBlock = new L2AclCommandBlock();
        l2AclCommandBlock.setDeviceId(stablenetDeviceId);
        l2AclCommandBlock.setAclName(String.format(L2_NAME_WITH_SEQUENCE, aclName));
        return l2AclCommandBlock;
    }

    /**
     * This method constructs delete vlan command block
     *
     * @param stablenetDeviceId
     * @param intermediateVlan
     * @return
     */
    private CommandBlock constructDeleteVlanCommandBlock(int stablenetDeviceId, int intermediateVlan) {
        VLanNoCommandBlock vLanNoCommandBlock = new VLanNoCommandBlock();
        vLanNoCommandBlock.setDeviceId(stablenetDeviceId);
        vLanNoCommandBlock.setVLan(intermediateVlan);
        return vLanNoCommandBlock;
    }

}
