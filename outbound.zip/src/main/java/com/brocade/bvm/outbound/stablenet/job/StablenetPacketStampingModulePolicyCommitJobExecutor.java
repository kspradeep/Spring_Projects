package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketStampingModulePolicy;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The StablenetPacketStampingModulePolicyCommitJobExecutor class implements methods to create PacketStampingModulePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetPacketStampingModulePolicyCommitJobExecutor extends AbstractPacketStampingModulePolicyJobExecutor {

    /**
     * This method constructs create PacketStampingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketStampingModulePolicy modulePolicy = (PacketStampingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        modulePolicy.getModules().forEach(module -> {
            command.append(String.format(MODULE_POLICY_EGRESS_PACKET_TIME_STAMPING_FORMAT, module.getModuleNumber(), getProcessor(module.getDevice(), modulePolicy)));
        });
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_STAMPING_MODULE_POLICY_CREATE);
    }
}
