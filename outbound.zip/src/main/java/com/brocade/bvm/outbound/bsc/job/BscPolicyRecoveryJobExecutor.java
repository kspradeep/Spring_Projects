package com.brocade.bvm.outbound.bsc.job;

import java.util.List;

import javax.inject.Named;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

/**
 * The BscPolicyRecoveryJobExecutor class implements methods to recover policy which is in ERROR state on Open Flow device through BSC
 */
@Slf4j
@Named
public class BscPolicyRecoveryJobExecutor extends BscPolicyDeleteJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_ROLLBACK);
    }

    @Override
    public Long startExternalJob(Job job) {
        return null;
    }

    /**
     * This method is used to recover policy on device by deleting policy
     *
     * @param job
     * @return
     */
    @Override
    public OutboundJobResponse execute(Job job) {
        Policy policyToDelete = (Policy) getParentObject(job);
        boolean jobExecutionStatus = deletePolicyOnDevice(job.getDevice(), policyToDelete);
        if (jobExecutionStatus) {
            return new OutboundJobResponse(Job.Status.SUCCESS, "Policy Recovery is Successful");
        } else {
            return new OutboundJobResponse(Job.Status.FAILED, "Policy Recovery is Failed");
        }
    }
}
