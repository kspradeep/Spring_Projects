package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketCapture;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class StablenetCommitSLXPacketCaptureJobExecutor extends AbstractStablenetSLXPacketCaptureJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_CAPTURE_CREATE);
    }

    @Override
    public String getCommands(Job job) {
        StringBuilder command = new StringBuilder();
        if (job.getType() == Job.Type.PACKET_CAPTURE_CREATE) {
            PacketCapture packetCapture = (PacketCapture) getParentObject(job);
            command.append(buildCommandForCreatePacketCapture(packetCapture));
            log.info("Stablenet SLX command generated from Job Id {} on device {} for packet capture create id {} is {}", job.getId(), job.getDevice().getId(), packetCapture.getId(), command.toString());
        }
        return command.toString();
    }

    /**
     * command for capture the packets
     *
     * @param packetCapture
     * @return
     */
    private String buildCommandForCreatePacketCapture(PacketCapture packetCapture) {
        StringBuilder command = new StringBuilder();
        command.append(NO_PACKET_CAPTURE);
        if (packetCapture.getFilter() != null && (packetCapture.getFilter().equalsIgnoreCase("L2") || packetCapture.getFilter().equalsIgnoreCase("L3"))) {
            command.append(String.format(PACKET_CAPTURE_WITH_OUT_PACKET_COUNT, packetCapture.getPort().getPortNumber().trim(), packetCapture.getDirection(), packetCapture.getFilter()));
        } else {
            command.append(String.format(PACKET_CAPTURE_WITH_PACKET_COUNT, packetCapture.getPort().getPortNumber().trim(), packetCapture.getDirection(), packetCapture.getFilter(), packetCapture.getPacketCount()));
        }
        return command.toString();
    }
}