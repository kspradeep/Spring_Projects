package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class UpdateSdPortGroupJobExecutor extends AbstractSdPortGroupJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_PORT_GROUP_UPDATE);
    }

    /**
     * This method builds PortGroup UPDATE commands to be executed on the given SD device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        SdPortGroup portGroupToUpdate = (SdPortGroup) getParentObject(job);
        StringBuilder command = new StringBuilder(CONFIGURE_TERMINAL);
        command.append(buildUpdateCommand(portGroupToUpdate));
        command.append(EXIT);
        log.info("Stablenet command generated from Job Id{} on device{} for updating SD PortGroup id {} is {}", job.getId(), job.getDevice().getId(), portGroupToUpdate.getId(), command);
        return command.toString();
    }
}
