package com.brocade.bvm.outbound.bsc.model;

import com.google.common.annotations.VisibleForTesting;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.net.util.SubnetUtils;

@Setter
@Getter
public class FlowRule {

    public static final String DEFAULT_MAC_MASK = "ff:ff:ff:ff:ff:ff";
    private String name;
    private String sourceIp4;
    private String destinationIp4;
    private String priority;

    private String sourceIp6;
    private String destinationIp6;

    private String destinationPort;
    private String sourcePort;

    private String vlanId;

    private String protocol;

    private String sourceMac;
    private String destinationMac;

    private String destinationMacMask;
    private String sourceMacMask;
    private String ethType;

    private String inPort;
    private String outPort;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FlowRule flowRule = (FlowRule) o;

        if (name != null ? !name.equalsIgnoreCase(flowRule.name) : flowRule.name != null) return false;
        if (sourceIp4 != null ? !getIp4BasedOnMask(sourceIp4).equalsIgnoreCase(getIp4BasedOnMask(flowRule.sourceIp4)) : flowRule.sourceIp4 != null)
            return false;
        if (destinationIp4 != null ? !getIp4BasedOnMask(destinationIp4).equalsIgnoreCase(getIp4BasedOnMask(flowRule.destinationIp4)) : flowRule.destinationIp4 != null)
            return false;
//        if (sourceIp6 != null ? !getIp6BasedOnMask(sourceIp6).equalsIgnoreCase(getIp6BasedOnMask(flowRule.sourceIp6)) : flowRule.sourceIp6 != null)
//            return false;
//        if (destinationIp6 != null ? !getIp6BasedOnMask(destinationIp6).equalsIgnoreCase(getIp6BasedOnMask(flowRule.destinationIp6)) : flowRule.destinationIp6 != null)
//            return false;
        if (destinationPort != null ? !destinationPort.equalsIgnoreCase(flowRule.destinationPort) : flowRule.destinationPort != null)
            return false;
        if (sourcePort != null ? !sourcePort.equalsIgnoreCase(flowRule.sourcePort) : flowRule.sourcePort != null)
            return false;
        if (vlanId != null ? !vlanId.equalsIgnoreCase(flowRule.vlanId) : flowRule.vlanId != null) return false;
        if (priority != null ? !priority.equalsIgnoreCase(flowRule.priority) : flowRule.priority != null) return false;
        if (protocol != null ? !protocol.equalsIgnoreCase(flowRule.protocol) : flowRule.protocol != null) return false;
        if (sourceMac != null ? !isMacValid(sourceMac, flowRule.sourceMac, sourceMacMask) : flowRule.sourceMac != null) return false;
        if (destinationMac != null ? !isMacValid(destinationMac, flowRule.destinationMac, destinationMacMask) : flowRule.destinationMac != null) return false;
        if (ethType != null ? !ethType.equalsIgnoreCase(flowRule.ethType) : flowRule.ethType != null) return false;
        if (inPort != null ? !inPort.equalsIgnoreCase(flowRule.inPort) : flowRule.inPort != null) return false;
        return outPort != null ? outPort.equalsIgnoreCase(flowRule.outPort) : flowRule.outPort == null;
    }

    String getIp4BasedOnMask(String ip) {
        if (ip != null && !ip.isEmpty()) {
            SubnetUtils subnetUtils = new SubnetUtils(ip);
            return subnetUtils.getInfo().getNetworkAddress();
        }
        return "";
    }

    private String getIp6BasedOnMask(String ip) {
        //bsc is not changing it, no need to apply mask
        return ip;
    }

    @VisibleForTesting
    boolean isMacValid(String opMacAddr, String conMacAddr, String macMask) {
        if (macMask == null || macMask.length() == 0) {
            macMask = DEFAULT_MAC_MASK;
        }
        char mask[] = macMask.toCharArray();
        char mac1[] = opMacAddr.toCharArray();
        char mac2[] = conMacAddr.toCharArray();
        for (int i = 0; i < mask.length; i++) {
            if ("f".equalsIgnoreCase(mask[i]+"") && !(""+mac1[i]).equalsIgnoreCase(mac2[i]+"")) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        return "FlowRule{" +
                "name='" + name + '\'' +
                ", sourceIp4='" + sourceIp4 + '\'' +
                ", destinationIp4='" + destinationIp4 + '\'' +
                ", priority='" + priority + '\'' +
                ", sourceIp6='" + sourceIp6 + '\'' +
                ", destinationIp6='" + destinationIp6 + '\'' +
                ", destinationPort='" + destinationPort + '\'' +
                ", sourcePort='" + sourcePort + '\'' +
                ", vlanId='" + vlanId + '\'' +
                ", protocol='" + protocol + '\'' +
                ", sourceMac='" + sourceMac + '\'' +
                ", destinationMac='" + destinationMac + '\'' +
                ", destinationMacMask='" + destinationMacMask + '\'' +
                ", sourceMacMask='" + sourceMacMask + '\'' +
                ", ethType='" + ethType + '\'' +
                ", inPort='" + inPort + '\'' +
                ", outPort='" + outPort + '\'' +
                '}';
    }
}
