package com.brocade.bvm.outbound.stablenet.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "snmpInterface")
@Data
@ToString
public class SnmpInterface {
    @XmlAttribute(name = "name")
    protected String name;

    @XmlAttribute(name = "obid")
    protected String obid;

    protected Inputs inputs;

    @XmlAccessorType(XmlAccessType.FIELD)
    @Data
    public static class Inputs {
        protected List<String> input;
    }
}
