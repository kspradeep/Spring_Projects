package com.brocade.bvm.outbound.bsc.job;

import java.util.List;

import javax.inject.Named;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.outbound.BaseOutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobExecutor;
import com.brocade.bvm.outbound.OutboundJobResponse;
import com.google.common.collect.Lists;

@Named
public class BscPortGroupRecoveryJobExecutor extends BscPortGroupDeleteJobExecutor {

	@Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_GROUP_RECOVER);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.OPENFLOW;
    }

}
