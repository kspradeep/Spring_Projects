package com.brocade.bvm.outbound.packetcapture.cli.util;

import org.springframework.beans.factory.annotation.Value;


public class CliConstants {

    public static final int DEFAULT_BUFFER_SIZE = 8192;

    @Value("${default.firmware.login.timeout.milliseconds:60000}")
    public static Integer DEFAULT_LOGIN_TIMEOUT = 60000; //in milliseconds

    @Value("${default.firmware.idle.timeout.milliseconds:300000}")
    public static Integer DEFAULT_IDLE_TIMEOUT = 300000; //in milliseconds

    @Value("${default.firmware.response.timeout.milliseconds:120000}")
    public static Integer DEFAULT_CMD_RESPONSE_TIMEOUT = 120000; //in milliseconds

    public enum DeviceType {
        IOS, NOS
    }

    public enum Protocol {
        TELNET, SSH
    }

    public enum AccessMode {
        USER_MODE, PRIVILEGE_MODE, CONFIG_MODE
    }
}
