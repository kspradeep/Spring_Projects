package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to construct command block for IpPayloadLength Recovery
 */
public class IpPayloadLengthCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private String processorNumber;

    @Getter
    @Setter
    private String range;

    @Getter
    @Setter
    private String ipType;

    @Getter
    @Setter
    private String ipTypeMatch;

    @Getter
    @Setter
    private String moduleNumber;

    @Getter
    @Setter
    private String portNumber;

    @Getter
    @Setter
    private String writeMem = "false";

    private static final String PRE_CMD = "conf t;";

    private static final String SHOW_CMD = "show %s match-payload-len interface ethernet %s";
    private static final String MATCH_CMD = "%s Match Payload Length Configuration";
    private static final String ACTION_CMD = "no %s match-payload-len slot %s %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(PRE_CMD);

        args.add(String.format(SHOW_CMD, ipType, portNumber));
        args.add(String.format(ipTypeMatch, MATCH_CMD));
        args.add(String.format(ACTION_CMD, ipType, moduleNumber, processorNumber));

        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "IpPayloadLengthCommandBlock [deviceId=" + deviceId + ", ipType=" + ipType + ", processorNumber=" + processorNumber + ", range=" + range + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }
}
