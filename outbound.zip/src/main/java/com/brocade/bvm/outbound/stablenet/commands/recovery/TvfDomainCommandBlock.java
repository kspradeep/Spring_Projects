package com.brocade.bvm.outbound.stablenet.commands.recovery;

import com.brocade.bvm.outbound.stablenet.model.DeployJobParameter;
import com.brocade.bvm.outbound.stablenet.model.SingularJobTrigger;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kraikar on 2/7/2017.
 */
public class TvfDomainCommandBlock implements CommandBlock {
    @Getter
    @Setter
    private Integer deviceId;

    @Getter
    @Setter
    private Integer tvfDomainId;

    @Getter
    @Setter
    private String writeMem = "false";

    /**
     * <pre>
     * argument #1 is tvf-domain id
     * eg: tvf-domain 100
     * </pre>
     */
    private static final String PRE_CMD = "conf t;tvf-domain %s;";
    /**
     * <pre>
     * argument #1 is tvf-domain id
     * eg: show tvf-domain 100
     * </pre>
     */
    private static final String SHOW_CMD = "show tvf-domain %s";
    /**
     * <pre>
     * argument #1 is tvf-domain id
     * eg: 1/1
     * </pre>
     */
    private static final String MATCH_CMD = "TVF Domain ID %s,";
    /**
     * <pre>
     * argument #1 is tvf-domain id
     * eg: no tvf-domain %s
     * </pre>
     */
    private static final String ACTION_CMD = "no tvf-domain %s";

    @Override
    public DeployJobParameter getTemplateJobInput() {
        DeployJobParameter deployJobParameter = new DeployJobParameter();
        DeployJobParameter.Devices devices = new DeployJobParameter.Devices();
        devices.getDeviceid().add(getDeviceId());
        DeployJobParameter.Input input = new DeployJobParameter.Input();
        List<String> args = new ArrayList<>();
        args.add(String.format(PRE_CMD, getTvfDomainId()));
        args.add(String.format(SHOW_CMD, getTvfDomainId()));
        args.add(String.format(MATCH_CMD, getTvfDomainId()));
        args.add(String.format(ACTION_CMD, getTvfDomainId()));
        args.add(writeMem);
        input.getArg().addAll(args);
        deployJobParameter.setDevices(devices);
        deployJobParameter.setInput(input);
        SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
        singularJobTrigger.setActive(false);
        deployJobParameter.setSingletrigger(singularJobTrigger);
        return deployJobParameter;
    }

    @Override
    public String toString() {
        return "TvfDomainCommandBlock[deviceId=" + deviceId + ", tvfDomainId=" + tvfDomainId + ", getTemplateJobInput()=" + getTemplateJobInput() + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TvfDomainCommandBlock that = (TvfDomainCommandBlock) o;

        if (deviceId != null ? !deviceId.equals(that.deviceId) : that.deviceId != null) return false;
        if (tvfDomainId != null ? !tvfDomainId.equals(that.tvfDomainId) : that.tvfDomainId != null) return false;
        return writeMem != null ? writeMem.equals(that.writeMem) : that.writeMem == null;
    }

    @Override
    public int hashCode() {
        int result = deviceId != null ? deviceId.hashCode() : 0;
        result = 31 * result + (tvfDomainId != null ? tvfDomainId.hashCode() : 0);
        result = 31 * result + (writeMem != null ? writeMem.hashCode() : 0);
        return result;
    }
}
