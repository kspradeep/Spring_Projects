package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.SLXPortGroupRecoveryCommandList;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class StablenetSLXPortGroupRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    @Inject
    protected SLXPortGroupRecoveryCommandList slxPortGroupRecoveryCommandList;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_GROUP_RECOVER, Job.Type.PORT_CHANNEL_RECOVER);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }

    /**
     * This method constructs portGroup recovery commands to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    public List<CommandBlock> getCommands(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        List<CommandBlock> commandBlocks = slxPortGroupRecoveryCommandList.constructCommandBlockList(portGroup);
        return commandBlocks;
    }
}
