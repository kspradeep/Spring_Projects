package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ManagedObjectRepository;
import com.brocade.bvm.model.db.*;
import org.hibernate.validator.internal.util.IgnoreJava6Requirement;

import javax.inject.Inject;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The AbstractHeaderStrippingModulePolicyJobExecutor class implemented methods used in COMMIT/UPDATE/DELETE of headerStripping module policy on Non Open Flow device through Stablenet
 */
public abstract class AbstractHeaderStrippingModulePolicyJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";

    protected static final String END = "end;";

    protected static final String EXIT = "exit;";

    protected static final String WRITE_MEMORY = "write memory;";

    protected static final String NO = "no ";

    protected static final String HEADER_STRIPPING_BLOCK_FORMAT = "packet-encap-processing;";

    /* strip-802-1br all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String STRIP_802_1_BR_FORMAT = "strip-802-1br %s %s;";

    /* strip-vn-tag all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String STRIP_VN_TAG_FORMAT = "strip-vn-tag %s %s;";

    /* strip-vxlan all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String STRIP_VX_LAN_FORMAT = "strip-vxlan %s %s;";

    /* bypass-802-1br all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String BYPASS_802_1_BR_FORMAT = "bypass-802-1br %s %s;";

    /* bypass-vn-tag all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String BYPASS_VN_TAG_FORMAT = "bypass-vn-tag %s %s;";

    protected static final String ALL = "all";

    protected static final String EMPTY = "";

    protected static final String SLOT = "slot ";

    private static final String DEVICE_ID = "device-id ";

    private static final String VLAN_HEADER_FORMAT = "vlan %s;";

    private static final String PORT_RECORD_TAG_FORMAT = "tagged ethe %s;";

    private static final String VLAN_RECORD_TAILOR_FORMAT = "transparent-hw-flooding;";

    private static final String L2_ACL_HEADER_FORMAT = "mac access-list match%s;";

    private static final String L2_RULE_FORMAT = "permit any any any etype %s;";

    private static final String ROUTEMAP_HEADER_FORMAT = "route-map only%s permit 1;";

    private static final String L2_ACL_RECORD_FORMAT = "match l2acl match%s;";

    private static final String VLAN_RECORD_FORMAT = "set next-hop-flood-vlan %s;";

    protected static final String VLAN_RECORD_FORMAT_TAIL = "set interface null0;";

    /* strip-nvgre all | slot <slot-num> | slot <slot-num> device-id <device-id> */
    protected static final String STRIP_NV_GRE_FORMAT = "strip-nvgre %s %s;";

    protected static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    protected static final String STRIP_GTP_DE_ENCAPSULATION = "gtp-de-encapsulation;";

    /**
     * This method returns processorNumber value to be applied on the device based on device OS and processor number
     *
     * @param isOs6
     * @param processorNumber
     * @return String returns processorVal
     */
    protected String getProcessor(boolean isOs6, HeaderStrippingModulePolicy.ProcessorNumber processorNumber) {
        String processorVal = processorNumber.getProcessorNumber();
        if (HeaderStrippingModulePolicy.ProcessorNumber.ALL == processorNumber) {
            processorVal = "";
        } else {
            processorVal = isOs6 ? DEVICE_ID + processorVal : "";
        }
        return processorVal;
    }

    /**
     * This method returns module number value to be applied on the device based on OS
     *
     * @param isOs6
     * @param moduleNumber
     * @return String
     */
    private String getModuleNumber(boolean isOs6, Integer moduleNumber) {
        return isOs6 ? SLOT + moduleNumber : ALL;
    }

    /**
     * This method builds create commands to be applied on the device
     *
     * @param modules
     * @param header
     * @param processorNumber
     * @return String
     */
    protected String buildCreateCommand(Set<Module> modules, HeaderStrippingModulePolicy.Headers header, HeaderStrippingModulePolicy.ProcessorNumber processorNumber, Boolean isPreserveHeader) {
        StringBuilder command = new StringBuilder();
        modules.forEach(module -> {
            boolean isOs6 = isOsVersion6(module.getDevice());
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                command.append(String.format(isPreserveHeader ? BYPASS_802_1_BR_FORMAT : STRIP_802_1_BR_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                command.append(String.format(isPreserveHeader ? BYPASS_VN_TAG_FORMAT : STRIP_VN_TAG_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
                command.append(String.format(STRIP_VX_LAN_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
                command.append(String.format(STRIP_NV_GRE_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
                command.append(String.format(isPreserveHeader ? BYPASS_802_1_BR_FORMAT : STRIP_802_1_BR_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
                command.append(String.format(isPreserveHeader ? BYPASS_VN_TAG_FORMAT : STRIP_VN_TAG_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
                command.append(String.format(STRIP_NV_GRE_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            }
        });
        return command.toString();
    }

    /**
     * This method builds delete commands to be applied on the device
     *
     * @param modules
     * @param header
     * @param processorNumber
     * @return String
     */
    protected String buildDeleteCommand(Set<Module> modules, HeaderStrippingModulePolicy.Headers header, HeaderStrippingModulePolicy.ProcessorNumber processorNumber, Boolean isPreserveHeader) {
        StringBuilder command = new StringBuilder();
        modules.forEach(module -> {
            boolean isOs6 = isOsVersion6(module.getDevice());
            if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
                command.append(String.format(isPreserveHeader ? NO + BYPASS_802_1_BR_FORMAT : NO + STRIP_802_1_BR_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
                command.append(String.format(isPreserveHeader ? NO + BYPASS_VN_TAG_FORMAT : NO + STRIP_VN_TAG_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.VXLAN == header) {
                command.append(String.format(NO + STRIP_VX_LAN_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.NVGRE == header) {
                command.append(String.format(NO + STRIP_NV_GRE_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
                command.append(String.format(isPreserveHeader ? NO + BYPASS_802_1_BR_FORMAT : NO + STRIP_802_1_BR_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
                command.append(String.format(isPreserveHeader ? NO + BYPASS_VN_TAG_FORMAT : NO + STRIP_VN_TAG_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
                command.append(String.format(NO + STRIP_NV_GRE_FORMAT, getModuleNumber(isOs6, module.getModuleNumber()), getProcessor(isOs6, processorNumber)));
            }
        });
        return command.toString();
    }

    /**
     * This method checks if the given device OS version is above 6
     *
     * @param device
     * @return boolean
     */
    private boolean isOsVersion6(Device device) {
        int osMajorVersion = device.getOsMajorVersion();
        return osMajorVersion >= MLXE_OS_MAJOR_VERSION;
    }

    protected String buildPreserveHeaderCommand(HeaderStrippingModulePolicy modulePolicy) {
        StringBuilder command = new StringBuilder();
        if (modulePolicy.isPreserve()) {
            // Intermediate VLAN
            command.append(buildVlanCommand(modulePolicy.getIntermediateVlan(), getIntermediatePortNumber(modulePolicy.getIntermediatePortId())));
            modulePolicy.getStripHeaders().forEach(header -> {
                // L2 ACL
                command.append(buildL2ACLCommand(header));
                // routemap
                String rmOrL2AclName = getRmOrL2AclName(header);
                command.append(buildRouteMapCommand(rmOrL2AclName, modulePolicy.getIntermediateVlan()));
            });

        }
        return command.toString();
    }

    private String getIntermediatePortNumber(Long intermediatePortId) {
        Port intermediatePort = null;
        ManagedObject managedObject = getManagedObject(intermediatePortId);
        if (managedObject instanceof PortGroup) {
            intermediatePort = ((PortGroup) managedObject).getPrimaryPort();
        } else {
            intermediatePort = (Port) managedObject;
        }
        return intermediatePort.getPortNumber();
    }

    protected String buildVlanCommand(Integer intermediateVlan, String intermediatePort) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(VLAN_HEADER_FORMAT, intermediateVlan));
        command.append(String.format(PORT_RECORD_TAG_FORMAT, intermediatePort));
        command.append(VLAN_RECORD_TAILOR_FORMAT);
        command.append(EXIT);
        return command.toString();
    }

    protected String buildL2ACLCommand(HeaderStrippingModulePolicy.Headers header) {
        String aclName = "";
        String brOffset = "";
        String vntagOffset = "";
        if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
            aclName = "-br";
            brOffset = "893f";
        } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
            aclName = "-vntag";
            vntagOffset = "8926";
        } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
            aclName = "-br-vntag";
            brOffset = "893f";
            vntagOffset = "8926";
        }

        StringBuilder command = new StringBuilder();
        command.append(String.format(L2_ACL_HEADER_FORMAT, aclName));
        if (!brOffset.isEmpty()) {
            command.append(String.format(L2_RULE_FORMAT, brOffset));
        }
        if (!vntagOffset.isEmpty()) {
            command.append(String.format(L2_RULE_FORMAT, vntagOffset));
        }
        command.append(EXIT);
        return command.toString();
    }

    protected String buildRouteMapCommand(String rmOrL2AclName, Integer intermediateVlan) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(ROUTEMAP_HEADER_FORMAT, rmOrL2AclName));
        command.append(String.format(L2_ACL_RECORD_FORMAT, rmOrL2AclName));
        command.append(String.format(VLAN_RECORD_FORMAT, intermediateVlan));
        command.append(VLAN_RECORD_FORMAT_TAIL);
        command.append(EXIT);
        return command.toString();
    }

    protected String buildRemovePreserveHeaderCommand(HeaderStrippingModulePolicy modulePolicy) {
        StringBuilder command = new StringBuilder();
        if (modulePolicy.isPreserve()) {
            modulePolicy.getStripHeaders().forEach(header -> {
                String rmOrL2AclName = getRmOrL2AclName(header);
                // routemap
                command.append(buildRemoveRouteMapCommand(rmOrL2AclName));
                // L2 ACL
                command.append(buildRemoveL2ACLCommand(rmOrL2AclName));
                // Intermediate VLAN
                command.append(buildRemoveVlanCommand(modulePolicy.getIntermediateVlan()));
            });

        }
        return command.toString();
    }

    protected String buildRemoveVlanCommand(Integer intermediateVlan) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(NO + VLAN_HEADER_FORMAT, intermediateVlan));
        return command.toString();
    }

    protected String buildRemoveL2ACLCommand(String rmOrL2AclName) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(NO + L2_ACL_HEADER_FORMAT, rmOrL2AclName));
        return command.toString();
    }

    protected String buildRemoveRouteMapCommand(String rmOrL2AclName) {
        StringBuilder command = new StringBuilder();
        command.append(String.format(NO + ROUTEMAP_HEADER_FORMAT, rmOrL2AclName));
        return command.toString();
    }

    private String getRmOrL2AclName(HeaderStrippingModulePolicy.Headers header) {
        String rmOrL2AclName = "";
        if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
            rmOrL2AclName = "-br";
        } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
            rmOrL2AclName = "-vntag";
        } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
            rmOrL2AclName = "-br-vntag";
        }
        return rmOrL2AclName;
    }

    private ManagedObject getManagedObject(Long intermediatePortId) {
        Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
        List<Long> ids = new ArrayList<>();
        ids.add(intermediatePortId);
        query.setParameter("ids", ids);
        return (ManagedObject) query.getSingleResult();
    }
}
