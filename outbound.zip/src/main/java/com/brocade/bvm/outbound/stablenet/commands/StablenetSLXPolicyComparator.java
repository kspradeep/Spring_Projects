package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.vlan.VlanTaggingStripping;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Named
public class StablenetSLXPolicyComparator {

    @Inject
    private FlowRepository flowRepository;

    @Inject
    protected PolicyHistoryRepository policyHistoryRepository;

    @Inject
    protected PolicyRepository policyRepository;

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    private boolean compare(Rule rule, Rule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null) return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null) return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null) return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getIsCountEnabled() != nRule.getIsCountEnabled()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;
        if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
            return false;
        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getIsHexadecimalType1() != nRule.getIsHexadecimalType1())
            return false;
        if (rule.getIsHexadecimalType2() != nRule.getIsHexadecimalType2())
            return false;
        if (rule.getIsHexadecimalType3() != nRule.getIsHexadecimalType3())
            return false;
        if (rule.getIsHexadecimalType4() != nRule.getIsHexadecimalType4())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }

    /**
     * This method compares oldPolicy with updated policy and builds the diff
     *
     * @param oldPolicy
     * @param newPolicy
     * @return StablenetSLXPolicyDiff
     */
    public StablenetSLXPolicyDiff comparePolicy(Policy oldPolicy, Policy newPolicy) {
        StablenetSLXPolicyDiff policyDiff = new StablenetSLXPolicyDiff();
        if (oldPolicy != null && newPolicy != null) {
            policyDiff.setRouteMapName(newPolicy.getComputedName());

            Set<Flow> newFlows = newPolicy.getFlows();
            Set<Flow> oldFlows = oldPolicy.getFlows();

            List<RuleSet> oldRuleSets = getFlatRuleSets(oldFlows);
            List<RuleSet> newRuleSets = getFlatRuleSets(newFlows);

            findIngressPortsAndSequncesDiff(newPolicy, oldFlows, newFlows, policyDiff, oldRuleSets, newRuleSets);

            setRuleSetTypes(oldRuleSets, newRuleSets, policyDiff);

            findRuleSetDiff(oldRuleSets, newRuleSets, policyDiff);
        }
        return policyDiff;
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    private List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        //
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }


    private void findIngressPortsAndSequncesDiff(Policy newPolicy, Set<Flow> oldFlows, Set<Flow> newFlows, StablenetSLXPolicyDiff policyDiff, List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets) {

        Set<String> oldRuleSetNames = oldRuleSets.stream().map(RuleSet::getName).collect(Collectors.toSet());
        Set<String> newRuleSetNames = newRuleSets.stream().map(RuleSet::getName).collect(Collectors.toSet());

        Set<RuleSet.IpVersion> oldIpVersions = oldRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet());
        Set<RuleSet.IpVersion> newIpVersions = newRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet());

        Set<Long> oldRuleSetIds = oldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> newRuleSetIds = newRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        Set<Long> oldFlowIds = oldFlows.stream().map(Flow::getId).collect(Collectors.toSet());
        Set<Long> newFlowIds = newFlows.stream().map(Flow::getId).collect(Collectors.toSet());

        Set<Port> oldIngressPorts = new HashSet<>();
        Set<Port> newIngressPorts = new HashSet<>();

        Set<PortGroup> oldIngressPortGroups = new HashSet<>();
        Set<PortGroup> newIngressPortGroups = new HashSet<>();

        Set<Port> oldEgressPorts = new HashSet<>();
        Set<Port> newEgressPorts = new HashSet<>();

        Set<PortGroup> oldEgressPortGroups = new HashSet<>();
        Set<PortGroup> newEgressPortGroups = new HashSet<>();

        Map<Integer, Set<String>> oldEgressPortsMap = new HashMap<>();
        Map<Integer, Set<String>> newEgressPortsMap = new HashMap<>();

        Map<Integer, Set<FlowEgressManagedObject>> oldFlowEgressPortsMap = new HashMap<>();
        Map<Integer, Set<FlowEgressManagedObject>> newFlowEgressPortsMap = new HashMap<>();

        Map<Integer, Set<String>> oldEgressPortGroupsMap = new HashMap<>();
        Map<Integer, Set<String>> newEgressPortGroupsMap = new HashMap<>();

        Map<Integer, Set<FlowEgressManagedObject>> oldFlowEgressPortGroupsMap = new HashMap<>();
        Map<Integer, Set<FlowEgressManagedObject>> newFlowEgressPortGroupsMap = new HashMap<>();

        Map<Integer, Set<String>> oldSequenceTvfDomainIdMap = new HashMap<>();
        Map<Integer, Set<String>> newSequenceTvfDomainIdMap = new HashMap<>();
        Map<Long, Flow> updatedFlowDefaultRouteMapDropMap = new HashMap<>();

        Map<Integer, Long> newFlowSeqsIdMap = newFlows.stream().collect(Collectors.toMap(
                e -> e.getSequence(),
                e -> e.getId()));
        Map<Integer, Long> oldFlowSeqsIdMap = oldFlows.stream().collect(Collectors.toMap(
                e -> e.getSequence(),
                e -> e.getId()));

        Map<Integer, RuleSetDiff> flowMap = new HashMap<>();

        // sequence - tvf mapping
        Map<Integer, Set<String>> newTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> oldTvfsMap = new HashMap<>();

        Set<String> newTvfList = new TreeSet<>();
        Set<String> oldTvfList = new TreeSet<>();

        Set<Flow> deletedFlows = new TreeSet<>();
        Set<Flow> addedFlows = new TreeSet<>();
        Set<Flow> updatedFlows = new TreeSet<>();

        Set<Integer> deletedSeqs = new TreeSet<>();
        Set<Integer> addedSeqs = new TreeSet<>();
        Set<Integer> updatedSeqs = new TreeSet<>();

        Map<Integer, Integer> oldDestinationGroupMap = new HashMap<>();
        Map<Integer, Integer> newDestinationGroupMap = new HashMap<>();

        oldFlows.forEach(oldFlow -> {
            /*If old flow id is not present in new flowIds, adding the old flow to deletedFlows*/
            if (!newFlowIds.contains(oldFlow.getId())) {
                deletedFlows.add(oldFlow);
            }

            Long newFlowId = newFlowSeqsIdMap.get(oldFlow.getSequence());
            Long oldFlowId = oldFlowSeqsIdMap.get(oldFlow.getSequence());

            /*If old sequence is not present in new sequences, adding the old sequence to deletedSeqs*/
            if (newFlowId == null || (oldFlowId != null && newFlowId.longValue() != oldFlowId.longValue())) {
                RuleSetDiff ruleSetDiff = new RuleSetDiff();
                ruleSetDiff.setDeletedRuleSets(oldFlow.getRuleSets());
                /*For TVF domain*/
                if (oldFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(oldFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(oldFlow.getVlans());
                }
                ruleSetDiff.setDeletedDestinationMac(oldFlow.getDestinationMacTag());
                if (oldFlow.getPacketTruncationMapping() != null) {
                    ruleSetDiff.setPacketTruncationMapping(oldFlow.getPacketTruncationMapping());
                }
                //ruleSetDiff.setDeletedTunnels(oldFlow.getTunnelPolicies());
                flowMap.put(oldFlow.getSequence(), ruleSetDiff);
                deletedSeqs.add(oldFlow.getSequence());
            } else {
                RuleSetDiff ruleSetDiff = flowMap.get(oldFlow.getSequence());
                if (ruleSetDiff == null) {
                    ruleSetDiff = new RuleSetDiff();
                }
                Set<RuleSet> deletedRuleSet = new TreeSet<>();
                if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    deletedRuleSet.addAll(ruleSetDiff.getDeletedRuleSets());
                }
                oldFlow.getRuleSets().forEach(ruleSet -> {
                    /*If old ruleSet name is not present in new ruleSet names, adding the old ruleSet to deletedRuleSet*/
                    if (oldRuleSetNames.contains(ruleSet.getName()) && !newRuleSetNames.contains(ruleSet.getName())) {
                        if (ruleSet.getType() != RuleSet.Type.L3) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && !newIpVersions.contains(ruleSet.getIpVersion())) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())) {
                            // TODO :: This seems not required
                            deletedRuleSet.add(ruleSet);
                        }
                    }
                    if (oldRuleSetNames.contains(ruleSet.getName()) && newRuleSetNames.contains(ruleSet.getName())) {
                        /*If ruleSet names are same and IP(IPV4/IPV6) versions are changed, adding to deleted ruleSet*/
                        if (oldIpVersions.contains(ruleSet.getIpVersion()) && !newIpVersions.contains(ruleSet.getIpVersion())) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())
                                && oldRuleSetIds.contains(ruleSet.getId()) && !newRuleSetIds.contains(ruleSet.getId())) {
                            /*If ruleSet names are same and IP versions are same, ruleSet is deleted and added back with same data, adding to deleted ruleSet*/
                            deletedRuleSet.add(ruleSet);
                        }
                    }
                });

                ruleSetDiff.setDeletedRuleSets(deletedRuleSet);
                /*For TVF domain*/
                if (oldFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(oldFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(oldFlow.getVlans());
                }
                if (oldFlow.getPacketTruncationMapping() != null) {
                    ruleSetDiff.setPacketTruncationMapping(oldFlow.getPacketTruncationMapping());
                }
                if (!ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    flowMap.put(oldFlow.getSequence(), ruleSetDiff);
                }
            }

            oldEgressPorts.addAll(oldFlow.getEgressPorts().stream().collect(Collectors.toSet()));
            oldEgressPortGroups.addAll(oldFlow.getEgressPortGroups().stream().collect(Collectors.toSet()));

            oldEgressPortsMap.put(oldFlow.getSequence(), oldFlow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
            oldEgressPortGroupsMap.put(oldFlow.getSequence(), oldFlow.getEgressPortGroups().stream().map(PortGroup::getName).collect(Collectors.toSet()));

            oldFlowEgressPortsMap.put(oldFlow.getSequence(), oldFlow.getFlowEgressPorts().stream().collect(Collectors.toSet()));
            oldFlowEgressPortGroupsMap.put(oldFlow.getSequence(), oldFlow.getFlowEgressPortGroups().stream().collect(Collectors.toSet()));

            oldSequenceTvfDomainIdMap.put(oldFlow.getSequence(), oldFlow.getTvfDomain() == true ? oldFlow.getVlans() : null);

            oldDestinationGroupMap.put(oldFlow.getSequence(), oldFlow.getDestinationGroupId());

            /*For TVF domain*/
            if (oldFlow.getTvfDomain()) {
                oldTvfsMap.put(oldFlow.getSequence(), Sets.newHashSet(oldFlow.getVlans()));
                oldTvfList.addAll(oldFlow.getVlans());
            }
        });
        if (!oldFlows.isEmpty()) {
            Flow oldFlow = oldFlows.stream().findFirst().get();
            if (oldFlow != null) {
                oldIngressPorts.addAll(oldFlow.getIngressPorts().stream().collect(Collectors.toSet()));
                oldIngressPortGroups.addAll(oldFlow.getIngressPortGroups().stream().collect(Collectors.toSet()));
            }
        }

        Map<Integer, VlanTaggingStripping> addedUpdatedFlowVlanTaggingStripping = new HashMap<>();
        newFlows.forEach(newFlow -> {
            /*If new flow id is not present in old flowIds, adding the new flow to addedFlows else to updatedFlows*/
            if (!oldFlowIds.contains(newFlow.getId())) {
                addedFlows.add(newFlow);
                //Adding Vlan details for all newly added flows of SLX 18s
                if (isSlx9240Slx9140(newFlow.getPolicy().getDevice())) {
                    VlanTaggingStripping vlanTaggingStripping = new VlanTaggingStripping();
                    vlanTaggingStripping.setSequence(newFlow.getSequence());
                    vlanTaggingStripping.setValnStrippingUpdated(false);
                    vlanTaggingStripping.setVlanTaggedUpdated(false);
                    vlanTaggingStripping.setTaggedVlanId(newFlow.getTaggedVlanId());
                    vlanTaggingStripping.setIsVlanStrippingOld(null);
                    vlanTaggingStripping.setVlanStripping(newFlow.getVlanStripping());
                    addedUpdatedFlowVlanTaggingStripping.put(newFlow.getSequence(), vlanTaggingStripping);
                }
            } else {
                oldFlows.forEach(flow -> {
                    if (flow.getId() != null && newFlow.getId() != null && flow.getId().longValue() == newFlow.getId().longValue()) {
                        if (flow.getIsDefaultRouteMapDrop() != newFlow.getIsDefaultRouteMapDrop()) {
                            updatedFlowDefaultRouteMapDropMap.put(newFlow.getId(), newFlow);
                        }
                        //Adding VLAN details for all updated or existing flows of SLX 18s
                        if (isSlx9240Slx9140(newFlow.getPolicy().getDevice())) {
                            VlanTaggingStripping vlanTaggingStripping = new VlanTaggingStripping();
                            vlanTaggingStripping.setSequence(flow.getSequence());
                            vlanTaggingStripping.setValnStrippingUpdated(flow.getVlanStripping() != newFlow.getVlanStripping());
                            vlanTaggingStripping.setVlanTaggedUpdated(newFlow.getTaggedVlanId() != flow.getTaggedVlanId());
                            vlanTaggingStripping.setTaggedVlanId(newFlow.getTaggedVlanId());
                            vlanTaggingStripping.setTaggedVlanIdDeleted(flow.getTaggedVlanId());
                            vlanTaggingStripping.setIsVlanStrippingOld(flow.getVlanStripping());
                            vlanTaggingStripping.setVlanStripping(newFlow.getVlanStripping());
                            addedUpdatedFlowVlanTaggingStripping.put(newFlow.getSequence(), vlanTaggingStripping);
                        }
                    }
                });
                updatedFlows.add(newFlow);
            }

            Long newFlowId = newFlowSeqsIdMap.get(newFlow.getSequence());
            Long oldFlowId = oldFlowSeqsIdMap.get(newFlow.getSequence());

            /*If new sequence is not present in old sequences, adding the new sequence to addedSeqs, else to updatedSeqs*/
            if (oldFlowId == null || (newFlowId != null && newFlowId.longValue() != oldFlowId.longValue())) {
                RuleSetDiff ruleSetDiff = flowMap.get(newFlow.getSequence());
                if (ruleSetDiff == null) {
                    ruleSetDiff = new RuleSetDiff();
                }
                ruleSetDiff.setAddedRuleSets(newFlow.getRuleSets());
                ruleSetDiff.setSeqChanged(true);
                /*For TVF domain*/
                if (newFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(newFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(newFlow.getVlans());
                }
                ruleSetDiff.setAddedDestinationMac(newFlow.getDestinationMacTag());
                ruleSetDiff.setAddedTunnels(newFlow.getTunnelPolicies());
                if (newFlow.getPacketTruncationMapping() != null) {
                    ruleSetDiff.setPacketTruncationMapping(newFlow.getPacketTruncationMapping());
                }
                flowMap.put(newFlow.getSequence(), ruleSetDiff);
                addedSeqs.add(newFlow.getSequence());
            } else {
                RuleSetDiff ruleSetDiff = flowMap.get(newFlow.getSequence());
                if (ruleSetDiff == null) {
                    ruleSetDiff = new RuleSetDiff();
                }

                List<Long> newTunnelIds = newFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());

                for (Flow oldFlow : oldFlows) {

                    if (oldFlow.getDestinationMacTag() == null && newFlow.getDestinationMacTag() != null) {
                        ruleSetDiff.setAddedDestinationMac(newFlow.getDestinationMacTag());
                    } else if (oldFlow.getDestinationMacTag() != null && newFlow.getDestinationMacTag() == null) {
                        ruleSetDiff.setDeletedDestinationMac(oldFlow.getDestinationMacTag());
                    } else if (oldFlow.getDestinationMacTag() != null && newFlow.getDestinationMacTag() != null) {
                        if (!oldFlow.getDestinationMacTag().equals(newFlow.getDestinationMacTag())) {
                            ruleSetDiff.setDestinationMacUpdated(true);
                        }
                        ruleSetDiff.setUpdatedDestinationMac(newFlow.getDestinationMacTag());
                    }

                    if (oldFlow.getSequence().equals(newFlow.getSequence()) && !oldFlow.getId().equals(newFlow.getId())) {
                        if (ruleSetDiff.getDeletedRuleSets() != null) {
                            ruleSetDiff.getDeletedRuleSets().addAll(oldFlow.getRuleSets());
                        } else {
                            ruleSetDiff.setDeletedRuleSets(oldFlow.getRuleSets());
                        }
                        ruleSetDiff.setSeqChanged(true);

                        break;
                    } else if (oldFlow.getSequence().equals(newFlow.getSequence()) && oldFlow.getId().equals(newFlow.getId())) {
                        List<Long> oldTunnelIds = oldFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());

                        List<TunnelDevicePolicy> deletedTunnels = Lists.newArrayList();
                        List<TunnelDevicePolicy> addedTunnels = Lists.newArrayList();
                        List<TunnelDevicePolicy> updatedTunnels = Lists.newArrayList();
                        // deleted tunnels
                        oldFlow.getTunnelPolicies().forEach(oldTunnel -> {
                            if (!newTunnelIds.contains(oldTunnel.getId())) {
                                deletedTunnels.add(oldTunnel);
                            }
                        });

                        newFlow.getTunnelPolicies().forEach(newTunnel -> {
                            if (!oldTunnelIds.contains(newTunnel.getId())) { /* Added tunnels*/
                                addedTunnels.add(newTunnel);
                            } else { /* updated tunnels*/
                                updatedTunnels.add(newTunnel);
                            }
                        });

                        //Below code is to make sure order of selection is maintained
                        if (newTunnelIds.size() == oldTunnelIds.size()) {
                            for (int i = 0; i < oldTunnelIds.size(); i++) {
                                if (!oldTunnelIds.get(i).equals(newTunnelIds.get(i))) {
                                    ruleSetDiff.setNewFlowTunnels(newFlow.getTunnelPolicies());
                                    ruleSetDiff.setOldFlowTunnels(oldFlow.getTunnelPolicies());
                                    break;
                                }
                            }
                        }

                        ruleSetDiff.setDeletedTunnels(deletedTunnels);
                        ruleSetDiff.setAddedTunnels(addedTunnels);
                        if (!ruleSetDiff.getAddedTunnels().isEmpty()) {
                            ruleSetDiff.setNewFlowTunnels(newFlow.getTunnelPolicies());
                            ruleSetDiff.setOldFlowTunnels(oldFlow.getTunnelPolicies());
                        }
                        ruleSetDiff.setUpdatedTunnels(updatedTunnels);
                        break;
                    }
                    if (oldFlow.getPacketTruncationMapping() != null) {
                        ruleSetDiff.setPacketTruncationMapping(oldFlow.getPacketTruncationMapping());
                    }
                    if (oldFlow.getPacketTruncationMapping() == null && newFlow.getPacketTruncationMapping() != null) {
                        ruleSetDiff.setPacketTruncationMapping(newFlow.getPacketTruncationMapping());
                    } else if (oldFlow.getPacketTruncationMapping() != null && newFlow.getPacketTruncationMapping() == null) {
                        ruleSetDiff.setPacketTruncationMapping(oldFlow.getPacketTruncationMapping());
                    } else if (oldFlow.getPacketTruncationMapping() != null && newFlow.getPacketTruncationMapping() != null) {
                        if ((oldFlow.getPacketTruncationMapping().getId() != null && newFlow.getPacketTruncationMapping().getId() != null) && !oldFlow.getPacketTruncationMapping().getId().equals(newFlow.getPacketTruncationMapping().getId())) {
                            ruleSetDiff.setPacketTruncationMapping(newFlow.getPacketTruncationMapping());
                        } else {
                            ruleSetDiff.setPacketTruncationMapping(oldFlow.getPacketTruncationMapping());
                        }
                    }
                }
                Set<RuleSet> updatedRuleSet = new TreeSet<>();
                Set<RuleSet> addedRuleSet = new TreeSet<>();
                if (ruleSetDiff.getAddedRuleSets() != null) {
                    addedRuleSet.addAll(ruleSetDiff.getAddedRuleSets());
                }
                newFlow.getRuleSets().forEach(ruleSet -> {
                    if (oldRuleSetNames.contains(ruleSet.getName()) && newRuleSetNames.contains(ruleSet.getName()) && oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())
                            && oldRuleSetIds.contains(ruleSet.getId()) && newRuleSetIds.contains(ruleSet.getId())) {
                        updatedRuleSet.add(ruleSet);
                    } else { /*If ruleSet names are same and IP versions are same, ruleSet is deleted and added back with same data, adding to added ruleSet*/
                        addedRuleSet.add(ruleSet);
                    }
                });
                /*For TVF domain*/
                if (newFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(newFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(newFlow.getVlans());
                }
                if (newFlow.getPacketTruncationMapping() != null) {
                    ruleSetDiff.setPacketTruncationMapping(newFlow.getPacketTruncationMapping());
                }
                ruleSetDiff.setAddedRuleSets(addedRuleSet);
                ruleSetDiff.setUpdatedRuleSets(updatedRuleSet);
                flowMap.put(newFlow.getSequence(), ruleSetDiff);
                updatedSeqs.add(newFlow.getSequence());
            }

            newEgressPorts.addAll(newFlow.getEgressPorts().stream().collect(Collectors.toSet()));
            newEgressPortGroups.addAll(newFlow.getEgressPortGroups().stream().collect(Collectors.toSet()));

            newEgressPortsMap.put(newFlow.getSequence(), newFlow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
            newEgressPortGroupsMap.put(newFlow.getSequence(), newFlow.getEgressPortGroups().stream().map(PortGroup::getName).collect(Collectors.toSet()));

            newFlowEgressPortsMap.put(newFlow.getSequence(), newFlow.getFlowEgressPorts().stream().collect(Collectors.toSet()));
            newFlowEgressPortGroupsMap.put(newFlow.getSequence(), newFlow.getFlowEgressPortGroups().stream().collect(Collectors.toSet()));

            newSequenceTvfDomainIdMap.put(newFlow.getSequence(), newFlow.getTvfDomain() == true ? newFlow.getVlans() : null);

            newDestinationGroupMap.put(newFlow.getSequence(), newFlow.getDestinationGroupId());

            /*For TVF domain*/
            if (newFlow.getTvfDomain()) {
                newTvfsMap.put(newFlow.getSequence(), Sets.newHashSet(newFlow.getVlans()));
                newTvfList.addAll(newFlow.getVlans());
            }
        });

        if (!newFlows.isEmpty()) {
            Flow newFlow = newFlows.stream().findFirst().get();
            if (newFlow != null) {
                newIngressPorts.addAll(newFlow.getIngressPorts().stream().collect(Collectors.toSet()));
                newIngressPortGroups.addAll(newFlow.getIngressPortGroups().stream().collect(Collectors.toSet()));
            }
        }

        policyDiff.setDeletedSeqs(deletedSeqs);
        policyDiff.setAddedSeqs(addedSeqs);
        policyDiff.setUpdatedSeqs(updatedSeqs);

        policyDiff.setNewEgressPortsMap(newEgressPortsMap);
        policyDiff.setOldEgressPortsMap(oldEgressPortsMap);

        policyDiff.setNewFlowEgressPortsMap(newFlowEgressPortsMap);
        policyDiff.setOldFlowEgressPortsMap(oldFlowEgressPortsMap);

        policyDiff.setNewEgressPortGroupsMap(newEgressPortGroupsMap);
        policyDiff.setOldEgressPortGroupsMap(oldEgressPortGroupsMap);

        policyDiff.setNewFlowEgressPortGroupsMap(newFlowEgressPortGroupsMap);
        policyDiff.setOldFlowEgressPortGroupsMap(oldFlowEgressPortGroupsMap);

        policyDiff.setUpdatedFlowDefaultRouteMapDrop(updatedFlowDefaultRouteMapDropMap);
        policyDiff.setAddedUpdatedFlowVlanTaggingStripping(addedUpdatedFlowVlanTaggingStripping);

        if (newPolicy.getGridPolicySetId() == null) {
            updateTvfDomainIdMap(policyDiff, oldSequenceTvfDomainIdMap, newSequenceTvfDomainIdMap, oldFlowSeqsIdMap, newFlowSeqsIdMap);
        } else {
            updateDestinationGroups(policyDiff, oldDestinationGroupMap, newDestinationGroupMap, oldFlowSeqsIdMap, newFlowSeqsIdMap);
        }

        policyDiff.setFlowMap(flowMap);

        findIngressDiff(oldIngressPorts, newIngressPorts, oldIngressPortGroups, newIngressPortGroups, policyDiff);

        findEgressDiff(oldEgressPorts, newEgressPorts, oldEgressPortGroups, newEgressPortGroups, policyDiff);

        // vlan to out port mapping
        Map<String, Set<String>> vlanToOutPortMap = new HashMap<>();
        // tvf to out port mapping
        Map<String, Set<String>> tvfToOutPortMap = new HashMap<>();

        buildVlanAndTvfOutPortsMap(newPolicy, vlanToOutPortMap, tvfToOutPortMap);

        findTvfDiff(oldFlows, newFlows, oldTvfsMap, newTvfsMap, oldTvfList, newTvfList, tvfToOutPortMap, policyDiff);

    }

    private void updateDestinationGroups(StablenetSLXPolicyDiff policyDiff, Map<Integer, Integer> oldDestinationGroupMap, Map<Integer, Integer> newDestinationGroupMap,
                                         Map<Integer, Long> oldFlowSeqsIdMap, Map<Integer, Long> newFlowSeqsIdMap) {
        Map<Integer, Integer> addedDestinationGroupMap = new HashMap<>();
        Map<Integer, Integer> deletedDestinationGroupMap = new HashMap<>();
        Map<Integer, Integer> exitingDestinationGroupMap = new HashMap<>();
        oldDestinationGroupMap.forEach((sequence, groupId) -> {
            Long newFlowId = newFlowSeqsIdMap.get(sequence);
            Long oldFlowId = oldFlowSeqsIdMap.get(sequence);
            if ((newFlowId != null && newFlowId != oldFlowId) || newDestinationGroupMap.get(sequence) == null || (oldDestinationGroupMap.get(sequence) != null && newDestinationGroupMap.get(sequence) != oldDestinationGroupMap.get(sequence))) {
                deletedDestinationGroupMap.put(sequence, groupId);
            }
        });
        newDestinationGroupMap.forEach((sequence, groupId) -> {
            Integer oldGroupId = oldDestinationGroupMap.get(sequence);
            Integer newGroupId = newDestinationGroupMap.get(sequence);
            Long newFlowId = newFlowSeqsIdMap.get(sequence);
            Long oldFlowId = oldFlowSeqsIdMap.get(sequence);
            if ((newFlowId != null && newFlowId != oldFlowId) || oldDestinationGroupMap.get(sequence) == null || (newDestinationGroupMap.get(sequence) != null && oldDestinationGroupMap.get(sequence) != newDestinationGroupMap.get(sequence))) {
                addedDestinationGroupMap.put(sequence, groupId);
            } else if (oldGroupId != null && newGroupId != null && newGroupId == oldGroupId) {
                exitingDestinationGroupMap.put(sequence, newGroupId);
            }
        });
        policyDiff.setGridPolicy(true);
        policyDiff.setNewDestinationGroupMap(addedDestinationGroupMap);
        policyDiff.setOldDestinationGroupMap(deletedDestinationGroupMap);
        policyDiff.setExitingDestinationGroupMap(exitingDestinationGroupMap);
    }

    private void updateTvfDomainIdMap(StablenetSLXPolicyDiff policyDiff, Map<Integer, Set<String>> oldSequenceTvfDomainIdMap, Map<Integer, Set<String>> newSequenceTvfDomainIdMap,
                                      Map<Integer, Long> oldFlowSeqsIdMap, Map<Integer, Long> newFlowSeqsIdMap) {
        Map<Integer, Set<String>> addedTvfDomainIdMap = new HashMap<>();
        Map<Integer, Set<String>> deletedTvfDomainIdMap = new HashMap<>();
        Map<Integer, Set<String>> exitingTvfDomainIdMap = new HashMap<>();

        oldSequenceTvfDomainIdMap.forEach((sequence, strings) -> {
            Long newFlowId = newFlowSeqsIdMap.get(sequence);
            Long oldFlowId = oldFlowSeqsIdMap.get(sequence);
            if (newSequenceTvfDomainIdMap.get(sequence) == null || (oldSequenceTvfDomainIdMap.get(sequence) != null && newSequenceTvfDomainIdMap.get(sequence) != oldSequenceTvfDomainIdMap.get(sequence)) || (newFlowId != null && oldFlowId != null && newFlowId.longValue() != oldFlowId.longValue())) {
                deletedTvfDomainIdMap.put(sequence, strings);
            }
        });

        newSequenceTvfDomainIdMap.forEach((sequence, strings) -> {
            Long newFlowId = newFlowSeqsIdMap.get(sequence);
            Long oldFlowId = oldFlowSeqsIdMap.get(sequence);
            if (oldSequenceTvfDomainIdMap.get(sequence) == null || (newSequenceTvfDomainIdMap.get(sequence) != null && oldSequenceTvfDomainIdMap.get(sequence) != newSequenceTvfDomainIdMap.get(sequence)) || (newFlowId != null && oldFlowId != null && newFlowId.longValue() != oldFlowId.longValue())) {
                addedTvfDomainIdMap.put(sequence, strings);
            } else if ((newFlowId != null && oldFlowId != null && newFlowId.longValue() == oldFlowId.longValue())) {
                exitingTvfDomainIdMap.put(sequence, strings);
            }
        });

        policyDiff.setNewSequenceTvfDomainIdMap(addedTvfDomainIdMap);
        policyDiff.setExistingSequenceTvfDomainIdMap(exitingTvfDomainIdMap);
        policyDiff.setOldSequenceTvfDomainIdMap(deletedTvfDomainIdMap);
    }

    /**
     * This method builds VLAN/TVF domain to destination port mapping to bind the ports appropriately
     *
     * @param newPolicy
     * @param vlanToOutPortMap
     * @param tvfToOutPortMap
     */
    private void buildVlanAndTvfOutPortsMap(Policy newPolicy, Map<String, Set<String>> vlanToOutPortMap, Map<String, Set<String>> tvfToOutPortMap) {
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(newPolicy.getDevice().getId(), newPolicy.getId());
        activePolicies.addAll(policyRepository.findAllActivePoliciesByDeviceIdNotCurrentPolicy(newPolicy.getDevice().getId(), newPolicy.getId()));

        // Collecting the destination ports from active policies(excluding the current policy) on the device
        activePolicies.forEach(activePolicy -> {
            activePolicy.getFlows().forEach(flow -> {
                if (flow.getTvfDomain()) {
                    flow.getVlans().forEach(tvfId -> {
                        Set<String> outPorts;
                        if (tvfToOutPortMap.containsKey(tvfId)) {
                            outPorts = tvfToOutPortMap.get(tvfId);
                        } else {
                            outPorts = new HashSet<>();
                        }
                        outPorts.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                        outPorts.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                        tvfToOutPortMap.put(tvfId, outPorts);
                    });
                } else {
                    flow.getVlans().forEach(vlandId -> {
                        Set<String> outPorts;
                        if (vlanToOutPortMap.containsKey(vlandId)) {
                            outPorts = vlanToOutPortMap.get(vlandId);
                        } else {
                            outPorts = new HashSet<>();
                        }
                        outPorts.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                        outPorts.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                        vlanToOutPortMap.put(vlandId, outPorts);
                    });
                }
            });
        });
    }

    /**
     * This method builds the source ports diff between old policy and updated policy
     *
     * @param oldIngressPorts
     * @param newIngressPorts
     * @param oldIngressPortGroups
     * @param newIngressPortGroups
     * @param policyDiff
     */
    private void findIngressDiff(Set<Port> oldIngressPorts, Set<Port> newIngressPorts, Set<PortGroup> oldIngressPortGroups, Set<PortGroup> newIngressPortGroups, StablenetSLXPolicyDiff policyDiff) {
        // Ingress ports
        Set<Long> oldPortIds = oldIngressPorts.stream().map(Port::getId).collect(Collectors.toSet());
        Set<Long> newPortIds = newIngressPorts.stream().map(Port::getId).collect(Collectors.toSet());

        // Ingress port-channel
        Set<Long> oldPortChannelIds = oldIngressPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());
        Set<Long> newPortChannelIds = newIngressPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());

        Set<Port> deletedPorts = new TreeSet<>();
        Set<Port> addedPorts = new TreeSet<>();
        Set<Port> unchangedPorts = new TreeSet<>();

        Set<PortGroup> deletedPortChannels = new HashSet<>();
        Set<PortGroup> addedPortChannels = new HashSet<>();
        Set<PortGroup> unchangedPortChannels = new HashSet<>();

        // deleted ingressports
        oldIngressPorts.forEach(oldPort -> {
            if (!newPortIds.contains(oldPort.getId())) {
                deletedPorts.add(oldPort);
            }
        });

        // added rulesets
        newIngressPorts.forEach(newPort -> {
            if (!oldPortIds.contains(newPort.getId())) {
                addedPorts.add(newPort);
            } else {
                unchangedPorts.add(newPort);
            }
        });

        // deleted ingress port groups
        oldIngressPortGroups.forEach(oldPort -> {
            if (!newPortChannelIds.contains(oldPort.getId())) {
                deletedPortChannels.add(oldPort);
            }
        });

        // added/unchanged ingress port groups
        newIngressPortGroups.forEach(newPort -> {
            if (!oldPortChannelIds.contains(newPort.getId())) {
                addedPortChannels.add(newPort);
            } else {
                unchangedPortChannels.add(newPort);
            }
        });

        policyDiff.setDeletedIngressPorts(deletedPorts);
        policyDiff.setAddedIngressPorts(addedPorts);
        policyDiff.setUnchangedIngressPorts(unchangedPorts);

        policyDiff.setDeletedIngressPortChannels(deletedPortChannels);
        policyDiff.setAddedIngressPortChannels(addedPortChannels);
        policyDiff.setUnchangedIngressPortChannels(unchangedPortChannels);
    }

    /**
     * This method builds the destination ports diff between old policy and updated policy
     *
     * @param oldEgressPorts
     * @param newEgressPorts
     * @param oldEgressPortGroups
     * @param newEgressPortGroups
     * @param policyDiff
     */
    private void findEgressDiff(Set<Port> oldEgressPorts, Set<Port> newEgressPorts, Set<PortGroup> oldEgressPortGroups, Set<PortGroup> newEgressPortGroups, StablenetSLXPolicyDiff policyDiff) {
        // Egress ports
        Set<Long> oldPortIds = oldEgressPorts.stream().map(Port::getId).collect(Collectors.toSet());
        Set<Long> newPortIds = newEgressPorts.stream().map(Port::getId).collect(Collectors.toSet());

        // Egress port-channel
        Set<Long> oldPortChannelIds = oldEgressPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());
        Set<Long> newPortChannelIds = newEgressPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());

        Set<Port> deletedPorts = new TreeSet<>();
        Set<Port> addedPorts = new TreeSet<>();
        Set<Port> unchangedPorts = new TreeSet<>();

        Set<PortGroup> deletedPortChannels = new HashSet<>();
        Set<PortGroup> addedPortChannels = new HashSet<>();
        Set<PortGroup> unchangedPortChannels = new HashSet<>();

        // deleted egress ports
        oldEgressPorts.forEach(oldPort -> {
            if (!newPortIds.contains(oldPort.getId())) {
                deletedPorts.add(oldPort);
            }
        });

        // added egress ports
        newEgressPorts.forEach(newPort -> {
            if (!oldPortIds.contains(newPort.getId())) {
                addedPorts.add(newPort);
            } else {
                unchangedPorts.add(newPort);
            }
        });

        // deleted egress port groups
        oldEgressPortGroups.forEach(oldPort -> {
            if (!newPortChannelIds.contains(oldPort.getId())) {
                deletedPortChannels.add(oldPort);
            }
        });

        // added/unchanged egress port groups
        newEgressPortGroups.forEach(newPort -> {
            if (!oldPortChannelIds.contains(newPort.getId())) {
                addedPortChannels.add(newPort);
            } else {
                unchangedPortChannels.add(newPort);
            }
        });

        policyDiff.setDeletedEgressPorts(deletedPorts);
        policyDiff.setAddedEgressPorts(addedPorts);
        policyDiff.setUnchangedEgressPorts(unchangedPorts);

        policyDiff.setDeletedEgressPortChannels(deletedPortChannels);
        policyDiff.setAddedEgressPortChannels(addedPortChannels);
        policyDiff.setUnchangedEgressPortChannels(unchangedPortChannels);
    }


    /**
     * This method builds TVF domain diff between old policy and updated policy
     *
     * @param oldFlows
     * @param newFlows
     * @param oldTvfsMap
     * @param newTvfsMap
     * @param oldTvfList
     * @param newTvfList
     * @param tvfToOutPortMap
     * @param policyDiff
     */
    private void findTvfDiff(Set<Flow> oldFlows,
                             Set<Flow> newFlows,
                             Map<Integer, Set<String>> oldTvfsMap,
                             Map<Integer, Set<String>> newTvfsMap,
                             Set<String> oldTvfList,
                             Set<String> newTvfList, Map<String,
            Set<String>> tvfToOutPortMap,
                             StablenetSLXPolicyDiff policyDiff) {

        // sequence to TVFs mapping
        Map<Integer, Set<String>> deletedTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> addedTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> updatedTvfsMap = new HashMap<>();

        List<String> deletedTvfList = new ArrayList<>();
        List<String> addedTvfList = new ArrayList<>();
        List<String> updatedTvfList = new ArrayList<>();

        oldTvfList.forEach(oldTvf -> {
            if (!newTvfList.contains(oldTvf)) {
                deletedTvfList.add(oldTvf);
            }
        });

        newTvfList.forEach(newTvf -> {
            if (!oldTvfList.contains(newTvf)) {
                addedTvfList.add(newTvf);
            } else {
                updatedTvfList.add(newTvf);
            }
        });

        oldTvfsMap.forEach((sequence, oldTvfs) -> {
            Set<String> newTvfs = newTvfsMap.get(sequence) != null ? newTvfsMap.get(sequence) : Sets.newHashSet();
            Set<String> deletedTvfs = new HashSet<>();
            oldTvfs.forEach(oldTvf -> {
                if (!newTvfs.contains(oldTvf)) {
                    deletedTvfs.add(oldTvf);
                }
            });
            deletedTvfsMap.put(sequence, deletedTvfs);
        });

        newTvfsMap.forEach((sequence, newTvfs) -> {
            Set<String> oldTvfs = oldTvfsMap.get(sequence) != null ? oldTvfsMap.get(sequence) : Sets.newHashSet();
            Set<String> addedTvfs = new HashSet<>();
            Set<String> updatedTvfs = new HashSet<>();
            newTvfs.forEach(newTvf -> {
                if (!oldTvfs.contains(newTvf)) {
                    addedTvfs.add(newTvf);
                } else {
                    updatedTvfs.add(newTvf);
                }
            });
            addedTvfsMap.put(sequence, addedTvfs);
            updatedTvfsMap.put(sequence, updatedTvfs);
        });

        // building old tvfs to destination port mapping
        Map<String, Set<String>> oldTvfEgressMap = new HashMap<>();
        Map<String, Set<String>> oldTvfEgressPortChannelMap = new HashMap<>();
        Map<Long, Set<String>> oldEgressMap = new HashMap<>();
        oldFlows.forEach(oldFlow -> {
            if (oldFlow.getTvfDomain()) {
                oldFlow.getVlans().forEach(oldTvf -> {
                    Set<String> egressUnmap;
                    if (oldTvfEgressMap.get(oldTvf) == null) {
                        egressUnmap = new HashSet<>();
                    } else {
                        egressUnmap = oldTvfEgressMap.get(oldTvf);
                    }
                    Set<String> egressPortChannelMap;
                    if (oldTvfEgressPortChannelMap.get(oldTvf) == null) {
                        egressPortChannelMap = new HashSet<>();
                    } else {
                        egressPortChannelMap = oldTvfEgressPortChannelMap.get(oldTvf);
                    }

                    Set<String> outPorts = new HashSet<>();
                    if (tvfToOutPortMap.containsKey(oldTvf)) {
                        outPorts = tvfToOutPortMap.get(oldTvf);
                    }
                    for (Port port : oldFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressUnmap.add(port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : oldFlow.getEgressPortGroups()) {
                        egressPortChannelMap.add(portGroup.getName());
                    }
                    oldTvfEgressMap.put(oldTvf, egressUnmap);
                    oldTvfEgressPortChannelMap.put(oldTvf, egressPortChannelMap);
                });
            }
            oldEgressMap.put(oldFlow.getId(), oldFlow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
        });

        // building new/updated tvfs to destination port mapping
        Map<String, Set<String>> newTvfEgressMap = new HashMap<>();
        Map<String, Set<String>> newTvfEgressPortChannelMap = new HashMap<>();
        Map<Long, Set<String>> newEgressMap = new HashMap<>();
        newFlows.forEach(newFlow -> {
            if (newFlow.getTvfDomain()) {
                newFlow.getVlans().forEach(newTvf -> {
                    Set<String> egressMap;
                    if (newTvfEgressMap.get(newTvf) == null) {
                        egressMap = new HashSet<>();
                    } else {
                        egressMap = newTvfEgressMap.get(newTvf);
                    }

                    Set<String> egressPortChannelMap;
                    if (newTvfEgressPortChannelMap.get(newTvf) == null) {
                        egressPortChannelMap = new HashSet<>();
                    } else {
                        egressPortChannelMap = newTvfEgressPortChannelMap.get(newTvf);
                    }

                    Set<String> outPorts = new HashSet<>();
                    if (tvfToOutPortMap.containsKey(newTvf)) {
                        outPorts = tvfToOutPortMap.get(newTvf);
                    }
                    for (Port port : newFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressMap.add(port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : newFlow.getEgressPortGroups()) {
                        egressPortChannelMap.add(portGroup.getName());
                    }
                    newTvfEgressMap.put(newTvf, egressMap);
                    newTvfEgressPortChannelMap.put(newTvf, egressPortChannelMap);
                });
            }
            newEgressMap.put(newFlow.getId(), newFlow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
        });

        TvfDiff tvfDiff = new TvfDiff();
        tvfDiff.setOldTvfMap(oldTvfEgressMap);
        tvfDiff.setNewTvfMap(newTvfEgressMap);
        tvfDiff.setOldTvfPortChannelMap(oldTvfEgressPortChannelMap);
        tvfDiff.setNewTvfPortChannelMap(newTvfEgressPortChannelMap);
        tvfDiff.setDeletedTvfsMap(deletedTvfsMap);
        tvfDiff.setAddedTvfsMap(addedTvfsMap);
        tvfDiff.setUpdatedTvfsMap(updatedTvfsMap);
        tvfDiff.setDeletedTvfs(deletedTvfList);
        tvfDiff.setAddedTvfs(addedTvfList);
        tvfDiff.setUpdatedTvfs(updatedTvfList);
        policyDiff.setTvfDiff(tvfDiff);
    }

    /**
     * This method is used to find the diff between oldRuleSets and newRuleSets and populate policyDiff
     *
     * @param oldRuleSets
     * @param newRuleSets
     * @param policyDiff
     */
    private void setRuleSetTypes(List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets, StablenetSLXPolicyDiff policyDiff) {
        Set<RuleSet.Type> oldRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.IpVersion> oldRuleSetIpList = Sets.newHashSet();

        oldRuleSetTypeList.addAll(oldRuleSets.stream().map(RuleSet::getType).collect(Collectors.toSet()));
        oldRuleSetIpList.addAll(oldRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));

        Map<Long, RuleSet.Type> oldRuleSetIdTypeMap = new HashMap<>();
        Map<Long, RuleSet.IpVersion> oldRuleSetIdIpVersionMap = new HashMap<>();
        oldRuleSets.forEach(ruleSet -> {
            if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) { /* MAC/UDA */
                oldRuleSetIdTypeMap.put(ruleSet.getId(), ruleSet.getType());
            } else if (ruleSet.getIpVersion() != null) { /* IPV4/IPV6*/
                oldRuleSetIdIpVersionMap.put(ruleSet.getId(), ruleSet.getIpVersion());
            }
        });

        Map<Long, RuleSet.Type> newRuleSetIdTypeMap = new HashMap<>();
        Map<Long, RuleSet.IpVersion> newRuleSetIdIpVersionMap = new HashMap<>();
        newRuleSets.forEach(ruleSet -> {
            if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) { /* MAC/UDA */
                newRuleSetIdTypeMap.put(ruleSet.getId(), ruleSet.getType());
            } else if (ruleSet.getIpVersion() != null) { /* IPV4/IPV6*/
                newRuleSetIdIpVersionMap.put(ruleSet.getId(), ruleSet.getIpVersion());
            }
        });

        Set<RuleSet.Type> newRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.IpVersion> newRuleSetIpList = Sets.newHashSet();

        newRuleSetTypeList.addAll(newRuleSets.stream().map(RuleSet::getType).collect(Collectors.toSet()));
        newRuleSetIpList.addAll(newRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));

        Set<RuleSet.Type> deletedRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.Type> addedRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.Type> updatedRuleSetTypeList = Sets.newHashSet();

        /* Start MAC/UDA */
        oldRuleSetIdTypeMap.forEach((ruleSetId, oldType) -> {
            RuleSet.Type newType = newRuleSetIdTypeMap.get(ruleSetId);
            if (newType != null && newType != oldType) {
                deletedRuleSetTypeList.add(oldType);
            } else if (newType == null) {
                deletedRuleSetTypeList.add(oldType);
            }
        });

        newRuleSetIdTypeMap.forEach((ruleSetId, newType) -> {
            RuleSet.Type oldType = oldRuleSetIdTypeMap.get(ruleSetId);
            if (oldType != null && oldType != newType) {
                addedRuleSetTypeList.add(newType);
            } else if (oldType == null) {
                addedRuleSetTypeList.add(newType);
            } else {
                updatedRuleSetTypeList.add(newType);
            }
        });

        updatedRuleSetTypeList.forEach(type -> {
            if (!deletedRuleSetTypeList.isEmpty() && deletedRuleSetTypeList.contains(type)) {
                deletedRuleSetTypeList.remove(type);
            }
            if (!addedRuleSetTypeList.isEmpty() && addedRuleSetTypeList.contains(type)) {
                addedRuleSetTypeList.remove(type);
            }
        });
        /* End MAC/UDA */

        Set<RuleSet.IpVersion> deletedRuleSetIpList = Sets.newHashSet();
        Set<RuleSet.IpVersion> addedRuleSetIpList = Sets.newHashSet();
        Set<RuleSet.IpVersion> updatedRuleSetIpList = Sets.newHashSet();

        /* Start IPV4/IPV6*/
        oldRuleSetIdIpVersionMap.forEach((ruleSetId, oldIpVersion) -> {
            RuleSet.IpVersion newIpVersion = newRuleSetIdIpVersionMap.get(ruleSetId);
            if (newIpVersion != null && newIpVersion != oldIpVersion) {
                deletedRuleSetIpList.add(oldIpVersion);
            } else if (newIpVersion == null) {
                deletedRuleSetIpList.add(oldIpVersion);
            }
        });

        newRuleSetIdIpVersionMap.forEach((ruleSetId, newIpVersion) -> {
            RuleSet.IpVersion oldIpVersion = oldRuleSetIdIpVersionMap.get(ruleSetId);
            if (oldIpVersion != null && oldIpVersion != newIpVersion) {
                addedRuleSetIpList.add(newIpVersion);
            } else if (oldIpVersion == null) {
                addedRuleSetIpList.add(newIpVersion);
            } else {
                updatedRuleSetIpList.add(newIpVersion);
            }
        });

        updatedRuleSetIpList.forEach(type -> {
            if (!deletedRuleSetIpList.isEmpty() && deletedRuleSetIpList.contains(type)) {
                deletedRuleSetIpList.remove(type);
            }
            if (!addedRuleSetIpList.isEmpty() && addedRuleSetIpList.contains(type)) {
                addedRuleSetIpList.remove(type);
            }
        });
        /* End IPV4/IPV6*/

        policyDiff.setDeletedRuleSetTypeList(deletedRuleSetTypeList);
        policyDiff.setDeletedRuleSetIpList(deletedRuleSetIpList);

        policyDiff.setUpdatedRuleSetTypeList(updatedRuleSetTypeList);
        policyDiff.setUpdatedRuleSetIpList(updatedRuleSetIpList);

        policyDiff.setAddedRuleSetTypeList(addedRuleSetTypeList);
        policyDiff.setAddedRuleSetIpList(addedRuleSetIpList);
    }

    /**
     * This method finds the diff between old ruleSets and updated ruleSets
     *
     * @param oldRuleSets
     * @param newRuleSets
     * @param policyDiff
     */
    private void findRuleSetDiff(List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets, StablenetSLXPolicyDiff policyDiff) {
        Set<Long> oldRuleSetIds = oldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> newRuleSetIds = newRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        List<RuleSet> deletedRuleSets = new ArrayList<>();
        List<RuleSet> addedRuleSets = new ArrayList<>();

        List<RuleSet> updatedOldRuleSets = new ArrayList<>();
        List<RuleSet> updatedNewRuleSets = new ArrayList<>();

        oldRuleSets.forEach(oldRuleSet -> {
            // deleted rulesets
            if (!newRuleSetIds.contains(oldRuleSet.getId())) {
                deletedRuleSets.add(oldRuleSet);
            } else {
                updatedOldRuleSets.add(oldRuleSet);
            }
        });

        // added rulesets
        newRuleSets.forEach(newRuleSet -> {
            if (!oldRuleSetIds.contains(newRuleSet.getId())) {
                addedRuleSets.add(newRuleSet);
            } else {
                addedRuleSets.add(newRuleSet);
                deletedRuleSets.add(newRuleSet);
                updatedNewRuleSets.add(newRuleSet);
            }
        });

        Set<Long> updatedOldRuleSetIds = updatedOldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> updatedNewRuleSetIds = updatedNewRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        /* MAC/UDA to list of RuleDiff*/
        Map<RuleSet.Type, List<RuleDiff>> ruleSetTypeDiffMap = new HashMap<>();

        /* IPV4/IPV6 to list of RuleDiff*/
        Map<RuleSet.IpVersion, List<RuleDiff>> ruleIpVersionDiffMap = new HashMap<>();

        updatedOldRuleSets.forEach(ruleSet -> {
            if (updatedNewRuleSetIds.contains(ruleSet.getId())) {
                List<RuleDiff> ruleDiffs = null;
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleDiffs = ruleSetTypeDiffMap.get(ruleSet.getType());
                } else {
                    ruleDiffs = ruleIpVersionDiffMap.get(ruleSet.getIpVersion());
                }
                if (ruleDiffs == null) {
                    ruleDiffs = new ArrayList<>();
                }
                RuleDiff ruleDiff = new RuleDiff();
                List<Rule> rules = new ArrayList<>();
                rules.addAll(ruleSet.getRules());
                ruleDiff.setOldRules(rules);
                ruleDiff.setRuleSet(ruleSet);
                ruleDiffs.add(ruleDiff);
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleSetTypeDiffMap.put(ruleSet.getType(), ruleDiffs);
                } else {
                    ruleIpVersionDiffMap.put(ruleSet.getIpVersion(), ruleDiffs);
                }
            }
        });

        updatedNewRuleSets.forEach(ruleSet -> {
            if (updatedOldRuleSetIds.contains(ruleSet.getId())) {
                List<RuleDiff> ruleDiffList = null;
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleDiffList = ruleSetTypeDiffMap.get(ruleSet.getType());
                } else {
                    ruleDiffList = ruleIpVersionDiffMap.get(ruleSet.getIpVersion());
                }

                List<RuleDiff> ruleDiffs = new ArrayList<>();
                ruleDiffList.forEach(ruleDiff -> {
                    if (ruleDiff.getRuleSet() != null && ruleDiff.getRuleSet().getId().equals(ruleSet.getId())) {
                        List<Rule> rules = new ArrayList<>();
                        rules.addAll(ruleSet.getRules());
                        ruleDiff.setNewRules(rules);
                        ruleDiff.setRuleSet(ruleSet);
                    }
                    ruleDiffs.add(ruleDiff);
                });

                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleSetTypeDiffMap.put(ruleSet.getType(), ruleDiffs);
                } else {
                    ruleIpVersionDiffMap.put(ruleSet.getIpVersion(), ruleDiffs);
                }
            }
        });

        Set<Long> updatedRuleIds = new HashSet<>();
        Set<Long> addedRuleIds = new HashSet<>();
        Set<Long> deletedRuleIds = new HashSet<>();
        Set<RuleSet.Type> ruleSetsTypeToUnmap = new HashSet<>();
        Set<RuleSet.IpVersion> ruleSetsIpVersionToUnmap = new HashSet<>();
        ruleSetTypeDiffMap.forEach((type, ruleDiffs) -> {
            ruleDiffs.forEach(ruleDiff -> {
                if (ruleDiff != null && ruleDiff.getOldRules() != null && ruleDiff.getNewRules() != null) {
                    findRuleDiff(ruleDiff.getOldRules(), ruleDiff.getNewRules(), ruleDiff, addedRuleIds, updatedRuleIds, deletedRuleIds);
                }
                if ((ruleDiff.getDeletedRules() != null && !ruleDiff.getDeletedRules().isEmpty()) || (ruleDiff.getAddedRules() != null && !ruleDiff.getAddedRules().isEmpty())) {
                    ruleSetsTypeToUnmap.add(type);
                }
            });
        });

        ruleIpVersionDiffMap.forEach((ipVersion, ruleDiffs) -> {
            ruleDiffs.forEach(ruleDiff -> {
                if (ruleDiff != null && ruleDiff.getOldRules() != null && ruleDiff.getNewRules() != null) {
                    findRuleDiff(ruleDiff.getOldRules(), ruleDiff.getNewRules(), ruleDiff, addedRuleIds, updatedRuleIds, deletedRuleIds);
                }
                if (!ruleDiff.getDeletedRules().isEmpty() || !ruleDiff.getAddedRules().isEmpty()) {
                    ruleSetsIpVersionToUnmap.add(ipVersion);
                }
            });
        });

        policyDiff.setRuleSetsTypeToUnmap(ruleSetsTypeToUnmap);
        policyDiff.setRuleSetsIpVersionToUnmap(ruleSetsIpVersionToUnmap);

        policyDiff.setRuleSetTypeMap(ruleSetTypeDiffMap);
        policyDiff.setRuleSetIpVersionMap(ruleIpVersionDiffMap);

        policyDiff.setRulesDeletedForPolicy(!deletedRuleIds.isEmpty() ? true : false);
        policyDiff.setRulesAddedForPolicy(!addedRuleIds.isEmpty() ? true : false);
        policyDiff.setRulesUpdatedForPolicy(!updatedRuleIds.isEmpty() ? true : false);
    }

    /**
     * This method fetches all the rules from multiple flows
     *
     * @param flows
     * @return List<RuleSet> of all rules across multiple flows
     */
    private List<RuleSet> getFlatRuleSets(Set<Flow> flows) {
        List<RuleSet> ruleSets = new ArrayList<>();
        flows.forEach(flow -> {
            ruleSets.addAll(flow.getRuleSets());
        });
        return ruleSets;
    }

    /**
     * This method finds the diff between old rules and updated rules
     *
     * @param oRuleList
     * @param nRuleList
     * @param ruleDiff
     * @param addedRuleIds
     * @param updatedRuleIds
     * @param deletedRuleIds
     */
    private void findRuleDiff(List<Rule> oRuleList, List<Rule> nRuleList, RuleDiff ruleDiff, Set<Long> addedRuleIds, Set<Long> updatedRuleIds, Set<Long> deletedRuleIds) {
        Set<Long> updateRuleIds = nRuleList.stream().map(Rule::getId).collect(Collectors.toSet());
        Set<Long> oldRuleIds = oRuleList.stream().map(Rule::getId).collect(Collectors.toSet());

        List<Rule> deletedRules = new ArrayList<>();
        List<Rule> addedRules = new ArrayList<>();
        //Deleted rules
        oRuleList.forEach(oldRule -> {
            if (!updateRuleIds.contains(oldRule.getId())) {
                deletedRules.add(oldRule);
                deletedRuleIds.add(oldRule.getId());
            }
        });

        nRuleList.forEach(newRule -> {
            //Added rules
            if (!oldRuleIds.contains(newRule.getId())) {
                addedRules.add(newRule);
                addedRuleIds.add(newRule.getId());
            } else {
                //Updated rules
                Rule oldRule = oRuleList.stream().filter(rule -> rule.getId().equals(newRule.getId())).findFirst().orElse(null);
                if (oldRule != null) {
                    if (!compare(oldRule, newRule)) {
                        addedRules.add(newRule);
                        deletedRules.add(oldRule);
                        addedRuleIds.add(newRule.getId());
                        deletedRuleIds.add(oldRule.getId());
                        updatedRuleIds.add(oldRule.getId());
                    }
                }
            }
        });
        ruleDiff.setDeletedRules(deletedRules);
        ruleDiff.setAddedRules(addedRules);
    }

    protected boolean isSlx9240Slx9140(Device device) {
        return (device.getType() == Device.Type.SLX && device.getModel() != null && (device.getModel().contains(FlexMatchProfile.SLX_9140) || device.getModel().contains(FlexMatchProfile.SLX_9240)));

    }
}
