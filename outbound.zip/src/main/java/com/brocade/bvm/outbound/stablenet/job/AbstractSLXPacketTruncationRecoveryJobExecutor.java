package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public abstract class AbstractSLXPacketTruncationRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    protected static final String ETHERNET = "Ethernet";

    protected static final String PORT_CHANNEL = "Port-channel";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_TRUNCATION_ROLLBACK);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
