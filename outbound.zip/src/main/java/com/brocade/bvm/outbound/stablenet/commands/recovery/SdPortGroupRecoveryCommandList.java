package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.dao.sessiondirector.EgressPortGroupHistoryRepository;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

public class SdPortGroupRecoveryCommandList {

    @Inject
    private EgressPortGroupHistoryRepository portGroupHistoryRepository;

    private List<CommandBlock> commandBlocks = new ArrayList<>();

    public List<CommandBlock> constructCommandBlockList(SdPortGroup sdPortGroup) {
        DeletePortGroupCommandBlock deletePortGroupCommandBlock = new DeletePortGroupCommandBlock();
        deletePortGroupCommandBlock.setDeviceId(sdPortGroup.getDevice().getStablenetId().intValue());
        deletePortGroupCommandBlock.setName(sdPortGroup.getName());
        commandBlocks.add(deletePortGroupCommandBlock);

        if (!commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("false");
        }
        return commandBlocks;
    }
}
