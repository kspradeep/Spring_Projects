package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.PortHistory;
import com.brocade.bvm.outbound.utility.GenericOutboundHelper;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

/**
 * The StablenetSLXPortTypeJobExecutor class enable/disable the LLDP on the selected ports.
 */
@Named
public class StablenetSLXPortTypeJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private PortHistoryRepository portHistoryRepository;

    @Inject
    protected GenericOutboundHelper genericOutboundHelper;

    private static final String INTERFACE_ETHERNET = "interface ethernet %s;";

    private static final String LLDP_DISABLE = "lldp disable;";

    private static final String LOOP_BACK_ENABLED = "loopback phy;";

    private static final String LOOP_BACK_DISABLED = "no loopback phy;";

    private static final String NO_LLDP_DISABLE = "no lldp disable;";

    /**
     * This method constructs commands to enable/disable the LLDP on the selected ports.
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        boolean isLoopBackSupported = genericOutboundHelper.isSlxLoopBackSupported(job.getDevice());
        getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .forEach(port -> {
                    commands.append(String.format(INTERFACE_ETHERNET, port.getPortNumber()));
                    List<PortHistory> portHistories = portHistoryRepository.findTop1ByParentIdAndWorkflowStatusOrderByRevisionTimeDesc(port.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
                    if (portHistories != null && !portHistories.isEmpty()) {
                        PortHistory portHistory = portHistories.get(0);
                        if (isLoopBackSupported && portHistory.isLoopBackEnabled()) {
                            commands.append(SHUTDOWN);
                            commands.append(LOOP_BACK_DISABLED);
                            commands.append(NO_SHUTDOWN);
                        }
                    }
                    if (Job.Type.PORT_MARK_INGRESS_GRID == job.getType() || Job.Type.PORT_MARK_EGRESS_GRID == job.getType()) {
                        commands.append(LLDP_DISABLE);
                    }
                    if (Port.Type.NONE == port.getType() || Job.Type.PORT_MARK_NONE_GRID == job.getType()) {
                        commands.append(NO_LLDP_DISABLE);
                    }
                    if (isLoopBackSupported && Port.Type.SERVICE_PORT == port.getType() && port.loopbackEnabled) {
                        commands.append(SHUTDOWN);
                        commands.append(LOOP_BACK_ENABLED);
                        commands.append(NO_SHUTDOWN);
                    }
                    commands.append(EXIT);
                });
        commands.append(EXIT);
        return commands.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_MARK_INGRESS, Job.Type.PORT_MARK_EGRESS, Job.Type.PORT_MARK_NONE, Job.Type.PORT_MARK_SERVICE,
                Job.Type.PORT_MARK_INGRESS_GRID, Job.Type.PORT_MARK_EGRESS_GRID, Job.Type.PORT_MARK_NONE_GRID);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
