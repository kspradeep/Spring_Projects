package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.dao.PacketSlicingModulePolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.history.PacketSlicingModulePolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The StablenetPacketSlicingModulePolicyUpdateJobExecutor class implements methods to update PacketSlicingModulePolicy on Non Open Flow device through Stablenet
 */
@Named
@Slf4j
public class StablenetPacketSlicingModulePolicyUpdateJobExecutor extends AbstractPacketSlicingModulePolicyJobExecutor {

    @Inject
    private PacketSlicingModulePolicyHistoryRepository modulePolicyHistoryRepository;

    @Inject
    private ModuleRepository moduleRepository;

    /**
     * This method constructs update PacketSlicingModulePolicy commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketSlicingModulePolicy modulePolicy = (PacketSlicingModulePolicy) getParentObject(job);
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        if (modulePolicy != null) {
            PacketSlicingModulePolicy oldModulePolicy = getPacketSlicingModulePolicyFromHistory(modulePolicy.getId());

            List<Module> oldModules = (List<Module>) moduleRepository.findAll(oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()));

            Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
            Set<Long> newModuleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());

            //removing egress-truncate from unselected modules during edit
            oldModules.forEach(oldModule -> {
                if (!newModuleIds.contains(oldModule.getId())) {
                    command.append(String.format(MODULE_POLICY_REVERT_EGRESS_TRUNCATE_FORMAT, oldModulePolicy.getNumberOfBytes(), oldModule.getModuleNumber()));
                }
            });

            //adding egress-truncate to newly selected modules during edit
            modulePolicy.getModules().forEach(newModule -> {
                if (!oldModuleIds.contains(newModule.getId()) || oldModulePolicy.getNumberOfBytes().intValue() != modulePolicy.getNumberOfBytes().intValue()) {
                    command.append(String.format(MODULE_POLICY_EGRESS_TRUNCATE_FORMAT, modulePolicy.getNumberOfBytes(), newModule.getModuleNumber()));
                }
            });

            Set<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> newPortIds = modulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());

            //removing egress-truncate from unselected ports during edit
            oldModulePolicy.getPorts().forEach(oldPort -> {
                if (!newPortIds.contains(oldPort.getId())) {
                    command.append(String.format(PORT_EGRESS_REVERT_TRUNCATE_FORMAT, oldPort.getPortNumber()));
                }
            });

            //adding egress-truncate to newly selected ports during edit
            modulePolicy.getPorts().forEach(newPort -> {
                if (!oldPortIds.contains(newPort.getId())) {
                    command.append(String.format(PORT_EGRESS_TRUNCATE_FORMAT, newPort.getPortNumber()));
                }
            });
        }
        //command.append(END);
        command.append(WRITE_MEMORY);
        log.trace("Command = " + command.toString());
        return command.toString();
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param latestModulePolicyId
     * @return PacketSlicingModulePolicy returns latest ACTIVE policy
     */
    private PacketSlicingModulePolicy getPacketSlicingModulePolicyFromHistory(Long latestModulePolicyId) {
        List<PacketSlicingModulePolicyHistory> packetSlicingModulePolicyHistoryList = modulePolicyHistoryRepository.findByIdAndWorkflowStatus(latestModulePolicyId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        PacketSlicingModulePolicy modulePolicy = null;
        if (packetSlicingModulePolicyHistoryList.size() >= 1) {
            PacketSlicingModulePolicyHistory packetSlicingModulePolicyHistory = packetSlicingModulePolicyHistoryList.get(0);
            modulePolicy = packetSlicingModulePolicyHistory.buildParent();
        }
        return modulePolicy;
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_SLICING_MODULE_POLICY_UPDATE);
    }
}
