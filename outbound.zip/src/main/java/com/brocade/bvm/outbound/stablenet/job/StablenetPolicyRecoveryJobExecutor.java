package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.outbound.stablenet.commands.recovery.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The StablenetPolicyRecoveryJobExecutor class implements methods to recover policy which is in ERROR state on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetPolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    private static final String IP = "ip";
    private static final String IPV6 = "ipv6";
    private static final String L2 = "l2";
    private static final String UDA = "uda";

    /***
     * Expect #1 route map name #2 is sequence*
     */
    private static final String ROUTE_MAP_WITH_SEQUENCE = "%s permit %s";

    private static final long ROUTE_MAP_CATCH_ALL_SEQUENCE = 999999999;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    protected HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_ROLLBACK);
    }

    /**
     * This method constructs policy recovery command blocks to be executed on the given device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        Policy policyToDelete = (Policy) getParentObject(job);
        log.debug("PolicyRecovery Job executor for policy id {}", policyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(policyToDelete);
        log.debug("Number of command blocks constructed for policy id {} is :{}", policyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs policy recovery command blocks for the given policy
     *
     * @param policyToDelete
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(Policy policyToDelete) {
        List<CommandBlock> finalCommandBlocks = new ArrayList<>();
        //Created LinkedHashSet to remove duplicate command blocks and maintain insertion order
        Set<CommandBlock> finalCommandBlocksSet = new LinkedHashSet<>();
        //This is to check if it's a save/commit over commit scenario, then recover the last committed policy first.
        Policy policyFromHistory = getPolicyFromHistory(policyToDelete);
        HeaderStrippingModulePolicy headerStrippingModulePolicy = null;
        if ((policyFromHistory != null && policyFromHistory.isPreserveHeader()) || (policyToDelete != null && policyToDelete.isPreserveHeader())) {
            List<HeaderStrippingModulePolicy> headerStrippingModulePolicies = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(policyToDelete.getDevice().getId());
            if (headerStrippingModulePolicies != null && !headerStrippingModulePolicies.isEmpty()) {
                headerStrippingModulePolicy = headerStrippingModulePolicies.stream().findFirst().get();
            }
        }
        String routeMapName = null;
        if (policyFromHistory != null && policyFromHistory.getComputedName() != null) {
            routeMapName = policyFromHistory.getComputedName();
        } else if (policyToDelete != null && policyToDelete.getComputedName() != null) {
            routeMapName = policyToDelete.getComputedName();
        }
        Integer replaceVlanId = 0;
        Long intermediatePortId = null;
        if (headerStrippingModulePolicy != null && headerStrippingModulePolicy.getStripHeaders() != null && !headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
            intermediatePortId = headerStrippingModulePolicy.getIntermediatePortId();
            routeMapName = getRmOrL2AclName(headerStrippingModulePolicy.getStripHeaders().stream().findFirst().get());
            replaceVlanId = headerStrippingModulePolicy.getReplaceVlan();
        }

        if (policyFromHistory != null && routeMapName != null) {
            finalCommandBlocksSet.addAll(constructCommandBlock(policyFromHistory, routeMapName, getIntermediatePortNumber(intermediatePortId)));
        } else if (policyFromHistory == null) {
            log.debug("Policy history not found for {}.", policyToDelete.getId());
        }
        /* This is to recover the user specified policy. */
        if (routeMapName != null) {
            finalCommandBlocksSet.addAll(constructCommandBlock(policyToDelete, routeMapName, getIntermediatePortNumber(intermediatePortId)));
        }
        finalCommandBlocks.addAll(finalCommandBlocksSet);
        finalCommandBlocks.addAll(unbindPortsFromReservedVlanAndDeleteReservedVlanCommandBlock(policyToDelete, replaceVlanId));

        if (!finalCommandBlocks.isEmpty()) {
            finalCommandBlocks.get(finalCommandBlocks.size() - 1).setWriteMem("true");
        }

        return finalCommandBlocks;
    }

    private String getIntermediatePortNumber(Long intermediatePortId) {
        Port intermediatePort = null;
        if (intermediatePortId != null) {
            ManagedObject managedObject = getManagedObject(intermediatePortId);
            if (managedObject != null) {
                if (managedObject instanceof Port) {
                    intermediatePort = (Port) managedObject;
                } else if (managedObject instanceof PortGroup) {
                    intermediatePort = ((PortGroup) managedObject).getPrimaryPort();
                }
            }
        }
        if (intermediatePort != null) {
            return intermediatePort.getPortNumber();
        }
        return null;
    }

    /**
     * This method constructs port unMap command block for the given port
     *
     * @param deviceId
     * @param port
     * @param type
     * @param routeMapName
     * @return InterfaceUnMapCommandBlock
     */
    private InterfaceUnMapCommandBlock constructInterfaceUnMapCMDBlock(Integer deviceId, String port, String type, String routeMapName) {
        InterfaceUnMapCommandBlock interfaceUnMapCMDBlock = new InterfaceUnMapCommandBlock();
        interfaceUnMapCMDBlock.setDeviceId(deviceId);
        interfaceUnMapCMDBlock.setPort(port);
        interfaceUnMapCMDBlock.setRouteMapName(routeMapName);
        interfaceUnMapCMDBlock.setType(type);
        return interfaceUnMapCMDBlock;
    }

    /**
     * This method constructs port unMap UDA command block for the given port
     *
     * @param deviceId
     * @param port
     * @param policy
     * @param type
     * @return InterfaceUnMapUDACommandBlock
     */
    private InterfaceUnMapUDACommandBlock constructInterfaceUnMapUDACMDBlock(Integer deviceId, String port, Policy policy, String type) {
        InterfaceUnMapUDACommandBlock interfaceUnMapUDACommandBlock = new InterfaceUnMapUDACommandBlock();
        interfaceUnMapUDACommandBlock.setDeviceId(deviceId);
        interfaceUnMapUDACommandBlock.setPort(port);
        interfaceUnMapUDACommandBlock.setType(type);
        interfaceUnMapUDACommandBlock.setOffset1(String.valueOf(policy.getFieldOffset1().longValue() == -1L ? "ignore" : policy.getFieldOffset1()));
        interfaceUnMapUDACommandBlock.setOffset2(String.valueOf(policy.getFieldOffset2().longValue() == -1L ? "ignore" : policy.getFieldOffset2()));
        interfaceUnMapUDACommandBlock.setOffset3(String.valueOf(policy.getFieldOffset3().longValue() == -1L ? "ignore" : policy.getFieldOffset3()));
        interfaceUnMapUDACommandBlock.setOffset4(String.valueOf(policy.getFieldOffset4().longValue() == -1L ? "ignore" : policy.getFieldOffset4()));
        return interfaceUnMapUDACommandBlock;
    }

    /**
     * This method constructs port unMap from GTPProfile command block for the given port
     *
     * @param deviceId
     * @param port
     * @param profileName
     * @param profileId
     * @return UnMapPortFromGTPProfileCommandBlock
     */
    private UnMapPortFromGTPProfileCommandBlock constructUnMapPortFromGTPProfileCommandBlock(Integer deviceId, String port, String profileName, Long profileId) {
        UnMapPortFromGTPProfileCommandBlock unMapPortFromGTPProfileCommandBlock = new UnMapPortFromGTPProfileCommandBlock();
        unMapPortFromGTPProfileCommandBlock.setDeviceId(deviceId);
        unMapPortFromGTPProfileCommandBlock.setPort(port);
        unMapPortFromGTPProfileCommandBlock.setProfileName(profileName);
        unMapPortFromGTPProfileCommandBlock.setProfileId(profileId);
        return unMapPortFromGTPProfileCommandBlock;
    }

    /**
     * This method constructs command block to remove loopback from the given port
     *
     * @param deviceId
     * @param port
     * @return InterfaceRemoveLoopbackCommandBlock
     */
    private InterfaceRemoveLoopbackCommandBlock constructInterfaceRemoveLoopbackCommandBlock(Integer deviceId, String port) {
        InterfaceRemoveLoopbackCommandBlock interfaceRemoveLoopbackCommandBlock = new InterfaceRemoveLoopbackCommandBlock();
        interfaceRemoveLoopbackCommandBlock.setDeviceId(deviceId);
        interfaceRemoveLoopbackCommandBlock.setPort(port);
        return interfaceRemoveLoopbackCommandBlock;
    }

    /**
     * This method constructs command blocks to remove policy from the given device
     *
     * @param policy
     * @return List<CommandBlock>
     */
    private List<CommandBlock> constructCommandBlock(Policy policy, String routeMapName, String intermediatePort) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        //By default its true, Assumption is to unMap all route maps (l2, ip, ipv6) from INGRESS port
        boolean isUnMap = getUnMappableSet(policy);
        Set<Port> egressToUnTag = getUntaggableEgressPorts(policy);
        Set<Port> egressToUnbindFromTvfDomain = getEgressPortsToUnbindFromTvfDomain(policy);
        Set<Flow> flows = policy.getFlows();
        int flowsSize = 0;
        int currentFlowsSize = 0;
        Device device = policy.getDevice();
        Integer stablenetDeviceId = device.getStablenetId().intValue();
        Long deviceId = device.getId();
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> servicePorts = new HashSet<>();
        Set<PortGroup> portGroups = new HashSet<>();

        Set<String> aclTypes = Sets.newHashSet();
        if (flows != null && !flows.isEmpty()) {
            flowsSize = flows.size();
            Flow currentFlow = flows.stream().findFirst().get();
            ingressPorts.addAll(currentFlow.getIngressPorts());
            ingressPorts.addAll(currentFlow.getIngressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
            // Collect only the Service Ports
            servicePorts.addAll(currentFlow.getIngressPorts().stream().filter(port -> port.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet()));
            portGroups.addAll(currentFlow.getIngressPortGroups());
            flows.forEach(flow -> {
                Set<RuleSet> ruleSets = flow.getRuleSets();
                if (ruleSets != null && !ruleSets.isEmpty()) {
                    ruleSets.forEach(ruleSet -> {
                        String ruleSetType = getRuleSetType(ruleSet);
                        if (ruleSetType != null && !aclTypes.contains(ruleSetType)) {
                            aclTypes.add(ruleSetType);
                        }
                    });
                }
            });
        }

        for (Port port : ingressPorts) {
            // un map policies from the interfaces
            if (isUnMap) {
                /** UnMap l2 route map from interface */
                if (aclTypes.contains(L2)) {
                    commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, port.getPortNumber(), L2, routeMapName));
                }

                /** UnMap uda route map from interface */
                if (aclTypes.contains(UDA)) {
                    commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, port.getPortNumber(), UDA, policy.getComputedName()));
                }

                /** UnMap ip route map from interface */
                if (aclTypes.contains(IP)) {
                    commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, port.getPortNumber(), IP, policy.getComputedName()));
                }

                /** UnMap ipv6 route map from interface */
                if (aclTypes.contains(IPV6)) {
                    commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, port.getPortNumber(), IPV6, policy.getComputedName()));
                }

                if (aclTypes.contains(UDA)) {
                    commandBlocks.add(constructInterfaceUnMapUDACMDBlock(stablenetDeviceId, port.getPortNumber(), policy, UDA));
                }

                /** UnMap allow all pbr from interface */
                AllowVLanPbrUnMapInterfaceCommandBlock vLanIcb = new AllowVLanPbrUnMapInterfaceCommandBlock();
                vLanIcb.setDeviceId(stablenetDeviceId);
                vLanIcb.setPort(port.getPortNumber());
                commandBlocks.add(vLanIcb);
            }
        }

        if (policy.isPreserveHeader() && intermediatePort != null) {
            commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, intermediatePort, IP, policy.getComputedName()));
            commandBlocks.add(constructInterfaceUnMapCMDBlock(stablenetDeviceId, intermediatePort, IPV6, policy.getComputedName()));
            commandBlocks.add(constructInterfaceRemoveLoopbackCommandBlock(stablenetDeviceId, intermediatePort));

            /** UnMap allow all pbr from interface */
            AllowVLanPbrUnMapInterfaceCommandBlock vLanIcb = new AllowVLanPbrUnMapInterfaceCommandBlock();
            vLanIcb.setDeviceId(stablenetDeviceId);
            vLanIcb.setPort(intermediatePort);
            commandBlocks.add(vLanIcb);
        }

        if (flows != null && !flows.isEmpty()) {
            for (Flow flow : flows) {
                Map<String, Set<RuleSetIdNameMap>> aclTypeNameIdMap = constructAclTypeNameMap(flow);

                // Remove route map section from device
                CommandBlock routeMapCommandBlock = constructDeleteRouteMapCommandBlock(policy, false, flow.getSequence());
                if (routeMapCommandBlock != null) {
                    commandBlocks.add(routeMapCommandBlock);
                }
                // Remove route map section with sequence 999999999 only when this
                // the last route map section of a policy.
                if (currentFlowsSize == (flowsSize - 1)) {
                    if (isUnMap) {
                        CommandBlock routeMapCatchAllCommandBlock = constructDeleteRouteMapCommandBlock(policy, true, flow.getSequence());
                        if (routeMapCatchAllCommandBlock != null) {
                            commandBlocks.add(routeMapCatchAllCommandBlock);
                        }
                    }
                }

                currentFlowsSize++;
                // Remove ACLs from the device
                if (aclTypeNameIdMap != null && !aclTypeNameIdMap.isEmpty()) {
                    for (String type : aclTypeNameIdMap.keySet()) {
                        commandBlocks.addAll(constructDeleteAclCommandBlock(deviceId, stablenetDeviceId, type, aclTypeNameIdMap.get(type), policy.getId()));
                    }
                }

                // un tagged the ports from vlan
                List<Long> egressList = Lists.newArrayList();
                if (!flow.getTvfDomain()) {
                    flow.getVlans().forEach(vlan -> {
                        if (vlan != null && egressToUnTag != null && !egressToUnTag.isEmpty()) {
                            for (Port egressPort : egressToUnTag) {
                                // check if any other policy has the same vlanId and egress combination
                                List<Long> flowIds = flowRepository.findByVlanAndEgressPortsAndTaggedNotInCurrentPolicy(deviceId, policy.getId(), vlan, Sets.newHashSet(egressPort.getId()), flow.getIsTagged());
                                if (flowIds.isEmpty()) {
                                    VLanPortNoTagCommandBlock noTagPortFromVlan = new VLanPortNoTagCommandBlock();
                                    noTagPortFromVlan.setDeviceId(stablenetDeviceId);
                                    noTagPortFromVlan.setPort(egressPort.getPortNumber());
                                    noTagPortFromVlan.setVLan(Integer.parseInt(vlan));
                                    noTagPortFromVlan.setTagged(flow.getIsTagged());
                                    commandBlocks.add(noTagPortFromVlan);
                                } else {
                                    egressList.add(egressPort.getId());
                                }
                            }
                        }
                        // check if any other policy has the same vlanId and egress combination
                        if (egressList.isEmpty()) {
                            VLanNoCommandBlock vLanNoCommandBlock = new VLanNoCommandBlock();
                            vLanNoCommandBlock.setDeviceId(stablenetDeviceId);
                            vLanNoCommandBlock.setVLan(Integer.parseInt(vlan));
                            commandBlocks.add(vLanNoCommandBlock);
                        }
                    });
                } else { // if tvf domain
                    flow.getVlans().forEach(tvfDomain -> {
                        if (tvfDomain != null && egressToUnbindFromTvfDomain != null && !egressToUnbindFromTvfDomain.isEmpty()) {
                            for (Port egressPort : egressToUnbindFromTvfDomain) {
                                // check if any other policy has the same tvfDomain and egress combination
                                List<Long> flowIds = flowRepository.findByTvfDomainAndEgressPortsAndNotInCurrentPolicy(deviceId, policy.getId(), tvfDomain, Sets.newHashSet(egressPort.getId()));
                                if (flowIds.isEmpty()) {
                                    TvfDomainUnbindPortsCommandBlock unbindPortsCommandBlock = new TvfDomainUnbindPortsCommandBlock();
                                    unbindPortsCommandBlock.setDeviceId(stablenetDeviceId);
                                    unbindPortsCommandBlock.setPort(egressPort.getPortNumber());
                                    unbindPortsCommandBlock.setTvfDomainId(Integer.parseInt(tvfDomain));
                                    commandBlocks.add(unbindPortsCommandBlock);
                                } else {
                                    egressList.add(egressPort.getId());
                                }
                            }
                        }
                        // check if any other policy has the same tvfDomain and egress combination
                        if (egressList.isEmpty()) {
                            TvfDomainCommandBlock tvfDomainCommandBlock = new TvfDomainCommandBlock();
                            tvfDomainCommandBlock.setDeviceId(stablenetDeviceId);
                            tvfDomainCommandBlock.setTvfDomainId(Integer.parseInt(tvfDomain));
                            commandBlocks.add(tvfDomainCommandBlock);
                        }
                    });
                }
            }
        }

        if (policy.isLoopbackEnabled()) {
            for (Port port : ingressPorts) {
                /** remove loopback from interface */
                commandBlocks.add(constructInterfaceRemoveLoopbackCommandBlock(stablenetDeviceId, port.getPortNumber()));
            }
        }

        /** UnMap interface from GTP Profile */
        if (policy.getGtpProfile() != null) {
            servicePorts.forEach(servicePort -> {
                commandBlocks.add(constructUnMapPortFromGTPProfileCommandBlock(stablenetDeviceId, servicePort.getPortNumber(), policy.getGtpProfile().getName(), policy.getGtpProfile().getProfileId()));
            });

            portGroups.forEach(portGroup -> {
                if (portGroup.getGtpProfile() == null && portGroup.getPrimaryPort() != null) {
                    commandBlocks.add(constructUnMapPortFromGTPProfileCommandBlock(stablenetDeviceId, portGroup.getPrimaryPort().getPortNumber(), policy.getGtpProfile().getName(), policy.getGtpProfile().getProfileId()));
                }
            });
        }

        return commandBlocks;
    }

    /**
     * This method constructs RuleSetType to ruleSet names map
     *
     * @param flow
     * @return Map<String ,   Set   < String>>
     */
    private Map<String, Set<RuleSetIdNameMap>> constructAclTypeNameMap(Flow flow) {
        Map<String, Set<RuleSetIdNameMap>> aclNameTypeMap = new HashMap<>();
        Set<RuleSet> ruleSets = flow.getRuleSets();
        if (ruleSets != null && !ruleSets.isEmpty()) {
            ruleSets.forEach(ruleSet -> {
                RuleSetIdNameMap ruleSetIdNameMap = new RuleSetIdNameMap();
                ruleSetIdNameMap.setId(ruleSet.getId());
                ruleSetIdNameMap.setName(ruleSet.getName());
                if (aclNameTypeMap.containsKey(getRuleSetType(ruleSet))) {
                    Set<RuleSetIdNameMap> ruleSetIdNameMaps = aclNameTypeMap.get(getRuleSetType(ruleSet));
                    ruleSetIdNameMaps.add(ruleSetIdNameMap);
                } else {
                    Set<RuleSetIdNameMap> ruleSetIdNameMaps = new HashSet<>();
                    ruleSetIdNameMaps.add(ruleSetIdNameMap);
                    aclNameTypeMap.put(getRuleSetType(ruleSet), ruleSetIdNameMaps);
                }
            });
        }
        return aclNameTypeMap;
    }

    /**
     * This method returns the RuleSetType for the given RuleSet object
     *
     * @param ruleSet
     * @return String
     */
    private String getRuleSetType(RuleSet ruleSet) {
        String ruleSetType = "";
        if (RuleSet.Type.L2 == ruleSet.getType()) {
            ruleSetType = L2;
        } else if (RuleSet.Type.L3 == ruleSet.getType() && RuleSet.IpVersion.V4 == ruleSet.getIpVersion()) {
            ruleSetType = IP;
        } else if (RuleSet.Type.L3 == ruleSet.getType() && RuleSet.IpVersion.V6 == ruleSet.getIpVersion()) {
            ruleSetType = IPV6;
        } else if (RuleSet.Type.UDA == ruleSet.getType()) {
            ruleSetType = UDA;
        }
        return ruleSetType;
    }

    /**
     * This method constructs delete ACL command blocks based on RuleSet type
     *
     * @param deviceId
     * @param type
     * @param aclNameIdMap
     * @return List<CommandBlock>
     */
    private List<CommandBlock> constructDeleteAclCommandBlock(Long deviceId, Integer stablenetDeviceId, String type, Set<RuleSetIdNameMap> aclNameIdMap, Long policyId) {
        List<CommandBlock> aclCommandBlocks = new ArrayList<>();
        if (aclNameIdMap != null && !aclNameIdMap.isEmpty()) {
            for (RuleSetIdNameMap ruleSetIdName : aclNameIdMap) {
                if (isRuleSetChangesRequired(ruleSetIdName, deviceId, policyId)) {
                    switch (type) {
                        case IP:
                            IPAclCommandBlock ipaclCommandBlock = new IPAclCommandBlock();
                            ipaclCommandBlock.setDeviceId(stablenetDeviceId);
                            ipaclCommandBlock.setAclName(ruleSetIdName.getName());
                            aclCommandBlocks.add(ipaclCommandBlock);
                            break;
                        case IPV6:
                            IPv6AclCommandBlock iPv6AclCommandBlock = new IPv6AclCommandBlock();
                            iPv6AclCommandBlock.setDeviceId(stablenetDeviceId);
                            iPv6AclCommandBlock.setAclName(ruleSetIdName.getName());
                            aclCommandBlocks.add(iPv6AclCommandBlock);
                            break;
                        case L2:
                            L2AclCommandBlock l2AclCommandBlock = new L2AclCommandBlock();
                            l2AclCommandBlock.setDeviceId(stablenetDeviceId);
                            l2AclCommandBlock.setAclName(ruleSetIdName.getName());
                            aclCommandBlocks.add(l2AclCommandBlock);
                            break;
                        case UDA:
                            UDAAclCommandBlock udaAclCommandBlock = new UDAAclCommandBlock();
                            udaAclCommandBlock.setDeviceId(stablenetDeviceId);
                            udaAclCommandBlock.setAclName(ruleSetIdName.getName());
                            aclCommandBlocks.add(udaAclCommandBlock);
                            break;
                        default:
                            log.debug("Invalid access-list type. (Allowed types are L2, IP, IPV6 and UDA)");
                            break;
                    }
                }
            }
        }
        return aclCommandBlocks;
    }

    /**
     * This method constructs delete route-map command block for the given sequence
     *
     * @param policyToDelete
     * @param isCatchAll
     * @param sequnce
     * @return CommandBlock
     */
    private CommandBlock constructDeleteRouteMapCommandBlock(Policy policyToDelete, boolean isCatchAll, Integer sequnce) {
        if (policyToDelete.getName() != null && sequnce > -1) {
            RouteMapCommandBlock routeMapCommandBlock = new RouteMapCommandBlock();
            routeMapCommandBlock.setDeviceId(policyToDelete.getDevice().getStablenetId().intValue());
            routeMapCommandBlock.setRouteMapName(policyToDelete.getComputedName());
            if (isCatchAll) {
                routeMapCommandBlock.setRouteMapNameAndPermitSeq(String.format(ROUTE_MAP_WITH_SEQUENCE, policyToDelete.getComputedName(), ROUTE_MAP_CATCH_ALL_SEQUENCE));
            } else {
                routeMapCommandBlock.setRouteMapNameAndPermitSeq(String.format(ROUTE_MAP_WITH_SEQUENCE, policyToDelete.getComputedName(), sequnce));
            }
            return routeMapCommandBlock;
        } else {
            log.error("Policy name or sequence is null!");
        }
        return null;
    }

    private boolean getUnMappableSet(Policy policyToDelete) {
        boolean isUnMap = true;
        boolean canBreak = false;
        Set<Long> ingressPortIds = Sets.newHashSet();
        Set<Flow> flows = policyToDelete.getFlows();
        if (flows != null && !flows.isEmpty()) {
            ingressPortIds.addAll(flows.stream().flatMap(flow -> flow.getIngressPorts().stream()).map(Port::getId).collect(Collectors.toSet()));
            ingressPortIds.addAll(flows.stream().findAny().get().getIngressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(PortGroup::getPrimaryPort).map(Port::getId).collect(Collectors.toSet()));
        }
        if (!ingressPortIds.isEmpty()) {
            List<Policy> policies = policyRepository.findByDeviceIdAndIngressPorts(policyToDelete.getDevice().getId(), ingressPortIds);
            if (policies != null && !policies.isEmpty()) {
                for (Policy eachPolicy : policies) {
                    Policy policyFromHistory = getPolicyFromHistory(eachPolicy);
                    if (policyFromHistory != null) {
                        //SAVE_OVER_COMMIT case
                        Set<Port> histIngressList = policyFromHistory.getFlows().stream().flatMap(flow -> flow.getIngressPorts().stream()).collect(Collectors.toSet());
                        histIngressList.addAll(policyFromHistory.getFlows().stream().findAny().get().getIngressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
                        canBreak = ingressPortIds.stream().allMatch(eachIngressPortId -> histIngressList.contains(eachIngressPortId));
                    } else {
                        canBreak = true;
                    }
                    if (canBreak) {
                        isUnMap = false;
                        break;
                    }
                }
            }
        }
        return isUnMap;
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param policy
     * @return Policy returns latest ACTIVE policy
     */
    protected Policy getPolicyFromHistory(Policy policy) {
        return getPolicyNameFromHistoryByTypes(policy.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING));
    }

    /**
     * Fetches the policy history object
     *
     * @param policyId
     * @param status
     * @return
     */
    protected Policy getPolicyNameFromHistoryByTypes(Long policyId, List<WorkflowParticipant.WorkflowStatus> status) {
        Policy policyFromHistory = null;
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policyId, status);
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a policy history entity with oldName {} and latest Policy Id {}", oldPolicy.getName(), policyId);
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * This method fetches the untaggable egress port(s) from the current policy
     *
     * @param policy
     * @return Set<Port> returns latest ACTIVE policy
     */
    protected Set<Port> getUntaggableEgressPorts(Policy policy) {
        Set<Port> currEgressInUse = new HashSet<>();
        for (Flow flow : policy.getFlows()) {
            if (!flow.getTvfDomain()) {
                currEgressInUse.addAll(flow.getEgressPorts().stream().filter(po -> po.getType() == Port.Type.EGRESS || po.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet()));
                // querying db to get all policy by deviceid
                List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(policy.getDevice().getId(),
                        Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING), flow);
                Set<String> currentVlan = flow.getVlans();
                Set<Port> egressInUse = new HashSet<>();
                // Iterating on policy to find vlan id
                if (policies != null && !policies.isEmpty()) {
                    // Populating all distinct egress
                    for (Policy pw : policies) {
                        for (Flow eachFlow : pw.getFlows()) {
                            if (!eachFlow.getTvfDomain()) {
                                Set<String> tmpVlan = eachFlow.getVlans();
                                tmpVlan.stream().filter(vlan -> currentVlan.contains(vlan)).forEach(vlan -> {
                                    egressInUse.addAll(eachFlow.getEgressPorts());
                                    egressInUse.addAll(eachFlow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
                                });
                            }
                        }
                        // removing egress to be deleted
                        Set<Port> currentEgressToRemove = new HashSet<>();
                        for (Port egress : egressInUse) {
                            currentEgressToRemove.addAll(currEgressInUse.stream().filter(port -> port.getId() == egress.getId()).collect(Collectors.toSet()));
                            currEgressInUse.remove(egress);
                        }
                        currEgressInUse.removeAll(currentEgressToRemove);
                    }
                }
            }
        }
        return currEgressInUse;
    }

    protected Set<Port> getEgressPortsToUnbindFromTvfDomain(Policy policy) {
        Set<Port> currEgressInUse = new HashSet<>();
        for (Flow flow : policy.getFlows()) {
            if (flow.getTvfDomain()) {
                currEgressInUse.addAll(flow.getEgressPorts().stream().filter(po -> po.getType() == Port.Type.EGRESS || po.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet()));
                // querying db to get all policy by deviceid
                List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(policy.getDevice().getId(),
                        Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.WARNING), flow);
                Set<String> currentVlan = flow.getVlans();
                Set<Port> egressInUse = new HashSet<>();
                // Iterating on policy to find vlan id
                if (policies != null && !policies.isEmpty()) {
                    // Populating all distinct egress
                    for (Policy pw : policies) {
                        for (Flow eachFlow : pw.getFlows()) {
                            if (eachFlow.getTvfDomain()) {
                                Set<String> tmpVlan = eachFlow.getVlans();
                                tmpVlan.stream().filter(vlan -> currentVlan.contains(vlan)).forEach(vlan -> {
                                    egressInUse.addAll(eachFlow.getEgressPorts());
                                    egressInUse.addAll(eachFlow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
                                });
                            }
                        }
                        // removing egress to be deleted
                        Set<Port> currentEgressToRemove = new HashSet<>();
                        for (Port egress : egressInUse) {
                            currentEgressToRemove.addAll(currEgressInUse.stream().filter(port -> port.getId() == egress.getId()).collect(Collectors.toSet()));
                            currEgressInUse.remove(egress);
                        }
                        currEgressInUse.removeAll(currentEgressToRemove);
                    }
                }
            }
        }
        return currEgressInUse;
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    protected List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        //
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    /**
     * if preserve header flag is true,
     * 1. Collect all the out ports from existing committed policies, whose preserve header flag is enabled
     * 2. Collect all the out ports from existing saved policies for which is active on the device, whose preserve header flag is enabled
     * 3. Collect all the out ports from current policy
     * 4. Get the diff of out ports collected in step 3 which are not present in step 1 & 2
     * 5. Construct the no untag ports commands for ports from the diff from step 4 and bind it to reserved VLAN.
     * <p>
     * a. Collect all the out ports from current policy
     * b. Then check if these ports are used in any other policy which has preserve header enabled
     * c. Apply the no command, for ports, if not present in step (b)
     **/
    private List<CommandBlock> unbindPortsFromReservedVlanAndDeleteReservedVlanCommandBlock(Policy policy, Integer replaceVlanId) {
        List<CommandBlock> commandBlocks = new ArrayList<>();

        // if preserve header flag is true
        if (policy.isPreserveHeader()) {

            // Step 1
            List<ManagedObject> egressPortsAndPortGroupsOfActivePolicies = policyRepository.getAllEgressPortsAndPortGroupsByDeviceId(policy.getDevice().getId());
            Set<String> outPortsOfActivePolicies = Sets.newHashSet();
            for (ManagedObject mo : egressPortsAndPortGroupsOfActivePolicies) {
                if (mo instanceof Port) {
                    outPortsOfActivePolicies.add(((Port) mo).getPortNumber());
                } else if (mo instanceof PortGroup) {
                    PortGroup pg = (PortGroup) mo;
                    if (pg != null && pg.getPrimaryPort() != null) {
                        outPortsOfActivePolicies.add(pg.getPrimaryPort().getPortNumber());
                    }
                }
            }
            // Step 2
            List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(policy.getDevice().getId(), 0l);
            Set<String> outPortsOfSavedActivePolicies = Sets.newHashSet();
            for (Policy activePolicy : activePolicies) {
                for (Flow flow : activePolicy.getFlows()) {
                    outPortsOfSavedActivePolicies.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                    outPortsOfSavedActivePolicies.addAll(flow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                }
            }
            outPortsOfActivePolicies.addAll(outPortsOfSavedActivePolicies);
            // Step 3
            Set<String> outPortsOfCurrentPolicy = Sets.newHashSet();
            for (Flow flow : policy.getFlows()) {
                outPortsOfCurrentPolicy.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                outPortsOfCurrentPolicy.addAll(flow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort() != null).map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
            }
            // Step 4
            Sets.SetView<String> outPortsToUnTagInReservedVlan = Sets.difference(outPortsOfCurrentPolicy, outPortsOfActivePolicies);
            // Step 5
            if (outPortsToUnTagInReservedVlan != null && !outPortsToUnTagInReservedVlan.isEmpty()) {
                Integer stablenetDeviceId = policy.getDevice().getStablenetId().intValue();
                for (String port : outPortsToUnTagInReservedVlan) {
                    VLanPortNoTagCommandBlock noTagPortFromVlan = new VLanPortNoTagCommandBlock();
                    noTagPortFromVlan.setDeviceId(stablenetDeviceId);
                    noTagPortFromVlan.setPort(port);
                    noTagPortFromVlan.setVLan(replaceVlanId);
                    noTagPortFromVlan.setTagged(false);
                    commandBlocks.add(noTagPortFromVlan);
                }
            }

            // To delete Reserved Vlan if it's not used in any policy
            if (canDeleteReservedVlan(policy)) {
                VLanNoCommandBlock vLanNoCommandBlock = new VLanNoCommandBlock();
                vLanNoCommandBlock.setDeviceId(policy.getDevice().getStablenetId().intValue());
                vLanNoCommandBlock.setVLan(replaceVlanId);
                commandBlocks.add(vLanNoCommandBlock);
            }
        }
        return commandBlocks;
    }

    /**
     * To check whether reserved vlan can be deleted
     *
     * @param policyToDelete
     * @return
     */
    private boolean canDeleteReservedVlan(Policy policyToDelete) {
        boolean deleteReservedVlan = true;
        // Check if preserved header is enabled apart form current policy
        List<Long> policiesWithPreserveHeader = policyRepository.findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(policyToDelete.getDevice().getId(), true, policyToDelete.getId());
        if (policiesWithPreserveHeader != null && !policiesWithPreserveHeader.isEmpty()) {
            deleteReservedVlan = false;
        }
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(policyToDelete.getDevice().getId(), policyToDelete.getId());
        if (activePolicies != null && !activePolicies.isEmpty()) {
            for (Policy activePolicy : activePolicies) {
                for (Flow flow : activePolicy.getFlows()) {
                    if (activePolicy.isPreserveHeader()) {
                        deleteReservedVlan = false;
                    }
                }
            }
        }
        return deleteReservedVlan;
    }

    private String getRmOrL2AclName(HeaderStrippingModulePolicy.Headers header) {
        String rmOrL2AclName = "";
        if (HeaderStrippingModulePolicy.Headers.BR802 == header) {
            rmOrL2AclName = "only-br";
        } else if (HeaderStrippingModulePolicy.Headers.VNTAG == header) {
            rmOrL2AclName = "only-vntag";
        } else if (HeaderStrippingModulePolicy.Headers.ALL == header) {
            rmOrL2AclName = "only-br-vntag";
        }
        return rmOrL2AclName;
    }

    private ManagedObject getManagedObject(Long intermediatePortId) {
        try {
            Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
            List<Long> ids = new ArrayList<>();
            ids.add(intermediatePortId);
            query.setParameter("ids", ids);
            return (ManagedObject) query.getSingleResult();
        } catch (NoResultException | NonUniqueResultException nre) {
            return null;
        }
    }

}
