package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The CommitSdIngressPortJobExecutor class implements methods to build CLI to perform SET ingress port on selected SD device
 */
@Slf4j
@Named
public class CommitSdIngressPortJobExecutor extends AbstractStablenetJobExecutor {

    private static final String CONFIGURE_TERMINAL = "configure terminal;";
    private static final String PROFILES = "profiles;";
    private static final String SET_INGRESS_PORT = "set ingress-port";
    private static final String TYPE = " type=%s";
    private static final String NAME = " name=%s";
    private static final String JUMBO_FRAME = " jumbo-frame=%s";
    private static final String ENABLE = "enable;";
    private static final String DISABLE = "disable;";
    private static final String EXIT = "exit;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_SET_INGRESS_PORT);
    }

    /**
     * This method builds set ingress ports commands to be executed on the given SD device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        List<IngressPort> ingressPorts = getImpactedObjects(job).stream()
                .filter(mo -> mo instanceof IngressPort)
                .map(mo -> (IngressPort) mo)
                .collect(Collectors.toList());

        StringBuilder command = new StringBuilder();
        StringBuilder ingressCommand = new StringBuilder();
        ingressPorts.forEach(ingressPort -> {
            if (ingressPort != null) {
                ingressCommand.append(SET_INGRESS_PORT);
                ingressCommand.append(String.format(TYPE, ingressPort.getName()));
                ingressCommand.append(String.format(NAME, ingressPort.getPhysicalInterface().getName()));
                ingressCommand.append(String.format(JUMBO_FRAME, ingressPort.isJumboFrame() ? ENABLE : DISABLE));
            }
        });

        if (ingressCommand.length() > 0) {
            command.append(CONFIGURE_TERMINAL);
            command.append(PROFILES);
            command.append(ingressCommand.toString());
            command.append(EXIT);
            command.append(EXIT);
        }

        return command.toString();
    }
}
