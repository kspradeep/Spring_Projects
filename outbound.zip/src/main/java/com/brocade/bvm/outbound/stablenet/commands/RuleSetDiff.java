package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.brocade.bvm.model.db.RuleSet;
import com.brocade.bvm.model.db.TunnelDevicePolicy;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Set;

/**
 * Created by dneelapa on 7/15/2016.
 */

@Getter
@NoArgsConstructor
public class RuleSetDiff {

    @Setter
    private boolean isSeqChanged;

    @Setter
    private Set<RuleSet> addedRuleSets;

    @Setter
    private Set<RuleSet> updatedRuleSets;

    @Setter
    private Set<RuleSet> deletedRuleSets;

    @Setter
    private Set<String> flowVlans;

    @Setter
    private Set<String> flowTvfs;

    @Setter
    private String deletedDestinationMac;

    @Setter
    private String addedDestinationMac;

    @Setter
    private String updatedDestinationMac;

    @Setter
    private boolean isDestinationMacUpdated;

    @Setter
    private List<TunnelDevicePolicy> deletedTunnels;

    @Setter
    private List<TunnelDevicePolicy> addedTunnels;

    @Setter
    private List<TunnelDevicePolicy> updatedTunnels;

    @Setter
    private List<TunnelDevicePolicy> newFlowTunnels;

    @Setter
    private List<TunnelDevicePolicy> oldFlowTunnels;

    @Setter
    private PacketTruncationMapping packetTruncationMapping;
}
