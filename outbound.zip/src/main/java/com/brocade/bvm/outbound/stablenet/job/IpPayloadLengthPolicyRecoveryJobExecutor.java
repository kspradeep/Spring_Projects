package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.outbound.stablenet.commands.recovery.CommandBlock;
import com.brocade.bvm.outbound.stablenet.commands.recovery.IpPayloadLengthCommandBlock;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Named
@Slf4j
public class IpPayloadLengthPolicyRecoveryJobExecutor extends AbstractStablenetRecoveryJobExecutor {

    private static final String DEVICE_ID = "device-id ";

    private static final String RANGE = "range ";

    private static final String SPACE = " ";

    private static final String IPV4 = "IPV4";
    private static final String IPV6 = "IPV6";

    /**
     * This method constructs IpPayloadLengthPolicy recovery command blocks to be executed on the GIVEN device
     *
     * @param job
     * @return List<CommandBlock> This returns list of command blocks
     */
    @Override
    public List<CommandBlock> getCommands(Job job) {
        IpPayloadLengthPolicy modulePolicyToDelete = (IpPayloadLengthPolicy) getParentObject(job);
        log.debug("IpPayloadLengthPolicyRecovery Job executor for policy id {}", modulePolicyToDelete.getId());
        List<CommandBlock> commandBlocks = constructCommandBlockList(modulePolicyToDelete);
        log.debug("Number of command blocks constructed for module policy id {} is :{}", modulePolicyToDelete.getId(), commandBlocks.size());
        return commandBlocks;
    }

    /**
     * This method constructs PacketLabelingModulePolicy recovery command blocks for the given policy
     *
     * @param payloadLengthPolicy
     * @return List<CommandBlock> This returns list of command blocks
     */
    private List<CommandBlock> constructCommandBlockList(IpPayloadLengthPolicy payloadLengthPolicy) {
        List<CommandBlock> finalCommandBlocks = Lists.newArrayList();
        payloadLengthPolicy.getModules().forEach(module -> {
            finalCommandBlocks.add(constructModuleCommandBlock(module, getProcessorCommand(payloadLengthPolicy), getRangeCommand(payloadLengthPolicy), payloadLengthPolicy.getIpType().name()));
        });
        return finalCommandBlocks;
    }

    /**
     * This method constructs IpPayloadLengthPolicy recovery command block for OS version 6 and above
     *
     * @param module
     * @param processorNumber
     * @return PacketStampingCommandBlock
     */
    private IpPayloadLengthCommandBlock constructModuleCommandBlock(Module module, String processorNumber, String range, String ipType) {
        IpPayloadLengthCommandBlock payloadLengthCommandBlock = new IpPayloadLengthCommandBlock();
        payloadLengthCommandBlock.setDeviceId(module.getDevice().getStablenetId().intValue());
        payloadLengthCommandBlock.setProcessorNumber(processorNumber);
        payloadLengthCommandBlock.setRange(range);
        if (IPV4.equalsIgnoreCase(ipType)) {
            payloadLengthCommandBlock.setIpType("ip");
            payloadLengthCommandBlock.setIpTypeMatch("IPv4");
        } else if (IPV6.equalsIgnoreCase(ipType)) {
            payloadLengthCommandBlock.setIpType("ipv6");
            payloadLengthCommandBlock.setIpTypeMatch("IPv6");
        }
        payloadLengthCommandBlock.setModuleNumber(String.valueOf(module.getModuleNumber()));
        payloadLengthCommandBlock.setPortNumber(String.valueOf(module.getPorts().stream().findFirst().get().getPortNumber()));
        return payloadLengthCommandBlock;
    }

    /**
     * This method returns processorNumber value to be applied on the device based on processor number
     *
     * @param payloadLengthPolicy
     * @return String returns processorVal
     */
    protected String getProcessorCommand(IpPayloadLengthPolicy payloadLengthPolicy) {
        String processorVal = payloadLengthPolicy.getProcessor().getProcessorNumber();
        if (IpPayloadLengthPolicy.ProcessorNumber.ALL == payloadLengthPolicy.getProcessor()) {
            processorVal = "";
        } else {
            processorVal = DEVICE_ID + processorVal;
        }
        return processorVal;
    }

    /**
     * This method returns range value to be applied on the device
     *
     * @param payloadLengthPolicy
     * @return String returns rangeCmd
     */
    protected String getRangeCommand(IpPayloadLengthPolicy payloadLengthPolicy) {
        StringBuilder rangeCmd = new StringBuilder();
        rangeCmd.append(RANGE).append(payloadLengthPolicy.getMinRange()).append(SPACE).append(payloadLengthPolicy.getMaxRange());
        return rangeCmd.toString();
    }

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.IP_PAYLOAD_LENGTH_POLICY_ROLLBACK);
    }

}
