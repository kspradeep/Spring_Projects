package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.Job.Type;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;


@Slf4j
@Named
public abstract class StablenetDeletePolicyJobExecutor extends AbstractStablenetPolicyJobExecutor {

    protected String buildCommand(Policy policyToDelete) {
        StringBuilder command = new StringBuilder();
        command.append(START_CONFIG_TERMINAL);
        int reservedVlanId = 0;
        String reservedVlanCommand = "";
        boolean deleteReservedVlan = false;
        // if preserve header flag is true
        HeaderStrippingModulePolicy headerStrippingModulePolicy = null;
        Device device = policyToDelete.getDevice();
        if (policyToDelete.isPreserveHeader()) {
            // Get the reserved vlan
            headerStrippingModulePolicy = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(device.getId()).stream().findFirst().get();
            if (headerStrippingModulePolicy != null) {
                reservedVlanId = headerStrippingModulePolicy.getReplaceVlan();
            } else {
                log.error("Replace VLAN Id is not configured on the device: {}, {}", device.getId(), device.getName());
            }
            // Construct the unbind egress ports from reserved vlan command
            reservedVlanCommand = buildUnbindPortsFromReservedVlanCommand(policyToDelete, reservedVlanId);
            deleteReservedVlan = canDeleteReservedVlan(policyToDelete);
        }

        Map<String, Set<Port>> egressToBeDeleted = getPortsUnbindedFromVlan(policyToDelete);
        Map<String, Set<Port>> egressToBeUnbindFromTvfDomain = getPortsUnbindedFromTvfDomain(policyToDelete);
        /*List<String> deletableVlan = getVlanListToDelete(policyToDelete);
        List<String> deletableTvfDomain = getTvfDomainListToDelete(policyToDelete);*/

        List<String> deletableVlan = getVlansToDelete(policyToDelete);
        List<String> deletableTvfDomain = getTvfDomainIdsToDelete(policyToDelete);
        Set<Port> ingressPorts = Sets.newHashSet();
        Set<Port> servicePorts = new HashSet<>();
        Set<PortGroup> portGroups = new HashSet<>();
        final Set<RuleSet.Type> ruleSetTypeList = Sets.newHashSet();
        final Set<RuleSet.IpVersion> ruleSetIpList = Sets.newHashSet();
        Set<Flow> flows = policyToDelete.getFlows();
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                ruleSetTypeList.addAll(flow.getRuleSets().stream().map(RuleSet::getType).collect(Collectors.toSet()));
                ruleSetIpList.addAll(flow.getRuleSets().stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));
            });

            Flow flow = flows.stream().findAny().get();
            if (flow != null) {
                if (flow.getIngressPorts() != null) {
                    ingressPorts.addAll(flow.getIngressPorts().stream().collect(Collectors.toSet()));
                    servicePorts.addAll(flow.getIngressPorts().stream().filter(port -> port.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet()));
                }
                // Get all the primary ports from the Service Port Groups
                if (flow.getIngressPortGroups() != null) {
                    ingressPorts.addAll(flow.getIngressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
                    portGroups.addAll(flow.getIngressPortGroups());
                }
            }
        }

        // #1 reverting Ingree statement
        //get Ingress ports
        GTPDevicePolicy gtpProfile = policyToDelete.getGtpProfile();
        if (gtpProfile != null) {
            StringBuilder portsToMapToGtpProfile = new StringBuilder();
            // To unbind service port(s) fromo the selected GTP Profile in the policy.
            servicePorts.forEach(servicePort -> {
                portsToMapToGtpProfile.append(String.format(POLICYSET_GTP_INGRESS_UNMAP_FORMAT, servicePort.getPortNumber()));
            });
            // To unbind primary port of port group from the selected GTP Profile in the policy, only if port group is not associated with GTP Profile.
            portGroups.forEach(portGroup -> {
                if (portGroup.getGtpProfile() == null) {
                    portsToMapToGtpProfile.append(String.format(POLICYSET_GTP_INGRESS_UNMAP_FORMAT, portGroup.getPrimaryPort().getPortNumber()));
                }
            });
            if (portsToMapToGtpProfile.length() > 0) {
                command.append(String.format(POLICYSET_GTP_ENTER_FORMAT, gtpProfile.getName(), gtpProfile.getProfileId()));
                command.append(portsToMapToGtpProfile);
                command.append(EXIT);
            }
        }

        String policyName = policyToDelete.getComputedName();
        if (policyToDelete.isPreserveHeader()) {
            // validate if multiple policies created for Preserve Header, then do not unmap loopback
            List<Long> preserveHeaderPolicies = policyRepository.findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(device.getId(), true, policyToDelete.getId());
            boolean isLoopBackEnabled = true;
            if (!preserveHeaderPolicies.isEmpty()) {
                isLoopBackEnabled = false;
            }
            command.append(String.format(POLICYSET_REVERT_INGRESS_RECORD_FORMAT, getIntermediatePortNumber(headerStrippingModulePolicy.getIntermediatePortId()), getReverseACLFormatForPolicy(policyToDelete.getComputedName(), Sets.newHashSet(), ruleSetIpList, policyToDelete, isLoopBackEnabled)));

            if (headerStrippingModulePolicy != null && headerStrippingModulePolicy.getStripHeaders() != null && !headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
                policyName = getRmOrL2AclName(headerStrippingModulePolicy.getStripHeaders().stream().findFirst().get());
            }
            ruleSetIpList.clear();
            ruleSetTypeList.clear();
            ruleSetTypeList.add(RuleSet.Type.L2);
        }

        for (Port ingress : ingressPorts) {
            command.append(String.format(POLICYSET_REVERT_INGRESS_RECORD_FORMAT, ingress.getPortNumber(), getReverseACLFormatForPolicy(policyName, ruleSetTypeList, ruleSetIpList, policyToDelete, policyToDelete.isLoopbackEnabled())));
        }

        // #2 and #3 Reverting ruleSet and flow
        command.append(buildRevertFlowCommand(policyToDelete, policyToDelete.getComputedName(), device.getId(), Type.POLICY_DELETE));

        // Adding end policy
        command.append(String.format(POLICY_REVERT_TAIL_FORMAT, policyToDelete.getComputedName(), CMD_PERMIT));

        Map<String, Set<String>> vlanMap = new HashMap<>();
        // #4 creating Egress statement
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                buildUnmapEgressCommand(flow, egressToBeDeleted, vlanMap);
            });
        }

        vlanMap.forEach((vlan, portCommands) -> {
            command.append(String.format(POLICYSET_EGRESS_EDIT_RECORD_HEADER_FORMAT, vlan));
            portCommands.forEach(unmapCmd -> {
                command.append(unmapCmd);
            });
            command.append(EXIT);
        });

        Map<String, Set<String>> tvfDomainMap = new HashMap<>();
        // #4 creating Egress statement
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                buildTvfDomainEgressMap(flow, egressToBeUnbindFromTvfDomain, tvfDomainMap);
            });
        }

        tvfDomainMap.forEach((tvfDomain, portCommands) -> {
            command.append(String.format(TVF_DOMAIN_HEADER_FORMAT, tvfDomain));
            portCommands.forEach(portUnbindCommand -> {
                command.append(portUnbindCommand);
            });
            command.append(EXIT);
        });

        // #5 Deleting Vlan if not in use
        if (deletableVlan != null && !deletableVlan.isEmpty()) {
            deletableVlan.forEach(vlan -> command.append(String.format(DELETE_VLAN_FORMAT, vlan)));
        }

        // #6 Deleting tvf domain if not in use
        if (deletableTvfDomain != null && !deletableTvfDomain.isEmpty()) {
            deletableTvfDomain.forEach(tvfDomain -> command.append(REVERT + String.format(TVF_DOMAIN_HEADER_FORMAT, tvfDomain)));
        }

        // #7 unbind egress ports from reserved vlan (no untag ports)
        command.append(reservedVlanCommand);

        // #8 Delete Reserved vlan
        if (deleteReservedVlan && flowRepository.findFlowVlansByDeviceIdAndVlan(device.getId(),String.valueOf(reservedVlanId)).isEmpty()) {
            command.append(String.format(DELETE_VLAN_FORMAT, reservedVlanId));
        }
        command.append(WRITE_MEMORY);
        command.append(END);
        return command.toString();
    }

    private void buildUnmapEgressCommand(Flow flow, Map<String, Set<Port>> egressToBeDeleted, Map<String, Set<String>> vlanMap) {
        if (egressToBeDeleted != null && flow.getVlans() != null && !egressToBeDeleted.isEmpty() && !flow.getTvfDomain()) {
            for (String vlan : flow.getVlans()) {
                Set<String> portCommand = vlanMap.get(vlan);
                if (portCommand == null) {
                    portCommand = new HashSet<>();
                }
                Set<Port> egressPorts = egressToBeDeleted.get(vlan);
                if (egressPorts != null) {
                    for (Port egress : egressPorts) {
                        String isTagged = flow.getIsTagged() ? "tagged" : "untagged";
                        if (flow.getEgressPorts() != null) {
                            Port egressToUnmap = flow.getEgressPorts().stream().filter(port -> port.getId().equals(egress.getId())).findFirst().orElse(null);
                            if (egressToUnmap != null) {
                                portCommand.add("no " + isTagged + " ethe " + egress.getPortNumber() + ";");
                            }
                        }
                        if (flow.getEgressPortGroups() != null) {
                            PortGroup egressPgToUnmap = flow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort().getId().equals(egress.getId())).findFirst().orElse(null);
                            if (egressPgToUnmap != null) {
                                portCommand.add("no " + isTagged + " ethe " + egressPgToUnmap.getPrimaryPort().getPortNumber() + ";");
                            }
                        }
                    }
                }
                vlanMap.put(vlan, portCommand);
            }
        }
    }

    private void buildTvfDomainEgressMap(Flow flow, Map<String, Set<Port>> egressToUnbind, Map<String, Set<String>> tvfDomainEgressMap) {
        if (egressToUnbind != null && flow.getVlans() != null && !egressToUnbind.isEmpty() && flow.getTvfDomain()) {
            for (String vlan : flow.getVlans()) {
                Set<String> portCommand = tvfDomainEgressMap.get(vlan);
                if (portCommand == null) {
                    portCommand = new HashSet<>();
                }
                Set<Port> egressPorts = egressToUnbind.get(vlan);
                if (egressPorts != null) {
                    for (Port egress : egressPorts) {
                        if (flow.getEgressPorts() != null) {
                            Port egressToUnmap = flow.getEgressPorts().stream().filter(port -> port.getId().equals(egress.getId())).findFirst().orElse(null);
                            if (egressToUnmap != null) {
                                portCommand.add(REVERT + String.format(BIND_PORT, egress.getPortNumber()));
                            }
                        }
                        if (flow.getEgressPortGroups() != null) {
                            PortGroup egressPgToUnmap = flow.getEgressPortGroups().stream().filter(portGroup -> portGroup.getPrimaryPort().getId().equals(egress.getId())).findFirst().orElse(null);
                            if (egressPgToUnmap != null) {
                                portCommand.add(REVERT + String.format(BIND_PORT, egressPgToUnmap.getPrimaryPort().getPortNumber()));
                            }
                        }
                    }
                }
                tvfDomainEgressMap.put(vlan, portCommand);
            }
        }
    }

    /**
     * if preserve header flag is true,
     * 1. Collect all the out ports from existing committed policies, whose preserve header flag is enabled
     * 2. Collect all the out ports from existing saved policies for which is active on the device, whose preserve header flag is enabled
     * 3. Collect all the out ports from current policy
     * 4. Get the diff of out ports collected in step 3 which are not present in step 1 & 2
     * 5. Construct the no untag ports commands for ports from the diff from step 4 and bind it to reserved VLAN.
     **/
    private String buildUnbindPortsFromReservedVlanCommand(Policy policy, int reservedVlanId) {
        Set<String> outPortsOfActivePolicies = Sets.newHashSet();
        Set<String> outPortsOfCurrentPolicy = Sets.newHashSet();
        // Step 1 - Collect all the out ports from existing committed policies, whose preserve header flag is enabled
        outPortsOfActivePolicies.addAll(getEgressPortsOfActivePolicies(policy.getDevice()));
        // Step 2 - Collect all the out ports from existing saved policies for which is active on the device, whose preserve header flag is enabled
        outPortsOfActivePolicies.addAll(getEgressPortsOfSavedOverActivePolicies(policy.getDevice()));
        // Step 3 - Collect all the out ports from current policy
        outPortsOfCurrentPolicy.addAll(getEgressPortsFromPolicy(policy));
        // Step 4 - Get the diff of out ports collected in step 3 which are not present in step 1 & 2
        Sets.SetView<String> outPortsToUnTagInReservedVlan = Sets.difference(outPortsOfCurrentPolicy, outPortsOfActivePolicies);

        // Step 5
        StringBuilder reservedVlanCommand = new StringBuilder();
        if (outPortsToUnTagInReservedVlan != null && !outPortsToUnTagInReservedVlan.isEmpty()) {
            reservedVlanCommand.append(String.format(POLICYSET_REPLACE_VLAN_HEADER_FORMAT, reservedVlanId));
            // untag port
            outPortsToUnTagInReservedVlan.forEach(port -> {
                reservedVlanCommand.append(REVERT + String.format(UNTAG_PORT, port));
            });

            reservedVlanCommand.append(EXIT);
        }
        return reservedVlanCommand.toString();
    }

    /**
     * To check whether reserved vlan can be deleted
     *
     * @param policyToDelete
     * @return
     */
    private boolean canDeleteReservedVlan(Policy policyToDelete) {
        boolean deleteReservedVlan = true;
        // Check if preserved header is enabled apart form current policy
        List<Long> policiesWithPreserveHeader = policyRepository.findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(policyToDelete.getDevice().getId(), true, policyToDelete.getId());
        if (policiesWithPreserveHeader != null && !policiesWithPreserveHeader.isEmpty()) {
            deleteReservedVlan = false;
        }
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(policyToDelete.getDevice().getId(), policyToDelete.getId());
        if (activePolicies != null && !activePolicies.isEmpty()) {
            for (Policy activePolicy : activePolicies) {
                for (Flow flow : activePolicy.getFlows()) {
                    if (activePolicy.isPreserveHeader()) {
                        deleteReservedVlan = false;
                    }
                }
            }
        }
        return deleteReservedVlan;
    }

    @Override
    public List<Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.POLICY_DELETE, Type.POLICY_DELETE_DRAFT);
    }

}
