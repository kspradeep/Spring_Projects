package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortGroupHistoryRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.history.PortGroupHistory;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Slf4j
@Named
public class StablenetSLXPortGroupUpdateJobExecutor extends AbstractStablenetSLXPortGroupJobExecutor {

    @Inject
    private PortGroupHistoryRepository portGroupHistoryRepository;

    @Inject
    private PortRepository portRepository;

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PORT_GROUP_UPDATE, Job.Type.PORT_CHANNEL_UPDATE);
    }

    /**
     * This method constructs portGroup update commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PortGroup portGroup = (PortGroup) getParentObject(job);
        log.trace("SLX Port Group update input: {}", portGroup);
        StringBuilder command = new StringBuilder();
        if (portGroup != null) {
            Set<Port> ports = portGroup.getPorts();
            if (ports != null && !ports.isEmpty()) {
                command.append(CONFIGURE_TERMINAL);
                PortGroup oldPortGroup = getPortGroupFromHistory(portGroup.getId());
//                Update port group
                command.append(updatePortGroup(portGroup, oldPortGroup));
                command.append(EXIT);
            } else {
                log.error("Please provide the participating port(s).");
            }
        } else {
            log.error("SLX Port Group object is null.");
        }
        log.debug("SLX Port Group update command: {}", command);
        return command.toString();
    }

    /**
     * This method fetches the ACTIVE portGroup from history
     *
     * @param portGroupId
     * @return PortGroup This returns portGroup from history
     */
    private PortGroup getPortGroupFromHistory(Long portGroupId) {
        List<PortGroupHistory> portGroupHistoryList = portGroupHistoryRepository.findByIdAndWorkflowStatus(portGroupId);
        PortGroup portGroup = null;
        if (portGroupHistoryList.size() >= 1) {
            PortGroupHistory portGroupHistory = portGroupHistoryList.get(0);
            portGroup = portGroupHistory.buildParent();
            List<Port> ports = (List<Port>) portRepository.findAll(portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toSet()));
            portGroup.setPorts(new TreeSet<>(ports));
        }
        return portGroup;
    }
}
