package com.brocade.bvm.outbound.stablenet.commands.recovery;


import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;

@Named
public class SdSamplingPolicyRecoveryCommandList {
    /**
     * This method is used to construct command block to recover Sampling Policy
     *
     * @param samplingPolicy
     * @return
     */
    public List<CommandBlock> constructCommandBlockList(SamplingPolicy samplingPolicy) {
        List<CommandBlock> commandBlocks = new ArrayList<>();
        SdSamplingPolicyCommandBlock samplingPolicyCommandBlock = new SdSamplingPolicyCommandBlock();
        samplingPolicyCommandBlock.setDeviceId(Math.toIntExact(samplingPolicy.getDevice().getStablenetId()));
        samplingPolicyCommandBlock.setName(samplingPolicy.getName());
        commandBlocks.add(samplingPolicyCommandBlock);
        if (!commandBlocks.isEmpty()) {
            commandBlocks.get(commandBlocks.size() - 1).setWriteMem("false");
        }
        return commandBlocks;
    }
}
