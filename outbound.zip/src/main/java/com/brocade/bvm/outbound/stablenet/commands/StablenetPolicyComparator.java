/*
 * $Id$ $Revision$
 * Copyright Brocade 2016
 */

package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The StablenetPolicyComparator class implements methods to compare the updated policy with old policy in DB, and builds the difference between old policy and updated policy
 */
@Named
public class StablenetPolicyComparator {

    @Inject
    private FlowRepository flowRepository;

    @Inject
    protected PolicyHistoryRepository policyHistoryRepository;

    @Inject
    protected PolicyRepository policyRepository;

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    private boolean compare(Rule rule, Rule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null)
            return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null)
            return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null)
            return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;

        if (!rule.getRuleSet().getFlow().getPolicy().isLegacy()) {
            if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
                return false;
        }

        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getMatchPayloadLength() != nRule.getMatchPayloadLength())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }

    /**
     * This method compares oldPolicy with updated policy and builds the diff
     *
     * @param oldPolicy
     * @param newPolicy
     * @return StablenetPolicyDiff
     */
    public StablenetPolicyDiff comparePolicy(Policy oldPolicy, Policy newPolicy) {
        StablenetPolicyDiff policyDiff = new StablenetPolicyDiff();
        if (oldPolicy != null && newPolicy != null) {
            String gtpFlag = "";

            if (oldPolicy.getGtpProfile() != null && newPolicy.getGtpProfile() == null) {
                gtpFlag = "deleted";
            }

            if (oldPolicy.getGtpProfile() == null && newPolicy.getGtpProfile() != null) {
                gtpFlag = "added";
            }

            if (oldPolicy.getGtpProfile() != null && newPolicy.getGtpProfile() != null && !oldPolicy.getGtpProfile().getId().equals(newPolicy.getGtpProfile().getId())) {
                gtpFlag = "updated";
            }

            policyDiff.setGtpFlag(gtpFlag);

            policyDiff.setRouteMapName(newPolicy.getComputedName());
            policyDiff.setOldPreserveHeader(oldPolicy.isPreserveHeader());
            policyDiff.setNewPreserveHeader(newPolicy.isPreserveHeader());
            findUdaOffSetChanged(oldPolicy, newPolicy, policyDiff);
            Set<Flow> newFlows = newPolicy.getFlows();
            Set<Flow> oldFlows = oldPolicy.getFlows();

            List<RuleSet> oldRuleSets = getFlatRuleSets(oldFlows);
            List<RuleSet> newRuleSets = getFlatRuleSets(newFlows);

            findIngressPortsAndSequncesDiff(newPolicy, oldFlows, newFlows, policyDiff, oldRuleSets, newRuleSets);

            setRuleSetTypes(oldRuleSets, newRuleSets, policyDiff);

            findRuleSetDiff(oldRuleSets, newRuleSets, policyDiff);
        }
        return policyDiff;
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    private List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        //
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    private void findUdaOffSetChanged(Policy oldPolicy, Policy newPolicy, StablenetPolicyDiff policyDiff) {
        boolean isUdaOffSetChanged = false;
        if (oldPolicy.getFieldOffset1() != null ? !oldPolicy.getFieldOffset1().equals(newPolicy.getFieldOffset1()) : newPolicy.getFieldOffset1() != null)
            isUdaOffSetChanged = true;
        if (oldPolicy.getFieldOffset2() != null ? !oldPolicy.getFieldOffset2().equals(newPolicy.getFieldOffset2()) : newPolicy.getFieldOffset2() != null)
            isUdaOffSetChanged = true;
        if (oldPolicy.getFieldOffset3() != null ? !oldPolicy.getFieldOffset3().equals(newPolicy.getFieldOffset3()) : newPolicy.getFieldOffset3() != null)
            isUdaOffSetChanged = true;
        if (oldPolicy.getFieldOffset4() != null ? !oldPolicy.getFieldOffset4().equals(newPolicy.getFieldOffset4()) : newPolicy.getFieldOffset4() != null)
            isUdaOffSetChanged = true;

        boolean oldUdaOffSetStatus = true;
        if (oldPolicy.getFieldOffset1() == -1 && oldPolicy.getFieldOffset2() == -1 && oldPolicy.getFieldOffset3() == -1 && oldPolicy.getFieldOffset4() == -1)
            oldUdaOffSetStatus = false;

        if (newPolicy.getFieldOffset1() == -1 && newPolicy.getFieldOffset2() == -1 && newPolicy.getFieldOffset3() == -1 && newPolicy.getFieldOffset4() == -1)
            isUdaOffSetChanged = false;

        policyDiff.setOldUdaOffSetStatus(oldUdaOffSetStatus);
        policyDiff.setUdaOffSetChanged(isUdaOffSetChanged);
    }

    private void findIngressPortsAndSequncesDiff(Policy newPolicy, Set<Flow> oldFlows, Set<Flow> newFlows, StablenetPolicyDiff policyDiff, List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets) {

        Set<String> oldRuleSetNames = oldRuleSets.stream().map(RuleSet::getName).collect(Collectors.toSet());
        Set<String> newRuleSetNames = newRuleSets.stream().map(RuleSet::getName).collect(Collectors.toSet());

        Set<RuleSet.IpVersion> oldIpVersions = oldRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet());
        Set<RuleSet.IpVersion> newIpVersions = newRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet());

        Set<Long> oldRuleSetIds = oldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> newRuleSetIds = newRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        Set<Long> oldFlowIds = oldFlows.stream().map(Flow::getId).collect(Collectors.toSet());
        Set<Long> newFlowIds = newFlows.stream().map(Flow::getId).collect(Collectors.toSet());

        Set<Port> oldIngressPorts = new HashSet<>();
        Set<Port> newIngressPorts = new HashSet<>();

        Set<Integer> newSeqs = newFlows.stream().map(Flow::getSequence).collect(Collectors.toSet());
        Set<Integer> oldSeqs = oldFlows.stream().map(Flow::getSequence).collect(Collectors.toSet());

        Map<Integer, RuleSetDiff> flowMap = new HashMap<>();
        // sequence - vlan mapping
        Map<Integer, Set<String>> newVlansMap = new HashMap<>();
        Map<Integer, Set<String>> oldVlansMap = new HashMap<>();

        // sequence - tvf mapping
        Map<Integer, Set<String>> newTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> oldTvfsMap = new HashMap<>();

        Set<String> newVlanList = new TreeSet<>();
        Set<String> oldVlanList = new TreeSet<>();

        Set<String> newTvfList = new TreeSet<>();
        Set<String> oldTvfList = new TreeSet<>();

        Set<Flow> deletedFlows = new TreeSet<>();
        Set<Flow> addedFlows = new TreeSet<>();
        Set<Flow> updatedFlows = new TreeSet<>();

        Set<Integer> deletedSeqs = new TreeSet<>();
        Set<Integer> addedSeqs = new TreeSet<>();
        Set<Integer> updatedSeqs = new TreeSet<>();

        oldFlows.forEach(oldFlow -> {
            /*If old flow id is not present in new flowIds, adding the old flow to deletedFlows*/
            if (!newFlowIds.contains(oldFlow.getId())) {
                deletedFlows.add(oldFlow);
            }

            /*If old sequence is not present in new sequences, adding the old sequence to deletedSeqs*/
            if (!newSeqs.contains(oldFlow.getSequence())) {
                RuleSetDiff ruleSetDiff = new RuleSetDiff();
                ruleSetDiff.setDeletedRuleSets(oldFlow.getRuleSets());
                /*For TVF domain*/
                if (oldFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(oldFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(oldFlow.getVlans());
                }
                ruleSetDiff.setDeletedDestinationMac(oldFlow.getDestinationMacTag());
                //ruleSetDiff.setDeletedTunnels(oldFlow.getTunnelPolicies());
                flowMap.put(oldFlow.getSequence(), ruleSetDiff);
                deletedSeqs.add(oldFlow.getSequence());
            } else {
                RuleSetDiff ruleSetDiff = flowMap.get(oldFlow.getSequence());
                if (ruleSetDiff == null) {
                    ruleSetDiff = new RuleSetDiff();
                }
                Set<RuleSet> deletedRuleSet = new TreeSet<>();
                if (ruleSetDiff.getDeletedRuleSets() != null && !ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    deletedRuleSet.addAll(ruleSetDiff.getDeletedRuleSets());
                }
                oldFlow.getRuleSets().forEach(ruleSet -> {
                    /*If old ruleSet name is not present in new ruleSet names, adding the old ruleSet to deletedRuleSet*/
                    if (oldRuleSetNames.contains(ruleSet.getName()) && !newRuleSetNames.contains(ruleSet.getName())) {
                        if (ruleSet.getType() != RuleSet.Type.L3) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && !newIpVersions.contains(ruleSet.getIpVersion())) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())) {
                            // TODO :: This seems not required
                            deletedRuleSet.add(ruleSet);
                        }
                    }
                    if (oldRuleSetNames.contains(ruleSet.getName()) && newRuleSetNames.contains(ruleSet.getName())) {
                        /*If ruleSet names are same and IP(IPV4/IPV6) versions are changed, adding to deleted ruleSet*/
                        if (oldIpVersions.contains(ruleSet.getIpVersion()) && !newIpVersions.contains(ruleSet.getIpVersion())) {
                            deletedRuleSet.add(ruleSet);
                        } else if (oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())
                                && oldRuleSetIds.contains(ruleSet.getId()) && !newRuleSetIds.contains(ruleSet.getId())) {
                            /*If ruleSet names are same and IP versions are same, ruleSet is deleted and added back with same data, adding to deleted ruleSet*/
                            deletedRuleSet.add(ruleSet);
                        }
                    }
                });

                ruleSetDiff.setDeletedRuleSets(deletedRuleSet);
                /*For TVF domain*/
                if (oldFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(oldFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(oldFlow.getVlans());
                }
                if (!ruleSetDiff.getDeletedRuleSets().isEmpty()) {
                    flowMap.put(oldFlow.getSequence(), ruleSetDiff);
                }
            }

            oldIngressPorts.addAll(oldFlow.getIngressPorts().stream().collect(Collectors.toSet()));
            oldIngressPorts.addAll(oldFlow.getIngressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));

            /*For TVF domain*/
            if (oldFlow.getTvfDomain()) {
                oldTvfsMap.put(oldFlow.getSequence(), Sets.newHashSet(oldFlow.getVlans()));
                oldTvfList.addAll(oldFlow.getVlans());
            } else {
                oldVlansMap.put(oldFlow.getSequence(), Sets.newHashSet(oldFlow.getVlans()));
                oldVlanList.addAll(oldFlow.getVlans());
            }
        });

        newFlows.forEach(newFlow -> {
            /*If new flow id is not present in old flowIds, adding the new flow to addedFlows else to updatedFlows*/
            if (!oldFlowIds.contains(newFlow.getId())) {
                addedFlows.add(newFlow);
            } else {
                updatedFlows.add(newFlow);
            }

            /*If new sequence is not present in old sequences, adding the new sequence to addedSeqs, else to updatedSeqs*/
            if (!oldSeqs.contains(newFlow.getSequence())) {
                RuleSetDiff ruleSetDiff = new RuleSetDiff();
                ruleSetDiff.setAddedRuleSets(newFlow.getRuleSets());
                ruleSetDiff.setSeqChanged(true);
                /*For TVF domain*/
                if (newFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(newFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(newFlow.getVlans());
                }
                ruleSetDiff.setAddedDestinationMac(newFlow.getDestinationMacTag());
                ruleSetDiff.setAddedTunnels(newFlow.getTunnelPolicies());

                flowMap.put(newFlow.getSequence(), ruleSetDiff);
                addedSeqs.add(newFlow.getSequence());
            } else {
                RuleSetDiff ruleSetDiff = flowMap.get(newFlow.getSequence());
                if (ruleSetDiff == null) {
                    ruleSetDiff = new RuleSetDiff();
                }

                List<Long> newTunnelIds = newFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());

                for (Flow oldFlow : oldFlows) {

                    if (oldFlow.getDestinationMacTag() == null && newFlow.getDestinationMacTag() != null) {
                        ruleSetDiff.setAddedDestinationMac(newFlow.getDestinationMacTag());
                    } else if (oldFlow.getDestinationMacTag() != null && newFlow.getDestinationMacTag() == null) {
                        ruleSetDiff.setDeletedDestinationMac(oldFlow.getDestinationMacTag());
                    } else if (oldFlow.getDestinationMacTag() != null && newFlow.getDestinationMacTag() != null) {
                        if (!oldFlow.getDestinationMacTag().equals(newFlow.getDestinationMacTag())) {
                            ruleSetDiff.setDestinationMacUpdated(true);
                        }
                        ruleSetDiff.setUpdatedDestinationMac(newFlow.getDestinationMacTag());
                    }

                    if (oldFlow.getSequence().equals(newFlow.getSequence()) && !oldFlow.getId().equals(newFlow.getId())) {
                        if (ruleSetDiff.getDeletedRuleSets() != null) {
                            ruleSetDiff.getDeletedRuleSets().addAll(oldFlow.getRuleSets());
                        } else {
                            ruleSetDiff.setDeletedRuleSets(oldFlow.getRuleSets());
                        }
                        ruleSetDiff.setSeqChanged(true);

                        break;
                    } else if (oldFlow.getSequence().equals(newFlow.getSequence()) && oldFlow.getId().equals(newFlow.getId())) {
                        List<Long> oldTunnelIds = oldFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());

                        List<TunnelDevicePolicy> deletedTunnels = Lists.newArrayList();
                        List<TunnelDevicePolicy> addedTunnels = Lists.newArrayList();
                        List<TunnelDevicePolicy> updatedTunnels = Lists.newArrayList();
                        // deleted tunnels
                        oldFlow.getTunnelPolicies().forEach(oldTunnel -> {
                            if (!newTunnelIds.contains(oldTunnel.getId())) {
                                deletedTunnels.add(oldTunnel);
                            }
                        });

                        newFlow.getTunnelPolicies().forEach(newTunnel -> {
                            if (!oldTunnelIds.contains(newTunnel.getId())) { /* Added tunnels*/
                                addedTunnels.add(newTunnel);
                            } else { /* updated tunnels*/
                                updatedTunnels.add(newTunnel);
                            }
                        });

                        //Below code is to make sure order of selection is maintained
                        if (newTunnelIds.size() == oldTunnelIds.size()) {
                            for (int i = 0; i < oldTunnelIds.size(); i++) {
                                if (!oldTunnelIds.get(i).equals(newTunnelIds.get(i))) {
                                    ruleSetDiff.setNewFlowTunnels(newFlow.getTunnelPolicies());
                                    ruleSetDiff.setOldFlowTunnels(oldFlow.getTunnelPolicies());
                                    break;
                                }
                            }
                        }

                        ruleSetDiff.setDeletedTunnels(deletedTunnels);
                        ruleSetDiff.setAddedTunnels(addedTunnels);
                        if (!ruleSetDiff.getAddedTunnels().isEmpty()) {
                            ruleSetDiff.setNewFlowTunnels(newFlow.getTunnelPolicies());
                            ruleSetDiff.setOldFlowTunnels(oldFlow.getTunnelPolicies());
                        }
                        ruleSetDiff.setUpdatedTunnels(updatedTunnels);
                        break;
                    }
                }
                Set<RuleSet> updatedRuleSet = new TreeSet<>();
                Set<RuleSet> addedRuleSet = new TreeSet<>();
                if (ruleSetDiff.getAddedRuleSets() != null) {
                    addedRuleSet.addAll(ruleSetDiff.getAddedRuleSets());
                }
                newFlow.getRuleSets().forEach(ruleSet -> {
                    if (oldRuleSetNames.contains(ruleSet.getName()) && newRuleSetNames.contains(ruleSet.getName()) && oldIpVersions.contains(ruleSet.getIpVersion()) && newIpVersions.contains(ruleSet.getIpVersion())
                            && oldRuleSetIds.contains(ruleSet.getId()) && newRuleSetIds.contains(ruleSet.getId())) {
                        updatedRuleSet.add(ruleSet);
                    } else { /*If ruleSet names are same and IP versions are same, ruleSet is deleted and added back with same data, adding to added ruleSet*/
                        addedRuleSet.add(ruleSet);
                    }
                });
                /*For TVF domain*/
                if (newFlow.getTvfDomain()) {
                    ruleSetDiff.setFlowTvfs(newFlow.getVlans());
                } else {
                    ruleSetDiff.setFlowVlans(newFlow.getVlans());
                }
                ruleSetDiff.setAddedRuleSets(addedRuleSet);
                ruleSetDiff.setUpdatedRuleSets(updatedRuleSet);
                flowMap.put(newFlow.getSequence(), ruleSetDiff);
                updatedSeqs.add(newFlow.getSequence());
            }

            newIngressPorts.addAll(newFlow.getIngressPorts().stream().collect(Collectors.toSet()));
            newIngressPorts.addAll(newFlow.getIngressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));

            /*For TVF domain*/
            if (newFlow.getTvfDomain()) {
                newTvfsMap.put(newFlow.getSequence(), Sets.newHashSet(newFlow.getVlans()));
                newTvfList.addAll(newFlow.getVlans());
            } else {
                newVlansMap.put(newFlow.getSequence(), Sets.newHashSet(newFlow.getVlans()));
                newVlanList.addAll(newFlow.getVlans());
            }
        });

        policyDiff.setDeletedSeqs(deletedSeqs);
        policyDiff.setAddedSeqs(addedSeqs);
        policyDiff.setUpdatedSeqs(updatedSeqs);

        policyDiff.setFlowMap(flowMap);

        findIngressDiff(oldIngressPorts, newIngressPorts, policyDiff);

        // vlan to out port mapping
        Map<String, Set<String>> vlanToOutPortMap = new HashMap<>();
        // tvf to out port mapping
        Map<String, Set<String>> tvfToOutPortMap = new HashMap<>();

        buildVlanAndTvfOutPortsMap(newPolicy, vlanToOutPortMap, tvfToOutPortMap);

        findVlanDiff(oldFlows, newFlows, oldVlansMap, newVlansMap, oldVlanList, newVlanList, vlanToOutPortMap, policyDiff);

        findTvfDiff(oldFlows, newFlows, oldTvfsMap, newTvfsMap, oldTvfList, newTvfList, tvfToOutPortMap, policyDiff);

    }

    /**
     * This method builds VLAN/TVF domain to destination port mapping to bind the ports appropriately
     *
     * @param newPolicy
     * @param vlanToOutPortMap
     * @param tvfToOutPortMap
     */
    private void buildVlanAndTvfOutPortsMap(Policy newPolicy, Map<String, Set<String>> vlanToOutPortMap, Map<String, Set<String>> tvfToOutPortMap) {
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(newPolicy.getDevice().getId(), newPolicy.getId());
        activePolicies.addAll(policyRepository.findAllActivePoliciesByDeviceIdNotCurrentPolicy(newPolicy.getDevice().getId(), newPolicy.getId()));

        // Collecting the destination ports from active policies(excluding the current policy) on the device
        activePolicies.forEach(activePolicy -> {
            activePolicy.getFlows().forEach(flow -> {
                if (flow.getTvfDomain()) {
                    flow.getVlans().forEach(tvfId -> {
                        Set<String> outPorts;
                        if (tvfToOutPortMap.containsKey(tvfId)) {
                            outPorts = tvfToOutPortMap.get(tvfId);
                        } else {
                            outPorts = new HashSet<>();
                        }
                        outPorts.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                        outPorts.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                        tvfToOutPortMap.put(tvfId, outPorts);
                    });
                } else {
                    flow.getVlans().forEach(vlandId -> {
                        Set<String> outPorts;
                        if (vlanToOutPortMap.containsKey(vlandId)) {
                            outPorts = vlanToOutPortMap.get(vlandId);
                        } else {
                            outPorts = new HashSet<>();
                        }
                        outPorts.addAll(flow.getEgressPorts().stream().map(Port::getPortNumber).collect(Collectors.toSet()));
                        outPorts.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getPortNumber()).collect(Collectors.toSet()));
                        vlanToOutPortMap.put(vlandId, outPorts);
                    });
                }
            });
        });
    }

    /**
     * This method builds the source ports diff between old policy and updated policy
     *
     * @param oldIngressPorts
     * @param newIngressPorts
     * @param policyDiff
     */
    private void findIngressDiff(Set<Port> oldIngressPorts, Set<Port> newIngressPorts, StablenetPolicyDiff policyDiff) {
        // Ingress ports
        Set<Long> oldPortIds = oldIngressPorts.stream().map(Port::getId).collect(Collectors.toSet());
        Set<Long> newPortIds = newIngressPorts.stream().map(Port::getId).collect(Collectors.toSet());

        Set<Port> deletedPorts = new TreeSet<>();
        Set<Port> addedPorts = new TreeSet<>();
        Set<Port> unchangedPorts = new TreeSet<>();

        // deleted ingressports
        oldIngressPorts.forEach(oldPort -> {
            if (!newPortIds.contains(oldPort.getId())) {
                deletedPorts.add(oldPort);
            }
        });

        // added rulesets
        newIngressPorts.forEach(newPort -> {
            if (!oldPortIds.contains(newPort.getId())) {
                addedPorts.add(newPort);
            } else {
                unchangedPorts.add(newPort);
            }
        });

        policyDiff.setDeletedIngressPorts(deletedPorts);
        policyDiff.setAddedIngressPorts(addedPorts);
        policyDiff.setUnchangedIngressPorts(unchangedPorts);
    }

    /**
     * This method builds VLAN diff between old policy and updated policy
     *
     * @param oldFlows
     * @param newFlows
     * @param oldVlansMap
     * @param newVlansMap
     * @param oldVlanList
     * @param newVlanList
     * @param vlanToOutPortMap
     * @param policyDiff
     */
    private void findVlanDiff(Set<Flow> oldFlows,
                              Set<Flow> newFlows,
                              Map<Integer, Set<String>> oldVlansMap,
                              Map<Integer, Set<String>> newVlansMap,
                              Set<String> oldVlanList,
                              Set<String> newVlanList,
                              Map<String, Set<String>> vlanToOutPortMap,
                              StablenetPolicyDiff policyDiff) {

        Map<Integer, Set<String>> deletedVlansMap = new HashMap<>();
        Map<Integer, Set<String>> addedVlansMap = new HashMap<>();
        Map<Integer, Set<String>> updatedVlansMap = new HashMap<>();

        List<String> deletedVlanList = new ArrayList<>();
        List<String> addedVlanList = new ArrayList<>();
        List<String> updatedVlanList = new ArrayList<>();

        /* deleted VLAN list*/
        oldVlanList.forEach(oldVlan -> {
            if (!newVlanList.contains(oldVlan)) {
                deletedVlanList.add(oldVlan);
            }
        });

        newVlanList.forEach(newVlan -> {
            if (!oldVlanList.contains(newVlan)) { /* Added VLANs*/
                addedVlanList.add(newVlan);
            } else { /* Updated VLANs*/
                updatedVlanList.add(newVlan);
            }
        });

        oldVlansMap.forEach((sequence, oldVlans) -> {
            Set<String> newVlans = newVlansMap.get(sequence) != null ? newVlansMap.get(sequence) : Sets.newHashSet();
            Set<String> deletedVlans = new HashSet<>();
            oldVlans.forEach(oldVlan -> { /* This is to delete VLANs from route-map*/
                if (!newVlans.contains(oldVlan)) {
                    deletedVlans.add(oldVlan);
                }
            });
            deletedVlansMap.put(sequence, deletedVlans);
        });

        newVlansMap.forEach((sequence, newVlans) -> {
            Set<String> oldVlans = oldVlansMap.get(sequence) != null ? oldVlansMap.get(sequence) : Sets.newHashSet();
            Set<String> addedVlans = new HashSet<>();
            Set<String> updatedVlans = new HashSet<>();
            newVlans.forEach(newVlan -> {
                if (!oldVlans.contains(newVlan)) { /* This is to added VLANs to route-map*/
                    addedVlans.add(newVlan);
                } else { /* This is to update VLANs to route-map*/
                    updatedVlans.add(newVlan);
                }
            });
            addedVlansMap.put(sequence, addedVlans);
            updatedVlansMap.put(sequence, updatedVlans);
        });

        /* Old VLAN to egressSet map*/
        Map<String, Set<String>> oldVlanEgressMap = new HashMap<>();
        oldFlows.forEach(oldFlow -> {
            String isTagged = oldFlow.getIsTagged() ? "tagged" : "untagged";
            /*only if the type is VLAN*/
            if (!oldFlow.getTvfDomain()) {
                oldFlow.getVlans().forEach(oldVlan -> {
                    Set<String> egressUnmap = new HashSet<>();
                    if (oldVlanEgressMap.get(oldVlan) == null) {
                        egressUnmap = new HashSet<>();
                    } else {
                        egressUnmap = oldVlanEgressMap.get(oldVlan);
                    }
                    Set<String> outPorts = new HashSet<>();
                    if (vlanToOutPortMap.containsKey(oldVlan)) {
                        outPorts = vlanToOutPortMap.get(oldVlan);
                    }
                    for (Port port : oldFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressUnmap.add(isTagged + " ethernet " + port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : oldFlow.getEgressPortGroups()) {
                        if (!outPorts.contains(portGroup.getPrimaryPort().getPortNumber())) {
                            egressUnmap.add(isTagged + " ethernet " + portGroup.getPrimaryPort().getPortNumber() + " pg");
                        }
                    }
                    oldVlanEgressMap.put(oldVlan, egressUnmap);
                });
            }
        });

        /* New VLAN to egressSet map*/
        Map<String, Set<String>> newVlanEgressMap = new HashMap<>();
        newFlows.forEach(newFlow -> {
            String isTagged = newFlow.getIsTagged() ? "tagged" : "untagged";
            /*only if the type is VLAN*/
            if (!newFlow.getTvfDomain()) {
                newFlow.getVlans().forEach(newVlan -> {
                    Set<String> egressMap = null;
                    if (newVlanEgressMap.get(newVlan) == null) {
                        egressMap = new HashSet<>();
                    } else {
                        egressMap = newVlanEgressMap.get(newVlan);
                    }
                    Set<String> outPorts = new HashSet<>();
                    if (vlanToOutPortMap.containsKey(newVlan)) {
                        outPorts = vlanToOutPortMap.get(newVlan);
                    }
                    for (Port port : newFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressMap.add(isTagged + " ethernet " + port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : newFlow.getEgressPortGroups()) {
                        if (!outPorts.contains(portGroup.getPrimaryPort().getPortNumber())) {
                            egressMap.add(isTagged + " ethernet " + portGroup.getPrimaryPort().getPortNumber() + " pg");
                        }
                    }
                    newVlanEgressMap.put(newVlan, egressMap);
                });
            }
        });

        VlanDiff vlanDiff = new VlanDiff();
        vlanDiff.setOldVlanMap(oldVlanEgressMap);
        vlanDiff.setNewVlanMap(newVlanEgressMap);
        vlanDiff.setDeletedVlansMap(deletedVlansMap);
        vlanDiff.setAddedVlansMap(addedVlansMap);
        vlanDiff.setUpdatedVlansMap(updatedVlansMap);
        vlanDiff.setDeletedVlans(deletedVlanList);
        vlanDiff.setAddedVlans(addedVlanList);
        vlanDiff.setUpdatedVlans(updatedVlanList);
        policyDiff.setVlanDiff(vlanDiff);
    }

    /**
     * This method builds TVF domain diff between old policy and updated policy
     *
     * @param oldFlows
     * @param newFlows
     * @param oldTvfsMap
     * @param newTvfsMap
     * @param oldTvfList
     * @param newTvfList
     * @param tvfToOutPortMap
     * @param policyDiff
     */
    private void findTvfDiff(Set<Flow> oldFlows,
                             Set<Flow> newFlows,
                             Map<Integer, Set<String>> oldTvfsMap,
                             Map<Integer, Set<String>> newTvfsMap,
                             Set<String> oldTvfList,
                             Set<String> newTvfList, Map<String,
            Set<String>> tvfToOutPortMap,
                             StablenetPolicyDiff policyDiff) {

        // sequence to TVFs mapping
        Map<Integer, Set<String>> deletedTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> addedTvfsMap = new HashMap<>();
        Map<Integer, Set<String>> updatedTvfsMap = new HashMap<>();

        List<String> deletedTvfList = new ArrayList<>();
        List<String> addedTvfList = new ArrayList<>();
        List<String> updatedTvfList = new ArrayList<>();

        oldTvfList.forEach(oldTvf -> {
            if (!newTvfList.contains(oldTvf)) {
                deletedTvfList.add(oldTvf);
            }
        });

        newTvfList.forEach(newTvf -> {
            if (!oldTvfList.contains(newTvf)) {
                addedTvfList.add(newTvf);
            } else {
                updatedTvfList.add(newTvf);
            }
        });

        oldTvfsMap.forEach((sequence, oldTvfs) -> {
            Set<String> newTvfs = newTvfsMap.get(sequence) != null ? newTvfsMap.get(sequence) : Sets.newHashSet();
            Set<String> deletedTvfs = new HashSet<>();
            oldTvfs.forEach(oldTvf -> {
                if (!newTvfs.contains(oldTvf)) {
                    deletedTvfs.add(oldTvf);
                }
            });
            deletedTvfsMap.put(sequence, deletedTvfs);
        });

        newTvfsMap.forEach((sequence, newTvfs) -> {
            Set<String> oldTvfs = oldTvfsMap.get(sequence) != null ? oldTvfsMap.get(sequence) : Sets.newHashSet();
            Set<String> addedTvfs = new HashSet<>();
            Set<String> updatedTvfs = new HashSet<>();
            newTvfs.forEach(newTvf -> {
                if (!oldTvfs.contains(newTvf)) {
                    addedTvfs.add(newTvf);
                } else {
                    updatedTvfs.add(newTvf);
                }
            });
            addedTvfsMap.put(sequence, addedTvfs);
            updatedTvfsMap.put(sequence, updatedTvfs);
        });

        // building old tvfs to destination port mapping
        Map<String, Set<String>> oldTvfEgressMap = new HashMap<>();
        oldFlows.forEach(oldFlow -> {
            if (oldFlow.getTvfDomain()) {
                oldFlow.getVlans().forEach(oldTvf -> {
                    Set<String> egressUnmap;
                    if (oldTvfEgressMap.get(oldTvf) == null) {
                        egressUnmap = new HashSet<>();
                    } else {
                        egressUnmap = oldTvfEgressMap.get(oldTvf);
                    }
                    Set<String> outPorts = new HashSet<>();
                    if (tvfToOutPortMap.containsKey(oldTvf)) {
                        outPorts = tvfToOutPortMap.get(oldTvf);
                    }
                    for (Port port : oldFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressUnmap.add("ports ethe " + port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : oldFlow.getEgressPortGroups()) {
                        if (!outPorts.contains(portGroup.getPrimaryPort().getPortNumber())) {
                            egressUnmap.add("ports ethe " + portGroup.getPrimaryPort().getPortNumber() + " pg");
                        }
                    }
                    oldTvfEgressMap.put(oldTvf, egressUnmap);
                });
            }
        });

        // building new/updated tvfs to destination port mapping
        Map<String, Set<String>> newTvfEgressMap = new HashMap<>();
        newFlows.forEach(newFlow -> {
            if (newFlow.getTvfDomain()) {
                newFlow.getVlans().forEach(newTvf -> {
                    Set<String> egressMap;
                    if (newTvfEgressMap.get(newTvf) == null) {
                        egressMap = new HashSet<>();
                    } else {
                        egressMap = newTvfEgressMap.get(newTvf);
                    }

                    Set<String> outPorts = new HashSet<>();
                    if (tvfToOutPortMap.containsKey(newTvf)) {
                        outPorts = tvfToOutPortMap.get(newTvf);
                    }
                    for (Port port : newFlow.getEgressPorts()) {
                        if (!outPorts.contains(port.getPortNumber())) {
                            egressMap.add("ports ethe " + port.getPortNumber());
                        }
                    }
                    for (PortGroup portGroup : newFlow.getEgressPortGroups()) {
                        if (!outPorts.contains(portGroup.getPrimaryPort().getPortNumber())) {
                            egressMap.add("ports ethe " + portGroup.getPrimaryPort().getPortNumber() + " pg");
                        }
                    }
                    newTvfEgressMap.put(newTvf, egressMap);
                });
            }
        });

        TvfDiff tvfDiff = new TvfDiff();
        tvfDiff.setOldTvfMap(oldTvfEgressMap);
        tvfDiff.setNewTvfMap(newTvfEgressMap);
        tvfDiff.setDeletedTvfsMap(deletedTvfsMap);
        tvfDiff.setAddedTvfsMap(addedTvfsMap);
        tvfDiff.setUpdatedTvfsMap(updatedTvfsMap);
        tvfDiff.setDeletedTvfs(deletedTvfList);
        tvfDiff.setAddedTvfs(addedTvfList);
        tvfDiff.setUpdatedTvfs(updatedTvfList);
        policyDiff.setTvfDiff(tvfDiff);
    }

    /**
     * This method is used to find the diff between oldRuleSets and newRuleSets and populate policyDiff
     *
     * @param oldRuleSets
     * @param newRuleSets
     * @param policyDiff
     */
    private void setRuleSetTypes(List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets, StablenetPolicyDiff policyDiff) {
        Set<RuleSet.Type> oldRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.IpVersion> oldRuleSetIpList = Sets.newHashSet();

        oldRuleSetTypeList.addAll(oldRuleSets.stream().map(RuleSet::getType).collect(Collectors.toSet()));
        oldRuleSetIpList.addAll(oldRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));

        Map<Long, RuleSet.Type> oldRuleSetIdTypeMap = new HashMap<>();
        Map<Long, RuleSet.IpVersion> oldRuleSetIdIpVersionMap = new HashMap<>();
        oldRuleSets.forEach(ruleSet -> {
            if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) { /* MAC/UDA */
                oldRuleSetIdTypeMap.put(ruleSet.getId(), ruleSet.getType());
            } else if (ruleSet.getIpVersion() != null) { /* IPV4/IPV6*/
                oldRuleSetIdIpVersionMap.put(ruleSet.getId(), ruleSet.getIpVersion());
            }
        });

        Map<Long, RuleSet.Type> newRuleSetIdTypeMap = new HashMap<>();
        Map<Long, RuleSet.IpVersion> newRuleSetIdIpVersionMap = new HashMap<>();
        newRuleSets.forEach(ruleSet -> {
            if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) { /* MAC/UDA */
                newRuleSetIdTypeMap.put(ruleSet.getId(), ruleSet.getType());
            } else if (ruleSet.getIpVersion() != null) { /* IPV4/IPV6*/
                newRuleSetIdIpVersionMap.put(ruleSet.getId(), ruleSet.getIpVersion());
            }
        });

        Set<RuleSet.Type> newRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.IpVersion> newRuleSetIpList = Sets.newHashSet();

        newRuleSetTypeList.addAll(newRuleSets.stream().map(RuleSet::getType).collect(Collectors.toSet()));
        newRuleSetIpList.addAll(newRuleSets.stream().map(RuleSet::getIpVersion).collect(Collectors.toSet()));

        Set<RuleSet.Type> deletedRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.Type> addedRuleSetTypeList = Sets.newHashSet();
        Set<RuleSet.Type> updatedRuleSetTypeList = Sets.newHashSet();

        /* Start MAC/UDA */
        oldRuleSetIdTypeMap.forEach((ruleSetId, oldType) -> {
            RuleSet.Type newType = newRuleSetIdTypeMap.get(ruleSetId);
            if (newType != null && newType != oldType) {
                deletedRuleSetTypeList.add(oldType);
            } else if (newType == null) {
                deletedRuleSetTypeList.add(oldType);
            }
        });

        newRuleSetIdTypeMap.forEach((ruleSetId, newType) -> {
            RuleSet.Type oldType = oldRuleSetIdTypeMap.get(ruleSetId);
            if (oldType != null && oldType != newType) {
                addedRuleSetTypeList.add(newType);
            } else if (oldType == null) {
                addedRuleSetTypeList.add(newType);
            } else {
                updatedRuleSetTypeList.add(newType);
            }
        });

        updatedRuleSetTypeList.forEach(type -> {
            if (!deletedRuleSetTypeList.isEmpty() && deletedRuleSetTypeList.contains(type)) {
                deletedRuleSetTypeList.remove(type);
            }
            if (!addedRuleSetTypeList.isEmpty() && addedRuleSetTypeList.contains(type)) {
                addedRuleSetTypeList.remove(type);
            }
        });
        /* End MAC/UDA */

        Set<RuleSet.IpVersion> deletedRuleSetIpList = Sets.newHashSet();
        Set<RuleSet.IpVersion> addedRuleSetIpList = Sets.newHashSet();
        Set<RuleSet.IpVersion> updatedRuleSetIpList = Sets.newHashSet();

        /* Start IPV4/IPV6*/
        oldRuleSetIdIpVersionMap.forEach((ruleSetId, oldIpVersion) -> {
            RuleSet.IpVersion newIpVersion = newRuleSetIdIpVersionMap.get(ruleSetId);
            if (newIpVersion != null && newIpVersion != oldIpVersion) {
                deletedRuleSetIpList.add(oldIpVersion);
            } else if (newIpVersion == null) {
                deletedRuleSetIpList.add(oldIpVersion);
            }
        });

        newRuleSetIdIpVersionMap.forEach((ruleSetId, newIpVersion) -> {
            RuleSet.IpVersion oldIpVersion = oldRuleSetIdIpVersionMap.get(ruleSetId);
            if (oldIpVersion != null && oldIpVersion != newIpVersion) {
                addedRuleSetIpList.add(newIpVersion);
            } else if (oldIpVersion == null) {
                addedRuleSetIpList.add(newIpVersion);
            } else {
                updatedRuleSetIpList.add(newIpVersion);
            }
        });

        updatedRuleSetIpList.forEach(type -> {
            if (!deletedRuleSetIpList.isEmpty() && deletedRuleSetIpList.contains(type)) {
                deletedRuleSetIpList.remove(type);
            }
            if (!addedRuleSetIpList.isEmpty() && addedRuleSetIpList.contains(type)) {
                addedRuleSetIpList.remove(type);
            }
        });
        /* End IPV4/IPV6*/

        policyDiff.setDeletedRuleSetTypeList(deletedRuleSetTypeList);
        policyDiff.setDeletedRuleSetIpList(deletedRuleSetIpList);

        policyDiff.setUpdatedRuleSetTypeList(updatedRuleSetTypeList);
        policyDiff.setUpdatedRuleSetIpList(updatedRuleSetIpList);

        policyDiff.setAddedRuleSetTypeList(addedRuleSetTypeList);
        policyDiff.setAddedRuleSetIpList(addedRuleSetIpList);
    }

    /**
     * This method finds the diff between old ruleSets and updated ruleSets
     *
     * @param oldRuleSets
     * @param newRuleSets
     * @param policyDiff
     */
    private void findRuleSetDiff(List<RuleSet> oldRuleSets, List<RuleSet> newRuleSets, StablenetPolicyDiff policyDiff) {
        Set<Long> oldRuleSetIds = oldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> newRuleSetIds = newRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        List<RuleSet> deletedRuleSets = new ArrayList<>();
        List<RuleSet> addedRuleSets = new ArrayList<>();

        List<RuleSet> updatedOldRuleSets = new ArrayList<>();
        List<RuleSet> updatedNewRuleSets = new ArrayList<>();

        oldRuleSets.forEach(oldRuleSet -> {
            // deleted rulesets
            if (!newRuleSetIds.contains(oldRuleSet.getId())) {
                deletedRuleSets.add(oldRuleSet);
            } else {
                updatedOldRuleSets.add(oldRuleSet);
            }
        });

        // added rulesets
        newRuleSets.forEach(newRuleSet -> {
            if (!oldRuleSetIds.contains(newRuleSet.getId())) {
                addedRuleSets.add(newRuleSet);
            } else {
                deletedRuleSets.add(newRuleSet);
                updatedNewRuleSets.add(newRuleSet);
            }
        });

        Set<Long> updatedOldRuleSetIds = updatedOldRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());
        Set<Long> updatedNewRuleSetIds = updatedNewRuleSets.stream().map(RuleSet::getId).collect(Collectors.toSet());

        /* MAC/UDA to list of RuleDiff*/
        Map<RuleSet.Type, List<RuleDiff>> ruleSetTypeDiffMap = new HashMap<>();

        /* IPV4/IPV6 to list of RuleDiff*/
        Map<RuleSet.IpVersion, List<RuleDiff>> ruleIpVersionDiffMap = new HashMap<>();

        updatedOldRuleSets.forEach(ruleSet -> {
            if (updatedNewRuleSetIds.contains(ruleSet.getId())) {
                List<RuleDiff> ruleDiffs = null;
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleDiffs = ruleSetTypeDiffMap.get(ruleSet.getType());
                } else {
                    ruleDiffs = ruleIpVersionDiffMap.get(ruleSet.getIpVersion());
                }
                if (ruleDiffs == null) {
                    ruleDiffs = new ArrayList<>();
                }
                RuleDiff ruleDiff = new RuleDiff();
                List<Rule> rules = new ArrayList<>();
                rules.addAll(ruleSet.getRules());
                ruleDiff.setOldRules(rules);
                ruleDiff.setRuleSet(ruleSet);
                ruleDiffs.add(ruleDiff);
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleSetTypeDiffMap.put(ruleSet.getType(), ruleDiffs);
                } else {
                    ruleIpVersionDiffMap.put(ruleSet.getIpVersion(), ruleDiffs);
                }
            }
        });

        updatedNewRuleSets.forEach(ruleSet -> {
            if (updatedOldRuleSetIds.contains(ruleSet.getId())) {
                List<RuleDiff> ruleDiffList = null;
                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleDiffList = ruleSetTypeDiffMap.get(ruleSet.getType());
                } else {
                    ruleDiffList = ruleIpVersionDiffMap.get(ruleSet.getIpVersion());
                }

                List<RuleDiff> ruleDiffs = new ArrayList<>();
                ruleDiffList.forEach(ruleDiff -> {
                    if (ruleDiff.getRuleSet() != null && ruleDiff.getRuleSet().getId().equals(ruleSet.getId())) {
                        List<Rule> rules = new ArrayList<>();
                        rules.addAll(ruleSet.getRules());
                        ruleDiff.setNewRules(rules);
                        ruleDiff.setRuleSet(ruleSet);
                    }
                    ruleDiffs.add(ruleDiff);
                });

                if (ruleSet.getType() != null && ruleSet.getType() != RuleSet.Type.L3) {
                    ruleSetTypeDiffMap.put(ruleSet.getType(), ruleDiffs);
                } else {
                    ruleIpVersionDiffMap.put(ruleSet.getIpVersion(), ruleDiffs);
                }
            }
        });

        Set<Long> updatedRuleIds = new HashSet<>();
        Set<Long> addedRuleIds = new HashSet<>();
        Set<Long> deletedRuleIds = new HashSet<>();
        Set<RuleSet.Type> ruleSetsTypeToUnmap = new HashSet<>();
        Set<RuleSet.IpVersion> ruleSetsIpVersionToUnmap = new HashSet<>();
        ruleSetTypeDiffMap.forEach((type, ruleDiffs) -> {
            ruleDiffs.forEach(ruleDiff -> {
                if (ruleDiff != null && ruleDiff.getOldRules() != null && ruleDiff.getNewRules() != null) {
                    findRuleDiff(ruleDiff.getOldRules(), ruleDiff.getNewRules(), ruleDiff, addedRuleIds, updatedRuleIds, deletedRuleIds);
                }
                if ((ruleDiff.getDeletedRules() != null && !ruleDiff.getDeletedRules().isEmpty()) || (ruleDiff.getAddedRules() != null && !ruleDiff.getAddedRules().isEmpty())) {
                    ruleSetsTypeToUnmap.add(type);
                }
            });
        });

        ruleIpVersionDiffMap.forEach((ipVersion, ruleDiffs) -> {
            ruleDiffs.forEach(ruleDiff -> {
                if (ruleDiff != null && ruleDiff.getOldRules() != null && ruleDiff.getNewRules() != null) {
                    findRuleDiff(ruleDiff.getOldRules(), ruleDiff.getNewRules(), ruleDiff, addedRuleIds, updatedRuleIds, deletedRuleIds);
                }
                if (!ruleDiff.getDeletedRules().isEmpty() || !ruleDiff.getAddedRules().isEmpty()) {
                    ruleSetsIpVersionToUnmap.add(ipVersion);
                }
            });
        });

        policyDiff.setRuleSetsTypeToUnmap(ruleSetsTypeToUnmap);
        policyDiff.setRuleSetsIpVersionToUnmap(ruleSetsIpVersionToUnmap);

        policyDiff.setRuleSetTypeMap(ruleSetTypeDiffMap);
        policyDiff.setRuleSetIpVersionMap(ruleIpVersionDiffMap);

        policyDiff.setRulesDeletedForPolicy(!deletedRuleIds.isEmpty() ? true : false);
        policyDiff.setRulesAddedForPolicy(!addedRuleIds.isEmpty() ? true : false);
        policyDiff.setRulesUpdatedForPolicy(!updatedRuleIds.isEmpty() ? true : false);
    }

    /**
     * This method fetches all the rules from multiple flows
     *
     * @param flows
     * @return List<RuleSet> of all rules across multiple flows
     */
    private List<RuleSet> getFlatRuleSets(Set<Flow> flows) {
        List<RuleSet> ruleSets = new ArrayList<>();
        flows.forEach(flow -> {
            ruleSets.addAll(flow.getRuleSets());
        });
        return ruleSets;
    }

    /**
     * This method finds the diff between old rules and updated rules
     *
     * @param oRuleList
     * @param nRuleList
     * @param ruleDiff
     * @param addedRuleIds
     * @param updatedRuleIds
     * @param deletedRuleIds
     */
    private void findRuleDiff(List<Rule> oRuleList, List<Rule> nRuleList, RuleDiff ruleDiff, Set<Long> addedRuleIds, Set<Long> updatedRuleIds, Set<Long> deletedRuleIds) {
        Set<Long> updateRuleIds = nRuleList.stream().map(Rule::getId).collect(Collectors.toSet());
        Set<Long> oldRuleIds = oRuleList.stream().map(Rule::getId).collect(Collectors.toSet());

        List<Rule> deletedRules = new ArrayList<>();
        List<Rule> addedRules = new ArrayList<>();
        //Deleted rules
        oRuleList.forEach(oldRule -> {
            if (!updateRuleIds.contains(oldRule.getId())) {
                deletedRules.add(oldRule);
                deletedRuleIds.add(oldRule.getId());
            }
        });

        nRuleList.forEach(newRule -> {
            //Added rules
            if (!oldRuleIds.contains(newRule.getId())) {
                addedRules.add(newRule);
                addedRuleIds.add(newRule.getId());
            } else {
                //Updated rules
                Rule oldRule = oRuleList.stream().filter(rule -> rule.getId().equals(newRule.getId())).findFirst().orElse(null);
                if (oldRule != null) {
                    if (!compare(oldRule, newRule)) {
                        addedRules.add(newRule);
                        deletedRules.add(oldRule);
                        addedRuleIds.add(newRule.getId());
                        deletedRuleIds.add(oldRule.getId());
                        updatedRuleIds.add(oldRule.getId());
                    }
                }
            }
        });
        ruleDiff.setDeletedRules(deletedRules);
        ruleDiff.setAddedRules(addedRules);
    }

}
