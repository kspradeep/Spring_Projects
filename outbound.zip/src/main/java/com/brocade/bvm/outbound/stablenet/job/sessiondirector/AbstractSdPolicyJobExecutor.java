package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.ActiveInterfaceHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.FilterPolicyHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.SamplingPolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.history.ActiveInterfaceHistory;
import com.brocade.bvm.model.db.history.FilterPolicyHistory;
import com.brocade.bvm.model.db.history.SamplingPolicyHistory;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterRule;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.common.IOUtils;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import net.schmizz.sshj.xfer.FileSystemFile;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * This class is used for handling global variables and functions used in SD Policy
 */
@Slf4j
public abstract class AbstractSdPolicyJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private FilterPolicyHistoryRepository filterPolicyHistoryRepository;

    @Inject
    private SamplingPolicyHistoryRepository samplingPolicyHistoryRepository;

    @Inject
    private ActiveInterfaceHistoryRepository activeInterfaceHistoryRepository;

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";
    protected static final String ADD_RULE = "add rule ";
    protected static final String DELETE_RULE = "del rule ";
    protected static final String ADD = "add ";
    protected static final String EDIT = "edit ";
    protected static final String DROP = "drop ";
    protected static final String DELETE = "del ";
    protected static final String SET = "set ";
    protected static final String CLEAR = "clear ";
    protected static final String EXIT = "exit;";
    protected static final String RETURN = "return;";
    protected static final String FILTER = "filter;";

    protected static final String PRESERVE_CPLANE = "preserve-cplane;";
    protected static final String TRAFFICTYPE = "traffic-type=%s;";

    protected static final String PRIORITY = "priority=%d ";
    protected static final String RANGE = "range=%d ";
    protected static final String PG = "port-group=%s ";
    protected static final String RPG = "replicate-port-group=%s ";
    protected static final String APPLY = "apply=%s ";
    protected static final String SAMPLING_POLICY = "sampling-policy=%s ";
    protected static final String FILTER_POLICY = "filter-policy=%s;";
    protected static final String DEDUPE_POLICY = "dedupe-policy=%s;";
    protected static final String SUBSCRIBER_TRAFFIC = "subscriber-traffic=%s ";
    protected static final String IMSI = "imsi=%s ";
    protected static final String IMEI = "imei=%s ";
    protected static final String APN = "apn=%s ";
    protected static final String QCI = "qci=%s ";
    protected static final String MCC = "mcc=%d ";
    protected static final String MNC = "mnc=%s ";
    protected static final String SIP_CALLING_PARTY = "sip-calling-party=%s ";
    protected static final String SIP_CALLED_PARTY = "sip-called-party=%s ";

    protected final static String SP = "sampling-policy";
    protected final static String DP = "dedupe-policy";
    protected final static String FP = "filter-policy";

    protected final static String CPG = "port-group";
    protected final static String CRPG = "replicate-port-group";

    protected static final String INTERFACE = "interface;";

    protected static final String EDIT_INTERFACE = "edit interface=%s;";
    protected static final String END = ";";

    private static final int SD_DEVICE_PORT = 22;
    private static final String SD_DEVICE_USER = "root";
    private static final String SD_DEVICE_PASSWORD = "password";

    @Value("${sd.server.file.path}")
    public String sdServerFilePath;
    @Value("${sd.evm.server.file.path}")
    public String evmServerFilePath;

    /**
     * This method builds commands to create Policy
     *
     * @param rule
     * @return create command
     */
    protected String buildCreateCommand(FilterRule rule, Device device) {
        if (rule.isBulkDelete())
            return buildDeleteCommand(rule, device);

        StringBuilder command = new StringBuilder();
        command.append(ADD_RULE);
        command.append(String.format(PRIORITY, rule.getPriority()));
        String filePath = getFilePath(rule, device);
        if (rule.getPortGroup() != null) {
            command.append(String.format(PG, rule.getPortGroup().getName()));
            if (rule.getReplicationPortGroup() != null)
                command.append(String.format(RPG, rule.getReplicationPortGroup().getName()));
        } else {
            command.append(String.format(PG, DROP));
        }
        if (rule.getApply() != null)
            command.append(String.format(APPLY, rule.getApply()));
        if (rule.getSubscriberTraffic() != null)
            command.append(String.format(SUBSCRIBER_TRAFFIC, rule.getSubscriberTraffic()));
        if (rule.getSamplingPolicy() != null)
            command.append(String.format(SAMPLING_POLICY, rule.getSamplingPolicy().getName()));
        if (rule.getImsiFileName() != null)
            command.append(String.format(IMSI, filePath));
        else if (rule.getImsi() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(IMSI, rule.getImsi() + "*"));
            else
                command.append(String.format(IMSI, rule.getImsi()));
        if (rule.getRange() != null)
            command.append(String.format(RANGE, rule.getRange()));
        if (rule.getImeiFileName() != null)
            command.append(String.format(IMEI, filePath));
        else if (rule.getImei() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(IMEI, rule.getImei() + "*"));
            else
                command.append(String.format(IMEI, rule.getImei()));
        if (rule.getApnFileName() != null)
            command.append(String.format(APN, filePath));
        else if (rule.getApn() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(APN, rule.getApn() + "*"));
            else
                command.append(String.format(APN, rule.getApn()));
        if (rule.getQci() != null)
            command.append(String.format(QCI, rule.getQci()));
        if (rule.getMcc() != null)
            command.append(String.format(MCC, rule.getMcc()));
        if (rule.getMnc() != null)
            command.append(String.format(MNC, rule.getMnc()));
        if (rule.getSipCallingPartyFileName() != null)
            command.append(String.format(SIP_CALLING_PARTY, filePath));
        else if (rule.getSipCallingParty() != null)
            command.append(String.format(SIP_CALLING_PARTY, rule.getSipCallingParty()));
        if (rule.getSipCalledPartyFileName() != null)
            command.append(String.format(SIP_CALLED_PARTY, filePath));
        else if (rule.getSipCalledParty() != null)
            command.append(String.format(SIP_CALLED_PARTY, rule.getSipCalledParty()));
        command.append(END);
        return command.toString();
    }

    /**
     * This method build the commands to delete Rule
     *
     * @param rule
     * @return delete command
     */
    protected String buildDeleteCommand(FilterRule rule, Device device) {
        StringBuilder command = new StringBuilder();
        command.append(DELETE_RULE);

        String filePath = getFilePath(rule, device);

        if (filePath != null)
            command = buildBulkFileDeleteCommand(filePath, command, rule);
        if (rule.getApply() != null)
            command.append(String.format(APPLY, rule.getApply()));
        if (rule.getSubscriberTraffic() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(SAMPLING_POLICY, rule.getSamplingPolicy()));
        if (rule.getImsi() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(IMSI, rule.getImsi() + "*"));
            else
                command.append(String.format(IMSI, rule.getImsi()));
        if (rule.getRange() != null)
            command.append(String.format(RANGE, rule.getRange()));
        if (rule.getImei() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(IMEI, rule.getImei() + "*"));
            else
                command.append(String.format(IMEI, rule.getImei()));
        if (rule.getApn() != null)
            if (rule.getSamplingPolicy() != null)
                command.append(String.format(APN, rule.getApn() + "*"));
            else
                command.append(String.format(APN, rule.getApn()));
        if (rule.getQci() != null)
            command.append(String.format(QCI, rule.getQci()));
        if (rule.getMcc() != null)
            command.append(String.format(MCC, rule.getMcc()));
        if (rule.getMnc() != null)
            command.append(String.format(MNC, rule.getMnc()));
        if (rule.getSipCallingParty() != null)
            command.append(String.format(SIP_CALLING_PARTY, rule.getSipCallingParty()));
        if (rule.getSipCalledParty() != null)
            command.append(String.format(SIP_CALLED_PARTY, rule.getSipCalledParty()));
        command.append(END);
        return command.toString();
    }

    protected StringBuilder buildBulkFileDeleteCommand(String filePath, StringBuilder command, FilterRule rule) {
        if (rule.getImsiFileName() != null)
            command.append(String.format(IMSI, filePath));
        if (rule.getImeiFileName() != null)
            command.append(String.format(IMEI, filePath));
        if (rule.getApnFileName() != null)
            command.append(String.format(APN, filePath));
        if (rule.getSipCallingPartyFileName() != null)
            command.append(String.format(SIP_CALLING_PARTY, filePath));
        if (rule.getSipCalledPartyFileName() != null)
            command.append(String.format(SIP_CALLED_PARTY, filePath));
        return command;
    }

    /**
     * This method fetches the ACTIVE SdFilterPolicy from history
     *
     * @param filterPolicyId
     * @return SdFilterPolicy This returns SdFilterPolicy from history
     */
    protected FilterPolicy getFilterPolicyFromHistory(Long filterPolicyId) {
        List<FilterPolicyHistory> filterPolicyHistoryList = filterPolicyHistoryRepository.findByIdAndWorkflowStatus(filterPolicyId, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        FilterPolicy sdFilterPolicy = null;
        if (filterPolicyHistoryList.size() >= 1) {
            FilterPolicyHistory sdFilterPolicyHistory = filterPolicyHistoryList.get(0);
            sdFilterPolicy = sdFilterPolicyHistory.buildParent();
        }
        return sdFilterPolicy;
    }

    /**
     * This method fetches the ACTIVE SamplingPolicy from history
     *
     * @param samplingPolicyId
     * @return SamplingPolicy This returns SamplingPolicy from history
     */
    protected SamplingPolicy getSamplingPolicyFromHistory(Long samplingPolicyId) {
        List<SamplingPolicyHistory> samplingPolicyHistoryList = samplingPolicyHistoryRepository.findByIdAndWorkflowStatus(samplingPolicyId, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        SamplingPolicy samplingPolicy = null;
        if (samplingPolicyHistoryList.size() >= 1) {
            SamplingPolicyHistory samplingPolicyHistory = samplingPolicyHistoryList.get(0);
            samplingPolicy = samplingPolicyHistory.buildParent();
        }
        return samplingPolicy;
    }

    /**
     * This method fetches the ACTIVE ActiveInterface from history
     *
     * @param activeInterfaceId
     * @return SamplingPolicy This returns ActiveInterface from history
     */
    protected ActiveInterface getActiveInterfaceFromHistory(Long activeInterfaceId) {
        List<ActiveInterfaceHistory> activeInterfaceHistoryList = activeInterfaceHistoryRepository.findByIdAndWorkflowStatus(activeInterfaceId, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        ActiveInterface activeInterface = null;
        if (activeInterfaceHistoryList.size() >= 1) {
            ActiveInterfaceHistory activeInterfaceHistory = activeInterfaceHistoryList.get(0);
            activeInterface = activeInterfaceHistory.buildParent();
        }
        return activeInterface;
    }


    private boolean compareSdRules(List<FilterRule> oSdRuleList, List<FilterRule> nSdRuleList, StringBuilder command) {

        return true;
    }

    protected List<FilterRule> getFilterRules(FilterPolicy filterPolicy) {
        ArrayList<FilterRule> filterRules = new ArrayList<>();
        filterPolicy.getRules().forEach(rule -> {
            filterRules.add(rule);
        });
        return filterRules;
    }

    /**
     * This method is used for comparing old filter object with new one and building Update command
     *
     * @param oldFilterPolicyRules
     * @param newFilterPolicyRules
     * @param command
     * @return
     */
    protected StringBuilder getUpdateCommand(List<FilterRule> oldFilterPolicyRules, List<FilterRule> newFilterPolicyRules, StringBuilder command, Device device) {
        Map<Long, Integer> oldFilterRuleIdHashMap = new ConcurrentHashMap<>();
        Map<Long, FilterRule> oldFilterRuleIdObjectMap = new ConcurrentHashMap<>();
        oldFilterPolicyRules.parallelStream().forEach(oldFilterPolicyRule -> {
            oldFilterRuleIdHashMap.put(oldFilterPolicyRule.getId(), oldFilterPolicyRule.hash());
            oldFilterRuleIdObjectMap.put(oldFilterPolicyRule.getId(), oldFilterPolicyRule);
        });

        Map<Long, Integer> newFilterRuleIdHashMap = new ConcurrentHashMap<>();
        Map<Long, FilterRule> newFilterRuleIdObjectMap = new ConcurrentHashMap<>();
        newFilterPolicyRules.parallelStream().forEach(newFilterPolicyRule -> {
            newFilterRuleIdHashMap.put(newFilterPolicyRule.getId(), newFilterPolicyRule.hash());
            newFilterRuleIdObjectMap.put(newFilterPolicyRule.getId(), newFilterPolicyRule);
        });

        MapDifference<Long, Integer> mapDifference = Maps.difference(oldFilterRuleIdHashMap, newFilterRuleIdHashMap);

        //deleted rules
        mapDifference.entriesOnlyOnLeft().forEach((id, hash) -> command.append(buildDeleteCommand(oldFilterRuleIdObjectMap.get(id), device)));

        //new rules
        mapDifference.entriesOnlyOnRight().forEach((id, hash) -> command.append(buildCreateCommand(newFilterRuleIdObjectMap.get(id), device)));

        //updated rules
        mapDifference.entriesDiffering().forEach((id, hash) -> {
            command.append(buildDeleteCommand(oldFilterRuleIdObjectMap.get(id), device));
            command.append(buildCreateCommand(newFilterRuleIdObjectMap.get(id), device));
        });
        return command;
    }

    /**
     * This method is used to create folder /opt/imsi_file & scp file into it
     *
     * @param device
     * @param fileName
     * @return
     * @throws Exception
     */
    public int copyFileToSd(Device device, String fileName) throws Exception {
        String deviceIp = device.getIpAddress();
        final SSHClient client = new SSHClient();
        Session session = null;
        client.addHostKeyVerifier(new PromiscuousVerifier());
        int exitStatus = -1;
        try {
            client.connect(deviceIp);
            client.authPassword(SD_DEVICE_USER, SD_DEVICE_PASSWORD);
            if (client.isConnected() && client.isAuthenticated()) {
                session = client.startSession();

                final Session.Command cmd = session.exec("mkdir /opt/sd_upload_dir;");
                log.debug("Command output: " + IOUtils.readFully(cmd.getInputStream()).toString());
                cmd.join(5, TimeUnit.SECONDS);
                exitStatus = cmd.getExitStatus();

                SFTPClient sftpClient = client.newSFTPClient();
                sftpClient.put(new FileSystemFile(evmServerFilePath + fileName), sdServerFilePath);
            } else {
                log.debug("SSHClient failed to connect/authenticate with IP : {}", deviceIp);
            }
        } finally {
            try {
                if (session != null) {
                    session.close();
                }
                if (client != null) {
                    client.disconnect();
                }
            } catch (IOException e) {
                log.error("Error while closing connection " + e.getLocalizedMessage());
            }
        }
        return exitStatus;
    }

    /**
     * This method is used to get file name
     *
     * @param device
     * @param rule
     * @return
     */
    public String getFilePath(FilterRule rule, Device device) {
        String fileName = null;
        if (rule.getImsiFileName() != null || rule.getImeiFileName() != null || rule.getApnFileName() != null || rule.getSipCallingPartyFileName() != null || rule.getSipCalledPartyFileName() != null) {
            if (rule.getImsiFileName() != null) {
                fileName = rule.getImsiFileName();
            } else if (rule.getImeiFileName() != null) {
                fileName = rule.getImeiFileName();
            } else if (rule.getApnFileName() != null) {
                fileName = rule.getApnFileName();
            } else if (rule.getSipCallingPartyFileName() != null) {
                fileName = rule.getSipCallingPartyFileName();
            } else if (rule.getSipCalledPartyFileName() != null) {
                fileName = rule.getSipCalledPartyFileName();
            }
            try {
                copyFileToSd(device, fileName);
            } catch (Exception e) {
                log.error("Error while copying file to sd device" + e.getMessage());
            }
        } else {
            return null;
        }
        return sdServerFilePath + fileName;
    }

    /**
     * This method is used to delete uploaded file from SD box
     *
     * @param device
     * @param files
     */
    public void deleteFilesFromSD(Device device, List<String> files) {
        String deviceIp = device.getIpAddress();
        final SSHClient client = new SSHClient();
        client.addHostKeyVerifier(new PromiscuousVerifier());
        try {
            client.connect(deviceIp);
            client.authPassword(SD_DEVICE_USER, SD_DEVICE_PASSWORD);
            final Session session = client.startSession();
            try {
                String fileName = "";
                for (String file : files) {
                    fileName = fileName.concat(file).concat(" ");
                }
                final Session.Command cmd = session.exec("cd /opt/sd_upload_dir;rm -rf " + fileName.trim() + ";");
                log.debug("Command output: " + IOUtils.readFully(cmd.getInputStream()).toString());
                cmd.join(5, TimeUnit.SECONDS);
            } finally {
                if (session != null) {
                    session.close();
                }
            }
        } catch (Exception e) {
            log.error("Error while deleting file from SD while recovery " + e.getLocalizedMessage());
        } finally {
            try {
                client.disconnect();
                client.close();
            } catch (IOException e) {
                log.error("Error while closing connection " + e.getLocalizedMessage());
            }
        }
    }

}
