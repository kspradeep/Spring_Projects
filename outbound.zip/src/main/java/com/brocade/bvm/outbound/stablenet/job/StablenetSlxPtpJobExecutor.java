package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.dao.PortHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.TargetHost;
import com.brocade.bvm.model.db.history.PortHistory;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

@Named
public class StablenetSlxPtpJobExecutor extends AbstractStablenetJobExecutor {

    protected static final String CONFIGURE_TERMINAL = "configure terminal;";
    private static final String PROTOCOL_PTP = "protocol ptp;";
    private static final String ENABLE = "enable;";
    private static final String DISABLE = "no enable;";
    private static final String END = "end";


    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SLX_PTP_ENABLE, Job.Type.SLX_PTP_DISABLE, Job.Type.SLX_PTP_DELETE);
    }

    @Override
    public Device.Mode getSupportedMode() {
        return Device.Mode.PLAIN;
    }

    /**
     * This method is used to build commands to enable/disable PTP
     *
     * @param job
     * @return OutboundJobResponse This returns response
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        commands.append(PROTOCOL_PTP);
        if (job.getType() == Job.Type.SLX_PTP_ENABLE) {
            commands.append(ENABLE);
        } else {
            commands.append(DISABLE);
        }
        commands.append(END);
        return commands.toString();
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SLX);
    }
}
