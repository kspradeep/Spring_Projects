package com.brocade.bvm.outbound.stablenet.commands;

import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.RuleSet;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

/**
 * Created by dneelapa on 7/13/2016.
 */

@Getter
@NoArgsConstructor
public class StablenetPolicyDiff {

    @Setter
    private boolean oldUdaOffSetStatus;

    @Setter
    private boolean isUdaOffSetChanged;

    @Setter
    private String routeMapName;

    @Setter
    private Set<Port> deletedIngressPorts;

    @Setter
    private Set<Port> addedIngressPorts;

    @Setter
    private Set<Port> unchangedIngressPorts;

    @Setter
    private Set<Integer> deletedSeqs;

    @Setter
    private Set<Integer> addedSeqs;

    @Setter
    private Set<Integer> updatedSeqs;

    @Setter
    private SortedSet<RuleSet> deletedRuleSets;

    @Setter
    private SortedSet<RuleSet> addedRuleSets;

    @Setter
    private Set<RuleSet.Type> deletedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> deletedRuleSetIpList;

    @Setter
    private Set<RuleSet.Type> addedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> addedRuleSetIpList;

    @Setter
    private Set<RuleSet.Type> updatedRuleSetTypeList;

    @Setter
    private Set<RuleSet.IpVersion> updatedRuleSetIpList;

    @Setter
    //port_number
    private Map<String, RuleSetDiff> policyMap;

    @Setter
    //route-map/sequence
    private Map<Integer, RuleSetDiff> flowMap;

    @Setter
    //acl_type
    private Map<RuleSet.Type, List<RuleDiff>> ruleSetTypeMap;

    @Setter
    //acl_type
    private Map<RuleSet.IpVersion, List<RuleDiff>> ruleSetIpVersionMap;

    @Setter
    private VlanDiff vlanDiff;

    @Setter
    private TvfDiff tvfDiff;

    @Setter
    private boolean isRulesUpdatedForPolicy;

    @Setter
    private boolean isRulesDeletedForPolicy;

    @Setter
    private boolean isRulesAddedForPolicy;

    @Setter
    private Set<Long> updatedRules;

    @Setter
    private Set<RuleSet.Type> ruleSetsTypeToUnmap;

    @Setter
    private Set<RuleSet.IpVersion> ruleSetsIpVersionToUnmap;

    @Setter
    private String gtpFlag;

    @Setter
    private boolean oldPreserveHeader;

    @Setter
    private boolean newPreserveHeader;

}
