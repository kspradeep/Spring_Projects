package com.brocade.bvm.outbound.exception;

import com.brocade.bvm.model.exception.ServerException;

public class OutboundConnectionException extends ServerException {
    public OutboundConnectionException(Throwable cause) {
        super(cause);
    }

    public OutboundConnectionException(String message) {
        super(message);
    }
}
