package com.brocade.bvm.outbound.stablenet.job.sessiondirector;

import com.brocade.bvm.dao.sessiondirector.GlobalConfigHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.GlobalConfigRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.GlobalConfigHistory;
import com.brocade.bvm.model.db.sessiondirector.GlobalConfig;
import com.brocade.bvm.outbound.stablenet.job.AbstractStablenetJobExecutor;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Named
public class UpdateSdGlobalConfigJobExecutor extends AbstractStablenetJobExecutor {

    @Inject
    private GlobalConfigRepository globalConfigRepository;

    @Inject
    private GlobalConfigHistoryRepository globalConfigHistoryRepository;

    protected static final String SET_MODE = "set sd-mode mode=%s;";

    protected static final String SET_FCR = "setFCR;";

    protected static final String CLEAR_FCR = "clearFCR;";

    protected static final String SET_S11_DROP = "set s11-drop;";

    protected static final String CLEAR_S11_DROP = "clear s11-drop;";

    protected static final String SET_RX_TX = "interface;edit interface=s11-s1u-gngp;set dir-based-split;";

    protected static final String CLEAR_RX_TX = "interface;edit interface=s11-s1u-gngp;clear dir-based-split;";

    protected static final String SET_FCR_FILE_TIME = "set fcrfile-mtime %d;";

    protected static final String SET_SGI_CORRELATION = "set sgi-correlation;";

    protected static final String CLEAR_SGI_CORRELATION = "clear sgi-correlation;";

    protected static final String SET_SIP_PORT = "set sip-port ports=%s;";

    protected static final String CLEAR_SIP_PORT = "clear sip-port ports=%s;";

    protected static final String SET_IP_FRAGMENTATION = "set gtpu-ipfrag;";

    protected static final String CLEAR_IP_FRAGMENTATION = "clear gtpu-ipfrag;";

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.SD_GLOBAL_CONFIG_UPDATE);
    }

    @Override
    public List<Device.Type> getSupportedDeviceTypes() {
        return Lists.newArrayList(Device.Type.SD);
    }

    /**
     * This method constructs set Global Configuration on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        StringBuilder commands = new StringBuilder(CONFIGURE_TERMINAL);
        GlobalConfig globalConfig = globalConfigRepository.findOne(job.getParentObjectId());
        GlobalConfig globalConfigFromHistory = getGlobalConfigFromHistory(globalConfig);

        if (globalConfigFromHistory != null) {
            if (!globalConfigFromHistory.getMode().equals(globalConfig.getMode())) {
                commands.append(String.format(SET_MODE, globalConfig.getMode().name()));
            }
            if (globalConfigFromHistory.getS11DropStatus() != globalConfig.getS11DropStatus()) {
                commands.append(globalConfig.getS11DropStatus() ? SET_S11_DROP : CLEAR_S11_DROP);
            }
            if (globalConfigFromHistory.getRxTxSplitStatus() != globalConfig.getRxTxSplitStatus()) {
                commands.append(globalConfig.getRxTxSplitStatus() ? SET_RX_TX : CLEAR_RX_TX);
                commands.append(EXIT);
            }
            if (globalConfigFromHistory.getSgiCorrelationStatus() != globalConfig.getSgiCorrelationStatus()) {
                commands.append(globalConfig.getSgiCorrelationStatus() ? SET_SGI_CORRELATION : CLEAR_SGI_CORRELATION);
            }
            if (globalConfigFromHistory.getFcrFileTime() != globalConfig.getFcrFileTime()) {
                commands.append(String.format(SET_FCR_FILE_TIME, globalConfig.getFcrFileTime()));
            }
            if (!globalConfigFromHistory.getSipPorts().containsAll(globalConfig.getSipPorts()) || !globalConfig.getSipPorts().containsAll(globalConfigFromHistory.getSipPorts())) {
                Set addedPorts = new HashSet<>(globalConfig.getSipPorts());
                addedPorts.removeAll(globalConfigFromHistory.getSipPorts());
                Set removedPorts = new HashSet<>(globalConfigFromHistory.getSipPorts());
                removedPorts.removeAll(globalConfig.getSipPorts());
                if (!addedPorts.isEmpty()) {
                    commands.append(String.format(SET_SIP_PORT, addedPorts.stream().map(Object::toString).collect(Collectors.joining(","))));
                }
                if (!removedPorts.isEmpty()) {
                    commands.append(String.format(CLEAR_SIP_PORT, removedPorts.stream().map(Object::toString).collect(Collectors.joining(","))));
                }
            }
            if (globalConfigFromHistory.getFcrStatus() != globalConfig.getFcrStatus()) {
                commands.append(globalConfig.getFcrStatus() ? SET_FCR : CLEAR_FCR);
            }
            if (globalConfigFromHistory.getIpFragmentationStatus() != globalConfig.getIpFragmentationStatus()) {
                commands.append(globalConfig.getIpFragmentationStatus() ? SET_IP_FRAGMENTATION : CLEAR_IP_FRAGMENTATION);
            }
        } else {
            commands.append(String.format(SET_MODE, globalConfig.getMode().name()));
            commands.append(globalConfig.getS11DropStatus() ? SET_S11_DROP : CLEAR_S11_DROP);
            commands.append(globalConfig.getRxTxSplitStatus() ? SET_RX_TX : CLEAR_RX_TX);
            commands.append(globalConfig.getSgiCorrelationStatus() ? SET_SGI_CORRELATION : CLEAR_SGI_CORRELATION);
            commands.append(String.format(SET_SIP_PORT, globalConfig.getSipPorts().stream().map(Object::toString).collect(Collectors.joining(","))));
            commands.append(String.format(SET_FCR_FILE_TIME, globalConfig.getFcrFileTime()));
            commands.append(globalConfig.getFcrStatus() ? SET_FCR : CLEAR_FCR);
            commands.append(globalConfig.getIpFragmentationStatus() ? SET_IP_FRAGMENTATION : CLEAR_IP_FRAGMENTATION);
        }
        commands.append(EXIT);
        return commands.toString();
    }

    /**
     * This method fetches the latest ACTIVE globalConfig from history for the current policy
     *
     * @param globalConfig
     * @return Policy returns latest ACTIVE policy
     */
    protected GlobalConfig getGlobalConfigFromHistory(GlobalConfig globalConfig) {
        // get the previous policy name from the history.
        GlobalConfig globalConfigFromHistory = null;
        List<GlobalConfigHistory> globalConfigFromHistoryList = globalConfigHistoryRepository.findByIdAndWorkflowStatus(globalConfig.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (!globalConfigFromHistoryList.isEmpty()) {
            GlobalConfigHistory oldConfig = globalConfigFromHistoryList.get(0);
            globalConfigFromHistory = oldConfig.buildParent();
        }
        return globalConfigFromHistory;
    }
}
