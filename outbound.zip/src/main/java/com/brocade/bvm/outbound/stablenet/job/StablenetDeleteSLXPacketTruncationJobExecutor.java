package com.brocade.bvm.outbound.stablenet.job;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

@Slf4j
@Named
public class StablenetDeleteSLXPacketTruncationJobExecutor extends AbstractStablenetSLXPacketTruncationJobExecutor {

    @Override
    public List<Job.Type> getSupportedJobTypes() {
        return Lists.newArrayList(Job.Type.PACKET_TRUNCATION_PROFILE_DELETE);
    }

    /**
     * This method builds packet truncation Delete commands to be executed on the given device
     *
     * @param job
     * @return String This returns command string
     */
    @Override
    public String getCommands(Job job) {
        PacketTruncationMapping packetTruncationMapping = (PacketTruncationMapping) getParentObject(job);
        String command = buildCommand(packetTruncationMapping);
        log.info("Stablenet SLX command generated from Job Id {} on device {} for packet truncation id {} is {}", job.getId(), job.getDevice().getId(), packetTruncationMapping.getId(), command);
        return command;
    }

    public String buildCommand(PacketTruncationMapping packetTruncationMapping) {
        StringBuilder command = new StringBuilder();
        command.append(CONFIGURE_TERMINAL);
        command.append(String.format(NO_TRUNCATION_PROFILE_NAME, packetTruncationMapping.getName()));
        command.append(EXIT);
        return command.toString();
    }
}
