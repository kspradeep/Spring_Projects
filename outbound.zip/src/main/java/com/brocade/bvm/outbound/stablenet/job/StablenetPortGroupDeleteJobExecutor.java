package com.brocade.bvm.outbound.stablenet.job;

import java.util.List;

import javax.inject.Named;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Job.Type;
import com.brocade.bvm.model.db.PortGroup;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

/**
 * The StablenetPortGroupDeleteJobExecutor class implements methods to delete portGroup on Non Open Flow device through Stablenet
 */
@Slf4j
@Named
public class StablenetPortGroupDeleteJobExecutor extends AbstractStablenetPortGroupJobExecutor {

	@Override
	public List<Type> getSupportedJobTypes() {
		return Lists.newArrayList(Type.PORT_GROUP_DELETE);
	}

	/**
	 * This method constructs portGroup delete commands to be executed on the given device
	 *
	 * @param job
	 * @return String This returns command string
	 */
	@Override
	public String getCommands(Job job) {
	    PortGroup portGroup = (PortGroup)getParentObject(job);
		StringBuilder cmd = new StringBuilder();
		if (portGroup != null) {
			cmd.append(CONFIGURE_TERMINAL);
			cmd.append(buildUnMapPortFromGtpProfile(portGroup));
			cmd.append(buildDeleteCommand(portGroup));
			cmd.append(END);
			cmd.append(WRITE_MEMORY);
		} else {
			log.error("PortGroup object is null.");
		}
		log.debug("PortGroup Delete CMD: {}", cmd);
		return cmd.toString();
	}
}
