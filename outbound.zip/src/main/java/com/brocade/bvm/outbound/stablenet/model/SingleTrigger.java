package com.brocade.bvm.outbound.stablenet.model;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * Used in scheduling the StableNet Rest Job.
 */
public class SingleTrigger {
    @XmlAttribute
    private String active = "false";
    @XmlAttribute
    private String start;
}
