package com.brocade.bvm.outbound;

import com.brocade.bvm.model.db.FirmwareJob;
import lombok.*;

@ToString
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Setter
public class FirmwareOutboundJobResponse {
    private FirmwareJob.Status status;
    private String jobResult;
}
