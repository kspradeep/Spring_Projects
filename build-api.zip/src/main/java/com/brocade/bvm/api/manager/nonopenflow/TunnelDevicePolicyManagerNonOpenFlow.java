package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractDevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.TunnelDevicePolicy;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/**
 * The TunnelDevicePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover GRE/MPLS TunnelDevicePolicy for NonOpenFlow
 */
@Named
public class TunnelDevicePolicyManagerNonOpenFlow extends AbstractDevicePolicyManager {

    public static final String TUNNEL_ID_PATTERN = "[0-9]+";

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private TunnelDevicePolicyRepository tunnelDevicePolicyRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * This method checks if TunnelDevicePolicy data is valid to commit on the given device
     *
     * @param policy
     * @return boolean
     */
    @Override
    protected boolean isValidPolicy(DevicePolicy policy) {
        if (policy != null) {
            Device device = deviceRepository.findOne(policy.getDevice().getId());
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("tunnel.policy.not.supported.device");
            }
            TunnelDevicePolicy tunnelDevicePolicy = (TunnelDevicePolicy) policy;
            if (tunnelDevicePolicy.getDevice().getId() == null) {
                return false;
            }
            if (tunnelDevicePolicy.getName() == null || tunnelDevicePolicy.getName().isEmpty()) {
                return false;
            }
            if (tunnelDevicePolicy.getType() == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * This method is used to create TunnelDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long commitPolicy(DevicePolicy policy) {
        TunnelDevicePolicy tunnelDevicePolicy = (TunnelDevicePolicy) policy;
        isValidPolicy(tunnelDevicePolicy);
        isValidPolicyToCommit(tunnelDevicePolicy);
        tunnelDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        tunnelDevicePolicy = devicePolicyRepository.save(tunnelDevicePolicy);
        // Setting job type based on TunnelDevicePolicy type
        Job.Type type = Job.Type.MPLS_TUNNEL_UPDATE;
        if (tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.GRE) {
            type = Job.Type.GRE_TUNNEL_UPDATE;
        }
        Long jobId = jobQueue.submit(JobTemplate.builder().type(type)
                .deviceId(tunnelDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(tunnelDevicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method checks if TunnelDevicePolicy data is valid to commit on the given device
     *
     * @param tunnelDevicePolicy
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(TunnelDevicePolicy tunnelDevicePolicy) {
        TunnelDevicePolicy.Type type = tunnelDevicePolicy.getType();
        List<TunnelDevicePolicy.Type> typeList = Arrays.asList(TunnelDevicePolicy.Type.MPLS, TunnelDevicePolicy.Type.GRE);
        if (type == null || !typeList.contains(type)) {
            throw new ValidationException("tunnelDevicePolicy.type.invalid");
        }

        String tunnelName = tunnelDevicePolicy.getName();
        if (tunnelName == null) {
            if (type == TunnelDevicePolicy.Type.GRE)
                throw new ValidationException("tunnelDevicePolicy.id.invalid");
            else if (type == TunnelDevicePolicy.Type.MPLS)
                throw new ValidationException("tunnelDevicePolicy.name.invalid");
        }
        if (tunnelName != null) {
            if (type == TunnelDevicePolicy.Type.MPLS) {
                if (tunnelName.length() > TunnelDevicePolicy.TUNNEL_NAME_LENGTH_MAX) {
                    throw new ValidationException("tunnelDevicePolicy.name.lengthInvalid");
                }
            } else if (type == TunnelDevicePolicy.Type.GRE) {
                Pattern pattern = Pattern.compile(TUNNEL_ID_PATTERN);

                if (!pattern.matcher(tunnelName).matches()) {
                    throw new ValidationException("tunnelDevicePolicy.tunnelId.notNumber");
                }
                int tunnelId = Integer.parseInt(tunnelName);
                if (tunnelId < TunnelDevicePolicy.TUNNEL_ID_MIN || tunnelId > TunnelDevicePolicy.TUNNEL_ID_MAX) {
                    throw new ValidationException("tunnelDevicePolicy.tunnelId.notValidRange");
                }
            }
        }
        return true;
    }

    /**
     * This method is used to update TunnelDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long updatePolicy(DevicePolicy policy) {
        TunnelDevicePolicy tunnelDevicePolicy = (TunnelDevicePolicy) policy;
        isValidPolicy(tunnelDevicePolicy);
        Long jobId = null;
        if (tunnelDevicePolicy.getId() == null) {
            jobId = commitPolicy(tunnelDevicePolicy);
        } else {
            TunnelDevicePolicy oldDevicePolicy = (TunnelDevicePolicy) devicePolicyRepository.findOne(tunnelDevicePolicy.getId());
            if (oldDevicePolicy == null) {
                throw new ValidationException("tunnelDevicePolicy.id.invalid");
            }
            boolean isSave = false;
            if (isPolicyUnChanged(oldDevicePolicy, tunnelDevicePolicy)) {
                throw new ValidationException("tunnelDevicePolicy.data.unChanged");
            }

            isValidPolicyToCommit(tunnelDevicePolicy);
            // Merging updated data
            oldDevicePolicy.setType(tunnelDevicePolicy.getType());
            oldDevicePolicy.setName(tunnelDevicePolicy.getName());
            oldDevicePolicy.setEnabled(tunnelDevicePolicy.isEnabled());
            oldDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            oldDevicePolicy = devicePolicyRepository.save(oldDevicePolicy);
            jobId = oldDevicePolicy.getId();
            // Setting job type based on TunnelDevicePolicy type
            Job.Type type = Job.Type.MPLS_TUNNEL_UPDATE;
            if (tunnelDevicePolicy.getType() == TunnelDevicePolicy.Type.GRE) {
                type = Job.Type.GRE_TUNNEL_UPDATE;
            }
            if (!isSave) {
                jobId = jobQueue.submit(JobTemplate.builder().type(type)
                        .deviceId(oldDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                        .parentObjectId(oldDevicePolicy.getId()).build());
            }
        }
        return jobId;
    }

    /**
     * This method checks if TunnelDevicePolicy data is updated
     *
     * @param oldDevicePolicy
     * @param newDevicePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(TunnelDevicePolicy oldDevicePolicy, TunnelDevicePolicy newDevicePolicy) {
        if (!oldDevicePolicy.getName().equals(newDevicePolicy.getName())) {
            return false;
        }
        if (oldDevicePolicy.isEnabled() != newDevicePolicy.isEnabled()) {
            return false;
        }
        return true;
    }

    /**
     * This method is used to delete TunnelDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(Long policyId) {
        TunnelDevicePolicy devicePolicy = (TunnelDevicePolicy) devicePolicyRepository.findOne(policyId);
        // Validate
        // 1. DevicePolicy present in DB
        if (devicePolicy == null) {
            throw new ValidationException("tunnelDevicePolicy.id.invalid");
        }
        isValidPolicy(devicePolicy);
        List<Long> flowIds = policyRepository.findFlowIdsByTunnelId(devicePolicy.getId());
        if (!flowIds.isEmpty()) {
            throw new ValidationException("tunnelDevicePolicy.used.inPolicy");
        }

        // 2. DevicePolicy not in active state.
        if (devicePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            throw new ValidationException("tunnelDevicePolicy.delete.policyApplied");
        }
        devicePolicyRepository.delete(devicePolicy);
        return -1L;
    }

    /**
     * This method is used to recover TunnelDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        return deletePolicy(policyId);
    }
}
