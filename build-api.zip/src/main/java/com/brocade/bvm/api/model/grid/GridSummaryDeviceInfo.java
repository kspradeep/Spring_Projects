package com.brocade.bvm.api.model.grid;

import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class GridSummaryDeviceInfo {

    private String deviceName;

    private TYPE type;

    private Set<GridSummaryInterfaceGroup> tapInterfaces = Sets.newHashSet();

    public void addTapInterfaces(GridSummaryInterfaceGroup gridSummaryInterfaceGroup) {
        tapInterfaces.add(gridSummaryInterfaceGroup);
    }

    private Set<GridSummaryInterfaceGroup> toolInterfaces = Sets.newHashSet();

    public void addToolInterfaces(GridSummaryInterfaceGroup gridSummaryInterfaceGroup) {
        toolInterfaces.add(gridSummaryInterfaceGroup);
    }

    public enum TYPE {
        AGGREGATOR,
        DISTRIBUTOR
    }
}