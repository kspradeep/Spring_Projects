package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.GridUIPolicySummary;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.model.grid.GridDeviceInfoRequest;
import com.brocade.bvm.api.model.grid.GridSummary;
import com.brocade.bvm.api.model.grid.GridSummaryDeviceInfo;
import com.brocade.bvm.api.model.grid.GridSummaryInterfaceGroup;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.grid.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.grid.PolicySetInterface;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The GridUIController class implements methods to fetch EVM grid data to display in UI
 */
@Slf4j
@RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/ui/grid")
@RestController
public class GridUIController {

    @Value("${slx.grid.supported.os.version:18}")
    private int slxGridSupportedVersion;

    private static final String PORT_GROUP = "PORT_CHANNEL";
    private static final String PORT = "PORT";

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private GridRepository gridRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private GridPolicyRepository gridPolicyRepository;

    /**
     * This method fetches all policies for the given grid id
     *
     * @param gridId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/{gridId}/policy")
    public ResponseEntity<Object> getAllGridPoliciesById(@PathVariable("gridId") Long gridId) {
        Map<String, Object> map = new HashMap<>();
        if (gridId != null) {
            List<GridPolicySet> gridPolicySets = gridPolicySetRepository.findByGridId(gridId);
            GridUIPolicySummary policySummaryOnDevice = new GridUIPolicySummary(gridPolicySets);
            map.put("policySummaries", policySummaryOnDevice.getPolicySets());
        }
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * Method fetches the devices by type and reconciled and perform RBAC.
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/devices")
    public ResponseEntity<Object> getAllDevices() {
        JSONArray devicesResponseArray = new JSONArray();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            List<Device> devices = deviceRepository.findAllByIdsAndTypeAndReconciledAndProfileSet(stablenetDeviceIds, Lists.newArrayList(Device.Type.SLX));
            devices.stream().forEach(device -> {
                if (!Strings.isNullOrEmpty(device.getOs())) {
                    Pattern pattern = Pattern.compile("^([A-Za-z]*)(\\d+)(\\w*)(\\.\\d+)");
                    Matcher matcher = pattern.matcher(device.getOs());
                    if (matcher.find() && matcher.groupCount() == 4) {
                        String version = matcher.group(2);
                        if (!Strings.isNullOrEmpty(version) && Integer.parseInt(version) >= slxGridSupportedVersion && "s".equals(matcher.group(3))) {
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put("id", device.getId());
                                jsonObject.put("name", device.getName());
                                jsonObject.put("type", device.getType());
                                jsonObject.put("model", device.getModel());
                                List<Object[]> clusterIds = gridClusterRepository.findAllByDeviceId(device.getId());
                                if (!clusterIds.isEmpty()) {
                                    Object[] clusterArray = clusterIds.stream().findAny().get();
                                    if (clusterArray != null && clusterArray.length > 2) {
                                        if (clusterArray[2] != null) {
                                            jsonObject.put("gridId", clusterArray[2]);
                                            jsonObject.put("gridType", DeviceGrid.TYPE.DISTRIBUTOR);
                                        } else if (clusterArray[1] != null) {
                                            jsonObject.put("gridId", clusterArray[1]);
                                            jsonObject.put("gridType", DeviceGrid.TYPE.AGGREGATOR);
                                        }
                                    }
                                }
                                JSONArray interfaceArray = new JSONArray();

                                Set<PortGroup> portGroups = new HashSet<>(portGroupRepository.findByDeviceIdAndWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE)));
                                Set<Long> portGroupMemberIds = Sets.newHashSet();
                                portGroups.forEach(portGroup -> {
                                    portGroupMemberIds.addAll(portGroup.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                                });
                                Set<Long> portIds = Sets.newHashSet();
                                device.getModules().forEach(module -> portIds.addAll(module.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet())));
                                Set<Long> portIdsInGrid = Sets.newHashSet();
                                if (portIds != null && !portIds.isEmpty()) {
                                    Set<Long> portIdsInGridFromDb = clusterNodeInterfaceRepository.findAllPortIdsById(portIds)
                                            .stream().mapToLong(value -> value.longValue()).boxed().collect(Collectors.toSet());
                                    if (portIdsInGridFromDb != null) {
                                        portIdsInGrid.addAll(portIdsInGridFromDb);
                                    }
                                }
                                device.getModules().forEach(module -> {
                                    List<Port> ports = Lists.newArrayList(module.getPorts());
                                    Collections.sort(ports);
                                    ports.stream().filter(port -> Port.Type.SERVICE_PORT != port.getType()).forEach(port -> {
                                        if (!portGroupMemberIds.contains(port.getId())) {
                                            try {
                                                JSONObject interfaceJsonObject = new JSONObject();
                                                interfaceJsonObject.put("id", port.getId());
                                                interfaceJsonObject.put("name", port.getName());
                                                interfaceJsonObject.put("objectType", PORT);
                                                interfaceJsonObject.put("type", port.getType());
                                                interfaceJsonObject.put("workflowStatus", port.getWorkflowStatus());
                                                interfaceJsonObject.put("isInUse", portIdsInGrid.contains(port.getId()) ? true : false);
                                                interfaceArray.put(interfaceJsonObject);
                                            } catch (JSONException e) {
                                                log.error("Failed to generate the device JSON for port. {}", e.getMessage());
                                            }
                                        }
                                    });
                                });
                                if (!portGroups.isEmpty()) {
                                    Set<Long> portGroupIdsInGrid = Sets.newHashSet();
                                    Set<Long> portGroupIds = portGroups.stream().map(ManagedObject::getId).collect(Collectors.toSet());
                                    if (portGroupIds != null && !portGroupIds.isEmpty()) {
                                        Set<Long> portGroupIdsInGridFromDb = clusterNodeInterfaceRepository.findAllPortIdsById(portGroupIds)
                                                .stream().mapToLong(value -> value.longValue()).boxed().collect(Collectors.toSet());
                                        if (portGroupIdsInGridFromDb != null) {
                                            portGroupIdsInGrid.addAll(portGroupIdsInGridFromDb);
                                        }
                                    }
                                    portGroups.stream().filter(portGroup -> Port.Type.SERVICE_PORT != portGroup.getType()).forEach(portGroup -> {
                                        try {
                                            JSONObject interfaceJsonObject = new JSONObject();
                                            interfaceJsonObject.put("id", portGroup.getId());
                                            interfaceJsonObject.put("name", portGroup.getName());
                                            interfaceJsonObject.put("objectType", PORT_GROUP);
                                            interfaceJsonObject.put("workflowStatus", portGroup.getWorkflowStatus());
                                            interfaceJsonObject.put("isInUse", portGroupIdsInGrid.contains(portGroup.getId()) ? true : false);
                                            JSONArray portArray = new JSONArray();
                                            for (Port port : portGroup.getPorts()) {
                                                interfaceJsonObject.put("type", port.getType());
                                                JSONObject portJsonObject = new JSONObject();
                                                portJsonObject.put("id", port.getId());
                                                portJsonObject.put("name", port.getName());
                                                portArray.put(portJsonObject);
                                            }
                                            interfaceJsonObject.put("ports", portArray);
                                            interfaceArray.put(interfaceJsonObject);
                                        } catch (JSONException e) {
                                            log.error("Failed to generate the device JSON for port group. {}", e.getMessage());
                                        }
                                    });
                                }
                                jsonObject.put("interfaces", interfaceArray);
                                devicesResponseArray.put(jsonObject);
                            } catch (JSONException e) {
                                log.error("Failed to generate the device JSON. {}", e.getMessage());
                            }

                        }
                    }
                }
            });
        }
        return new ResponseEntity<>(devicesResponseArray.toString(), HttpStatus.OK);
    }

    /**
     * This method fetches the device grid for the given gridId
     *
     * @param gridId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{gridId}/tapinterfaces")
    public ResponseEntity<Object> getGridTapInterfaces(@PathVariable("gridId") Long gridId) throws JSONException {
        if (gridId != null) {
            DeviceGrid deviceGrid = gridRepository.findOne(gridId);
            if (deviceGrid != null) {
                JSONObject interfaceObject = new JSONObject();
                JSONArray tapInterfaceArray = new JSONArray();
                JSONArray toolInterfaceArray = new JSONArray();
                JSONArray participatingTapInterfaceArray = new JSONArray();

                List<PolicySetInterface> tapInterfaces = Lists.newArrayList();
                Set<Long> tapClusterNodeIds = Sets.newHashSet();
                deviceGrid.getSourceNodes().forEach(networkNode -> {
                    networkNode.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        tapClusterNodeIds.add(clusterNodeInterface.getId());
                        try {
                            JSONObject tapJsonObject = new JSONObject();
                            tapJsonObject.put("id", clusterNodeInterface.getId());
                            tapJsonObject.put("name", clusterNodeInterface.getName());
                            tapInterfaceArray.put(tapJsonObject);
                        } catch (JSONException e) {
                            log.error("Failed to generate the JSON for get grid tap interfaces. {}", e.getMessage());
                        }
                    });
                });
                if (!tapClusterNodeIds.isEmpty()) {
                    tapInterfaces.addAll(gridPolicyRepository.getPolicyTapInterfaces(tapClusterNodeIds));
                }
                List<PolicySetInterface> toolInterfaces = Lists.newArrayList();
                Set<Long> toolClusterNodeIds = Sets.newHashSet();
                deviceGrid.getDestinationNodes().forEach(networkNode -> {
                    networkNode.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        toolClusterNodeIds.add(clusterNodeInterface.getId());
                        try {
                            JSONObject toolJsonObject = new JSONObject();
                            toolJsonObject.put("id", clusterNodeInterface.getId());
                            toolJsonObject.put("name", clusterNodeInterface.getName());
                            toolInterfaceArray.put(toolJsonObject);
                        } catch (JSONException e) {
                            log.error("Failed to generate the JSON for get grid tool interfaces. {}", e.getMessage());
                        }
                    });
                });
                if (!toolClusterNodeIds.isEmpty()) {
                    toolInterfaces.addAll(gridPolicyRepository.getPolicyToolInterfaces(toolClusterNodeIds));
                }
                if (!tapInterfaces.isEmpty()) {
                    tapInterfaces.forEach(tapInterface -> {
                        try {
                            ClusterNodeInterface clusterNodeInterface = clusterNodeInterfaceRepository.findOne(tapInterface.getClusterNodeId());
                            if (clusterNodeInterface != null) {
                                JSONObject portJsonObject = new JSONObject();
                                portJsonObject.put("policySetId", tapInterface.getPolicySetId());
                                portJsonObject.put("id", clusterNodeInterface.getId());
                                portJsonObject.put("name", clusterNodeInterface.getName());
                                participatingTapInterfaceArray.put(portJsonObject);
                            }
                        } catch (JSONException e) {
                            log.error("Failed to generate the JSON for get grid tap interfaces. {}", e.getMessage());
                        }
                    });
                }
                interfaceObject.put("tapInterfaces", tapInterfaceArray);
                interfaceObject.put("toolInterfaces", toolInterfaceArray);
                interfaceObject.put("participatingTapInterfaces", participatingTapInterfaceArray);
                return new ResponseEntity<>(interfaceObject.toString(), HttpStatus.OK);
            }
        }
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method is used to fetch devices for Grid based on type
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/summary")
    public ResponseEntity<Object> getGridSummary() {
        Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
        Set<GridSummary> deviceGridsSummary = Sets.newHashSet();
        if (!deviceGrids.isEmpty()) {
            deviceGrids.forEach(deviceGrid -> {
                GridSummary gridSummary = new GridSummary();
                gridSummary.setId(deviceGrid.getId());
                gridSummary.setName(deviceGrid.getName());
                gridSummary.setDescription(deviceGrid.getDescription());
                gridSummary.setWorkflowStatus(deviceGrid.getWorkflowStatus());
                deviceGrid.getSourceNodes().forEach(networkNode -> {
                    GridSummaryDeviceInfo gridSummaryDeviceInfo = new GridSummaryDeviceInfo();
                    gridSummaryDeviceInfo.setDeviceName(networkNode.getDevice().getName());
                    gridSummaryDeviceInfo.setType(GridSummaryDeviceInfo.TYPE.AGGREGATOR);
                    gridSummary.addData(gridSummaryDeviceInfo);

                    networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                        GridSummaryInterfaceGroup gridSummaryInterfaceGroup = new GridSummaryInterfaceGroup();
                        gridSummaryInterfaceGroup.setName(networkNodeInterface.getName());

                        Set<String> interfaces = Sets.newHashSet();
                        interfaces.addAll(networkNodeInterface.getPorts().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
                        interfaces.addAll(networkNodeInterface.getPortGroups().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
                        gridSummaryInterfaceGroup.setInterfaces(interfaces);

                        gridSummaryDeviceInfo.addTapInterfaces(gridSummaryInterfaceGroup);
                    });
                });

                deviceGrid.getDestinationNodes().forEach(networkNode -> {
                    GridSummaryDeviceInfo gridSummaryDeviceInfo = new GridSummaryDeviceInfo();
                    gridSummaryDeviceInfo.setDeviceName(networkNode.getDevice().getName());
                    gridSummaryDeviceInfo.setType(GridSummaryDeviceInfo.TYPE.DISTRIBUTOR);
                    gridSummary.addData(gridSummaryDeviceInfo);

                    networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                        GridSummaryInterfaceGroup gridSummaryInterfaceGroup = new GridSummaryInterfaceGroup();
                        gridSummaryInterfaceGroup.setName(networkNodeInterface.getName());

                        Set<String> interfaces = Sets.newHashSet();
                        interfaces.addAll(networkNodeInterface.getPorts().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
                        interfaces.addAll(networkNodeInterface.getPortGroups().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
                        gridSummaryInterfaceGroup.setInterfaces(interfaces);

                        gridSummaryDeviceInfo.addToolInterfaces(gridSummaryInterfaceGroup);
                    });
                });
                deviceGridsSummary.add(gridSummary);
            });
        }
        return new ResponseEntity<>(deviceGridsSummary, HttpStatus.OK);
    }


    /**
     * This method is used to fetch devices for Grid based on type
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/basicinfo")
    public ResponseEntity<Object> getGridsBasicInfo() {
        Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
        JSONArray gridArray = new JSONArray();
        if (!deviceGrids.isEmpty()) {
            deviceGrids.forEach(deviceGrid -> {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("id", deviceGrid.getId());
                    jsonObject.put("name", deviceGrid.getName());
                    jsonObject.put("type", "SLX");
                    jsonObject.put("mode", "PLAIN");
                    JSONArray taps = new JSONArray();
                    JSONArray tools = new JSONArray();
                    deviceGrid.getSourceNodes().forEach(networkNode -> {
                        networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                            JSONObject nodeJsonObject = new JSONObject();
                            try {
                                nodeJsonObject.put("id", networkNodeInterface.getId());
                                nodeJsonObject.put("name", networkNodeInterface.getName());
                            } catch (JSONException e) {
                                log.error("Exception while creating the tap basic info, {}", e.getMessage());
                            }
                            taps.put(nodeJsonObject);
                        });
                    });

                    deviceGrid.getDestinationNodes().forEach(networkNode -> {
                        networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                            JSONObject nodeJsonObject = new JSONObject();
                            try {
                                nodeJsonObject.put("id", networkNodeInterface.getId());
                                nodeJsonObject.put("name", networkNodeInterface.getName());
                            } catch (JSONException e) {
                                log.error("Exception while creating the tool basic info, {}", e.getMessage());
                            }
                            tools.put(nodeJsonObject);
                        });
                    });
                    jsonObject.put("taps", taps);
                    jsonObject.put("tools", tools);
                    gridArray.put(jsonObject);
                } catch (JSONException e) {
                    log.error("Exception while creating the grid basic info, {}", e.getMessage());
                }
            });
        }
        return new ResponseEntity<>(gridArray.toString(), HttpStatus.OK);
    }

    /**
     * Method returns the custom JSON for editing the grid by id
     *
     * @param gridId
     * @return
     * @throws JSONException
     */
    @RequestMapping(value = "/{gridId}/edit")
    public ResponseEntity<Object> getEditGrid(@PathVariable("gridId") Long gridId) throws JSONException {
        if (gridId != null) {
            DeviceGrid deviceGrid = gridRepository.findOne(gridId);
            if (deviceGrid != null) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", deviceGrid.getId());
                jsonObject.put("name", deviceGrid.getName());
                jsonObject.put("description", deviceGrid.getDescription());
                jsonObject.put("type", "SLX");
                jsonObject.put("mode", "PLAIN");

                JSONArray aggregatorConfArray = new JSONArray();
                deviceGrid.getSourceNodes().forEach(networkNode -> {
                    networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                        try {
                            JSONObject aggregatorJsonObject = new JSONObject();
                            JSONObject deviceJsonObject = new JSONObject();
                            deviceJsonObject.put("id", networkNode.getDevice().getId());
                            deviceJsonObject.put("name", networkNode.getDevice().getName());
                            aggregatorJsonObject.put("device", deviceJsonObject);
                            aggregatorJsonObject.put("networkNodeId", networkNode.getId());
                            aggregatorJsonObject.put("networkNodeInterfaceId", networkNodeInterface.getId());
                            aggregatorJsonObject.put("tapPort", networkNodeInterface.getName());
                            JSONArray interfaceArray = new JSONArray();
                            for (Port port : networkNodeInterface.getPorts()) {
                                JSONObject interfaceJsonObject = new JSONObject();
                                interfaceJsonObject.put("id", port.getId());
                                interfaceJsonObject.put("name", port.getName());
                                interfaceJsonObject.put("type", port.getType());
                                interfaceJsonObject.put("objectType", PORT);
                                interfaceArray.put(interfaceJsonObject);
                            }
                            for (PortGroup portGroup : networkNodeInterface.getPortGroups()) {
                                JSONObject interfaceJsonObject = new JSONObject();
                                interfaceJsonObject.put("id", portGroup.getId());
                                interfaceJsonObject.put("name", portGroup.getName());
                                interfaceJsonObject.put("objectType", PORT_GROUP);
                                interfaceArray.put(interfaceJsonObject);
                            }
                            aggregatorJsonObject.put("interfaces", interfaceArray);
                            aggregatorConfArray.put(aggregatorJsonObject);
                        } catch (JSONException e) {
                            log.error("Failed to generate the grid JSON. {}", e.getMessage());
                        }
                    });
                });
                jsonObject.put("aggregatorConf", aggregatorConfArray);

                JSONArray distributorConfArray = new JSONArray();
                deviceGrid.getDestinationNodes().forEach(networkNode -> {
                    networkNode.getClusterNodeInterfaces().forEach(networkNodeInterface -> {
                        Set<ManagedObject> interfaces = Sets.newHashSet();
                        interfaces.addAll(networkNodeInterface.getPorts());
                        interfaces.addAll(networkNodeInterface.getPortGroups());

                        try {
                            JSONObject distributorJsonObject = new JSONObject();
                            JSONObject deviceJsonObject = new JSONObject();
                            deviceJsonObject.put("id", networkNode.getDevice().getId());
                            deviceJsonObject.put("name", networkNode.getDevice().getName());
                            distributorJsonObject.put("device", deviceJsonObject);
                            distributorJsonObject.put("networkNodeId", networkNode.getId());
                            distributorJsonObject.put("networkNodeInterfaceId", networkNodeInterface.getId());
                            distributorJsonObject.put("toolPort", networkNodeInterface.getName());
                            JSONArray interfaceArray = new JSONArray();
                            for (Port port : networkNodeInterface.getPorts()) {
                                JSONObject interfaceJsonObject = new JSONObject();
                                interfaceJsonObject.put("id", port.getId());
                                interfaceJsonObject.put("name", port.getName());
                                interfaceJsonObject.put("type", port.getType());
                                interfaceJsonObject.put("objectType", PORT);
                                interfaceArray.put(interfaceJsonObject);
                            }
                            for (PortGroup portGroup : networkNodeInterface.getPortGroups()) {
                                JSONObject interfaceJsonObject = new JSONObject();
                                interfaceJsonObject.put("id", portGroup.getId());
                                interfaceJsonObject.put("name", portGroup.getName());
                                interfaceJsonObject.put("objectType", PORT_GROUP);
                                interfaceArray.put(interfaceJsonObject);
                            }
                            distributorJsonObject.put("interfaces", interfaceArray);
                            distributorConfArray.put(distributorJsonObject);
                        } catch (JSONException e) {
                            log.error("Failed to generate the grid JSON.. {}", e.getMessage());
                        }
                    });
                });
                jsonObject.put("distributorConf", distributorConfArray);
                return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Method fetches the devices by type and reconciled and perform RBAC.
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/gridanddevice-basic")
    public ResponseEntity<Object> getGridsAndDeviceBasic() {
        JSONArray devicesResponseArray = new JSONArray();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            List<Device> devices = deviceRepository.findAllByIdsAndTypeAndReconciledAndProfileSet(stablenetDeviceIds, Lists.newArrayList(Device.Type.SLX));
            devices.stream().forEach(device -> {
                if (!Strings.isNullOrEmpty(device.getOs())) {
                    Pattern pattern = Pattern.compile("^([A-Za-z]*)(\\d+)(\\w*)(\\.\\d+)");
                    Matcher matcher = pattern.matcher(device.getOs());
                    if (matcher.find() && matcher.groupCount() == 4) {
                        String version = matcher.group(2);
                        if (!Strings.isNullOrEmpty(version) && Integer.parseInt(version) >= slxGridSupportedVersion && "s".equals(matcher.group(3))) {
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put("id", device.getId());
                                jsonObject.put("name", device.getName());
                                jsonObject.put("type", GridDeviceInfoRequest.TargetType.TYPE.DEVICE);
                                devicesResponseArray.put(jsonObject);
                            } catch (JSONException e) {
                                log.error("Failed to generate device JSON. {}", e.getMessage());
                            }
                        }
                    }
                }
            });
            deviceGrids.forEach(deviceGrid -> {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("id", deviceGrid.getId());
                    jsonObject.put("name", deviceGrid.getName());
                    jsonObject.put("type", GridDeviceInfoRequest.TargetType.TYPE.GRID);
                    devicesResponseArray.put(jsonObject);
                } catch (JSONException e) {
                    log.error("Failed to generate grid JSON. {}", e.getMessage());
                }
            });
        }
        return new ResponseEntity<>(devicesResponseArray.toString(), HttpStatus.OK);
    }
}
