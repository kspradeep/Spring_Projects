package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.manager.statistics.SwitchOverviewManager;
import com.brocade.bvm.api.model.statistics.GridOverview;
import com.brocade.bvm.dao.grid.GridPolicySetRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsGridRepository;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.cache.PolicyCache;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.statistics.GridStatisticsOverview;
import com.brocade.bvm.model.db.statistics.OneGridStatisticsOverview;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicLong;

@RequestMapping(produces = "application/json", value = "/statistics")
@RestController
@Slf4j
public class StatisticsGridUIController {

  @Inject private GridPolicySetRepository gridPolicySetRepository;
  @Inject private GridRepository gridRepository;
  @Inject StatisticsGridRepository statisticsGridRepository;
  @Inject private SwitchOverviewManager switchOverviewManager;
  @Inject private StatisticsPolicyRepository statisticsPolicyRepository;

  /**
   * This endpoint returns grid overview for dashboard
   *
   * @return GridOverview
   */
  @RequestMapping(method = RequestMethod.GET, value = "/{gridId}/grid-overview")
  public ResponseEntity<com.brocade.bvm.api.model.statistics.GridOverview> gridOverview(
      @PathVariable("gridId") Long gridId) {
    log.debug("Start: grid overview for grid id {}", gridId);
    if (StringUtils.isEmpty(gridId)) {
      log.error("Grid id is null in grid overview");
      return new ResponseEntity<>(new GridOverview(), HttpStatus.BAD_REQUEST);
    } else {
      DeviceGrid deviceGrid = gridRepository.findOne(gridId);
      com.brocade.bvm.api.model.statistics.GridOverview gridOverview =
          new com.brocade.bvm.api.model.statistics.GridOverview();
      try{
      if (deviceGrid != null) {
        gridOverview.setNoDevices(
            deviceGrid.getDestinationNodes().size() + deviceGrid.getSourceNodes().size());
        gridOverview.setNoAggregator(deviceGrid.getSourceNodes().size());
        gridOverview.setNoDistributor(deviceGrid.getDestinationNodes().size());

        // Calculate tap port bandwidth and name
        AtomicLong tapBandwidth = new AtomicLong();
        deviceGrid
            .getSourceNodes()
            .forEach(
                networkNode -> {
                  Device device = networkNode.getDevice();
                  List<String> allTaps = new ArrayList<>();
                  gridOverview.getDevices().add(device.getName());
                  networkNode
                      .getClusterNodeInterfaces()
                      .forEach(
                          networkNodeInterface ->
                              networkNodeInterface
                                  .getPorts()
                                  .forEach(
                                      port -> {
                                        tapBandwidth.getAndAdd(port.getLineSpeed());
                                        allTaps.add(port.getName());
                                      }));
                  Map<String, List<String>> portMap = new HashMap<>();
                  portMap.put(device.getName(), allTaps);
                  gridOverview.getTapPorts().add(portMap);
                });

        // Set tap port bandwidth
        gridOverview.setTapBandwidth(tapBandwidth.longValue());

        // Calculate tool port bandwidth and name
        AtomicLong toolBandwidth = new AtomicLong();
        deviceGrid
            .getDestinationNodes()
            .forEach(
                networkNode -> {
                  Device device = networkNode.getDevice();
                  List<String> allTool = new ArrayList<>();
                  gridOverview.getDevices().add(device.getName());
                  networkNode
                      .getClusterNodeInterfaces()
                      .forEach(
                          networkNodeInterface ->
                              networkNodeInterface
                                  .getPorts()
                                  .forEach(
                                      port -> {
                                        toolBandwidth.getAndAdd(port.getLineSpeed());
                                        allTool.add(port.getName());
                                      }));
                  Map<String, List<String>> portMap = new HashMap<>();
                  portMap.put(device.getName(), allTool);
                  gridOverview.getToolPorts().add(portMap);
                });

        // Set tool port bandwidth
        gridOverview.setToolBandwidth(toolBandwidth.longValue());
        gridOverview.setConfiguredPolices(
            gridOverview.getConfiguredPolices()
                + gridPolicySetRepository
                    .findNameByGridIdAndWorkflowStatus(
                        deviceGrid.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE)
                    .size());

      } else {
        log.error("No device grid exist for grid id {}", gridId);
      }
      }catch (Exception e) {
          log.error(e.getMessage());
      }
      log.debug("End: grid overview for grid id {}", gridId);
      return new ResponseEntity<>(gridOverview, HttpStatus.OK);
    }
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{gridId}/grid-statistics")
  public ResponseEntity<OneGridStatisticsOverview> gridStatistics(
      @PathVariable("gridId") Long gridId) {
    log.debug("Start: grid statistics for grid id {}", gridId);
    if (gridId == null) {
      log.error("Grid id is null in grid-statistics");
      return new ResponseEntity<>(new OneGridStatisticsOverview(), HttpStatus.BAD_REQUEST);
    }

    DeviceGrid deviceGrid = gridRepository.findOne(gridId);
    OneGridStatisticsOverview oneGridStatisticsOverview = new OneGridStatisticsOverview();
    try{
    if (deviceGrid == null) {
      log.error("No device grid exist for grid id {}", gridId);
    } else {
//      oneGridStatisticsOverview.setPacketDifInTapAndTool(
//          statisticsGridRepository.setPacketDifferenceInPort(deviceGrid));
//      oneGridStatisticsOverview.setTopFivePolicies(
//          policyCache.getTopFivePoliciesByHitCount(gridId));
      oneGridStatisticsOverview.setPortOverThreshold(
          statisticsGridRepository.getPortOverThresholdCount(deviceGrid.getId()));
      oneGridStatisticsOverview.setAllPoliciesAndHitCounts(
          statisticsGridRepository.findAllPolicesAndHitCount(gridId));
    }
    }catch (Exception e) {
        log.error(e.getMessage());
    }

    log.debug("End: grid statistics for grid id {}", gridId);
    return new ResponseEntity<>(oneGridStatisticsOverview, HttpStatus.OK);
  }

  @RequestMapping("/grid-statistics-overview")
  public ResponseEntity<Object> statisticsOverview() {
    GridStatisticsOverview gridStatisticsOverview = new GridStatisticsOverview();
    try {
      log.debug("Start: grid statistics overview for all grids");

      CompletableFuture<List<String>> topFiveGrids = statisticsGridRepository.findTopFiveGrids();
      CompletableFuture<List<String>> bottomFiveGrids =
          statisticsGridRepository.findBottomFiveGrids();

      CompletableFuture.allOf(bottomFiveGrids, topFiveGrids).join();

      gridStatisticsOverview.setTopFiveTapPorts(switchOverviewManager.findTopFiveTapPorts());
      gridStatisticsOverview.setBottomFiveTapPorts(new HashSet<>());
      gridStatisticsOverview.setTopFiveToolPorts(switchOverviewManager.findTopFiveToolPorts());
      gridStatisticsOverview.setBottomFiveToolPorts(new HashSet<>());
      gridStatisticsOverview.setTopFiveGrids(topFiveGrids.get());
      gridStatisticsOverview.setBottomFiveGrids(new ArrayList<>());
      gridStatisticsOverview.setToFivePolicies(statisticsPolicyRepository.getTopFivePolices().get("grid"));
      log.debug("End: grid statistics overview for all grids");

    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return new ResponseEntity<>(gridStatisticsOverview, HttpStatus.OK);
  }

  @Scheduled(fixedDelay = 3000)
  private void checkPortOverThreshold() {
    try {
      Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
      if (!StringUtils.isEmpty(deviceGrids) && deviceGrids.size() > 0) {
        deviceGrids.forEach(
            deviceGrid -> statisticsGridRepository.calculatePortsOverthreshold(deviceGrid));
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
  }
}
