package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.HeaderStrippingModulePolicyRepository;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The PolicyManagerNonOpenFlow class implements methods related to policy for NonOpenFlow
 */
@Slf4j
@Named
public class PolicyManagerNonOpenFlow extends AbstractPolicyManager {

    public static final String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(/([0-9]|1[0-9]|2[0-9]|3[0-2]))*$";
    public static final String MAC_ADDRESS_PATTERN = "^(([a-fA-F0-9]{2}-){5}[a-fA-F0-9]{2}|([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}|([0-9A-Fa-f]{4}\\.){2}[0-9A-Fa-f]{4})?$";


    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    /**
     * This method validates if the policy data is valid to save in BVM
     *
     * @param policy
     * @return boolean
     * @throws ValidationException
     */
    @Override
    public boolean isValidPolicyToSave(Policy policy, boolean isStandalone) throws ValidationException {
        if (policy.getGridPolicySetId() != null && isStandalone) {
            log.error("Cannot save policy as it is associated with a grid policy.");
            throw new ValidationException("Cannot save policy as it is associated with a grid policy.");
        }
        validateForGrid(policy, isStandalone);
        validateIfIngressAndEgressPortsAndPortGroupAreValid(policy);
        isValidForLoopBack(policy);
        isValidPolicyForGTPProfileToApply(policy);
        isAnyPolicyWithVlanAndEgressPort(policy);
        isRuleContainsValidIp(policy);
        isPolicyCandidateToSave(policy);
        isTagAndDeviceIdUnique(policy);
        isAnyPolicyInProgessOrError(policy);
        isSequenceInUseByAnyPolicyOnDevice(policy);
        isValidHttpGtpFiltering(policy);
        isValidVlanTagOrStrip(policy);
        return true;
    }

    /**
     * This method validates if the policy data is valid in the SLX type
     *
     * @param policy
     * @return boolean
     * @throws ValidationException
     */
    protected boolean isValidHttpGtpFiltering(Policy policy) {
        if (policy.isGtpHttpFiltered() && !isSlx9240Slx9140(policy.getDevice())) {
            throw new ValidationException("GTP-HTTP Filtering is applicable only for SLX 9140 and 9240");
        }
        return true;
    }

    /**
     * This method validates if the VLAN Strippping and Tagging doesn't co-exists in 9240 or 9140 SLX device
     *
     * @param policy
     * @return
     */
    protected boolean isValidVlanTagOrStrip(Policy policy) {
        Boolean isNotSlx9240 = !isSlx9240Slx9140(policy.getDevice());
        policy.getFlows().forEach(flow -> {
            if ((flow.getVlanStripping() || (flow.getTaggedVlanId() != null && flow.getTaggedVlanId() > 0)) && isNotSlx9240) {
                log.error("VLAN Stripping and VLAN Tagging not supported in SLX 9850 in Classic mode.");
                throw new ValidationException("VLAN Stripping and VLAN Tagging is not supported.");
            } else if (flow.getVlanStripping() && (flow.getTaggedVlanId() != null && flow.getTaggedVlanId() > 0) && !isNotSlx9240) {
                log.error("VLAN Stripping and VLAN Tagging cannot co-exist.");
                throw new ValidationException("VLAN Stripping and VLAN Tagging cannot co-exist.");
            } else if (flow.getTaggedVlanId() != null && (flow.getTaggedVlanId() < 1 || flow.getTaggedVlanId() > 4090) && !isNotSlx9240) {
                log.error("Tagged VLAN Id should be in the range [1-4090]");
                throw new ValidationException("Tagged VLAN Id should be in the range [1-4090]");

            }
        });
        return true;
    }

    /**
     * This method validates if the policy data is valid to commit on the device
     *
     * @param policy
     * @return boolean
     */
    @Override
    public boolean isValidPolicyToCommit(Policy policy, boolean isStandalone) {
        if (policy.getGridPolicySetId() != null && isStandalone) {
            log.error("Cannot commit policy as it is associated with a grid policy.");
            throw new ValidationException("Cannot commit policy as it is associated with a grid policy.");
        }
        validateForGrid(policy, isStandalone);
        isAnyPolicyInProgessOrError(policy);
        return true;
    }

    @Override
    public boolean isFlowPriorityValid(Policy policy) throws ValidationException {
        return true;
    }

    @Override
    public boolean isVLanValid(Policy policy) throws ValidationException {

        Set<String> vlans = Sets.newHashSet();
        policy.getFlows().forEach(flow -> {
            vlans.addAll(flow.getVlans());
        });

        List<HeaderStrippingModulePolicy> headerStrippingModulePolicies = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(policy.getDevice().getId());
        if (!headerStrippingModulePolicies.isEmpty()) {
            HeaderStrippingModulePolicy headerStrippingModulePolicy = headerStrippingModulePolicies.get(0);
            if (vlans.contains(String.valueOf(headerStrippingModulePolicy.getIntermediateVlan()))) {
                throw new ValidationException("VLAN entered is already used as Intermediate VLAN in Header Preserve policy.");
            }

            if (vlans.contains(String.valueOf(headerStrippingModulePolicy.getReplaceVlan()))) {
                throw new ValidationException("VLAN entered is already used as Replace VLAN in Header Preserve policy.");
            }
        }
        return true;
    }

    /**
     * This method validates if the policy data is valid to update in bvm
     *
     * @param policy
     * @return boolean
     */
    @Override
    protected boolean isValidPolicyToUpdate(Policy policy, boolean isStandalone) throws ValidationException {
        if (policy.getGridPolicySetId() != null && isStandalone) {
            log.error("Cannot update policy as it is associated with a grid policy.");
            throw new ValidationException("Cannot update policy as it is associated with a grid policy.");
        }
        validateForGrid(policy, isStandalone);
        validateIfIngressAndEgressPortsAndPortGroupAreValid(policy);
        isAnyPolicyWithVlanAndEgressPort(policy);
        isValidForLoopBack(policy);
        isValidPolicyForGTPProfileToApply(policy);
        isRuleContainsValidIp(policy);
        isPolicyCandidateToSave(policy);
        isAnyPolicyInProgessOrError(policy);
        isTagAndDeviceIdUniqueForUpdate(policy);
        isSequenceInUseByAnyPolicyOnDevice(policy);
        return true;
    }

    /**
     * Validates the interfaces of a policy, is it used in device grid or not
     *
     * @param policy
     * @param isStandalone
     */
    private void validateForGrid(Policy policy, boolean isStandalone) {
        if (isStandalone) {
            Optional<Flow> flowOptional = policy.getFlows().stream().findAny();
            if (flowOptional.isPresent()) {
                Flow flow = flowOptional.get();

                List<Long> managedObjectIds = Lists.newArrayList();
                managedObjectIds.addAll(flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
                managedObjectIds.addAll(flow.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
                validateInterfacesWithGrid(managedObjectIds);
            }
        }
    }

    /**
     * This method validates if any policy flow(s) exist with same VLAN, Egress port(s)/portGroup(s) and tagged/untagged combination
     *
     * @param policyToSave
     * @return boolean
     */
    private boolean isAnyPolicyWithVlanAndEgressPort(Policy policyToSave) {
        final Set<Long> egressPorts = Sets.newHashSet();
        Long deviceId = policyToSave.getDevice().getId();
        Map<String, String> vlanMap = Maps.newHashMap();
        Map<String, Set<String>> egressUntaggedMap = new HashMap<>();

        for (Flow flow : policyToSave.getFlows()) {
            egressPorts.addAll(flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
            egressPorts.addAll(flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getId()).collect(Collectors.toSet()));
            if (!flow.getTvfDomain()) {
                flow.getVlans().forEach(vlanId -> {
                    Set<String> egressUntaggedSet = new HashSet<>();
                    egressPorts.forEach(egressPortId -> {
                        String key = vlanId + "|" + egressPortId;
                        String value = flow.getIsTagged() ? "tagged" : "untagged";
                        String egressUntagged = egressPortId + "|" + value;

                        //To check if one of the flow in current policy, exists with different VLAN, same egress and untagged combination
                        if (!flow.getIsTagged()) {
                            egressUntaggedMap.forEach((vlan, egressUntagSet) -> {
                                if (!vlanId.equals(vlan) && egressUntagSet.contains(egressUntagged)) {
                                    log.error("Cannot save policy as another flow exists with the same egress port and untagged combination, but different VLAN ID.");
                                    throw new ValidationException("Cannot save policy as another policy exists with the same egress port and untagged combination, but different VLAN ID.");
                                }
                            });
                            egressUntaggedSet.add(egressUntagged);
                        }

                        if (vlanMap.size() > 0 && vlanMap.containsKey(key) && vlanMap.get(key) != null && !value.equals(vlanMap.get(key))) {
                            if (!flow.getIsTagged()) {
                                log.error("Can't save policy as one of the flow in other policy has same vlan/egress and tagged combination");
                                throw new ValidationException("Cannot save policy as another policy exists with the same VLAN ID egress port and tagged combination.");
                            } else {
                                log.error("Can't save policy as one of the flow in other policy has same vlan/egress and untagged combination");
                                throw new ValidationException("Cannot save policy as another policy exists with the same VLAN ID, egress port and untagged combination.");
                            }
                        } else {
                            vlanMap.put(vlanId + "|" + egressPortId, value);
                        }
                    });
                    egressUntaggedMap.put(vlanId, egressUntaggedSet);
                });

                flow.getVlans().forEach(vlanId -> {
                    List<Long> flowIds = Lists.newArrayList();
                    if (!egressPorts.isEmpty()) {
                        if (policyToSave.getId() != null) {
                            flowIds = flowRepository.findByVlanAndEgressPortsAndTaggedNotInPolicy(deviceId, vlanId, egressPorts, flow.getIsTagged(), policyToSave.getId());
                        } else {
                            flowIds = flowRepository.findByVlanAndEgressPortsAndTagged(deviceId, vlanId, egressPorts, flow.getIsTagged());
                        }
                    }
                    if (!flowIds.isEmpty()) {
                        if (!flow.getIsTagged()) {
                            log.error("Can't save policy as one of the flow in other policy has same vlan/egress and tagged combination");
                            throw new ValidationException("Cannot save policy as another policy exists with the same VLAN ID egress port and tagged combination.");
                        } else {
                            log.error("Can't save policy as one of the flow in other policy has same vlan/egress and untagged combination");
                            throw new ValidationException("Cannot save policy as another policy exists with the same VLAN ID, egress port and untagged combination.");
                        }
                    }

                    //To check if one of the flow in other policy, exists with different VLAN, same egress and untagged combination
                    if (!flow.getIsTagged() && !egressPorts.isEmpty()) {
                        Set<Long> flowIdSet = Sets.newHashSet();
                        if(flow.getId() != null) {
                            flowIdSet.addAll(flowRepository.findByVlanNotInAndEgressPortsAndTaggedAndFlowIdNotIn(deviceId, vlanId, egressPorts, flow.getIsTagged(), flow.getId()));
                        } else {
                            flowIdSet.addAll(flowRepository.findByVlanNotInAndEgressPortsAndTagged(deviceId, vlanId, egressPorts, flow.getIsTagged()));
                        }
                        if (!flowIdSet.isEmpty()) {
                            log.error("Cannot save policy as another policy exists with the same egress port and untagged combination, but different VLAN ID.");
                            throw new ValidationException("Cannot save policy as another policy exists with the same egress port and untagged combination, but different VLAN ID.");
                        }
                    }
                });
                egressPorts.clear();
            }

            /* Validate if TVF domain is selected and isTagged is false, since port(s) are binded to tvf domain without mentioning tagged or untagged
            Validate if TVF domain is selected and destinationMac is empty. Since Destination MAC change feature is not supported */
            if (flow.getTvfDomain() && !(policyToSave.getDevice().getType() == Device.Type.SLX && policyToSave.getDevice().getMode() == Device.Mode.PLAIN)) {
                if (!policyToSave.isPreserveHeader() && flow.getIsTagged()) {
                    log.error("Cannot save policy as TVF domain is selected, destination ports cannot be tagged.");
                    throw new ValidationException("Cannot save policy as TVF domain is selected and destination ports cannot be tagged.");
                }
                if (flow.getDestinationMacTag() != null && !flow.getDestinationMacTag().isEmpty()) {
                    log.error("Cannot save policy as TVF domain is selected, destination MAC change feature is not supported.");
                    throw new ValidationException("Cannot save policy as TVF domain is selected and destination MAC cannot be changed.");
                }
            }
        }
        return false;
    }

    /**
     * This method validates if the selected GTPProfile is valid to be applied on the device
     *
     * @param policyToSave
     * @throws ValidationException if loopBack is not enabled or different GTP profile is used in policy and portGroup
     */
    private void isValidPolicyForGTPProfileToApply(Policy policyToSave) {
        if (policyToSave.getGtpProfile() != null) {
            if (!policyToSave.isLoopbackEnabled()) {
                throw new ValidationException("Loopback is required for GTP profile and must be selected.");
            }
            // To validate that request should have unique GTP Profile selected.
            Set<Long> gtpProfileIds = new HashSet<>();
            // Collect GTP Profile Ids
            gtpProfileIds.addAll(policyToSave.getFlows().stream().findFirst().get().getIngressPortGroups().stream().filter(portGroup -> portGroup.getGtpProfile() != null)
                    .map(portGroup -> portGroup.getGtpProfile().getProfileId()).collect(Collectors.toSet()));
            // Add GTP Profile Id which is selected in policy
            gtpProfileIds.add(policyToSave.getGtpProfile().getProfileId());
            if (gtpProfileIds.size() > 1) {
                throw new ValidationException("GTP profile mismatch! Selected Service Port Group(s) should have the same GTP profile as the policy.");
            }
        }
    }

    /**
     * This method validates if the ingress port(s)/portGroup(s) selected are valid to apply loopBack on the device
     *
     * @param policyToSave
     */
    private void isValidForLoopBack(Policy policyToSave) {
        if (policyToSave.isLoopbackEnabled()) {
            isServicePort(policyToSave);
        }
    }

    /**
     * This method validates if the ingress port(s)/portGroup(s) selected are of type service port(s)/portGroup(s)
     *
     * @param policyToSave
     * @throws ValidationException if the selected ingress port(s)/portGroup(s) not of type service port(s)/portGroup(s)
     */
    private void isServicePort(Policy policyToSave) {
        Set<Port> serviceIngressPorts = Sets.newHashSet();
        Set<PortGroup> serviceIngressPortGroups = Sets.newHashSet();
        policyToSave.getFlows().forEach(flow -> {
            serviceIngressPorts.addAll(flow.getIngressPorts().stream().filter(port -> (port.getType() == Port.Type.SERVICE_PORT)).collect(Collectors.toSet()));
            serviceIngressPortGroups.addAll(flow.getIngressPortGroups().stream().filter(portGroup -> (portGroup.getPrimaryPort().getType() == Port.Type.SERVICE_PORT)).collect(Collectors.toSet()));
        });
        policyToSave.getFlows().forEach(flow -> {
            if ((serviceIngressPorts.size() != flow.getIngressPorts().size()) || (serviceIngressPortGroups.size() != flow.getIngressPortGroups().size())) {
                throw new ValidationException("Creating a policy with GTP profile supports only Service Ports as Ingress Ports.");
            }
        });
    }

    /**
     * This method collects all the rule objects from all the RuleSet objects
     *
     * @param ruleSetList
     * @return List<Rule>
     */
    private List<Rule> getFlatRules(Set<RuleSet> ruleSetList) {
        // Creating duplicate list of Rule from Ruleset and updating the
        // ethernet type for any and null cases.
        List<Rule> rules = new ArrayList<>();
        for (RuleSet ruleSet : ruleSetList) {
            Set<Rule> ruleList = ruleSet.getRules();
            for (Rule rule : ruleList) {
                Rule ruleNew = new Rule();
                ruleNew.setSourceIp(rule.getSourceIp());
                ruleNew.setDestinationIp(rule.getDestinationIp());
                ruleNew.setSequence(rule.getSequence());
                ruleNew.setVlanId(rule.getVlanId());
                if (ruleSet.getIpVersion() != null) {
                    ruleNew.setEthType(ruleSet.getIpVersion().toString());
                }
                rules.add(ruleNew);
            }
        }
        return rules;
    }

    /**
     * This method validates if the given ip is a valid IPV4
     *
     * @param ip
     * @return boolean
     */
    private boolean validateIpv4(String ip) {
        if (ip != null) {
            if ("any".equalsIgnoreCase(ip)) {
                return true;
            } else {
                Pattern pattern = Pattern.compile(IPV4_PATTERN);
                return pattern.matcher(ip).matches();
            }
        }
        return true;
    }

    /**
     * This method validates if the given macAddress is a valid
     *
     * @param macAddress
     * @return boolean
     */
    private boolean validateMacAddress(String macAddress) {
        if (macAddress != null) {
            Pattern pattern = Pattern.compile(MAC_ADDRESS_PATTERN);
            return pattern.matcher(macAddress).matches();
        }
        return true;
    }

    /**
     * This method validates if rules in the policy contains valid IPV4 or IPV6
     *
     * @param policy
     * @return boolean
     */
    private boolean isRuleContainsValidIp(Policy policy) {
        for (Flow eachFlow : policy.getFlows()) {
            if (!validateMacAddress(eachFlow.getDestinationMacTag())) {
                throw new ValidationException("Invalid Destination Mac address!");
            }
            for (Rule rule : getFlatRules(eachFlow.getRuleSets())) {
                String etherType = rule.getEthType();
                String srcIp = rule.getSourceIp();
                String destIP = rule.getDestinationIp();

                if (etherType != null && !(etherType.equalsIgnoreCase("any"))) {
                    if (etherType.equalsIgnoreCase(RuleSet.IpVersion.V4.toString())) {
                        if (!validateIpv4(srcIp) || !validateIpv4(destIP)) {
                            throw new ValidationException("Policy rule contains invalid IPv4 address.");
                        }
                    } else if (etherType.equalsIgnoreCase(RuleSet.IpVersion.V6.toString())) {
                        if (!validateIpv6(srcIp) || !validateIpv6(destIP)) {
                            throw new ValidationException("Policy rule contains invalid IPv6 address.");
                        }
                    }
                }
            }
        }
        return true;
    }
}