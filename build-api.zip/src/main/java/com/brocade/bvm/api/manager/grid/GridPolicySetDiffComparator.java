package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.dao.grid.ClusterNodeInterfaceRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.GridClusterRequest;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Named
public class GridPolicySetDiffComparator {

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    public GridPolicySetDiff compareGridPolicies(GridPolicySet gridPolicySetUpdated, GridPolicySet gridPolicySetExisting) {
        GridPolicySetDiff gridPolicySetDiff = new GridPolicySetDiff();

        Set<ClusterNodeInterface> clusterNodeSourceInterfacesExisting = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeDestinationInterfacesExisting = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeSourceInterfacesUpdated = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeDestinationInterfacesUpdated = Sets.newHashSet();

        gridPolicySetUpdated.getGridPolicies().forEach(gridPolicy -> {
            clusterNodeSourceInterfacesUpdated.addAll(gridPolicy.getIngressClusterNodeInterfaces());
            clusterNodeDestinationInterfacesUpdated.addAll(gridPolicy.getEgressClusterNodeInterfaces());
        });
        gridPolicySetExisting.getGridPolicies().forEach(gridPolicy -> {
            clusterNodeSourceInterfacesExisting.addAll(gridPolicy.getIngressClusterNodeInterfaces());
            clusterNodeDestinationInterfacesExisting.addAll(gridPolicy.getEgressClusterNodeInterfaces());
        });

        Set<ClusterNodeInterface> clusterNodeSourcesUpdated = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeSourcesUnchanged = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeDestinationsUpdated = Sets.newHashSet();
        Set<ClusterNodeInterface> clusterNodeDestinationsUnchanged = Sets.newHashSet();

        Set<ClusterNodeInterface> clusterNodeSourcesAdded = findDifference(clusterNodeSourceInterfacesUpdated, clusterNodeSourceInterfacesExisting);//bandwidth increases
        Set<ClusterNodeInterface> clusterNodeSourcesDeleted = findDifference(clusterNodeSourceInterfacesExisting, clusterNodeSourceInterfacesUpdated);//bandwidth reduces
        findUpdates(clusterNodeSourceInterfacesUpdated, clusterNodeSourceInterfacesExisting, clusterNodeSourcesUpdated, clusterNodeSourcesUnchanged);
        Set<ClusterNodeInterface> clusterNodeDestinationsAdded = findDifference(clusterNodeDestinationInterfacesUpdated, clusterNodeDestinationInterfacesExisting);//path added
        Set<ClusterNodeInterface> clusterNodeDestinationsDeleted = findDifference(clusterNodeDestinationInterfacesExisting, clusterNodeDestinationInterfacesUpdated);//path deleted
        findUpdates(clusterNodeDestinationInterfacesUpdated, clusterNodeDestinationInterfacesExisting, clusterNodeDestinationsUpdated, clusterNodeDestinationsUnchanged);

        gridPolicySetDiff.setClusterNodeSourcesAdded(clusterNodeSourcesAdded);
        gridPolicySetDiff.setClusterNodeSourcesDeleted(clusterNodeSourcesDeleted);
        gridPolicySetDiff.setClusterNodeSourcesUpdated(clusterNodeSourcesUpdated);
        gridPolicySetDiff.setClusterNodeSourcesUnchanged(clusterNodeSourcesUnchanged);

        gridPolicySetDiff.setClusterNodeDestinationsAdded(clusterNodeDestinationsAdded);
        gridPolicySetDiff.setClusterNodeDestinationsDeleted(clusterNodeDestinationsDeleted);
        gridPolicySetDiff.setClusterNodeDestinationsUpdated(clusterNodeDestinationsUpdated);
        gridPolicySetDiff.setClusterNodeDestinationsUnchanged(clusterNodeDestinationsUnchanged);
        return gridPolicySetDiff;
    }


    private Set<ClusterNodeInterface> findDifference(Set<ClusterNodeInterface> sourceSet,
                                                     Set<ClusterNodeInterface> targetSet) {
        Set<ClusterNodeInterface> difference = new HashSet<>();
        for (ClusterNodeInterface source : sourceSet) {
            if (targetSet.stream().noneMatch(target -> target.getId() == source.getId())) {
                difference.add(source);
            }
        }
        return difference;
    }

    private void findUpdates(Set<ClusterNodeInterface> sourceSet,
                             Set<ClusterNodeInterface> targetSet, Set<ClusterNodeInterface> sourcesUpdated, Set<ClusterNodeInterface> sourcesUnchanged) {
        for (ClusterNodeInterface source : sourceSet) {
            Optional<ClusterNodeInterface> clusterRequestOptional = targetSet.stream().filter(target -> target.getId() == source.getId()).findAny();
            if (clusterRequestOptional.isPresent()) {
                ClusterNodeInterface destination = clusterRequestOptional.get();
                if (destination.getPortsAndPortGroups().size() != source.getPortsAndPortGroups().size() ||
                        findNewObjectId(destination.getPorts(), source.getPorts()).size() > 1 ||
                        findNewObjectId(source.getPorts(), destination.getPorts()).size() > 1 ||
                        findNewObjectId(destination.getPortGroups(), source.getPortGroups()).size() > 1 ||
                        findNewObjectId(source.getPortGroups(), destination.getPortGroups()).size() > 1) {
                    sourcesUpdated.add(source);
                } else {
                    sourcesUnchanged.add(source);
                }
            }
        }
    }

    private Set<Long> findNewObjectId(Set<? extends ManagedObject> existingSet,
                                      Set<? extends ManagedObject> updatedSet) {
        // look for new Ports/portgroups - as these are partial filled objects
        // from UI
        Set<Long> toAdd = new HashSet<>();
        for (ManagedObject eachUpdate : updatedSet) {
            if (!existingSet.stream().anyMatch(po -> po.getId().longValue() == eachUpdate.getId().longValue())) {
                toAdd.add(eachUpdate.getId());
            }
        }
        return toAdd;
    }
}