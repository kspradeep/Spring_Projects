package com.brocade.bvm.api.factory;

import com.brocade.bvm.api.manager.*;
import com.brocade.bvm.api.manager.nonopenflow.*;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;
import lombok.Getter;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Set;

@Getter
@Named
public class NonOpenFlowFactory implements ManagerFactory {

    @Inject
    private PortManagerNonOpenFlow portManager;

    @Inject
    private PolicyManagerNonOpenFlow policyManager;

    @Inject
    private PortGroupManagerNonOpenFlow portGroupManager;

    @Inject
    private LoadBalanceModulePolicyManagerNonOpenFlow loadBalanceModulePolicyManager;

    @Inject
    private SlxLoadBalanceModulePolicyManagerNonOpenFlow slxLoadBalanceModulePolicyManager;

    @Inject
    private PacketStampingModulePolicyManagerNonOpenFlow packetStampingModulePolicyManager;

    @Inject
    private PacketLabelingModulePolicyManagerNonOpenFlow packetLabelingModulePolicyManager;

    @Inject
    private PacketSlicingModulePolicyManagerNonOpenFlow packetSlicingModulePolicyManager;

    @Inject
    private HeaderStrippingModulePolicyManagerNonOpenFlow headerStrippingModulePolicyManager;

    @Inject
    private MPLSDevicePolicyManagerNonOpenFlow mplsDevicePolicyManagerNonOpenFlow;

    @Inject
    private GTPDevicePolicyManagerNonOpenFlow gtpDevicePolicyManagerNonOpenFlow;

    @Inject
    private TunnelDevicePolicyManagerNonOpenFlow tunnelDevicePolicyManagerNonOpenFlow;

    @Inject
    ReservedVlanDevicePolicyManagerNonOpenFlow reservedVlanDevicePolicyManagerNonOpenFlow;

    @Inject
    private SlxPtpManagerNonOpenflow slxPacketStampingPolicy;

    @Inject
    private GtpDeEncapsulationModulePolicyManager gtpDeEncapsulationModulePolicyManager;

	@Inject
    private IpPayloadLengthPolicyManager ipPayloadLengthPolicyManager;
    public ModulePolicyManager getModulePolicyManager(ModulePolicyRequest request) {
        if (request.getLoadBalanceModulePolicy() != null) {
            return loadBalanceModulePolicyManager;
        } else if (request.getSlxLoadBalanceModulePolicy() != null) {
            return slxLoadBalanceModulePolicyManager;
        } else if (request.getPacketStampingModulePolicy() != null) {
            return packetStampingModulePolicyManager;
        } else if (request.getPacketSlicingModulePolicy() != null) {
            return packetSlicingModulePolicyManager;
        } else if (request.getPacketLabelingModulePolicy() != null) {
            return packetLabelingModulePolicyManager;
        } else if (request.getHeaderStrippingModulePolicy() != null) {
            return headerStrippingModulePolicyManager;
        } else if (request.getGtpDeEncapsulationModulePolicy() != null) {
            return gtpDeEncapsulationModulePolicyManager;
        } else if (request.getIpPayloadLengthPolicy() != null) {
            return ipPayloadLengthPolicyManager;
        }
        return null;
    }

    public ModulePolicyManager getModulePolicyManager(ModulePolicy modulePolicy) {
        if (modulePolicy instanceof LoadBalanceModulePolicy) {
            return loadBalanceModulePolicyManager;
        } else if (modulePolicy instanceof SlxLoadBalanceModulePolicy) {
            return slxLoadBalanceModulePolicyManager;
        } else if (modulePolicy instanceof PacketStampingModulePolicy) {
            return packetStampingModulePolicyManager;
        } else if (modulePolicy instanceof PacketSlicingModulePolicy) {
            return packetSlicingModulePolicyManager;
        } else if (modulePolicy instanceof PacketLabelingModulePolicy) {
            return packetLabelingModulePolicyManager;
        } else if (modulePolicy instanceof HeaderStrippingModulePolicy) {
            return headerStrippingModulePolicyManager;
        } else if (modulePolicy instanceof GtpDeEncapsulationModulePolicy) {
            return gtpDeEncapsulationModulePolicyManager;
        } else if (modulePolicy instanceof IpPayloadLengthPolicy) {
            return ipPayloadLengthPolicyManager;
        }
        return null;
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(Set<? extends DevicePolicy> devicePolicy) {
        DevicePolicy policy = devicePolicy.stream().findFirst().get();
        return getDevicePolicyManager(policy);
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(DevicePolicy devicePolicy) {
        if (devicePolicy instanceof MPLSDevicePolicy) {
            return mplsDevicePolicyManagerNonOpenFlow;
        } else if (devicePolicy instanceof GTPDevicePolicy) {
            return gtpDevicePolicyManagerNonOpenFlow;
        } else if (devicePolicy instanceof TunnelDevicePolicy) {
            return tunnelDevicePolicyManagerNonOpenFlow;
        } else if (devicePolicy instanceof ReservedVlanDevicePolicy) {
            return reservedVlanDevicePolicyManagerNonOpenFlow;
        } else if (devicePolicy instanceof SlxPtpPolicy) {
            return slxPacketStampingPolicy;
        }
        return null;
    }

    @Override
    public SdPolicyManager getSdPolicyManager(Set<? extends SdPolicy> Policy) {
        throw new UnsupportedOperationException("Session Director Policy not supported for Non OpenFlow!");
    }

    @Override
    public SdPolicyManager getSdPolicyManager(SdPolicy policy) {
        throw new UnsupportedOperationException("Session Director Policy not supported for Non OpenFlow!");
    }

    @Override
    public SdPortGroupManager getSdPortGroupManager() {
        throw new UnsupportedOperationException("Session Director Port not supported for Non OpenFlow!");
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(Set<? extends TemplatePolicy> templatePolicies) {
        throw new UnsupportedOperationException("This feature is not supported for Non OpenFlow!");
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(TemplatePolicy templatePolicy) {
        throw new UnsupportedOperationException("This feature is not supported for Non OpenFlow!");
    }
}
