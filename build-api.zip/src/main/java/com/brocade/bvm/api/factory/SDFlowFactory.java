package com.brocade.bvm.api.factory;

import com.brocade.bvm.api.controller.ManagerFactoryBuilder;
import com.brocade.bvm.api.manager.*;
import com.brocade.bvm.api.manager.sessiondirector.SdActiveInterfaceManager;
import com.brocade.bvm.api.manager.sessiondirector.SdEgressPortGroupManager;
import com.brocade.bvm.api.manager.sessiondirector.SdEgressPortManager;
import com.brocade.bvm.api.manager.sessiondirector.SdStatsManager;
import com.brocade.bvm.api.model.*;
import com.brocade.bvm.api.utility.StatsTimer;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.brocade.bvm.model.exception.ServerException;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * This class used as a factory class for SD
 */

@Named
@Slf4j
public class SDFlowFactory implements ManagerFactory {

    private static final int FLOW_SEQUENCE_UNIT = 100;

    private static final String CLEANUP = "cleanup";
    private static final String EGRESS = "egress";
    private static final String INGRESS = "ingress";

    private static final String START = "start";
    private static final String STOP = "stop";
    private static final String CLEAR = "clear";

    private static final String IP = "ip";
    private static final String ANY = "any";
    private static final String EQ = "eq";
    private static final String UDP = "udp";
    private static final String TCP = "tcp";

    private final static String ARCH1_DEF_S11_S1U_VoLTE = "ARCH1_DEF_S11_S1U_VoLTE";
    private final static String ARCH1_DEF_S11_S1U_2_40G_CONFIG = "ARCH1_DEF_S11_S1U_2_40G_CONFIG";
    private final static String ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI = "ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI";

    private final static String CONTROL_PORT = "CONTROL-PORT";
    private final static String GTPU_PORT1 = "GTPU-PORT1";
    private final static String GTPU_PORT2 = "GTPU-PORT2";
    private final static String GTPU_PORT = "GTPU-PORT";
    private final static String RTP_PORT = "RTP-PORT";
    private final static String SIP_PORT = "SIP-PORT";

    @Inject
    @Qualifier(value = "SdFilterPolicyManager")
    private SdPolicyManager filterPolicyManager;

    @Inject
    @Qualifier(value = "SdDedupePolicyManager")
    private SdPolicyManager sdDedupePolicyManager;

    @Inject
    @Qualifier(value = "SdSamplingPolicyManager")
    private SdPolicyManager sdSamplingPolicyManager;

    @Inject
    @Qualifier(value = "SdActiveInterfaceManager")
    private SdActiveInterfaceManager sdActiveInterfaceManager;

    @Inject
    @Qualifier(value = "SdStatsManager")
    private SdStatsManager sdStatsManager;

    @Inject
    private SdEgressPortManager sdEgressPortManager;

    @Inject
    private SdEgressPortGroupManager sdEgressPortGroupManager;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    protected EntityManager entityManager;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private RuleRepository ruleRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    private ProfileInterfaceMappingRepository profileInterfaceMappingRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected ProfileRepository profileRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    private IngressPortRepository ingressPortRepository;

    @Inject
    private EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    private JobRepository jobRepository;

    @Value("${stablenet-response.timeout.minutes}")
    private int stablenetTimeoutMinutes;

    @Value("${job.poll.interval.seconds:3}")
    private int jobPollIntervalSeconds;

    @Value("${policy.job.poll.interval.seconds:10}")
    private int policyJobPollIntervalSeconds;

    @Inject
    private StatsTimer statsTimerTask;

    @Inject
    private GlobalConfigRepository globalConfigRepository;

    @Inject
    private SdPairedDeviceRepository pairedDeviceRepository;

    @Override
    public PortManager getPortManager() {
        return null;
    }

    @Override
    public PolicyManager getPolicyManager() {
        return null;
    }

    @Override
    public PortGroupManager getPortGroupManager() {
        return null;
    }

    @Override
    public ModulePolicyManager getModulePolicyManager(ModulePolicyRequest request) {
        return null;
    }

    @Override
    public ModulePolicyManager getModulePolicyManager(ModulePolicy modulePolicy) {
        return null;
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(Set<? extends DevicePolicy> devicePolicies) {
        throw new ValidationException("policy.action.invalid");
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(DevicePolicy devicePolicy) {
        throw new ValidationException("policy.action.invalid");
    }

    public SdPortPolicyManager getSdPortManager() {
        return sdEgressPortManager;
    }

    public SdPortGroupManager getSdPortGroupManager() {
        return sdEgressPortGroupManager;
    }

    @Override
    public SdPolicyManager getSdPolicyManager(Set<? extends SdPolicy> policies) {
        SdPolicy policy = policies.stream().findFirst().get();
        if (policy instanceof FilterPolicy) {
            return filterPolicyManager;
        } else if (policy instanceof DeDupePolicy) {
            return sdDedupePolicyManager;
        } else if (policy instanceof SamplingPolicy) {
            return sdSamplingPolicyManager;
        }
        return null;
    }

    @Override
    public SdPolicyManager getSdPolicyManager(SdPolicy policy) {
        if (policy instanceof FilterPolicy) {
            return filterPolicyManager;
        } else if (policy instanceof DeDupePolicy) {
            return sdDedupePolicyManager;
        } else if (policy instanceof SamplingPolicy) {
            return sdSamplingPolicyManager;
        }
        return null;
    }


    /**
     * This method is used for marking MLXe/SLX ports
     *
     * @param ports
     * @param targetDevice
     * @return
     */
    public Job markPorts(Set<Port> ports, Device targetDevice, String action) {
        if (targetDevice == null) {
            throw new ValidationException("device.id.invalid");
        }
        List<Long> ingressPortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() != null && sdPortParameter.getType() == Port.Type.INGRESS).map(Port::getId).collect(Collectors.toList());
        List<Long> egressPortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() != null && sdPortParameter.getType() == Port.Type.EGRESS).map(Port::getId).collect(Collectors.toList());
        List<Long> nonePortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() == Port.Type.NONE).map(Port::getId).collect(Collectors.toList());

        if (EGRESS.equals(action) && egressPortIds.isEmpty()) {
            log.error("At least one EGRESS port is required");
            throw new ValidationException("one.egress.port.mandatory");
        } else if (INGRESS.equals(action) && ingressPortIds.isEmpty()) {
            log.error("At least one INGRESS port is required");
            throw new ValidationException("one.ingress.port.mandatory");
        }
        ingressPortIds = filterMarkedPorts(ingressPortIds, Port.Type.INGRESS);
        egressPortIds = filterMarkedPorts(egressPortIds, Port.Type.EGRESS);
        nonePortIds = filterMarkedPorts(nonePortIds, Port.Type.NONE);

        if (EGRESS.equals(action) && !nonePortIds.isEmpty()) {
            List<Long> sdEgressPortIds = egressPortRepository.findEgressPortIdsByPortIds(nonePortIds);
            if (!sdEgressPortIds.isEmpty() && !egressPortGroupRepository.findPortGroupIdsByPortIds(sdEgressPortIds).isEmpty()) {
                log.error("Cannot perform port operation. Port is in use in Port Group");
                throw new ValidationException("port.used.portGroup");
            }
        }

        long portJobId;
        Job job = new Job();
        if (!ingressPortIds.isEmpty()) {
            portJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .changeType(targetDevice.getId(), ingressPortIds, Port.Type.INGRESS, false);
            job = getJobStatus(portJobId);
        }
        if (job != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS) && !egressPortIds.isEmpty()) {
            portJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .changeType(targetDevice.getId(), egressPortIds, Port.Type.EGRESS, false);
            job = getJobStatus(portJobId);
        }
        return job;
    }

    /**
     * This method is used for validating the unmarking of MLXe/SLX ports
     *
     * @param ports
     * @return
     */
    public void validateUnMarkPorts(Set<Port> ports, Policy policyTwo, Set<Port> egressPorts, String action) {
        List<Long> nonePortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() == Port.Type.NONE).map(Port::getId).collect(Collectors.toList());
        List<Long> egressPortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() != null && sdPortParameter.getType() == Port.Type.EGRESS).map(Port::getId).collect(Collectors.toList());
        nonePortIds = filterMarkedPorts(nonePortIds, Port.Type.NONE);
        if (!nonePortIds.isEmpty()) {
            List<EgressPort> sdEgressPortIds = egressPortRepository.findEgressPortByPortIds(nonePortIds);
            sdEgressPortIds.forEach(port -> {
                if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    throw new ValidationException("egress.port.in.error.state");
                }
            });
        }
        if (EGRESS.equals(action)) {
            if (!nonePortIds.isEmpty()) {
                List<Long> sdEgressPortIds = egressPortRepository.findEgressPortIdsByPortIds(nonePortIds);
                if (!sdEgressPortIds.isEmpty() && !egressPortGroupRepository.findPortGroupIdsByPortIds(sdEgressPortIds).isEmpty()) {
                    log.error("Cannot perform port operation. Port is in use in Port Group");
                    throw new ValidationException("port.used.portGroup");
                }
            }
            if (policyTwo != null && !egressPorts.isEmpty()) {
                SortedSet<Flow> flows = new TreeSet<>();
                policyTwo.getFlows().forEach(flow ->
                        flow.getEgressPorts().stream().forEach(flowPort -> {
                            Optional portOptional = egressPorts.stream().filter(port -> flowPort.getId() == port.getId()).findAny();
                            if (portOptional.isPresent()) {
                                flows.add(flow);
                            }
                        })
                );
                if (flows.size() == 0 && egressPortIds.isEmpty()) {
                    throw new ValidationException("one.egress.port.mandatory");
                }
            }
        }
    }

    /**
     * This method is used for unmarking MLXe/SLX ports
     *
     * @param ports
     * @param targetDevice
     * @return
     */
    public Job unMarkPorts(Set<Port> ports, Device targetDevice) {
        if (targetDevice == null) {
            throw new ValidationException("device.id.invalid");
        }
        List<Long> nonePortIds = ports.stream().filter(sdPortParameter -> sdPortParameter.getId() != null && sdPortParameter.getType() == Port.Type.NONE).map(Port::getId).collect(Collectors.toList());
        nonePortIds = filterMarkedPorts(nonePortIds, Port.Type.NONE);

        long portJobId;
        Job job = new Job();
        if (!nonePortIds.isEmpty()) {
            portJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .changeType(targetDevice.getId(), nonePortIds, Port.Type.NONE, false);
            job = getJobStatus(portJobId);
        }
        return job;
    }

    /**
     * This method is used to recover MLXe/SLX ports
     *
     * @param portIds
     * @param targetDevice
     * @return
     */
    public Job recoverPorts(List<Long> portIds, Device targetDevice) {
        if (targetDevice == null) {
            throw new ValidationException("device.id.invalid");
        }
        long jobId = managerBuilder.getOperationsFactory(targetDevice)
                .getPortManager()
                .recoverPort(targetDevice.getId(), portIds);
        Job job = getJobStatus(jobId);
        return job;
    }

    /**
     * Method removes the already marked ports and return new ports for marking
     *
     * @param portIds
     * @param type
     * @return
     */
    private List<Long> filterMarkedPorts(List<Long> portIds, Port.Type type) {
        List<Long> applicablePortIds = Lists.newArrayList();
        if (!portIds.isEmpty()) {
            List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                    .filter(port -> port.getType() != type)
                    .collect(Collectors.toList());

            applicablePortIds = applicablePorts.stream().map(Port::getId).collect(Collectors.toList());
        }
        return applicablePortIds;
    }


    /**
     * This method is used to validate the Target policies and SD egress ports
     *
     * @param sdPortPolicyParameter
     * @param sdEgressPorts
     * @return
     */
    private void validateSdPortPolicyParameter(SdPortPolicyParameter sdPortPolicyParameter, List<EgressPort> sdEgressPorts) {
        Policy policyOne = sdPortPolicyParameter.getPolicyOne();
        Policy policyTwo = sdPortPolicyParameter.getPolicyTwo();
        if ((policyOne != null && policyOne.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR)
                || (policyTwo != null && policyTwo.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR)) {
            throw new ValidationException("policy.in.error.state");
        }
        if ((policyOne != null && policyOne.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)
                || (policyTwo != null && policyTwo.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)) {
            throw new ValidationException("policy.commit.inprogress");
        }
        validateEgressPorts(sdEgressPorts);
        List<Long> egressPortIds = sdEgressPorts.stream().filter(port -> port.getId() != null).map(EgressPort::getId).collect(Collectors.toList());
        if (!egressPortIds.isEmpty()) {
            if (compareEgressPorts(sdEgressPorts)
                    && !((policyOne == null || (policyOne != null && policyOne.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT))
                    || (policyTwo == null || (policyTwo != null && policyTwo.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT)))) {
                throw new ValidationException("sd.global.config.same");
            }
        }
    }

    /**
     * This method is used to validate the SD egress ports
     *
     * @param sdEgressPorts
     * @return
     */
    private void validateEgressPorts(List<EgressPort> sdEgressPorts) {
        Set<Long> vlanSet = Sets.newHashSet();
        sdEgressPorts.forEach(egressPort -> {
            if (egressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                log.error("Cannot commit a port id {} which is in progress.", egressPort.getId());
                throw new ValidationException("port.commit.inprogress");
            } else if (egressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                log.error("Cannot commit a port id {} which is in error state.", egressPort.getId());
                throw new ValidationException("egress.port.in.error.state");
            } else if (egressPort.getVlanMappings().isEmpty()) {
                throw new ValidationException("sdvlanport.save.emptyvlan");
            } else if (egressPort.getImsiLimit() == null) {
                throw new ValidationException("sdvlanport.save.emptyimsilimit");
            } else if (egressPort.getLoadBalance() == null) {
                throw new ValidationException("sdloadbalance.save.emptylbalgorithm");
            } else {
                try {
                    if (egressPort.getImsiLimit().trim().isEmpty() || egressPort.getImsiLimit().length() > 8
                            || Integer.parseInt(egressPort.getImsiLimit()) < EgressPort.IMSI_MIN || Integer.parseInt(egressPort.getImsiLimit()) > EgressPort.IMSI_MAX) {
                        throw new ValidationException("sd.egress.imsiNotInRange");
                    }
                } catch (NumberFormatException e) {
                    throw new ValidationException("sd.egress.imsiNotInRange");
                }
                Set<SdPortVlanMapping> vlanMappings = egressPort.getVlanMappings();
                vlanMappings.forEach(vlanMapping -> {
                    long vlan = vlanMapping.getVlanId();
                    if (vlan < EgressPort.VLAN_MIN || vlan > EgressPort.VLAN_MAX) {
                        throw new ValidationException("sdvlanport.save.vlannotinrange");
                    }
                    if (vlanSet.contains(vlanMapping.getVlanId())) {
                        throw new ValidationException("egress.port.vlan.not.unique");
                    }
                    vlanSet.add(vlan);
                });
            }
        });
    }

    /**
     * This method is used to compare new and old egress port sets
     *
     * @param nEgressPortList
     * @return
     */
    private boolean compareEgressPorts(List<EgressPort> nEgressPortList) {
        boolean isEqual = false;
        for (int ctr = 0; ctr < nEgressPortList.size(); ctr++) {
            EgressPort egressPort = nEgressPortList.get(ctr);
            if (egressPort.getId() == null || egressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT)
                return false;
            EgressPort egressPortDB = egressPortRepository.findOne(egressPort.getId());
            if (egressPortDB != null) {
                if (compare(egressPort, egressPortDB)) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        }
        return isEqual;
    }

    /**
     * This method is used to compare new and old egress ports
     *
     * @param oPort
     * @param nPort
     * @return
     */
    private boolean compare(EgressPort nPort, EgressPort oPort) {
        if (nPort.getSourcePort() != oPort.getSourcePort()) return false;
        if (nPort.getAction() != oPort.getAction()) return false;
        if (nPort.getImsiLimit() != null && !nPort.getImsiLimit().equals(oPort.getImsiLimit())) return false;
        if (nPort.getLoadBalance() != oPort.getLoadBalance()) return false;
        if (!compareIdSets(nPort.getTaggedVlanIds(), getVlanIdsByType(oPort.getVlanMappings(), true))) return false;
        if (!nPort.isDefault() && !compareIdSets(nPort.getUntaggedVlanIds(), getVlanIdsByType(oPort.getVlanMappings(), false)))
            return false;
        return true;
    }

    private Set<Long> getVlanIdsByType(Set<SdPortVlanMapping> vlanMappings, boolean isTagged) {
        Set<Long> firstIdSets = Sets.newHashSet();
        if (!vlanMappings.isEmpty()) {
            vlanMappings.forEach(sdPortVlanMapping -> {
                if (sdPortVlanMapping.isTagged() == isTagged) {
                    firstIdSets.add(sdPortVlanMapping.getVlanId());
                }
            });
        }
        return firstIdSets;
    }

    /**
     * This method is used to compare two sets of type Long
     *
     * @param firstIdSets
     * @param secondIdSets
     * @return
     */
    private boolean compareIdSets(Set<Long> firstIdSets, Set<Long> secondIdSets) {
        if (firstIdSets != null && secondIdSets != null) {
            if (!firstIdSets.isEmpty() && !secondIdSets.isEmpty() && firstIdSets.size() == secondIdSets.size()) {
                for (Long aLong : firstIdSets) {
                    if (!secondIdSets.contains(aLong)) {
                        return false;
                    }
                }
                for (Long aLong : secondIdSets) {
                    if (!firstIdSets.contains(aLong)) {
                        return false;
                    }
                }
                return true;
            } else if (firstIdSets.isEmpty() && secondIdSets.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method is used for commit MLXe/SLX policy and add SD egress ports
     *
     * @param sdPortPolicyParameter
     * @param sdDevice
     * @return
     */
    public Long commitPortsAndPolicies(SdPortPolicyParameter sdPortPolicyParameter, Device sdDevice) {
        Device targetDevice = deviceRepository.findOne(sdPortPolicyParameter.getTargetDevice().getId());
        if (targetDevice == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (sdPortPolicyParameter.getSdPortParameters() == null || sdPortPolicyParameter.getSdPortParameters().isEmpty()) {
            throw new ValidationException("sd.port.empty");
        }

        List<Long> ingressPortIds = sdPortPolicyParameter.getSdPortParameters().stream().filter(sdPortParameter -> sdPortParameter != null && sdPortParameter.getId() != null && sdPortParameter.getType() != null &&
                sdPortParameter.getWorkflowStatus() != Port.WorkflowStatus.ERROR && sdPortParameter.getType() == Port.Type.INGRESS).map(SdPortParameter::getId).collect(Collectors.toList());
        List<Long> egressPortIds = sdPortPolicyParameter.getSdPortParameters().stream().filter(sdPortParameter -> sdPortParameter != null && sdPortParameter.getId() != null && sdPortParameter.getType() != null &&
                sdPortParameter.getWorkflowStatus() != Port.WorkflowStatus.ERROR && sdPortParameter.getType() == Port.Type.EGRESS).map(SdPortParameter::getId).collect(Collectors.toList());
        Set<Port> ingressPorts = Sets.newHashSet(portRepository.findAll(ingressPortIds));
        Set<Port> egressPorts = Sets.newHashSet(portRepository.findAll(egressPortIds));

        if (ingressPorts.isEmpty() || egressPorts.isEmpty()) {
            throw new ValidationException("sd.port.empty");
        }

        //add port group also
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDevice.getId());
        Profile profile = null;
        if (profileMapping != null) {
            profile = profileRepository.findOne(profileMapping.getProfile().getId());
        }
        if (profileMapping != null && profile != null) {
            Set<ManagedObject> servicePortsAndPortGroups = new HashSet<>();
            List<IngressPort> sdIngressPorts = ingressPortRepository.findByDeviceIdAndProfileId(sdDevice.getId(), profileMapping.getProfile().getId());
            sdIngressPorts.forEach(ingressPort -> {
                if (ingressPort.getServicePort() == null) {
                    throw new ValidationException("sd.service.ports.empty");
                }
            });

            List<Long> servicePortIds = getPortsFromSdIngressPortIds(sdIngressPorts);
            Set<Port> servicePorts = Sets.newHashSet(portRepository.findAll(servicePortIds));
            if (servicePorts.isEmpty()) {
                throw new ValidationException("sd.port.empty");
            }
            List<Long> portInSubmittedState = egressPortRepository.findByDeviceAndInWorkflowStatus(sdDevice.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
            if (!portInSubmittedState.isEmpty()) {
                log.error("Cannot commit Port as another Port operation is in progress.");
                throw new ValidationException("port.commit.inprogress");
            }
            List<EgressPort> sdEgressPorts = getEgressPorts(sdDevice, sdPortPolicyParameter.getSdPortParameters());
            validateSdPortPolicyParameter(sdPortPolicyParameter, sdEgressPorts);

            if (sdPortPolicyParameter.getPolicyOne() == null && sdPortPolicyParameter.getPolicyTwo() == null) {
                if (profileMapping.getProfile().getName().equals(ARCH1_DEF_S11_S1U_2_40G_CONFIG)) {
                    PortGroup portGroup = createPortGroup(targetDevice, sdIngressPorts);
                    Set<Port> portsNotInPortGroup = Sets.newHashSet();
                    sdIngressPorts.forEach(ingressPort -> {
                        if (!ingressPort.getName().contains(GTPU_PORT)) {
                            portsNotInPortGroup.add(ingressPort.getServicePort());
                        }
                    });
                    if (!portGroup.getPorts().isEmpty()) {
                        Long jobId = managerBuilder.getOperationsFactory(targetDevice).getPortGroupManager().commitPortGroup(portGroup, targetDevice);
                        servicePortsAndPortGroups.addAll(portsNotInPortGroup);
                        servicePortsAndPortGroups.add(portGroup);
                        Job job = getJobStatus(jobId);
                        if (job != null && job.getStatus() == Job.Status.FAILED) {
                            throw new ServerException(job.getJobResult());
                        }
                    } else {
                        servicePortsAndPortGroups.addAll(servicePorts);
                    }
                } else {
                    servicePortsAndPortGroups.addAll(servicePorts);
                }
            } else {
                //get the service ports from policy
                servicePortsAndPortGroups.addAll(getServicePortsAndPortGroups(sdPortPolicyParameter.getPolicyOne(), sdPortPolicyParameter.getPolicyTwo()));
            }

            //ingress and service ports
            Set<Long> vlanIdsUsedInSdEgress = getVlanIdsFromEgressPorts(sdEgressPorts);
            Job job = commitTargetPolicyOne(sdPortPolicyParameter.getPolicyOne(), targetDevice, profile, sdIngressPorts,
                    ingressPorts, servicePortsAndPortGroups, vlanIdsUsedInSdEgress);
            if (job != null && job.getStatus() == Job.Status.SUCCESS) {
                //service port and egress ports
                List<EgressPort> sdEgressPortsForPolicy = sdEgressPorts.stream().filter(port -> !port.isDefault()).collect(Collectors.toList());
                job = commitTargetPolicyTwo(sdPortPolicyParameter.getPolicyTwo(), targetDevice, servicePortsAndPortGroups, sdEgressPortsForPolicy);
                if (job != null && job.getStatus() == Job.Status.SUCCESS) {
                    Long sdPortJobId = getSdPortManager().commitPort(sdDevice, sdEgressPorts);
                    if (sdPortJobId != -1) {
                        job = getJobStatus(sdPortJobId);
                        if (job != null && job.getStatus() == Job.Status.SUCCESS) {
                            return job.getId();
                        }
                    }
                }
            }
            if (job != null) {
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(job.getJobResult());
                }
                return job.getId();
            }
            throw new ServerException("Job timed out");
        }
        throw new ValidationException("sd.profile.not.configured");
    }

    /**
     * This method is used to update the Egress ports
     *
     * @param sdDevice
     * @param sdEgressPortsToUpdate
     * @return ResponseEntity<Object> This returns job id
     */
    public Long updateEgressPort(Device sdDevice, List<EgressPort> sdEgressPortsToUpdate) {
        validateEgressPorts(sdEgressPortsToUpdate);
        Long sdPortJobId = getSdPortManager().commitPort(sdDevice, sdEgressPortsToUpdate);
        if (sdPortJobId != -1) {
            Job job = getJobStatus(sdPortJobId);
            if (job != null) {
                if (job.getStatus() == Job.Status.SUCCESS) {
                    return job.getId();
                } else {
                    throw new ServerException(job.getJobResult());
                }
            }
        }
        return -1L;
    }

    private Set<Long> getVlanIdsFromEgressPorts(List<EgressPort> egressPorts) {
        Set<Long> vlanIdList = Sets.newHashSet();
        egressPorts.forEach(port ->
                vlanIdList.addAll(port.getVlanMappings().stream().map(SdPortVlanMapping::getVlanId).collect(Collectors.toList()))
        );
        return vlanIdList;
    }

    /**
     * Inserts the Vlan to the VlanMapping object from the UI request i.e. from taggedVlanIds and untaggedVlanIds set
     *
     * @param egressPort
     */
    private Set<SdPortVlanMapping> populateVlanIdsFromRequest(EgressPort egressPort) {
        Set<SdPortVlanMapping> sdPortVlanMappings = new HashSet<>();
        Set<SdPortVlanMapping> oldVlanMappings = egressPort.getVlanMappings();
        Set<Long> vlanIdSet = Sets.newHashSet();
        if (egressPort.getTaggedVlanIds() != null) {
            for (Long vlanId : egressPort.getTaggedVlanIds()) {
                if (vlanId != null) {
                    SdPortVlanMapping vlanMapping = oldVlanMappings.stream().filter(vlanMap -> vlanMap.getVlanId().longValue() == vlanId.longValue()).findFirst().orElse(null);
                    if (vlanMapping == null) {
                        vlanMapping = new SdPortVlanMapping();
                        vlanMapping.setVlanId(vlanId);
                    }
                    vlanIdSet.add(vlanId);
                    vlanMapping.setTagged(true);
                    sdPortVlanMappings.add(vlanMapping);
                }
            }
        }
        if (egressPort.getUntaggedVlanIds() != null && egressPort.getUntaggedVlanIds().size() > 1) {
            throw new ValidationException("only.one.vlan.port.untagged.allowed");
        }
        if (egressPort.getUntaggedVlanIds() != null && egressPort.getTaggedVlanIds() != null) {
            if ((egressPort.getUntaggedVlanIds().size() + egressPort.getTaggedVlanIds().size()) > 20) {
                throw new ValidationException("sd.max.vlan.count.allowed");
            }
        }
        if (egressPort.getUntaggedVlanIds() == null && egressPort.getTaggedVlanIds() != null) {
            if (egressPort.getTaggedVlanIds().size() > 20) {
                throw new ValidationException("sd.max.vlan.count.allowed");
            }
        }
        if (egressPort.getUntaggedVlanIds() != null) {
            for (Long vlanId : egressPort.getUntaggedVlanIds()) {
                SdPortVlanMapping vlanMapping = oldVlanMappings.stream().filter(vlanMap -> vlanMap.getVlanId().longValue() == vlanId.longValue()).findFirst().orElse(null);
                if (vlanMapping == null) {
                    vlanMapping = new SdPortVlanMapping();
                    vlanMapping.setVlanId(vlanId);
                }
                if (vlanIdSet.contains(vlanId)) {
                    throw new ValidationException("egress.port.vlan.not.unique");
                }
                vlanMapping.setTagged(false);
                sdPortVlanMappings.add(vlanMapping);
            }
        }
        return sdPortVlanMappings;
    }

    /**
     * Collects the physical port ids from SD ingress ports
     *
     * @param sdIngressPorts
     * @return
     */
    private List<Long> getPortsFromSdIngressPortIds(List<IngressPort> sdIngressPorts) {
        List<Long> servicePortIds = Lists.newArrayList();
        sdIngressPorts.forEach(ingressPort ->
                servicePortIds.add(ingressPort.getServicePort().getId())
        );
        return servicePortIds;
    }

    /**
     * Returns the service ports from the policy
     *
     * @param policyOne
     * @param policyTwo
     * @return
     */
    private Set<ManagedObject> getServicePortsAndPortGroups(Policy policyOne, Policy policyTwo) {
        Set<ManagedObject> servicePortsAndPortGroups = new HashSet<>();
        if (policyOne != null) {
            policyOne.getFlows().forEach(flow -> {
                servicePortsAndPortGroups.addAll(flow.getEgressPortGroups());
                servicePortsAndPortGroups.addAll(flow.getEgressPorts());
            });
        } else if (policyTwo != null) {
            policyTwo.getFlows().forEach(flow -> {
                servicePortsAndPortGroups.addAll(flow.getIngressPortGroups());
                servicePortsAndPortGroups.addAll(flow.getIngressPorts());
            });
        }
        return servicePortsAndPortGroups;
    }


    /**
     * Method creates the port group based on the interface type
     *
     * @param device
     * @param sdIngressPorts
     * @return
     */
    public PortGroup createPortGroup(Device device, List<IngressPort> sdIngressPorts) {
        PortGroup portGroup = new PortGroup();
        portGroup.setDevice(device);

        Set<Port> portsForPortGroup = Sets.newHashSet();
        sdIngressPorts.forEach(ingressPort -> {
            if (ingressPort.getName().contains(GTPU_PORT)) {
                portsForPortGroup.add(ingressPort.getServicePort());
            }
        });
        portGroup.setName("pg_" + sdIngressPorts.stream().findFirst().get().getId() + "_" + device.getName() + "_" + device.getId());
        portGroup.setPorts(portsForPortGroup);
        return portGroup;
    }

    /**
     * This method is used for commit first MLXe/SLX policy
     *
     * @param policy
     * @param targetDevice
     * @param sdIngressPorts
     * @param ingressPorts
     * @param servicePortsAndPortGroups
     * @return
     */
    public Job commitTargetPolicyOne(Policy policy, Device targetDevice, Profile profile, List<IngressPort> sdIngressPorts, Set<Port> ingressPorts,
                                     Set<ManagedObject> servicePortsAndPortGroups, Set<Long> vlanIdsUsedInSdEgress) {
        Job job = new Job();
        if (policy != null) {
            policy = policyRepository.findOne(policy.getId());
        }
        if (policy == null && profile != null && sdIngressPorts != null && ingressPorts != null && servicePortsAndPortGroups != null) {
            policy = createTargetPolicyOne(targetDevice, profile, sdIngressPorts, ingressPorts, servicePortsAndPortGroups, vlanIdsUsedInSdEgress);
        } else if (policy != null) {
            policy = updateTargetPolicyOne(policy, ingressPorts, vlanIdsUsedInSdEgress);
        }
        if (policy != null) {
            updateDefaultValues(policy);
            Long policyOneJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policy, false);
            job = getJobStatus(policyOneJobId);
        }
        return job;
    }

    /**
     * This method is used for commit second MLXe/SLX policy
     *
     * @param policy
     * @param targetDevice
     * @param servicePortsAndPortGroups
     * @param sdEgressPorts
     * @return
     */
    public Job commitTargetPolicyTwo(Policy policy, Device targetDevice, Set<ManagedObject> servicePortsAndPortGroups, List<EgressPort> sdEgressPorts) {
        Job job = new Job();
        if (policy != null) {
            policy = policyRepository.findOne(policy.getId());
        }
        if (policy == null && targetDevice != null && servicePortsAndPortGroups != null && sdEgressPorts != null) {
            policy = createTargetPolicyTwo(targetDevice, servicePortsAndPortGroups, sdEgressPorts);
        } else if (policy != null) {
            policy = updateTargetPolicyTwo(policy, servicePortsAndPortGroups, sdEgressPorts);
        }
        if (policy != null) {
            updateDefaultValues(policy);
            Long policyTwoJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policy, false);
            job = getJobStatus(policyTwoJobId);
        }
        return job;
    }

    /**
     * Method sets the default value for the policy fields which are null
     *
     * @param policy
     */
    private void updateDefaultValues(Policy policy) {
        if (policy != null) {
            policy.getFlows().forEach(flow -> {
                if (flow.getIsTagged() == null) {
                    flow.setIsTagged(false);
                }
                if (flow.getIsDefaultRouteMapDrop() == null) {
                    flow.setIsDefaultRouteMapDrop(false);
                }
                flow.getRuleSets().forEach(ruleSet -> {
                    ruleSet.getRules().forEach(rule -> {
                        if (rule.getSourcePort() == null)
                            rule.setSourcePort(0);
                        if (rule.getDestinationPort() == null)
                            rule.setDestinationPort(0);
                        if (rule.getVlanId() == null)
                            rule.setVlanId(-1);
                        if (rule.getIsPermit() == null)
                            rule.setIsPermit(false);
                    });
                });
            });
        }
    }

    /**
     * This method builds the updates MLXe/SLX policy
     *
     * @param policy
     * @param ingressPorts
     * @return
     */
    public Policy updateTargetPolicyOne(Policy policy, Set<Port> ingressPorts, Set<Long> vlanIdsUsedInSdEgress) {
        Set<Long> vlansInFlow = new HashSet<>();
        policy.getFlows().forEach(flow -> {
            flow.clearIngressPortsAndPortGroups();
            flow.setIngressPorts(ingressPorts);
        });
        if (vlanIdsUsedInSdEgress != null) {
            vlansInFlow.addAll(vlanIdsUsedInSdEgress);
            vlanIdsUsedInSdEgress.stream().forEach(vlan ->
                    policy.getFlows().stream().forEach(flow ->
                            flow.getVlans().forEach(existingVlanId -> {
                                if (existingVlanId.equals(vlan.toString())) {
                                    Long newVlanId = generateVlanIds(vlansInFlow, policy.getDevice().getId());
                                    flow.setVlans(Sets.newHashSet(String.valueOf(newVlanId)));
                                }
                            })
                    )
            );
        }
        return policy;
    }

    /**
     * This method updates MLXe/SLX policy based on service port update
     *
     * @param targetDevice
     * @param oldServicePortToNewMap
     * @return
     */
    public Job updateTargetPoliciesForServicePorts(Device targetDevice, Map<Long, Port> oldServicePortToNewMap) {
        Policy policyOne = null;
        Policy policyTwo = null;
        Job job = null;
        Set<Policy> sdPolicies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(targetDevice.getId(), true));
        if (!sdPolicies.isEmpty()) {
            for (Policy policy : sdPolicies) {
                if (policy.getName().contains("_one_")) {
                    policyOne = policy;
                } else if (policy.getName().contains("_two_")) {
                    policyTwo = policy;
                }
            }

            Set<Port> newPorts = Sets.newHashSet();
            Set<Port> oldPorts = Sets.newHashSet();
            if (!oldServicePortToNewMap.isEmpty()) {
                if (policyOne != null) {
                    policyOne.getFlows().forEach(flow -> {
                        Port oldEgressPort = flow.getEgressPorts().stream().findAny().orElseGet(null);
                        if (oldEgressPort != null) {
                            Port newEgressPort = oldServicePortToNewMap.get(oldEgressPort.getId());
                            if (newEgressPort != null) {
                                flow.removeEgressPorts(Sets.newHashSet(oldEgressPort));
                                flow.removeFlowEgressManagedObjects(Sets.newHashSet(oldEgressPort));
                                flow.addEgressPorts(Sets.newHashSet(newEgressPort));
                                flow.addFlowEgressManagedObjects(Sets.newHashSet(newEgressPort));
                                oldPorts.add(oldEgressPort);
                                newPorts.add(newEgressPort);
                            }
                        }
                    });

                    Long policyOneJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policyOne, false);
                    job = getJobStatus(policyOneJobId);
                }

                if (job != null && job.getStatus() == Job.Status.SUCCESS && policyTwo != null && !oldPorts.isEmpty() && !newPorts.isEmpty()) {
                    policyTwo.getFlows().forEach(flow -> {
                        flow.removeIngressPorts(oldPorts);
                        flow.setIngressPorts(newPorts);
                    });
                    Long policyTwoJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policyTwo, false);
                    job = getJobStatus(policyTwoJobId);
                }
            }
        }
        return job;
    }

    /**
     * This method create MLXe/SLX policy
     *
     * @param targetDevice
     * @param profile
     * @param ingressPorts
     * @param servicePortsAndPortGroups
     * @return
     * @Param sdIngressPorts
     */
    private Policy createTargetPolicyOne(Device targetDevice, Profile profile, List<IngressPort> sdIngressPorts, Set<Port> ingressPorts,
                                         Set<ManagedObject> servicePortsAndPortGroups, Set<Long> vlanIdsUsedInSdEgress) {
        Policy policy = new Policy();
        policy.setDevice(targetDevice);
        List<Integer> sipCustomPorts = new ArrayList<>();
        GlobalConfig globalConfig = globalConfigRepository.findByDeviceId(pairedDeviceRepository.findByTargetDeviceId(targetDevice.getId()).getDevice().getId());
        if (globalConfig != null) {
            sipCustomPorts.addAll(globalConfig.getSipPorts());
        }
        Map<String, List> portNumberTypeMap = Maps.newLinkedHashMap();
        if (profile.getName().equals(ARCH1_DEF_S11_S1U_2_40G_CONFIG)) {
            portNumberTypeMap.put(CONTROL_PORT, Lists.newArrayList(2123));
            portNumberTypeMap.put(GTPU_PORT1, Lists.newArrayList(2152));
            portNumberTypeMap.put(GTPU_PORT2, Lists.newArrayList(2152));
        } else if (profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE) || profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI)) {
            portNumberTypeMap.put(CONTROL_PORT, Lists.newArrayList(2123));
            sipCustomPorts.add(5060);
            portNumberTypeMap.put(SIP_PORT, sipCustomPorts);
            portNumberTypeMap.put(GTPU_PORT, Lists.newArrayList(2152));
            portNumberTypeMap.put(RTP_PORT, Lists.newArrayList()); // - catch all
        }

        policy.setName("policy_one_" + targetDevice.getType().toString() + "_" + targetDevice.getId());
        policy.setCreatedFromSd(true);
        policy.setFieldOffset1(-1l);
        policy.setFieldOffset2(-1l);
        policy.setFieldOffset3(-1l);
        policy.setFieldOffset4(-1l);

        SortedSet<Flow> flows = new TreeSet<>();
        Set<Long> vlansInFlow = new HashSet<>(vlanIdsUsedInSdEgress);
        int flowSeq = 5;
        for (String ingressPortType : portNumberTypeMap.keySet()) {
            List<Integer> portList = portNumberTypeMap.get(ingressPortType);
            if (portList != null) {
                IngressPort ingressPort = sdIngressPorts.stream().filter(port -> port.getName().equals(ingressPortType)).findFirst().orElse(null);
                if (ingressPort != null && ingressPort.getServicePort() != null && ingressPort.getServicePort() instanceof Port) {
                    Long vlanId = generateVlanIds(vlansInFlow, targetDevice.getId());
                    if ((profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE) || profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI)) &&
                            CONTROL_PORT.equals(ingressPortType) && portList.size() > 1 && portList.contains(2123)) {
                        flows.add(createFlow(profile, ingressPort.getServicePort(), ingressPorts, vlanId, Lists.newArrayList(2123), flowSeq += 5));
                        portList.remove(portList.indexOf(2123));
                    }
                    flows.add(createFlow(profile, ingressPort.getServicePort(), ingressPorts, vlanId, portList, flowSeq += 5));
                }
            }
        }
        policy.setFlows(flows);
        return policy;
    }

    /**
     * Create the flow for the policy one
     *
     * @param profile
     * @param managedObject
     * @param ingressPorts
     * @param vlanId
     * @param portList
     * @param flowSeq
     * @return
     */
    private Flow createFlow(Profile profile, ManagedObject managedObject, Set<Port> ingressPorts, Long vlanId,
                            List<Integer> portList, int flowSeq) {
        Flow flow = new Flow();
        flow.setSequence(flowSeq);
        flow.setIsTagged(true);
        flow.setVlans(Sets.newHashSet(String.valueOf(vlanId)));
        if (managedObject instanceof Port) {
            flow.setEgressPorts(Sets.newHashSet((Port) managedObject));
        } else if (managedObject instanceof PortGroup) {
            flow.setEgressPortGroups(Sets.newHashSet((PortGroup) managedObject));
        }
        flow.setIngressPorts(ingressPorts);
        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        int ruleSetSeq = 1;
        for (RuleSet.IpVersion ipVersion : RuleSet.IpVersion.values()) {
            RuleSet ruleSet = new RuleSet();
            ruleSet.setSequence(ruleSetSeq);
            ruleSet.setType(RuleSet.Type.L3);
            ruleSet.setIpVersion(ipVersion);
            ruleSetSeq++;
            SortedSet<Rule> rules = new TreeSet<>();
            //catch all rule
            if (portList.isEmpty()) {
                Rule rule = new Rule();
                rule.setSequence(1l);
                rule.setProtocol(IP);
                rule.setProtocolType(IP);
                rule.setSourceIp(ANY);
                rule.setDestinationIp(ANY);
                rule.setIsPermit(true);
                rule.setSourcePortOperator(EQ);
                rule.setDestinationPortOperator(EQ);
                rule.setSourceMac(ANY);
                rule.setDestinationMac(ANY);
                rule.setEthType(ANY);
                rules.add(rule);
            } else {
                long sequence = 1;
                for (Integer portNo : portList) {
                    rules.add(addRule(UDP, sequence++, portNo, -1));
                    rules.add(addRule(UDP, sequence++, -1, portNo));
                    if (profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI) && portNo != 2123 && portNo != 2152) {
                        rules.add(addRule(TCP, sequence++, portNo, -1));
                        rules.add(addRule(TCP, sequence++, -1, portNo));
                    }
                }
            }
            ruleSet.setRules(rules);
            ruleSets.add(ruleSet);
        }
        flow.setRuleSets(ruleSets);
        return flow;
    }

    /**
     * Method build and return the rule
     *
     * @param protocol
     * @param sequence
     * @param sourcePortNo
     * @param destinationPortNo
     * @return
     */
    private Rule addRule(String protocol, long sequence, int sourcePortNo, int destinationPortNo) {
        Rule rule = new Rule();
        rule.setSequence(sequence);
        rule.setProtocol(protocol);
        rule.setProtocolType(protocol);
        rule.setSourceIp(ANY);
        rule.setDestinationIp(ANY);
        if (sourcePortNo != -1)
            rule.setSourcePort(sourcePortNo);
        if (destinationPortNo != -1)
            rule.setDestinationPort(destinationPortNo);
        rule.setIsPermit(true);
        rule.setSourcePortOperator(EQ);
        rule.setDestinationPortOperator(EQ);
        rule.setSourceMac(ANY);
        rule.setDestinationMac(ANY);
        rule.setEthType(ANY);
        return rule;
    }


    /**
     * Method return the maximum flow sequence number from policy
     *
     * @param policy
     * @return
     */
    private int getMaxFlowSequence(Policy policy) {
        int flowSequence = 0;
        for (Flow flow : policy.getFlows()) {
            flowSequence = flow.getSequence() > flowSequence ? flow.getSequence() : flowSequence;
        }
        return flowSequence;
    }

    /**
     * This method create MLXe/SLX policy
     *
     * @param targetDevice
     * @param servicePortsAndPortGroups
     * @param sdEgressPorts
     * @return
     */
    private Policy createTargetPolicyTwo(Device targetDevice, Set<ManagedObject> servicePortsAndPortGroups, List<EgressPort> sdEgressPorts) {
        Policy policy = new Policy();
        policy.setDevice(targetDevice);

        policy.setName("policy_two_" + targetDevice.getType().toString() + "_" + targetDevice.getId());
        policy.setCreatedFromSd(true);
        policy.setFieldOffset1(-1l);
        policy.setFieldOffset2(-1l);
        policy.setFieldOffset3(-1l);
        policy.setFieldOffset4(-1l);

        SortedSet<Flow> flows = new TreeSet<>();
        AtomicInteger flowSequence = new AtomicInteger(FLOW_SEQUENCE_UNIT);
        sdEgressPorts.forEach(port -> {
            port.getVlanMappings().forEach(vlanMapping -> {
                long vlanId = vlanMapping.getVlanId();
                flows.add(addFlow(servicePortsAndPortGroups, port, flowSequence, vlanId));
                flows.add(addFlow(servicePortsAndPortGroups, port, flowSequence, vlanId + EgressPort.VLAN_INCREMENT_VALUE));
            });
        });
        policy.setFlows(flows);
        return policy;
    }

    /**
     * This method removes the unmarked ports from MLXe/SLX policy and commit
     *
     * @param policy
     * @param egressPorts
     * @return
     */
    public Job removePortsFromPolicyTwoAndSd(Policy policy, Device sdDevice, Device targetDevice, Set<Port> egressPorts) {
        Job job = new Job();
        if (policy != null) {
            List<EgressPort> removedSdEgressPorts = Lists.newArrayList();
            List<EgressPort> sdEgressPortsFromDb = egressPortRepository.findByDeviceId(sdDevice.getId());
            sdEgressPortsFromDb.forEach(egressPort -> {
                if (!egressPort.isDefault()) {
                    Port existingPort = egressPorts.stream().filter(port1 -> port1.getId() == egressPort.getSourcePort().getId()).findAny().orElse(null);
                    if (existingPort == null) {
                        removedSdEgressPorts.add(egressPort);
                    }
                }
            });
            SortedSet<Flow> flows = new TreeSet<>();
            policy.getFlows().forEach(flow ->
                    flow.getEgressPorts().stream().forEach(flowPort -> {
                        Optional portOptional = egressPorts.stream().filter(port -> flowPort.getId() == port.getId()).findAny();
                        if (portOptional.isPresent()) {
                            flows.add(flow);
                        }
                    })
            );
            if (!removedSdEgressPorts.isEmpty()) {
                Long sdPortJobId = getSdPortManager().deletePort(sdDevice, removedSdEgressPorts);
                job = getJobStatus(sdPortJobId);
            }
            if (policy.getFlows().size() != flows.size() && flows.size() > 0) {
                policy.setFlows(flows);
                Long policyOneJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policy, false);
                job = getJobStatus(policyOneJobId);
            }
        }
        return job;
    }

    /**
     * This method builds the updated MLXe/SLX policy
     *
     * @param policy
     * @param servicePortsAndPortGroups
     * @param sdEgressPorts
     * @return
     */
    private Policy updateTargetPolicyTwo(Policy policy, Set<ManagedObject> servicePortsAndPortGroups, List<EgressPort> sdEgressPorts) {
        SortedSet<Flow> flows = Sets.newTreeSet();
        AtomicInteger flowSequence = new AtomicInteger(getMaxFlowSequence(policy));
        sdEgressPorts.forEach(port -> {
            Set<Flow> existingFlows = policy.getFlows().stream().filter(flow -> {
                return flow.getEgressPorts().stream().anyMatch(port1 -> port.getSourcePort().getId() == port1.getId());
            }).collect(Collectors.toSet());

            //new port
            if (existingFlows.isEmpty()) {
                port.getVlanMappings().forEach(vlanMapping -> {
                    flows.add(addFlow(servicePortsAndPortGroups, port, flowSequence, vlanMapping.getVlanId()));
                    flows.add(addFlow(servicePortsAndPortGroups, port, flowSequence, vlanMapping.getVlanId() + EgressPort.VLAN_INCREMENT_VALUE));
                });
            } else {
                //need to match the vlans and find new vlan and add flow
                Set<String> vlanSetFromPort = Sets.newHashSet();
                port.getVlanMappings().forEach(vlanMapping -> {
                    vlanSetFromPort.add(String.valueOf(vlanMapping.getVlanId()));
                    vlanSetFromPort.add(String.valueOf(vlanMapping.getVlanId() + EgressPort.VLAN_INCREMENT_VALUE));
                });

                vlanSetFromPort.forEach(vlan -> {
                    Flow updatedFlowWithNewVlan = existingFlows.stream().filter(flow -> flow.getVlans().contains(vlan)).findAny().orElse(null);
                    if (updatedFlowWithNewVlan != null) {
                        SdPortVlanMapping vlanMapping = port.getVlanMappings().stream().filter(vlanTagged -> vlanTagged.getVlanId().longValue() == Long.valueOf(vlan).longValue()).findFirst().orElse(null);
                        updatedFlowWithNewVlan.setIsTagged(vlanMapping != null ? vlanMapping.isTagged() : true);
                        flows.add(updatedFlowWithNewVlan);
                    } else {
                        //add new flow for the vlan
                        flows.add(addFlow(servicePortsAndPortGroups, port, flowSequence, Long.valueOf(vlan)));
                    }
                });
            }
        });
        policy.setFlows(flows);
        return policy;
    }

    /**
     * Method builds the flow based on the port and port-group
     *
     * @param servicePortsAndPortGroups
     * @param sdEgressPort
     * @param flowSequence
     * @param vlanId
     * @return
     */
    private Flow addFlow(Set<ManagedObject> servicePortsAndPortGroups, EgressPort sdEgressPort, AtomicInteger flowSequence, long vlanId) {
        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        SortedSet<Rule> rules = new TreeSet<>();

        Flow flow = new Flow();
        flow.setSequence(flowSequence.addAndGet(FLOW_SEQUENCE_UNIT));
        if (sdEgressPort.getVlanMappings().stream().filter(vlan -> vlan.getVlanId() == vlanId).collect(Collectors.toList()).size() > 1) {
            throw new ValidationException("port.vlan.duplicate");
        }
        SdPortVlanMapping vlanMapping = sdEgressPort.getVlanMappings().stream().filter(vlan -> vlan.getVlanId() == vlanId).findFirst().orElse(null);
        flow.setIsTagged(vlanMapping != null ? vlanMapping.isTagged() : true);
        flow.setVlans(Sets.newHashSet(String.valueOf(vlanId)));
        flow.setIngressPorts(servicePortsAndPortGroups.stream()
                .filter(mo -> mo instanceof Port)
                .map(mo -> (Port) mo)
                .collect(Collectors.toSet()));
        flow.setIngressPortGroups(servicePortsAndPortGroups.stream()
                .filter(mo -> mo instanceof PortGroup)
                .map(mo -> (PortGroup) mo)
                .collect(Collectors.toSet()));
        flow.setEgressPorts(Sets.newHashSet(sdEgressPort.getSourcePort()));

        RuleSet ruleSet = new RuleSet();
        ruleSet.setSequence(1);
        ruleSet.setType(RuleSet.Type.L2);

        Rule rule = new Rule();
        rule.setSequence(1l);
        rule.setEthType(ANY);
        rule.setSourceIp(ANY);
        rule.setDestinationIp(ANY);
        rule.setSourceMac(ANY);
        rule.setDestinationMac(ANY);
        rule.setIsPermit(true);
        rule.setVlanId((int) vlanId);
        rules.add(rule);

        ruleSet.setRules(rules);
        ruleSets.add(ruleSet);
        flow.setRuleSets(ruleSets);
        return flow;
    }

    /**
     * This method is used for recover MLXe/SLX policies
     *
     * @param sdPortPolicyParameter
     * @return
     */
    public Long recoverPolicies(SdPortPolicyParameter sdPortPolicyParameter) {
        Device pairedDevice = deviceRepository.findById(sdPortPolicyParameter.getTargetDevice().getId());

        Job job = new Job();
        Policy policyOne = null;
        Policy policyTwo = null;
        if (sdPortPolicyParameter.getPolicyOne() != null) {
            policyOne = policyRepository.findOne(sdPortPolicyParameter.getPolicyOne().getId());
        }
        if (sdPortPolicyParameter.getPolicyTwo() != null) {
            policyTwo = policyRepository.findOne(sdPortPolicyParameter.getPolicyTwo().getId());
        }

        if (policyOne != null && policyOne.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
            Long policyOneJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager()
                    .deletePolicy(policyOne.getId(), false, false);
            job = getJobStatusWithoutTimeout(policyOneJobId);
        }
        if (job != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
            if (policyTwo != null && policyTwo.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                Long policyTwoJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager().deletePolicy(policyTwo.getId(), false, false);
                job = getJobStatusWithoutTimeout(policyTwoJobId);
            }
        }
        if (job != null) {
            return job.getId();
        }
        return -1l;
    }

    /**
     * This method is used for recover SD Egress port
     *
     * @param ports
     * @param sdDevice
     * @return
     */
    public Long recoverSdEgressPorts(List<EgressPort> ports, Device sdDevice) {
        Job job = new Job();
        List<Long> portIds = ports.stream().filter(port -> !port.isDefault()).map(EgressPort::getId).collect(Collectors.toList());
        if (!portIds.isEmpty() && !egressPortGroupRepository.findPortGroupIdsByPortIds(portIds).isEmpty()) {
            log.error("Cannot perform port operation. Port is in use in Port Group");
            throw new ValidationException("port.used.portGroup");
        }
        List<Long> portInSubmittedState = egressPortRepository.findByDeviceAndInWorkflowStatus(sdDevice.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!portInSubmittedState.isEmpty()) {
            log.error("Cannot recover Port as another Port operation is in progress.");
            throw new ValidationException("port.recover.in.progress");
        }
        Long sdPortJobId = getSdPortManager().rollbackPort(sdDevice, ports);
        if (sdPortJobId != -1) {
            job = getJobStatus(sdPortJobId);

            if (job != null && job.getStatus() == Job.Status.FAILED) {
                throw new ServerException(job.getJobResult());
            }
        }
        if (job != null) {
            return job.getId();
        }
        return -1l;
    }

    /**
     * This method is used for recover MLXe/SLX port and policy
     *
     * @param sdPortPolicyParameter
     * @param sdDevice
     * @return
     */
    public Long recoverPortsAndPolicies(SdPortPolicyParameter sdPortPolicyParameter, Device sdDevice) {
        Device pairedDevice = sdPortPolicyParameter.getTargetDevice();
        Job job = new Job();
        List<Long> portInSubmittedState = egressPortRepository.findByDeviceAndInWorkflowStatus(sdDevice.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!portInSubmittedState.isEmpty()) {
            log.error("Cannot recover Port as another Port operation is in progress.");
            throw new ValidationException("port.recover.in.progress");
        }
        PortParameters portParameters = getPortParameters(sdPortPolicyParameter.getSdPortParameters());
        List<EgressPort> ports = getEgressPorts(sdDevice, sdPortPolicyParameter.getSdPortParameters());
        Long sdPortJobId = getSdPortManager().rollbackPort(sdDevice, ports);
        if (sdPortJobId != -1) {
            job = getJobStatus(sdPortJobId);
        }
        if (job != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
            Policy policyOne = null;
            Policy policyTwo = null;
            if (sdPortPolicyParameter.getPolicyOne() != null) {
                policyOne = policyRepository.findOne(sdPortPolicyParameter.getPolicyOne().getId());
            }
            if (sdPortPolicyParameter.getPolicyTwo() != null) {
                policyTwo = policyRepository.findOne(sdPortPolicyParameter.getPolicyTwo().getId());
            }

            if (policyOne != null && policyOne.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                Long policyOneJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager()
                        .deletePolicy(policyOne.getId(), false, false);
                job = getJobStatus(policyOneJobId);
            }
            if (job != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
                if (policyTwo != null && policyTwo.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    Long policyTwoJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager().deletePolicy(policyTwo.getId(), false, false);
                    job = getJobStatus(policyTwoJobId);
                }
                if (job != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
                    Set<PortGroup> portGroups = Sets.newHashSet();
                    if (policyOne != null) {
                        policyOne.getFlows().forEach(flow -> {
                            portGroups.addAll(flow.getEgressPortGroups());
                        });
                    } else if (policyTwo != null) {
                        policyTwo.getFlows().forEach(flow -> {
                            portGroups.addAll(flow.getIngressPortGroups());
                        });
                    }
                    if (!portGroups.isEmpty()) {
                        for (PortGroup portGroup : portGroups) {
                            if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                                List<Long> portGroupIds = new ArrayList<>();
                                portGroupIds.add(portGroup.getId());
                                Long jobId = managerBuilder.getOperationsFactory(pairedDevice).getPortGroupManager().rollBackPortGroup(portGroup, portGroupIds);
                                job = getJobStatus(jobId);
                                if (job != null && job.getStatus() == Job.Status.FAILED) {
                                    throw new ServerException(job.getJobResult());
                                }
                            }
                        }
                    }

                    List<Long> portIds = portParameters.getPortIds();
                    if (job != null && portIds != null && !portIds.isEmpty() && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
                        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                                .collect(Collectors.toList());
                        portIds = applicablePorts.stream().filter(port -> port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR).map(Port::getId).collect(Collectors.toList());
                        if (portIds != null && !portIds.isEmpty()) {
                            Long portJobId = managerBuilder.getOperationsFactory(pairedDevice)
                                    .getPortManager()
                                    .recoverPort(pairedDevice.getId(), portIds);
                            job = getJobStatus(portJobId);
                            if (job != null && job.getStatus() == Job.Status.SUCCESS) {
                                return job.getId();
                            }
                        }
                    }
                }
            }
        }

        if (job != null) {
            if (job.getStatus() == Job.Status.FAILED) {
                throw new ServerException(job.getJobResult());
            }
            return job.getId();
        }
        throw new ServerException("Job timed out");
    }


    /**
     * This method is used for delete MLXe/SLX port and policy
     *
     * @param sdPortPolicyParameter
     * @param sdDevice
     * @return
     */
    public Long deletePortsAndPolicies(SdPortPolicyParameter sdPortPolicyParameter, Device sdDevice) {
        Device pairedDevice = sdPortPolicyParameter.getTargetDevice();
        List<EgressPort> ports = getEgressPorts(sdDevice, sdPortPolicyParameter.getSdPortParameters());
        Job job = new Job();
        List<Long> portInSubmittedState = egressPortRepository.findByDeviceAndInWorkflowStatus(sdDevice.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!portInSubmittedState.isEmpty()) {
            log.error("Cannot delete Port as another Port operation is in progress.");
            throw new ValidationException("port.delete.inprogress");
        }
        Long sdPortJobId = -1L;
        if (!ports.isEmpty()) {
            sdPortJobId = getSdPortManager().deletePort(sdDevice, ports);
            if (sdPortJobId != -1) {
                job = getJobStatus(sdPortJobId);
            }
        }

        if (job != null && (job.getStatus() == Job.Status.CREATED | job.getStatus() == Job.Status.SUCCESS)) {
            Policy policyOne = null;
            Policy policyTwo = null;
            if (sdPortPolicyParameter.getPolicyOne() != null) {
                policyOne = policyRepository.findOne(sdPortPolicyParameter.getPolicyOne().getId());
            }
            if (sdPortPolicyParameter.getPolicyTwo() != null) {
                policyTwo = policyRepository.findOne(sdPortPolicyParameter.getPolicyTwo().getId());
            }

            if (policyOne != null) {
                Long policyOneJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager()
                        .deletePolicy(policyOne.getId(), false, false);
                job = getJobStatus(policyOneJobId);
            }
            if (job != null && (job.getStatus() == Job.Status.CREATED | job.getStatus() == Job.Status.SUCCESS)) {
                if (policyTwo != null) {
                    Long policyTwoJobId = managerBuilder.getOperationsFactory(pairedDevice).getPolicyManager().deletePolicy(policyTwo.getId(), false, false);
                    job = getJobStatus(policyTwoJobId);
                }
                if (job != null && (job.getStatus() == Job.Status.CREATED | job.getStatus() == Job.Status.SUCCESS)) {
                    Set<PortGroup> portGroups = Sets.newHashSet();
                    if (policyOne != null) {
                        policyOne.getFlows().forEach(flow -> {
                            portGroups.addAll(flow.getEgressPortGroups());
                        });
                    } else if (policyTwo != null) {
                        policyTwo.getFlows().forEach(flow -> {
                            portGroups.addAll(flow.getIngressPortGroups());
                        });
                    }
                    if (!portGroups.isEmpty()) {
                        for (PortGroup portGroup : portGroups) {
                            List<Long> portGroupIds = new ArrayList<>();
                            portGroupIds.add(portGroup.getId());
                            Long jobId = managerBuilder.getOperationsFactory(pairedDevice).getPortGroupManager().deletePortGroup(portGroup, portGroupIds);
                            job = getJobStatus(jobId);
                            if (job != null && job.getStatus() == Job.Status.FAILED) {
                                throw new ServerException(job.getJobResult());
                            }
                        }
                    }
                }
            }
        }

        if (job != null) {
            if (job.getStatus() == Job.Status.FAILED) {
                throw new ServerException(job.getJobResult());
            }
            return job.getId();
        }
        throw new ServerException("Job timed out");
    }


    /**
     * This method is used for save/commit policy
     *
     * @param sdPolicyRequest
     * @param device
     * @param action
     * @return
     */
    public Long saveOrCommit(SdPolicyRequest sdPolicyRequest, Device device, String action) {
        long jobPolicyId = 0;
        if (!sdPolicyRequest.getDedupePolicies().isEmpty()) {
            jobPolicyId = getSdPolicyManager(sdPolicyRequest.getDedupePolicies()).
                    saveOrCommitPolicies(sdPolicyRequest.getDedupePolicies(), device, action, sdPolicyRequest.getName());
        }
        if (!sdPolicyRequest.getFilterPolicies().isEmpty()) {
            jobPolicyId = getSdPolicyManager(sdPolicyRequest.getFilterPolicies()).
                    saveOrCommitPolicies(sdPolicyRequest.getFilterPolicies(), device, action, sdPolicyRequest.getName());
        }
        if (!sdPolicyRequest.getSamplingPolicies().isEmpty()) {
            jobPolicyId = getSdPolicyManager(sdPolicyRequest.getSamplingPolicies()).
                    saveOrCommitPolicies(sdPolicyRequest.getSamplingPolicies(), device, action, sdPolicyRequest.getName());
        }
        return jobPolicyId;
    }

    /**
     * This method is used for committing an Interface with status polling
     *
     * @param activeInterface
     * @param device
     * @param action
     * @return
     */
    public Long commitInterfaceWithStatusPolling(ActiveInterface activeInterface, Device device, String action) {
        Long jobId = saveOrCommitInterface(activeInterface, device, action);
        if (jobId != null && jobId != -1) {
            Job job = getJobStatus(jobId);
            if (job != null) {
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(job.getJobResult());
                }
            }
        }
        return jobId;
    }

    /**
     * This method is used for saving/commit an Interface
     *
     * @param activeInterface
     * @param device
     * @param action
     * @return
     */
    public Long saveOrCommitInterface(ActiveInterface activeInterface, Device device, String action) {
        Long jobId = sdActiveInterfaceManager.saveOrCommitActiveInterface(activeInterface, device, action);
        return jobId;
    }

    /**
     * This is used for getting stats on demand
     *
     * @param statsType
     * @param device
     * @return
     */
    public Object getStats(String statsType, Device device) {
        return sdStatsManager.getStats(statsType, device);
    }

    public Object startStopStatsTimeTask(String action, Device device) {
        if (action.equalsIgnoreCase(START)) {
            statsTimerTask.startStatsTimerTask(device);
        } else if (action.equalsIgnoreCase(STOP)) {
            statsTimerTask.stopStatsTimerTask();
        } else if (action.equalsIgnoreCase(CLEAR)) {
            return sdStatsManager.clearStats(device);
        }
        return null;
    }

    /**
     * This method is used for deleting an interface with status polling
     *
     * @param activeInterface
     * @param device
     * @return
     */
    public Long deleteInterfaceWithStatusPolling(ActiveInterface activeInterface, Device device) {
        Long jobId = deleteInterface(Lists.newArrayList(activeInterface), device);
        if (jobId != null && jobId != -1) {
            Job job = getJobStatus(jobId);
            if (job != null) {
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(job.getJobResult());
                }
            }
        }
        return jobId;
    }

    /**
     * This method is used for deleting an interface
     *
     * @param activeInterfaces
     * @param device
     * @return
     */
    public Long deleteInterface(List<ActiveInterface> activeInterfaces, Device device) {
        return sdActiveInterfaceManager.deleteInterface(activeInterfaces, device);
    }

    /**
     * This method is used for deleting Policy
     *
     * @param policies
     * @param action
     * @return
     */
    public Long deletePolicy(List<SdPolicy> policies, String action) {
        if (!policies.isEmpty()) {
            SdPolicy sdPolicyToDelete = policies.get(0);
            if (sdPolicyToDelete != null) {
                if (CLEANUP.equalsIgnoreCase(action) && WorkflowParticipant.WorkflowStatus.ERROR.equals(sdPolicyToDelete.getWorkflowStatus())) {
                    return getSdPolicyManager(sdPolicyToDelete).recoverPolicy(sdPolicyToDelete.getId());
                } else {
                    return getSdPolicyManager(sdPolicyToDelete).deletePolicy(policies);
                }
            }
        }
        return -1L;
    }

    /**
     * This method is return the job status
     *
     * @param jobId
     * @return
     */
    private Job getJobStatus(Long jobId) {
        log.debug("Job status polling {}", jobId);
        long startTime = System.currentTimeMillis();
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }

            try {
                TimeUnit.SECONDS.sleep(jobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((stablenetTimeoutMinutes + 1) * 60 * 1000)) {
                log.warn("Job status polling timeout!");
                break;
            }
        }
        return null;
    }

    /**
     * This method is return the job status, there is no timeout
     *
     * @param jobId
     * @return
     */
    private Job getJobStatusWithoutTimeout(Long jobId) {
        log.debug("********** Job Status polling, no timeout**********");
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }
            try {
                TimeUnit.SECONDS.sleep(policyJobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
        }
        return null;
    }

    /**
     * This method is return the SD egress ports
     *
     * @param device
     * @param sdPortParameters
     * @return
     */
    private List<EgressPort> getEgressPorts(Device device, List<SdPortParameter> sdPortParameters) {
        List<EgressPort> ports = new ArrayList();
        sdPortParameters.stream().forEach(sdPortParameter -> {
            if (sdPortParameter.getType() == Port.Type.EGRESS && sdPortParameter.getEgressPort() == null) {
                throw new ValidationException("sd.egress.port.missing");
            }
            EgressPort egressPort = sdPortParameter.getEgressPort();
            if (egressPort != null) {
                egressPort.setDevice(device);
                egressPort.setName(sdPortParameter.getName());
                Set<SdPortVlanMapping> vlanMappings = populateVlanIdsFromRequest(egressPort);
                if (vlanMappings != null) {
                    egressPort.setVlanMappings(vlanMappings);
                }
                egressPort.setVlanMappings(vlanMappings);
                if (!egressPort.isDefault()) {
                    egressPort.setSourcePort(portRepository.findOne(sdPortParameter.getId()));
                }
                ports.add(egressPort);
            }
        });
        return ports;
    }

    /**
     * This method returns the MLXe/SLX ports for port marking
     *
     * @param sdPortParameters
     * @return
     */
    private PortParameters getPortParameters(List<SdPortParameter> sdPortParameters) {
        PortParameters portParameters = new PortParameters();
        List<Long> portIds = new ArrayList<>();
        sdPortParameters.stream().forEach(sdPortParameter -> {
            portIds.add(sdPortParameter.getId());
        });
        portParameters.setPortIds(portIds);
        return portParameters;
    }

    /**
     * This method collects the used vlan Id from rule, flow vlan and header stripping module policy and return the unique id for a device.
     *
     * @param deviceId
     * @return
     */
    private synchronized Long generateVlanIds(Set<Long> vlansInFlow, Long deviceId) {
        Set<Long> vlans = new HashSet<>();
        List<String> flowVlans = flowRepository.findVlansByDeviceId(deviceId);
        if (!flowVlans.isEmpty()) {
            flowVlans.forEach(vlan -> {
                vlans.add(Long.parseLong(vlan));
            });
        }
        vlans.addAll(headerStrippingModulePolicyRepository.findVlanIdsByDeviceId(deviceId));
        vlans.addAll(ruleRepository.findVlanIdsByDevice(deviceId));
        vlans.addAll(vlansInFlow);
        Long vlanId = getVlanId(vlans);
        vlansInFlow.add(vlanId);
        return vlanId;
    }

    /**
     * This method generate an unused vlan Id
     *
     * @param vlanIdUsed
     * @return
     */
    private synchronized Long getVlanId(Set<Long> vlanIdUsed) {
        List<Long> vlanIdAll = new ArrayList();
        for (long i = EgressPort.VLAN_MIN; i <= EgressPort.VLAN_MAX; i++) {
            vlanIdAll.add(i);
        }
        if (!vlanIdUsed.isEmpty()) {
            vlanIdAll.removeAll(vlanIdUsed);
        }
        if (!vlanIdAll.isEmpty()) {
            return vlanIdAll.get(0);
        } else {
            throw new ValidationException("Cannot add VLAN ID, only " + EgressPort.VLAN_MAX + " VLAN IDs are supported!");
        }
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(Set<? extends TemplatePolicy> templatePolicies) {
        throw new UnsupportedOperationException("This feature is not supported for SessionDirector!");
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(TemplatePolicy templatePolicy) {
        throw new UnsupportedOperationException("This feature is not supported for SessionDirector!");
    }
}
