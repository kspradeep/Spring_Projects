package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.model.DeviceAdditionResponse;
import com.brocade.bvm.dao.DeviceDiscoveryJobRepository;
import com.brocade.bvm.model.db.DeviceDiscoveryJob;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.JobBaseVO;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.XmlDiscoveryBaseJobVO;
import com.brocade.bvm.outbound.stablenet.model.JobResultVO;
import com.brocade.bvm.outbound.stablenet.model.RestResultStateEnum;
import com.brocade.bvm.outbound.stablenet.model.Result;
import com.brocade.bvm.outbound.stablenet.model.ResultVo;
import com.google.common.base.Strings;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.xml.bind.*;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

@Slf4j
public class AddDeviceJobCallable implements Callable {

    public AddDeviceJobCallable(StablenetAdminConnection stablenetAdminConnection, XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO, String addDeviceXmlDiscoveryUrl, String jobResultListUrl, String jobresultdata, String deleteJobUrl, DeviceDiscoveryJobRepository deviceDiscoveryJobRepository, String modifyDeviceXmlDiscoveryUrl, String jobIsRunningStatusUrl, String jobStartUrl, int snDiscoveryTimeoutMinutes, int delayTocheckJobStatusInSeconds) {
        this.stablenetConnection = stablenetAdminConnection;
        this.xmlDiscoveryBaseJobVO = xmlDiscoveryBaseJobVO;
        this.addDeviceXmlDiscoveryUrl = addDeviceXmlDiscoveryUrl;
        this.jobResultListUrl = jobResultListUrl;
        this.jobresultdata = jobresultdata;
        this.deleteJobUrl = deleteJobUrl;
        this.deviceDiscoveryJobRepository = deviceDiscoveryJobRepository;
        this.modifyDeviceXmlDiscoveryUrl = modifyDeviceXmlDiscoveryUrl;
        this.jobIsRunningStatusUrl = jobIsRunningStatusUrl;
        this.jobStartUrl = jobStartUrl;
        this.snDiscoveryTimeoutMinutes = snDiscoveryTimeoutMinutes;
        this.delayTocheckJobStatusInSeconds = delayTocheckJobStatusInSeconds;
    }

    private String addDeviceXmlDiscoveryUrl;

    private String modifyDeviceXmlDiscoveryUrl;

    private String jobIsRunningStatusUrl;

    private String jobResultListUrl;

    private String jobresultdata;

    private String deleteJobUrl;

    private String jobStartUrl;

    private int snDiscoveryTimeoutMinutes;

    private int delayTocheckJobStatusInSeconds;

    public static final String SUCCESS = "SUCCESS";

    public static final String FAILED = "FAILED";

    public static final String NOT_FOUND = "not found";

    public static final String RUNNING = "running";

    public static final String IDLE = "idle";

    public static final String PROCESSING = "PROCESSING";

    private String discoveryJobId;

    private DeviceDiscoveryJobRepository deviceDiscoveryJobRepository;

    @Getter
    private StablenetAdminConnection stablenetConnection;

    @Getter
    public XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO;

    /**
     * Starts the discovery Job added or updated by object id
     *
     * @param id
     * @throws Exception
     */
    public void startJob(String id) throws Exception {
        if (!Strings.isNullOrEmpty(id)) {
            ResultVo resultVo = stablenetConnection.get(jobStartUrl, id).readEntity(ResultVo.class);
            if (resultVo.getState().equalsIgnoreCase(RestResultStateEnum.SUCCESS.value())) {
                checkForRunningStatusAndGetLatestObjId(id);
            }
        } else {
            log.error("Object Id not found in EVM.");
        }
    }

    /**
     * Checks the running status of the discovery job started
     *
     * @param objId
     * @throws Exception
     */
    private void isRunning(String objId) throws Exception {
        long startTime = System.currentTimeMillis();
        boolean isJobRunning = true;
        while (isJobRunning) {
            Result result = JAXB.unmarshal(new StringReader(stablenetConnection.get(jobIsRunningStatusUrl, objId).readEntity(String.class)), Result.class);
            if (result.getInfo() != null && result.getInfo().equals(NOT_FOUND)) {
                log.debug("Discovery Job not found or deleted from StableNet.");
                throw new ServerException("Discovery Job not found or deleted from StableNet.");
            } else if (result.getInfo() != null && result.getInfo().equals(RUNNING)) {
                log.debug("Device discovery job is still running, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                TimeUnit.SECONDS.sleep(delayTocheckJobStatusInSeconds);
            } else if (result.getInfo() != null && result.getInfo().equals(IDLE)) {
                log.debug("Device discovery job is still not started, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                break;
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((snDiscoveryTimeoutMinutes + 1) * 1000 * 60)) {
                log.error(String.format("StableNet job got timed out after {} minutes. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                throw new ServerException(String.format("StableNet job got timed out after {} minutes. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
            }
        }

    }

    /**
     * Gets the latest job id got by starting the discovery job
     *
     * @param obid
     * @throws Exception
     */
    private void checkForRunningStatusAndGetLatestObjId(String obid) throws Exception {
        isRunning(obid);
        List<JobResultVO> jobResultList = stablenetConnection.get(jobResultListUrl, obid).readEntity(new GenericType<List<JobResultVO>>() {
        });
        if (jobResultList == null || jobResultList.isEmpty()) {
            log.debug("Discovery Job object Id not found");
        } else {
            Optional<JobResultVO> jobResultVO = jobResultList.stream().findFirst();
            String resultJobObjId = jobResultVO.get().getObid();
            checkIfJobCompleted(resultJobObjId);
        }
    }

    /**
     * Gets the job analyzer response content by object id
     *
     * @param obid
     * @throws Exception
     */
    private void checkIfJobCompleted(String obid) throws Exception {
        boolean isJobRunning = true;
        long startTime = System.currentTimeMillis();
        while (isJobRunning) {
            String jobContent = stablenetConnection.getWithoutAcceptType(jobresultdata, obid).readEntity(String.class);
            if (jobContent == null || (jobContent != null && jobContent.equals("Job has not been finished yet!"))) {
                log.debug("Device discovery job is still running, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                TimeUnit.SECONDS.sleep(delayTocheckJobStatusInSeconds);
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime >= ((snDiscoveryTimeoutMinutes + 1) * 1000 * 60)) {
                    log.error(String.format("StableNet job got timed out after {} seconds. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                    throw new ServerException(String.format("StableNet job got timed out after {} seconds. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                } else {
                    continue;
                }
            } else if (jobContent != null && jobContent.contains("Devices failed SNMP discovery")) {
                log.error("Device discovery failed :\n.{}", jobContent);
                deleteFailedDiscoveryJob(discoveryJobId);
                saveDiscoveryJob(xmlDiscoveryBaseJobVO, jobContent);
                throw new ServerException(jobContent);
            } else if (jobContent != null && jobContent.contains("successfully discovered")) {
                log.debug("Device discovery job added and discovered successfully.");
                saveDiscoveryJob(xmlDiscoveryBaseJobVO, jobContent);
                break;
            } else {
                log.error("Device discovery failed :\n.{}", jobContent);
                deleteFailedDiscoveryJob(discoveryJobId);
                saveDiscoveryJob(xmlDiscoveryBaseJobVO, jobContent);
                throw new ServerException(jobContent);
            }
        }
    }

    /**
     * This method deletes the discovery job which couldn't get discovered.
     *
     * @param discoveryJobId
     */
    private void deleteFailedDiscoveryJob(String discoveryJobId) {
        try {
            Response response = stablenetConnection.delete(deleteJobUrl, "/" + discoveryJobId);
            if (response != null && response.getStatus() == HttpStatus.OK.value()) {
                log.debug("Removed failed discovery job with id {} from StableNet.", discoveryJobId);
            }
        } catch (Exception e) {
            log.error("Error while deleting discovery job with id {}.", discoveryJobId);
        }

    }

    @Override
    public Object call() throws Exception {
        StringBuilder responseAddDeviceJob = new StringBuilder();
        DeviceAdditionResponse deviceAdditionResponse = new DeviceAdditionResponse();
        deviceAdditionResponse.setDeviceIp(xmlDiscoveryBaseJobVO.getName());
        try {
            String xmlDiscoveryBaseJobVOString = ObjectToXmlString(XmlDiscoveryBaseJobVO.class, xmlDiscoveryBaseJobVO);
            JobBaseVO jobBaseVOresponse = null;
            if (xmlDiscoveryBaseJobVO.getObid() != null) {
                jobBaseVOresponse = JAXB.unmarshal(new StringReader(stablenetConnection.put(Entity.xml(xmlDiscoveryBaseJobVOString), modifyDeviceXmlDiscoveryUrl).readEntity(String.class)), JobBaseVO.class);
            } else {
                jobBaseVOresponse = JAXB.unmarshal(new StringReader(stablenetConnection.post(Entity.xml(xmlDiscoveryBaseJobVOString), addDeviceXmlDiscoveryUrl).readEntity(String.class)), JobBaseVO.class);
            }
            this.discoveryJobId = jobBaseVOresponse.getObid();
            xmlDiscoveryBaseJobVO.setObid(jobBaseVOresponse.getObid());
            saveDiscoveryJob(xmlDiscoveryBaseJobVO, PROCESSING);
            startJob(jobBaseVOresponse.getObid());
            responseAddDeviceJob.append("Device ").append(xmlDiscoveryBaseJobVO.getName()).append(" discovery job added successfully in StableNet.");
            log.debug("Device discovery job added successfully in StableNet.");
            deviceAdditionResponse.setStatus(SUCCESS);
        } catch (ServerException e) {
            deviceAdditionResponse.setStatus(FAILED);
            deviceAdditionResponse.setErrorMessage(e.getMessage());
        } catch (Exception e) {
            log.error("Add device : error occurred {}", e.getMessage());
            deviceAdditionResponse.setStatus(FAILED);
            deviceAdditionResponse.setErrorMessage(e.getMessage());
        }
        return deviceAdditionResponse;
    }

    /**
     * Saves discovery job in EVM after adding or updating the job in StableNet
     *
     * @param xmlDiscoveryBaseJobVO
     * @param content
     */
    private void saveDiscoveryJob(XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO, String content) {
        List<DeviceDiscoveryJob> deviceDiscoveryJobs = deviceDiscoveryJobRepository.findByIpAddress(xmlDiscoveryBaseJobVO.getName());
        if (deviceDiscoveryJobs != null && !deviceDiscoveryJobs.isEmpty()) {
            DeviceDiscoveryJob deviceDiscoveryJob = deviceDiscoveryJobs.get(0);
            if (!Strings.isNullOrEmpty(xmlDiscoveryBaseJobVO.getObid())) {
                deviceDiscoveryJob.setObjId(xmlDiscoveryBaseJobVO.getObid());
            }
            if(content != null && content.equals(PROCESSING)){
                deviceDiscoveryJobRepository.save(deviceDiscoveryJob);
                log.debug("Discovery job added in StableNet and discovery in progress.");
            }
            else if (content != null && content.contains("successfully discovered")) {
                deviceDiscoveryJob.setJob_status(DeviceDiscoveryJob.JOB_STATUS.SUCCESS);
                deviceDiscoveryJob.setResponse(content);
                deviceDiscoveryJob.setRunning(false);
                deviceDiscoveryJobRepository.save(deviceDiscoveryJob);
                log.debug("Device discovery job added successfully in Extreme Visibility Manager.");
            } else {
                deviceDiscoveryJob.setJob_status(DeviceDiscoveryJob.JOB_STATUS.FAILED);
                if (content != null) {
                    deviceDiscoveryJob.setResponse(content);
                }
                deviceDiscoveryJobRepository.delete(deviceDiscoveryJob.getId());
            }
        }

    }

    /**
     * Converts Java object to xml object
     *
     * @param klass
     * @param templateInput
     * @return xml object as String
     */
    private String ObjectToXmlString(Class<?> klass, Object templateInput) {
        StringWriter writer = new StringWriter();
        try {
            JAXBContext context = JAXBContext.newInstance(klass);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(templateInput, writer);
        } catch (PropertyException e) {
            log.error(e.getMessage());
        } catch (JAXBException e) {
            log.error(e.getMessage());
        }
        return writer.toString();
    }
}
