package com.brocade.bvm.api.factory;

import com.brocade.bvm.api.manager.*;
import com.brocade.bvm.api.manager.openflow.PolicyManagerOpenFlow;
import com.brocade.bvm.api.manager.openflow.PortGroupManagerOpenFlow;
import com.brocade.bvm.api.manager.openflow.PortManagerOpenFlow;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.ModulePolicy;
import com.brocade.bvm.model.db.TemplatePolicy;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Set;

@Slf4j
@Getter
@Named
public class OpenFlowFactory implements ManagerFactory {

    @Inject
    private PortManagerOpenFlow portManager;

    @Inject
    private PolicyManagerOpenFlow policyManager;

    @Inject
    private PortGroupManagerOpenFlow portGroupManager;

    public ModulePolicyManager getModulePolicyManager(ModulePolicyRequest request) {
        throw new UnsupportedOperationException("Module Policy not supported for OpenFlow!");
    }

    public ModulePolicyManager getModulePolicyManager(ModulePolicy modulePolicy) {
        throw new UnsupportedOperationException("Module Policy not supported for OpenFlow!");
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(Set<? extends DevicePolicy> devicePolicy) {
        throw new UnsupportedOperationException("Device Policy not supported for OpenFlow!");
    }

    @Override
    public DevicePolicyManager getDevicePolicyManager(DevicePolicy devicePolicy) {
        throw new UnsupportedOperationException("Device Policy not supported for OpenFlow!");
    }

    @Override
    public SdPolicyManager getSdPolicyManager(Set<? extends SdPolicy> Policy) {
        throw new UnsupportedOperationException("Session Director Policy not supported for OpenFlow!");
    }

    @Override
    public SdPolicyManager getSdPolicyManager(SdPolicy policy) {
        throw new UnsupportedOperationException("Session Director Policy not supported for OpenFlow!");
    }

    @Override
    public SdPortGroupManager getSdPortGroupManager() {
        throw new UnsupportedOperationException("Session Director Port not supported for OpenFlow!");
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(Set<? extends TemplatePolicy> templatePolicies) {
        throw new UnsupportedOperationException("This feature is not supported for OpenFlow!");
    }

    @Override
    public TemplatePolicyManager getTemplatePolicyManager(TemplatePolicy templatePolicy) {
        throw new UnsupportedOperationException("This feature is not supported for OpenFlow!");
    }
}
