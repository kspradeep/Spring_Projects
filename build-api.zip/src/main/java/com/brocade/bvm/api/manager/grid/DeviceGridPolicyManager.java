package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.api.manager.GridPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.*;
import com.brocade.bvm.model.db.history.GridPolicySetHistory;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DeviceGridPolicyManager implements GridPolicyManager {

    public static final String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(/([0-9]|1[0-9]|2[0-9]|3[0-2]))*$";
    public static final String MAC_ADDRESS_PATTERN = "^(([a-fA-F0-9]{2}-){5}[a-fA-F0-9]{2}|([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}|([0-9A-Fa-f]{4}\\.){2}[0-9A-Fa-f]{4})?$";

    private static final long MIN_OFFSET = -1;
    private static final long MAX_OFFSET = 124;
    private static final long MIN_SLX_9850_OFFSET = 0;
    private static final long MAX_SLX_9850_OFFSET = 63;

    private static final String MASK_HEX_PATTERN = "^([Ff0]{0,8})$";
    private static final String VALUE_HEX_PATTERN = "^([A-Fa-f0-9]{0,8})$";
    private static final String VALUE_DECIMAL_PATTERN = "^([\\d]+)$";

    private static final String IPV6_PATTERN1 = "^(((?=(?>.*?::)(?!.*::)))(::)?([0-9A-F]{1,4}::?){0,5}|([0-9A-F]{1,4}:){6})(\\2([0-9A-F]{1,4}(::?|$)){0,2}|((25[0-5]|(2[0-4]|1\\d|[1-9])?\\d)(\\.|$)){4}|[0-9A-F]{1,4}:[0-9A-F]{1,4})(?<![^:]:|\\.)\\z";
    private static final String IPV6_PATTERN2 = "^((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(/(([0-9])|([0-9]{2})|(1[0-1][0-9])|(12[0-8])))$";
    private static final String IPV6_PATTERN3 = "^(((?=(?>.*?::)(?!.*::)))(::)?([0-9A-F]{1,4}::?){0,5}|([0-9A-F]{1,4}:){6})(\\2([0-9A-F]{1,4}(::?|$)){0,2}|((25[0-5]|(2[0-4]|1[0-9]|[1-9])?[0-9])(\\.|$)){4}|[0-9A-F]{1,4}:[0-9A-F]{1,4})(?<![^:]:)(?<!\\.)\\z";
    private static final String IPV6_PATTERN4 = "^\\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?\\s*$";
    private static final String IPV6_PATTERN5 = "^(?:(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){6})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:::(?:(?:(?:[0-9a-fA-F]{1,4})):){5})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){4})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,1}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){3})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,2}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){2})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,3}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:[0-9a-fA-F]{1,4})):)(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,4}(?:(?:[0-9a-fA-F]{1,4})))?::)(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,5}(?:(?:[0-9a-fA-F]{1,4})))?::)(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,6}(?:(?:[0-9a-fA-F]{1,4})))?::))))$";

    private Pattern pattern1 = Pattern.compile(IPV6_PATTERN1);
    private Pattern pattern2 = Pattern.compile(IPV6_PATTERN2);
    private Pattern pattern3 = Pattern.compile(IPV6_PATTERN3);
    private Pattern pattern4 = Pattern.compile(IPV6_PATTERN4);
    private Pattern pattern5 = Pattern.compile(IPV6_PATTERN5);
    private Pattern slxPolicyNamePattern = Pattern.compile(Policy.SLX_POLICY_NAME_PATTERN);
    private Pattern slxRulesetNamePattern = Pattern.compile(RuleSet.SLX_RULESET_NAME_PATTERN);

    @Inject
    private GridPolicySetHelper gridPolicySetHelper;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private GridPolicySetHistoryRepository gridPolicySetHistoryRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private GridRepository gridRepository;

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridMatrixRepository gridMatrixRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private JobRepository jobRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private GridRuleSetRepository gridRuleSetRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    private BlockingQueue<Long> pathIdQueue = new LinkedBlockingQueue<>();

    /**
     * This method is used to save the grid policy set
     *
     * @param gridPolicySetToSave
     * @return Long This returns policySetId
     */
    public Long saveGridPolicy(GridPolicySet gridPolicySetToSave) throws ValidationException {
        // populate the policy set with db entities
        if (gridPolicySetToSave.getId() != null) {
            // get existing policy set and merge the policy set object
            GridPolicySet existingPolicy = gridPolicySetRepository.findOne(gridPolicySetToSave.getId());
            // merge policy set attributes
            if (existingPolicy != null) {
                if (WorkflowParticipant.WorkflowStatus.ERROR == existingPolicy.getWorkflowStatus()) {
                    throw new ValidationException("Cannot save policy as policy is in error state.");
                } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == existingPolicy.getWorkflowStatus()) {
                    throw new ValidationException("Cannot commit policy as another policy operation is in progress. Please try after sometime.");
                }
                isValidPolicySetToUpdate(gridPolicySetToSave, existingPolicy);
            } else {
                throw new ValidationException("policy.not.found");
            }

        } else {
            // validate the policy set
            isValidPolicySetToSave(gridPolicySetToSave);
        }

        gridPolicySetToSave.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        // save policy set in DB
        updateInterfaces(gridPolicySetToSave);
        DeviceGrid deviceGrid = gridRepository.findOne(gridPolicySetToSave.getDeviceGrid().getId());
        if (deviceGrid == null) {
            throw new ValidationException("Grid does not exist!");
        }
        gridPolicySetToSave.setDeviceGrid(deviceGrid);
        gridPolicySetToSave = gridPolicySetRepository.save(gridPolicySetToSave);
        return gridPolicySetToSave.getId();
    }

    /**
     * Updating the member ports in the cluster
     *
     * @param gridPolicySet
     */
    private void updateInterfaces(GridPolicySet gridPolicySet) {
        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
            List<Long> ingressNodeIds = gridPolicy.getIngressClusterNodeInterfaces().stream().map(ClusterNodeInterface::getId).collect(Collectors.toList());
            List<Long> egressNodeIds = gridPolicy.getEgressClusterNodeInterfaces().stream().map(ClusterNodeInterface::getId).collect(Collectors.toList());
            gridPolicy.setIngressClusterNodeInterfaces(Sets.newHashSet(clusterNodeInterfaceRepository.findAll(ingressNodeIds)));
            gridPolicy.setEgressClusterNodeInterfaces(Sets.newHashSet(clusterNodeInterfaceRepository.findAll(egressNodeIds)));
        });
        updateNullFieldsForPolicy(gridPolicySet);
    }

    /**
     * This method is used to commit the grid policy set
     *
     * @param gridPolicySet
     * @return Long This returns jobId
     */
    public Long commitGridPolicy(GridPolicySet gridPolicySet) throws ValidationException {
        boolean isNew = false;
        if (gridPolicySet.getId() == null) {
            isNew = true;
        }
        saveGridPolicy(gridPolicySet);
        GridPolicySet gridPolicySetHistory = null;
        if (!isNew) {
            gridPolicySetHistory = gridPolicySetHelper.getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
        }
        GridPolicySet gridPolicySetInDb = gridPolicySetRepository.findOne(gridPolicySet.getId());
        if (gridPolicySetInDb != null) {
            if (gridPolicySetHistory == null || WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySetHistory.getWorkflowStatus()) {
                gridPolicySetInDb.setWorkflowType(Job.Type.POLICY_CREATE);
            } else {
                gridPolicySetInDb.setWorkflowType(Job.Type.POLICY_UPDATE);
            }
            gridPolicySetInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
            gridPolicySetRepository.save(gridPolicySetInDb);
            if (gridPolicySetHistory == null || WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySetHistory.getWorkflowStatus()) {
                gridPolicySetHelper.commitGridPolicies(gridPolicySetInDb);
            } else {
                gridPolicySetHelper.updatePolicySet(gridPolicySetInDb, gridPolicySetHistory);
            }
            gridPolicySetInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
            gridPolicySetRepository.save(gridPolicySetInDb);
            return gridPolicySetInDb.getId();
        }
        throw new ValidationException("policy.not.found");
    }

    @PostConstruct
    void init() {
        //Start thread to consume submitted jobs
        ExecutorService jobConsumer = Executors.newSingleThreadExecutor();
        jobConsumer.execute(new PathIdConsumer());
        jobConsumer.shutdown();
    }

    /**
     * Update the failed path with new topology path
     *
     * @param pathId
     */
    public void updatePath(Long pathId) {
        if (pathId != null) {
            try {
                pathIdQueue.put(pathId);
            } catch (InterruptedException e) {
                log.error("Error while storing the failed network path ids.  {}", e.getMessage());
            }
        }
    }

    /**
     * The PathIdConsumer class implements the methods to take submitted path ids and process it
     */
    private class PathIdConsumer implements Runnable {

        /**
         * This method is used to take submitted path ids and process
         */
        @Override
        public void run() {
            while (true) {
                try {
                    Long pathId = pathIdQueue.take();
                    AtomicBoolean isReadyToUpdate = new AtomicBoolean(true);
                    Set<GridTopologyPath> gridTopologyPathsFailed = gridTopologyPathRepository.findAllByPathIdAndIsActive(pathId, false);
                    if (gridTopologyPathsFailed != null) {
                        for (GridTopologyPath gridTopologyPathFailed : gridTopologyPathsFailed) {
                            GridMatrix gridMatrix = gridMatrixRepository.findByTopologyPathId(gridTopologyPathFailed.getId());
                            if (gridMatrix != null) {
                                GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(gridMatrix.getGridPolicySetId());
                                if (gridPolicySet != null && WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
                                    TimeUnit.SECONDS.sleep(10);
                                    pathIdQueue.put(pathId);
                                    isReadyToUpdate = new AtomicBoolean(false);
                                }
                            }
                        }
                    }
                    if (isReadyToUpdate.get()) {
                        log.trace("Removing pathId from queue {}", pathId);
                        gridPolicySetHelper.updatePathFailedPolicy(pathId, true);
                    }
                } catch (Exception e) {
                    log.error("Failed to update the network path.  {}", e.getMessage());
                }
            }
        }
    }

    /**
     * Update the failed policy set with new topology path
     *
     * @param policySetId
     */
    public void updateFailedPoliciesManually(Long policySetId) {
        if (policySetId != null) {
            GridPolicySet gridPolicySetInDb = gridPolicySetRepository.findOne(policySetId);
            if (gridPolicySetInDb == null) {
                log.error("Invalid policy id {}.", policySetId);
                throw new ValidationException("Invalid policy id!.");
            }
            Set<Long> gridTopologyPathIds = gridTopologyPathRepository.findByPolicySetIdAndIsActive(policySetId, false);
            if (!gridTopologyPathIds.isEmpty()) {
                gridTopologyPathIds.forEach(gridTopologyPathId -> {
                    Set<GridTopologyPath> gridTopologyPathsFailed = gridTopologyPathRepository.findAllByPathIdAndPolicyIdAndIsActive(policySetId, gridTopologyPathId, true);
                    if (gridTopologyPathsFailed != null) {
                        gridTopologyPathsFailed.forEach(gridTopologyPathFailed -> {
                            gridTopologyPathFailed.setIsActive(false);
                            gridTopologyPathRepository.save(gridTopologyPathFailed);
                        });
                    }
                    gridPolicySetHelper.updatePathFailedPolicy(gridTopologyPathId, false);
                });
            } else {
                log.error("No network path found for the policy set {}.", policySetId);
                throw new ValidationException("No network path found for the policy set.");
            }
        }
    }

    /**
     * This method is used to recover grid policy set
     *
     * @param policySetId
     * @return Long This returns jobId
     */
    @Override
    public Long rollbackGridPolicy(Long policySetId) {
        GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
        if (gridPolicySet != null) {
            if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
                throw new ValidationException("Cannot recover policy as another policy operation is in progress. Please try after sometime.");
            }
            if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus()) {
                gridPolicySet.setWorkflowType(Job.Type.POLICY_ROLLBACK);
                gridPolicySetHelper.rollbackPolicySet(gridPolicySet);
                return gridPolicySet.getId();
            } else {
                throw new ValidationException("Cannot recover the policy as it is not in error state.");
            }
        }
        throw new ValidationException("policy.not.found");
    }

    /**
     * This method is used to recover grid policy set
     *
     * @param policySetId
     * @return Long This returns jobId
     */
    @Override
    public Long deleteGridPolicy(Long policySetId) throws ValidationException {
        GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
        if (gridPolicySet != null) {
            if (gridPolicySet.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                GridPolicySet policyFromHistory = gridPolicySetHelper.getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                if (policyFromHistory != null && policyFromHistory.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                    //restore the committed policy copy from history and set status to active
                    //ensure that the policy from history has the same id.
                    gridPolicySet.setDeviceGrid(policyFromHistory.getDeviceGrid());
                    gridPolicySet.setGridPolicies(policyFromHistory.getGridPolicies());
                    gridPolicySet.setName(policyFromHistory.getName());
                    gridPolicySet.setWorkflowStatus(policyFromHistory.getWorkflowStatus());
                    gridPolicySet.setFlexMatchProfiles(policyFromHistory.getFlexMatchProfiles());
                    updateInterfaces(gridPolicySet);
                    gridPolicySetRepository.save(gridPolicySet);
                    log.info("Policy moved to committed state", gridPolicySet.getId());
                    return -1l;
                } else {
                    gridPolicySetRepository.delete(gridPolicySet);
                    log.info("Policy {} is in Draft state, so nothing to do on device", gridPolicySet.getId());
                    return -1l;
                }
            } else if (gridPolicySet.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                // should not delete a policy if in Submitted state
                log.error("Cannot delete a policy {} which is in progress.", gridPolicySet.getId());
                throw new ValidationException("Cannot delete policy as another policy operation is in progress. Please try after sometime.");
            } else if (gridPolicySet.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                gridPolicySet.setWorkflowType(Job.Type.POLICY_DELETE);
                gridPolicySetHelper.deletePolicySet(gridPolicySet, true);
                return gridPolicySet.getId();
            } else if (gridPolicySet.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                //do recovery
                return rollbackGridPolicy(gridPolicySet.getId());
            }
        }
        throw new ValidationException("policy.not.found");
    }

    @Override
    public void abortGridPolicy(GridPolicySet gridPolicySet) {
        Set<GridMatrix> gridMatrices = gridMatrixRepository.findByPolicySetId(gridPolicySet.getId());
        gridMatrices.forEach(gridMatrix -> {
            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
            gridMatrixRepository.save(gridMatrix);

            List<Job> activePolicyJobs = jobRepository.findByParentObjectIdAndStatusIn(gridMatrix.getPolicyId(), Lists.newArrayList(Job.Status.CREATED));
            activePolicyJobs.forEach(job -> {
                job.setStatus(Job.Status.FAILED);
                job.setJobResult("Job aborted manually.");
            });
            List<Job> activeMatrixJobs = jobRepository.findByParentObjectIdAndStatusIn(gridMatrix.getId(), Lists.newArrayList(Job.Status.CREATED));
            activeMatrixJobs.forEach(job -> {
                job.setStatus(Job.Status.FAILED);
                job.setJobResult("Job aborted manually.");
            });
        });
        String gridName = gridRepository.findNameById(gridPolicySet.getDeviceGrid().getId());
        gridPolicySetHelper.updateEvent(gridPolicySet.getId(), gridPolicySet.getWorkflowType().toString(), gridName, Job.Status.FAILED.toString(), "Policy aborted manually.", Event.Severity.MAJOR);
        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
        gridPolicySetRepository.save(gridPolicySet);
    }


    /**
     * Validates the Policy set name
     *
     * @param name
     */
    protected void isPolicySetNameValid(String name) {
        if (Strings.isNullOrEmpty(name)) {
            log.error("Policy name cannot be empty.");
            throw new ValidationException("Policy name cannot be empty.");
        } else if (!(slxPolicyNamePattern.matcher(name).matches())) {
            log.error(Policy.SLX_POLICY_NAME_ERROR_MESSAGE);
            throw new ValidationException(Policy.SLX_POLICY_NAME_ERROR_MESSAGE);
        }
    }

    /**
     * This method validates if the grid policy set is valid to save in BVM
     *
     * @param gridPolicySet
     * @return boolean
     * @throws ValidationException
     */
    protected boolean isValidPolicySetToSave(GridPolicySet gridPolicySet) throws ValidationException {
        DecimalFormat df = new DecimalFormat("#");
        df.setRoundingMode(RoundingMode.CEILING);
        DeviceGrid deviceGrid;
        isPolicySetNameValid(gridPolicySet.getName());
        if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus()) {
            throw new ValidationException("Cannot save policy as policy is in error state.");
        } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
            throw new ValidationException("Cannot save policy as another policy operation is in progress. Please try after sometime.");
        } else {
            if (gridPolicySet.getDeviceGrid() == null) {
                throw new ValidationException("Grid not selected.");
            }
            deviceGrid = gridRepository.findOne(gridPolicySet.getDeviceGrid().getId());
            if (deviceGrid == null) {
                throw new ValidationException("Grid not selected.");
            } else if (WorkflowParticipant.WorkflowStatus.ERROR == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid is in error state. Please recover grid and try again.");
            } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid operation is in progress. Please try after sometime.");
            } else if (WorkflowParticipant.WorkflowStatus.DRAFT == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid is in draft state. Please commit grid and try again.");
            }
            deviceGrid.getSourceNodes().forEach(gridCluster -> {
                Device device = gridCluster.getDevice();
                if (deviceRepository.findIdByIdAndIsDeleted(device.getId(), true) != null) {
                    String message = "Aggregator device " + (device.getName() != null ? device.getName() : "") + " has been deleted from the inventory.";
                    throw new ValidationException(message);
                }
                if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(device.getId()) == null) {
                    String message = "Aggregator device " + (device.getName() != null ? device.getName() : "") + " is missing from inventory.";
                    throw new ValidationException(message);
                }
            });
            deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                Device device = gridCluster.getDevice();
                if (deviceRepository.findIdByIdAndIsDeleted(device.getId(), true) != null) {
                    String message = "Distributor device " + (device.getName() != null ? device.getName() : "") + " has been deleted from the inventory.";
                    throw new ValidationException(message);
                }
                if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(device.getId()) == null) {
                    String message = "Distributor device " + (device.getName() != null ? device.getName() : "") + " is missing from inventory.";
                    throw new ValidationException(message);
                }
            });
            isTagAndDeviceIdUnique(gridPolicySet, deviceGrid.getSourceNodes());
        }
        Set<GridRuleSet.Type> typeList = Sets.newHashSet();
        gridPolicySet.getGridPolicies().forEach(flow -> {
            typeList.addAll(flow.getRuleSets().stream().map(GridRuleSet::getType).collect(Collectors.toSet()));
        });
        isValidForUda(gridPolicySet);
        isValidVlanTagOrStrip(gridPolicySet);
        List<String> ruleSetNames = Lists.newArrayList();
        List<String> newRuleSetNames = Lists.newArrayList();
        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
            if (gridPolicy.getEgressClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Tool interface cannot not be empty.");
            } else if (gridPolicy.getIngressClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Tap interface cannot not be empty.");
            } else if (gridPolicy.getRuleSets().isEmpty()) {
                throw new ValidationException("Ruleset cannot not be empty.");
            }
            gridPolicy.getRuleSets().forEach(gridRuleSet -> {
                if (Strings.isNullOrEmpty(gridRuleSet.getName())) {
                    throw new ValidationException("Ruleset name cannot not be empty.");
                } else if (!slxRulesetNamePattern.matcher(gridRuleSet.getName()).matches()) {
                    log.error(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                    throw new ValidationException(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                }
                if (gridRuleSet.getRules().isEmpty()) {
                    throw new ValidationException("Rule(s) cannot not be empty.");
                }
                if (gridRuleSet.getId() == null) {
                    newRuleSetNames.add(gridRuleSet.getName());
                }
                ruleSetNames.add(gridRuleSet.getName());
            });
            if (gridPolicy.getVlanStripping() && (gridPolicy.getTaggedVlanId() != null && gridPolicy.getTaggedVlanId() > 0)) {
                log.error("VLAN Stripping and VLAN Tagging cannot co-exist.");
                throw new ValidationException("VLAN Stripping and VLAN Tagging cannot co-exist.");
            } else if (gridPolicy.getTaggedVlanId() != null && (gridPolicy.getTaggedVlanId() < 1 || gridPolicy.getTaggedVlanId() > 4090)) {
                log.error("Tagged VLAN Id should be in the range [1-4090].");
                throw new ValidationException("Tagged VLAN Id should be in the range [1-4090].");
            }
            AtomicLong atomicLong = new AtomicLong(0);
            gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                ClusterNodeInterface clusterNodeInterfaceDb = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
                clusterNodeInterfaceDb.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed()));
                clusterNodeInterfaceDb.getPortGroups().forEach(portGroup -> portGroup.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed())));
                Long bandwidth = Long.parseLong(df.format((atomicLong.get() / 1000)));
                if (bandwidth == 0) {
                    log.error("Bandwidth of ingress interface " + clusterNodeInterfaceDb.getName() + " should be greater than zero.");
                    throw new ValidationException("Bandwidth of ingress interface " + clusterNodeInterfaceDb.getName() + " should be greater than zero.");
                }
            });
        });
        List<String> uniqueRuleSetNames = ruleSetNames.stream().distinct().collect(Collectors.toList());
        //Check if the new Policy has unique Ruleset name across the flows
        if (!ruleSetNames.isEmpty() && ruleSetNames.size() != uniqueRuleSetNames.size()) {
            log.error("Policy set is having duplicate ruleset name.");
            throw new ValidationException("Policy set is having duplicate ruleset name.");
        }
        if (deviceGrid != null) {
            Long policySetId = gridPolicySet.getId();
            List<String> matchingRuleSetNames = Lists.newArrayList();
            if (!newRuleSetNames.isEmpty()) {
                if (policySetId != null) {
                    matchingRuleSetNames.addAll(gridRuleSetRepository.findByNameAndDeviceGridIdAndNotPolicySetId(newRuleSetNames, deviceGrid.getId(), policySetId));
                } else {
                    matchingRuleSetNames.addAll(gridRuleSetRepository.findByNameAndDeviceGridId(newRuleSetNames, deviceGrid.getId()));
                }
            }
            deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                Long deviceId = gridCluster.getDevice().getId();
                if (!newRuleSetNames.isEmpty()) {
                    if (matchingRuleSetNames != null && matchingRuleSetNames.isEmpty()) {
                        matchingRuleSetNames.addAll(ruleSetRepository.findNameByNameAndDeviceId(newRuleSetNames, deviceId));
                    }
                    if (matchingRuleSetNames != null && !matchingRuleSetNames.isEmpty()) {
                        log.error("Ruleset names " + String.join(",", matchingRuleSetNames) + " already mapped to other policy. Ruleset name must be unique.");
                        throw new ValidationException("Ruleset names " + String.join(",", matchingRuleSetNames) + " already mapped to other policy. Ruleset name must be unique.");
                    }
                }
            });
        }
        return true;
    }


    /**
     * This method validates if the grid policy set is valid to update in bvm
     *
     * @param gridPolicySet
     * @return boolean
     */
    protected boolean isValidPolicySetToUpdate(GridPolicySet gridPolicySet, GridPolicySet existingPolicy) throws ValidationException {
        DecimalFormat df = new DecimalFormat("#");
        df.setRoundingMode(RoundingMode.CEILING);
        DeviceGrid deviceGrid;
        if (Strings.isNullOrEmpty(gridPolicySet.getName())) {
            throw new ValidationException("Policy name cannot be empty.");
        } else if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus() ||
                WorkflowParticipant.WorkflowStatus.ERROR == existingPolicy.getWorkflowStatus()) {
            throw new ValidationException("Cannot save policy as policy is in error state.");
        } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus() ||
                WorkflowParticipant.WorkflowStatus.SUBMITTED == existingPolicy.getWorkflowStatus()) {
            throw new ValidationException("Cannot save policy as another policy operation is in progress. Please try after sometime.");
        } else {
            if (gridPolicySet.getDeviceGrid() == null) {
                throw new ValidationException("Grid not selected.");
            }
            deviceGrid = gridRepository.findOne(gridPolicySet.getDeviceGrid().getId());
            if (deviceGrid == null) {
                throw new ValidationException("Grid not selected.");
            } else if (WorkflowParticipant.WorkflowStatus.ERROR == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid is in error state. Please recover grid and try again.");
            } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid operation is in progress. Please try after sometime.");
            } else if (WorkflowParticipant.WorkflowStatus.DRAFT == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot save policy as grid is in draft state. Please commit grid and try again.");
            }
            deviceGrid.getSourceNodes().forEach(gridCluster -> {
                if (deviceRepository.findIdByIdAndIsDeleted(gridCluster.getDevice().getId(), true) != null) {
                    String message = "Aggregator device " + (gridCluster.getDevice().getName() != null ? gridCluster.getDevice().getName() : "") + " has been deleted from the inventory.";
                    throw new ValidationException(message);
                }
                if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(gridCluster.getDevice().getId()) == null) {
                    String message = "Aggregator device " + (gridCluster.getDevice().getName() != null ? gridCluster.getDevice().getName() : "") + " is missing from inventory.";
                    throw new ValidationException(message);
                }
            });
            deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                if (deviceRepository.findIdByIdAndIsDeleted(gridCluster.getDevice().getId(), true) != null) {
                    String message = "Distributor device " + (gridCluster.getDevice().getName() != null ? gridCluster.getDevice().getName() : "") + " has been deleted from the inventory.";
                    throw new ValidationException(message);
                }
                if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(gridCluster.getDevice().getId()) == null) {
                    String message = "Distributor device " + (gridCluster.getDevice().getName() != null ? gridCluster.getDevice().getName() : "") + " is missing from inventory.";
                    throw new ValidationException(message);
                }
            });
            GridPolicySet policyFromHistory = gridPolicySetHelper.getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            if (policyFromHistory != null) {
                if (policyFromHistory.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                    if (!gridPolicySet.getName().equals(existingPolicy.getName())) {
                        throw new ValidationException("Cannot modify the name for a committed policy.");
                    }
                    if (gridPolicySet.getIsOverSubscriptionAllowed() != existingPolicy.getIsOverSubscriptionAllowed()) {
                        throw new ValidationException("Cannot enable/disable oversubscription for a committed policy.");
                    }
                } else if (gridPolicySet.getWorkflowStatus() == null || WorkflowParticipant.WorkflowStatus.DRAFT == gridPolicySet.getWorkflowStatus()) {
                    validatePolicyNameOnSourceNodes(gridPolicySet.getName(), deviceGrid.getSourceNodes());
                }
            }
            if (policyFromHistory == null && (gridPolicySet.getWorkflowStatus() == null || WorkflowParticipant.WorkflowStatus.DRAFT == gridPolicySet.getWorkflowStatus())) {
                validatePolicyNameOnSourceNodes(gridPolicySet.getName(), deviceGrid.getSourceNodes());
            }
        }
        Set<Long> gridTopologyPathIds = gridTopologyPathRepository.findByPolicySetIdAndIsActive(gridPolicySet.getId(), false);
        if (!gridTopologyPathIds.isEmpty()) {
            throw new ValidationException("Cannot save policy as policy has network path(s) in failed state. Please click Cancel and click Try Me button to retry.");
        }
        isTagAndDeviceIdUniqueForUpdate(gridPolicySet);
        Set<GridRuleSet.Type> typeList = Sets.newHashSet();
        gridPolicySet.getGridPolicies().forEach(flow -> {
            typeList.addAll(flow.getRuleSets().stream().map(GridRuleSet::getType).collect(Collectors.toSet()));
        });
        isValidForUda(gridPolicySet);
        isValidVlanTagOrStrip(gridPolicySet);
        List<String> ruleSetNames = Lists.newArrayList();
        List<String> newRuleSetNames = Lists.newArrayList();
        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
            if (gridPolicy.getEgressClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Tool interface cannot not be empty.");
            } else if (gridPolicy.getIngressClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Tap interface cannot not be empty.");
            } else if (gridPolicy.getRuleSets().isEmpty()) {
                throw new ValidationException("Ruleset cannot not be empty.");
            }
            gridPolicy.getRuleSets().forEach(gridRuleSet -> {
                if (Strings.isNullOrEmpty(gridRuleSet.getName())) {
                    log.error("Ruleset name cannot be empty.");
                    throw new ValidationException("Ruleset name cannot be empty.");
                } else if (!slxRulesetNamePattern.matcher(gridRuleSet.getName()).matches()) {
                    //Check if all the Ruleset name adhere to the pattern as on device
                    log.error(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                    throw new ValidationException(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                }
                if (gridRuleSet.getRules().isEmpty()) {
                    throw new ValidationException("Rule(s) cannot not be empty.");
                }
                if (gridRuleSet.getId() == null) {
                    newRuleSetNames.add(gridRuleSet.getName());
                }
                ruleSetNames.add(gridRuleSet.getName());
            });
            if (gridPolicy.getVlanStripping() && (gridPolicy.getTaggedVlanId() != null && gridPolicy.getTaggedVlanId() > 0)) {
                log.error("VLAN Stripping and VLAN Tagging cannot co-exist.");
                throw new ValidationException("VLAN Stripping and VLAN Tagging cannot co-exist.");
            } else if (gridPolicy.getTaggedVlanId() != null && (gridPolicy.getTaggedVlanId() < 1 || gridPolicy.getTaggedVlanId() > 4090)) {
                log.error("Tagged VLAN Id should be in the range [1-4090].");
                throw new ValidationException("Tagged VLAN Id should be in the range [1-4090].");
            }
            AtomicLong atomicLong = new AtomicLong(0);
            gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                ClusterNodeInterface clusterNodeInterfaceDb = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
                clusterNodeInterfaceDb.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed()));
                clusterNodeInterfaceDb.getPortGroups().forEach(portGroup -> portGroup.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed())));
                Long bandwidth = Long.parseLong(df.format((atomicLong.get() / 1000)));
                if (bandwidth == 0) {
                    log.error("Bandwidth of ingress interface " + clusterNodeInterfaceDb.getName() + " should be greater than zero.");
                    throw new ValidationException("Bandwidth of ingress interface " + clusterNodeInterfaceDb.getName() + " should be greater than zero.");
                }
            });
        });
        List<String> uniqueRuleSetNames = ruleSetNames.stream().distinct().collect(Collectors.toList());
        //Check if the new Policy has unique Ruleset name across the flows
        if (!ruleSetNames.isEmpty() && ruleSetNames.size() != uniqueRuleSetNames.size()) {
            log.error("Policy set is having duplicate ruleset names.");
            throw new ValidationException("Policy set is having duplicate ruleset names.");
        }
        if (deviceGrid != null) {
            Long policySetId = gridPolicySet.getId();
            List<String> matchingRuleSetNames = Lists.newArrayList();
            if (!newRuleSetNames.isEmpty()) {
                if (policySetId != null) {
                    matchingRuleSetNames.addAll(gridRuleSetRepository.findByNameAndDeviceGridIdAndNotPolicySetId(newRuleSetNames, deviceGrid.getId(), policySetId));
                } else {
                    matchingRuleSetNames.addAll(gridRuleSetRepository.findByNameAndDeviceGridId(newRuleSetNames, deviceGrid.getId()));
                }
            }
            deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                Long deviceId = gridCluster.getDevice().getId();
                if (!newRuleSetNames.isEmpty()) {
                    if (matchingRuleSetNames != null && matchingRuleSetNames.isEmpty()) {
                        matchingRuleSetNames.addAll(ruleSetRepository.findNameByNameAndDeviceId(newRuleSetNames, deviceId));
                    }
                    if (matchingRuleSetNames != null && !matchingRuleSetNames.isEmpty()) {
                        log.error("Ruleset names " + String.join(",", matchingRuleSetNames) + " already mapped to other policy. Ruleset name must be unique.");
                        throw new ValidationException("Ruleset names " + String.join(",", matchingRuleSetNames) + " already mapped to other policy. Ruleset name must be unique.");
                    }
                }
            });
        }
        return true;
    }


    /**
     * This method validates if the given ip is a valid IPV4
     *
     * @param ip
     * @return boolean
     */
    private boolean validateIpv4(String ip) {
        if (ip != null) {
            if ("any".equalsIgnoreCase(ip)) {
                return true;
            } else {
                Pattern pattern = Pattern.compile(IPV4_PATTERN);
                return pattern.matcher(ip).matches();
            }
        }
        return true;
    }

    /**
     * This method validates if the given ip is a valid IPV6
     *
     * @param ip
     * @return boolean
     */
    protected boolean validateIpv6(String ip) {
        if (ip != null) {
            if ("any".equalsIgnoreCase(ip)) {
                return true;
            } else {
                return (pattern1.matcher(ip).matches() || pattern2.matcher(ip).matches() || pattern3.matcher(ip).matches() || pattern4.matcher(ip).matches() || pattern5.matcher(ip).matches());
            }
        }
        return true;
    }

    /**
     * This method validates if the given macAddress is a valid
     *
     * @param macAddress
     * @return boolean
     */
    private boolean validateMacAddress(String macAddress) {
        if (macAddress != null) {
            Pattern pattern = Pattern.compile(MAC_ADDRESS_PATTERN);
            return pattern.matcher(macAddress).matches();
        }
        return true;
    }

    /**
     * This method validates if rules in the policy contains valid IPV4 or IPV6
     *
     * @param policy
     * @return boolean
     */
    private boolean isRuleContainsValidIp(GridPolicySet policy) {
        for (GridPolicy eachFlow : policy.getGridPolicies()) {
            if (!validateMacAddress(eachFlow.getDestinationMacTag())) {
                throw new ValidationException("policy.save.invalidDestMac");
            }
            for (GridRule rule : getFlatRules(eachFlow.getRuleSets())) {
                String etherType = rule.getEthType();
                String srcIp = rule.getSourceIp();
                String destIP = rule.getDestinationIp();

                if (etherType != null && !(etherType.equalsIgnoreCase("any"))) {
                    if (etherType.equalsIgnoreCase(GridRuleSet.IpVersion.V4.toString())) {
                        if (!validateIpv4(srcIp) || !validateIpv4(destIP)) {
                            throw new ValidationException("policy.save.invalidipv4");
                        }
                    } else if (etherType.equalsIgnoreCase(GridRuleSet.IpVersion.V6.toString())) {
                        if (!validateIpv6(srcIp) || !validateIpv6(destIP)) {
                            throw new ValidationException("policy.save.invalidipv6");
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * This method collects all the rule objects from all the RuleSet objects
     *
     * @param ruleSetList
     * @return List<Rule>
     */
    private List<GridRule> getFlatRules(Set<GridRuleSet> ruleSetList) {
        // Creating duplicate list of Rule from Ruleset and updating the
        // ethernet type for any and null cases.
        List<GridRule> rules = new ArrayList<>();
        for (GridRuleSet ruleSet : ruleSetList) {
            Set<GridRule> ruleList = ruleSet.getRules();
            for (GridRule rule : ruleList) {
                GridRule ruleNew = new GridRule();
                ruleNew.setSourceIp(rule.getSourceIp());
                ruleNew.setDestinationIp(rule.getDestinationIp());
                ruleNew.setSequence(rule.getSequence());
                ruleNew.setVlanId(rule.getVlanId());
                if (ruleSet.getIpVersion() != null) {
                    ruleNew.setEthType(ruleSet.getIpVersion().toString());
                }
                rules.add(ruleNew);
            }
        }
        return rules;
    }

    private boolean isValidForUda(GridPolicySet gridPolicySet) {
        Set<GridRuleSet.Type> typeList = Sets.newHashSet();
        gridPolicySet.getGridPolicies().forEach(flow -> {
            typeList.addAll(flow.getRuleSets().stream().map(GridRuleSet::getType).collect(Collectors.toSet()));
        });
        if (!gridPolicySet.getFlexMatchProfiles().isEmpty() && !typeList.contains(GridRuleSet.Type.UDA)) {
            log.error("Cannot save FlexMatch policy {} as the RuleSet Type UDA does not exist in the policy.", gridPolicySet.getId());
            throw new ValidationException("Cannot save FlexMatch policy as the RuleSet Type UDA does not exist in the policy.");
        }
        if (typeList.contains(GridRuleSet.Type.UDA) && gridPolicySet.getId() != null) {
            GridPolicySet policyInDb = gridPolicySetRepository.findOne(gridPolicySet.getId());
            if (policyInDb != null && gridPolicySet.getFlexMatchProfiles() != null && policyInDb.getFlexMatchProfiles() != null &&
                    !gridPolicySet.getFlexMatchProfiles().isEmpty() && !policyInDb.getFlexMatchProfiles().isEmpty()) {
                if (gridPolicySet.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != policyInDb.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                    Set<GridRuleSet> ruleSets = Sets.newHashSet();
                    gridPolicySet.getGridPolicies().forEach(flow -> {
                        ruleSets.addAll(flow.getRuleSets().stream().filter(ruleSet -> ruleSet.getId() != null && ruleSet.getType() == GridRuleSet.Type.UDA).collect(Collectors.toList()));
                        if (!ruleSets.isEmpty()) {
                            log.error("Cannot update the Profile for an existing flow.");
                            throw new ValidationException("Cannot update the Profile for an existing UDA flow.");
                        }
                    });
                }
            }
            isOffsetValuesValid(gridPolicySet);
            isValidRulesForUda(gridPolicySet);
        }
        return true;
    }

    /**
     * This method validates if the policy rules are having valid data for UDA
     *
     * @param policy
     * @return boolean
     */
    private boolean isValidRulesForUda(GridPolicySet policy) {
        policy.getGridPolicies().forEach(flow -> {
            flow.getRuleSets().forEach(ruleSet -> {
                if (GridRuleSet.Type.UDA == ruleSet.getType()) {
                    ruleSet.getRules().forEach(rule -> {
                        if ((rule.getIsHexadecimalType1() && !isValidHexaValueAndMask(rule.getFieldValue1(), rule.getFieldmask1()))
                                || (rule.getIsHexadecimalType2() && !isValidHexaValueAndMask(rule.getFieldValue2(), rule.getFieldmask2()))
                                || (rule.getIsHexadecimalType3() && !isValidHexaValueAndMask(rule.getFieldValue3(), rule.getFieldmask3()))
                                || (rule.getIsHexadecimalType4() && !isValidHexaValueAndMask(rule.getFieldValue4(), rule.getFieldmask4()))) {
                            log.error("Can't save policy as the Rule Field Value and Mask are invalid");
                            throw new ValidationException("Cannot save policy as the values for Rule Field and Mask are invalid.");
                        }
                        if ((!rule.getIsHexadecimalType1() && !isValidValueAndMask(rule.getFieldValue1(), rule.getFieldmask1()))
                                || (!rule.getIsHexadecimalType2() && !isValidValueAndMask(rule.getFieldValue2(), rule.getFieldmask2()))
                                || (!rule.getIsHexadecimalType3() && !isValidValueAndMask(rule.getFieldValue3(), rule.getFieldmask3()))
                                || (!rule.getIsHexadecimalType4() && !isValidValueAndMask(rule.getFieldValue4(), rule.getFieldmask4()))) {
                            log.error("Can't save policy as the Rule Field Value and Mask are invalid");
                            throw new ValidationException("Cannot save policy as the values for Rule Field and Mask are invalid.");
                        }
                    });
                }
            });
        });
        return true;
    }

    /**
     * This method validates is the given value a valid decimal and hexadecimal value
     *
     * @param value
     * @param mask
     * @return boolean
     */
    protected boolean isValidValueAndMask(String value, String mask) {
        Pattern maskHexaPattern = Pattern.compile(MASK_HEX_PATTERN);
        Pattern valueDecimalPattern = Pattern.compile(VALUE_DECIMAL_PATTERN);
        if (!"any".equals(value)) {
            if ("any".equals(mask)) {
                return false;
            }
            Matcher maskMatcher = maskHexaPattern.matcher(mask);
            Matcher valueMatcher = valueDecimalPattern.matcher(value);
            return (maskMatcher.matches() && valueMatcher.matches());
        }
        return true;
    }

    /**
     * TThis method validates is the given value a valid hexadecimal value
     *
     * @param value
     * @param mask
     * @return boolean
     */
    protected boolean isValidHexaValueAndMask(String value, String mask) {
        Pattern maskPattern = Pattern.compile(MASK_HEX_PATTERN);
        Pattern valuePattern = Pattern.compile(VALUE_HEX_PATTERN);
        if (!"any".equals(value)) {
            if ("any".equals(mask)) {
                return false;
            }
            Matcher maskMatcher = maskPattern.matcher(mask);
            Matcher valueMatcher = valuePattern.matcher(value);
            return (maskMatcher.matches() && valueMatcher.matches());
        }
        return true;
    }

    /**
     * This method validates if all the Offset values of policy are valid
     *
     * @param policy
     * @return boolean
     */
    private boolean isOffsetValuesValid(GridPolicySet policy) {
        if (!isOffsetValid(policy.getFieldOffset1(), false)
                || !isOffsetValid(policy.getFieldOffset2(), false)
                || !isOffsetValid(policy.getFieldOffset3(), false)
                || !isOffsetValid(policy.getFieldOffset4(), false)) {
            log.error("Can't save policy as the Field Offset range is invalid");
            throw new ValidationException("FlexMatch profile field Offset range is invalid.");
        } else if ((policy.getFieldOffset1() != MIN_OFFSET && policy.getFieldOffset1() % 4 != 0)
                || (policy.getFieldOffset2() != MIN_OFFSET && policy.getFieldOffset2() % 4 != 0)) {
            log.error("Cannot save policy as the 1st/2nd Field Offset value of is not a multiple of 4.");
            throw new ValidationException("Cannot save policy as the 1st/2nd Field Offset value is not a multiple of 4.");
        }
        return true;
    }

    /**
     * This method validates if Offset is in between -1 and 116, where -1 implies for ignore
     *
     * @param fieldOffset
     * @return boolean
     */
    private boolean isOffsetValid(Long fieldOffset, boolean isSlx9850) {
        if (isSlx9850) {
            if ((fieldOffset < MIN_SLX_9850_OFFSET || fieldOffset > MAX_SLX_9850_OFFSET)) {
                return false;
            }
        } else {
            if ((fieldOffset < MIN_OFFSET || fieldOffset > MAX_OFFSET)) {
                return false;
            }
        }

        return true;
    }

    /**
     * This method checks if the name and deviceId given is used in any other policy on the device for create
     *
     * @param policyToSave
     * @throws ValidationException if name and deviceId is already used
     */
    protected void isTagAndDeviceIdUnique(GridPolicySet policyToSave, Set<GridCluster> sourceNodes) {
        String policyName = policyToSave.getName();
        List<GridPolicySet> policies = gridPolicySetRepository.findByNameAndDevice(policyName, policyToSave.getDeviceGrid().getId());
        if (!policies.isEmpty()) {
            throw new ValidationException("Policy name already exists.");
        }
        validatePolicyNameOnSourceNodes(policyName, sourceNodes);
        isPolicyNameUniqueforDraftPolicy(policyToSave);
    }

    /**
     * Validates, is the policy name is unique on all source nodes
     *
     * @param policyName
     * @param sourceNodes
     */
    private void validatePolicyNameOnSourceNodes(String policyName, Set<GridCluster> sourceNodes) {
        Set<String> deviceNamesHasPolicy = Sets.newHashSet();
        sourceNodes.forEach(gridCluster -> {
            String deviceName = policyRepository.findDeviceNamesByNameAndDeviceId(policyName, gridCluster.getDevice().getId());
            if (!Strings.isNullOrEmpty(deviceName)) {
                deviceNamesHasPolicy.add(deviceName);
            }
        });
        if (!deviceNamesHasPolicy.isEmpty()) {
            throw new ValidationException(String.format("Policy name already exists on %s.", deviceNamesHasPolicy.stream().collect(Collectors.joining(","))));
        }
    }

    protected void isTagAndDeviceIdUniqueForUpdate(GridPolicySet policyToSave) {
        List<GridPolicySet> policies = gridPolicySetRepository.findByNameAndDeviceForUpdate(policyToSave.getName(), policyToSave.getDeviceGrid().getId(), policyToSave.getId());
        if (!policies.isEmpty()) {
            throw new ValidationException("Policy name already exists.");
        }
        isPolicyNameUniqueforDraftPolicy(policyToSave);
    }

    /**
     * This method checks if the name given is used in any other DRAFT policy on the device
     *
     * @param policyToSave
     * @throws ValidationException if name and deviceId is already used
     */
    protected void isPolicyNameUniqueforDraftPolicy(GridPolicySet policyToSave) {
        Long policyId = 0L;
        if (policyToSave.getId() != null) {
            policyId = policyToSave.getId();
        }
        List<Long> draftPolicyIds = gridPolicySetRepository.findDraftPoliciesByDeviceId(policyToSave.getDeviceGrid().getId(), policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                GridPolicySetHistory activePolicyFromHistroy = gridPolicySetHistoryRepository.findCurrentActivePolicy(policyToSave.getDeviceGrid().getId(), draftPolicyId);
                if (activePolicyFromHistroy != null && activePolicyFromHistroy.getName().equalsIgnoreCase(policyToSave.getName())) {
                    throw new ValidationException("Policy name already exists.");
                }
            });
        }
    }

    /**
     * This method is used to set the default value for null fields
     *
     * @param gridPolicySet
     * @return ResponseEntity<Object> This returns policy
     */
    private GridPolicySet updateNullFieldsForPolicy(GridPolicySet gridPolicySet) {
        gridPolicySet.getGridPolicies().stream().forEach(gridPolicy -> {
            if (gridPolicy.getIsTagged() == null)
                gridPolicy.setIsTagged(false);
            if (gridPolicy.getIsDefaultRouteMapDrop() == null)
                gridPolicy.setIsDefaultRouteMapDrop(false);
            gridPolicy.getRuleSets().forEach(ruleSet -> {
                ruleSet.getRules().forEach(rule -> {
                    if (rule.getSourcePort() == null)
                        rule.setSourcePort(0);
                    if (rule.getDestinationPort() == null)
                        rule.setDestinationPort(0);
                    if (rule.getVlanId() == null)
                        rule.setVlanId(-1);
                    if (rule.getIsPermit() == null)
                        rule.setIsPermit(false);
                });
            });

        });
        return gridPolicySet;
    }

    /**
     * This method validates if the VLAN Strippping and Tagging doesn't co-exists in 9240 or 9140 SLX device
     *
     * @param policy
     * @return
     */
    private boolean isValidVlanTagOrStrip(GridPolicySet policy) {
        policy.getGridPolicies().forEach(flow -> {
            if (flow.getVlanStripping() && (flow.getTaggedVlanId() != null && flow.getTaggedVlanId() > 0)) {
                log.error("VLAN Stripping and VLAN Tagging cannot co-exist.");
                throw new ValidationException("VLAN Stripping and VLAN Tagging cannot co-exist.");
            } else if (flow.getTaggedVlanId() != null && (flow.getTaggedVlanId() < 1 || flow.getTaggedVlanId() > 4090)) {
                log.error("Tagged VLAN Id should be in the range [1-4090]");
                throw new ValidationException("Tagged VLAN Id should be in the range [1-4090]");
            }
        });
        return true;
    }
}