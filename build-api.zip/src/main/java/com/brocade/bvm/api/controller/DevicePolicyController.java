package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.DevicePolicyRequest;
import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.dao.DevicePolicyRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DevicePolicy;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.*;

/**
 * The DevicePolicyController class implements methods to perform CRUD operations related to SD device policy or MLXE device policy
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/device/{deviceid}/devicepolicy")
public class DevicePolicyController {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    public static final String CLEANUP = "cleanup";
    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private GenericHelper genericHelper;

    /**
     * This method is used to save device policy(DRAFT) in bvm db or create device policy on device based action param
     *
     * @param action
     * @param deviceId
     * @param devicePolicyRequest
     * @return ResponseEntity<Object>
     * @throws JsonProcessingException
     */
    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitDevicePolicies(@RequestParam(value = "action", required = false) String action, @PathVariable("deviceid") Long deviceId,
                                                             @RequestBody DevicePolicyRequest devicePolicyRequest) throws JsonProcessingException {
        log.info("Action on DevicePolicy to " + action);
        Device device = validateAndReturnDevice(deviceId);
        if (devicePolicyRequest == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (device != null) {
            List<Long> jobPolicyIds;
            if (device.getType() == Device.Type.SD) {
                throw new ValidationException("policy.action.invalid");
            } else {
                try {
                    DevicePolicy devicePolicy = null;
                    if (devicePolicyRequest.getMplsDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getMplsDevicePolicy();
                    } else if (devicePolicyRequest.getGtpDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getGtpDevicePolicy();
                    } else if (devicePolicyRequest.getReservedVlanDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getReservedVlanDevicePolicy();
                    } else if (devicePolicyRequest.getSlxPtpPolicy() != null) {
                        devicePolicy = devicePolicyRequest.getSlxPtpPolicy();
                    }
                    jobPolicyIds = managerBuilder.getOperationsFactory(device).getDevicePolicyManager(devicePolicy).saveOrCommitDevicePolicies(Sets.newHashSet(devicePolicy), device, action, null);
                } catch (UnsupportedOperationException e) {
                    log.error("Policy action {} is failed on device {} : {}", action, deviceId, e.getLocalizedMessage());
                    throw new ValidationException(e.getLocalizedMessage());
                }
            }
            if (jobPolicyIds.size() > 0) {
                return new ResponseEntity<>(jobPolicyIds, HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
    }

    /**
     * This method is used to fetch all device policies for the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Object> getDevicePoliciesByDeviceId(@PathVariable("deviceid") Long deviceId) {

        log.debug("********** Start: Get Device Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }

        Set<DevicePolicy> devicePolicies = devicePolicyRepository.findByDeviceId(deviceId);
        Map<String, Set<DevicePolicy>> policyMap = new HashMap<>();
        if (devicePolicies != null && devicePolicies.size() > 0) {
            policyMap.putAll(managerBuilder.getOperationsFactory(device)
                    .getDevicePolicyManager(devicePolicies)
                    .getDevicePolicies(devicePolicies));
        }

        if (policyMap != null && policyMap.size() > 0) {
            return new ResponseEntity<>(policyMap, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }
    }

    /**
     * This method is used to delete all device policies for the given policyId
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE)
    public ResponseEntity<Object> deleteAllDevicePolicies(@PathVariable("deviceid") Long deviceId) {

        log.debug("********** Start: Delete Device Policies **********");
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        List<Long> jobIds = new ArrayList<>();
        Set<DevicePolicy> devicePolicies = devicePolicyRepository.findByDeviceId(deviceId);
        if (devicePolicies != null) {
            devicePolicies.stream().forEach(devicePolicy -> {
                Long jobId = managerBuilder.getOperationsFactory(device)
                        .getDevicePolicyManager(devicePolicy)
                        .deletePolicy(devicePolicy.getId());
                jobIds.add(jobId);
            });
        }
        if (jobIds != null && jobIds.size() > 0) {
            return new ResponseEntity<>(jobIds, HttpStatus.OK);
        } else {
            throw new ValidationException("policy.get.notfound");
        }
    }

    /**
     * This method is used to delete device policy for the given policyId
     *
     * @param action
     * @param deviceId
     * @param policyId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{policyid}")
    public ResponseEntity<Object> deleteDevicePolicy(@RequestParam(value = "action", required = false) String action,
                                                     @PathVariable("deviceid") Long deviceId, @PathVariable("policyid") Long policyId) {
        log.debug("********** Start: Delete Device Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (policyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        Long jobId = null;
        DevicePolicy devicePolicy = devicePolicyRepository.findOne(policyId);
        if (devicePolicy != null) {
            try {
                if (CLEANUP.equalsIgnoreCase(action)) {
                    if (devicePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                        jobId = managerBuilder.getOperationsFactory(device)
                                .getDevicePolicyManager(devicePolicy)
                                .recoverPolicy(devicePolicy.getId());
                    } else {
                        throw new ValidationException("policy.action.invalid");
                    }
                } else {
                    jobId = managerBuilder.getOperationsFactory(device)
                            .getDevicePolicyManager(devicePolicy)
                            .deletePolicy(devicePolicy.getId());
                }
            } catch (UnsupportedOperationException e) {
                log.error("Policy action {} is failed on device {} : {}", action, deviceId, e.getLocalizedMessage());
                throw new ValidationException(e.getLocalizedMessage());
            }
        } else {
            throw new ValidationException("policy.get.notfound");
        }
        if (jobId != null) {
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        } else {
            throw new ValidationException("policy.get.notfound");
        }
    }

    /**
     * This method is used to update device policy as DRAFT in bvm db or update device policy on device based action param
     *
     * @param action
     * @param deviceId
     * @param devicePolicyRequest
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitDevicePolicies(@RequestParam(value = "action", required = false) String action,
                                                               @PathVariable("deviceid") Long deviceId, @RequestBody DevicePolicyRequest devicePolicyRequest) {
        log.debug("********** Start: Update Device Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (devicePolicyRequest == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        List<Long> jobPolicyIds;
        try {
            if (action == null || UPDATE.equalsIgnoreCase(action) || COMMIT.equalsIgnoreCase(action)) {
                if (device.getType() == Device.Type.SD) {
                    throw new ValidationException("policy.action.invalid");
                } else {
                    DevicePolicy devicePolicy = null;
                    if (devicePolicyRequest.getMplsDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getMplsDevicePolicy();
                    } else if (devicePolicyRequest.getGtpDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getGtpDevicePolicy();
                    } else if (devicePolicyRequest.getTunnelDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getTunnelDevicePolicy();
                    } else if (devicePolicyRequest.getReservedVlanDevicePolicy() != null) {
                        devicePolicy = devicePolicyRequest.getReservedVlanDevicePolicy();
                    } else if (devicePolicyRequest.getSlxPtpPolicy() != null) {
                        devicePolicy = devicePolicyRequest.getSlxPtpPolicy();
                    }
                    jobPolicyIds = managerBuilder.getOperationsFactory(device).getDevicePolicyManager(devicePolicy).saveOrCommitDevicePolicies(Sets.newHashSet(devicePolicy), device, UPDATE, null);
                    return new ResponseEntity<>(jobPolicyIds, HttpStatus.OK);
                }
            } else if (action.equalsIgnoreCase(CLEANUP)) {
                Set<DevicePolicy> devicePolicies = devicePolicyRepository.findByDeviceId(deviceId);
                if (devicePolicies == null || devicePolicies.size() == 0) {
                    throw new ValidationException("policy.get.notfound");
                }
                List<Long> jobIds = new ArrayList<>();
                devicePolicies.stream().forEach(devicePolicy -> {
                    if (devicePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                        long jobId = managerBuilder.getOperationsFactory(device)
                                .getDevicePolicyManager(devicePolicy)
                                .recoverPolicy(devicePolicy.getId());
                        jobIds.add(jobId);
                    }
                });
                return new ResponseEntity<>(jobIds, HttpStatus.OK);
            }
        } catch (UnsupportedOperationException e) {
            log.error("Policy action {} is failed on device {} : {}", action, deviceId, e.getLocalizedMessage());
            throw new ValidationException(e.getLocalizedMessage());
        }
        throw new ValidationException("policy.action.invalid");
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }
}
