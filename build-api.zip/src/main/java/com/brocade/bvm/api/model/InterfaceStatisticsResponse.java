package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Sets;
import lombok.Getter;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

@Getter
public class InterfaceStatisticsResponse {

    @JsonProperty
    private String ipAddress;

    @JsonProperty
    private String sysName;

    @JsonProperty
    private String profileType;

    @JsonProperty
    private String profileName;

    @JsonProperty
    private Instant timestamp;

    @JsonProperty
    private Set<Map<String, String>> counters = Sets.newHashSet();

}
