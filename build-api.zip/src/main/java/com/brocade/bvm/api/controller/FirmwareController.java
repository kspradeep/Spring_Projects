package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.FirmwareManager;
import com.brocade.bvm.api.model.*;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceFirmwareInfoRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.dao.FirmwareJobRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.model.db.FirmwareJob;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.model.firmware.FirmwareHistoryObject;
import com.brocade.bvm.outbound.firmware.job.util.SshConnection;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.sftp.RemoteResourceInfo;
import net.schmizz.sshj.sftp.SFTPClient;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class implements methods to perform firmware upgrade
 */
@RestController
@Slf4j
@RequestMapping(value = "/firmware", produces = "application/json")
public class FirmwareController {

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private DeviceRepository deviceRepository;

    @Value("${evm.server.software.slx.path}")
    private String evmServerSlxSoftwarePath;

    @Inject
    private FirmwareManager firmwareManager;

    @Inject
    private DeviceFirmwareInfoRepository deviceFirmwareInfoRepository;

    @Inject
    private FirmwareJobRepository firmwareJobRepository;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private ApplicationContext applicationContext;

    private static final String USERNAME = "HOST_USERNAME";
    private static final String PASSWORD = "HOST_PASSWORD";
    private static final String IP = "HOST_IP";

    /**
     * This method is used to fetch device, based on the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object> This returns device
     */
    @RequestMapping(value = "/device/{deviceId}/list")
    public ResponseEntity<Object> getFirmwares(@PathVariable("deviceId") Long deviceId) {
        log.info("********** Start: getFirmwares **********");
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        ApplicationConstant ipConstant = featureConstantsRepository.findByName(IP);
        ApplicationConstant usernameConstant = featureConstantsRepository.findByName(USERNAME);
        ApplicationConstant passwordConstant = featureConstantsRepository.findByName(PASSWORD);
        if (ipConstant == null || usernameConstant == null || passwordConstant == null) {
            throw new ValidationException("firmware.host.info.empty");
        }
        List<String> list = Lists.newArrayList();
        try {
            SshConnection sshConnection = applicationContext.getBean(SshConnection.class);
            sshConnection.connect(ipConstant.getValue(), usernameConstant.getValue(), passwordConstant.getConstantValue());
            SFTPClient sftpClient = sshConnection.getSftpClient();
            String firmwarePath = evmServerSlxSoftwarePath.endsWith("/") ? evmServerSlxSoftwarePath : (evmServerSlxSoftwarePath + "/");
            List<RemoteResourceInfo> sftpFiles = sftpClient.ls(firmwarePath);
            for (RemoteResourceInfo sftpFile : sftpFiles) {
                if (sftpFile.isDirectory() && sftpFile.getName().startsWith("slx")) {
                    list.add(sftpFile.getName());
                }
            }
        } catch (Exception e) {
            log.error("Failed to get Firmware version due to {}", e.getMessage());
            throw new ValidationException("Firmware file not found at host server.");
        }

        log.info("Firmware List: " + list);
        if (!list.isEmpty()) {
            Collections.sort(list);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("firmwareList", list);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * This method is used to fetch device firmware upgrade history from device, based on the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object> This returns device
     */
    @RequestMapping(value = "/device/{deviceId}/firmwarehistory")
    public ResponseEntity<Object> getFirmwareHistory(@PathVariable("deviceId") Long deviceId) {
        log.info("Start: getFirmwareHistory");
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (Device.Type.SLX != device.getType()) {
            throw new ValidationException("Feature not supported for non SLX device type.");
        }
        List<FirmwareHistoryObject> slxHistory = firmwareManager.getFirmwareHistory(device);
        log.info("End: getFirmwareHistory");
        return new ResponseEntity<>(slxHistory, HttpStatus.OK);
    }


    /**
     * This method is used to fetch device, based on the given deviceId
     *
     * @return ResponseEntity<Object> This returns device
     */
    @RequestMapping(value = "/devices/list")
    public ResponseEntity<Object> getAllDevicesFirmwareInfo() {
        log.info("********** Start: getAllDevicesFirmwareInfo **********");
        List<DeviceFirmwareInfo> deviceFirmwareInfos = deviceFirmwareInfoRepository.findByDeletedFalse();
        List<DeviceFirmwareSummary> deviceFirmwareSummaries = Lists.newArrayList();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (!deviceFirmwareInfos.isEmpty()) {
            deviceFirmwareInfos.forEach(deviceFirmwareInfo -> {
                List<FirmwareJob> firmwareJobs = firmwareJobRepository.findByTargetHostIdAndParentObjectId(deviceFirmwareInfo.getDevice().getId(), deviceFirmwareInfo.getId());
                if (!firmwareJobs.isEmpty()) {
                    FirmwareJob firmwareJob = firmwareJobs.get(0);
                    if (firmwareJob != null) {
                        DeviceFirmwareSummary deviceFirmwareSummary = new DeviceFirmwareSummary();
                        deviceFirmwareSummary.setId(deviceFirmwareInfo.getId());
                        deviceFirmwareSummary.setName(deviceFirmwareInfo.getDevice().getName());
                        deviceFirmwareSummary.setIpAddress(deviceFirmwareInfo.getDevice().getIpAddress());
                        deviceFirmwareSummary.setSoftwareVersion(deviceFirmwareInfo.getFirmwareName());
                        deviceFirmwareSummary.setUsername(deviceFirmwareInfo.getUsername());
                        deviceFirmwareSummary.setPassword(deviceFirmwareInfo.getPassword());
                        if (firmwareJob.getLastUpdatedTime() != null) {
                            Date myDate = Date.from(firmwareJob.getLastUpdatedTime());
                            String formattedDate = formatter.format(myDate);
                            deviceFirmwareSummary.setLastUpdatedTime(formattedDate);
                        }
                        deviceFirmwareSummary.setFirmwareJobId(firmwareJob.getId());
                        deviceFirmwareSummary.setWorkflowStatus(deviceFirmwareInfo.getWorkflowStatus().name());
                        deviceFirmwareSummary.setRebootRequired(deviceFirmwareInfo.getRebootRequired());
                        deviceFirmwareSummaries.add(deviceFirmwareSummary);
                    }
                }
            });
        }

        Map<String, Object> map = new HashMap<>();
        map.put("deviceFirmwareSummaries", deviceFirmwareSummaries);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * This method is used to update port group, on the given device for the given portgroupid
     *
     * @param deviceFirmwareInfoRequest
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/upgrade")
    public ResponseEntity<Object> upgradeFirmware(@RequestBody DeviceFirmwareInfoRequest deviceFirmwareInfoRequest) {
        log.info("********** Start: Upgrade Firmware **********");
        ApplicationConstant ipConstant = featureConstantsRepository.findByName(IP);
        ApplicationConstant usernameConstant = featureConstantsRepository.findByName(USERNAME);
        ApplicationConstant passwordConstant = featureConstantsRepository.findByName(PASSWORD);
        if (ipConstant == null || usernameConstant == null || passwordConstant == null) {
            throw new ValidationException("firmware.host.info.empty");
        }

        if (deviceFirmwareInfoRequest != null && deviceFirmwareInfoRequest.getDeviceFirmwareInfos() != null) {
            deviceFirmwareInfoRequest.getDeviceFirmwareInfos().forEach(deviceFirmwareInfo -> {
                if (deviceFirmwareInfo.getFirmwareName() == null || deviceFirmwareInfo.getFirmwareName().isEmpty()) {
                    throw new ValidationException("firmware.name.empty");
                }

                if (deviceFirmwareInfo.getUsername() == null || deviceFirmwareInfo.getUsername().isEmpty()) {
                    throw new ValidationException("device.user.empty");
                }

                if (deviceFirmwareInfo.getPassword() == null || deviceFirmwareInfo.getPassword().isEmpty()) {
                    throw new ValidationException("device.pass.empty");
                }

                if (deviceFirmwareInfo.getDevice().getId() < 1) {
                    throw new ValidationException("device.id.invalid");
                }
                if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceFirmwareInfo.getDevice().getId())) {
                    throw new ForbiddenException("rbac.device.notAuthorized");
                }
            });
            firmwareManager.upgradeFirmware(deviceFirmwareInfoRequest.getDeviceFirmwareInfos());
        } else if (deviceFirmwareInfoRequest != null && deviceFirmwareInfoRequest.getIds() != null) {
            firmwareManager.rebootUpgradedDevice(deviceFirmwareInfoRequest.getIds());
        } else {
            log.error("DeviceFirmwareInfo data is invalid");
            throw new ValidationException("firmware.info.invalid");
        }
        return getAllDevicesFirmwareInfo();
    }

    /**
     * This method is used to fetch error status for the given objectId
     *
     * @param objectId
     * @return
     */
    @RequestMapping(value = "/error/{objectid}")
    public ResponseEntity<Object> getObjectStatus(@PathVariable("objectid") Long objectId) {
        JSONObject jsonObject = new JSONObject();
        if (objectId != null) {
            String jobResult = firmwareJobRepository.getJobStatusByObjectId(objectId);
            try {
                jsonObject.put("jobresult", jobResult);
            } catch (JSONException e) {
                throw new ServerException(e);
            }
        }
        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to update port group, on the given device for the given portgroupid
     *
     * @param hostInfoRequest
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/save/host")
    public ResponseEntity<Object> saveOrUpdateHostCredentials(@RequestBody HostInfoRequest hostInfoRequest) {
        log.info("********** Start: saveOrUpdateHostCredentials **********");
        Long objId = 0l;
        if (hostInfoRequest != null) {
            if (hostInfoRequest.getHostIp() == null || hostInfoRequest.getHostIp().isEmpty()) {
                throw new ValidationException("host.ip.empty");
            }

            if (hostInfoRequest.getUsername() == null || hostInfoRequest.getUsername().isEmpty()) {
                throw new ValidationException("host.user.empty");
            }

            if (hostInfoRequest.getPassword() == null || hostInfoRequest.getPassword().isEmpty()) {
                throw new ValidationException("host.pass.empty");
            }
            objId = firmwareManager.saveHostInfo(hostInfoRequest);
        }
        return new ResponseEntity<>(objId, HttpStatus.OK);
    }

    /**
     * This method is used to fetch error status for the given objectId
     *
     * @return
     */
    @RequestMapping(value = "/get/host")
    public ResponseEntity<Object> getHostInfo() {
        ApplicationConstant usernameConstant = featureConstantsRepository.findByName(USERNAME);
        ApplicationConstant passwordConstant = featureConstantsRepository.findByName(PASSWORD);
        ApplicationConstant ipConstant = featureConstantsRepository.findByName(IP);
        HostInfoRequest hostInfoRequest = new HostInfoRequest();
        if (usernameConstant != null && passwordConstant != null && ipConstant != null) {
            hostInfoRequest.setUsername(usernameConstant.getConstantValue());
            hostInfoRequest.setPassword(passwordConstant.getConstantValue());
            hostInfoRequest.setHostIp(ipConstant.getConstantValue());
        }
        return new ResponseEntity<>(hostInfoRequest, HttpStatus.OK);
    }

    /**
     * This method is used to delete policy for the given policyId
     *
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/info/delete")
    public ResponseEntity<Object> deleteDeviceFirmwareInfo(@RequestBody DeviceFirmwareInfoRequest deviceFirmwareInfoRequest) {
        log.debug("********** Start: deleteDeviceFirmwareInfo **********");
        if (deviceFirmwareInfoRequest != null && deviceFirmwareInfoRequest.getIds() != null) {
            List<DeviceFirmwareInfo> deviceFirmwareInfos = (List<DeviceFirmwareInfo>) deviceFirmwareInfoRepository.findAll(deviceFirmwareInfoRequest.getIds());
            deviceFirmwareInfos.forEach(deviceFirmwareInfo -> deviceFirmwareInfo.setDeleted(true));
            deviceFirmwareInfoRepository.save(deviceFirmwareInfos);
        }
        return getAllDevicesFirmwareInfo();
    }

}
