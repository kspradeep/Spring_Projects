package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.controller.DevicePolicyController;
import com.brocade.bvm.api.controller.ManagerFactoryBuilder;
import com.brocade.bvm.api.controller.SdPolicyController;
import com.brocade.bvm.api.manager.SdPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.DeDupePolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The AbstractSDPolicyManager class implements methods to perform policy create/update/delete/recover on the selected SD device
 */
public abstract class AbstractSDPolicyManager implements SdPolicyManager {

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    /**
     * This method is used fetch map of SD policies based type of SD policy
     *
     * @param policies
     * @return
     */
    public Map<String, Set<SdPolicy>> getPolicies(Set<? extends SdPolicy> policies) {
        Map<String, Set<SdPolicy>> policyMap = new HashMap<>();
        policies.stream().forEach(policy -> {
            Set<SdPolicy> sdPolicies = new HashSet<>();
            if (policy instanceof FilterPolicy) {
                sdPolicies.add(policy);
                policyMap.put("sdFilterPolicies", sdPolicies);
            } else if (policy instanceof DeDupePolicy) {
                sdPolicies.add(policy);
                policyMap.put("sdDedupePolicies", sdPolicies);
            } else if (policy instanceof SamplingPolicy) {
                sdPolicies.add(policy);
                policyMap.put("sdSamplingPolicies", sdPolicies);
            }
        });
        return policyMap;
    }


    /**
     * This method is used to invoke COMMIT/UPDATE SD policy based on action
     *
     * @param policies
     * @param device
     * @param action
     * @param policyName
     * @return
     */
    public Long saveOrCommitPolicies(Set<? extends SdPolicy> policies, Device device, String action, String policyName) {
        Long jobPolicyId = 0l;
        for (SdPolicy policyToSave : policies) {
            jobPolicyId = saveOrCommitPolicy(policyToSave, device, policyName, action);
        }
        return jobPolicyId;
    }

    /**
     * This method is used to invoke SAVE/COMMIT SD policy methods based on action
     *
     * @param policyToSave
     * @param device
     * @param policyName
     * @param action
     * @return
     */
    private Long saveOrCommitPolicy(SdPolicy policyToSave, Device device, String policyName, String action) {
        long ids = 0;
        policyToSave.setDevice(device);

        validatePolicy(policyToSave);

        if (action == null || action.equalsIgnoreCase(SdPolicyController.SAVE) || action.equalsIgnoreCase(SdPolicyController.UPDATE)) {
            ids = savePolicy(policyToSave);
        } else if (action.equalsIgnoreCase(DevicePolicyController.COMMIT)) {
            ids = commitPolicy(policyToSave);
        } else {
            throw new ValidationException("policy.action.invalid");
        }
        return ids;
    }

    /**
     * This method validates if SD policy data is valid to commit on the given device
     *
     * @param policies
     * @param device
     * @param policyName
     * @param isUpdate
     */
    public void validatePolicies(Set<? extends SdPolicy> policies, Device device, String policyName, boolean isUpdate) {
        for (SdPolicy policy : policies) {
            policy.setName(policyName);
            policy.setDevice(device);
            isPolicyInputValid(policy, isUpdate);
        }
    }

    /**
     * This method validates if SD policy data is valid to commit on the given device
     *
     * @param sdPolicy
     */
    public void validatePolicy(SdPolicy sdPolicy) {
        if (sdPolicy instanceof FilterPolicy) {
            FilterPolicy filterPolicy = (FilterPolicy) sdPolicy;
            if (filterPolicy.getName() == null) {
                throw new ValidationException("policy.name.empty");
            }
            filterPolicy.getRules().forEach(rule -> {
                if (SdPolicyController.FORWARD.equalsIgnoreCase(rule.getAction()) && rule.getPortGroup() == null) {
                    throw new ValidationException("rule.forward.pg.empty");
                } /*else if (rule.getSamplingPolicy() != null && rule.getImsi() != null) {
                    throw new ValidationException("invalid.comination.sampling.imsi");
                }*/
            });
        }

    }


    @Override
    public Long recoverPolicy(Long policyId) {
        throw new UnsupportedOperationException("Recovery is not supported for SD!");
    }

    protected abstract Long commitPolicy(SdPolicy policy);

    protected abstract Long savePolicy(SdPolicy policy);

    protected abstract void isPolicyInputValid(SdPolicy policy, boolean isUpdate);
}
