package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class DeviceStatusResponse {

    @JsonProperty
    private String sysName;

    @JsonProperty
    private String deviceIPAddress;

    @JsonProperty
    private String chassisMacAddress;

    @JsonProperty
    private Integer state;

}
