package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Policy;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CopyPolicyRequest {

    private List<Device> devices;

    private Policy policy;

}
