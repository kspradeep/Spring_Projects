package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.Port;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Max;
import java.util.List;

@Getter
@Setter
public class PortParameters {
    private List<Long> portIds;
    private Port.Mode mode;
    private Port.AdminStatus status;
    private Port.Type type;
    private String description;
    private Long lineSpeed;
    private boolean loopbackEnabled;
}
