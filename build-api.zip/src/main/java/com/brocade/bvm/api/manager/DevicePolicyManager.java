package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DevicePolicy;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface DevicePolicyManager {

    /**
     * return saved/updated SdPolicy
     */
    List<Long> saveOrCommitDevicePolicies(Set<? extends DevicePolicy> devicePolicies, Device device, String action, String policyName);

    Map<String, Set<DevicePolicy>> getDevicePolicies(Set<? extends DevicePolicy> devicePolicies);

    Long deletePolicy(Long policyId);

    Long recoverPolicy(Long policyId);

    void validateDevicePolicies(Set<? extends DevicePolicy> devicePolicies, Device device, String policyName, boolean isUpdate);
}
