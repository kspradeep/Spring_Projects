package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.SamplingPolicyHistory;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Named(value = "SdSamplingPolicyManager")
public class SdSamplingPolicyManager extends AbstractSDPolicyManager {

    @Inject
    protected SamplingPolicyRepository sdSamplingPolicyRepository;

    @Inject
    protected ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    protected FilterPolicyRepository filterPolicyRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    protected JobQueue jobQueue;

    @Inject
    protected SamplingPolicyHistoryRepository samplingPolicyHistoryRepositiory;

    /**
     * This method is used to validate if the given SamplingPolicy is valid to commit on the device
     *
     * @param policyToSave
     * @return
     * @throws ValidationException
     */
    protected boolean isValidSamplingPolicyToCommit(SamplingPolicy policyToSave) {
        return true;
    }

    /**
     * This method checks if the SamplingPolicy name is already used by other SD policies for SAVE
     *
     * @param policyToUpdate
     * @throws ValidationException
     */
    protected void isValidSamplingPolicyToSave(SamplingPolicy policyToUpdate) {

        if (policyToUpdate.getName() == null) {
            throw new ValidationException("policy.save.invalidname");
        } else if (policyToUpdate.getName().length() > SamplingPolicy.SAMPLE_POLICY_NAME_MAX) {
            throw new ValidationException("policy.save.invalidname.max16char");
        }

        if (policyToUpdate != null && policyToUpdate.getName().equalsIgnoreCase(SamplingPolicy.RESERVE_NAME_SAMPLE)) {
            throw new ValidationException("policy.save.reserve.name.sample");
        }

        List<SamplingPolicy> samplingPolicies = sdSamplingPolicyRepository.findByNameAndDevice(policyToUpdate.getName(), policyToUpdate.getDevice().getId());
        if (!samplingPolicies.isEmpty()) {
            throw new ValidationException("policy.save.tagnotunique");
        }
    }


    /**
     * This method checks if the SamplingPolicy input data is valid
     *
     * @param policyToValidate
     * @param isUpdate
     * @throws ValidationException
     */
    public void isPolicyInputValid(SdPolicy policyToValidate, boolean isUpdate) {
        SamplingPolicy policy = (SamplingPolicy) policyToValidate;
        if (Strings.isNullOrEmpty(policy.getName())) {
            throw new ValidationException("policy.save.invalidname");
        } else {

        }
    }

    /**
     * This method is used to SAVE SamplingPolicy in BVM db as DRAFT
     *
     * @param policy
     * @return
     */
    @Override
    public Long savePolicy(SdPolicy policy) {
        SamplingPolicy policyToSave = (SamplingPolicy) policy;
        //reloading the device object to make it an attached entity.
        Device device = deviceRepository.findById(policyToSave.getDevice().getId());

        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(device.getId());
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(device.getId());
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", device.getId());
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", device.getId());
            throw new ValidationException("sd.profile.not.configured");
        }
        // populate the Policy with db entities
        if (policyToSave.getId() == null) {
            isValidSamplingPolicyToSave(policyToSave);
        } else {
            List<SamplingPolicyHistory> samplingPolicyHistoryList = samplingPolicyHistoryRepositiory.findByIdAndWorkflowStatus(policyToSave.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
            if (!samplingPolicyHistoryList.isEmpty()) {
                comparePolicy(policyToSave, samplingPolicyHistoryList.get(0).buildParent());
                if (!activeInterfaceRepository.findActiveInterfaceBasedOnSamplingPolicyId(policy.getId()).isEmpty() || !filterPolicyRepository.findFilterPolicyBasedOnSamplingPolicyId(policy.getId()).isEmpty()) {
                    if (!policyToSave.getAction().equals(samplingPolicyHistoryList.get(0).buildParent().getAction())) {
                        log.error("Policy is active action change is not allowed.");
                        throw new ValidationException("policy.active.not.allowed.action.change");
                    }
                }
            }
        }
        if (policyToSave.getRate() < SamplingPolicy.MIN_SAMPLE_RATE || policyToSave.getRate() > SamplingPolicy.MAX_SAMPLE_RATE) {
            throw new ValidationException("policy.save.invalidTimeout");
        }

        List<FilterPolicy> filterPolicies = filterPolicyRepository.findByNameAndDevice(policyToSave.getName(), policyToSave.getDevice().getId());
        if (!filterPolicies.isEmpty()) {
            throw new ValidationException("same.name.exists.in.filterPolicy");
        }

        List<SamplingPolicy> samplingPolicies = sdSamplingPolicyRepository.findAllByDeviceId(policyToSave.getDevice().getId());
        if (samplingPolicies != null && samplingPolicies.size() >= SamplingPolicy.MAX_SAMPLE_POLICY && policyToSave.getId() == null) {
            throw new ValidationException("samplingPolicy.max10.allowed");
        }

        policyToSave.setDevice(device);
        policyToSave.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        // save policy in DB
        sdSamplingPolicyRepository.save(policyToSave);
        return policyToSave.getId();
    }


    /**
     * This method is used to COMMIT SdFilterPolicy in the given SD device
     *
     * @param policyToCommit
     * @return
     * @throws ValidationException
     */
    @Override
    public Long commitPolicy(SdPolicy policyToCommit) {
        SamplingPolicy policy = (SamplingPolicy) policyToCommit;
        isValidSamplingPolicyToCommit(policy);
        isInProgress(policy, "policy.commit.inprogress");

        Device device = deviceRepository.findById(policy.getDevice().getId());
        policy.setDevice(device);

        boolean isNew = false;
        long jobId = -1;
        long policyId = -1;
        // check if policy exists
        if (policy.getId() == null) {
            policyId = savePolicy(policy);
            isNew = true;
        } else {
            policyId = policy.getId();
        }
        SamplingPolicy policyInDb = sdSamplingPolicyRepository.findOne(policyId);
        if (policyInDb != null) {

            Job.Type type = Job.Type.SD_SAMPLING_POLICY_CREATE;
            if (!isNew) {
                if (getPolicyFromHistory(policyInDb, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE)) != null && !WorkflowParticipant.WorkflowStatus.DRAFT.equals(policyInDb.getWorkflowStatus())) {
                    type = Job.Type.SD_SAMPLING_POLICY_UPDATE;
                }
                savePolicy(policy);
            }
            List<Long> impactedObjectIds = new ArrayList<>();
            impactedObjectIds.add(policyId);

            jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(policy.getDevice().getId())
                    .parentObjectId(policyId).impactedObjectIds(impactedObjectIds).build());
            return jobId;
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to DELETE SamplingPolicy in the given SD device
     *
     * @param policies
     * @return
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(List<? extends SdPolicy> policies) {
        if (!policies.isEmpty()) {
            List<Long> impactedObjectIds = new ArrayList<>();
            List<SamplingPolicy> samplingPolicies = new ArrayList<>();
            boolean isActivePolicy = false;
            for (SdPolicy sdPolicy : policies) {
                SamplingPolicy policy = sdSamplingPolicyRepository.findOne(sdPolicy.getId());
                if (policy != null) {
                    isInProgress(policy, "policy.delete.inprogress");
                    if (!activeInterfaceRepository.findActiveInterfaceBasedOnSamplingPolicyId(policy.getId()).isEmpty()) {
                        throw new ValidationException("policy.used.in.interface");
                    }
                    if (!filterPolicyRepository.findFilterPolicyBasedOnSamplingPolicyId(policy.getId()).isEmpty()) {
                        throw new ValidationException("policy.used.in.filterRule");
                    }
                    if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                        log.error("Policy {} in error state. Aborting operation", policy.getId());
                        throw new ValidationException("invalid.combination.mix.policy.status");
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                        sdSamplingPolicyRepository.delete(policy);
                        log.info("Policy {} in draft state nothing on device so deleting it from BVM", policy.getName());
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                        log.error("Cannot delete a Sampling Policy id {} which is in progress.", policy.getId());
                        throw new ValidationException("policy.delete.inprogress");
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                        policy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        samplingPolicies.add(policy);
                        impactedObjectIds.add(policy.getId());
                        isActivePolicy = true;
                    }
                }
            }
            if (!isActivePolicy) {
                return -1l;
            }

            sdSamplingPolicyRepository.save(samplingPolicies);
            Job.Type jobType = Job.Type.SD_SAMPLING_POLICY_DELETE;
            long jobId = jobQueue.submit(JobTemplate
                    .builder()
                    .type(jobType)
                    .deviceId(policies.get(0).getDevice().getId())
                    .impactedObjectIds(impactedObjectIds).build());
            return jobId;
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to recover SamplingPolicy which is in ERROR state
     *
     * @param policyId
     * @return
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        SamplingPolicy samplingPolicy = sdSamplingPolicyRepository.findOne(policyId);
        if (samplingPolicy == null) {
            throw new ValidationException("policy.get.notfound");
        }
        isInProgress(samplingPolicy, "policy.recovery.inprogress");
        samplingPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        sdSamplingPolicyRepository.save(samplingPolicy);

        List<Long> impactedObjectIds = new ArrayList<>();
        impactedObjectIds.add(samplingPolicy.getId());
        Job.Type jobType = Job.Type.SD_SAMPLING_POLICY_RECOVER;
        long jobId = jobQueue.submit(JobTemplate
                .builder()
                .type(jobType)
                .deviceId(samplingPolicy.getDevice().getId())
                .impactedObjectIds(impactedObjectIds)
                .parentObjectId(policyId).build());
        return jobId;
    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param policy
     * @param workflowStatus
     * @return
     */
    protected SamplingPolicy getPolicyFromHistory(SamplingPolicy policy, List<WorkflowParticipant.WorkflowStatus> workflowStatus) {
        SamplingPolicy policyFromHistory = null;
        // get the previous policy name from the history.
        List<SamplingPolicyHistory> policyHistoryList = samplingPolicyHistoryRepositiory.findByIdAndWorkflowStatus(policy.getId(),
                workflowStatus);
        if (!policyHistoryList.isEmpty()) {
            SamplingPolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a SamplingPolicyHistory entity with oldName {} and lasted SamplingPolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * This method is used to compare Old Policy with New Policy and throw error message if there is no change made
     *
     * @param newPolicy
     * @param oldPolicy
     */
    protected void comparePolicy(SamplingPolicy newPolicy, SamplingPolicy oldPolicy) {
        if (!newPolicy.getName().equals(oldPolicy.getName())) {
            throw new ValidationException("name.change.not.allowed");
        } else if (newPolicy.isPreserveCplane() == oldPolicy.isPreserveCplane() && newPolicy.getRate() == oldPolicy.getRate() && newPolicy.getLoadBalanceAlgo().getName().equalsIgnoreCase(oldPolicy.getLoadBalanceAlgo().getName()) && newPolicy.getAction().equalsIgnoreCase(oldPolicy.getAction())) {
            throw new ValidationException("data.unchanged");
        }
    }

    /**
     * This method is use to validate if some operation is in progress it will not allow to proceed further
     *
     * @param samplingPolicy
     * @param operation
     */
    protected void isInProgress(SamplingPolicy samplingPolicy, String operation) {
        List<SamplingPolicy> inProgressOrErrorPoliciesOnDevice = sdSamplingPolicyRepository
                .findByDeviceAndInWorkflowStatus(samplingPolicy.getDevice().getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
            throw new ValidationException(operation);
        }
    }

}
