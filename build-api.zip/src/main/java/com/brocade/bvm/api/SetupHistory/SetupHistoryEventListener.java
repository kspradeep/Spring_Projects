package com.brocade.bvm.api.SetupHistory;

import com.brocade.bvm.dao.SetupHistoryRepository;
import com.brocade.bvm.model.db.SetupHistory;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Component
@Slf4j
public class SetupHistoryEventListener {

    @Value("${evm.app.version}")
    private String evmApiVersion;

    @Value("${evm.app.deploy.type}")
    private String deployType;

    @Value("${evm.app.deploy.time}")
    private String dateTime;

    @Inject
    private SetupHistoryRepository setupHistoryRepository;

    @EventListener
    void onStartup(ApplicationReadyEvent event) {
        SetupHistory setupHistory = new SetupHistory();
        log.debug("Enter set up history ");
        try {
            List<SetupHistory> setupHistories = null;
            if (!Strings.isNullOrEmpty(evmApiVersion) && !Strings.isNullOrEmpty(deployType) && !Strings.isNullOrEmpty(dateTime)) {
                setupHistory.setVersion(evmApiVersion);
                setupHistory.setSetUpDateTime(dateTime);
                setupHistories = Lists.newArrayList(setupHistoryRepository.findAll());
                if (setupHistories != null && setupHistories.size() != 0) {
                    Optional<SetupHistory> setupHistoryByVersions = setupHistoryRepository.findByVersionAndAction(evmApiVersion, deployType).stream().filter(setupHistory2 -> setupHistory2.getVersion() != null && setupHistory2.getVersion().equals(evmApiVersion) && setupHistory2.getAction() != null && setupHistory2.getAction().equals(deployType)).findAny();
                    if (!setupHistoryByVersions.isPresent()) {
                        setupHistory.setAction(deployType);
                        setupHistoryRepository.save(setupHistory);
                    }
                } else {
                    setupHistory.setAction(deployType);
                    setupHistoryRepository.save(setupHistory);
                }
            }
        } catch (Exception e) {
            log.error("error in set up history {}", e.getMessage());
        }
    }
}
