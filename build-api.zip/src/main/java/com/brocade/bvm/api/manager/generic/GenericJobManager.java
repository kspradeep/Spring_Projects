package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.model.db.Job;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.util.concurrent.TimeUnit;

@Named
@Slf4j
public class GenericJobManager {

    @Value("${stablenet-response.timeout.minutes}")
    private Integer stablenetTimeoutMinutes;

    @Value("${job.poll.interval.seconds:3}")
    private Integer jobPollIntervalSeconds;

    @Inject
    private EntityManager entityManager;

    @Inject
    private JobRepository jobRepository;

    /**
     * This method is return the job status
     *
     * @param jobId
     * @return
     */
    public Job getJobStatus(Long jobId) {
        log.debug("Job Status polling for id ={}", jobId);
        long startTime = System.currentTimeMillis();
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }

            try {
                TimeUnit.SECONDS.sleep(jobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((stablenetTimeoutMinutes + 1) * 60 * 1000)) {
                log.warn("Job status polling timeout!");
                break;
            }
        }
        return null;
    }

    /**
     * Update target host information for some of the error cases.
     *
     * @param job
     * @return
     */
    public String updateErrorMessage(Job job) {
        String jobResult = job.getJobResult();
        if (jobResult != null && jobResult.contains("FATAL ERROR:")) {
            jobResult = jobResult + "<BR>Device : " + job.getDevice().getName();
        }
        return jobResult;
    }

}
