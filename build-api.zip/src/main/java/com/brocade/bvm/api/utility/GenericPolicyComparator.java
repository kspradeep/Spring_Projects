/*
 * $Id$ $Revision$
 * Copyright Brocade 2016
 */

package com.brocade.bvm.api.utility;

import com.brocade.bvm.model.db.*;

import javax.inject.Named;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The GenericPolicyComparator class implements methods to compare the updated policy with old policy in DB, to check if any changes are made to old policy
 */
@Named
public class GenericPolicyComparator implements Comparator<Policy> {

    /**
     * This method compares oldPolicy with updated policy
     *
     * @param oldPolicy
     * @param newPolicy
     * @return int returns 0 if equal and -1 if not equal
     */
    @Override
    public int compare(Policy oldPolicy, Policy newPolicy) {
        if (oldPolicy.getName() != null ? !oldPolicy.getName().equals(newPolicy.getName()) : newPolicy.getName() != null)
            return -1;
        if (oldPolicy.getFieldOffset1() != null ? !oldPolicy.getFieldOffset1().equals(newPolicy.getFieldOffset1()) : newPolicy.getFieldOffset1() != null)
            return -1;
        if (oldPolicy.getFieldOffset2() != null ? !oldPolicy.getFieldOffset2().equals(newPolicy.getFieldOffset2()) : newPolicy.getFieldOffset2() != null)
            return -1;
        if (oldPolicy.getFieldOffset3() != null ? !oldPolicy.getFieldOffset3().equals(newPolicy.getFieldOffset3()) : newPolicy.getFieldOffset3() != null)
            return -1;
        if (oldPolicy.getFieldOffset4() != null ? !oldPolicy.getFieldOffset4().equals(newPolicy.getFieldOffset4()) : newPolicy.getFieldOffset4() != null)
            return -1;
        if (oldPolicy.isLoopbackEnabled() != newPolicy.isLoopbackEnabled())
            return -1;
        if (oldPolicy.getGtpProfile() != null && newPolicy.getGtpProfile() == null)
            return -1;
        if (oldPolicy.getGtpProfile() == null && newPolicy.getGtpProfile() != null)
            return -1;
        if (oldPolicy.getGtpProfile() != null && newPolicy.getGtpProfile() != null && !oldPolicy.getGtpProfile().getId().equals(newPolicy.getGtpProfile().getId()))
            return -1;
        if (oldPolicy.isPreserveHeader() != newPolicy.isPreserveHeader())
            return -1;
        if (oldPolicy.isTimestamp() != newPolicy.isTimestamp())
            return -1;
        if (oldPolicy.isGtpHttpFiltered() != newPolicy.isGtpHttpFiltered())
            return -1;
        if (oldPolicy.isIngressValid() != newPolicy.isIngressValid())
            return -1;
        if (oldPolicy.getEgressAction() != null ? !oldPolicy.getEgressAction().equals(newPolicy.getEgressAction()) : newPolicy.getEgressAction() != null)
            return -1;
        if (oldPolicy.getFlexMatchProfiles() != null && newPolicy.getFlexMatchProfiles() != null) {
            if (oldPolicy.getFlexMatchProfiles().size() != newPolicy.getFlexMatchProfiles().size()) {
                return -1;
            } else if (oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() > 0 &&
                    oldPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != newPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                return -1;
            }
        }

        //Creating new rules even when sequence is spoiled
        List<Flow> oldFlowList = oldPolicy.getFlows().asList();
        List<Flow> newFlowList = newPolicy.getFlows().asList();
        int result = -1;
        if (oldFlowList.size() == newFlowList.size()) {
            for (int i = 0; i < newFlowList.size(); i++) {
                Flow newFlow = newFlowList.get(i);
                Flow oldFlow = oldFlowList.stream().filter(flow -> flow.getId().equals(newFlow.getId())).findFirst().orElse(null);
                if (oldFlow != null && newFlow != null) {
                    if (compare(newFlow, oldFlow)) {
                        result = 0;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            }
        }
        return result;
    }

    /**
     * This method compares newFlow with old flow
     *
     * @param newFlow
     * @param oldFlow
     * @return boolean
     */
    private boolean compare(Flow newFlow, Flow oldFlow) {
        if (!oldFlow.getTunnelPolicies().isEmpty() && newFlow.getTunnelPolicies().isEmpty())
            return false;
        if (oldFlow.getTunnelPolicies().isEmpty() && !newFlow.getTunnelPolicies().isEmpty())
            return false;
        if (!oldFlow.getTunnelPolicies().isEmpty() && !newFlow.getTunnelPolicies().isEmpty()) {
            List<Long> oldTunnelIds = oldFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());
            List<Long> newTunnelIds = newFlow.getTunnelPolicies().stream().map(TunnelDevicePolicy::getId).collect(Collectors.toList());
            if (newTunnelIds.size() != oldTunnelIds.size() || !newTunnelIds.containsAll(oldTunnelIds)) {
                return false;
            } else if (newTunnelIds.size() == oldTunnelIds.size()) {
                for (int i = 0; i < oldTunnelIds.size(); i++) {
                    if (oldTunnelIds.get(i) != newTunnelIds.get(i)) {
                        return false;
                    }
                }
            }
        }
        if (newFlow.getTvfDomain() != oldFlow.getTvfDomain())
            return false;
        if ((newFlow.getFlowName() != null && !newFlow.getFlowName().equals(oldFlow.getFlowName())) || (oldFlow.getFlowName() != null && newFlow.getFlowName() == null)) {
            return false;
        }
        if (newFlow.getIsDefaultRouteMapDrop() != oldFlow.getIsDefaultRouteMapDrop())
            return false;
        if (newFlow.getIsTagged() != oldFlow.getIsTagged())
            return false;
        if (newFlow.getVlanStripping() != oldFlow.getVlanStripping())
            return false;
        if (newFlow.getTaggedVlanId() != oldFlow.getTaggedVlanId())
            return false;
        if (newFlow.getSequence() != null ? !newFlow.getSequence().equals(oldFlow.getSequence()) : oldFlow.getSequence() != null)
            return false;
        if (newFlow.getSourceMacTag() != null ? !newFlow.getSourceMacTag().equals(oldFlow.getSourceMacTag()) : oldFlow.getSourceMacTag() != null)
            return false;
        if (newFlow.getDestinationMacTag() != null ? !newFlow.getDestinationMacTag().equals(oldFlow.getDestinationMacTag()) : oldFlow.getDestinationMacTag() != null)
            return false;
        if (newFlow.getVlans() != null ? !newFlow.getVlans().equals(oldFlow.getVlans()) : oldFlow.getVlans() != null)
            return false;
        if (newFlow.getRuleSets() != null && oldFlow.getRuleSets() != null && !compareRuleSets(newFlow.getRuleSets().asList(), oldFlow.getRuleSets().asList()))
            return false;
        if (newFlow.getIngressPorts() != null && oldFlow.getIngressPorts() != null && !comparePorts(newFlow.getIngressPorts().asList(), oldFlow.getIngressPorts().asList()))
            return false;
        if (newFlow.getIngressPortGroups() != null && oldFlow.getIngressPortGroups() != null && !comparePortGroups(newFlow.getIngressPortGroups().asList(), oldFlow.getIngressPortGroups().asList()))
            return false;
        if (newFlow.getEgressPorts() != null && oldFlow.getEgressPorts() != null && !comparePorts(newFlow.getEgressPorts().asList(), oldFlow.getEgressPorts().asList()))
            return false;
        if ((oldFlow.getPacketTruncationMapping() == null && newFlow.getPacketTruncationMapping() != null) || (oldFlow.getPacketTruncationMapping() != null && newFlow.getPacketTruncationMapping() == null))
            return false;
        if (oldFlow.getPacketTruncationMapping() != null && newFlow.getPacketTruncationMapping() != null && newFlow.getPacketTruncationMapping().getId() != null && !newFlow.getPacketTruncationMapping().getId().equals(oldFlow.getPacketTruncationMapping().getId()))
            return false;
        return (newFlow.getEgressPortGroups() != null && oldFlow.getEgressPortGroups() != null && comparePortGroups(newFlow.getEgressPortGroups().asList(), oldFlow.getEgressPortGroups().asList()));
    }

    /**
     * This method compares newPorts with oldPorts
     *
     * @param nPortList
     * @param oPortList
     * @return boolean
     */
    private boolean comparePorts(List<Port> nPortList, List<Port> oPortList) {
        boolean isEqual = true;
        if (nPortList.size() == oPortList.size()) {
            for (int ctr = 0; ctr < nPortList.size(); ctr++) {
                Port newPort = nPortList.get(ctr);
                Port oldPort = oPortList.stream().filter(port -> port.getId().equals(newPort.getId())).findFirst().orElse(null);
                if (oldPort != null) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        } else if (nPortList.size() != oPortList.size()) {
            isEqual = false;
        }
        return isEqual;
    }

    /**
     * This method compares newPortGroups with oldPortGroups
     *
     * @param nPortGroupListList
     * @param oPortGroupListList
     * @return boolean
     */
    private boolean comparePortGroups(List<PortGroup> nPortGroupListList, List<PortGroup> oPortGroupListList) {
        boolean isEqual = true;
        if (nPortGroupListList.size() == oPortGroupListList.size()) {
            for (int ctr = 0; ctr < nPortGroupListList.size(); ctr++) {
                PortGroup newPortGroup = nPortGroupListList.get(ctr);
                PortGroup oldPortGroup = oPortGroupListList.stream().filter(portGroup -> portGroup.getId().equals(newPortGroup.getId())).findFirst().orElse(null);
                if (oldPortGroup != null) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        } else if (nPortGroupListList.size() != oPortGroupListList.size()) {
            isEqual = false;
        }
        return isEqual;
    }

    /**
     * This method compares newRuleSets with oldRuleSets
     *
     * @param nRuleSetList
     * @param oRuleSetList
     * @return boolean
     */
    private boolean compareRuleSets(List<RuleSet> nRuleSetList, List<RuleSet> oRuleSetList) {
        boolean isEqual = false;
        if (nRuleSetList.size() == oRuleSetList.size()) {
            for (int ctr = 0; ctr < nRuleSetList.size(); ctr++) {
                if (compare(nRuleSetList.get(ctr), oRuleSetList.get(ctr))) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        }
        return isEqual;
    }

    /**
     * This method compares newRuleSet with oldRuleSet
     *
     * @param nRuleSet
     * @param oRuleSet
     * @return boolean
     */
    private boolean compare(RuleSet nRuleSet, RuleSet oRuleSet) {
        boolean isEqual = false;
        //Even change in name can spoil validation of object
        if ((nRuleSet.getType() == oRuleSet.getType()) && (nRuleSet.getIpVersion() == oRuleSet.getIpVersion()) && nRuleSet.getName() != null && nRuleSet.getName().equals(oRuleSet.getName())) {
            isEqual = compareRule(nRuleSet.getRules().asList(), oRuleSet.getRules().asList());
        }
        return isEqual;
    }


    /**
     * This method compares newRules with oldRules
     *
     * @param nRuleList
     * @param oRuleList
     * @return boolean
     */
    public boolean compareRule(List<Rule> nRuleList, List<Rule> oRuleList) {
        boolean isEqual = false;
        if (nRuleList.size() == oRuleList.size()) {
            for (int ctr = 0; ctr < nRuleList.size(); ctr++) {
                if (compare(nRuleList.get(ctr), oRuleList.get(ctr))) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        }
        return isEqual;
    }

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    private boolean compare(Rule rule, Rule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null)
            return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null)
            return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null)
            return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getIsCountEnabled() != nRule.getIsCountEnabled()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getProtocolType() != null ? !rule.getProtocolType().equals(nRule.getProtocolType()) : nRule.getProtocolType() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;
        if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
            return false;
        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getMatchPayloadLength() != nRule.getMatchPayloadLength())
            return false;
        if (rule.getIsHexadecimalType1() != nRule.getIsHexadecimalType1())
            return false;
        if (rule.getIsHexadecimalType2() != nRule.getIsHexadecimalType2())
            return false;
        if (rule.getIsHexadecimalType3() != nRule.getIsHexadecimalType3())
            return false;
        if (rule.getIsHexadecimalType4() != nRule.getIsHexadecimalType4())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }
}
