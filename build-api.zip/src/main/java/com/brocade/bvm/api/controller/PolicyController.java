package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.model.CopyPolicyRequest;
import com.brocade.bvm.api.model.CopyPolicyResponse;
import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.api.utility.GenericPolicyComparator;
import com.brocade.bvm.api.utility.PolicyControllerHelper;
import com.brocade.bvm.api.utility.PolicyValidator;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The PolicyController class implements methods to perform CRUD operations related to policy
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/policy")
public class PolicyController {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    public static final String CLEANUP = "cleanup";
    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";
    public static final String ROLLBACK = "rollback";
    public static final String ADD = "add";
    public static final String DELETE = "delete";

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private FlexMatchProfileRepository flexMatchProfileRepository;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private GenericPolicyComparator genericPolicyComparator;

    @Inject
    private PolicyControllerHelper policyControllerHelper;

    @Inject
    private GenericHelper genericHelper;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    /**
     * This method is used to save policy(DRAFT) in bvm db or create policy on device based action param
     *
     * @param action
     * @param policy
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitPolicy(@RequestParam(value = "action", required = false) String action,
                                                     @RequestBody Policy policy) throws JsonProcessingException {
        if (policy == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (policy.getDevice() == null) {
            throw new ValidationException("policy.get.invaliddevice");
        }
        Device device = validateAndReturnDevice(policy.getDevice().getId());
        log.info("Action on rule set to " + action);
        Map<String, StringBuilder> validationMap = PolicyValidator.isValidPolicy(policy, device.getMode(), device.getType());
        if (device != null && validationMap != null && !validationMap.isEmpty()) {
            StringBuilder validationErrors = validationMap.get(PolicyValidator.ERROR_KEY);
            StringBuilder validationWarnings = validationMap.get(PolicyValidator.WARNING_KEY);
            if (validationErrors != null && validationErrors.length() != 0 || validationWarnings != null && validationWarnings.length() != 0) {
                StringBuilder messageBuilder = new StringBuilder();
                if (validationErrors != null && validationErrors.length() != 0 && validationWarnings != null && validationWarnings.length() != 0) {
                    messageBuilder.append("The policy has errors and warnings.");
                    messageBuilder.append(validationErrors.toString().replaceAll("<br>", "\\$"));
                    messageBuilder.append(validationWarnings.toString().replaceAll("<br>", "\\$"));
                } else {
                    if (validationErrors != null && validationErrors.length() != 0) {
                        messageBuilder.append("The policy has errors.$").append(validationErrors.toString().replaceAll("<br>", "\\$"));
                    }
                    if (validationWarnings != null && validationWarnings.length() != 0) {
                        messageBuilder.append("The policy has warnings.$").append(validationWarnings.toString().replaceAll("<br>", "\\$"));
                    }
                }
                throw new ValidationException(messageBuilder.toString());
            }
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(policy.getDevice().getId())) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }

        if (device != null) {
            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isVlansInPolicyAuthorized(policy)) {
                throw new ForbiddenException("rbac.vlan.notAuthorized");
            }

            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isSourceMacTagInPolicyAuthorized(policy)) {
                throw new ForbiddenException("rbac.smac.notAuthorized");
            }
            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isDestinationMacTagInPolicyAuthorized(policy)) {
                throw new ForbiddenException("rbac.dmac.notAuthorized");
            }

            //required for copy policy
            flushIdsForPolicy(policy);
            policy = updateNullFieldsForPolicy(policy, device.getMode());
            Set<FlexMatchProfile> profiles = new HashSet<>();
            if (policy.getFlexMatchProfiles() != null && !policy.getFlexMatchProfiles().isEmpty()) {
                policy.getFlexMatchProfiles().forEach(profile -> {
                    FlexMatchProfile flexMatchProfile = flexMatchProfileRepository.findOne(profile.getId());
                    if (flexMatchProfile != null) {
                        profiles.add(flexMatchProfile);
                    } else {
                        throw new ValidationException("profile.id.invalid");
                    }
                });
                policy.setFlexMatchProfiles(profiles);
            }
            if (action == null || action.equalsIgnoreCase(SAVE)) {
                Long policyId = managerBuilder.getOperationsFactory(device).getPolicyManager().savePolicy(policy, true);
                return new ResponseEntity<>(policyId, HttpStatus.OK);
            } else if (action.equalsIgnoreCase(COMMIT)) {
                Long jobId = managerBuilder.getOperationsFactory(device).getPolicyManager().commitPolicy(policy, true);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            } else {
                throw new ValidationException("policy.action.invalid");
            }
        } else {
            throw new ValidationException("device.id.invalid");
        }
    }

    /**
     * This method is used to fetch policy for the given policyId
     *
     * @param policyId
     * @return ResponseEntity<Object> This returns policy
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{policyid}")
    public ResponseEntity<Object> getPolicy(@PathVariable("policyid") Long policyId) {

        log.debug("********** Start: Get policy set **********");
        if (policyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        Policy policy = policyRepository.findOne(policyId);
        if (policy != null) {
            if (policy.getDevice() == null) {
                throw new ValidationException("policy.get.invaliddevice");
            }
            Long deviceId = policy.getDevice().getId();
            validateAndReturnDevice(deviceId);
            if (!authorityProvider.getAuthorizedDeviceIds().contains(policy.getDevice().getId())) {
                throw new ForbiddenException("rbac.device.notAuthorized");
            }
            Set<Policy> policies = new HashSet<>();
            policies.add(policy);
            if (authorityProvider.applyRBACOnPolicies(policies, policy.getDevice().getId()).isEmpty()) {
                throw new ValidationException("rbac.policy.notAuthorized");
            }
            return new ResponseEntity<>(policy, HttpStatus.OK);
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to fetch policies for the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object> This returns list policies
     */
    @RequestMapping(method = RequestMethod.GET, params = "deviceid")
    public ResponseEntity<Object> getPoliciesByDeviceId(@RequestParam("deviceid") Long deviceId, @RequestParam(value = "createdFromSd", required = false) String createdFromSd) {

        log.debug("********** Start: Fetch deployed policies on the device id :: " + deviceId);
        validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        boolean isCreatedFromSd = false;
        if (!StringUtils.isEmpty(createdFromSd) && "true".equals(createdFromSd)) {
            isCreatedFromSd = true;
        }
        Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(deviceId, isCreatedFromSd));
        policies = authorityProvider.applyRBACOnPolicies(policies, deviceId);

        if (policies != null && policies.size() > 0) {
            log.debug("{} policies found for the device with id {}", policies.size(), deviceId);
            return new ResponseEntity<>(policies, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }
    }

    /**
     * This method is used to fetch all the rulesets for a given device id
     *
     * @param deviceId
     * @return ResponseEntity<Object> This returns rulesets
     */
    @RequestMapping(method = RequestMethod.GET, value = "rulesets/{deviceid}")
    public ResponseEntity<Object> getRulesets(@PathVariable("deviceid") Long deviceId) {
        log.debug("********** Start: Get rulesets **********");
        validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        Set<RuleSet> allRuleSets = ruleSetRepository.findByDeviceIdAndPolicyNotCreatedBySD(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.WARNING));
        Set<RuleSet> allActiveRulesets = new HashSet<>();

        allRuleSets.forEach(ruleSet -> {
            RuleSet inactiveRuleset = allRuleSets.stream().filter(ruleSet1 -> ruleSet.getName().equals(ruleSet1.getName()) && ruleSet1.getIsInactive()).findAny().orElse(null);
            if (!ruleSet.getIsInactive() && inactiveRuleset == null) {
                allActiveRulesets.add(ruleSet);
            }
        });
        allActiveRulesets.stream().forEach(ruleSet -> {
            ruleSet.getRules().stream().forEach(rule -> {
                rule.clearId();
            });
            ruleSet.clearId();
        });
        if (allActiveRulesets != null && !allActiveRulesets.isEmpty()) {
            log.debug("{} rulesets found for the device with id {}", allRuleSets.size(), deviceId);
            String json = "[]";
            try {
                ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                json = ow.writeValueAsString(allActiveRulesets);
            } catch (IOException e) {
                log.error(e.getMessage());
            }
            return new ResponseEntity<>(json, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }
    }

    /**
     * This method is used to delete policy for the given policyId
     *
     * @param policyId
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{policyid}")
    public ResponseEntity<Object> deletePolicy(@PathVariable("policyid") Long policyId) {

        log.debug("********** Start: Delete policy set **********");
        if (policyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        Policy policy = policyRepository.findOne(policyId);
        if (policy != null) {
            validateAndReturnDevice(policy.getDevice().getId());
            if (!authorityProvider.getAuthorizedDeviceIds().contains(policy.getDevice().getId())) {
                throw new ForbiddenException("rbac.device.notAuthorized");
            }
            if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                throw new ValidationException("policy.action.invalid");
            }
            Set<Policy> policies = new HashSet<>();
            policies.add(policy);
            if (authorityProvider.applyRBACOnPolicies(policies, policy.getDevice().getId()).isEmpty()) {
                throw new ValidationException("rbac.policy.notAuthorized");
            }
            Long jobId = managerBuilder.getOperationsFactory(policy.getDevice()).getPolicyManager()
                    .deletePolicy(policyId, false, true);
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        } else {
            throw new ValidationException("policy.get.notfound");
        }
    }

    /**
     * This method is used to update policy as DRAFT in bvm db or update policy on device based action param
     *
     * @param action
     * @param policyId
     * @param policy
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{policyid}", consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitPolicy(@RequestParam(value = "action", required = false) String action,
                                                       @PathVariable(value = "policyid") Long policyId, @RequestBody Policy policy) {
        log.debug("********** Start: update policy set **********");
        if (policyId == null || (!CLEANUP.equalsIgnoreCase(action) && !ROLLBACK.equalsIgnoreCase(action) && policy != null && (policy.getId() == null || policyId.longValue() != policy.getId().longValue()))) {
            throw new ValidationException("policy.id.invalid");
        }
        Policy policyFromDb = policyRepository.findOne(policyId);
        if (policyFromDb == null || policy == null) {
            throw new ValidationException("policy.get.notfound");
        }
        if (policyFromDb.getDevice() == null) {
            throw new ValidationException("policy.get.invaliddevice");
        }
        if (!CLEANUP.equalsIgnoreCase(action) && !ROLLBACK.equalsIgnoreCase(action) && (policy.getDevice() == null || policy.getDevice().getId() == null)) {
            throw new ValidationException("policy.get.invaliddevice");
        }
        if (WorkflowParticipant.WorkflowStatus.ERROR == policyFromDb.getWorkflowStatus() && UPDATE.equalsIgnoreCase(action)) {
            throw new ValidationException("Cannot save policy as policy is in error state.");
        }
        Device device = validateAndReturnDevice(policyFromDb.getDevice().getId());

        if (!authorityProvider.getAuthorizedDeviceIds().contains(device.getId())) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }

        if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isVlansInPolicyAuthorized(policy)) {
            throw new ForbiddenException("rbac.vlan.notAuthorized");
        }

        if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isSourceMacTagInPolicyAuthorized(policy)) {
            throw new ForbiddenException("rbac.smac.notAuthorized");
        }

        if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isDestinationMacTagInPolicyAuthorized(policy)) {
            throw new ForbiddenException("rbac.dmac.notAuthorized");
        }

        if (action != null && (ADD.equalsIgnoreCase(action) || DELETE.equalsIgnoreCase(action))) {
            policy = policyControllerHelper.updatePortPortGroupRuleInPolicy(policy, policyFromDb, action);
        }

        Map<String, StringBuilder> validationMap = PolicyValidator.isValidPolicy(policy, device.getMode(), device.getType());
        if (WorkflowParticipant.WorkflowStatus.ERROR == policyFromDb.getWorkflowStatus() && COMMIT.equalsIgnoreCase(action)) {
            if (policyFromDb.isLegacy()) {
                List<PolicyHistory> policyHistorySubmitted = policyHistoryRepository.findByIdAndWorkflowStatusses(policyFromDb.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
                if (policyHistorySubmitted != null && !policyHistorySubmitted.isEmpty()) {
                    throw new ValidationException("Recover the policy to continue, as further modification of the policy in error state is not allowed.");
                }
            } else {
                throw new ValidationException("Recover the policy to continue, as further modification of the policy in error state is not allowed.");
            }
        }
        if (device != null && !CLEANUP.equalsIgnoreCase(action) && !ROLLBACK.equalsIgnoreCase(action) && validationMap != null && !validationMap.isEmpty()) {
            if (policyFromDb.isLegacy() && Device.Mode.PLAIN == device.getMode()) {
                if (Device.Type.MLXE == device.getType()) {
                    if (validationMap != null && !validationMap.isEmpty()) {
                        StringBuilder validationErrors = validationMap.get(PolicyValidator.ERROR_KEY);
                        StringBuilder validationWarnings = validationMap.get(PolicyValidator.WARNING_KEY);
                        StringBuilder messageBuilder = new StringBuilder();
                        if (validationErrors != null && validationErrors.length() != 0 && !policyFromDb.isInWarningState() && validationWarnings != null && validationWarnings.length() != 0) {
                            messageBuilder.append("The policy has errors and warnings.");
                        } else {
                            if (validationErrors != null && validationErrors.length() != 0) {
                                messageBuilder.append("The policy has errors.");
                            }
                            if (!policyFromDb.isInWarningState() && validationWarnings != null && validationWarnings.length() != 0) {
                                messageBuilder.append("The policy has warnings.");
                            }
                        }
                        if (validationErrors != null && validationErrors.length() != 0) {
                            messageBuilder.append("$$ERRORS :");
                            messageBuilder.append(validationErrors.toString().replaceAll("<br>", "\\$"));
                        }
                        if (!policyFromDb.isInWarningState() && validationWarnings != null && validationWarnings.length() != 0) {
                            messageBuilder.append("$$WARNINGS :");
                            messageBuilder.append(validationWarnings.toString().replaceAll("<br>", "\\$"));
                        }
                        if (messageBuilder.length() > 0) {
                            throw new ValidationException(messageBuilder.toString());
                        }
                    }
                } else if (Device.Type.SLX == device.getType()) {
                    StringBuilder validationErrors = validationMap.get(PolicyValidator.ERROR_KEY);
                    if (validationErrors != null && validationErrors.length() != 0) {
                        StringBuilder messageBuilder = new StringBuilder();
                        messageBuilder.append("The policy has errors.").append(validationErrors.toString().replaceAll("<br>", "\\$"));
                        throw new ValidationException(messageBuilder.toString());
                    }
                }
            } else {
                throw new ValidationException("policy.data.invalid");
            }
        }
        if (action != null && (ADD.equalsIgnoreCase(action) || DELETE.equalsIgnoreCase(action))) {
            Long jobId = managerBuilder.getOperationsFactory(device).getPolicyManager()
                    .commitPolicy(policy, true);
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        } else {
            policy = updateNullFieldsForPolicy(policy, device.getMode());
            Set<FlexMatchProfile> profiles = new HashSet<>();
            if (policy.getFlexMatchProfiles() != null && !policy.getFlexMatchProfiles().isEmpty()) {
                policy.getFlexMatchProfiles().forEach(profile -> {
                    FlexMatchProfile flexMatchProfile = flexMatchProfileRepository.findOne(profile.getId());
                    if (flexMatchProfile != null) {
                        profiles.add(flexMatchProfile);
                    } else {
                        throw new ValidationException("profile.id.invalid");
                    }
                });
                policy.setFlexMatchProfiles(profiles);
            }

            if (policy.getName() != null && !policy.getName().equals(policyFromDb.getName())) {
                throw new ValidationException("Name change is not allowed for an existing policy.");
            }
            if (action == null || action.equalsIgnoreCase(UPDATE)) {
                if (genericPolicyComparator.compare(policyFromDb, policy) == 0) {
                    if (!(policyFromDb.getName() != null ? !policyFromDb.getName().equals(policy.getName()) : policy.getName() != null)) {
                        throw new ValidationException("policy.data.unchanged");
                    }
                }
                policyId = managerBuilder.getOperationsFactory(device).getPolicyManager()
                        .savePolicy(policy, true);
                return new ResponseEntity<>(policyId, HttpStatus.OK);
            } else if (COMMIT.equalsIgnoreCase(action)) {
                boolean isSetInterfaceNull0TobeUpdated = isSetInterfaceNull0TobeUpdated(policyFromDb, device);
                if (policyFromDb.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.DRAFT && (genericPolicyComparator.compare(policyFromDb, policy) == 0)) {
                    if (policyFromDb.getName() != null ? !policyFromDb.getName().equals(policy.getName()) : policy.getName() != null) {
                        policyFromDb.setName(policy.getName());
                        policyFromDb = policyRepository.save(policyFromDb);
                        return new ResponseEntity<>(policyFromDb.getId(), HttpStatus.OK);
                    } else {
                        if (Device.Type.SLX == device.getType() || !isSetInterfaceNull0TobeUpdated) {
                            throw new ValidationException("policy.data.unchanged");
                        }
                    }
                }
                Long jobId = managerBuilder.getOperationsFactory(device).getPolicyManager()
                        .commitPolicy(policy, true);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            } else if (CLEANUP.equalsIgnoreCase(action)) {
                if (WorkflowParticipant.WorkflowStatus.ERROR != policyFromDb.getWorkflowStatus()) {
                    throw new ValidationException("policy.action.invalid");
                }
                Long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager()
                        .deletePolicy(policyFromDb.getId(), false, true);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            } else if (ROLLBACK.equalsIgnoreCase(action) && device.getMode() == Device.Mode.OPENFLOW) {
                if (device.getType() != null && device.getModel() != null && (Device.Type.SLX.equals(device.getType()) && device.getModel().contains(FlexMatchProfile.SLX_9850))) {
                    if (!policyFromDb.getFlexMatchProfiles().isEmpty()) {
                        log.error("RollBack action is not supported for flex match policy.");
                        throw new ValidationException("rollback.action.not.supported");
                    }
                }
                if (WorkflowParticipant.WorkflowStatus.ERROR != policyFromDb.getWorkflowStatus()) {
                    throw new ValidationException("policy.action.invalid");
                }
                Long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager()
                        .rollbackPolicy(policyFromDb.getId(), true);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("policy.action.invalid");

    }

    @RequestMapping(method = RequestMethod.POST, value = "/copy", consumes = "application/json")
    public ResponseEntity copyPolicies(@RequestBody CopyPolicyRequest copyPolicyRequest) throws JsonProcessingException {
        List<Long> jobIds = Lists.newArrayList();
        List<CopyPolicyResponse> responses = new ArrayList<CopyPolicyResponse>();
        Policy existingPolicy = policyRepository.findOne(copyPolicyRequest.getPolicy().getId());
        if (existingPolicy == null) {
            throw new ValidationException("Invalid Policy!");
        }
        //validate the copy policy on the devices.
        StringBuilder errorResponses = new StringBuilder();
        copyPolicyRequest.getDevices().stream().forEach(device1 -> {
            Device device;
            if (device1.getId() != null) {
                device = deviceRepository.findOne(device1.getId());
                if (device != null) {
                    try {
                        Policy copyPolicy = managerBuilder.getOperationsFactory(device).getPolicyManager().getCopyPolicy(existingPolicy, device1.getId());
                        managerBuilder.getOperationsFactory(copyPolicy.getDevice()).getPolicyManager().validateCopyPolicy(copyPolicy);
                    } catch (ValidationException e) {
                        if (e != null && !e.getMessage().isEmpty()) {
                            errorResponses.append(e.getMessage());
                        }
                    }
                } else {
                    errorResponses.append("Invalid device!");
                }
            } else {
                errorResponses.append("Invalid device Id!");
            }
        });
        if (errorResponses != null && errorResponses.length() != 0) {
            throw new ValidationException(errorResponses.toString());
        }
        //commit the policy on the devices.
        copyPolicyRequest.getDevices().stream().forEach(deviceObj -> {
            Device device;
            if (deviceObj.getId() != null) {
                device = deviceRepository.findOne(deviceObj.getId());
                if (device != null) {
                    Policy copyPolicy = managerBuilder.getOperationsFactory(device).getPolicyManager().getCopyPolicy(existingPolicy, deviceObj.getId());
                    Long jobId = managerBuilder.getOperationsFactory(copyPolicy.getDevice()).getPolicyManager().copyPolicy(copyPolicy, true);
                    jobIds.add(jobId);
                } else {
                    throw new ValidationException("Invalid device!");
                }
            } else {
                throw new ValidationException("Invalid device Id!");
            }
        });
        updateJobResult(jobIds, responses);
        return new ResponseEntity<>(responses, HttpStatus.OK);
    }


    /**
     * This method is used to clear ids of flow, ruleSet and rule from policy object for copy policy
     *
     * @param policy
     * @return ResponseEntity<Object> This returns policy
     */
    private Policy flushIdsForPolicy(Policy policy) {
        policy.clearId();
        policy.setLegacy(Boolean.FALSE);
        policy.getFlows().stream().forEach(flow -> {
            flow.clearId();
            flow.getRuleSets().stream().forEach(ruleSet -> {
                ruleSet.clearId();
                ruleSet.getRules().stream().forEach(rule -> {
                    rule.clearId();
                });
            });
        });
        return policy;
    }

    /**
     * MLXE Reconciled Policy with missing set interface null0 to be committed
     *
     * @param policy
     * @param device
     * @return
     */
    boolean isSetInterfaceNull0TobeUpdated(Policy policy, Device device) {
        AtomicBoolean isSetInterfaceNull0TobeUpdated = new AtomicBoolean(false);
        if (device != null && Device.Type.MLXE == device.getType()) {
            if (policy.getFlows() != null) {
                Flow flowWithoutSetInterfaceNull0 = policy.getFlows().stream().filter(flow ->
                        flow.getIsDefaultRouteMapDrop() != null && !flow.getIsDefaultRouteMapDrop()
                ).findAny().orElse(null);
                if (flowWithoutSetInterfaceNull0 != null) {
                    isSetInterfaceNull0TobeUpdated.set(true);
                }
            }
        }
        return isSetInterfaceNull0TobeUpdated.get();
    }

    /**
     * This method is used to set the default value for null fields
     *
     * @param policy
     * @return ResponseEntity<Object> This returns policy
     */
    private Policy updateNullFieldsForPolicy(Policy policy, Device.Mode mode) {
        if (Device.Mode.PLAIN == mode) {
            if (policy.getFieldOffset1() == null)
                policy.setFieldOffset1(-1L);
            if (policy.getFieldOffset2() == null)
                policy.setFieldOffset2(-1L);
            if (policy.getFieldOffset3() == null)
                policy.setFieldOffset3(-1L);
            if (policy.getFieldOffset4() == null)
                policy.setFieldOffset4(-1L);
        }
        if (policy.getLoopbackEnabled() == null) {
            policy.setLoopbackEnabled(false);
        }
        if (policy.getFlows() != null) {
            policy.getFlows().stream().forEach(flow -> {
                if (flow.getIsTagged() == null)
                    flow.setIsTagged(false);
                if (flow.getIsDefaultRouteMapDrop() == null)
                    flow.setIsDefaultRouteMapDrop(false);
                if (flow.getRuleSets() != null) {
                    flow.getRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getRules() != null) {
                            ruleSet.getRules().forEach(rule -> {
                                if (rule.getSourcePort() == null)
                                    rule.setSourcePort(0);
                                if (rule.getDestinationPort() == null)
                                    rule.setDestinationPort(0);
                                if (rule.getVlanId() == null)
                                    rule.setVlanId(-1);
                                if (rule.getIsPermit() == null)
                                    rule.setIsPermit(false);
                            });
                        }
                    });
                }
            });
        }
        return policy;
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }

    /**
     * Update the copyPolicyResponses object based on job result
     *
     * @param jobIdList
     * @param copyPolicyResponses
     */
    private void updateJobResult(List<Long> jobIdList, List<CopyPolicyResponse> copyPolicyResponses) {
        if (jobIdList != null) {
            jobIdList.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    CopyPolicyResponse copyPolicyResponse = new CopyPolicyResponse();
                    copyPolicyResponse.setDeviceName(device.getName());
                    copyPolicyResponse.setDeviceId(device.getId());

                    if (job.getStatus() == Job.Status.FAILED) {
                        copyPolicyResponse.setPolicyErrorResult(job.getJobResult());
                    } else {
                        copyPolicyResponse.setPolicySuccessful(true);
                    }
                    copyPolicyResponses.add(copyPolicyResponse);
                }

            });
        }
    }
}
