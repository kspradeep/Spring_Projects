package com.brocade.bvm.api.model.grid;

import lombok.Data;

import java.util.Set;

@Data
public class GridDeviceInfoRequest {

    Set<TargetType> targetHosts;

    @Data
    public static class TargetType {

        private Long id;

        private String name;

        private TYPE type;

        public enum TYPE {
            GRID,
            DEVICE
        }
    }
}
