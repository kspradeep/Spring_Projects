package com.brocade.bvm.api.manager.packetcapture.impl;

import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.manager.packetcapture.PacketCaptureManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PacketCaptureRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.PacketCapture;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.outbound.exception.CliConnectorException;
import com.brocade.bvm.outbound.packetcapture.cli.PCSshConnection;
import com.brocade.bvm.outbound.packetcapture.cli.model.Response;
import com.brocade.bvm.outbound.packetcapture.cli.util.CliConstants;
import com.brocade.bvm.outbound.stablenet.service.StablenetExecutionService;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import javax.inject.Inject;
import javax.inject.Named;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.temporal.ValueRange;
import java.util.*;
import java.util.regex.Pattern;

@Named
@Slf4j
public class AbstractPacketCaptureManager implements PacketCaptureManager {

    private static final String CAPTURE_ENABLED = "\\bcapture is enabled on interface Eth %s\\b";

    private static final String SHOW_PACKET_CAPTURE = "show capture packet config;";

    // e.g:oscmd scp /tmp/pktcapture.pcap root@10.37.130.38:/opt/pcap/pktcapture-2019-10-18T12:53:57.800.pcap
    private static final String COPY_PCAP_FILE = "oscmd scp /tmp/pktcapture.pcap %s@%s:%s%s-pktcapture-%s.pcap";

    private static final String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$";
    private static final String IPV6_PATTERN_SHORT = "^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$";
    private static final String IPV6_PATTERN_LONG = "^((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))$";


    @Inject
    private PacketCaptureRepository packetCaptureRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private ApplicationContext applicationContext;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private StablenetExecutionService executeCommandsOnDevice;

    @Value("${pcap.poll.interval.seconds:30}")
    private Integer pcapPollIntervalSeconds;

    /**
     * create packet capture for the port
     *
     * @param packetCapture
     * @return
     */
    @Override
    public Long createPacketCapture(PacketCapture packetCapture) {
        log.debug("create Packet Capture");
        PacketCapture packetCaptureDb = null;
        Long jobOutputId = -1L;
        validatePacketCapture(packetCapture);
        packetCaptureDb = packetCaptureRepository.findByDevice_Id(packetCapture.getDevice().getId());
        Device device = deviceRepository.findOne(packetCapture.getDevice().getId());
        Port port = portRepository.findOne(packetCapture.getPort().getId());
        if (port == null) {
            throw new ValidationException("Invalid port.");
        }
        if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
            if (packetCaptureDb != null) {
                packetCaptureDb.setDevice(device);
                packetCaptureDb.setPort(port);
                packetCaptureDb.setDirection(packetCapture.getDirection());
                packetCaptureDb.setFilter(packetCapture.getFilter());
                if (packetCapture.getPacketCount() != null) {
                    packetCaptureDb.setPacketCount(packetCapture.getPacketCount());
                }
                packetCaptureDb.setPcapCreated(false);
                packetCaptureDb.setDownloaded(false);

                packetCaptureDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                packetCaptureDb = packetCaptureRepository.save(packetCaptureDb);
            } else {
                packetCapture.setDevice(device);
                packetCapture.setPort(port);
                packetCapture.setPcapCreated(false);
                packetCapture.setDownloaded(false);
                packetCapture.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                packetCaptureDb = packetCaptureRepository.save(packetCapture);
            }
            Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_CAPTURE_CREATE).deviceId(packetCaptureDb.getDevice().getId())
                    .parentObjectId(packetCaptureDb.getId()).impactedObjectIds(Collections.emptyList()).build());
            jobOutputId = jobId;
        } else {
            throw new ValidationException("Invalid device.");
        }
        return jobResult(jobOutputId);
    }

    /**
     * Get packet capture by device and port id.
     *
     * @param deviceId
     * @return
     */
    @Override
    public String getPacketCapture(Long deviceId) {
        PacketCapture packetCapture = packetCaptureRepository.findByDevice_Id(deviceId);
        JSONObject packetCaptureJson = new JSONObject();
        if (packetCapture != null) {
            if (packetCapture.getDevice() != null && !packetCapture.getDevice().isDeleted() && packetCapture.getDevice().isReconciled()) {
                try {
                    packetCaptureJson.put("id", packetCapture.getId());
                    packetCaptureJson.put("deviceId", packetCapture.getDevice().getId());
                    packetCaptureJson.put("deviceName", packetCapture.getDevice().getName());
                    packetCaptureJson.put("portId", packetCapture.getPort().getId());
                    packetCaptureJson.put("portName", packetCapture.getPort().getName());
                    packetCaptureJson.put("workflowStatus", packetCapture.getWorkflowStatus());
                    packetCaptureJson.put("direction", packetCapture.getDirection());
                    packetCaptureJson.put("filter", packetCapture.getFilter());
                    packetCaptureJson.put("packetCount", packetCapture.getPacketCount() != null ? packetCapture.getPacketCount() : null);
                    packetCaptureJson.put("path", packetCapture.getDestinationPath() != null ? packetCapture.getDestinationPath() : null);
                    packetCaptureJson.put("destinationIp", packetCapture.getDestinationIp() != null ? packetCapture.getDestinationIp() : null);
                    packetCaptureJson.put("isDownloaded", packetCapture.isDownloaded());
                    packetCaptureJson.put("isPcapCreated", packetCapture.isPcapCreated());
                } catch (JSONException e) {
                    log.error("Failed to generate the packet capture JSON. {}", e.getMessage());
                }
            }
        }
        return packetCaptureJson.toString();
    }

    /**
     * @param copyPcapFileReq
     * @throws CliConnectorException
     */
    @Override
    public void copyPcapFile(Map<String, String> copyPcapFileReq) throws CliConnectorException {
        boolean isIpv6 = false;
        validateCopyPcap(copyPcapFileReq);
        Long deviceId = Long.parseLong(copyPcapFileReq.get("deviceId"));
        Device device = deviceRepository.findOne(deviceId);
        PacketCapture packetCapture = packetCaptureRepository.findByDevice_Id(deviceId);
        PCSshConnection sshConnection = applicationContext.getBean(PCSshConnection.class);
        List<String> cmds = new ArrayList<>();
        cmds.add("show capture packet config");
        try {
            connectAndExecuteCommand(copyPcapFileReq, cmds, sshConnection, device.getIpAddress());
        } catch (Exception e) {
            throw new ValidationException(e.getMessage());
        }
        if (device != null) {
            String path = copyPcapFileReq.get("path");
            if (!path.endsWith("/")) {
                path = path + "/";
            }
            String destIpValue = copyPcapFileReq.get("destIp");
            //if ipv6 address add the ip inside of the brackets
            isIpv6 = validateIpv6(destIpValue);
            if (isIpv6) {
                destIpValue = "[" + destIpValue + "]";
            }
            String destUserName = copyPcapFileReq.get("destUserName");
            //e.g : COPY_PCAP_FILE = "oscmd scp /tmp/pktcapture.pcap root@10.37.130.38:/opt/pcap";
            Instant instant = Instant.now();
            Date myDate = Date.from(instant);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
            String formattedDate = formatter.format(myDate);
            cmds.add(String.format(COPY_PCAP_FILE, destUserName, destIpValue, path, device.getName(), formattedDate));
            try {
                connectAndExecuteCommand(copyPcapFileReq, cmds, sshConnection, device.getIpAddress());
            } catch (Exception e) {
                throw new ValidationException(e.getMessage());
            }
            if (packetCapture != null && WorkflowParticipant.WorkflowStatus.ACTIVE == packetCapture.getWorkflowStatus()) {
                packetCapture.setDestinationPath(path);
                if (isIpv6 && destIpValue.length() > 2) {
                    packetCapture.setDestinationIp(destIpValue.substring(1, destIpValue.length() - 1));
                } else {
                    packetCapture.setDestinationIp(destIpValue);
                }
                packetCapture.setDownloaded(true);
                packetCaptureRepository.save(packetCapture);
            }
            sshConnection.disconnect();
        } else {
            throw new ValidationException("Invalid device.");
        }
    }

    /**
     * Check the job status is updated or not
     *
     * @param jobId
     * @return
     */
    private Job isJobUpdated(Long jobId) {
        Job job = genericJobManager.getJobStatus(jobId);
        return job;
    }

    /**
     * Validate the packet capture request
     *
     * @param packetCapture
     */
    private void validatePacketCapture(PacketCapture packetCapture) {
        if (packetCapture == null || packetCapture.getDirection() == null || packetCapture.getFilter() == null) {
            throw new ValidationException("packet.capture.invalid");
        }
        if (packetCapture.getDevice() == null && packetCapture.getDevice().getId() == null) {
            throw new ValidationException("packet.capture.device.id.invalid");
        }
        if (packetCapture.getPort() == null && packetCapture.getPort().getId() == null) {
            throw new ValidationException("packet.capture.port.id.invalid");
        }
        if (packetCapture.getPacketCount() != null && (!ValueRange.of(PacketCapture.PACKET_COUNT__MIN, PacketCapture.PACKET_COUNT__MAX).isValidValue(packetCapture.getPacketCount()))) {
            throw new ValidationException("packetCapture.data.invalidPacketCount");
        }
    }


    /**
     * @param copyPcapFileReq
     * @param cmds
     * @param pcSshConnection
     * @param sourceIp
     * @return
     * @throws Exception
     */
    private List<Response> connectAndExecuteCommand(Map<String, String> copyPcapFileReq, List<String> cmds, PCSshConnection pcSshConnection, String sourceIp) throws Exception {
        String srcUserName = copyPcapFileReq.get("srcUserName");
        String srcPassword = copyPcapFileReq.get("srcPassword");
        pcSshConnection.connect(sourceIp, srcUserName, srcPassword);
        pcSshConnection.readData();
        List<Response> responses = pcSshConnection.executeCommand(cmds, CliConstants.AccessMode.CONFIG_MODE, copyPcapFileReq);
        return responses;
    }

    /**
     * Validate the copy pcap file request
     *
     * @param copyPcapFileReq
     */
    private void validateCopyPcap(Map<String, String> copyPcapFileReq) {
        if (copyPcapFileReq == null || copyPcapFileReq.get("deviceId") == null || copyPcapFileReq.get("path") == null || copyPcapFileReq.get("srcUserName") == null || copyPcapFileReq.get("srcPassword") == null || copyPcapFileReq.get("destIp") == null || copyPcapFileReq.get("destUserName") == null || copyPcapFileReq.get("destPassword") == null) {
            throw new ValidationException("copy.pcap.request.invalid");
        }
        //validate the destion Ip
        if (copyPcapFileReq.get("destIp") != null) {
            if (copyPcapFileReq.get("destIp") != null && !Strings.isNullOrEmpty(copyPcapFileReq.get("destIp"))) {
                if (copyPcapFileReq.get("destIp").contains(":")) {
                    if (!validateIpv6(copyPcapFileReq.get("destIp"))) {
                        throw new ValidationException("host.server.invalidIp");
                    }
                } else if (!validateIpv4(copyPcapFileReq.get("destIp"))) {
                    throw new ValidationException("host.server.invalidIp");
                }
            } else {
                throw new ValidationException("host.server.invalidIp");
            }
        }
    }

    /**
     * get the job result
     *
     * @param jobId
     */
    private Long jobResult(Long jobId) {
        if (jobId != null) {
            Job job = genericJobManager.getJobStatus(jobId);
            if (job != null) {
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ValidationException(job.getJobResult());
                }
            }
        }
        return jobId;
    }

    /**
     * This method validates if the given ip is a valid IPV4
     *
     * @param ip
     * @return boolean
     */
    private boolean validateIpv4(String ip) {
        if (ip != null) {
            Pattern pattern = Pattern.compile(IPV4_PATTERN);
            return pattern.matcher(ip).matches();
        }
        return false;
    }

    /**
     * This method validates if the given ip is a valid IPV6
     *
     * @param ip
     * @return boolean
     */
    private boolean validateIpv6(String ip) {
        if (ip != null) {
            if (ip.contains("::") && ip.split(":").length <= 8) {
                Pattern pattern = Pattern.compile(IPV6_PATTERN_SHORT);
                return pattern.matcher(ip).matches();
            } else if (ip.contains(":") && ip.split(":").length != 8) {
                return false;
            } else {
                Pattern pattern = Pattern.compile(IPV6_PATTERN_LONG);
                return pattern.matcher(ip).matches();
            }
        }
        return false;
    }
}




