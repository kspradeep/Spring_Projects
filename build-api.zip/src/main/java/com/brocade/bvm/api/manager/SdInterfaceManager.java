package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;

import java.util.Map;
import java.util.Set;


public interface SdInterfaceManager {
    Long saveOrCommitActiveInterface(ActiveInterface activeInterface, Device device, String action);

    Map<String, Set<ActiveInterface>> getActiveInterfaces(ActiveInterface activeInterface, Device device);
}
