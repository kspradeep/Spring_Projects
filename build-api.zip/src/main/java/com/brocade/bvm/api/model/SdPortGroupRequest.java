package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.sessiondirector.ProfileInterfaceMapping;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class SdPortGroupRequest {

    private SdPortGroup sdPortGroup;

    private List<ProfileInterfaceMapping> profileInterfaceMapping;

    private List<ProfileInterfaceMapping> profileInterfaces;
}
