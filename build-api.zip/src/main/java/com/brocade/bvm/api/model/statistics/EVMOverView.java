package com.brocade.bvm.api.model.statistics;

import lombok.Data;

@Data
public class EVMOverView {
    private Long totalNoOfSwitches;
    private int totalSLX;
    private int totalMLX;
    private int totalNoOfGrids;
    private long totalTapPorts;
    private long totalToolPorts;
    private int totalPolices;
    private long memoryUtilization;
    private double totalMemory;
    private double cpuUtilization;
    private int totalNoOfUser;
    private int totalSoftwareServers;
    private int cpuCores;
}
