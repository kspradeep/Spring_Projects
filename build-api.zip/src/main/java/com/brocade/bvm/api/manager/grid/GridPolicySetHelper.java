package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.api.controller.ManagerFactoryBuilder;
import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.grid.*;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import com.brocade.bvm.model.db.history.GridPolicySetHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import com.brocade.bvm.outbound.grid.model.ToolAddressInterface;
import com.brocade.bvm.outbound.rest.RestHelperWithoutProxy;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Named
@Slf4j
public class GridPolicySetHelper {

    private static final String IP = "ip";
    private static final String ANY = "any";
    private static final String EQ = "eq";

    private static final String FABRIC = "type-fabric";
    private static final String EDGE = "EDGE";

    @Value("${network.path.auto.switch.limit}")
    private Integer networkPathSwitchAutoLimit;

    @Value("${tme.server.port:8082}")
    private Integer tmeServerPort;

    private static String tmePathCreateUrl = ":{tmeServerPort}/evm/pathrequest";
    private static String tmePathDeleteUrl = ":{tmeServerPort}/evm/pathdelete";
    private static String tmePathSyncUrl = ":{tmeServerPort}/evm/syncpath";
    private static String tmeTopologyPathUrl = ":{tmeServerPort}/evm/gridrequest";

    @Inject
    private GridPolicySetDiffComparator gridPolicySetComparator;

    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private GridRepository gridRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private GridMatrixHistoryRepository gridMatrixHistoryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @Inject
    private GridMatrixRepository gridMatrixRepository;

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private DestinationGroupRepository destinationGroupRepository;

    @Inject
    private GridPolicySetHistoryRepository gridPolicySetHistoryRepository;

    @Inject
    private EventRepository eventRepository;

    @Inject
    private NetworkNodeRepository networkNodeRepository;

    @Inject
    private IntermediateNodeRepository intermediateNodeRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private RestHelperWithoutProxy restHelperWithoutProxy;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private PlatformTransactionManager transactionManager;

    @Inject
    private JobQueue jobQueue;

    /**
     * Mathod commits the grid policy on device.
     *
     * @param gridPolicySet
     */
    protected List<Long> commitGridPolicies(GridPolicySet gridPolicySet) {
        //create all the combinations of interfaces and send REST API request to GE for path.
        //Parse the output and construct and return the end to end communication path.
        try {
            Set<GridClusterRequest> gridClusterSources = Sets.newHashSet();
            Set<GridClusterRequest> gridClusterDestinations = Sets.newHashSet();

            gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
                groupNodeInterfacesByDevice(Sets.newHashSet(gridPolicy.getIngressClusterNodeInterfaces()), gridClusterSources);
                groupNodeInterfacesByDevice(Sets.newHashSet(gridPolicy.getEgressClusterNodeInterfaces()), gridClusterDestinations);
            });

            if (gridClusterSources.isEmpty()) {
                log.error("Aggregator interfaces are empty. {}", gridPolicySet.getId());
                throw new ValidationException("Aggregator interfaces cannot be empty.");
            }

            if (gridClusterDestinations.isEmpty()) {
                log.error("Distributor interfaces are empty. {}", gridPolicySet.getId());
                throw new ValidationException("Distributor interfaces cannot be empty.");
            }

            Set<GridMatrix> gridMatrices = Sets.newHashSet();
            gridClusterSources.forEach(gridClusterSource -> {
                gridMatrices.add(createMatrix(gridPolicySet, gridClusterSource, gridClusterDestinations));
            });
            List<Long> jobIds = commitMatrix(gridMatrices, gridPolicySet);
            return jobIds;
        } catch (Exception e) {
            String gridName = gridRepository.findNameById(gridPolicySet.getDeviceGrid().getId());
            String errorMessage = e.getMessage();
            if (Strings.isNullOrEmpty(errorMessage)) {
                errorMessage = "Failed to commit the policy.";
            }
            log.error("Failed to commit the policy {}.  cause : {}", gridPolicySet.getId(), errorMessage);
            updateEvent(gridPolicySet.getId(), Job.Type.POLICY_CREATE.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.CRITICAL);
            gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
            gridPolicySetRepository.save(gridPolicySet);
            throw new ServerException(e.getMessage());
        }
    }

    /**
     * Creates the matrix object w.r.t. the policy set and individual device in which policies are applied.
     *
     * @param gridPolicySet
     * @param gridClusterSource
     * @param gridClusterDestinations
     * @return
     */
    private GridMatrix createMatrix(GridPolicySet gridPolicySet, GridClusterRequest gridClusterSource, Set<GridClusterRequest> gridClusterDestinations) {
        DecimalFormat df = new DecimalFormat("#");
        df.setRoundingMode(RoundingMode.CEILING);
        AtomicLong atomicLong = new AtomicLong(0);
        Set<Long> managedObjectIds = Sets.newHashSet();
        gridClusterSource.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
            clusterNodeInterface.getPorts().forEach(port -> {
                if (!managedObjectIds.contains(port.getId())) {
                    atomicLong.addAndGet(port.getLineSpeed());
                    managedObjectIds.add(port.getId());
                }
            });
            clusterNodeInterface.getPortGroups().forEach(portGroup -> {
                if (!managedObjectIds.contains(portGroup.getId())) {
                    portGroup.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed()));
                    managedObjectIds.add(portGroup.getId());
                }
            });
        });
        Long bandwidth = Long.parseLong(df.format((atomicLong.get() / 1000)));
        GridMatrix gridMatrix = new GridMatrix();
        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gridMatrix.setGridPolicySetId(gridPolicySet.getId());
        gridMatrix.setSourceDeviceId(gridClusterSource.getDevice().getId());
        gridMatrix.setDestinationDeviceIds(gridClusterDestinations.stream().map(gridClusterRequest -> gridClusterRequest.getDevice().getId()).collect(Collectors.toSet()));
        Set<GridTopologyPath> gridTopologyPaths = Sets.newHashSet();

        Set<Long> policyIngressIds = Sets.newHashSet();
        Set<Long> policyEgressIds = Sets.newHashSet();
        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
            gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                policyIngressIds.addAll(clusterNodeInterface.getPortsAndPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
            });
            gridPolicy.getEgressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                policyEgressIds.addAll(clusterNodeInterface.getPortsAndPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
            });
        });
        gridClusterDestinations.forEach(gridClusterRequest -> {
            gridClusterRequest.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                try {
                    GridTopologyPath gridTopologyPath = createPath(gridPolicySet, gridClusterSource, gridClusterRequest, clusterNodeInterface, bandwidth);
                    if (gridTopologyPath != null) {
                        gridTopologyPaths.add(gridTopologyPath);
                        gridTopologyPath.getSourceNetworkNode().getEgressPortsAndPortGroups().forEach(managedObject -> {
                            if (policyIngressIds.contains(managedObject.getId())) {
                                log.error("Interface " + managedObject.getName() + " on " + gridTopologyPath.getSourceNetworkNode().getDevice().getName() + " is used as both ingress and egress.");
                                throw new ValidationException("Interface " + managedObject.getName() + " on " + gridTopologyPath.getSourceNetworkNode().getDevice().getName() + " cannot be used as it is conflicting with network path.");
                            }
                        });
                        gridTopologyPath.getDestinationNetworkNode().getIngressPortsAndPortGroups().forEach(managedObject -> {
                            if (policyEgressIds.contains(managedObject.getId())) {
                                log.error("Interface " + managedObject.getName() + " on " + gridTopologyPath.getDestinationNetworkNode().getDevice().getName() + " is used as both ingress and egress.");
                                throw new ValidationException("Interface " + managedObject.getName() + " on " + gridTopologyPath.getDestinationNetworkNode().getDevice().getName() + " cannot be used as it is conflicting with network path.");
                            }
                        });
                    }
                } catch (Exception e) {
                    //clean up all existing paths.
                    gridTopologyPaths.forEach(gridTopologyPathObj -> {
                        if (gridTopologyPathObj.getPathId() != null) {
                            deletePath(gridTopologyPathObj.getPathId());
                        }
                    });
                    throw new ServerException(e.getMessage());
                }
            });
        });

        synchronized (this) {
            Set<Integer> toolIdsUsed = gridTopologyPathRepository.getAllToolAddresses();
            gridTopologyPaths.forEach(gridTopologyPath -> {
                Integer toolAddress = getToolId(toolIdsUsed);
                toolIdsUsed.add(toolAddress);
                gridTopologyPath.setToolAddress(toolAddress);
            });
            gridMatrix.setGridTopologyPaths(gridTopologyPaths);
            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            gridMatrixRepository.save(gridMatrix);
        }
        return gridMatrix;
    }

    /**
     * Method commits the matrix, pbf destination, pbf destination group and target policies on each devices part of the grid.
     *
     * @param gridMatrices
     * @param gridPolicySet
     * @return
     */
    private List<Long> commitMatrix(Set<GridMatrix> gridMatrices, GridPolicySet gridPolicySet) {
        synchronized (this) {
            gridMatrices.forEach(gridMatrix -> {
                Device sourceDevice = deviceRepository.findOne(gridMatrix.getSourceDeviceId());
                Policy aggregatorPolicy = getAggregatorPolicySet(gridPolicySet, new Policy(), sourceDevice, gridMatrix.getGridTopologyPaths());
                validateDevicePolicy(aggregatorPolicy, sourceDevice.getName());
                Set<DestinationGroup> destinationGroups = generateAndSetGroupIds(aggregatorPolicy, gridPolicySet, gridMatrix, Sets.newHashSet(gridMatrix.getDestinationGroups()), gridMatrix.getGridTopologyPaths());
                managerBuilder.getOperationsFactory(sourceDevice).getPolicyManager().savePolicy(aggregatorPolicy, false);
                gridMatrix.setPolicyId(aggregatorPolicy.getId());
                gridMatrix.setDestinationGroups(destinationGroups);
                gridMatrixRepository.save(gridMatrix);

                Set<Long> intermediateDeviceIds = Sets.newHashSet();
                gridMatrix.getGridTopologyPaths().forEach(toolAddressTopologyPathMapping -> {
                    GridTopologyPath gridTopologyPathDb = gridTopologyPathRepository.findOne(toolAddressTopologyPathMapping.getId());
                    if (gridTopologyPathDb != null) {
                        intermediateDeviceIds.addAll(gridTopologyPathDb.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                    }
                });
                updateToolAddress(gridMatrix.getSourceDeviceId(), Sets.newHashSet(gridMatrix.getDestinationDeviceIds()), gridMatrix, intermediateDeviceIds, Job.Type.GRID_TOOL_ADDRESS_CREATE);
                updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_CREATE);
            });
        }
        List<Long> jobIdsAdded = Lists.newArrayList();
        Job.Type type = Job.Type.POLICY_CREATE;
        gridMatrices.forEach(gridMatrix -> {
            if (gridMatrix.getPolicyId() != null) {
                List<Long> impactedObjectIds = Lists.newArrayList();
                impactedObjectIds.add(gridMatrix.getId());
                Policy aggregatorPolicy = policyRepository.findOne(gridMatrix.getPolicyId());
                long jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(aggregatorPolicy.getDevice().getId())
                        .parentObjectId(aggregatorPolicy.getId()).impactedObjectIds(impactedObjectIds).build());
                if (jobId != -1) {
                    jobIdsAdded.add(jobId);
                }
            }
        });
        jobIdsAdded.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
            }
        });
        gridMatrices.forEach(gridMatrix -> {
            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
            gridMatrixRepository.save(gridMatrix);
        });
        return jobIdsAdded;
    }

    /**
     * Method request for the topology path from TME based on the interface nodes.
     *
     * @param gridPolicySet
     * @param gridClusterSource
     * @param gridClusterDestination
     * @param clusterNodeInterface
     * @param bandwidth
     * @return
     */
    private GridTopologyPath createPath(GridPolicySet gridPolicySet, GridClusterRequest gridClusterSource, GridClusterRequest gridClusterDestination, ClusterNodeInterfaceRequest clusterNodeInterface, Long bandwidth) {
        GridTopologyPath gridTopologyPath;
        try {
            Map<String, Object> pathResponseMap = getTopologyPath(gridClusterSource.getDevice().getChassis(), gridClusterDestination.getDevice().getChassis(), null, null, bandwidth, gridPolicySet.getIsCspfEnabled());
            log.debug("path response between {} and {} is {}", gridClusterSource.getDevice().getId(), gridClusterDestination.getDevice().getId(), pathResponseMap);
            if (pathResponseMap != null && !pathResponseMap.isEmpty()) {
                Set<Port> sourceNodeIngressPorts = Sets.newHashSet();
                Set<PortGroup> sourceNodeIngressPortGroups = Sets.newHashSet();
                gridClusterSource.getClusterNodeInterfaces().forEach(clusterNodeInterfaceRequest -> {
                    sourceNodeIngressPorts.addAll(clusterNodeInterfaceRequest.getPorts());
                    sourceNodeIngressPortGroups.addAll(clusterNodeInterfaceRequest.getPortGroups());
                });
                gridTopologyPath = parsePathResponseAndMakeTopology(pathResponseMap, sourceNodeIngressPorts, sourceNodeIngressPortGroups, clusterNodeInterface.getPorts(),
                        clusterNodeInterface.getPortGroups(), gridPolicySet.getIsOverSubscriptionAllowed(), gridClusterSource.getDevice().getName(), gridClusterDestination.getDevice().getName());
                if (gridTopologyPath != null) {
                    if (gridTopologyPath.getPathId() != null && gridTopologyPathRepository.findByPathIdAndIsActive(gridTopologyPath.getPathId(), true) != null) {
                        log.error("Network path id {} already exists! Try restarting the Visibility Manager service to sync with TME.", gridTopologyPath.getPathId());
                        throw new ValidationException("Network path already exists.");
                    }
                    gridTopologyPath.setBandwidth(bandwidth);
                    gridTopologyPath.setIsCspfEnabled(gridPolicySet.getIsCspfEnabled());
                    gridTopologyPath.setTapNodeInterfaceIds(gridClusterSource.getClusterNodeInterfaces().stream().map(ClusterNodeInterfaceRequest::getId).collect(Collectors.toSet()));
                    gridTopologyPath.setToolNodeInterfaceId(clusterNodeInterface.getId());
                    gridTopologyPath.setPolicySetId(gridPolicySet.getId());
                } else {
                    log.error("Failed to parse network path. {}", pathResponseMap);
                    throw new ValidationException("Failed to parse the path due to missing fields/invalid values.");
                }
            } else {
                log.error("Invalid network path. {}", pathResponseMap);
                throw new ValidationException("Invalid network path!");
            }
        } catch (Exception e) {
            throw new ValidationException(e.getMessage());
        }
        return gridTopologyPath;
    }

    /**
     * Validate the policy update request from update grid API.
     *
     * @param deviceGrid
     * @param deviceGridHistory
     */
    public void validateUpdatePolicySetFromGrid(DeviceGrid deviceGrid, DeviceGrid deviceGridHistory) {
        List<Long> gridPolicySetIds = gridPolicySetRepository.findIdsByGridId(deviceGrid.getId());
        if (!gridPolicySetIds.isEmpty()) {
            Set<Long> deletedSourceNodes = Sets.newHashSet();
            Set<Long> deletedDestinationNodes = Sets.newHashSet();

            Set<ClusterNodeInterface> clusterInterfacesSourceUpdated = Sets.newHashSet();
            Set<ClusterNodeInterface> clusterInterfacesDestUpdated = Sets.newHashSet();
            Set<Long> clusterNodeInterfacesSourceToDelete = Sets.newHashSet();
            Set<Long> clusterNodeInterfacesDestToDelete = Sets.newHashSet();

            compareGrids(deviceGridHistory, deviceGrid, deletedSourceNodes, deletedDestinationNodes,
                    clusterInterfacesSourceUpdated, clusterInterfacesDestUpdated, clusterNodeInterfacesSourceToDelete, clusterNodeInterfacesDestToDelete);
            if (!clusterInterfacesSourceUpdated.isEmpty() || !clusterInterfacesDestUpdated.isEmpty() || !deletedSourceNodes.isEmpty() || !deletedDestinationNodes.isEmpty()
                    || !clusterNodeInterfacesSourceToDelete.isEmpty() || !clusterNodeInterfacesDestToDelete.isEmpty()) {
                Set<Long> clusterNodeInterfaceIdsSourceUpdated = clusterInterfacesSourceUpdated.stream().map(ClusterNodeInterface::getId).collect(Collectors.toSet());
                Set<Long> clusterNodeInterfaceIdsDestUpdated = clusterInterfacesDestUpdated.stream().map(ClusterNodeInterface::getId).collect(Collectors.toSet());
                gridPolicySetIds.forEach(policySetId -> {
                    GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
                    if (gridPolicySet != null) {
                        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
                            gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                if (deletedSourceNodes.contains(clusterNodeInterface.getGridCluster().getId())) {
                                    throw new ValidationException("Cannot delete tap interface " + clusterNodeInterface.getName() + " as it is used in policy " + gridPolicySet.getName() + ".");
                                } else if (clusterNodeInterfacesSourceToDelete.contains(clusterNodeInterface.getId())) {
                                    throw new ValidationException("Cannot delete tap interface " + clusterNodeInterface.getName() + " as it is used in policy " + gridPolicySet.getName() + ".");
                                }
                                if (clusterNodeInterfaceIdsSourceUpdated.contains(clusterNodeInterface.getId())) {
                                    if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus()) {
                                        throw new ValidationException("Cannot update grid as policy " + gridPolicySet.getName() + " is in error state. Please recover the policy and try again.");
                                    } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
                                        throw new ValidationException("Cannot update grid as another operation is in progress on policy " + gridPolicySet.getName() + ". Please try after sometime.");
                                    } else if (WorkflowParticipant.WorkflowStatus.DRAFT == gridPolicySet.getWorkflowStatus()) {
                                        GridPolicySet policyFromHistoryNew = getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.ACTIVE));
                                        if (policyFromHistoryNew != null && policyFromHistoryNew.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                                            throw new ValidationException("Cannot update grid as policy " + gridPolicySet.getName() + " is in draft state. Please commit or revert the policy and try again.");
                                        }
                                    }
                                }
                            });
                            gridPolicy.getEgressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                if (deletedDestinationNodes.contains(clusterNodeInterface.getGridCluster().getId())) {
                                    throw new ValidationException("Cannot delete tool interface " + clusterNodeInterface.getName() + " as it is used in policy " + gridPolicySet.getName() + ".");
                                } else if (clusterNodeInterfacesDestToDelete.contains(clusterNodeInterface.getId())) {
                                    throw new ValidationException("Cannot delete tool interface " + clusterNodeInterface.getName() + " as it is used in policy " + gridPolicySet.getName() + ".");
                                }
                                if (clusterNodeInterfaceIdsDestUpdated.contains(clusterNodeInterface.getId())) {
                                    if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus()) {
                                        throw new ValidationException("Cannot update grid as policy " + gridPolicySet.getName() + " is in error state. Please recover the policy and try again.");
                                    } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
                                        throw new ValidationException("Cannot update grid as another operation is in progress on policy " + gridPolicySet.getName() + ". Please try after sometime.");
                                    } else if (WorkflowParticipant.WorkflowStatus.DRAFT == gridPolicySet.getWorkflowStatus()) {
                                        GridPolicySet policyFromHistoryNew = getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.ACTIVE));
                                        if (policyFromHistoryNew != null && policyFromHistoryNew.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                                            throw new ValidationException("Cannot update grid as policy " + gridPolicySet.getName() + " is in draft state. Please commit or revert the policy and try again.");
                                        }
                                    }
                                }
                            });
                        });
                    }
                });
            }
        }
    }

    /**
     * Updates/commits the policies w.r.t. the grid changes.
     *
     * @param deviceGrid
     * @param deviceGridHistory
     */
    public void updatePolicySetFromGrid(DeviceGrid deviceGrid, DeviceGrid deviceGridHistory) {
        List<Long> gridPolicySetIds = gridPolicySetRepository.findIdsByGridId(deviceGrid.getId());
        if (gridPolicySetIds != null && !gridPolicySetIds.isEmpty()) {
            DecimalFormat df = new DecimalFormat("#");
            df.setRoundingMode(RoundingMode.CEILING);
            //Add/delete interfaces to existing Tap/Tool group
            //Delete existing Tap/Tool group - NO action as it may delete the policies associated. Validate and throw error.
            //Add new Tap/Tool group - NO action needed.
            Set<Long> deletedSourceNodes = Sets.newHashSet();
            Set<Long> deletedDestinationNodes = Sets.newHashSet();
            Set<ClusterNodeInterface> clusterInterfacesSourceUpdated = Sets.newHashSet();
            Set<ClusterNodeInterface> clusterInterfacesDestUpdated = Sets.newHashSet();
            Set<Long> clusterNodeInterfacesSourceToDelete = Sets.newHashSet();
            Set<Long> clusterNodeInterfacesDestToDelete = Sets.newHashSet();

            compareGrids(deviceGridHistory, deviceGrid, deletedSourceNodes, deletedDestinationNodes,
                    clusterInterfacesSourceUpdated, clusterInterfacesDestUpdated, clusterNodeInterfacesSourceToDelete, clusterNodeInterfacesDestToDelete);
            if (!clusterInterfacesSourceUpdated.isEmpty() || !clusterInterfacesDestUpdated.isEmpty()) {
                gridPolicySetIds.forEach(policySetId -> {
                    GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
                    if (gridPolicySet != null) {
                        AtomicBoolean isUpdated = new AtomicBoolean(false);
                        gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
                            gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                Optional<ClusterNodeInterface> clusterNodeInterfaceOptional = clusterInterfacesSourceUpdated.stream().filter(clusterNodeSourceUpdated -> clusterNodeSourceUpdated.getId() == clusterNodeInterface.getId()).findAny();
                                if (clusterNodeInterfaceOptional.isPresent()) {
                                    ClusterNodeInterface clusterNodeInterfaceUpdated = clusterNodeInterfaceOptional.get();
                                    clusterNodeInterface.setPorts(clusterNodeInterfaceUpdated.getPorts());
                                    clusterNodeInterface.setPortGroups(clusterNodeInterfaceUpdated.getPortGroups());
                                    isUpdated.set(true);
                                }
                            });
                            //need update the pbf destination set interface.
                            gridPolicy.getEgressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                Optional<ClusterNodeInterface> clusterNodeInterfaceOptional = clusterInterfacesDestUpdated.stream().filter(clusterNodeDestUpdated -> clusterNodeDestUpdated.getId() == clusterNodeInterface.getId()).findAny();
                                if (clusterNodeInterfaceOptional.isPresent()) {
                                    ClusterNodeInterface clusterNodeInterfaceUpdated = clusterNodeInterfaceOptional.get();
                                    clusterNodeInterface.setPorts(clusterNodeInterfaceUpdated.getPorts());
                                    clusterNodeInterface.setPortGroups(clusterNodeInterfaceUpdated.getPortGroups());
                                    isUpdated.set(true);
                                }
                            });
                        });
                        if (isUpdated.get()) {
                            gridPolicySetRepository.save(gridPolicySet);
                        }
                    }
                });

                Set<MatrixUpdated> matrixUpdatedSet = Sets.newHashSet();
                gridPolicySetIds.forEach(policySetId -> {
                    GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
                    if (gridPolicySet != null && WorkflowParticipant.WorkflowStatus.ACTIVE == gridPolicySet.getWorkflowStatus() && gridPolicySet.getGridPolicies() != null) {
                        try {
                            gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
                                gridPolicy.getIngressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                    Optional<ClusterNodeInterface> clusterNodeInterfaceOptional = clusterInterfacesSourceUpdated.stream().filter(clusterNodeSourceUpdated -> clusterNodeSourceUpdated.getId() == clusterNodeInterface.getId()).findAny();
                                    if (clusterNodeInterfaceOptional.isPresent()) {
                                        AtomicLong atomicLong = new AtomicLong(0);
                                        Set<Long> managedObjectIds = Sets.newHashSet();
                                        clusterNodeInterface.getPorts().forEach(port -> {
                                            if (!managedObjectIds.contains(port.getId())) {
                                                atomicLong.addAndGet(port.getLineSpeed());
                                                managedObjectIds.add(port.getId());
                                            }
                                        });
                                        clusterNodeInterface.getPortGroups().forEach(portGroup -> {
                                            if (!managedObjectIds.contains(portGroup.getId())) {
                                                portGroup.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed()));
                                                managedObjectIds.add(portGroup.getId());
                                            }
                                        });
                                        Long bandwidth = Long.parseLong(df.format((atomicLong.get() / 1000)));
                                        ClusterNodeInterface clusterNodeInterfaceUpdated = clusterNodeInterfaceOptional.get();
                                        //find all path using this interfaces;
                                        Set<BigInteger> gridTopologyPathIds = gridTopologyPathRepository.findByPolicySetIdAndSourceInterfaceId(gridPolicySet.getId(), clusterNodeInterfaceUpdated.getId());
                                        gridTopologyPathIds.forEach(gridTopologyPathId -> {
                                            GridTopologyPath gridTopologyPathToUpdate = gridTopologyPathRepository.findOne(gridTopologyPathId.longValue());
                                            if (gridTopologyPathToUpdate != null) {
                                                Device sourceDevice = gridTopologyPathToUpdate.getSourceNetworkNode().getDevice();
                                                Device destinationDevice = gridTopologyPathToUpdate.getDestinationNetworkNode().getDevice();
                                                Set<Port> sourceNodeIngressPorts = clusterNodeInterfaceUpdated.getPorts();
                                                Set<PortGroup> sourceNodeIngressPortGroups = clusterNodeInterfaceUpdated.getPortGroups();
                                                Set<PortGroup> destinationNodeEgressPortGroups = gridTopologyPathToUpdate.getDestinationNetworkNode().getEgressPortGroups();
                                                Set<Port> destinationNodeEgressPorts = gridTopologyPathToUpdate.getDestinationNetworkNode().getEgressPorts();
                                                Map<String, Object> pathResponseMap = getTopologyPath(sourceDevice.getChassis(), destinationDevice.getChassis(), null, null, bandwidth, gridPolicySet.getIsCspfEnabled());
                                                log.debug("updatePolicySetFromGrid aggregator : New path response between source id {} and destination id {} is {}", sourceDevice.getId(), destinationDevice.getId(), pathResponseMap);
                                                if (pathResponseMap != null && !pathResponseMap.isEmpty()) {
                                                    GridTopologyPath gridTopologyPath = parsePathResponseAndMakeTopology(pathResponseMap, sourceNodeIngressPorts, sourceNodeIngressPortGroups, destinationNodeEgressPorts, destinationNodeEgressPortGroups,
                                                            gridPolicySet.getIsOverSubscriptionAllowed(), sourceDevice.getName(), destinationDevice.getName());
                                                    if (gridTopologyPath != null) {
                                                        if (gridTopologyPath.getPathId() != null && gridTopologyPathRepository.findByPathIdAndIsActive(gridTopologyPath.getPathId(), true) != null) {
                                                            log.error("Network path id {} already exists! Try restarting the Visibility Manager service to sync with TME.", gridTopologyPath.getPathId());
                                                            throw new ValidationException("Network path already exists.");
                                                        }
                                                        Set<Integer> toolIdsUsed = gridTopologyPathRepository.getAllToolAddresses();
                                                        gridTopologyPath.setBandwidth(gridTopologyPathToUpdate.getBandwidth());
                                                        gridTopologyPath.setToolAddress(getToolId(toolIdsUsed));
                                                        gridTopologyPath.setIsCspfEnabled(gridPolicySet.getIsCspfEnabled());
                                                        gridTopologyPath.setTapNodeInterfaceIds(Sets.newHashSet(gridTopologyPathToUpdate.getTapNodeInterfaceIds()));
                                                        gridTopologyPath.setToolNodeInterfaceId(gridTopologyPathToUpdate.getToolNodeInterfaceId());
                                                        gridTopologyPath.setPolicySetId(gridPolicySet.getId());

                                                        GridMatrix gridMatrix = gridMatrixRepository.findByTopologyPathId(gridTopologyPathToUpdate.getId());
                                                        if (gridMatrix != null) {
                                                            try {
                                                                gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                                                                gridMatrix.addGridTopologyPath(gridTopologyPath);
                                                                gridTopologyPathRepository.save(gridTopologyPath);
                                                                gridMatrix.removeGridTopologyPath(gridTopologyPathToUpdate);
                                                                Set<GridTopologyPath> gridTopologyPathsUpdated = gridTopologyPathRepository.findAllByPathIdAndPolicyIdAndIsActive(gridPolicySet.getId(), gridTopologyPath.getPathId(), true);
                                                                gridMatrix.getDestinationGroups().forEach(destinationGroup -> {
                                                                    if (destinationGroup.getGridTopologyPathIds().stream().anyMatch(aLong -> aLong == gridTopologyPathToUpdate.getId())) {
                                                                        if (gridTopologyPathsUpdated != null) {
                                                                            gridTopologyPathsUpdated.forEach(gridTopologyPath1 -> {
                                                                                destinationGroup.addGridTopologyPathId(gridTopologyPath1.getId());
                                                                            });
                                                                        }
                                                                        destinationGroup.removeGridTopologyPathId(gridTopologyPathToUpdate.getId());
                                                                        destinationGroupRepository.save(destinationGroup);
                                                                    }
                                                                });
                                                                gridMatrixRepository.save(gridMatrix);
                                                                Set<Long> intermediateDeviceIdsOldPath = gridTopologyPathToUpdate.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet());
                                                                Set<Long> intermediateDeviceIds = gridTopologyPath.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet());
                                                                Set<Long> missingIntermediateDevicesFromFailedPath = Sets.difference(intermediateDeviceIdsOldPath, intermediateDeviceIds);
                                                                Set<Long> gridClusterDestinations = Sets.newHashSet();
                                                                gridClusterDestinations.add(destinationDevice.getId());
                                                                if (gridTopologyPathToUpdate.getPathId() != null && gridTopologyPathToUpdate.getIsActive()) {
                                                                    deletePath(gridTopologyPathToUpdate.getPathId());
                                                                    gridTopologyPathToUpdate.setIsActive(false);
                                                                }
                                                                MatrixUpdated matrixUpdated = new MatrixUpdated();
                                                                Optional<MatrixUpdated> optionalMatrixUpdated = matrixUpdatedSet.stream().filter(matrixUpdated1 -> matrixUpdated1.getGridMatrixId() == gridMatrix.getId()).findAny();
                                                                if (optionalMatrixUpdated.isPresent()) {
                                                                    matrixUpdated = optionalMatrixUpdated.get();
                                                                } else {
                                                                    matrixUpdatedSet.add(matrixUpdated);
                                                                }
                                                                matrixUpdated.setGridPolicySetId(policySetId);
                                                                matrixUpdated.setGridMatrixId(gridMatrix.getId());
                                                                matrixUpdated.setSourceDeviceId(sourceDevice.getId());
                                                                matrixUpdated.addGridClusterDestinations(gridClusterDestinations);
                                                                matrixUpdated.addIntermediateDeviceIds(intermediateDeviceIds);
                                                                matrixUpdated.addMissingIntermediateDeviceIds(missingIntermediateDevicesFromFailedPath);
                                                            } catch (Exception e) {
                                                                gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                                                                gridMatrixRepository.save(gridMatrix);
                                                                throw new ValidationException(e.getMessage());
                                                            }
                                                        } else {
                                                            if (gridTopologyPath != null && gridTopologyPath.getPathId() != null && gridTopologyPath.getIsActive()) {
                                                                deletePath(gridTopologyPath.getPathId());
                                                                gridTopologyPath.setIsActive(false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    log.error("updatePolicySetFromGrid aggregator : Invalid network path. {}", pathResponseMap);
                                                    throw new ValidationException("Invalid network path!");
                                                }
                                            }
                                        });
                                    }
                                });
                                //need update the pbf destination set interface.
                                gridPolicy.getEgressClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                                    Optional<ClusterNodeInterface> clusterNodeInterfaceOptional = clusterInterfacesDestUpdated.stream().filter(clusterNodeDestUpdated -> clusterNodeDestUpdated.getId() == clusterNodeInterface.getId()).findAny();
                                    if (clusterNodeInterfaceOptional.isPresent()) {
                                        ClusterNodeInterface clusterNodeInterfaceUpdated = clusterNodeInterfaceOptional.get();
                                        Set<BigInteger> gridTopologyPathIds = gridTopologyPathRepository.findByPolicySetIdAndDestinationInterfaceId(gridPolicySet.getId(), clusterNodeInterfaceUpdated.getId());
                                        gridTopologyPathIds.forEach(gridTopologyPathFailedId -> {
                                            GridTopologyPath gridTopologyPathToUpdate = gridTopologyPathRepository.findOne(gridTopologyPathFailedId.longValue());
                                            Device sourceDevice = gridTopologyPathToUpdate.getSourceNetworkNode().getDevice();
                                            Device destinationDevice = gridTopologyPathToUpdate.getDestinationNetworkNode().getDevice();

                                            Set<Port> sourceNodeIngressPorts = gridTopologyPathToUpdate.getSourceNetworkNode().getIngressPorts();
                                            Set<PortGroup> sourceNodeIngressPortGroups = gridTopologyPathToUpdate.getSourceNetworkNode().getIngressPortGroups();
                                            Set<Port> destinationNodeEgressPorts = clusterNodeInterfaceUpdated.getPorts();
                                            Set<PortGroup> destinationNodeEgressPortGroups = clusterNodeInterfaceUpdated.getPortGroups();

                                            Map<String, Object> pathResponseMap = getTopologyPath(sourceDevice.getChassis(), destinationDevice.getChassis(), null, null, gridTopologyPathToUpdate.getBandwidth(), gridPolicySet.getIsCspfEnabled());
                                            log.debug("updatePolicySetFromGrid distributor : New path response between source id {} and destination id {} is {}", sourceDevice.getId(), destinationDevice.getId(), pathResponseMap);
                                            if (pathResponseMap != null && !pathResponseMap.isEmpty()) {
                                                GridTopologyPath gridTopologyPath = parsePathResponseAndMakeTopology(pathResponseMap, sourceNodeIngressPorts, sourceNodeIngressPortGroups, destinationNodeEgressPorts, destinationNodeEgressPortGroups,
                                                        gridPolicySet.getIsOverSubscriptionAllowed(), sourceDevice.getName(), destinationDevice.getName());
                                                if (gridTopologyPath != null) {
                                                    if (gridTopologyPath.getPathId() != null && gridTopologyPathRepository.findByPathIdAndIsActive(gridTopologyPath.getPathId(), true) != null) {
                                                        log.error("Network path id {} already exists! Try restarting the Visibility Manager service to sync with TME.", gridTopologyPath.getPathId());
                                                        throw new ValidationException("Network path already exists.");
                                                    }
                                                    Set<Integer> toolIdsUsed = gridTopologyPathRepository.getAllToolAddresses();
                                                    gridTopologyPath.setBandwidth(gridTopologyPathToUpdate.getBandwidth());
                                                    gridTopologyPath.setToolAddress(getToolId(toolIdsUsed));
                                                    gridTopologyPath.setIsCspfEnabled(gridPolicySet.getIsCspfEnabled());
                                                    gridTopologyPath.setTapNodeInterfaceIds(Sets.newHashSet(gridTopologyPathToUpdate.getTapNodeInterfaceIds()));
                                                    gridTopologyPath.setToolNodeInterfaceId(gridTopologyPathToUpdate.getToolNodeInterfaceId());
                                                    gridTopologyPath.setPolicySetId(gridPolicySet.getId());

                                                    GridMatrix gridMatrix = gridMatrixRepository.findByTopologyPathId(gridTopologyPathToUpdate.getId());
                                                    if (gridMatrix != null) {
                                                        try {
                                                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                                                            gridMatrix.addGridTopologyPath(gridTopologyPath);
                                                            gridTopologyPathRepository.save(gridTopologyPath);
                                                            gridMatrix.removeGridTopologyPath(gridTopologyPathToUpdate);
                                                            Set<GridTopologyPath> gridTopologyPathsUpdated = gridTopologyPathRepository.findAllByPathIdAndPolicyIdAndIsActive(gridPolicySet.getId(), gridTopologyPath.getPathId(), true);

                                                            gridMatrix.getDestinationGroups().forEach(destinationGroup -> {
                                                                if (destinationGroup.getGridTopologyPathIds().stream().anyMatch(aLong -> aLong == gridTopologyPathToUpdate.getId())) {
                                                                    if (gridTopologyPathsUpdated != null) {
                                                                        gridTopologyPathsUpdated.forEach(gridTopologyPath1 -> {
                                                                            destinationGroup.addGridTopologyPathId(gridTopologyPath1.getId());
                                                                        });
                                                                    }
                                                                    destinationGroup.removeGridTopologyPathId(gridTopologyPathToUpdate.getId());
                                                                    destinationGroupRepository.save(destinationGroup);
                                                                }
                                                            });
                                                            gridMatrixRepository.save(gridMatrix);
                                                            Set<Long> intermediateDeviceIdsOldPath = gridTopologyPathToUpdate.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet());
                                                            Set<Long> intermediateDeviceIds = gridTopologyPath.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet());
                                                            Set<Long> missingIntermediateDevicesFromFailedPath = Sets.difference(intermediateDeviceIdsOldPath, intermediateDeviceIds);
                                                            Set<Long> gridClusterDestinations = Sets.newHashSet();
                                                            gridClusterDestinations.add(destinationDevice.getId());
                                                            if (gridTopologyPathToUpdate.getPathId() != null && gridTopologyPathToUpdate.getIsActive()) {
                                                                deletePath(gridTopologyPathToUpdate.getPathId());
                                                                gridTopologyPathToUpdate.setIsActive(false);
                                                            }
                                                            MatrixUpdated matrixUpdated = new MatrixUpdated();
                                                            Optional<MatrixUpdated> optionalMatrixUpdated = matrixUpdatedSet.stream().filter(matrixUpdated1 -> matrixUpdated1.getGridMatrixId() == gridMatrix.getId()).findAny();
                                                            if (optionalMatrixUpdated.isPresent()) {
                                                                matrixUpdated = optionalMatrixUpdated.get();
                                                            } else {
                                                                matrixUpdatedSet.add(matrixUpdated);
                                                            }
                                                            matrixUpdated.setGridPolicySetId(policySetId);
                                                            matrixUpdated.setGridMatrixId(gridMatrix.getId());
                                                            matrixUpdated.setSourceDeviceId(sourceDevice.getId());
                                                            matrixUpdated.addGridClusterDestinations(gridClusterDestinations);
                                                            matrixUpdated.addIntermediateDeviceIds(intermediateDeviceIds);
                                                            matrixUpdated.addMissingIntermediateDeviceIds(missingIntermediateDevicesFromFailedPath);
                                                        } catch (Exception e) {
                                                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                                                            gridMatrixRepository.save(gridMatrix);
                                                            throw new ValidationException(e.getMessage());
                                                        }
                                                    } else {
                                                        if (gridTopologyPath != null && gridTopologyPath.getPathId() != null && gridTopologyPath.getIsActive()) {
                                                            deletePath(gridTopologyPath.getPathId());
                                                            gridTopologyPath.setIsActive(false);
                                                        }
                                                    }
                                                }
                                            } else {
                                                log.error("updatePolicySetFromGrid distributor : Invalid network path. {}", pathResponseMap);
                                                throw new ValidationException("Invalid network path!");
                                            }
                                        });
                                    }
                                });
                            });
                        } catch (Exception e) {
                            String gridName = gridRepository.findNameById(gridPolicySet.getDeviceGrid().getId());
                            String errorMessage = e.getMessage();
                            if (Strings.isNullOrEmpty(errorMessage)) {
                                errorMessage = "Failed to update the policy.";
                            }
                            log.error("Failed to update the policy {} from grid {}.  cause : {}", gridPolicySet.getId(), gridName, errorMessage);
                            updateEvent(gridPolicySet.getId(), Job.Type.POLICY_UPDATE.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                            gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                            gridPolicySetRepository.save(gridPolicySet);
                            throw new ValidationException(e.getMessage());
                        }
                    }
                });

                matrixUpdatedSet.forEach(matrixUpdated -> {
                    GridMatrix gridMatrix = gridMatrixRepository.findOne(matrixUpdated.gridMatrixId);
                    GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(matrixUpdated.getGridPolicySetId());
                    if (gridMatrix != null) {
                        try {
                            if (gridPolicySet != null) {
                                gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                                gridPolicySetRepository.save(gridPolicySet);
                            }
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                            gridMatrixRepository.save(gridMatrix);
                            List<Long> jobIdsUpdated = Lists.newArrayList();
                            Policy policyFromDb = policyRepository.findOne(gridMatrix.getPolicyId());
                            if (policyFromDb != null) {
                                Policy updatedPolicy = getAggregatorPolicySet(gridPolicySet, policyFromDb, policyFromDb.getDevice(), gridMatrix.getGridTopologyPaths());
                                validateDevicePolicy(updatedPolicy, policyFromDb.getDevice().getName());
                                managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager().savePolicy(updatedPolicy, false);
                                updateToolGroup(matrixUpdated.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE);
                                if (!matrixUpdated.getMissingIntermediateDeviceIds().isEmpty()) {
                                    GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                                    if (gridMatrixHistory != null) {
                                        updateToolAddress(null, null, gridMatrixHistory, matrixUpdated.getMissingIntermediateDeviceIds(), Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE);
                                    }
                                }
                                updateToolAddress(matrixUpdated.getSourceDeviceId(), Sets.newHashSet(matrixUpdated.getGridClusterDestinations()), gridMatrix, matrixUpdated.getIntermediateDeviceIds(), Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                                updateToolGroup(matrixUpdated.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_ADD);

                                long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager().commitPolicy(updatedPolicy, false);
                                if (jobId != -1) {
                                    jobIdsUpdated.add(jobId);
                                }
                            }
                            jobIdsUpdated.forEach(aLong -> {
                                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                                    throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                                }
                            });
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                            gridMatrixRepository.save(gridMatrix);
                            if (gridPolicySet != null) {
                                gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                                gridPolicySetRepository.save(gridPolicySet);
                            }
                        } catch (Exception e) {
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                            gridMatrixRepository.save(gridMatrix);
                            GridPolicySet gridPolicySetInDB = gridPolicySetRepository.findOne(matrixUpdated.getGridPolicySetId());
                            if (gridPolicySetInDB != null) {
                                String gridName = gridRepository.findNameById(gridPolicySetInDB.getDeviceGrid().getId());
                                String errorMessage = e.getMessage();
                                if (Strings.isNullOrEmpty(errorMessage)) {
                                    errorMessage = "Failed to update the policy.";
                                }
                                log.error("Failed to commit the policy {} from grid {}.  cause : {}", gridPolicySetInDB.getId(), gridName, errorMessage);
                                updateEvent(gridPolicySetInDB.getId(), Job.Type.POLICY_UPDATE.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                                gridPolicySetInDB.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                                gridPolicySetRepository.save(gridPolicySetInDB);
                            }
                            throw new ServerException(e.getMessage());
                        }
                    }
                });
            }
        }
    }

    @Data
    class MatrixUpdated {
        Long gridPolicySetId;
        Long gridMatrixId;
        Long sourceDeviceId;
        Set<Long> gridClusterDestinations = Sets.newHashSet();
        Set<Long> missingIntermediateDeviceIds = Sets.newHashSet();
        Set<Long> intermediateDeviceIds = Sets.newHashSet();

        public void addGridClusterDestinations(Set<Long> gridClusterDestinations) {
            this.gridClusterDestinations.addAll(gridClusterDestinations);
        }

        public void addMissingIntermediateDeviceIds(Set<Long> missingIntermediateDeviceIds) {
            this.missingIntermediateDeviceIds.addAll(missingIntermediateDeviceIds);
        }

        public void addIntermediateDeviceIds(Set<Long> intermediateDeviceIds) {
            this.intermediateDeviceIds.addAll(intermediateDeviceIds);
        }
    }

    /**
     * Compare and commits the grid policy by merging and making appropriate changes in pbf destination, pbf destination group and policy.
     *
     * @param gridPolicySet
     * @param gridPolicySetExisting
     * @return
     */
    public List<Long> updatePolicySet(GridPolicySet gridPolicySet, GridPolicySet gridPolicySetExisting) {
        try {
            //compare policy objects
            //find the paths added/deleted (device/tool/tap)
            //request for path if b/w changes or interface added/deleted**
            //update tool address and tool group
            //update policy
            Set<GridClusterRequest> gridClusterSources = Sets.newHashSet();
            Set<GridClusterRequest> gridClusterDestinations = Sets.newHashSet();

            gridPolicySet.getGridPolicies().forEach(gridPolicy -> {
                groupNodeInterfacesByDevice(Sets.newHashSet(gridPolicy.getIngressClusterNodeInterfaces()), gridClusterSources);
                groupNodeInterfacesByDevice(Sets.newHashSet(gridPolicy.getEgressClusterNodeInterfaces()), gridClusterDestinations);
            });

            DecimalFormat df = new DecimalFormat("#");
            df.setRoundingMode(RoundingMode.CEILING);
            Set<GridMatrix> gridMatricesAdded = Sets.newHashSet();
            Set<GridMatrix> gridMatricesDeleted = Sets.newHashSet();
            Set<Long> gridMatrixIdsUpdated = Sets.newHashSet();

            Set<GridMatrix> gridMatrixSetExisting = gridMatrixRepository.findByPolicySetId(gridPolicySet.getId());

            if (!gridMatrixSetExisting.isEmpty()) {
                gridMatrixSetExisting.forEach(gridMatrix -> {
                    Set<GridClusterRequest> gridClusterSourcesFiltered = gridClusterSources.stream().filter(gridClusterRequest -> gridClusterRequest.getDevice().getId() == gridMatrix.getSourceDeviceId()).collect(Collectors.toSet());
                    Set<Long> destinationDeviceIds = gridClusterDestinations.stream().map(gridClusterRequest -> gridClusterRequest.getDevice().getId()).collect(Collectors.toSet());
                    Set<BigInteger> gridMatrixSetIds = gridMatrixRepository.findByPolicySetIdAndSourceAndDestination(gridPolicySet.getId(), gridMatrix.getSourceDeviceId(), destinationDeviceIds);

                    if (gridClusterSourcesFiltered.isEmpty() || gridMatrixSetIds.isEmpty()) {
                        //Remove the matrix
                        gridMatricesDeleted.add(gridMatrix);
                    } else {
                        AtomicBoolean isMatrixUpdated = new AtomicBoolean(false);
                        //check whether interfaces deleted or not from source and destination sides
                        Set<GridTopologyPath> gridTopologyPathsToDelete = Sets.newHashSet();
                        Set<GridTopologyPath> gridTopologyPaths = gridMatrix.getGridTopologyPaths();
                        Map<Long, Set<Long>> gridPathInterfaceIdsRemoved = Maps.newHashMap();
                        gridTopologyPaths.forEach(gridTopologyPath -> {
                            gridClusterSourcesFiltered.forEach(gridClusterRequest -> {
                                Set<Long> sourceInterfaceIds = gridClusterRequest.getClusterNodeInterfaces().stream().map(ClusterNodeInterfaceRequest::getId).collect(Collectors.toSet());
                                Sets.SetView<Long> idsToRemove = Sets.difference(gridTopologyPath.getTapNodeInterfaceIds(), sourceInterfaceIds);
                                if (!idsToRemove.isEmpty()) {
                                    isMatrixUpdated.set(true);
                                    Set<Long> removedInterfaceIds = gridPathInterfaceIdsRemoved.get(gridTopologyPath.getId());
                                    if (removedInterfaceIds == null)
                                        removedInterfaceIds = Sets.newHashSet();
                                    removedInterfaceIds.addAll(idsToRemove);
                                    gridPathInterfaceIdsRemoved.put(gridTopologyPath.getId(), removedInterfaceIds);
                                }
                            });

                            AtomicBoolean isPathPresent = new AtomicBoolean(false);
                            gridClusterDestinations.forEach(gridClusterRequest -> {
                                gridClusterRequest.getClusterNodeInterfaces().forEach(clusterNodeInterfaceRequest -> {
                                    if (gridTopologyPath.getToolNodeInterfaceId() == clusterNodeInterfaceRequest.getId()) {
                                        isPathPresent.set(true);
                                    }
                                });
                            });
                            if (!isPathPresent.get()) {
                                gridTopologyPathsToDelete.add(gridTopologyPath);
                                if (gridTopologyPath.getPathId() != null && gridTopologyPath.getIsActive()) {
                                    deletePath(gridTopologyPath.getPathId());
                                    gridTopologyPath.setIsActive(false);
                                    gridTopologyPathRepository.save(gridTopologyPath);
                                }
                            }
                        });
                        gridPathInterfaceIdsRemoved.forEach((gridTopologyPathId, interfaceIdSet) -> {
                            GridTopologyPath gridTopologyPath = gridTopologyPathRepository.findOne(gridTopologyPathId);
                            interfaceIdSet.forEach(interfaceId -> {
                                gridTopologyPath.removeTapNodeInterfaceId(interfaceId);
                            });
                            gridTopologyPathRepository.save(gridTopologyPath);
                        });
                        if (!gridTopologyPathsToDelete.isEmpty()) {
                            isMatrixUpdated.set(true);
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                            gridMatrix.removeGridTopologyPaths(gridTopologyPathsToDelete);
                            gridMatrixRepository.save(gridMatrix);
                        }
                        if (isMatrixUpdated.get()) {
                            gridMatrixIdsUpdated.add(gridMatrix.getId());
                        }
                    }
                });
            }

            //Remove the deleted matrix from further processing.
            gridClusterSources.forEach(gridClusterSource -> {
                AtomicLong atomicLong = new AtomicLong(0);
                Set<Long> managedObjectIds = Sets.newHashSet();
                gridClusterSource.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                    clusterNodeInterface.getPorts().forEach(port -> {
                        if (!managedObjectIds.contains(port.getId())) {
                            atomicLong.addAndGet(port.getLineSpeed());
                            managedObjectIds.add(port.getId());
                        }
                    });
                    clusterNodeInterface.getPortGroups().forEach(portGroup -> {
                        if (!managedObjectIds.contains(portGroup.getId())) {
                            portGroup.getPorts().forEach(port -> atomicLong.addAndGet(port.getLineSpeed()));
                            managedObjectIds.add(portGroup.getId());
                        }
                    });
                });
                Long bandwidth = Long.parseLong(df.format((atomicLong.get() / 1000)));
                Set<Long> sourceInterfaceIds = gridClusterSource.getClusterNodeInterfaces().stream().map(ClusterNodeInterfaceRequest::getId).collect(Collectors.toSet());
                Set<Long> destinationDeviceIds = gridClusterDestinations.stream().map(gridClusterRequest -> gridClusterRequest.getDevice().getId()).collect(Collectors.toSet());
                Set<BigInteger> gridMatrixSetIds = gridMatrixRepository.findByPolicySetIdAndSourceAndDestination(gridPolicySet.getId(), gridClusterSource.getDevice().getId(), destinationDeviceIds);
                if (gridMatrixSetIds.isEmpty()) {
                    //new grid matrix(es) to be created
                    gridMatricesAdded.add(createMatrix(gridPolicySet, gridClusterSource, gridClusterDestinations));
                } else {
                    //update and delete
                    gridMatrixSetIds.forEach(gridMatrixId -> {
                        GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixId.longValue());
                        AtomicBoolean isMatrixUpdated = new AtomicBoolean(false);
                        Set<GridTopologyPath> gridTopologyPathsToAdd = Sets.newHashSet();
                        Set<GridTopologyPath> gridTopologyPathsToDelete = Sets.newHashSet();
                        Set<GridTopologyPath> gridTopologyPaths = gridMatrix.getGridTopologyPaths();
                        Map<Long, Set<Long>> gridPathInterfaceIdsAdded = Maps.newHashMap();
                        gridClusterDestinations.forEach(gridClusterDestination -> {
                            gridClusterDestination.getClusterNodeInterfaces().forEach(clusterNodeInterfaceRequestDestination -> {
                                Set<GridTopologyPath> gridTopologyPathsFiltered = gridTopologyPaths.stream().filter(gridTopologyPath -> gridTopologyPath.getToolNodeInterfaceId() == clusterNodeInterfaceRequestDestination.getId()).collect(Collectors.toSet());
                                if (gridTopologyPathsFiltered.isEmpty()) {
                                    //no path to the destination, new path to be added
                                    //Update the existing matrix
                                    GridTopologyPath gridTopologyPath = createPath(gridPolicySet, gridClusterSource, gridClusterDestination, clusterNodeInterfaceRequestDestination, bandwidth);
                                    if (gridTopologyPath != null) {
                                        gridTopologyPathsToAdd.add(gridTopologyPath);
                                    }
                                } else {
                                    gridTopologyPathsFiltered.forEach(gridTopologyPathToBeUpdated -> {
                                        if (gridTopologyPathToBeUpdated.getBandwidth() < bandwidth) {
                                            GridTopologyPath gridTopologyPath = createPath(gridPolicySet, gridClusterSource, gridClusterDestination, clusterNodeInterfaceRequestDestination, bandwidth);
                                            if (gridTopologyPath != null) {
                                                isMatrixUpdated.set(true);
                                                gridTopologyPathsToAdd.add(gridTopologyPath);
                                                gridTopologyPathsToDelete.add(gridTopologyPathToBeUpdated);
                                                if (gridTopologyPathToBeUpdated.getPathId() != null && gridTopologyPathToBeUpdated.getIsActive()) {
                                                    deletePath(gridTopologyPathToBeUpdated.getPathId());
                                                    gridTopologyPathToBeUpdated.setIsActive(false);
                                                    gridTopologyPathRepository.save(gridTopologyPathToBeUpdated);
                                                }
                                            }
                                        }
                                    });
                                    gridTopologyPathsFiltered.removeAll(gridTopologyPathsToDelete);
                                    gridTopologyPathsFiltered.forEach(gridTopologyPath -> {
                                        Sets.SetView<Long> idsToAdd = Sets.difference(sourceInterfaceIds, gridTopologyPath.getTapNodeInterfaceIds());
                                        if (!idsToAdd.isEmpty()) {
                                            isMatrixUpdated.set(true);
                                            Set<Long> addedInterfaceIds = gridPathInterfaceIdsAdded.get(gridTopologyPath.getId());
                                            if (addedInterfaceIds == null)
                                                addedInterfaceIds = Sets.newHashSet();
                                            addedInterfaceIds.addAll(idsToAdd);
                                            gridPathInterfaceIdsAdded.put(gridTopologyPath.getId(), addedInterfaceIds);
                                        }
                                    });
                                }
                            });
                        });
                        gridPathInterfaceIdsAdded.forEach((gridTopologyPathId, interfaceIdSet) -> {
                            GridTopologyPath gridTopologyPath = gridTopologyPathRepository.findOne(gridTopologyPathId);
                            interfaceIdSet.forEach(interfaceId -> {
                                gridTopologyPath.addTapNodeInterfaceId(interfaceId);
                            });
                            gridTopologyPathRepository.save(gridTopologyPath);
                        });
                        if (!gridTopologyPathsToAdd.isEmpty()) {
                            isMatrixUpdated.set(true);
                            Set<Integer> toolIdsUsed = gridTopologyPathRepository.getAllToolAddresses();
                            gridTopologyPathsToAdd.forEach(gridTopologyPath -> {
                                Integer toolAddress = getToolId(toolIdsUsed);
                                toolIdsUsed.add(toolAddress);
                                gridTopologyPath.setToolAddress(toolAddress);
                            });
                            gridMatrix.addGridTopologyPaths(gridTopologyPathsToAdd);
                        }
                        if (!gridTopologyPathsToDelete.isEmpty()) {
                            isMatrixUpdated.set(true);
                            gridMatrix.removeGridTopologyPaths(gridTopologyPathsToDelete);
                        }
                        if (isMatrixUpdated.get()) {
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                            gridMatrixRepository.save(gridMatrix);
                            gridMatrixIdsUpdated.add(gridMatrix.getId());
                        }
                    });
                }
            });
            List<Long> jobIdsAll = Lists.newArrayList();
            if (!gridMatricesAdded.isEmpty()) {
                jobIdsAll = commitMatrix(gridMatricesAdded, gridPolicySet);
            }

            if (!gridMatricesDeleted.isEmpty()) {
                jobIdsAll.addAll(deleteMatrixes(gridMatricesDeleted));
                gridMatrixSetExisting.removeAll(gridMatricesDeleted);
            }

            List<Long> jobIdsUpdated = Lists.newArrayList();
            if (!gridMatrixIdsUpdated.isEmpty()) {
                gridMatrixIdsUpdated.forEach(gridMatrixId -> {
                    GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixId);
                    if (gridMatrix != null) {
                        Set<Long> intermediateDeviceIds = Sets.newHashSet();
                        gridMatrix.getGridTopologyPaths().forEach(toolAddressTopologyPathMapping -> {
                            GridTopologyPath gridTopologyPathDb = gridTopologyPathRepository.findOne(toolAddressTopologyPathMapping.getId());
                            if (gridTopologyPathDb != null) {
                                intermediateDeviceIds.addAll(gridTopologyPathDb.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                            }
                        });
                        Policy policyFromDb = policyRepository.findOne(gridMatrix.getPolicyId());
                        if (policyFromDb != null) {
                            Policy updatedPolicy = getAggregatorPolicySet(gridPolicySet, policyFromDb, policyFromDb.getDevice(), gridMatrix.getGridTopologyPaths());
                            validateDevicePolicy(updatedPolicy, policyFromDb.getDevice().getName());
                            Set<DestinationGroup> destinationGroups = generateAndSetGroupIds(updatedPolicy, gridPolicySet, gridMatrix, Sets.newHashSet(gridMatrix.getDestinationGroups()), gridMatrix.getGridTopologyPaths());
                            gridMatrix.setDestinationGroups(destinationGroups);
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                            gridMatrixRepository.save(gridMatrix);

                            Set<Long> intermediateDeviceIdsOldPath = Sets.newHashSet();
                            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                            if (gridMatrixHistory != null) {
                                gridMatrixHistory.getGridTopologyPaths().forEach(toolAddressTopologyPathMapping -> {
                                    intermediateDeviceIdsOldPath.addAll(toolAddressTopologyPathMapping.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                                });
                                Set<Long> missingIntermediateDevicesFromFailedPath = Sets.difference(intermediateDeviceIdsOldPath, intermediateDeviceIds);
                                if (!missingIntermediateDevicesFromFailedPath.isEmpty()) {
                                    updateToolAddress(null, null, gridMatrixHistory, missingIntermediateDevicesFromFailedPath, Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE);
                                }
                            }
                            updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE);
                            updateToolAddress(gridMatrix.getSourceDeviceId(), Sets.newHashSet(gridMatrix.getDestinationDeviceIds()), gridMatrix, intermediateDeviceIds, Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                            updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_ADD);

                            long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager().commitPolicy(updatedPolicy, false);
                            if (jobId != -1) {
                                jobIdsUpdated.add(jobId);
                            }
                        }
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                        gridMatrixRepository.save(gridMatrix);
                    }
                });
                gridMatrixSetExisting = gridMatrixSetExisting.stream().filter(gridMatrix -> !gridMatrixIdsUpdated.contains(gridMatrix.getId())).collect(Collectors.toSet());
            }
            if (!gridMatrixSetExisting.isEmpty()) {
                gridMatrixSetExisting.forEach(gridMatrixObject -> {
                    GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixObject.getId());
                    if (gridMatrix != null) {
                        Policy policyFromDb = policyRepository.findOne(gridMatrix.getPolicyId());
                        Set<Long> intermediateDeviceIds = Sets.newHashSet();
                        gridMatrix.getGridTopologyPaths().forEach(toolAddressTopologyPathMapping -> {
                            GridTopologyPath gridTopologyPathDb = gridTopologyPathRepository.findOne(toolAddressTopologyPathMapping.getId());
                            if (gridTopologyPathDb != null) {
                                intermediateDeviceIds.addAll(gridTopologyPathDb.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                            }
                        });
                        if (policyFromDb != null) {
                            Policy updatedPolicy = getAggregatorPolicySet(gridPolicySet, policyFromDb, policyFromDb.getDevice(), gridMatrix.getGridTopologyPaths());
                            validateDevicePolicy(updatedPolicy, policyFromDb.getDevice().getName());
                            Set<DestinationGroup> destinationGroups = generateAndSetGroupIds(updatedPolicy, gridPolicySet, gridMatrix, Sets.newHashSet(gridMatrix.getDestinationGroups()), gridMatrix.getGridTopologyPaths());
                            gridMatrix.setDestinationGroups(destinationGroups);
                            gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                            gridMatrixRepository.save(gridMatrix);
                            Set<Long> intermediateDeviceIdsOldPath = Sets.newHashSet();
                            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                            if (gridMatrixHistory != null) {
                                gridMatrixHistory.getGridTopologyPaths().forEach(toolAddressTopologyPathMapping -> {
                                    intermediateDeviceIdsOldPath.addAll(toolAddressTopologyPathMapping.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                                });
                                Set<Long> missingIntermediateDevicesFromFailedPath = Sets.difference(intermediateDeviceIdsOldPath, intermediateDeviceIds);
                                if (!missingIntermediateDevicesFromFailedPath.isEmpty()) {
                                    updateToolAddress(null, null, gridMatrixHistory, missingIntermediateDevicesFromFailedPath, Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE);
                                }
                            }
                            updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE);
                            updateToolAddress(gridMatrix.getSourceDeviceId(), Sets.newHashSet(gridMatrix.getDestinationDeviceIds()), gridMatrix, intermediateDeviceIds, Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                            updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_ADD);
                            long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager().commitPolicy(updatedPolicy, false);
                            if (jobId != -1) {
                                jobIdsUpdated.add(jobId);
                            }
                        }
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                        gridMatrixRepository.save(gridMatrix);
                    }
                });
            }
            jobIdsUpdated.forEach(aLong -> {
                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                }
            });
            jobIdsAll.addAll(jobIdsUpdated);
            return jobIdsAll;
        } catch (Exception e) {
            GridPolicySet gridPolicySetInDB = gridPolicySetRepository.findOne(gridPolicySet.getId());
            if (gridPolicySetInDB != null) {
                String gridName = gridRepository.findNameById(gridPolicySetInDB.getDeviceGrid().getId());
                String errorMessage = e.getMessage();
                if (Strings.isNullOrEmpty(errorMessage)) {
                    errorMessage = "Failed to update the policy.";
                }
                log.error("Failed to update the policy {}.  cause : {}", gridPolicySetInDB.getId(), errorMessage);
                updateEvent(gridPolicySetInDB.getId(), Job.Type.POLICY_UPDATE.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.CRITICAL);
                gridPolicySetInDB.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                gridPolicySetRepository.save(gridPolicySetInDB);
            }
            throw new ServerException(e.getMessage());
        }
    }

    /**
     * Update the path failed policy by requesting new path and making relevant changes in pbf destination, pbf destination group and policies.
     *
     * @param pathId
     */
    public void updatePathFailedPolicy(Long pathId, boolean isAuto) {
        Set<GridTopologyPath> gridTopologyPathsFailed = gridTopologyPathRepository.findAllByPathIdAndIsActive(pathId, false);
        if (gridTopologyPathsFailed != null) {
            log.debug("updating the failed topology path {}, isAuto {}", pathId, isAuto);
            gridTopologyPathsFailed.forEach(gridTopologyPathFailedDb -> {
                AtomicBoolean isSuccessful = new AtomicBoolean(true);
                AtomicBoolean isPathSwitchLimitExceeded = new AtomicBoolean(false);

                AtomicLong matrixId = new AtomicLong();
                AtomicLong gridPolicySetId = new AtomicLong();
                AtomicLong sourceDeviceId = new AtomicLong();
                AtomicLong destinationDeviceId = new AtomicLong();

                AtomicBoolean isSourceNodeUpdated = new AtomicBoolean(false);
                AtomicBoolean isToolGroupUpdatedDeleteRequired = new AtomicBoolean(false);
                AtomicBoolean isToolGroupUpdatedAddRequired = new AtomicBoolean(false);
                AtomicBoolean isToolAddressUpdatedRequiredSource = new AtomicBoolean(false);
                AtomicBoolean isToolAddressUpdatedRequiredDestination = new AtomicBoolean(false);

                Set<Long> intermediateDeviceIds = Sets.newHashSet();
                Set<Long> intermediateDeviceIdsForToolAddress = Sets.newHashSet();
                Set<Long> missingIntermediateDevicesFromFailedPath = Sets.newHashSet();
                Map<Long, Set<Long>> intermediateNodesOldManagedObjectSet = Maps.newHashMap();

                TransactionTemplate transactionRw = new TransactionTemplate(transactionManager);
                transactionRw.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
                transactionRw.execute(new TransactionCallbackWithoutResult() {
                    @Override
                    protected void doInTransactionWithoutResult(TransactionStatus status) {
                        GridTopologyPath gridTopologyPathFailed = gridTopologyPathRepository.findOne(gridTopologyPathFailedDb.getId());
                        GridMatrix gridMatrix = gridMatrixRepository.findByTopologyPathId(gridTopologyPathFailed.getId());
                        if (gridMatrix != null) {
                            matrixId.set(gridMatrix.getId());
                            GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(gridMatrix.getGridPolicySetId());
                            try {
                                if (isAuto && networkPathSwitchAutoLimit != 0 && gridMatrix.getFailureCount() >= networkPathSwitchAutoLimit) {
                                    Long gridId = gridPolicySetRepository.findGridIdById(gridPolicySet.getId());
                                    String gridName = gridRepository.findNameById(gridId);
                                    isPathSwitchLimitExceeded.set(true);
                                    updateEvent(gridPolicySet.getId(), Job.Type.NETWORK_PATH_SWITCH_MANUAL.toString(), gridName, Job.Status.FAILED.toString(), "Network path switch limit (1) exceeded. Please click try me button to retry.", Event.Severity.MAJOR);
                                    log.error("Network path switch limit (" + networkPathSwitchAutoLimit + ") exceeded: {}, pathId {}", gridMatrix.getFailureCount(), pathId);
                                    throw new ValidationException("Aborting! Network path switch limit (" + networkPathSwitchAutoLimit + ") exceeded. Please click Try Me button to retry.");
                                }
                            } catch (Exception e) {
                                isSuccessful.set(false);
                            }

                            if (!isPathSwitchLimitExceeded.get()) {
                                gridPolicySetId.set(gridPolicySet.getId());
                                ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                                try {
                                    if (WorkflowParticipant.WorkflowStatus.ERROR == gridPolicySet.getWorkflowStatus()) {
                                        log.error("Path cannot be updated as grid policy {} is in error state.", gridPolicySet.getId());
                                        throw new ValidationException("Cannot update policy " + gridPolicySet.getName() + " as policy is in error state. Please recover the policy and try again.");
                                    }
                                    if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySet.getWorkflowStatus()) {
                                        log.error("Path cannot be updated as grid policy {} is in submitted state.", gridPolicySet.getId());
                                        throw new ValidationException("Cannot update policy " + gridPolicySet.getName() + " as policy is in submitted state. Please try after sometime.");
                                    }
                                    if (WorkflowParticipant.WorkflowStatus.ACTIVE == gridPolicySet.getWorkflowStatus()) {
                                        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                                        gridPolicySetRepository.save(gridPolicySet);
                                        NetworkNode sourceNetworkNode = gridTopologyPathFailed.getSourceNetworkNode();
                                        NetworkNode destinationNetworkNode = gridTopologyPathFailed.getDestinationNetworkNode();
                                        Device sourceDevice = sourceNetworkNode.getDevice();
                                        Device destinationDevice = destinationNetworkNode.getDevice();
                                        sourceDeviceId.set(sourceDevice.getId());
                                        destinationDeviceId.set(destinationDevice.getId());

                                        Set<Port> sourceNodeIngressPorts = sourceNetworkNode.getIngressPorts();
                                        Set<PortGroup> sourceNodeIngressPortGroups = sourceNetworkNode.getIngressPortGroups();
                                        Set<Port> destinationNodeEgressPorts = destinationNetworkNode.getEgressPorts();
                                        Set<PortGroup> destinationNodeEgressPortGroups = destinationNetworkNode.getEgressPortGroups();

                                        lock.writeLock().lock();
                                        Map<String, Object> pathResponseMap = getTopologyPath(sourceDevice.getChassis(), destinationDevice.getChassis(), null, null, gridTopologyPathFailed.getBandwidth(), gridPolicySet.getIsCspfEnabled());
                                        log.debug("updatePathFailedPolicy : New path response between source id {} and destination id {} is {}", sourceDevice.getId(), destinationDevice.getId(), pathResponseMap);
                                        if (pathResponseMap != null && !pathResponseMap.isEmpty()) {
                                            GridTopologyPath gridTopologyPath = parsePathResponseAndMakeTopology(pathResponseMap, sourceNodeIngressPorts, sourceNodeIngressPortGroups, destinationNodeEgressPorts, destinationNodeEgressPortGroups,
                                                    gridPolicySet.getIsOverSubscriptionAllowed(), sourceDevice.getName(), destinationDevice.getName());
                                            if (gridTopologyPath != null) {
                                                if (gridTopologyPath.getPathId() != null && gridTopologyPathRepository.findByPathIdAndIsActive(gridTopologyPath.getPathId(), true) != null) {
                                                    if (!isAuto || gridTopologyPath.getPathId() != gridTopologyPathFailed.getPathId()) {
                                                        log.error("Network path id {} already exists! Try restarting the Visibility Manager service to sync with TME.", gridTopologyPath.getPathId());
                                                        throw new ValidationException("Network path already exists.");
                                                    }
                                                }
                                                Set<Long> egressPortsSourceOld = networkNodeRepository.findEgressByNodeId(gridTopologyPathFailed.getSourceNetworkNode().getId()).stream().map(BigInteger::longValue).collect(Collectors.toSet());
                                                Set<Long> egressPortsDestinationOld = networkNodeRepository.findEgressByNodeId(gridTopologyPathFailed.getDestinationNetworkNode().getId()).stream().map(BigInteger::longValue).collect(Collectors.toSet());
                                                Set<IntermediateNode> intermediateNodesOld = gridTopologyPathFailed.getIntermediateNodes();
                                                intermediateNodesOld.forEach(intermediateNode -> {
                                                    Set<Long> intermediateEgressPortsNew = Sets.newHashSet();
                                                    if (intermediateNodesOldManagedObjectSet.containsKey(intermediateNode.getId())) {
                                                        intermediateEgressPortsNew = intermediateNodesOldManagedObjectSet.get(intermediateNode.getId());
                                                    }
                                                    intermediateEgressPortsNew.addAll(intermediateNode.getEgressPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                                                    intermediateEgressPortsNew.addAll(intermediateNode.getEgressPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                                                    intermediateNodesOldManagedObjectSet.put(intermediateNode.getId(), intermediateEgressPortsNew);
                                                });

                                                gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                                                Set<Integer> toolIdsUsed = gridTopologyPathRepository.getAllToolAddresses();
                                                gridTopologyPath.setBandwidth(gridTopologyPathFailed.getBandwidth());
                                                gridTopologyPath.setToolAddress(getToolId(toolIdsUsed));
                                                gridTopologyPath.setIsCspfEnabled(gridPolicySet.getIsCspfEnabled());
                                                gridTopologyPath.setTapNodeInterfaceIds(Sets.newHashSet(gridTopologyPathFailed.getTapNodeInterfaceIds()));
                                                gridTopologyPath.setToolNodeInterfaceId(gridTopologyPathFailed.getToolNodeInterfaceId());
                                                gridTopologyPath.setPolicySetId(gridPolicySet.getId());
                                                gridMatrix.addGridTopologyPath(gridTopologyPath);
                                                gridTopologyPathRepository.save(gridTopologyPath);
                                                gridMatrix.removeGridTopologyPath(gridTopologyPathFailed);
                                                if (isAuto) {
                                                    gridMatrix.setFailureCount(gridMatrix.getFailureCount() + 1);
                                                }
                                                Set<GridTopologyPath> gridTopologyPathsUpdated = gridTopologyPathRepository.findAllByPathIdAndPolicyIdAndIsActive(gridPolicySet.getId(), gridTopologyPath.getPathId(), true);

                                                gridMatrix.getDestinationGroups().forEach(destinationGroup -> {
                                                    if (destinationGroup.getGridTopologyPathIds().stream().anyMatch(aLong -> aLong == gridTopologyPathFailed.getId())) {
                                                        if (gridTopologyPathsUpdated != null) {
                                                            gridTopologyPathsUpdated.forEach(gridTopologyPath1 -> {
                                                                destinationGroup.addGridTopologyPathId(gridTopologyPath1.getId());
                                                            });
                                                        }
                                                        destinationGroup.removeGridTopologyPathId(gridTopologyPathFailed.getId());
                                                        destinationGroupRepository.save(destinationGroup);
                                                    }
                                                });
                                                gridMatrixRepository.save(gridMatrix);
                                                Set<Long> intermediateDeviceIdsOldPath = intermediateNodesOld.stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet());
                                                intermediateDeviceIds.addAll(gridTopologyPath.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                                                missingIntermediateDevicesFromFailedPath.addAll(Sets.difference(intermediateDeviceIdsOldPath, intermediateDeviceIds));

                                                NetworkNode networkNodeSourceNew = networkNodeRepository.findOne(gridTopologyPath.getSourceNetworkNode().getId());
                                                Set<Long> egressPortsSourceNew = networkNodeSourceNew.getEgressPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                                                egressPortsSourceNew.addAll(networkNodeSourceNew.getEgressPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));

                                                NetworkNode networkNodeDestinationNew = networkNodeRepository.findOne(gridTopologyPath.getDestinationNetworkNode().getId());
                                                Set<Long> egressPortsDestinationNew = networkNodeDestinationNew.getEgressPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                                                egressPortsDestinationNew.addAll(networkNodeDestinationNew.getEgressPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));

                                                Set<IntermediateNode> intermediateNodesNew = gridTopologyPath.getIntermediateNodes();

                                                boolean isIntermediateOrDestinationNodeUpdated = compareTopologyPaths(egressPortsDestinationNew, egressPortsDestinationOld, intermediateNodesNew, intermediateNodesOld, intermediateNodesOldManagedObjectSet);
                                                if ((!Sets.difference(egressPortsSourceNew, egressPortsSourceOld).isEmpty() || !Sets.difference(egressPortsSourceOld, egressPortsSourceNew).isEmpty())) {
                                                    isSourceNodeUpdated.set(true);
                                                }
                                                if (isSourceNodeUpdated.get() || isIntermediateOrDestinationNodeUpdated) {
                                                    isToolGroupUpdatedDeleteRequired.set(isUpdateToolGroupAddressRequired(gridMatrix, sourceDevice.getId(), false));

                                                    isToolAddressUpdatedRequiredSource.set(isUpdateToolAddressRequired(gridMatrix, sourceDevice.getId()));
                                                    isToolAddressUpdatedRequiredDestination.set(isUpdateToolAddressRequired(gridMatrix, destinationDevice.getId()));
                                                    intermediateDeviceIds.forEach(intermediateDeviceId -> {
                                                        if (isUpdateToolAddressRequired(gridMatrix, intermediateDeviceId)) {
                                                            intermediateDeviceIdsForToolAddress.add(intermediateDeviceId);
                                                        }
                                                    });
                                                    isToolGroupUpdatedAddRequired.set(isUpdateToolGroupAddressRequired(gridMatrix, sourceDevice.getId(), true));
                                                }
                                                if (isSourceNodeUpdated.get()) {
                                                    Policy policyFromDb = policyRepository.findOne(gridMatrix.getPolicyId());
                                                    Policy updatedPolicy = getAggregatorPolicySet(gridPolicySet, policyFromDb, policyFromDb.getDevice(), gridMatrix.getGridTopologyPaths());
                                                    validateDevicePolicy(updatedPolicy, policyFromDb.getDevice().getName());
                                                    long jobId = managerBuilder.getOperationsFactory(policyFromDb.getDevice()).getPolicyManager().savePolicy(updatedPolicy, false);
                                                }
                                            } else {
                                                isSuccessful.set(false);
                                                throw new ValidationException("Path not found.");
                                            }
                                        } else {
                                            isSuccessful.set(false);
                                            log.error("Invalid network path. {}", pathResponseMap);
                                            throw new ValidationException("Invalid network path!");
                                        }
                                    }
                                } catch (Exception e) {
                                    log.error("Failed to switch path for path id {}.  cause : {}", pathId, e.getMessage());
                                    Long gridId = gridPolicySetRepository.findGridIdById(gridPolicySet.getId());
                                    String gridName = gridRepository.findNameById(gridId);
                                    String errorMessage = e.getMessage();
                                    if (Strings.isNullOrEmpty(errorMessage)) {
                                        errorMessage = "Failed to switch network path.";
                                    }
                                    if (isAuto) {
                                        updateEvent(gridPolicySet.getId(), Job.Type.NETWORK_PATH_SWITCH_AUTO.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                                    } else {
                                        updateEvent(gridPolicySet.getId(), Job.Type.NETWORK_PATH_SWITCH_MANUAL.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                                    }
                                    isSuccessful.set(false);
                                } finally {
                                    try {
                                        if (lock.writeLock().isHeldByCurrentThread()) {
                                            lock.writeLock().unlock();
                                        }
                                    } catch (IllegalMonitorStateException e) {
                                        log.error("IllegalMonitorStateException thrown by lock.");
                                    }
                                    if (isSuccessful.get() == false) {
                                        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                                        gridPolicySetRepository.save(gridPolicySet);
                                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                                        gridMatrixRepository.save(gridMatrix);
                                    }
                                }
                            }
                        } else {
                            log.error("No policy found on the failed path id {}.", pathId);
                        }
                    }
                });

                if (isSuccessful.get()) {
                    GridMatrix gridMatrix = gridMatrixRepository.findOne(matrixId.get());
                    GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(gridPolicySetId.get());
                    gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                    gridPolicySetRepository.save(gridPolicySet);
                    try {
                        if (isToolGroupUpdatedDeleteRequired.get()) {
                            commitToolGroup(sourceDeviceId.get(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE);
                        }
                        List<Long> jobIdToolAddressDelete = Lists.newArrayList();
                        if (!missingIntermediateDevicesFromFailedPath.isEmpty()) {
                            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
                            if (gridMatrixHistory != null) {
                                missingIntermediateDevicesFromFailedPath.forEach(deviceId -> {
                                    Long jobId = commitToolAddress(deviceId, gridMatrixHistory, Job.Type.GRID_TOOL_ADDRESS_DELETE_OLD_ACTIVE);
                                    if (jobId != -1) {
                                        jobIdToolAddressDelete.add(jobId);
                                    }
                                });
                            }
                        }
                        jobIdToolAddressDelete.forEach(aLong -> {
                            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                            }
                        });
                        List<Long> jobIdToolAddressUpdate = Lists.newArrayList();
                        if (isToolAddressUpdatedRequiredSource.get()) {
                            Long jobId = commitToolAddress(sourceDeviceId.get(), gridMatrix, Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                            if (jobId != -1) {
                                jobIdToolAddressUpdate.add(jobId);
                            }
                        }
                        if (isToolAddressUpdatedRequiredDestination.get()) {
                            Long jobId = commitToolAddress(destinationDeviceId.get(), gridMatrix, Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                            if (jobId != -1) {
                                jobIdToolAddressUpdate.add(jobId);
                            }
                        }
                        intermediateDeviceIdsForToolAddress.forEach(deviceId -> {
                            Long jobId = commitToolAddress(deviceId, gridMatrix, Job.Type.GRID_TOOL_ADDRESS_UPDATE);
                            if (jobId != -1) {
                                jobIdToolAddressUpdate.add(jobId);
                            }
                        });
                        jobIdToolAddressUpdate.forEach(aLong -> {
                            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                            }
                        });
                        if (isToolGroupUpdatedAddRequired.get()) {
                            commitToolGroup(sourceDeviceId.get(), gridMatrix, Job.Type.GRID_TOOL_GROUP_UPDATE_ADD);
                        }
                        if (isSourceNodeUpdated.get()) {
                            List<Long> jobIdsAdded = Lists.newArrayList();
                            if (gridMatrix.getPolicyId() != null) {
                                List<Long> impactedObjectIds = Lists.newArrayList();
                                impactedObjectIds.add(gridMatrix.getId());
                                Policy aggregatorPolicy = policyRepository.findOne(gridMatrix.getPolicyId());
                                if (aggregatorPolicy != null) {
                                    long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.POLICY_UPDATE).deviceId(aggregatorPolicy.getDevice().getId())
                                            .parentObjectId(aggregatorPolicy.getId()).impactedObjectIds(impactedObjectIds).build());
                                    if (jobId != -1) {
                                        jobIdsAdded.add(jobId);
                                    }
                                }
                            }
                            jobIdsAdded.forEach(aLong -> {
                                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                                    throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                                }
                            });
                        }
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                        gridMatrixRepository.save(gridMatrix);
                        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                        gridPolicySetRepository.save(gridPolicySet);
                        log.debug("Path switched successfully between {} and {}", sourceDeviceId.get(), destinationDeviceId.get());

                        if (isAuto) {
                            Long gridId = gridPolicySetRepository.findGridIdById(gridPolicySetId.get());
                            String gridName = gridRepository.findNameById(gridId);
                            updateEvent(gridPolicySet.getId(), Job.Type.NETWORK_PATH_SWITCH_AUTO.toString(), gridName, Job.Status.SUCCESS.toString(), "Network path switched successfully.", Event.Severity.INFO);
                        }
                    } catch (Exception e) {
                        log.error("Failed to switch path for path id {}.  cause : {}", pathId, e.getMessage());
                        Long gridId = gridPolicySetRepository.findGridIdById(gridPolicySetId.get());
                        String gridName = gridRepository.findNameById(gridId);
                        String errorMessage = e.getMessage();
                        if (Strings.isNullOrEmpty(errorMessage)) {
                            errorMessage = "Failed to switch network path.";
                        }
                        if (isAuto) {
                            updateEvent(gridPolicySetId.get(), Job.Type.NETWORK_PATH_SWITCH_AUTO.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                        } else {
                            updateEvent(gridPolicySetId.get(), Job.Type.NETWORK_PATH_SWITCH_MANUAL.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
                        }
                        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                        gridPolicySetRepository.save(gridPolicySet);
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                        gridMatrixRepository.save(gridMatrix);
                    }
                }
            });
        } else {
            log.error("Topology path switch : Failed path id {} not found in db.", pathId);
        }
    }

    /**
     * Deletes the pbf destination, pbf destination group and policies associated to a matrix.
     *
     * @param gridMatrixSet
     * @return
     */
    private List<Long> deleteMatrixes(Set<GridMatrix> gridMatrixSet) {
        List<Long> jobIds = Lists.newArrayList();
        if (gridMatrixSet != null && !gridMatrixSet.isEmpty()) {
            gridMatrixSet.forEach(gridMatrix -> {
                if (gridMatrix.getSourceDeviceId() != null && deviceRepository.findIdByIdAndIsDeleted(gridMatrix.getSourceDeviceId(), true) != null) {
                    String deviceName = deviceRepository.findNameById(gridMatrix.getSourceDeviceId());
                    String message = "Deletion/addition of device " + deviceName + " in StableNet has altered the grid. Recreate the grid as no other modifications can be made to this grid.";
                    throw new ValidationException(message);
                }
                gridMatrix.getDestinationDeviceIds().forEach(deviceId -> {
                    if (deviceId != null && deviceRepository.findIdByIdAndIsDeleted(deviceId, true) != null) {
                        String deviceName = deviceRepository.findNameById(deviceId);
                        String message = "Deletion/addition of device " + deviceName + " in StableNet has altered the grid. Recreate the grid as no other modifications can be made to this grid.";
                        throw new ValidationException(message);
                    }
                });
            });
            gridMatrixSet.forEach(gridMatrix -> {
                jobIds.addAll(deleteMatrixPolicy(gridMatrix));
            });
            jobIds.forEach(aLong -> {
                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                }
            });
            jobIds.clear();
            //cleaning the device policies in draft
            gridMatrixSet.forEach(gridMatrix -> {
                jobIds.addAll(deleteMatrixPolicy(gridMatrix));
            });
            jobIds.forEach(aLong -> {
                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                }
            });
            gridMatrixSet.forEach(gridMatrixObj -> {
                GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixObj.getId());
                if (gridMatrix != null) {
                    gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                    gridMatrix.setWorkflowType(Job.Type.POLICY_DELETE);
                    gridMatrixRepository.save(gridMatrix);
                    Set<Long> intermediateDeviceIds = Sets.newHashSet();
                    Set<GridTopologyPath> gridTopologyPaths = gridMatrix.getGridTopologyPaths();
                    if (gridTopologyPaths != null && !gridTopologyPaths.isEmpty()) {
                        gridTopologyPaths.forEach(gridTopologyPath -> {
                            GridTopologyPath gridTopologyPathCurrent = gridTopologyPathRepository.findOne(gridTopologyPath.getId());
                            intermediateDeviceIds.addAll(gridTopologyPathCurrent.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                            if (gridTopologyPathCurrent.getPathId() != null && gridTopologyPathCurrent.getIsActive()) {
                                deletePath(gridTopologyPathCurrent.getPathId());
                            }
                        });
                    }
                    updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_DELETE);
                    updateToolAddress(gridMatrix.getSourceDeviceId(), Sets.newHashSet(gridMatrix.getDestinationDeviceIds()), gridMatrix, intermediateDeviceIds, Job.Type.GRID_TOOL_ADDRESS_DELETE);
                    log.debug("Deletion of grid matrix {} completed for gird policyset {}", gridMatrix.getId(), gridMatrix.getGridPolicySetId());
                }
            });
            gridMatrixSet.forEach(gridMatrixObj -> {
                GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixObj.getId());
                if (gridMatrix != null) {
                    gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                    gridMatrix.setWorkflowType(Job.Type.POLICY_DELETE);
                    gridMatrixRepository.delete(gridMatrix);
                }
            });
        }
        return jobIds;
    }

    /**
     * Deletes the grid policies from individual devices.
     *
     * @param gridMatrix
     * @return
     */
    private List<Long> deleteMatrixPolicy(GridMatrix gridMatrix) {
        List<Long> jobIds = Lists.newArrayList();
        if (gridMatrix.getSourceDeviceId() != null) {
            Device device = deviceRepository.findById(gridMatrix.getSourceDeviceId());
            if (device != null && gridMatrix.getPolicyId() != null) {
                Policy policyToDelete = policyRepository.findOne(gridMatrix.getPolicyId());
                if (policyToDelete != null) {
                    Long jobId = managerBuilder.getOperationsFactory(device).getPolicyManager().deletePolicy(policyToDelete.getId(), false, false);
                    if (jobId != -1) {
                        jobIds.add(jobId);
                    }
                }
            }
        }
        return jobIds;
    }

    /**
     * Deletes the grid policy by removing pbf destination, pbf destination group and policies for each matrixes.
     *
     * @param gridPolicySet
     * @param isDeletePolicy
     * @return
     */
    public List<Long> deletePolicySet(GridPolicySet gridPolicySet, boolean isDeletePolicy) {
        List<Long> jobIds = Lists.newArrayList();
        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
        gridPolicySetRepository.save(gridPolicySet);
        List<Long> impactedObjectIds = Lists.newArrayList();
        impactedObjectIds.add(gridPolicySet.getId());
        try {
            Set<GridMatrix> gridMatrixSet = gridMatrixRepository.findByPolicySetId(gridPolicySet.getId());
            if (gridMatrixSet != null && !gridMatrixSet.isEmpty()) {
                jobIds = deleteMatrixes(gridMatrixSet);
            }
            if (isDeletePolicy) {
                gridPolicySetRepository.delete(gridPolicySet.getId());
            } else {
                gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                gridPolicySetRepository.save(gridPolicySet);
            }
            return jobIds;
        } catch (Exception e) {
            GridPolicySet gridPolicySetInDB = gridPolicySetRepository.findOne(gridPolicySet.getId());
            if (gridPolicySetInDB != null) {
                String gridName = gridRepository.findNameById(gridPolicySetInDB.getDeviceGrid().getId());
                String errorMessage = e.getMessage();
                if (Strings.isNullOrEmpty(errorMessage)) {
                    errorMessage = "Failed to delete policy.";
                }
                log.error("Failed to delete grid policy {} for grid {}.  cause : {}", gridPolicySetInDB.getId(), gridName, errorMessage);
                gridPolicySetInDB.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                gridPolicySetRepository.save(gridPolicySetInDB);
                Set<GridMatrix> gridMatrixSet = gridMatrixRepository.findByPolicySetId(gridPolicySetInDB.getId());
                gridMatrixSet.forEach(gridMatrix -> {
                    gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                    gridMatrixRepository.save(gridMatrix);
                });
                updateEvent(gridPolicySetInDB.getId(), Job.Type.POLICY_DELETE.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.CRITICAL);
            }
            throw new ServerException(e.getMessage());
        }
    }

    /**
     * Rollback the grid policy configuration.
     *
     * @param gridPolicySet
     */
    public void rollbackPolicySet(GridPolicySet gridPolicySet) {
        gridPolicySet.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
        gridPolicySetRepository.save(gridPolicySet);
        List<Long> impactedObjectIds = Lists.newArrayList();
        impactedObjectIds.add(gridPolicySet.getId());
        List<Long> jobIds = Lists.newArrayList();
        try {
            Set<GridMatrix> gridMatrixSet = gridMatrixRepository.findByPolicySetId(gridPolicySet.getId());
            if (gridMatrixSet != null && !gridMatrixSet.isEmpty()) {
                gridMatrixSet.forEach(gridMatrix -> {
                    if (gridMatrix.getSourceDeviceId() != null && deviceRepository.findIdByIdAndIsDeleted(gridMatrix.getSourceDeviceId(), true) != null) {
                        String deviceName = deviceRepository.findNameById(gridMatrix.getSourceDeviceId());
                        String message = "Deletion/addition of device " + deviceName + " in StableNet has altered the grid. Recreate the grid as no other modifications can be made to this grid.";
                        throw new ValidationException(message);
                    }
                    gridMatrix.getDestinationDeviceIds().forEach(deviceId -> {
                        if (deviceId != null && deviceRepository.findIdByIdAndIsDeleted(deviceId, true) != null) {
                            String deviceName = deviceRepository.findNameById(deviceId);
                            String message = "Deletion/addition of device " + deviceName + " in StableNet has altered the grid. Recreate the grid as no other modifications can be made to this grid.";
                            throw new ValidationException(message);
                        }
                    });
                });
                gridMatrixSet.forEach(gridMatrix -> {
                    jobIds.addAll(deleteMatrixPolicy(gridMatrix));
                });
                jobIds.forEach(aLong -> {
                    Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                    if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                        throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                    }
                });
                jobIds.clear();
                //cleaning the device policies in draft
                gridMatrixSet.forEach(gridMatrix -> {
                    jobIds.addAll(deleteMatrixPolicy(gridMatrix));
                });
                jobIds.forEach(aLong -> {
                    Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                    if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                        throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
                    }
                });
                gridMatrixSet.forEach(gridMatrixObj -> {
                    GridMatrix gridMatrix = gridMatrixRepository.findOne(gridMatrixObj.getId());
                    if (gridMatrix != null) {
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                        gridMatrix.setWorkflowType(Job.Type.POLICY_ROLLBACK);
                        gridMatrixRepository.save(gridMatrix);
                        Set<Long> intermediateDeviceIds = Sets.newHashSet();
                        Set<GridTopologyPath> gridTopologyPaths = gridMatrix.getGridTopologyPaths();
                        if (gridTopologyPaths != null && !gridTopologyPaths.isEmpty()) {
                            gridTopologyPaths.forEach(gridTopologyPath -> {
                                GridTopologyPath gridTopologyPathCurrent = gridTopologyPathRepository.findOne(gridTopologyPath.getId());
                                intermediateDeviceIds.addAll(gridTopologyPathCurrent.getIntermediateNodes().stream().map(IntermediateNode::getDevice).map(Device::getId).collect(Collectors.toSet()));
                                if (gridTopologyPathCurrent.getPathId() != null && gridTopologyPathCurrent.getIsActive()) {
                                    deletePath(gridTopologyPathCurrent.getPathId());
                                }
                            });
                        }
                        updateToolGroup(gridMatrix.getSourceDeviceId(), gridMatrix, Job.Type.GRID_TOOL_GROUP_ROLLBACK);
                        updateToolAddress(gridMatrix.getSourceDeviceId(), Sets.newHashSet(gridMatrix.getDestinationDeviceIds()), gridMatrix, intermediateDeviceIds, Job.Type.GRID_TOOL_ADDRESS_ROLLBACK);
                    }
                });
                Set<GridMatrix> gridMatrixSetDb = gridMatrixRepository.findByPolicySetId(gridPolicySet.getId());
                if (!gridMatrixSetDb.isEmpty()) {
                    gridMatrixSetDb.forEach(gridMatrix -> {
                        gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                        gridMatrix.setWorkflowType(Job.Type.POLICY_ROLLBACK);
                        gridMatrixRepository.delete(gridMatrix);
                    });
                }
            }
            GridPolicySet gridPolicySetIbDB = gridPolicySetRepository.findOne(gridPolicySet.getId());
            gridPolicySetIbDB.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            gridPolicySetRepository.save(gridPolicySetIbDB);
        } catch (Exception e) {
            GridPolicySet gridPolicySetInDB = gridPolicySetRepository.findOne(gridPolicySet.getId());
            if (gridPolicySetInDB != null) {
                String gridName = gridRepository.findNameById(gridPolicySetInDB.getDeviceGrid().getId());
                String errorMessage = e.getMessage();
                if (Strings.isNullOrEmpty(errorMessage)) {
                    errorMessage = "Failed to recover policy.";
                }
                log.error("Failed to recover grid policy {} for grid {}.  cause : {}", gridPolicySetInDB.getId(), gridName, errorMessage);
                gridPolicySetInDB.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                gridPolicySetRepository.save(gridPolicySetInDB);
                Set<GridMatrix> gridMatrixSet = gridMatrixRepository.findByPolicySetId(gridPolicySetInDB.getId());
                gridMatrixSet.forEach(gridMatrix -> {
                    gridMatrix.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                    gridMatrixRepository.save(gridMatrix);
                });
                updateEvent(gridPolicySetInDB.getId(), Job.Type.POLICY_ROLLBACK.toString(), gridName, Job.Status.FAILED.toString(), errorMessage, Event.Severity.MAJOR);
            }
            throw new ServerException(e.getMessage());
        }
    }

    /**
     * Match and return two topology paths.
     *
     * @param egressPortsDestinationNew
     * @param egressPortsDestinationOld
     * @param intermediateNodesNew
     * @param intermediateNodesOld
     * @return
     */
    private boolean compareTopologyPaths(Set<Long> egressPortsDestinationNew, Set<Long> egressPortsDestinationOld, Set<IntermediateNode> intermediateNodesNew, Set<IntermediateNode> intermediateNodesOld,
                                         Map<Long, Set<Long>> intermediateNodesOldManagedObjectSet) {
        if (intermediateNodesNew.size() != intermediateNodesOld.size()) {
            return true;
        }
        if ((!Sets.difference(egressPortsDestinationNew, egressPortsDestinationOld).isEmpty() || !Sets.difference(egressPortsDestinationOld, egressPortsDestinationNew).isEmpty())) {
            return true;
        }

        AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        intermediateNodesNew.forEach(intermediateNodeNewDb -> {
            Optional<IntermediateNode> intermediateNodeOptional = intermediateNodesOld.stream().filter(intermediateNodeOld -> intermediateNodeOld.getDevice().getId() == intermediateNodeNewDb.getDevice().getId()).findAny();
            if (intermediateNodeOptional.isPresent()) {
                IntermediateNode intermediateNodeOldDb = intermediateNodeOptional.get();
                Set<Long> intermediateEgressPortsNew = intermediateNodeNewDb.getEgressPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                intermediateEgressPortsNew.addAll(intermediateNodeNewDb.getEgressPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toSet()));

                Set<Long> intermediateEgressPortsOld = intermediateNodesOldManagedObjectSet.get(intermediateNodeOldDb.getId());
                if (intermediateEgressPortsOld != null && (!Sets.difference(intermediateEgressPortsNew, intermediateEgressPortsOld).isEmpty() || !Sets.difference(intermediateEgressPortsOld, intermediateEgressPortsNew).isEmpty())) {
                    atomicBoolean.set(true);
                }
            } else {
                atomicBoolean.set(true);
            }
        });
        if (!atomicBoolean.get()) {
            intermediateNodesOld.forEach(intermediateNodeOldDb -> {
                Optional<IntermediateNode> intermediateNodeOptional = intermediateNodesNew.stream().filter(intermediateNodeOld -> intermediateNodeOld.getDevice().getId() == intermediateNodeOldDb.getDevice().getId()).findAny();
                if (!intermediateNodeOptional.isPresent()) {
                    atomicBoolean.set(true);
                }
            });
        }
        return atomicBoolean.get();
    }

    /**
     * Merges the updated grid object into existing grid object retrieved from DB
     *
     * @param existingGrid
     * @param updatedGrid
     * @return
     */
    public void compareGrids(DeviceGrid existingGrid, DeviceGrid updatedGrid, Set<Long> deletedSourceNodes, Set<Long> deletedDestinationNodes, Set<ClusterNodeInterface> clusterInterfacesSourceUpdated,
                             Set<ClusterNodeInterface> clusterInterfacesDestUpdated, Set<Long> clusterNodeInterfacesSourceToDelete, Set<Long> clusterNodeInterfacesDestToDelete) {
        existingGrid.getSourceNodes().forEach(gridClusterExisting -> {
            Set<GridCluster> updatedGridClusters = updatedGrid.getSourceNodes().stream().filter(gridCluster -> gridClusterExisting.getId() != null && gridClusterExisting.getId().equals(gridCluster.getId())).collect(Collectors.toSet());
            if (updatedGridClusters.size() > 0) {
                GridCluster updatedGridCluster = updatedGridClusters.stream().findFirst().get();
                updateNetworkNode(gridClusterExisting, updatedGridCluster, clusterInterfacesSourceUpdated, clusterNodeInterfacesSourceToDelete);
            } else {
                deletedSourceNodes.add(gridClusterExisting.getId());
                gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface ->
                        clusterNodeInterfacesSourceToDelete.add(clusterNodeInterface.getId())
                );

            }
        });

        existingGrid.getDestinationNodes().forEach(gridClusterExisting -> {
            Set<GridCluster> updatedGridClusters = updatedGrid.getDestinationNodes().stream().filter(gridCluster -> gridClusterExisting.getId() != null && gridClusterExisting.getId().equals(gridCluster.getId())).collect(Collectors.toSet());
            if (updatedGridClusters.size() > 0) {
                GridCluster updatedGridCluster = updatedGridClusters.stream().findFirst().get();
                updateNetworkNode(gridClusterExisting, updatedGridCluster, clusterInterfacesDestUpdated, clusterNodeInterfacesDestToDelete);
            } else {
                deletedDestinationNodes.add(gridClusterExisting.getId());
                gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface ->
                        clusterNodeInterfacesDestToDelete.add(clusterNodeInterface.getId())
                );
            }
        });
        //check these clusters/cluster interfaces in policy set. Return the error if exist.
    }

    /**
     * Merges the updated GridCluster object into existing GridCluster object.
     *
     * @param gridClusterExisting
     * @param updatedGridCluster
     */
    private void updateNetworkNode(GridCluster gridClusterExisting, GridCluster updatedGridCluster, Set<ClusterNodeInterface> clusterNodeInterfacesUpdated,
                                   Set<Long> clusterNodeInterfacesToDelete) {
        if (gridClusterExisting.getDevice().getId() == updatedGridCluster.getDevice().getId()) {
            gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterfaceExisting -> {
                Optional<ClusterNodeInterface> searchResult = updatedGridCluster.getClusterNodeInterfaces().stream().filter(clusterNodeInterface -> clusterNodeInterface.getId() == clusterNodeInterfaceExisting.getId()).findFirst();
                if (searchResult.isPresent()) {
                    //update these interfaces in the policy set.
                    ClusterNodeInterface networkInterfaceUpdated = searchResult.get();

                    Set<Long> networkNodePortsAdded = findNewObjectId(clusterNodeInterfaceExisting.getPorts(), networkInterfaceUpdated.getPorts());
                    Set<Long> networkNodePortsDeleted = findNewObjectId(networkInterfaceUpdated.getPorts(), clusterNodeInterfaceExisting.getPorts());

                    Set<Long> networkNodePortGroupsAdded = findNewObjectId(clusterNodeInterfaceExisting.getPortGroups(), networkInterfaceUpdated.getPortGroups());
                    Set<Long> networkNodePortGroupsDeleted = findNewObjectId(networkInterfaceUpdated.getPortGroups(), clusterNodeInterfaceExisting.getPortGroups());

                    if (!networkNodePortsAdded.isEmpty() || !networkNodePortsDeleted.isEmpty() ||
                            !networkNodePortGroupsAdded.isEmpty() || !networkNodePortGroupsDeleted.isEmpty()) {
                        clusterNodeInterfacesUpdated.add(networkInterfaceUpdated);
                    }
                } else {
                    //check these cluster interfaces in policy set. Return the error if exist.
                    clusterNodeInterfacesToDelete.add(clusterNodeInterfaceExisting.getId());
                }
            });
        }
    }


    /**
     * This method is used find the new port(s)/portGroup(s) to be updated in the policy on the device
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<Long> findNewObjectId(Set<? extends ManagedObject> existingSet,
                                      Set<? extends ManagedObject> updatedSet) {
        Set<Long> toAdd = new HashSet<>();
        for (ManagedObject eachUpdate : updatedSet) {
            if (!existingSet.stream().anyMatch(po -> po.getId().longValue() == eachUpdate.getId().longValue())) {
                toAdd.add(eachUpdate.getId());
            }
        }
        return toAdd;
    }

    /**
     * Generate and save the pbf destination group id for a matrix.
     *
     * @param policy
     * @param gridMatrix
     * @param destinationGroups
     * @param gridTopologyPathSet
     * @return
     */
    private Set<DestinationGroup> generateAndSetGroupIds(Policy policy, GridPolicySet gridPolicySet, GridMatrix gridMatrix, Set<DestinationGroup> destinationGroups, Set<GridTopologyPath> gridTopologyPathSet) {
        if (policy != null && gridTopologyPathSet != null && !gridTopologyPathSet.isEmpty()) {
            synchronized (this) {
                Set<DestinationGroup> destinationExisting = Sets.newHashSet(destinationGroups);
                policy.getFlows().forEach(flow -> {
                    if (flow.getId() == null || flow.getDestinationGroupId() == null) {
                        Set<Long> gridTopologyPathIds = Sets.newHashSet();
                        Optional<GridPolicy> gridPolicyOptional = gridPolicySet.getGridPolicies().stream().filter(gridPolicy -> gridPolicy.getId() == flow.getGridPolicyId()).findAny();
                        if (gridPolicyOptional.isPresent()) {
                            GridPolicy gridPolicy = gridPolicyOptional.get();
                            Set<Long> gridPolicyEgressIds = gridPolicy.getEgressClusterNodeInterfaces().stream().map(ClusterNodeInterface::getId).collect(Collectors.toSet());

                            gridTopologyPathSet.stream().forEach(gridTopologyPath -> {
                                Long topologySourceNodeEgressId = gridTopologyPath.getToolNodeInterfaceId();
                                if (gridPolicyEgressIds.contains(topologySourceNodeEgressId)) {
                                    gridTopologyPathIds.add(gridTopologyPath.getId());
                                }
                            });
                        }
                        DestinationGroup destinationGroup = null;
                        for (DestinationGroup destinationGroup1 : destinationGroups) {
                            if (gridTopologyPathIds.size() == destinationGroup1.getGridTopologyPathIds().size() && Sets.difference(gridTopologyPathIds, destinationGroup1.getGridTopologyPathIds()).isEmpty()) {
                                destinationGroup = destinationGroup1;
                                destinationExisting.remove(destinationGroup);
                            }
                        }
                        if (destinationGroup == null) {
                            destinationGroup = new DestinationGroup();
                            destinationGroup.setGridTopologyPathIds(gridTopologyPathIds);
                            destinationGroup.setGridMatrix(gridMatrix);
                            destinationGroup.setGroupId(getGroupId(destinationGroupRepository.getAllGroupIds()));
                            destinationGroupRepository.save(destinationGroup);
                            destinationGroups.add(destinationGroup);
                        }
                        flow.setDestinationGroupId(destinationGroup.getGroupId());
                    } else {
                        Set<Long> gridTopologyPathIds = Sets.newHashSet();
                        Optional<GridPolicy> gridPolicyOptional = gridPolicySet.getGridPolicies().stream().filter(gridPolicy -> gridPolicy.getId() == flow.getGridPolicyId()).findAny();
                        if (gridPolicyOptional.isPresent()) {
                            GridPolicy gridPolicy = gridPolicyOptional.get();
                            Set<Long> gridPolicyEgressIds = gridPolicy.getEgressClusterNodeInterfaces().stream().map(ClusterNodeInterface::getId).collect(Collectors.toSet());

                            gridTopologyPathSet.stream().forEach(gridTopologyPath -> {
                                Long topologySourceNodeEgressId = gridTopologyPath.getToolNodeInterfaceId();
                                if (gridPolicyEgressIds.contains(topologySourceNodeEgressId)) {
                                    gridTopologyPathIds.add(gridTopologyPath.getId());
                                }
                            });
                        }
                        DestinationGroup destinationGroup = null;
                        for (DestinationGroup destinationGroup1 : destinationGroups) {
                            if (gridTopologyPathIds.size() == destinationGroup1.getGridTopologyPathIds().size() && Sets.difference(gridTopologyPathIds, destinationGroup1.getGridTopologyPathIds()).isEmpty()) {
                                destinationGroup = destinationGroup1;
                                destinationExisting.remove(destinationGroup);
                            }
                        }
                        if (destinationGroup == null) {
                            destinationGroup = new DestinationGroup();
                            destinationGroup.setGridTopologyPathIds(gridTopologyPathIds);
                            destinationGroup.setGridMatrix(gridMatrix);
                            destinationGroup.setGroupId(getGroupId(destinationGroupRepository.getAllGroupIds()));
                            destinationGroupRepository.save(destinationGroup);
                            destinationGroups.add(destinationGroup);
                        } else {
                            destinationGroup.setGridTopologyPathIds(gridTopologyPathIds);
                        }
                        flow.setDestinationGroupId(destinationGroup.getGroupId());
                    }
                });
                if (!destinationExisting.isEmpty()) {
                    destinationGroups.removeAll(destinationExisting);
                }
            }
        }
        return destinationGroups;
    }

    /**
     * This method create SLX policy set
     *
     * @param gridPolicySet
     * @param targetDevice
     * @param gridTopologyPathSet
     * @return
     * @Param sdIngressPorts
     */
    private Policy getAggregatorPolicySet(GridPolicySet gridPolicySet, Policy policy, Device targetDevice,
                                          Set<GridTopologyPath> gridTopologyPathSet) {
        policy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        policy.setDevice(targetDevice);
        policy.setGridPolicySetId(gridPolicySet.getId());
        policy.setName(gridPolicySet.getName());
        policy.setFieldOffset1(gridPolicySet.getFieldOffset1());
        policy.setFieldOffset2(gridPolicySet.getFieldOffset2());
        policy.setFieldOffset3(gridPolicySet.getFieldOffset3());
        policy.setFieldOffset4(gridPolicySet.getFieldOffset4());
        policy.setEgressAction(gridPolicySet.getEgressAction());
        policy.setTimestamp(gridPolicySet.isTimestamp());
        policy.setGtpHttpFiltered(gridPolicySet.isGtpHttpFiltered());
        policy.setLoopbackEnabled(gridPolicySet.isLoopbackEnabled());
        policy.setFlexMatchProfiles(gridPolicySet.getFlexMatchProfiles());
        policy.setFlows(copyFlows(targetDevice, gridPolicySet.getGridPolicies(), Sets.newTreeSet(policy.getFlows()), gridTopologyPathSet));
        return updateNullFieldsForPolicy(policy);
    }

    private SortedSet<Flow> copyFlows(Device targetDevice, SortedSet<GridPolicy> gridPolicyPolicies, SortedSet<Flow> flows, Set<GridTopologyPath> gridTopologyPathSet) {
        if (!gridPolicyPolicies.isEmpty()) {
            SortedSet<Flow> flowsToDelete = Sets.newTreeSet();
            flows.forEach(flowObj -> {
                if (gridPolicyPolicies.stream().noneMatch(gridPolicy -> gridPolicy.getId() == flowObj.getGridPolicyId())) {
                    flowsToDelete.add(flowObj);
                }
            });
            flows.removeAll(flowsToDelete);
            SortedSet<Flow> flowsToAdd = Sets.newTreeSet();
            gridPolicyPolicies.forEach(gridPolicy -> {
                Optional<Flow> flowOptional = flows.stream().filter(flowObj -> gridPolicy.getId() == flowObj.getGridPolicyId()).findFirst();
                if (flowOptional.isPresent()) {
                    copyFlow(targetDevice, gridPolicy, flowOptional.get(), gridTopologyPathSet);
                } else {
                    Flow flow = copyFlow(targetDevice, gridPolicy, new Flow(), gridTopologyPathSet);
                    flow.setGridPolicyId(gridPolicy.getId());
                    flowsToAdd.add(flow);
                }
            });
            flows.addAll(flowsToAdd);
        }
        return flows;
    }

    /**
     * Copies the grid policy properties to related flow.
     *
     * @param targetDevice
     * @param gridPolicy
     * @param flow
     * @param gridTopologyPathSet
     * @return
     */
    private Flow copyFlow(Device targetDevice, GridPolicy gridPolicy, Flow flow, Set<GridTopologyPath> gridTopologyPathSet) {
        flow.setSequence(gridPolicy.getSequence());
        flow.setIsTagged(gridPolicy.getIsTagged());
        flow.setVlanStripping(gridPolicy.getVlanStripping());
        flow.setTaggedVlanId(gridPolicy.getTaggedVlanId());
        flow.setIsDefaultRouteMapDrop(gridPolicy.getIsDefaultRouteMapDrop());
        flow.setVlans(gridPolicy.getVlans());
        flow.setSourceMacTag(gridPolicy.getSourceMacTag());
        flow.setDestinationMacTag(gridPolicy.getDestinationMacTag());

        List<Long> ingressPortIds = Lists.newArrayList();
        List<Long> ingressPortGroupIds = Lists.newArrayList();
        Set<ClusterNodeInterface> ingressClusterNodeInterfaces = Sets.newHashSet();
        gridPolicy.getIngressClusterNodeInterfaces().stream().forEach(clusterNodeInterface -> {
            ClusterNodeInterface clusterNodeInterfaceInDb = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
            if (clusterNodeInterfaceInDb.getGridCluster().getDevice().getId().longValue() == targetDevice.getId().longValue()) {
                ingressClusterNodeInterfaces.add(clusterNodeInterfaceInDb);
            }
        });
        ingressClusterNodeInterfaces.forEach(clusterNodeInterface -> {
            ingressPortIds.addAll(clusterNodeInterface.getPorts().stream().map(Port::getId).collect(Collectors.toList()));
            ingressPortGroupIds.addAll(clusterNodeInterface.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList()));
        });

        Set<Port> egressPorts = Sets.newHashSet();
        Set<PortGroup> egressPortGroups = Sets.newHashSet();
        Set<ClusterNodeInterface> egressClusterNodeInterfaces = gridPolicy.getEgressClusterNodeInterfaces();
        egressClusterNodeInterfaces.stream().forEach(clusterNodeInterface -> {
            Set<GridTopologyPath> gridTopologyPaths = gridTopologyPathSet.stream().filter(toolAddressTopologyPathMapping -> toolAddressTopologyPathMapping.getToolNodeInterfaceId() == clusterNodeInterface.getId())
                    .collect(Collectors.toSet());
            if (!gridTopologyPaths.isEmpty()) {
                gridTopologyPaths.forEach(gridTopologyPath -> {
                    GridTopologyPath gridTopologyPathFromDb = gridTopologyPathRepository.findOne(gridTopologyPath.getId());
                    NetworkNode sourceNetworkNode = gridTopologyPathFromDb.getSourceNetworkNode();
                    egressPorts.addAll(sourceNetworkNode.getEgressPorts());
                    egressPortGroups.addAll(sourceNetworkNode.getEgressPortGroups());
                });
            }
        });
        List<Long> egressPortIds = egressPorts.stream().map(Port::getId).collect(Collectors.toList());
        List<Long> egressPortGroupIds = egressPortGroups.stream().map(PortGroup::getId).collect(Collectors.toList());
        Set<Port> egressPortInDb = Sets.newHashSet(portRepository.findAll(egressPortIds));
        Set<PortGroup> egressPortGroupInDb = Sets.newHashSet(portGroupRepository.findAll(egressPortGroupIds));
        flow.clearIngressPortsAndPortGroups();
        flow.clearEgressPortsAndPortGroups();
        flow.setIngressPorts(Sets.newHashSet(portRepository.findAll(ingressPortIds)));
        flow.setIngressPortGroups(Sets.newHashSet(portGroupRepository.findAll(ingressPortGroupIds)));
        flow.setEgressPorts(egressPortInDb);
        flow.setEgressPortGroups(egressPortGroupInDb);

        flow.addFlowEgressManagedObjects(egressPortInDb);
        flow.addFlowEgressManagedObjects(egressPortGroupInDb);
        flow.setRuleSets(copyRuleSets(gridPolicy.getRuleSets(), Sets.newTreeSet(flow.getRuleSets())));
        return flow;
    }

    /**
     * Iterate grid rulesets and call the copy ruleset function for each of them.
     *
     * @param gridRuleSets
     * @param ruleSets
     * @return
     */
    private SortedSet<RuleSet> copyRuleSets(SortedSet<GridRuleSet> gridRuleSets, SortedSet<RuleSet> ruleSets) {
        if (!gridRuleSets.isEmpty()) {
            SortedSet<RuleSet> ruleSetsToDelete = Sets.newTreeSet();
            ruleSets.forEach(ruleSet -> {
                if (gridRuleSets.stream().noneMatch(gridRuleSet -> gridRuleSet.getId() == ruleSet.getGridRuleSetId())) {
                    ruleSetsToDelete.add(ruleSet);
                }
            });
            ruleSets.removeAll(ruleSetsToDelete);
            SortedSet<RuleSet> ruleSetsToAdd = Sets.newTreeSet();
            gridRuleSets.forEach(gridRuleSet -> {
                Optional<RuleSet> ruleSetOptional = ruleSets.stream().filter(ruleSet -> gridRuleSet.getId() == ruleSet.getGridRuleSetId()).findFirst();
                if (ruleSetOptional.isPresent()) {
                    copyRuleSet(gridRuleSet, ruleSetOptional.get());
                } else {
                    RuleSet ruleSet = copyRuleSet(gridRuleSet, new RuleSet());
                    ruleSet.setGridRuleSetId(gridRuleSet.getId());
                    ruleSetsToAdd.add(ruleSet);
                }
            });
            ruleSets.addAll(ruleSetsToAdd);
        }
        return ruleSets;
    }

    /**
     * Copies the grid ruleset properties to related ruleset.
     *
     * @param gridRuleSet
     * @param ruleSet
     * @return
     */
    private RuleSet copyRuleSet(GridRuleSet gridRuleSet, RuleSet ruleSet) {
        ruleSet.setName(gridRuleSet.getName());
        ruleSet.setSequence(gridRuleSet.getSequence());
        switch (gridRuleSet.getType()) {
            case L2:
                ruleSet.setType(RuleSet.Type.L2);
                break;
            case L3:
                ruleSet.setType(RuleSet.Type.L3);
                break;
            case L23:
                ruleSet.setType(RuleSet.Type.L23);
                break;
            case UDA:
                ruleSet.setType(RuleSet.Type.UDA);
                break;
        }
        if (gridRuleSet.getIpVersion() != null) {
            ruleSet.setIpVersion(gridRuleSet.getIpVersion() == GridRuleSet.IpVersion.V4 ? RuleSet.IpVersion.V4 : RuleSet.IpVersion.V6);
        }
        SortedSet<Rule> rules = copyRules(gridRuleSet.getRules(), Sets.newTreeSet(ruleSet.getRules()));
        ruleSet.setRules(rules);
        return ruleSet;
    }

    private SortedSet<Rule> copyRules(SortedSet<GridRule> gridRules, SortedSet<Rule> rules) {
        if (!gridRules.isEmpty()) {
            SortedSet<Rule> rulesToDelete = Sets.newTreeSet();
            rules.forEach(rule -> {
                if (gridRules.stream().noneMatch(gridRule -> gridRule.getId() == rule.getGridRuleId())) {
                    rulesToDelete.add(rule);
                }
            });
            rules.removeAll(rulesToDelete);
            SortedSet<Rule> rulesToAdd = Sets.newTreeSet();
            gridRules.forEach(gridRule -> {
                Optional<Rule> ruleOptional = rules.stream().filter(rule -> gridRule.getId() == rule.getGridRuleId()).findFirst();
                if (ruleOptional.isPresent()) {
                    copyRule(gridRule, ruleOptional.get());
                } else {
                    Rule rule = copyRule(gridRule, new Rule());
                    rule.setGridRuleId(gridRule.getId());
                    rulesToAdd.add(rule);
                }
            });
            rules.addAll(rulesToAdd);
        }
        return rules;
    }

    /**
     * Copies the grid rules properties to related rule
     *
     * @param primaryRule
     * @param rule
     * @return
     */
    private Rule copyRule(GridRule primaryRule, Rule rule) {
        //catch all rule
        rule.setSequence(primaryRule.getSequence());
        rule.setProtocol(primaryRule.getProtocol());
        rule.setProtocolType(primaryRule.getProtocolType());
        rule.setSourceIp(primaryRule.getSourceIp());
        rule.setDestinationIp(primaryRule.getDestinationIp());
        rule.setIsPermit(primaryRule.getIsPermit());
        rule.setSourcePort(primaryRule.getSourcePort());
        rule.setDestinationPort(primaryRule.getDestinationPort());
        rule.setSourcePortOperator(primaryRule.getSourcePortOperator());
        rule.setDestinationPortOperator(primaryRule.getDestinationPortOperator());
        rule.setSourceMac(primaryRule.getSourceMac());
        rule.setDestinationMac(primaryRule.getDestinationMac());
        rule.setEthType(primaryRule.getEthType());
        rule.setCustomAcl(primaryRule.getCustomAcl());
        rule.setVlanId(primaryRule.getVlanId());
        rule.setIsCountEnabled(primaryRule.getIsCountEnabled());
        rule.setMatchPayloadLength(primaryRule.getMatchPayloadLength());
        rule.setFieldmask1(primaryRule.getFieldmask1());
        rule.setFieldmask2(primaryRule.getFieldmask2());
        rule.setFieldmask3(primaryRule.getFieldmask3());
        rule.setFieldmask4(primaryRule.getFieldmask4());
        rule.setFieldValue1(primaryRule.getFieldValue1());
        rule.setFieldValue2(primaryRule.getFieldValue2());
        rule.setFieldValue3(primaryRule.getFieldValue3());
        rule.setFieldValue4(primaryRule.getFieldValue4());
        rule.setByteSize1(primaryRule.getByteSize1());
        rule.setByteSize2(primaryRule.getByteSize2());
        rule.setByteSize3(primaryRule.getByteSize3());
        rule.setByteSize4(primaryRule.getByteSize4());
        return rule;
    }

    /**
     * Set or remove the address table in all the nodes in the path
     *
     * @param gridMatrix
     * @param type
     */
    protected void updateToolAddress(Long sourceDeviceId, Set<Long> gridClusterDestinations, GridMatrix gridMatrix, Set<Long> intermediateDeviceIds, Job.Type type) {
        List<Long> jobIds = Lists.newArrayList();
        //Set the the path/address id on each participating devices.
        if (sourceDeviceId != null && (type != Job.Type.GRID_TOOL_ADDRESS_UPDATE || isUpdateToolAddressRequired(gridMatrix, sourceDeviceId))) {
            if (intermediateDeviceIds.contains(sourceDeviceId)) {
                intermediateDeviceIds.remove(sourceDeviceId);
            }
            Long jobId1 = commitToolAddress(sourceDeviceId, gridMatrix, type);
            if (jobId1 != -1) {
                jobIds.add(jobId1);
            }
        }
        if (gridClusterDestinations != null && !gridClusterDestinations.isEmpty()) {
            gridClusterDestinations.forEach(destinationDeviceId -> {
                if (type != Job.Type.GRID_TOOL_ADDRESS_UPDATE || isUpdateToolAddressRequired(gridMatrix, destinationDeviceId)) {
                    if (intermediateDeviceIds.contains(destinationDeviceId)) {
                        intermediateDeviceIds.remove(destinationDeviceId);
                    }
                    Long jobId2 = commitToolAddress(destinationDeviceId, gridMatrix, type);
                    if (jobId2 != -1) {
                        jobIds.add(jobId2);
                    }
                }
            });
        }
        if (intermediateDeviceIds != null && !intermediateDeviceIds.isEmpty()) {
            intermediateDeviceIds.forEach(intermediateDeviceId -> {
                if (type != Job.Type.GRID_TOOL_ADDRESS_UPDATE || isUpdateToolAddressRequired(gridMatrix, intermediateDeviceId)) {
                    if (Job.Type.GRID_TOOL_ADDRESS_ROLLBACK == type && deviceRepository.findIdByIdAndIsDeleted(intermediateDeviceId, true) != null) {
                        log.debug("Skipping the GRID_TOOL_ADDRESS_ROLLBACK job for device {] as the device is in deleted state. Existing pbf destination configuration will not be cleaned.", intermediateDeviceId);
                    } else {
                        Long jobId3 = commitToolAddress(intermediateDeviceId, gridMatrix, type);
                        if (jobId3 != -1) {
                            jobIds.add(jobId3);
                        }
                    }
                }
            });
        }
        jobIds.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
            }
        });
    }

    /**
     * Validating the device policy interfaces
     *
     * @param policy
     * @param deviceName
     */
    private void validateDevicePolicy(Policy policy, String deviceName) {
        policy.getFlows().forEach(flow -> {
            Set<Long> ingressPortIds = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> egressPortIds = flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<String> ingressPortChannelIds = flow.getIngressPortGroups().stream().map(PortGroup::getName).collect(Collectors.toSet());
            Set<String> egressPortChannelIds = flow.getEgressPortGroups().stream().map(PortGroup::getName).collect(Collectors.toSet());

            // Validating if the same port(s)/portGroup(s) exists as both source port and destination port
            Sets.SetView commonPortIds = Sets.intersection(ingressPortIds, egressPortIds);
            Sets.SetView commonPortGroupIds = Sets.intersection(ingressPortChannelIds, egressPortChannelIds);
            if (!commonPortIds.isEmpty()) {
                Set<Port> portsFromDB = Sets.newHashSet(portRepository.findAll(commonPortIds));
                String interfacePorts = portsFromDB.stream().map(Port::getName).collect(Collectors.joining(","));
                log.debug("Policy with name {} cannot have same port {} exists as both source and destination port on device {}", policy.getName(), interfacePorts, deviceName);
                throw new ValidationException("Interface " + interfacePorts + " on " + deviceName + " cannot be used as it is conflicting with network path.");
            } else if (!commonPortGroupIds.isEmpty()) {
                Set<PortGroup> portGroupsFromDB = Sets.newHashSet(portGroupRepository.findAll(commonPortGroupIds));
                String interfacePortGroups = portGroupsFromDB.stream().map(PortGroup::getName).collect(Collectors.joining(","));
                log.debug("Policy with name {} cannot have same port group {} exists as both source and destination port on device {}", policy.getName(), interfacePortGroups, deviceName);
                throw new ValidationException("Interface " + interfacePortGroups + " on " + deviceName + " cannot be used as it is conflicting with network path.");
            }
        });
    }

    /**
     * Committing the pbf destination command on device.
     *
     * @param deviceId
     * @param gridMatrix
     * @param type
     * @return
     */
    private Long commitToolAddress(Long deviceId, GridMatrix gridMatrix, Job.Type type) {
        //Set the the path/address id on each participating devices.
        Long jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(deviceId)
                .parentObjectId(gridMatrix.getId()).impactedObjectIds(Collections.emptyList()).build());
        return jobId;
    }

    /**
     * Set or remove the tool group entries on the source node
     *
     * @param gridMatrix
     * @param type
     */
    protected void updateToolGroup(Long sourceDeviceId, GridMatrix gridMatrix, Job.Type type) {
        List<Long> jobIds = Lists.newArrayList();
        //to set the tool group on aggregator device
        if (type == Job.Type.GRID_TOOL_GROUP_CREATE || type == Job.Type.GRID_TOOL_GROUP_DELETE || type == Job.Type.GRID_TOOL_GROUP_ROLLBACK || (type == Job.Type.GRID_TOOL_GROUP_UPDATE_ADD && isUpdateToolGroupAddressRequired(gridMatrix, sourceDeviceId, true))
                || (type == Job.Type.GRID_TOOL_GROUP_UPDATE_DELETE && isUpdateToolGroupAddressRequired(gridMatrix, sourceDeviceId, false))) {
            Long jobId2 = jobQueue.submit(JobTemplate.builder().type(type).deviceId(sourceDeviceId)
                    .parentObjectId(gridMatrix.getId()).impactedObjectIds(Collections.emptyList()).build());
            if (jobId2 != -1) {
                jobIds.add(jobId2);
            }
        }
        jobIds.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
            }
        });
    }

    /**
     * Committing the pbf destination group on device.
     *
     * @param sourceDeviceId
     * @param gridMatrix
     * @param type
     */
    private void commitToolGroup(Long sourceDeviceId, GridMatrix gridMatrix, Job.Type type) {
        List<Long> jobIds = Lists.newArrayList();
        //to set the tool group on aggregator device
        Long jobId2 = jobQueue.submit(JobTemplate.builder().type(type).deviceId(sourceDeviceId)
                .parentObjectId(gridMatrix.getId()).impactedObjectIds(Collections.emptyList()).build());
        if (jobId2 != -1) {
            jobIds.add(jobId2);
        }
        jobIds.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                throw new ServerException(genericJobManager.updateErrorMessage(internalPolicyJob));
            }
        });
    }

    /**
     * @param sourceChassis
     * @param destinationChassis
     * @param sourceInterface
     * @param destinationInterface
     * @param bandWidth
     * @return
     */
    private Map<String, Object> getTopologyPath(String sourceChassis, String destinationChassis, Port sourceInterface, Port destinationInterface, Long bandWidth, boolean isCspf) {
        String uri = "https://tme" + tmePathCreateUrl.replace("{tmeServerPort}", tmeServerPort.toString());
//        String uri = "https://10.37.130.38" + tmePathCreateUrl.replace("{tmeServerPort}", tmeServerPort.toString());
        JSONObject postBody = new JSONObject();
        try {
            postBody.put("FromType", 1);
            postBody.put("ToType", 1);
            postBody.put("Lport", (sourceInterface != null && sourceInterface.getName() != null) ? sourceInterface.getName() : "");
            postBody.put("Rport", (destinationInterface != null && destinationInterface.getName() != null) ? destinationInterface.getName() : "");
            postBody.put("LchassisID", sourceChassis != null ? sourceChassis : "");
            postBody.put("RchassisID", destinationChassis != null ? destinationChassis : "");
            postBody.put("Cost", bandWidth);//IN GB
            postBody.put("Cspf", isCspf ? 1 : 0);

        } catch (JSONException e) {
            log.error("Error while creating PathInfo JSON. {}", e.getMessage());
        }
        log.debug("Path create request params {}", postBody);
        Map<String, Object> map = Maps.newHashMap();
        try {
            Response res = restHelperWithoutProxy.post(Entity.json(postBody.toString()), MediaType.APPLICATION_JSON_TYPE, uri);
            if (res != null) {
                map = getJsonResponseInMap(res);
            }
        } catch (OutboundConnectionException | OutboundApiException e) {
            log.error("Failed to execute the getTopologyPath API. {}", e.getMessage());
        }
        return map;
    }

    public Map<String, Object> syncPath(GridTopologyPath gridTopologyPath) {
        String uri = "https://tme" + tmePathSyncUrl.replace("{tmeServerPort}", tmeServerPort.toString());
//        String uri = "https://10.37.130.38" + tmePathSyncUrl.replace("{tmeServerPort}", tmeServerPort.toString());
        JSONObject postBody = new JSONObject();
        try {
            postBody.put("FromType", 1);
            postBody.put("ToType", 1);
            postBody.put("PathID", gridTopologyPath.getPathId());
            postBody.put("Path", gridTopologyPath.getPathJson());
            postBody.put("Cost", gridTopologyPath.getBandwidth());
            postBody.put("Cspf", gridTopologyPath.getIsCspfEnabled() ? 1 : 0);

        } catch (JSONException e) {
            log.error("Error while synchronizing PathInfo JSON. {}", e.getMessage());
        }
        log.debug("Path sync request params {}", postBody);
        Map<String, Object> map = Maps.newHashMap();
        try {
            Response res = restHelperWithoutProxy.post(Entity.json(postBody.toString()), MediaType.APPLICATION_JSON_TYPE, uri);
            if (res != null) {
                map = getJsonResponseInMap(res);
            }
        } catch (OutboundConnectionException | OutboundApiException e) {
            log.error("Failed to execute the syncPath API. {}", e.getMessage());
        }
        return map;
    }

    /**
     * REST API call to TME to delete the path
     *
     * @param chassisIdSet
     * @return
     */
    protected Map<String, Object> getTopology(Set<String> chassisIdSet) {
        String uri = "https://tme" + tmeTopologyPathUrl.replace("{tmeServerPort}", tmeServerPort.toString());
//        String uri = "https://10.37.130.38" + tmeTopologyPathUrl.replace("{tmeServerPort}", tmeServerPort.toString());
        StringBuilder postBody = new StringBuilder();
        postBody.append("{\"ChassisID\":[\"").append(chassisIdSet.stream().collect(Collectors.joining("\",\""))).append("\"]}");
        log.debug("Grid topology request params {}", postBody);
        Map<String, Object> map = Maps.newHashMap();
        try {
            Response res = restHelperWithoutProxy.post(Entity.json(postBody.toString()), MediaType.APPLICATION_JSON_TYPE, uri);
            if (res != null) {
                map = getJsonResponseInMap(res);
            }
        } catch (Exception e) {
            log.error("Failed to execute the getTopology API. {}", e.getMessage());
        }
        return map;
    }

    /**
     * REST API call to TME to delete the path
     *
     * @param pathId
     * @return
     */
    private Map<String, Object> deletePath(Long pathId) {
        String uri = "https://tme" + tmePathDeleteUrl.replace("{tmeServerPort}", tmeServerPort.toString());
//        String uri = "https://10.37.130.38" + tmePathDeleteUrl.replace("{tmeServerPort}", tmeServerPort.toString());
        StringBuilder postBody = new StringBuilder();
        postBody.append("{\"PathID\":[").append(pathId).append("]}");
        log.debug("Path delete request params {}", postBody);
        Map<String, Object> map = Maps.newHashMap();
        Response res = restHelperWithoutProxy.post(Entity.json(postBody.toString()), MediaType.APPLICATION_JSON_TYPE, uri);
        try {
            if (res != null) {
                map = getJsonResponseInMap(res);
            }
        } catch (OutboundConnectionException | OutboundApiException e) {
            log.error("Failed to execute the deletePath API. {}", e.getMessage());
        }
        return map;
    }

    /**
     * Prepare the response map from the rest api response.
     *
     * @param res
     * @return
     */
    private Map<String, Object> getJsonResponseInMap(Response res) {
        String responseString = res.readEntity(String.class);
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> map = Maps.newHashMap();
        try {
            if (!Strings.isNullOrEmpty(responseString)) {
                responseString = responseString.replaceAll("-\\\\u003e", "->");
                map = mapper.readValue(responseString, new TypeReference<Map<String, Object>>() {
                });
            }
        } catch (IOException e) {
            throw new ValidationException(e.getMessage());
        }
        return map;
    }

    /**
     * Returns all the topology paths saved.
     *
     * @return
     */
    public boolean syncTopologyPath() {
        Set<GridTopologyPath> gridTopologyPathSet = gridTopologyPathRepository.getAllPaths(true);
        log.debug("Count of network paths to sync : {}", gridTopologyPathSet.size());
        gridTopologyPathSet.forEach(gridTopologyPath -> {
            try {
                if (gridTopologyPath != null) {
                    Object errorCode = null;
                    Map<String, Object> pathResponseMap = syncPath(gridTopologyPath);
                    if (pathResponseMap != null && pathResponseMap.containsKey("ErrorCode")) {
                        errorCode = pathResponseMap.get("ErrorCode");
                    }
                    log.debug("Network sync response from TME for path {} is {}", gridTopologyPath.getPathId(), pathResponseMap);
                    if (pathResponseMap == null || !pathResponseMap.containsKey("ErrorCode") || (errorCode != null && Integer.parseInt(errorCode.toString()) != 0)) {
                        log.error("Failed to sync the network path with TME, updating the policies with another path. error code : {}", errorCode);
                        gridTopologyPath.setIsActive(false);
                        gridTopologyPathRepository.save(gridTopologyPath);

                        GridMatrix gridMatrix = gridMatrixRepository.findByTopologyPathId(gridTopologyPath.getId());
                        if (gridMatrix != null && gridMatrix.getGridPolicySetId() != null) {
                            GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(gridMatrix.getGridPolicySetId());
                            if (gridPolicySet != null && WorkflowParticipant.WorkflowStatus.ERROR != gridPolicySet.getWorkflowStatus()) {
                                if (networkPathSwitchAutoLimit == 0 || gridMatrix.getFailureCount() < networkPathSwitchAutoLimit) {
                                    try {
                                        updatePathFailedPolicy(gridTopologyPath.getPathId(), true);
                                    } catch (Exception e) {
                                        log.error("Network path sync failed for path {} due to {}", gridTopologyPath.getPathId(), e.getMessage());
                                    }
                                } else {
                                    log.error("Skipping the network path sync as network path switch limit (" + networkPathSwitchAutoLimit + ") exceeded by {} for pathId {}", gridMatrix.getFailureCount(), gridTopologyPath.getPathId());
                                }
                            } else if (gridPolicySet != null) {
                                log.error("Skipping the network path sync as policy {} is in error state, pathId {}", gridPolicySet.getId(), gridTopologyPath.getPathId());
                            }
                        }
                    } else {
                        log.debug("Network path sync is successful for path id {}.", gridTopologyPath.getPathId());
                    }
                }
            } catch (Exception e) {
                log.error("Failed to sync the network path id {}. {}", gridTopologyPath.getPathId(), e.getMessage());
            }
        });
        return true;
    }

    /**
     * Parse and validate the topology response map returned by the path request api.
     *
     * @param pathResponseMap
     * @param destinationNodeEgressPorts
     * @param destinationNodeEgressPortGroups
     * @return
     */
    private GridTopologyPath parsePathResponseAndMakeTopology(Map<String, Object> pathResponseMap, Set<Port> sourceNodeIngressPorts, Set<PortGroup> sourceNodeIngressPortGroups,
                                                              Set<Port> destinationNodeEgressPorts, Set<PortGroup> destinationNodeEgressPortGroups, boolean isOverSubscriptionAllowed, String aggregatorName, String distributorName) {
        GridTopologyPath gridTopologyPath = new GridTopologyPath();
        if (pathResponseMap.containsKey("Path")) {
            gridTopologyPath.setPathJson(String.valueOf(pathResponseMap.get("Path")));
        }
        if (pathResponseMap.containsKey("PathID")) {
            gridTopologyPath.setPathId(Long.valueOf(pathResponseMap.get("PathID").toString()));
        }
        if (!isOverSubscriptionAllowed && pathResponseMap.containsKey("OverSub") && pathResponseMap.get("OverSub") != null) {
            List<Map> overSubList = (List<Map>) pathResponseMap.get("OverSub");
            if (overSubList != null) {
                overSubList.forEach(overSub -> {
                    Object hop = overSub.get("Hop");
                    Integer origCost = 0;
                    Integer subCost = 0;
                    if (overSub.containsKey("OrigCost")) {
                        origCost = Integer.parseInt(overSub.get("OrigCost").toString());
                    }
                    if (overSub.containsKey("SubCost")) {
                        subCost = Integer.parseInt(overSub.get("SubCost").toString());
                    }
                    if (subCost > origCost) {
                        log.error("Network path {} is oversubscribed. Requested bandwidth is not available.", hop);
                        if (gridTopologyPath.getPathId() != null) {
                            deletePath(gridTopologyPath.getPathId());
                        }
                        throw new ValidationException("Network path is oversubscribed. Requested bandwidth is not available. Please recover the policy, enable oversubscription option and retry.");
                    }
                });
            }
        }
        if (pathResponseMap.containsKey("ErrorCode")) {
            Integer errorCode = Integer.parseInt(pathResponseMap.get("ErrorCode").toString());
            if (errorCode != null && errorCode != 0) {
                log.error("Error code received from tme {}", errorCode);
            }
        }
        parsePathResponse(gridTopologyPath, gridTopologyPath.getPathJson());
        if (gridTopologyPath.getSourceNetworkNode() != null) {
            NetworkNode sourceNetworkNode = gridTopologyPath.getSourceNetworkNode();
            sourceNetworkNode.setIngressPorts(sourceNodeIngressPorts);
            sourceNetworkNode.setIngressPortGroups(sourceNodeIngressPortGroups);
        }
        if (gridTopologyPath.getDestinationNetworkNode() != null) {
            NetworkNode destinationNetworkNode = gridTopologyPath.getDestinationNetworkNode();
            destinationNetworkNode.setEgressPorts(destinationNodeEgressPorts);
            destinationNetworkNode.setEgressPortGroups(destinationNodeEgressPortGroups);
        }
        if (gridTopologyPath.getSourceNetworkNode() == null || gridTopologyPath.getDestinationNetworkNode() == null) {
            if (gridTopologyPath.getPathId() != null) {
                deletePath(gridTopologyPath.getPathId());
            }
            if (gridTopologyPath.getSourceNetworkNode() == null) {
                log.error("Failed to identify the path for aggregator device {}.", aggregatorName);
                throw new ValidationException("Failed to identify the network path from aggregator device " + aggregatorName + " to distributor device " + distributorName + ".");
            } else if (gridTopologyPath.getDestinationNetworkNode() == null) {
                log.error("Failed to identify the path for destination device {}.", distributorName);
                throw new ValidationException("Failed to identify the network path from aggregator device " + aggregatorName + " to distributor device " + distributorName + ".");
            }
        }
        if (gridTopologyPath.getSourceNetworkNode().getEgressPortsAndPortGroups().size() == 0) {
            if (gridTopologyPath.getPathId() != null) {
                deletePath(gridTopologyPath.getPathId());
            }
            log.error("Egress port/port group is empty for aggregator device.");
            throw new ValidationException("Egress port/port group cannot be empty for aggregator device.");
        }
        if (gridTopologyPath.getDestinationNetworkNode().getIngressPortsAndPortGroups().size() == 0) {
            if (gridTopologyPath.getPathId() != null) {
                deletePath(gridTopologyPath.getPathId());
            }
            log.error("Ingress port/port group is empty for distributor device.");
            throw new ValidationException("Ingress port/port group cannot be empty for distributor device.");
        }
        return gridTopologyPath;
    }

    /**
     * Topology path parser using pattern.
     *
     * @param gridTopologyPath
     * @param path
     */
    private void parsePathResponse(GridTopologyPath gridTopologyPath, String path) {
        if (!Strings.isNullOrEmpty(path)) {
            Pattern pattern = Pattern.compile("^->([0-9a-f\\.]+->[A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)->(([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->[0-9a-f\\.]+->[A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->)+)*([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->[0-9a-f\\.]+)$");
            Matcher matcher = pattern.matcher(path);
            if (matcher.matches()) {
                String firstGroup = matcher.group(1);
                String secondGroup = matcher.group(2);
                String thirdGroup = matcher.group(4);

                if (!Strings.isNullOrEmpty(firstGroup) && !Strings.isNullOrEmpty(thirdGroup)) {
                    List<String> firstGroupList = Lists.newArrayList(firstGroup.split("->"));
                    List<String> thirdGroupList = Lists.newArrayList(thirdGroup.split("->"));

                    NetworkNode sourceNetworkNode = new NetworkNode();
                    NetworkNode destinationNetworkNode = new NetworkNode();
                    SortedSet<IntermediateNode> intermediateNodes = new TreeSet<>();

                    String srcInterfaceEgress = firstGroupList.get(1);
                    String destInterfaceIngress = thirdGroupList.get(0);
                    String sourceDeviceChassis = firstGroupList.get(0);
                    Device sourceNetworkNodeDevice = deviceRepository.findByChassis(sourceDeviceChassis);
                    if (sourceNetworkNodeDevice != null) {
                        sourceNetworkNode.setDevice(sourceNetworkNodeDevice);
                        if (srcInterfaceEgress.contains("Ethernet")) {
                            Port port = portRepository.findPortByNameAndDeviceId(srcInterfaceEgress, sourceNetworkNodeDevice.getId());
                            if (port != null) {
                                sourceNetworkNode.addEgressPort(port);
                                port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                                port.setType(Port.Type.SERVICE_PORT);
                            } else {
                                log.error("Aggregator Port not found by name {} on device {}", srcInterfaceEgress, sourceNetworkNodeDevice.getId());
                                throw new ValidationException("The port " + srcInterfaceEgress + " not found on the device " + sourceNetworkNodeDevice.getName() + "! Perform a StableNet and/or Visibility Manager refresh and retry.");
                            }
                        } else if (srcInterfaceEgress.contains("Port-channel")) {
                            srcInterfaceEgress = srcInterfaceEgress.replace("Port-channel", "");
                            PortGroup portGroup = portGroupRepository.findByNameAndDeviceId(srcInterfaceEgress.trim(), sourceNetworkNodeDevice.getId());
                            if (portGroup != null) {
                                if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                                    log.error("Aggregator Port Channel {} on {} is in error state.", srcInterfaceEgress, sourceNetworkNodeDevice.getId());
                                    throw new ValidationException("The port channel " + srcInterfaceEgress + " on the device " + sourceNetworkNodeDevice.getName() + " is in error state. Please recover the port channel and try again.");
                                }
                                sourceNetworkNode.addEgressPortGroup(portGroup);
                            } else {
                                log.error("Aggregator Port Channel {} not found on {}", srcInterfaceEgress, sourceNetworkNodeDevice.getId());
                                throw new ValidationException("The port channel " + srcInterfaceEgress + " not found on the device " + sourceNetworkNodeDevice.getName() + "!");
                            }
                        }
                    } else {
                        log.error("Invalid aggregator device, device is not identified by chassis ", sourceDeviceChassis);
                        if (gridTopologyPath.getPathId() != null) {
                            deletePath(gridTopologyPath.getPathId());
                        }
                        throw new ValidationException("The aggregator device " + sourceDeviceChassis + " is not listed in the inventory. Discover the device and apply the policy again. ");
                    }

                    String destinationDeviceChassis = thirdGroupList.get(1);
                    Device destinationNetworkNodeDevice = deviceRepository.findByChassis(destinationDeviceChassis);
                    if (destinationNetworkNodeDevice != null) {
                        destinationNetworkNode.setDevice(destinationNetworkNodeDevice);
                        if (destInterfaceIngress.contains("Ethernet")) {
                            Port port = portRepository.findPortByNameAndDeviceId(destInterfaceIngress, destinationNetworkNodeDevice.getId());
                            if (port != null) {
                                destinationNetworkNode.addIngressPort(port);
                            } else {
                                log.error("Distributor Port not found by name {} on device {}", destInterfaceIngress, destinationNetworkNodeDevice.getId());
                                throw new ValidationException("The port " + destInterfaceIngress + " not found on the device " + destinationNetworkNodeDevice.getName() + "! Perform a StableNet and/or Visibility Manager refresh and retry.");
                            }
                        } else if (destInterfaceIngress.contains("Port-channel")) {
                            destInterfaceIngress = destInterfaceIngress.replace("Port-channel", "");
                            PortGroup portGroup = portGroupRepository.findByNameAndDeviceId(destInterfaceIngress.trim(), destinationNetworkNodeDevice.getId());
                            if (portGroup != null) {
                                if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                                    log.error("Distributor Port Channel {} on {} is in error state.", destInterfaceIngress, destinationNetworkNodeDevice.getId());
                                    throw new ValidationException("The port channel " + destInterfaceIngress + " on the device " + destinationNetworkNodeDevice.getName() + " is in error state. Please recover the port channel and try again.");
                                }
                                destinationNetworkNode.addIngressPortGroup(portGroup);
                            } else {
                                log.error("Distributor Port Channel {} not found on device {}", destInterfaceIngress, destinationNetworkNodeDevice.getId());
                                throw new ValidationException("The port channel " + destInterfaceIngress + " not found on the device " + destinationNetworkNodeDevice.getName() + "!");
                            }
                        }
                    } else {
                        log.error("Invalid distributor device, device is not identified by chassis ", destinationDeviceChassis);
                        if (gridTopologyPath.getPathId() != null) {
                            deletePath(gridTopologyPath.getPathId());
                        }
                        throw new ValidationException("The distributor device " + destinationDeviceChassis + " is not listed in the inventory. Discover the device and apply the policy again. ");
                    }

                    if (!Strings.isNullOrEmpty(secondGroup)) {
                        Pattern internalNetworkInfoPattern = Pattern.compile("(([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)->([0-9a-f\\.]+)->([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)+)+");
                        Matcher internalNetworkInfoMatcher = internalNetworkInfoPattern.matcher(secondGroup);
                        int sequence = 0;
                        while (internalNetworkInfoMatcher.find()) {
                            String intermediateInterfaceIngress = internalNetworkInfoMatcher.group(2);
                            String intermediateInterfaceEgress = internalNetworkInfoMatcher.group(4);
                            String intermediateDeviceChassis = internalNetworkInfoMatcher.group(3);
                            Device internalNodeDevice = deviceRepository.findByChassis(intermediateDeviceChassis);
                            if (internalNodeDevice != null) {
                                IntermediateNode internalNode = new IntermediateNode();
                                internalNode.setDevice(internalNodeDevice);
                                if (intermediateInterfaceIngress.contains("Ethernet")) {
                                    Port port = portRepository.findPortByNameAndDeviceId(intermediateInterfaceIngress, internalNodeDevice.getId());
                                    if (port != null) {
                                        internalNode.addIngressPort(port);
                                    } else {
                                        log.error("Intermediate Port not found by name {} on {}", intermediateInterfaceIngress, internalNodeDevice.getId());
                                        throw new ValidationException("The port " + intermediateInterfaceIngress + " not found on the device " + internalNodeDevice.getName() + "! Perform a StableNet and/or Visibility Manager refresh and retry.");
                                    }
                                } else if (intermediateInterfaceIngress.contains("Port-channel")) {
                                    intermediateInterfaceIngress = intermediateInterfaceIngress.replace("Port-channel", "");
                                    PortGroup portGroup = portGroupRepository.findByNameAndDeviceId(intermediateInterfaceIngress.trim(), internalNodeDevice.getId());
                                    if (portGroup != null) {
                                        if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                                            log.error("Intermediate ingress Port Channel {} on {} is in error state.", intermediateInterfaceIngress, internalNodeDevice.getId());
                                            throw new ValidationException("The port channel " + intermediateInterfaceIngress + " on the device " + internalNodeDevice.getName() + " is in error state. Please recover the port channel and try again.");
                                        }
                                        internalNode.addIngressPortGroup(portGroup);
                                    } else {
                                        log.error("Intermediate Port Channel not found by id {} on {}", intermediateInterfaceIngress, internalNodeDevice.getId());
                                        throw new ValidationException("The port channel " + intermediateInterfaceIngress + " not found on the device " + internalNodeDevice.getName() + "!");
                                    }
                                }
                                if (intermediateInterfaceEgress.contains("Ethernet")) {
                                    Port port = portRepository.findPortByNameAndDeviceId(intermediateInterfaceEgress, internalNodeDevice.getId());
                                    if (port != null) {
                                        internalNode.addEgressPort(port);
                                    } else {
                                        log.error("Intermediate Port not found by name {} on {}", intermediateInterfaceEgress, internalNodeDevice.getId());
                                        throw new ValidationException("The port " + intermediateInterfaceEgress + " not found on the device " + internalNodeDevice.getName() + "! Perform a StableNet and/or Visibility Manager refresh and retry.");
                                    }
                                } else if (intermediateInterfaceEgress.contains("Port-channel")) {
                                    intermediateInterfaceEgress = intermediateInterfaceEgress.replace("Port-channel", "");
                                    PortGroup portGroup = portGroupRepository.findByNameAndDeviceId(intermediateInterfaceEgress.trim(), internalNodeDevice.getId());
                                    if (portGroup != null) {
                                        if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                                            log.error("Intermediate egress Port Channel {} on {} is in error state.", intermediateInterfaceEgress, internalNodeDevice.getId());
                                            throw new ValidationException("The port channel " + intermediateInterfaceEgress + " on the device " + internalNodeDevice.getName() + " is in error state. Please recover the port channel and try again.");
                                        }
                                        internalNode.addEgressPortGroup(portGroup);
                                    } else {
                                        log.error("Intermediate Port Channel not found by id {} on {}", intermediateInterfaceEgress, internalNodeDevice.getId());
                                        throw new ValidationException("The port channel " + intermediateInterfaceEgress + " not found on the device " + internalNodeDevice.getName() + "!");
                                    }
                                }
                                internalNode.setSequence(sequence++);
                                intermediateNodes.add(internalNode);
                            } else {
                                log.error("Invalid intermediate device, device is not identified by chassis ", intermediateDeviceChassis);
                                if (gridTopologyPath.getPathId() != null) {
                                    deletePath(gridTopologyPath.getPathId());
                                }
                                throw new ValidationException("The device " + intermediateDeviceChassis + " is not listed in the inventory. Discover the device and apply the policy again.");
                            }
                        }
                    }
                    gridTopologyPath.setSourceNetworkNode(sourceNetworkNode);
                    gridTopologyPath.setDestinationNetworkNode(destinationNetworkNode);
                    gridTopologyPath.setIntermediateNodes(intermediateNodes);
                }
            }
        }
    }

    private boolean isUpdateToolAddressRequired(GridMatrix gridMatrix, Long deviceId) {
        AtomicBoolean isUpdateRequired = new AtomicBoolean(false);
        if (gridMatrix != null) {
            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
            if (gridMatrixHistory != null) {
                Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = getToolAddressMap(gridMatrix.getGridTopologyPaths(), deviceId);
                Map<Integer, ToolAddressInterface> groupToolInterfaceHistoryMap = getToolAddressMap(gridMatrixHistory.getGridTopologyPaths(), deviceId);
                if (toolAddressInterfaceMap != null && groupToolInterfaceHistoryMap != null) {
                    groupToolInterfaceHistoryMap.forEach((toolAddress, toolAddressExisting) -> {
                        ToolAddressInterface toolAddressUpdated = toolAddressInterfaceMap.get(toolAddress);
                        if (toolAddressUpdated == null) {
                            isUpdateRequired.set(true);
                        }
                    });
                    if (!isUpdateRequired.get()) {
                        toolAddressInterfaceMap.forEach((toolAddress, toolAddressUpdated) -> {
                            ToolAddressInterface toolAddressExisting = groupToolInterfaceHistoryMap.get(toolAddress);
                            if (toolAddressExisting != null) {
                                if (!compare(toolAddressUpdated, toolAddressExisting)) {
                                    isUpdateRequired.set(true);
                                }
                            } else {
                                isUpdateRequired.set(true);
                            }
                        });
                    }
                }
            }
        }
        return isUpdateRequired.get();
    }

    private boolean isUpdateToolGroupAddressRequired(GridMatrix gridMatrix, Long deviceId, boolean isAdd) {
        AtomicBoolean isUpdateRequired = new AtomicBoolean(false);
        if (gridMatrix != null) {
            GridMatrix gridMatrixHistory = getGridMatrixFromHistory(gridMatrix.getId());
            if (gridMatrixHistory != null) {
                Map<Integer, Set<Integer>> groupToolAddressesMap = getToolGroupMap(gridMatrix.getDestinationGroups(), gridMatrix.getGridTopologyPaths(), deviceId);
                Map<Integer, Set<Integer>> groupToolAddressesHistoryMap = getToolGroupMap(gridMatrixHistory.getDestinationGroups(), gridMatrixHistory.getGridTopologyPaths(), deviceId);
                if (groupToolAddressesMap != null && groupToolAddressesHistoryMap != null) {
                    if (!isAdd) {
                        groupToolAddressesHistoryMap.forEach((groupId, toolAddressSetExisting) -> {
                            Set<Integer> toolAddressSetUpdated = groupToolAddressesMap.get(groupId);
                            if (toolAddressSetUpdated != null && !toolAddressSetUpdated.isEmpty() && toolAddressSetExisting != null && !toolAddressSetExisting.isEmpty()) {
                                Set<Integer> toolAddressAdded = Sets.difference(toolAddressSetUpdated, toolAddressSetExisting);
                                Set<Integer> toolAddressDeleted = Sets.difference(toolAddressSetExisting, toolAddressSetUpdated);
                                if (!toolAddressAdded.isEmpty() || !toolAddressDeleted.isEmpty()) {
                                    isUpdateRequired.set(true);
                                }
                            }
                            if (toolAddressSetUpdated == null || toolAddressSetUpdated.isEmpty()) {
                                isUpdateRequired.set(true);
                            }
                        });
                    } else {
                        groupToolAddressesMap.forEach((groupId, toolAddressSetUpdated) -> {
                            Set<Integer> toolAddressSetExisting = groupToolAddressesHistoryMap.get(groupId);
                            if (toolAddressSetUpdated != null && !toolAddressSetUpdated.isEmpty() && toolAddressSetExisting != null && !toolAddressSetExisting.isEmpty()) {
                                Set<Integer> toolAddressAdded = Sets.difference(toolAddressSetUpdated, toolAddressSetExisting);
                                Set<Integer> toolAddressDeleted = Sets.difference(toolAddressSetExisting, toolAddressSetUpdated);
                                if (!toolAddressAdded.isEmpty() || !toolAddressDeleted.isEmpty()) {
                                    isUpdateRequired.set(true);
                                }
                            }
                            if (toolAddressSetExisting == null || toolAddressSetExisting.isEmpty()) {
                                isUpdateRequired.set(true);
                            }
                        });
                    }
                }
            }
        }
        return isUpdateRequired.get();
    }

    private Map<Integer, Set<Integer>> getToolGroupMap(Set<DestinationGroup> destinationGroups, Set<GridTopologyPath> gridTopologyPaths, Long deviceId) {
        Map<Integer, Set<Integer>> groupToolAddressesMap = Maps.newHashMap();
        if (destinationGroups != null && gridTopologyPaths != null) {
            destinationGroups.stream().forEach(destinationGroup -> {
                Integer groupId = destinationGroup.getGroupId();
                destinationGroup.getGridTopologyPathIds().forEach(gridTopologyPathId -> {
                    Optional<GridTopologyPath> gridTopologyPathOptional = gridTopologyPaths.stream().filter(gridTopologyPath -> gridTopologyPath.getId() == gridTopologyPathId).findFirst();
                    if (gridTopologyPathOptional.isPresent()) {
                        GridTopologyPath gridTopologyPath = gridTopologyPathOptional.get();
                        if (gridTopologyPath != null && gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                            Set<Integer> toolAddressSet = Sets.newHashSet();
                            if (groupToolAddressesMap.containsKey(groupId)) {
                                toolAddressSet = groupToolAddressesMap.get(groupId);
                            }
                            toolAddressSet.add(gridTopologyPath.getToolAddress());
                            groupToolAddressesMap.put(groupId, toolAddressSet);
                        }
                    }
                });
            });
        }
        return groupToolAddressesMap;
    }

    private Map<Integer, ToolAddressInterface> getToolAddressMap(Set<GridTopologyPath> gridTopologyPaths, Long deviceId) {
        Map<Integer, ToolAddressInterface> toolAddressInterfaceMap = Maps.newHashMap();
        if (gridTopologyPaths != null) {
            gridTopologyPaths.forEach(gridTopologyPath -> {
                if (gridTopologyPath.getSourceNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setType(FABRIC);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getSourceNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else if (gridTopologyPath.getDestinationNetworkNode().getDevice().getId() == deviceId) {
                    Integer toolAddress = gridTopologyPath.getToolAddress();
                    if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                        ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                        toolAddressInterface.setToolAddress(toolAddress);
                        toolAddressInterface.setType(EDGE);
                        toolAddressInterface.setManagedObjects(gridTopologyPath.getDestinationNetworkNode().getEgressPortsAndPortGroups());
                        toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                    }
                } else {
                    gridTopologyPath.getIntermediateNodes().forEach(intermediateNode -> {
                        if (intermediateNode.getDevice().getId() == deviceId) {
                            Integer toolAddress = gridTopologyPath.getToolAddress();
                            if (!toolAddressInterfaceMap.containsKey(toolAddress)) {
                                ToolAddressInterface toolAddressInterface = new ToolAddressInterface();
                                toolAddressInterface.setToolAddress(toolAddress);
                                toolAddressInterface.setManagedObjects(intermediateNode.getEgressPortsAndPortGroups());
                                toolAddressInterface.setType(FABRIC);
                                toolAddressInterfaceMap.put(toolAddress, toolAddressInterface);
                            }
                        }
                    });
                }
            });
        }
        return toolAddressInterfaceMap;
    }

    private boolean compare(ToolAddressInterface toolAddressInterfaceUpdated, ToolAddressInterface toolAddressInterfaceExisting) {
        if (toolAddressInterfaceUpdated != null && toolAddressInterfaceExisting != null) {
            if (toolAddressInterfaceUpdated.getType() != null && toolAddressInterfaceUpdated.getType().equals(toolAddressInterfaceExisting.getType()) &&
                    toolAddressInterfaceUpdated.getToolAddress() != null && toolAddressInterfaceUpdated.getToolAddress() == toolAddressInterfaceExisting.getToolAddress() &&
                    toolAddressInterfaceUpdated.getManagedObjects().size() != 0 && toolAddressInterfaceUpdated.getManagedObjects().size() == toolAddressInterfaceExisting.getManagedObjects().size()) {
                Set<Long> updatedManagedObjectIds = toolAddressInterfaceUpdated.getManagedObjects().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                Set<Long> existingManagedObjectIds = toolAddressInterfaceExisting.getManagedObjects().stream().map(ManagedObject::getId).collect(Collectors.toSet());
                Set<Long> differenceSet = Sets.difference(updatedManagedObjectIds, existingManagedObjectIds);
                if (differenceSet.isEmpty())
                    return true;
            }
        }
        return false;
    }

    private GridMatrix getGridMatrixFromHistory(Long matrixId) {
        List<GridMatrixHistory> gridMatrixHistoryList = gridMatrixHistoryRepository.findByIdAndWorkflowStatus(matrixId, WorkflowParticipant.WorkflowStatus.ACTIVE);
        GridMatrix gridMatrix = null;
        if (gridMatrixHistoryList.size() >= 1) {
            GridMatrixHistory gridMatrixHistory = gridMatrixHistoryList.get(0);
            gridMatrix = gridMatrixHistory.buildParent();
        }
        return gridMatrix;
    }

    /**
     * This method is used to set the default value for null fields
     *
     * @param policy
     * @return ResponseEntity<Object> This returns policy
     */
    private Policy updateNullFieldsForPolicy(Policy policy) {
        policy.getFlows().stream().forEach(flow -> {
            if (flow.getIsTagged() == null)
                flow.setIsTagged(false);
            if (flow.getIsDefaultRouteMapDrop() == null)
                flow.setIsDefaultRouteMapDrop(false);
            flow.getRuleSets().forEach(ruleSet -> {
                ruleSet.getRules().forEach(rule -> {
                    if (rule.getSourcePort() == null)
                        rule.setSourcePort(0);
                    if (rule.getDestinationPort() == null)
                        rule.setDestinationPort(0);
                    if (rule.getVlanId() == null)
                        rule.setVlanId(-1);
                    if (rule.getIsPermit() == null)
                        rule.setIsPermit(false);
                });
            });

        });
        return policy;
    }

    /**
     * Filter the tool/tap interfaces based on the device.
     *
     * @param clusterNodeInterfaces
     * @param deviceNodeInterfaces
     * @return
     */
    private Set<GridClusterRequest> groupNodeInterfacesByDevice(Set<ClusterNodeInterface> clusterNodeInterfaces, Set<GridClusterRequest> deviceNodeInterfaces) {
        clusterNodeInterfaces.forEach(clusterNodeInterface -> {
            ClusterNodeInterface clusterNodeInterfaceInDb = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
            Device device = clusterNodeInterfaceInDb.getGridCluster().getDevice();
            Optional<GridClusterRequest> gridClusterOptional = deviceNodeInterfaces.stream().filter(gridCluster1 -> gridCluster1.getDevice().getId() == device.getId()).findAny();
            GridClusterRequest gridClusterRequest = new GridClusterRequest();
            boolean isNew = true;
            if (gridClusterOptional.isPresent()) {
                gridClusterRequest = gridClusterOptional.get();
                isNew = false;
            }
            Set<ClusterNodeInterfaceRequest> clusterNodeInterfacesGroup = gridClusterRequest.getClusterNodeInterfaces();
            if (!clusterNodeInterfacesGroup.stream().anyMatch(clusterNodeInterfaceRequest -> clusterNodeInterfaceRequest.getId() == clusterNodeInterfaceInDb.getId())) {
                gridClusterRequest.addClusterNodeInterface(clusterNodeInterfaceInDb);
            }
            if (isNew) {
                gridClusterRequest.setDevice(device);
                deviceNodeInterfaces.add(gridClusterRequest);
            }
        });
        return deviceNodeInterfaces;
    }

    /**
     * This method generate an unique tool Id
     *
     * @param toolIdsUsed
     * @return
     */
    private synchronized Integer getToolId(Set<Integer> toolIdsUsed) {
        List<Integer> toolIdAll = new ArrayList();
        for (int i = 1; i <= DeviceGrid.TOOL_ADDRESS_LIMIT; i++) {
            toolIdAll.add(i);
        }
        if (!toolIdsUsed.isEmpty()) {
            toolIdAll.removeAll(toolIdsUsed);
        }
        if (!toolIdAll.isEmpty()) {
            return toolIdAll.get(0);
        } else {
            throw new ValidationException("Tool address limit (" + DeviceGrid.TOOL_ADDRESS_LIMIT + ") exceeded!");
        }
    }

    /**
     * This method generate an unique group Id
     *
     * @param groupIdsUsed
     * @return
     */
    private synchronized Integer getGroupId(Set<Integer> groupIdsUsed) {
        List<Integer> toolIdAll = new ArrayList();
        for (int i = 1; i <= DeviceGrid.TOOL_GROUP_ADDRESS_LIMIT; i++) {
            toolIdAll.add(i);
        }
        if (!groupIdsUsed.isEmpty()) {
            toolIdAll.removeAll(groupIdsUsed);
        }
        if (!toolIdAll.isEmpty()) {
            return toolIdAll.get(0);
        } else {
            throw new ValidationException("Tool group address limit (" + DeviceGrid.TOOL_GROUP_ADDRESS_LIMIT + ") exceeded!");
        }
    }

    /**
     * Generate the event for the failed/errored actions.
     *
     * @param parentObjectId
     * @param jobType
     * @param deviceName
     * @param result
     * @param jobStatus
     */
    public void updateEvent(Long parentObjectId, String jobType, String deviceName, String jobStatus, String result, Event.Severity severity) {
        Event event = new Event();
        event.setParentObjectId(parentObjectId);
        event.setType(jobType);
        event.setJobStatus(jobStatus);
        event.setSeverity(severity);
        event.setCreatedByUser(SecurityContextHolder.getContext().getAuthentication() != null
                ? SecurityContextHolder.getContext().getAuthentication().getName() : configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
        event.setCreatedTime(Instant.now());
        event.setTargetHost(deviceName);
        event.setLastUpdatedTime(Instant.now());
        event.setResult(result);
        eventRepository.save(event);
    }

    /**
     * This method fetches the latest GridPolicySet from history using the current GridPolicySet and it's workflow statuses for delete/recovery validations.
     *
     * @param gridPolicySet
     * @return Policy returns latest ACTIVE or ERROR policy
     */
    protected GridPolicySet getGridPolicySetFromHistory(GridPolicySet gridPolicySet, List<WorkflowParticipant.WorkflowStatus> statuses) {
        GridPolicySet gridPolicySetFromHistory = null;
        if (gridPolicySet != null && gridPolicySet.getId() != null && statuses != null && !statuses.isEmpty()) {
            List<GridPolicySetHistory> gridPolicySetHistoryList = gridPolicySetHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(gridPolicySet.getId(), statuses);
            if (!gridPolicySetHistoryList.isEmpty()) {
                GridPolicySetHistory oldGridPolicySet = gridPolicySetHistoryList.get(0);
                if (HistoryObject.RevisionType.DELETED != oldGridPolicySet.getRevisionType()) {
                    log.debug("Found a grid policy history entity with old name {} and latest name {}", oldGridPolicySet.getName(), gridPolicySet.getName());
                    gridPolicySetFromHistory = oldGridPolicySet.buildParent();
                }
            }
        }
        return gridPolicySetFromHistory;
    }
}
