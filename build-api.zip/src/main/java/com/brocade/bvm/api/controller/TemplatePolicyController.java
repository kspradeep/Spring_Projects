package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.TemplatePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.FlexMatchProfileRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.TemplatePolicyRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.FlexMatchProfile;
import com.brocade.bvm.model.db.TemplatePolicy;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.List;

@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/templatepolicy")
public class TemplatePolicyController {

    public static final String CLEANUP = "cleanup";
    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";
    public static final Integer MIN_SLX_9850_OFFSET = 0;
    public static final Integer MAX_SLX_9850_OFFSET = 63;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private TemplatePolicyRepository templatePolicyRepository;

    @Inject
    private FlexMatchProfileRepository flexMatchProfileRepository;

    /**
     * This method is used to save template policy(DRAFT) in bvm db or create template policy on device based action param
     *
     * @param action
     * @param templatePolicyRequest
     * @return ResponseEntity<Object>
     * @throws JsonProcessingException
     */
    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitPolicy(@RequestParam(value = "action", required = false) String action,
                                                     @RequestBody TemplatePolicyRequest templatePolicyRequest) throws JsonProcessingException {
        log.info("Action on TemplatePolicy to " + action);
        List<Long> jobPolicyIds;
        TemplatePolicy templatePolicy = null;
        if (templatePolicyRequest.getSlxFlexMatchProfile() != null) {
            templatePolicy = templatePolicyRequest.getSlxFlexMatchProfile();
            templatePolicy.setDeviceModel(templatePolicyRequest.getDeviceModel() != null ? templatePolicyRequest.getDeviceModel().toString() : null);
            isValidHeaderField(templatePolicyRequest);
        }
        jobPolicyIds = managerBuilder.getOperationsFactory(new Device()).getTemplatePolicyManager(templatePolicy).saveOrCommitPolicies(Sets.newHashSet(templatePolicy), action);
        if (jobPolicyIds.size() > 0) {
            return new ResponseEntity<>(jobPolicyIds, HttpStatus.OK);
        }
        throw new ValidationException("profile.not.configured");
    }

    /**
     * This method is used to update template policy as DRAFT in bvm db or update template policy on device based action param
     *
     * @param action
     * @param templatePolicyRequest
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitPolicy(@RequestParam(value = "action", required = false) String action,
                                                       @RequestBody TemplatePolicyRequest templatePolicyRequest) {
        if(templatePolicyRequest != null) {
            log.debug("********** Update TemplatePolicy **********");
            List<Long> jobPolicyIds = Lists.newArrayList();
            if (action == null || UPDATE.equalsIgnoreCase(action) || COMMIT.equalsIgnoreCase(action)) {
                TemplatePolicy templatePolicy = null;
                if (templatePolicyRequest.getSlxFlexMatchProfile() != null) {
                    templatePolicy = templatePolicyRequest.getSlxFlexMatchProfile();
                    templatePolicy.setDeviceModel(templatePolicyRequest.getDeviceModel() != null ? templatePolicyRequest.getDeviceModel().toString() : null);
                    isValidHeaderField(templatePolicyRequest);
                    jobPolicyIds = managerBuilder.getOperationsFactory(new Device()).getTemplatePolicyManager(templatePolicy).saveOrCommitPolicies(Sets.newHashSet(templatePolicy), action);
                    if (jobPolicyIds.size() > 0) {
                        return new ResponseEntity<>(jobPolicyIds, HttpStatus.OK);
                    }
                }
            } else {
                throw new ValidationException("policy.action.invalid");
            }
        }
        throw new ValidationException("profile.not.configured");
    }

    /**
     * This method is used to validate the valid header field for SLX 9850 device
     *
     * @param templatePolicyRequest
     * @return
     */
    protected boolean isValidHeaderField(TemplatePolicyRequest templatePolicyRequest) {
        if (templatePolicyRequest.getDeviceModel() != null && templatePolicyRequest.getDeviceModel().equalsIgnoreCase(FlexMatchProfile.SLX_9850)) {
            (templatePolicyRequest.getSlxFlexMatchProfile()).getFlexHeaders().forEach(flexHeader -> {
                flexHeader.getFlexHeaderFields().forEach(flexHeaderField -> {
                    Integer validOffset = (flexHeaderField.getCustomOffset() != null && flexHeaderField.getOffset() != null && flexHeaderField.getCustomOffset() > -1) ? flexHeaderField.getCustomOffset() + flexHeaderField.getOffset() : flexHeaderField.getOffset();
                    if ((validOffset < MIN_SLX_9850_OFFSET || validOffset > MAX_SLX_9850_OFFSET)) {
                        log.error("FlexMatch profile field Offset range is invalid.");
                        throw new ValidationException("policy.save.fieldOffsetRangeInvalid");
                    }
                });
            });
        }
        return true;
    }

    /**
     * This method is used to fetch all template policies for the given device model
     *
     * @param templateId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{templateid}")
    public ResponseEntity<Object> getTemplateById(@PathVariable("templateid") Long templateId) {
        log.debug("get template for policy id {}", templateId);
        TemplatePolicy templatePolicy = templatePolicyRepository.findOne(templateId);
        if (templatePolicy != null) {
            List<Long> policyIds = policyRepository.findIdsByFlexMatchProfileId(templatePolicy.getId());
            if (policyIds != null && !policyIds.isEmpty()) {
                templatePolicy.setIsInUse(true);
            }
        }
        return new ResponseEntity<>(templatePolicy, HttpStatus.OK);
    }


    /**
     * This method is used to fetch all template policies for the given device model
     *
     * @param deviceModel
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Object> getPolicyByDeviceId(@RequestParam(value = "devicemodel", required = false) String deviceModel) {
        log.debug("get template policies for device model {}", deviceModel);
        List<TemplatePolicy> templatePolicies;
        if (deviceModel == null) {
            //Specific for SLX9240/SLX9140 templates : Model = SLX9240 or null
            templatePolicies = templatePolicyRepository.findByDeviceModelAndNullDeviceModel(null);
        } else {
            if (deviceModel.equals("all")) {
                templatePolicies = Lists.newArrayList(templatePolicyRepository.findAll());
            } else {
                //For SLX9850 templates : Model = SLX9850 or null
                templatePolicies = templatePolicyRepository.findByDeviceModelAndNullDeviceModel(deviceModel);
            }
        }
        if (templatePolicies != null && !templatePolicies.isEmpty()) {
            templatePolicies.stream().forEach(templatePolicy -> {
                List<Long> policyIds = policyRepository.findIdsByFlexMatchProfileId(templatePolicy.getId());
                if (policyIds != null && !policyIds.isEmpty()) {
                    templatePolicy.setIsInUse(true);
                }
            });
        }
        return new ResponseEntity<>(templatePolicies, HttpStatus.OK);
    }


    /**
     * This method is used to delete template policy for the given policyId
     *
     * @param action
     * @param templateId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{templateid}")
    public ResponseEntity<Object> deleteTemplatePolicy(@RequestParam(value = "action", required = false) String action,
                                                       @PathVariable("templateid") Long templateId) {
        log.debug("********** Delete TemplatePolicy {} **********", templateId);
        Long jobPolicyId;
        TemplatePolicy templatePolicy = templatePolicyRepository.findOne(templateId);
        if (templatePolicy != null) {
            if (CLEANUP.equalsIgnoreCase(action)) {
                jobPolicyId = managerBuilder.getOperationsFactory(new Device()).getTemplatePolicyManager(templatePolicy).deletePolicy(templatePolicy.getId());
                return new ResponseEntity<>(jobPolicyId, HttpStatus.OK);
            } else {
                throw new ValidationException("policy.action.invalid");
            }
        }
        throw new ValidationException("policy.get.notfound");
    }
}
