package com.brocade.bvm.api.manager.openflow;

import com.brocade.bvm.api.manager.generic.AbstractPortManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.Port.AdminStatus;
import com.brocade.bvm.model.db.Port.Mode;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The PortManagerOpenFlow class implements methods related to port for NonOpenFlow
 */
@Named
@Slf4j
public class PortManagerOpenFlow extends AbstractPortManager {

    @Inject
    private PortRepository portRepository;

    @Override
    protected boolean isPortTypeJobRequired() {
        return false;
    }

    /**
     * This method used to find the applicable ports, whose admin status, mode is not same as the selected admin status, mode
     *
     * @param portIds
     * @param status
     * @param mode
     * @throws ValidationException
     */
    @Override
    protected List<Port> filterAdminPorts(List<Long> portIds, AdminStatus status, Mode mode) {
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .filter(port -> (port.getAdminStatus() != status || port.getMode() != mode))
                .collect(Collectors.toList());
        return applicablePorts;
    }

    /**
     * This method validates if the selected port(s) are part of any Policy, before changing the AdminStatus
     *
     * @param portIds
     * @throws ValidationException
     */
    protected void isValidForAdminStatus(List<Long> portIds) {
        List<BigInteger> policyIds = flowRepository.findPolicyIdsInIngressPortMapping(portIds);
        policyIds.addAll(flowRepository.findPolicyIdsInEgressPortMapping(portIds));
        if (policyIds != null && policyIds.size() > 0) {
            policyIds.stream().forEach(policyId -> {
                Policy policy = policyRepository.findOne(policyId.longValue());
                if (policy != null) {
                    log.error("Port already in use in another Policy {}", policy.getId());
                    throw new ValidationException("port.operation.usedinpolicy");
                }
            });
        }
    }

    /**
     * This method validates ports
     *
     * @param portIds
     * @throws ValidationException
     */
    protected void isValidForTypeChange(Long deviceId, List<Long> portIds) {

    }

    public long updatePortSpeed(Long deviceId, List<Long> portIds, Long lineSpeed) {
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .collect(Collectors.toList());
        if (applicablePorts.stream().anyMatch(port -> {
            return port.getWorkflowStatus() != null && port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR;
        })) {
            throw new ValidationException("port.speed.notallowed");
        }

        applicablePorts.stream().forEach(port -> {
            port.setLineSpeed(lineSpeed);
        });

        portRepository.save(applicablePorts);
        long jobId = 0; // Return 0 if no job is created
        Job.Type jobType = Job.Type.PORT_SPEED_UPDATE;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());

        return jobId;
    }

}
