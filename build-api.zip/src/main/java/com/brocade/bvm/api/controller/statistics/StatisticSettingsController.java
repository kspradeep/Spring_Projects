package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.manager.statistics.StatisticsSettingsManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.model.grid.GridDeviceInfoRequest;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

@RestController
public class StatisticSettingsController {

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private StatisticsSettingsManager statisticsSettingsManager;

    @RequestMapping(value = "/{threshold}/threshold", method = RequestMethod.POST)
    public void setThreshold(@PathVariable("threshold") float threshold) {
        if (threshold < 1 || threshold > 100) {
            throw new ValidationException("threshold.out.of.range");
        }

        ApplicationConstant constant =
                featureConstantsRepository.findByName(
                        ApplicationConstant.THRESHOLD.UTILIZATION_THRESHOLD.getConstant());
        if (constant == null) {
            constant = new ApplicationConstant();
        }
        constant.setName(ApplicationConstant.THRESHOLD.UTILIZATION_THRESHOLD.getConstant());
        constant.setValue(String.valueOf(threshold));
        featureConstantsRepository.save(constant);
    }

    @RequestMapping(value = "/{interval}/interval", method = RequestMethod.POST)
    public void setInterval(@PathVariable("interval") int interval) {
        List<Integer> validOptions = Arrays.asList(30, 60, 90);
        if (!validOptions.contains(interval)) {
            throw new ValidationException("interval.not.valid");
        }

        ApplicationConstant intervalConstant =
                featureConstantsRepository.findByName(ApplicationConstant.THRESHOLD.INTERVAL.getConstant());
        if (intervalConstant == null) {
            intervalConstant = new ApplicationConstant();
        }
        intervalConstant.setName(ApplicationConstant.THRESHOLD.INTERVAL.getConstant());
        intervalConstant.setValue(String.valueOf(interval));
        featureConstantsRepository.save(intervalConstant);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/threshold")
    public float getThreshold() {

        ApplicationConstant utilization =
                featureConstantsRepository.findByName(
                        ApplicationConstant.THRESHOLD.UTILIZATION_THRESHOLD.getConstant());
        if (utilization == null) {
            utilization = new ApplicationConstant();
            utilization.setValue("100");
        }

        return Float.parseFloat(utilization.getValue());
    }

    @RequestMapping(method = RequestMethod.GET, value = "/interval")
    public int getInterval() {
        ApplicationConstant constant =
                featureConstantsRepository.findByName(ApplicationConstant.THRESHOLD.INTERVAL.getConstant());
        if (constant == null) {
            constant = new ApplicationConstant();
            constant.setValue("30");
        }

        return Integer.parseInt(constant.getValue());
    }

    /**
     * Method clears the statistic counters on the target devices/grids.
     *
     * @param gridDeviceInfoRequest
     * @return
     */
    @RequestMapping(value = "/statistics/counters/clear", method = RequestMethod.PUT)
    public ResponseEntity<Object> clearCounters(@RequestBody GridDeviceInfoRequest gridDeviceInfoRequest) {
        if (gridDeviceInfoRequest == null) {
            throw new ValidationException("Invalid input!.");
        }
        statisticsSettingsManager.clearCounters(gridDeviceInfoRequest);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
