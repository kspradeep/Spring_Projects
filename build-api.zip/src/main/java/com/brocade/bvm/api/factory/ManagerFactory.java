/**
 *
 */
package com.brocade.bvm.api.factory;

import com.brocade.bvm.api.manager.*;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.ModulePolicy;
import com.brocade.bvm.model.db.TemplatePolicy;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;

import java.util.Set;

public interface ManagerFactory {
    PortManager getPortManager();

    PolicyManager getPolicyManager();

    PortGroupManager getPortGroupManager();

    ModulePolicyManager getModulePolicyManager(ModulePolicyRequest request);

    ModulePolicyManager getModulePolicyManager(ModulePolicy modulePolicy);

    DevicePolicyManager getDevicePolicyManager(Set<? extends DevicePolicy> devicePolicy);

    DevicePolicyManager getDevicePolicyManager(DevicePolicy devicePolicy);

    SdPolicyManager getSdPolicyManager(Set<? extends SdPolicy> Policy);

    SdPolicyManager getSdPolicyManager(SdPolicy policy);

    SdPortGroupManager getSdPortGroupManager();

    TemplatePolicyManager getTemplatePolicyManager(Set<? extends TemplatePolicy> templatePolicies);

    TemplatePolicyManager getTemplatePolicyManager(TemplatePolicy templatePolicy);

}
