package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractDevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.SlxPtpPolicy;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collections;

/**
 * The SlxPtpManagerNonOpenflow class implements methods to Enable/Disable PTP for SLX Classic
 */
@Named
public class SlxPtpManagerNonOpenflow extends AbstractDevicePolicyManager {

    private static final String SLX_9850 = "SLX9850";

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * Validating the Slx Ptp policy
     *
     * @param policy
     * @return
     */
    @Override
    protected boolean isValidPolicy(DevicePolicy policy) {
        if (policy != null) {
            Device device = deviceRepository.findOne(policy.getDevice().getId());
            if (device != null && (device.getType() != Device.Type.SLX) || device.getMode() != Device.Mode.PLAIN ||
                    (Device.Type.SLX == device.getType() && device.getModel() != null && device.getModel().contains(SLX_9850))) {
                throw new ValidationException("ptp.policy.not.supported.device");
            }
        }
        return true;
    }

    /**
     * This method is used to create PTP Policy, on the given device
     *
     * @param devicePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long commitPolicy(DevicePolicy devicePolicy) {
        SlxPtpPolicy packetStampingPolicy = (SlxPtpPolicy) devicePolicy;
        isValidPolicy(packetStampingPolicy);
        packetStampingPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetStampingPolicy = devicePolicyRepository.save(packetStampingPolicy);
        Job.Type type = packetStampingPolicy.isEnabled() ? Job.Type.SLX_PTP_ENABLE : Job.Type.SLX_PTP_DISABLE;

        Long jobId = jobQueue.submit(JobTemplate.builder().type(type)
                .deviceId(packetStampingPolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(packetStampingPolicy.getId()).build());
        return jobId;
    }

    @Override
    protected Long updatePolicy(DevicePolicy devicePolicy) {
        SlxPtpPolicy packetStampingPolicy = (SlxPtpPolicy) devicePolicy;
        isValidPolicy(packetStampingPolicy);
        Long jobId = null;
        if (packetStampingPolicy.getId() == null) {
            jobId = commitPolicy(packetStampingPolicy);
        } else {
            SlxPtpPolicy oldDevicePolicy = (SlxPtpPolicy) devicePolicyRepository.findOne(packetStampingPolicy.getId());
            if (oldDevicePolicy == null) {
                throw new ValidationException("ptpDevicePolicy.id.invalid");
            }

            if (isPolicyUnChanged(oldDevicePolicy, packetStampingPolicy)) {
                throw new ValidationException("ptpDevicePolicy.data.unChanged");
            }
            // Merging updated data
            oldDevicePolicy.setName(packetStampingPolicy.getName());
            oldDevicePolicy.setEnabled(packetStampingPolicy.isEnabled());
            oldDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            oldDevicePolicy = devicePolicyRepository.save(oldDevicePolicy);
            packetStampingPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            packetStampingPolicy = devicePolicyRepository.save(packetStampingPolicy);
            Job.Type type = packetStampingPolicy.isEnabled() ? Job.Type.SLX_PTP_ENABLE : Job.Type.SLX_PTP_DISABLE;

            jobId = jobQueue.submit(JobTemplate.builder().type(type)
                    .deviceId(oldDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                    .parentObjectId(oldDevicePolicy.getId()).build());

        }
        return jobId;
    }

    @Override
    public Long deletePolicy(Long policyId) {
        SlxPtpPolicy packetStampingPolicy = (SlxPtpPolicy) devicePolicyRepository.findOne(policyId);
        if (packetStampingPolicy == null) {
            throw new ValidationException("ptpDevicePolicy.id.invalid");
        }
        isValidPolicy(packetStampingPolicy);
        Job.Type type = Job.Type.SLX_PTP_DELETE;

        Long jobId = jobQueue.submit(JobTemplate.builder().type(type)
                .deviceId(packetStampingPolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(packetStampingPolicy.getId()).build());
        return jobId;
    }

    @Override
    public Long recoverPolicy(Long policyId) {
        return deletePolicy(policyId);
    }


    /**
     * This method checks if PTP Policy data is updated
     *
     * @param oldDevicePolicy
     * @param newDevicePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(SlxPtpPolicy oldDevicePolicy, SlxPtpPolicy newDevicePolicy) {
        if (oldDevicePolicy.isEnabled() != newDevicePolicy.isEnabled()) {
            return false;
        }
        return true;
    }

}
