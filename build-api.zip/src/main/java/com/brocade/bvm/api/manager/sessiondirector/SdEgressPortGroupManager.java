package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.manager.SdPortGroupManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.dao.sessiondirector.ActiveInterfaceRepository;
import com.brocade.bvm.dao.sessiondirector.EgressPortGroupHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.EgressPortGroupRepository;
import com.brocade.bvm.dao.sessiondirector.EgressPortRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.EgressPortGroupHistory;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import com.brocade.bvm.model.exception.ServerException;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The SdEgressPortGroupManager class implements methods to perform CRUD operations of egress port group
 */
@Named
@Slf4j
public class SdEgressPortGroupManager implements SdPortGroupManager {

    @Inject
    protected EntityManager entityManager;

    @Inject
    protected EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    protected EgressPortGroupHistoryRepository egressPortGroupHistoryRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    private JobRepository jobRepository;

    @Inject
    private ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    protected JobQueue jobQueue;

    @Value("${stablenet-response.timeout.minutes}")
    private int stablenetTimeoutMinutes;

    @Value("${job.poll.interval.seconds:3}")
    private int jobPollIntervalSeconds;

    private final static String PORT_GROUP_NAME_REGEX = "^[a-zA-Z]{1}.*";

    /**
     * This method is used to save port group to database
     *
     * @param portGroup
     * @return Long This returns jobId
     */
    @Override
    public Long savePortGroup(SdPortGroup portGroup) {
        portGroup.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        Set<EgressPort> ports = new HashSet<>();
        portGroup.getEgressPorts().stream().forEach(egressPort -> {
            EgressPort egressPortFromDb = egressPortRepository.findOne(egressPort.getId());
            if (egressPortFromDb != null) {
                ports.add(egressPortFromDb);
            }
        });
        if (SdPortGroup.LoadBalanceAlgorithms.NO_VLAN != portGroup.getLoadBalance() && ports.isEmpty()) {
            log.error("Port group has no member egress ports!, id {}", portGroup.getId());
            throw new ValidationException("portGroup.empty.port");
        }
        portGroup.setEgressPorts(ports);

        // save port group in DB
        portGroup = egressPortGroupRepository.save(portGroup);
        return portGroup.getId();
    }

    /**
     * This method validate the port group request
     *
     * @param portGroup
     * @throws ValidationException
     */
    protected void isValidPortGroupToSave(SdPortGroup portGroup, Device device) {
        if (portGroup.getName() == null || portGroup.getName().isEmpty()) {
            throw new ValidationException("portGroup.name.empty");
        } else if (portGroup.getName().length() > SdPortGroup.NAME_MAX_LENGTH) {
            throw new ValidationException("sd.portGroup.invalidNameLength");
        } else if (!portGroup.getName().matches(PORT_GROUP_NAME_REGEX)) {
            throw new ValidationException("sd.portGroup.name.first.character");
        } else if (SdPortGroup.LoadBalanceAlgorithms.NO_VLAN != portGroup.getLoadBalance() && (portGroup.getEgressPorts() == null || portGroup.getEgressPorts().isEmpty())) {
            throw new ValidationException("portGroup.empty.port");
        } else if (portGroup.getEgressPorts().size() > SdPortGroup.MAX_PORT_COUNT_ALLOWED) {
            throw new ValidationException("sd.portGroup.max.port.count.allowed");
        } else if (egressPortGroupRepository.findByNameAndDevice(portGroup.getName(), device) != null) {
            log.error("Port group name already in use. Aborting!");
            throw new ValidationException("portGroup.name.exists");
        }
        List<SdPortGroup> egressPortGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!egressPortGroups.isEmpty()) {
            log.error("Cannot commit Port Group as another Port Group operation is in progress, id {}", portGroup.getId());
            throw new ValidationException("port.group.commit.in.progress");
        }
        List<Long> portIds = portGroup.getEgressPorts().stream().map(EgressPort::getId).collect(Collectors.toList());
        Set<EgressPort> portsInDb = StreamSupport.stream(egressPortRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
        portsInDb.forEach(port -> {
            if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                log.error("Member port is in error state. Aborting!");
                throw new ValidationException("egress.port.in.error.state");
            }
        });
        if (portIds.size() != portsInDb.size()) {
            log.error("Some of the selected ports are not present in database.");
            throw new ValidationException("port.selected.missing");
        }
        if (!portIds.isEmpty() && !egressPortGroupRepository.findPortGroupIdsByPortIds(portIds).isEmpty()) {
            log.error("Cannot perform port operation. Port is in use in Port Group");
            throw new ValidationException("port.used.portGroup");
        }
    }

    /**
     * This method validate the port group request
     *
     * @param portGroup
     * @throws ValidationException
     */
    protected void isValidPortGroupToEdit(SdPortGroup portGroup, Device device) {
        if (portGroup.getName() == null || portGroup.getName().isEmpty()) {
            throw new ValidationException("portGroup.name.empty");
        } else if (portGroup.getName().length() > SdPortGroup.NAME_MAX_LENGTH) {
            throw new ValidationException("sd.portGroup.invalidNameLength");
        } else if (!portGroup.getName().matches(PORT_GROUP_NAME_REGEX)) {
            throw new ValidationException("sd.portGroup.name.first.character");
        } else if (SdPortGroup.LoadBalanceAlgorithms.NO_VLAN != portGroup.getLoadBalance() && (portGroup.getEgressPorts() == null || portGroup.getEgressPorts().isEmpty())) {
            throw new ValidationException("portGroup.empty.port");
        } else if (portGroup.getEgressPorts().size() > SdPortGroup.MAX_PORT_COUNT_ALLOWED) {
            throw new ValidationException("sd.portGroup.max.port.count.allowed");
        } else if (portGroup.isDefault() && portGroup.getLoadBalance() != SdPortGroup.LoadBalanceAlgorithms.ROUND_ROBIN) {
            throw new ValidationException("default.portGroup.lb.not.modifiable");
        } else if (WorkflowParticipant.WorkflowStatus.SUBMITTED.equals(portGroup.getWorkflowStatus())) {
            log.error("Can't edit as Port Group with name [{}] on device [{}] which is in progress ", portGroup.getName(), device.getId());
            throw new ValidationException("3011");
        } else if (WorkflowParticipant.WorkflowStatus.ERROR.equals(portGroup.getWorkflowStatus())) {
            log.error("Can't edit as Port Group with name [{}] on device [{}] which is in error state ", portGroup.getName(), device.getId());
            throw new ValidationException("portGroup.in.error");
        }
        List<SdPortGroup> egressPortGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!egressPortGroups.isEmpty()) {
            log.error("Cannot commit Port Group as another Port Group operation is in progress, id {}", portGroup.getId());
            throw new ValidationException("port.group.commit.in.progress");
        }
        SdPortGroup oldPortGroup = egressPortGroupRepository.findById(portGroup.getId());
        List<Long> newPortIds = portGroup.getEgressPorts().stream().map(EgressPort::getId).collect(Collectors.toList());
        List<Long> oldPortIds = oldPortGroup.getEgressPorts().stream().map(EgressPort::getId).collect(Collectors.toList());
        if (!newPortIds.isEmpty()) {
            Set<EgressPort> portsInDb = StreamSupport.stream(egressPortRepository.findAll(newPortIds).spliterator(), false).collect(Collectors.toSet());
            if (newPortIds.size() != portsInDb.size()) {
                log.error("Some of the selected ports are not present in database.");
                throw new ValidationException("port.selected.missing");
            }
            portsInDb.forEach(port -> {
                if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    log.error("Member port is in error state. Aborting!");
                    throw new ValidationException("egress.port.in.error.state");
                }
            });
        }
        oldPortIds.stream().forEach(aLong -> {
            newPortIds.remove(aLong);
        });
        if (!newPortIds.isEmpty() && !egressPortGroupRepository.findPortGroupIdsByPortIds(newPortIds).isEmpty()) {
            log.error("Cannot perform port operation. Port is in use in Port Group");
            throw new ValidationException("port.used.portGroup");
        }
    }

    /**
     * This method is used to commit port group on the given device
     *
     * @param portGroup
     * @return Long This returns jobId
     */
    @Override
    public Long commitPortGroup(SdPortGroup portGroup) {
        boolean isNew = false;
        long portGroupId;
        // check if port group exists
        if (portGroup.getId() == null) {
            isNew = true;
            isValidPortGroupToSave(portGroup, portGroup.getDevice());
            portGroupId = savePortGroup(portGroup);
        } else {
            portGroupId = portGroup.getId();
        }
        SdPortGroup portGroupInDb = egressPortGroupRepository.findOne(portGroupId);
        if (portGroupInDb != null) {
            Job.Type type = Job.Type.SD_PORT_GROUP_CREATE;
            if (!isNew) {
                isValidPortGroupToEdit(portGroup, portGroup.getDevice());
                SdPortGroup portGroupFromHistory = getPortGroupFromHistory(portGroupInDb, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.DRAFT));
                if (!portGroup.getName().equals(portGroupFromHistory.getName())) {
                    throw new ValidationException("name.change.not.allowed");
                }
                savePortGroup(portGroup);
                if (portGroup.isDefault() || (portGroupFromHistory != null && portGroupFromHistory.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE)) {
                    type = Job.Type.SD_PORT_GROUP_UPDATE;
                }
            }
            portGroup = egressPortGroupRepository.findOne(portGroupId);
            List<Long> impactedObjectIds = new ArrayList<>();
            impactedObjectIds.add(portGroupId);

            long jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(portGroup.getDevice().getId())
                    .parentObjectId(portGroupId).impactedObjectIds(impactedObjectIds).build());

            Job job = getJobStatus(jobId);
            if (job.getStatus() == Job.Status.FAILED) {
                throw new ServerException(job.getJobResult());
            }
            return jobId;
        }
        throw new ValidationException("portGroup.id.invalid");
    }

    /**
     * This method is used to delete/recover port group on the given device
     *
     * @param portGroupId
     * @return Long This returns jobId
     */
    @Override
    public Long deletePortGroup(Long portGroupId) {
        SdPortGroup portGroup = egressPortGroupRepository.findOne(portGroupId);
        if (portGroup != null) {
            if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                SdPortGroup portGroupFromHistory = getPortGroupFromHistory(portGroup, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                if (portGroupFromHistory != null && portGroupFromHistory.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                    //restore the committed port copy from history and set status to active
                    //ensure that the port from history has the same id.
                    portGroup.setDevice(portGroupFromHistory.getDevice());
                    portGroup.setName(portGroupFromHistory.getName());
                    portGroup.setWorkflowStatus(portGroupFromHistory.getWorkflowStatus());
                    egressPortGroupRepository.save(portGroup);
                    log.info("Port group moved to committed state", portGroup.getId());
                    return -1l;
                } else {
                    egressPortGroupRepository.delete(portGroup);
                    log.info("Port group id{} is in Draft state, so nothing to do on device", portGroup.getId());
                    return -1l;
                }
            } else if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                // should not delete a port if in Submitted state
                log.error("Cannot delete a port group id {} which is in progress.", portGroup.getId());
                throw new ValidationException("portGroup.delete.inProgress");
            } else if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                List<SdPortGroup> egressPortGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(portGroup.getDevice().getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
                if (!egressPortGroups.isEmpty()) {
                    log.error("Cannot delete Port Group as another Port Group operation is in progress, id {}", portGroup.getId());
                    throw new ValidationException("port.group.delete.in.progress");
                }
                List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findActiveInterfacesByPortGroupId(portGroup.getId());
                if (!activeInterfaces.isEmpty()) {
                    log.error("Port group is part of an interface. Aborting!");
                    throw new ValidationException("portGroup.exists.interface.no.delete");
                }
                List<Long> portGroupIds = Lists.newArrayList(portGroup.getId());
                if (!portGroupIds.isEmpty() && !egressPortGroupRepository.findPortGroupUsedInFilter(portGroupIds).isEmpty()) {
                    log.error("Participating port group is being used in a policy. Aborting!");
                    throw new ValidationException("portGroup.exists.policy");
                }
                if (portGroup.isDefault() && portGroup.getEgressPorts().size() == 1) {
                    log.error("Cannot delete Port Group as the default-port-group is in active state");
                    throw new ValidationException("default.portGroup.delete.in.active.state");
                }
                //new request , so setting it to DRAFT
                portGroup.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                egressPortGroupRepository.save(portGroup);
                Job.Type jobType = Job.Type.SD_PORT_GROUP_DELETE;
                if (portGroup.isDefault()) {
                    jobType = Job.Type.SD_DEFAULT_PORT_GROUP_DELETE;
                }
                long jobId = jobQueue.submit(JobTemplate
                        .builder()
                        .type(jobType)
                        .deviceId(portGroup.getDevice().getId())
                        .impactedObjectIds(Collections.emptyList())
                        .parentObjectId(portGroup.getId()).build());

                Job job = getJobStatus(jobId);
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(job.getJobResult());
                }
                return jobId;
            } else if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                //do recovery
                //new request , so setting it to DRAFT
                List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findActiveInterfacesByPortGroupId(portGroup.getId());
                if (!activeInterfaces.isEmpty()) {
                    log.error("Port group is part of an interface. Aborting!");
                    throw new ValidationException("portGroup.exists.interface.no.recovery");
                }
                portGroup.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                egressPortGroupRepository.save(portGroup);
                Job.Type jobType = Job.Type.SD_PORT_GROUP_ROLLBACK;
                long jobId = jobQueue.submit(JobTemplate
                        .builder()
                        .type(jobType)
                        .deviceId(portGroup.getDevice().getId())
                        .impactedObjectIds(Collections.emptyList())
                        .parentObjectId(portGroup.getId()).build());

                Job job = getJobStatus(jobId);
                if (job.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(job.getJobResult());
                }
                return jobId;
            } else if (portGroup.getWorkflowStatus() == null && portGroup.isDefault()) {
                log.error("Cannot delete a default port group, id {}.", portGroup.getId());
                throw new ValidationException("default.portGroup.delete.invalid");
            }
        }
        throw new ValidationException("portGroup.id.invalid");
    }

    /**
     * This method is used to recover port group which is in ERROR state
     *
     * @param portGroupId
     * @return
     * @throws ValidationException
     */
    @Override
    public Long rollbackPortGroup(Long portGroupId) {
        SdPortGroup portGroup = egressPortGroupRepository.findOne(portGroupId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        if (portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
            List<SdPortGroup> egressPortGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(portGroup.getDevice().getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
            if (!egressPortGroups.isEmpty()) {
                log.error("Cannot recover Port Group as another Port Group operation is in progress, id {}", portGroup.getId());
                throw new ValidationException("port.group.recover.in.progress");
            }
            List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findActiveInterfacesByPortGroupId(portGroup.getId());
            if (!activeInterfaces.isEmpty()) {
                log.error("Port group is part of interface. Aborting!");
                throw new ValidationException("portGroup.exists.interface.no.recovery");
            }
            portGroup.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            egressPortGroupRepository.save(portGroup);

            List<Long> impactedObjectIds = new ArrayList<>();
            impactedObjectIds.add(portGroup.getId());
            Job.Type jobType = Job.Type.SD_PORT_GROUP_ROLLBACK;
            long jobId = jobQueue.submit(JobTemplate
                    .builder()
                    .type(jobType)
                    .deviceId(portGroup.getDevice().getId())
                    .impactedObjectIds(impactedObjectIds)
                    .parentObjectId(portGroupId).build());

            Job job = getJobStatus(jobId);
            if (job.getStatus() == Job.Status.FAILED) {
                throw new ServerException(job.getJobResult());
            }
            return jobId;
        }
        throw new ValidationException("portGroup.recovery.notallowed");
    }

    /**
     * This method fetches the latest ACTIVE port group history for the current port
     *
     * @param portGroup
     * @param workflowStatus
     * @return
     */
    protected SdPortGroup getPortGroupFromHistory(SdPortGroup portGroup, List<WorkflowParticipant.WorkflowStatus> workflowStatus) {
        SdPortGroup portGroupFromHistory = null;
        // get the previous Port group name from the history.
        List<EgressPortGroupHistory> portGroupHistoryList = egressPortGroupHistoryRepository.findByIdAndWorkflowStatus(portGroup.getId(),
                workflowStatus);
        if (!portGroupHistoryList.isEmpty()) {
            EgressPortGroupHistory oldPortGroupHistory = portGroupHistoryList.get(0);
            log.debug("Found a PortGroupFromHistory entity with oldName {} and lasted PortGroupName {}", oldPortGroupHistory.getName(), portGroup.getName());
            portGroupFromHistory = oldPortGroupHistory.buildParent();
        }
        return portGroupFromHistory;
    }

    /**
     * This method is return the job status
     *
     * @param jobId
     * @return
     */
    private Job getJobStatus(Long jobId) {
        log.debug("********** Job Status polling **********");
        long startTime = System.currentTimeMillis();
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }

            try {
                TimeUnit.SECONDS.sleep(jobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((stablenetTimeoutMinutes + 1) * 60 * 1000)) {
                log.warn("Job status polling timeout!");
                break;
            }
        }
        return null;
    }
}
