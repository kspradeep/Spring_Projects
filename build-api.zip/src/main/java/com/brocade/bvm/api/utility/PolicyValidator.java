package com.brocade.bvm.api.utility;

import com.brocade.bvm.model.db.*;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The PolicyValidator class implements methods to validate if policy object contains valid data to SAVE/COMMIT
 */
public class PolicyValidator {

    public static final String WARNING_KEY = "WARNING";
    public static final String ERROR_KEY = "ERROR";

    /**
     * This method checks if the policy data is valid
     *
     * @param policy
     * @param mode
     * @param type
     * @return
     */
    public static Map<String, StringBuilder> isValidPolicy(Policy policy, Device.Mode mode, Device.Type type) {
        StringBuilder validationErrors = new StringBuilder();
        StringBuilder validationWarnings = new StringBuilder();

        if (Strings.isNullOrEmpty(policy.getName())) {
            validationErrors.append("<br>- Policy name not defined.");
        }
        if (policy.getFlows() == null || policy.getFlows().isEmpty()) {
            validationErrors.append("<br>- Policy has no route-map instance defined.");
        } else {
            Flow flowFirst = policy.getFlows().stream().findFirst().get();
            if (flowFirst != null) {
                if (mode == Device.Mode.PLAIN) {
                    if (type == Device.Type.MLXE) {
                        if ((flowFirst.getIngressPorts() == null || flowFirst.getIngressPorts().isEmpty()) && (flowFirst.getIngressPortGroups() == null || flowFirst.getIngressPortGroups().isEmpty())) {
                            validationWarnings.append("<br>- Missing ingress port/port-group.");
                        }
                        if (flowFirst.getIngressPorts() != null && !flowFirst.getIngressPorts().isEmpty()) {
                            List<Port> portsWithLoopbackEnabledOtherThanTypeService = flowFirst.getIngressPorts().stream().filter(port -> !Port.Type.SERVICE_PORT.equals(port.getType()) && port.isLoopbackEnabled()).collect(Collectors.toList());
                            if (portsWithLoopbackEnabledOtherThanTypeService != null && !portsWithLoopbackEnabledOtherThanTypeService.isEmpty()) {
                                validationWarnings.append("<br>- Loopback enabled on port ").append(portsWithLoopbackEnabledOtherThanTypeService.stream().map(Port::getPortNumber).collect(Collectors.joining(","))).append(" with type other than service type.");
                            }
                        }
                    } else if (type == Device.Type.SLX) {
                        if ((flowFirst.getIngressPorts() == null || flowFirst.getIngressPorts().isEmpty()) && (flowFirst.getIngressPortGroups() == null || flowFirst.getIngressPortGroups().isEmpty())) {
                            validationWarnings.append("<br>- Missing ingress port/port-group.");
                        }
                    }
                } else {
                    if ((flowFirst.getIngressPorts() == null || flowFirst.getIngressPorts().isEmpty()) && (flowFirst.getIngressPortGroups() == null || flowFirst.getIngressPortGroups().isEmpty())) {
                        validationErrors.append("<br>- Missing ingress port/port-group.");
                    }
                }
            }
            policy.getFlows().forEach(flow -> {
                isValidFlow(flow, mode, type, validationErrors, validationWarnings);
            });
        }
        Map<String, StringBuilder> validationMap = Maps.newHashMap();
        if (validationErrors != null && validationErrors.length() != 0) {
            validationMap.put(ERROR_KEY, validationErrors);
        }
        if (validationWarnings != null && validationWarnings.length() != 0) {
            validationMap.put(WARNING_KEY, validationWarnings);
        }
        return validationMap;
    }

    /**
     * This method checks if the flow data is valid
     *
     * @param flow
     * @param mode
     * @param type
     * @param validationErrors
     * @param validationWarnings
     */
    public static void isValidFlow(Flow flow, Device.Mode mode, Device.Type type, StringBuilder validationErrors, StringBuilder validationWarnings) {
        if (flow == null) {
            validationErrors.append("<br>- Policy has invalid route-map instance defined.");
        } else {
            String flowNameOrSequenceNo = (flow != null && flow.getFlowName() != null) ? flow.getFlowName() + " flow-name." : " sequence number " + flow.getSequence() + ".";
            if (mode == Device.Mode.PLAIN) {
                if (type == Device.Type.MLXE) {
                    if ((flow.getVlans() != null && !flow.getVlans().isEmpty()) && ((flow.getEgressPorts() == null || flow.getEgressPorts().isEmpty()) && (flow.getEgressPortGroups() == null || flow.getEgressPortGroups().isEmpty()))) {
                        validationWarnings.append("<br>- Missing egress port/port-group tagging to the VLAN for policy with ").append(flowNameOrSequenceNo);
                    }
                    if (flow.getVlans() == null || flow.getVlans().isEmpty()) {
                        validationWarnings.append("<br>- Missing \"set next-hop-flood-vlan\" or \"set next-hop-tvf-domain\" statement for policy with ").append(flowNameOrSequenceNo);
                    }
                    if (Strings.isNullOrEmpty(flow.getFlowName())) {
                        validationWarnings.append("<br>- Missing \"flow-name\" for policy with ").append(flowNameOrSequenceNo);
                    }
                } else {
                    if ((flow.getEgressPorts() == null || flow.getEgressPorts().isEmpty()) && (flow.getEgressPortGroups() == null || flow.getEgressPortGroups().isEmpty())) {
                        validationWarnings.append("\n- Missing egress port/port-channel for policy with ").append(flowNameOrSequenceNo);
                    }
                }
            } else {
                if ((flow.getEgressPorts() == null || flow.getEgressPorts().size() == 0) && (flow.getEgressPortGroups() == null || flow.getEgressPortGroups().size() == 0)) {
                    validationErrors.append("<br>- Missing egress port/port-group for policy with ").append(flowNameOrSequenceNo);
                }
            }
            if (!(flow.getRuleSets() == null || flow.getRuleSets().isEmpty())) {
                flow.getRuleSets().forEach(ruleSet -> {
                    isValidRuleSet(ruleSet, validationErrors, flowNameOrSequenceNo, type);
                });
            }
        }
    }

    /**
     * This method checks if the ruleSet data is valid
     *
     * @param ruleSet
     * @param validationErrors
     * @param flowNameOrSequenceNo
     */
    public static void isValidRuleSet(RuleSet ruleSet, StringBuilder validationErrors, String flowNameOrSequenceNo, Device.Type type) {
        if (ruleSet == null) {
            if(Device.Type.SLX == type){
                validationErrors.append("<br>- Missing RuleSet for policy with ").append(flowNameOrSequenceNo);
            } else {
                validationErrors.append("<br>- Missing RuleSet for policy with ").append(flowNameOrSequenceNo);
            }
        } else {
            if (ruleSet.getType() == null) {
                validationErrors.append("<br>- Missing RuleSet type for policy with ").append(flowNameOrSequenceNo);
            } else if (ruleSet.getType() == RuleSet.Type.L3 && ruleSet.getIpVersion() == null) {
                validationErrors.append("<br>- Missing IP version for the RuleSet type L3 for policy with ").append(flowNameOrSequenceNo);
            }

            if (ruleSet.getRules() == null || ruleSet.getRules().isEmpty()) {
                validationErrors.append("<br>- Missing rules in ").append(flowNameOrSequenceNo);
            } else {
                ruleSet.getRules().forEach(rule -> {
                    isValidRule(rule, validationErrors, flowNameOrSequenceNo);
                });
            }
        }
    }

    /**
     * This method checks if the rule data is valid
     *
     * @param rule
     * @param validationErrors
     * @param flowNameOrSequenceNo
     */
    public static void isValidRule(Rule rule, StringBuilder validationErrors, String flowNameOrSequenceNo) {
        if (rule == null) {
            validationErrors.append("<br>- Invalid rule in ").append(flowNameOrSequenceNo);
        }
    }
}
