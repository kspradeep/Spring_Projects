package com.brocade.bvm.api.manager;

import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.model.db.ModulePolicy;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ModulePolicyManager {
	Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy);
	Long deleteModulePolicy(Long deviceId, Long modulePolicyId);
	Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicy);
	Map<String, Set<? extends ModulePolicy>> getModulePolicies(List<? extends ModulePolicy> modulePolicies);
	Long recoverModulePolicy(Long deviceId, Long modulePolicyId);

}
