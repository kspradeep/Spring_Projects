package com.brocade.bvm.api.manager.packetcapture;

import com.brocade.bvm.model.db.PacketCapture;
import com.brocade.bvm.outbound.exception.CliConnectorException;

import java.util.Map;

public interface PacketCaptureManager {

    Long createPacketCapture(PacketCapture packetCapture);

    String getPacketCapture(Long deviceId);

    void copyPcapFile(Map<String, String> copyPcapFileReq) throws CliConnectorException;
}
