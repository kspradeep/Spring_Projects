package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.statistics.Dashboard;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

@RestController
@RequestMapping(value = "/statistics/dashboard")
@Slf4j
public class DashboardController {

  @Inject private JdbcTemplate jdbcTemplate;

  @RequestMapping(method = RequestMethod.POST)
  public void save(@RequestBody Dashboard dashboard) {
    Object[] params =
        new Object[] {dashboard.getUserName(), dashboard.getDashboard(), dashboard.getDashboard()};
    jdbcTemplate.update(
        "INSERT INTO bvm.stats_dashboard (user_name, dashboard) VALUES(?, ?) ON DUPLICATE KEY UPDATE dashboard=?",
        params);
  }

  @RequestMapping(value = "{user}")
  public String get(@PathVariable("user") String user) {
    String dashboard = "[]";
    try {
      dashboard =
          jdbcTemplate.queryForObject(
              "select d.dashboard from bvm.stats_dashboard d where d.user_name=?",
              new Object[] {user},
              String.class);
    } catch (EmptyResultDataAccessException e) {
      log.warn(
          "No dashboard available for user {}",
          SecurityContextHolder.getContext().getAuthentication().getName());
    }
    return dashboard;
  }
}
