package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.PortParameters;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridClusterRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.dao.sessiondirector.PhysicalInterfaceRepository;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.sessiondirector.PhysicalInterface;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The DeviceController class implements methods to perform operations related to port and port group
 */
@Slf4j
@RequestMapping(produces = "application/json", value = "/device")
@RestController
public class DeviceController {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    @Value("${slx.internal.loopback.supported.os.version:18.1.01}")
    private String slxLoopBackSupportedVersion;
    @Inject
    private GenericHelper genericHelper;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private PhysicalInterfaceRepository physicalInterfaceRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    protected PortRepository portRepository;

    public static final String ROLLBACK = "rollback";
    public static final String BREAKOUT_ENABLE = "breakoutenable";
    public static final String BREAKOUT_DISABLE = "breakoutdisable";
    public static final String LOOPBACK = "loopback";


    /**
     * This method is used to fetch all devices, which are added to BVM
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping
    public ResponseEntity<Object> getAllDevices() {
        //TODO filter isActive everywhere
        List<Device> devices = Lists.newArrayList();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            devices = deviceRepository.findAllByIdsAndIsReconciled(stablenetDeviceIds);
            Iterator<Device> deviceIterator = devices.iterator();
            while (deviceIterator.hasNext()) {
                Device device = deviceIterator.next();
                if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
                    if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                        deviceIterator.remove();
                    }
                }
                authorityProvider.applyRBACOnDevice(device);
                device.getPortGroups().forEach(portGroup -> {
                    // Setting the GTP Profile id explicitly, as the portGroup.getGtpProfile() method is annotated with @JsonIgnore
                    portGroup.setGtpProfileId(portGroup.getGtpProfile() != null ? portGroup.getGtpProfile().getId() : null);
                });
                if (Device.Type.SD.equals(device.getType())) {
                    List<PhysicalInterface> physicalInterfaces = physicalInterfaceRepository.findByDeviceId(device.getId());
                    device.setNumberOfPorts(physicalInterfaces != null ? physicalInterfaces.size() : 0);
                }
            }
        }
        return new ResponseEntity<>(devices, HttpStatus.OK);
    }

    /**
     * This method is used to fetch device, based on the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object> This returns device
     */
    @RequestMapping(value = "/{deviceId}")
    public ResponseEntity<Object> getDevice(@PathVariable("deviceId") Long deviceId) {
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (device != null) {
            return new ResponseEntity<>(authorityProvider.applyRBACOnDevice(device), HttpStatus.OK);
        }
        throw new ValidationException("device.not.authorized");
    }


    /**
     * This method is used to perform port operations like marking port as none/ingress/egress/service port and enable/disable/cleanup
     *
     * @param action
     * @param deviceId
     * @param portParameters
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{deviceId}/port")
    public ResponseEntity<Object> updatePorts(@RequestParam(value = "action", required = false) String action,
                                              @PathVariable("deviceId") Long deviceId, @RequestBody PortParameters portParameters) {
        log.info("Start: update ports");
        Device device = validateAndReturnDevice(deviceId);
        if (portParameters == null || portParameters.getPortIds() == null || portParameters.getPortIds().isEmpty()) {
            throw new ValidationException("port.ids.invalid");
        }
        //RBAC
        if (!authorityProvider.hasAuthorityOnPorts(deviceId, portParameters.getPortIds())) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }
        log.info("Action set to " + action);

        Long jobId = null;
        if (action != null && action.equalsIgnoreCase("cleanup")) {
            jobId = managerBuilder.getOperationsFactory(deviceRepository.findOne(deviceId))
                    .getPortManager()
                    .recoverPort(deviceId, portParameters.getPortIds());
        } else if (BREAKOUT_ENABLE.equals(action) || BREAKOUT_DISABLE.equals(action)) {
            if (device.getModel() != null && device.getModel().contains(FlexMatchProfile.SLX_9850)) {
                throw new ValidationException("Breakout options are not supported on SLX9850 device.");
            }
            validateInterfacesWithGrid(portParameters.getPortIds());
            validateInterfacesWithGridPolicySet(portParameters.getPortIds());
            jobId = managerBuilder.getOperationsFactory(deviceRepository.findOne(deviceId))
                    .getPortManager()
                    .applyOrRemoveBreakout(deviceId, portParameters.getPortIds(), BREAKOUT_ENABLE.equals(action), portParameters.getLineSpeed());
        } else {
            if (portParameters.getType() != null) {
                validateInterfacesWithGrid(portParameters.getPortIds());
                validateInterfacesWithGridPolicySet(portParameters.getPortIds());
                validateServiceTypeChange(portParameters, device, action);
                jobId = managerBuilder.getOperationsFactory(deviceRepository.findOne(deviceId))
                        .getPortManager()
                        .changeType(deviceId, portParameters.getPortIds(), portParameters.getType(), portParameters.isLoopbackEnabled()
                        );
            } else if (portParameters.getStatus() != null) {
                jobId = managerBuilder.getOperationsFactory(deviceRepository.findOne(deviceId))
                        .getPortManager()
                        .changeAdminStatus(deviceId, portParameters.getPortIds(), portParameters.getStatus(), portParameters.getMode());
            } else if (portParameters.getLineSpeed() != null) {
                if (device.getModel().contains(FlexMatchProfile.SLX_9850)) {
                    throw new ValidationException("Set Line Speed option is not supported on SLX9850 device.");
                }
                validateInterfacesWithGrid(portParameters.getPortIds());
                validateInterfacesWithGridPolicySet(portParameters.getPortIds());
                jobId = managerBuilder.getOperationsFactory(device)
                        .getPortManager()
                        .updatePortSpeed(deviceId, portParameters.getPortIds(), portParameters.getLineSpeed());
            } else {
                throw new ValidationException("policy.action.invalid");
            }
        }
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to validate if service port (loopback) operation is valid
     *
     * @param portParameters
     * @param device
     * @param action
     */
    private void validateServiceTypeChange(PortParameters portParameters, Device device, String action) {
        boolean isSlxLoopbackSupported = genericHelper.isSLXVersionValid(device.getOs(), slxLoopBackSupportedVersion) >= 0;
        if (!isSlxLoopbackSupported && portParameters.isLoopbackEnabled()) {
            throw new ValidationException("Loopback is supported only for SLX version 18.1.01 and above");
        }
        if (isSlxLoopbackSupported && portParameters.getPortIds() != null && !portParameters.getPortIds().isEmpty()) {
            List<Port> portList = StreamSupport.stream(portRepository.findAll(portParameters.getPortIds()).spliterator(), false).collect(Collectors.toList());
            //This check is for SLX Service + Loopback operation
            if (portParameters.getType() != null && Port.Type.SERVICE_PORT == portParameters.getType()) {
                if (!Strings.isNullOrEmpty(action) && LOOPBACK.equals(action) && portParameters.isLoopbackEnabled()) {
                    List<Port> portsTypeService = portList.stream().filter(port -> {
                        return Port.Type.SERVICE_PORT != port.getType();
                    }).collect(Collectors.toList());
                    if (portsTypeService != null && !portsTypeService.isEmpty()) {
                        log.error("Select only Service Port(s).");
                        throw new ValidationException("Select only Service Port(s).");
                    }
                } else {
                    if (portList != null && !portList.isEmpty()) {
                        if (portParameters.isLoopbackEnabled()) {
                            List<Port> portsLoopBackEnabled = portList.stream().filter(port -> {
                                return port.isLoopbackEnabled();
                            }).collect(Collectors.toList());

                            if (portsLoopBackEnabled != null && !portsLoopBackEnabled.isEmpty()) {
                                log.error("Loopback is already enabled on the selected port(s).");
                                throw new ValidationException("Loopback is already enabled on the selected port(s).");
                            }
                        }
                    }
                }

            }
        }
    }


    /**
     * This method fetches the admin status of the given ports
     *
     * @param deviceId
     * @return
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{deviceId}/port/status")
    public ResponseEntity<Object> getPortsAndPortGroupsOfDeviceStatus(@PathVariable("deviceId") Long deviceId, @RequestBody PortParameters portParameters) {
        Device device = deviceRepository.findOne(deviceId);
        if (device != null && (device.getType() == Device.Type.SLX || device.getType() == Device.Type.MLXE) && !portParameters.getPortIds().isEmpty()) {
            long jobId = managerBuilder.getOperationsFactory(deviceRepository.findOne(deviceId))
                    .getPortManager()
                    .getAdminStatus(deviceId, portParameters.getPortIds());
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        }
        throw new ValidationException("device.id.invalid");
    }

    /**
     * This method is used to add/edit/delete port description
     *
     * @param deviceId
     * @param portParameters
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{deviceId}/port/description")
    public ResponseEntity<Object> updatePortDescription(@PathVariable("deviceId") Long deviceId, @RequestBody PortParameters portParameters) {
        log.info("Start: update port description");
        Device device = validateAndReturnDevice(deviceId);
        if (portParameters == null || portParameters.getPortIds() == null || portParameters.getPortIds().isEmpty()) {
            throw new ValidationException("port.ids.invalid");
        }
        //RBAC
        if (!authorityProvider.hasAuthorityOnPorts(deviceId, portParameters.getPortIds())) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }

        if (portParameters.getDescription() != null && portParameters.getDescription().length() > 255) {
            throw new ValidationException("port.description.invalid");
        }

        Long jobId = managerBuilder.getOperationsFactory(device).getPortManager()
                .updateDescription(deviceId, portParameters.getPortIds(), portParameters.getDescription());
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to fetch port group, based on the given portGroupId
     *
     * @param portGroupId
     * @return ResponseEntity<Object> This returns portGroup
     */
    @RequestMapping(method = RequestMethod.GET, value = "/portgroup/{portgroupid}")
    public ResponseEntity<Object> getPortGroup(@PathVariable(value = "portgroupid") Long portGroupId) {
        log.debug("Start: get Port Group");
        if (portGroupId == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        PortGroup portGroup = portGroupRepository.findById(portGroupId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        if (portGroup.getDevice() != null) {
            validateAndReturnDevice(portGroup.getDevice().getId());
        }
        if (!authorityProvider.hasAuthorityOnPorts(portGroup.getDevice().getId(), portGroup.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toList()))) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }
        return new ResponseEntity<>(portGroup, HttpStatus.OK);
    }

    /**
     * This method is used to create port group, on the given device
     *
     * @param deviceId
     * @param portGroup
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.POST, value = "/{deviceid}/portgroup", consumes = "application/json")
    public ResponseEntity<Object> createPortGroup(@PathVariable("deviceid") Long deviceId, @RequestBody PortGroup portGroup) {
        log.debug("Start: create Port Group");
        Device device = validateAndReturnDevice(deviceId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.data.invalid");
        }
        if (portGroup.getPorts() == null || portGroup.getPorts().isEmpty()) {
            throw new ValidationException("port.ids.invalid");
        }
        List<Long> portIds = portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        // RBAC
        if (!authorityProvider.hasAuthorityOnPorts(deviceId, portIds)) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }
        updateDefaultValuesForNull(portGroup);
        validateInterfacesWithGrid(portIds);
        validateInterfacesWithGridPolicySet(portIds);
        Long jobId = managerBuilder.getOperationsFactory(device).getPortGroupManager().commitPortGroup(portGroup, device);
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to update port group, on the given device for the given portgroupid
     *
     * @param deviceId
     * @param portGroupId
     * @param portGroup
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{deviceid}/portgroup/{portgroupid}")
    public ResponseEntity<Object> editPortGroup(
            @PathVariable(value = "deviceid") Long deviceId,
            @PathVariable(value = "portgroupid") Long portGroupId,
            @RequestBody PortGroup portGroup) {
        log.info("*Start: edit port group");
        Device device = validateAndReturnDevice(deviceId);
        if (portGroupId == null || portGroupId < 1) {
            throw new ValidationException("portGroup.id.invalid");
        }
        if (portGroup == null) {
            throw new ValidationException("portGroup.data.invalid");
        }
        if (portGroup.getPorts() == null || portGroup.getPorts().isEmpty()) {
            throw new ValidationException("port.ids.invalid");
        }
        List<Long> portIds = portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        // RBAC
        if (!authorityProvider.hasAuthorityOnPorts(deviceId, portIds)) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }
        List<Long> managedObjectIds = Lists.newArrayList();
        managedObjectIds.addAll(portIds);
        managedObjectIds.add(portGroupId);
        updateDefaultValuesForNull(portGroup);
        validateInterfacesWithGrid(managedObjectIds);
        validateInterfacesWithGridPolicySet(managedObjectIds);
        Long jobId = managerBuilder.getOperationsFactory(device).getPortGroupManager().editPortGroup(portGroup, device, portGroupId);
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * Update default value for field values which is null
     *
     * @param portGroup
     */
    private void updateDefaultValuesForNull(PortGroup portGroup) {
        if (portGroup.getLoopbackEnabled() == null) {
            portGroup.setLoopbackEnabled(false);
        }
        if (portGroup.getMinimumLinkEnabled() == null) {
            portGroup.setMinimumLinkEnabled(false);
        }
    }

    /**
     * This method is used to delete port group, on the given device for the given portgroupid
     *
     * @param portGroupId
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/portgroup/{portgroupid}")
    public ResponseEntity<Object> deletePortGroup(@RequestParam(value = "action", required = false) String action, @PathVariable(value = "portgroupid") Long portGroupId) {
        log.info("Start: delete Port Group");
        if (portGroupId == null || portGroupId < 1) {
            throw new ValidationException("portGroup.id.invalid");
        }
        PortGroup portGroup = portGroupRepository.findById(portGroupId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        Device device;
        if (portGroup.getDevice() != null) {
            device = validateAndReturnDevice(portGroup.getDevice().getId());
        } else {
            throw new ValidationException("device.id.invalid");
        }
        List<Long> portIds = portGroup.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toList());
        // RBAC
        if (!authorityProvider.hasAuthorityOnPorts(portGroup.getDevice().getId(), portIds)) {
            throw new ForbiddenException("rbac.port.notAuthorized");
        }
        PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findByPortGroupIdAndDeviceId(portGroupId, device.getId());
        if (packetTruncationMapping != null) {
            throw new ValidationException(String.format("Cannot delete the Port Channel as it is being used in a Packet Truncation profile: %s", packetTruncationMapping.getName()));
        }
        List<Long> portGroupIds = new ArrayList<>();
        portGroupIds.add(portGroup.getId());
        boolean isRollback = ROLLBACK.equalsIgnoreCase(action) && device.getMode() == Device.Mode.OPENFLOW;
        Long jobId = null;
        // Checking if the portGroup to be deleted is used as Ingress or Egress in any policy
        if (!isRollback && (!policyRepository.findFlowIdsByIngressPortOrPortGroupIds(portGroupIds).isEmpty() || !policyRepository.findFlowIdsByEgressPortOrPortGroupIds(portGroupIds).isEmpty())) {
            if (!ROLLBACK.equalsIgnoreCase(action)) {
                boolean isClassicSLX = (portGroup.getDevice().getType() == Device.Type.SLX) && (portGroup.getDevice().getMode() == Device.Mode.PLAIN);
                throw new ValidationException(isClassicSLX ? "portChannel.operation.notallowed" : "portGroup.operation.notallowed");
            }
        }
        if (isRollback) {
            jobId = managerBuilder.getOperationsFactory(portGroup.getDevice()).getPortGroupManager()
                    .rollBackPortGroup(portGroup, portGroupIds);
            return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
        } else {
            List<Long> managedObjectIds = Lists.newArrayList();
            managedObjectIds.addAll(portIds);
            managedObjectIds.add(portGroupId);
            validateInterfacesWithGrid(managedObjectIds);
            validateInterfacesWithGridPolicySet(managedObjectIds);
            jobId = managerBuilder.getOperationsFactory(portGroup.getDevice()).getPortGroupManager()
                    .deletePortGroup(portGroup, portGroupIds);
        }
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }

    /**
     * Validates the interfaces, is it used in grid policy set or not
     *
     * @param managedObjectIds
     */
    private void validateInterfacesWithGridPolicySet(List<Long> managedObjectIds) {
        if (!managedObjectIds.isEmpty() && (!gridTopologyPathRepository.findIntermediateIngressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findIntermediateEgressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findSourceIngressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findDestinationEgressByManagedObjectId(managedObjectIds).isEmpty())) {
            throw new ValidationException("Cannot create/update the port(s)/port group(s) as it is used in a grid policy.");
        }

    }

    /**
     * Validates the interfaces, is it used in device grid or not
     *
     * @param managedObjectIds
     */
    private void validateInterfacesWithGrid(List<Long> managedObjectIds) {
        if (!managedObjectIds.isEmpty() && !gridClusterRepository.findInterfaceByManagedObjectId(managedObjectIds).isEmpty()) {
            throw new ValidationException("Cannot create/update the port(s)/port group(s) as it is used in a grid.");
        }
    }
}
