package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.SettingManager;
import com.brocade.bvm.api.model.DeviceAdditionResponse;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridClusterRepository;
import com.brocade.bvm.dao.grid.GridPolicySetRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.dao.grid.IntermediateNodeRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.admin.StablenetAgentConfig;
import com.brocade.bvm.model.db.admin.StablenetDeviceConfig;
import com.brocade.bvm.model.db.grid.GridCluster;
import com.brocade.bvm.model.db.grid.IntermediateNode;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.agentmodel.AgentListVO;
import com.brocade.bvm.outbound.stablenet.agentmodel.AgentVO;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.*;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.IntervalJobTrigger;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.SingularJobTrigger;
import com.brocade.bvm.outbound.stablenet.jobbasemodel.UserIdList;
import com.brocade.bvm.outbound.stablenet.model.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXB;
import java.io.StringReader;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Slf4j
@Named
public class DeviceSettingManager implements SettingManager {
    @Value("${stablenet.resource-url.device.remove}")
    private String devicesRemoveUrl;

    @Value("${stablenet.resource-url.job.device.add}")
    private String addDeviceXmlDiscoveryUrl;

    @Value("${stablenet.resource-url.agent.get}")
    private String getAgentUrl;

    @Value("${stablenet.resource-url.jobs.jobresultlist}")
    private String jobResultListUrl;

    @Value("${stablenet.resource-url.jobs.jobresultdata}")
    private String jobresultdata;

    @Value("${stablenet.resource-url.users.listgroups}")
    private String userListGroupsUrl;

    @Value("${stablenet.resource-url.jobs.remove}")
    private String deleteJobUrl;

    @Value("${stablenet.resource-url.jobs.modify}")
    private String modifyDeviceXmlDiscoveryUrl;

    @Value("${stablenet.resource-url.jobs.isrunning}")
    private String jobIsRunningStatusUrl;

    @Value("${stablenet.resource-url.jobs.start}")
    private String jobStartUrl;

    @Value("${stablenet.discovery.job.timeout.minutes:40}")
    private int snDiscoveryTimeoutMinutes;

    @Value("${stablenet.job.status.poll.interval.seconds:5}")
    private int delayTocheckJobStatusInSeconds;

    @Value("${tacacs.server.auto.configuration}")
    private boolean tacacsServerAutoConfig = false;

    @Inject
    private StablenetAdminConnection stablenetConnection;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private StablenetDeviceConfigRepository stablenetDeviceConfigRepository;

    @Inject
    private StablenetAgentConfigRepository stablenetAgentConfigRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private IntermediateNodeRepository intermediateNodeRepository;

    @Inject
    private DeviceDiscoveryJobRepository deviceDiscoveryJobRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private TemplatePolicyRepository templatePolicyRepository;

    @Inject
    private FlexMatchProfileRepository flexMatchProfileRepository;

    public static final String NOT_FOUND = "not found";

    public static final String RUNNING = "running";

    public static final String IDLE = "idle";

    private static final String TRUE = "true";

    /**
     * Validate and delete the device(s) from StableNet Measurements and EVM inventory list.
     *
     * @param devices
     * @return
     */
    @Override
    public Set<Long> deleteDevice(List<Device> devices) {
        String stablenetIdsString = devices.stream().map(device -> String.valueOf(device.getStablenetId())).collect(Collectors.joining(","));
        Set<Long> deviceIds = devices.stream().map(TargetHost::getId).collect(Collectors.toSet());
        validateDeviceDelete(deviceIds);
        try {
            List<Long> jobIdsTelemetry = Lists.newArrayList();
            List<Long> jobIdsTacacs = Lists.newArrayList();
            List<Long> jobIdsLldp = Lists.newArrayList();
            devices.stream().filter(device -> Device.Type.SLX == device.getType()).forEach(device -> {
                if (device.isProfileConfigured()) {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.DELETE_TELEMETRY_PROFILE).deviceId(device.getId())
                            .impactedObjectIds(Collections.emptyList()).build());
                    if (jobId != -1) {
                        jobIdsTelemetry.add(jobId);
                    }
                }
                if (tacacsServerAutoConfig && device.isAuthenticationConfigured()) {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.DELETE_TACACS_SERVER).deviceId(device.getId())
                            .impactedObjectIds(Collections.emptyList()).build());
                    if (jobId != -1) {
                        jobIdsTacacs.add(jobId);
                    }
                }
                //get all unused egress port and enable lldp protocol
                List<Long> egressPortIds = Lists.newArrayList();
                device.getModules().forEach(module -> egressPortIds.addAll(module.getPorts().stream().filter(port -> Port.Type.EGRESS == port.getType()).map(Port::getId).collect(Collectors.toList())));
                if (!egressPortIds.isEmpty()) {
                    List<Long> freePortIdsFromPortGroup = Lists.newArrayList();
                    device.getPortGroups().stream().filter(portGroup -> Port.Type.EGRESS == portGroup.getType()).forEach(portGroup -> freePortIdsFromPortGroup.addAll(portGroup.getPorts().stream().filter(port -> Port.Type.EGRESS == port.getType()).map(ManagedObject::getId).collect(Collectors.toList())));
                    if (!freePortIdsFromPortGroup.isEmpty()) {
                        egressPortIds.removeAll(freePortIdsFromPortGroup);
                    }
                    if (!egressPortIds.isEmpty()) {
                        List<Long> freeEgressPortIds = policyRepository.findPortIdsByEgressPortIds(device.getId(), egressPortIds);
                        if (!freeEgressPortIds.isEmpty()) {
                            egressPortIds.removeAll(freeEgressPortIds);
                        }
                    }
                    if (!egressPortIds.isEmpty()) {
                        Set<Port> updatedPorts = Sets.newHashSet();
                        device.getModules().forEach(module -> module.getPorts().forEach(port -> {
                            if (egressPortIds.contains(port.getId())) {
                                port.setType(Port.Type.NONE);
                                port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                                port.setWorkflowType(Job.Type.PORT_MARK_NONE);
                                updatedPorts.add(port);
                            }
                        }));
                        portRepository.save(updatedPorts);
                        Long jobId = jobQueue.submit(JobTemplate.builder()
                                .type(Job.Type.PORT_MARK_NONE)
                                .deviceId(device.getId())
                                .impactedObjectIds(egressPortIds)
                                .build());
                        if (jobId != -1) {
                            jobIdsLldp.add(jobId);
                        }
                    }
                }

                Set<BigInteger> templatePolicyIds = templatePolicyRepository.findIdByDeviceId(device.getId());
                if (!templatePolicyIds.isEmpty()) {
                    templatePolicyIds.forEach(id -> {
                        FlexMatchProfile flexMatchProfile = flexMatchProfileRepository.findOne(id.longValue());
                        if (flexMatchProfile != null) {
                            Set<Long> templateDeviceIds = flexMatchProfile.getDeviceIds();
                            if(templateDeviceIds.contains(device.getId())) {
                                templateDeviceIds.remove(device.getId());
                                flexMatchProfileRepository.save(flexMatchProfile);
                            }
                        }
                    });
                }
            });
            jobIdsTelemetry.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    if (job.getStatus() == Job.Status.SUCCESS) {
                        device = deviceRepository.findById(device.getId());
                        device.setProfileConfigured(false);
                        deviceRepository.save(device);
                    } else if (job.getStatus() == Job.Status.FAILED) {
                        log.error("Failed to delete telemetry configuration on device {} due to {}", device.getId(), job.getJobResult());
                    }
                }
            });
            jobIdsTacacs.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    if (job.getStatus() == Job.Status.SUCCESS) {
                        device = deviceRepository.findById(device.getId());
                        device.setAuthenticationConfigured(false);
                        device.setAuthorizationConfigured(false);
                        deviceRepository.save(device);
                    } else if (job.getStatus() == Job.Status.FAILED) {
                        log.error("Failed to delete tacacs configuration on device {} due to {}", device.getId(), job.getJobResult());
                    }
                }
            });
            jobIdsLldp.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    if (device != null && job.getStatus() == Job.Status.FAILED) {
                        log.error("Failed to reconfigure LLDP on device {} due to {}", device.getId(), job.getJobResult());
                    }
                }
            });
            Response response = stablenetConnection.delete(devicesRemoveUrl, "/" + stablenetIdsString);
            log.debug("Device delete response :: {}", response.toString());
            Set<String> ips = new HashSet<>();
            if (response != null && response.getStatus() == HttpStatus.OK.value()) {
                List<Device> deletedDeviceList = new ArrayList<>();
                devices.forEach(device -> {
                    device = deviceRepository.findById(device.getId());
                    device.setDeleted(true);
                    deletedDeviceList.add(device);
                    ips.add(device.getIpAddress());
                });
                deviceRepository.save(deletedDeviceList);
                log.debug("Deleted device ids : {}", devices.stream().map(device -> String.valueOf(device.getId())).collect(Collectors.joining(",")));
                List<DeviceDiscoveryJob> discoveryJobsToBeDeleted = deviceDiscoveryJobRepository.findByInIpAddress(ips);
                if (discoveryJobsToBeDeleted != null) {
                    deleteDiscoveryJob(discoveryJobsToBeDeleted.stream().map((job -> job.getId())).collect(Collectors.toList()));
                }
            } else {
                log.debug("Device(s) are not deleted due to StableNet response status, " + (response != null ? response.getStatus() : ""));
                throw new ValidationException("Failed to delete device.");
            }
            return deviceIds;
        } catch (Exception e) {
            log.error("Failed to delete device(s) {}, {}", stablenetIdsString, e.getMessage());
            throw new ValidationException("Failed to delete device.");
        }
    }

    /**
     * Validate the devices before deletion
     *
     * @param deviceIds
     */
    private void validateDeviceDelete(Set<Long> deviceIds) {
        StringBuilder deviceGridValidation = new StringBuilder();
        deviceIds.forEach(deviceId -> {
            List<GridCluster> gridClusters = gridClusterRepository.findByDeviceId(deviceId);
            if (!gridClusters.isEmpty()) {
                String deviceName = gridClusters.stream().findAny().get().getDevice().getName();
                Set<String> gridNames = Sets.newHashSet();
                gridNames.addAll(gridClusters.stream().filter(gridCluster -> gridCluster.getDeviceGridSource() != null).map(gridCluster -> gridCluster.getDeviceGridSource().getName()).collect(Collectors.toSet()));
                gridNames.addAll(gridClusters.stream().filter(gridCluster -> gridCluster.getDeviceGridDestination() != null).map(gridCluster -> gridCluster.getDeviceGridDestination().getName()).collect(Collectors.toSet()));
                if (deviceGridValidation.length() > 0) {
                    deviceGridValidation.append("<br>");
                }
                deviceGridValidation.append("Device Name [Grid Name] -> ").append(deviceName).append(" [").append(gridNames.stream().collect(Collectors.joining(","))).append("]");
            }
        });
        if (deviceGridValidation.length() > 0) {
            deviceGridValidation.insert(0, "Cannot delete device as it is used in a grid.<br>");
            throw new ValidationException(deviceGridValidation.toString());
        }

        StringBuilder deviceGridPolicyValidation = new StringBuilder();
        deviceIds.forEach(deviceId -> {
            Set<String> policySets = Sets.newHashSet();
            Set<IntermediateNode> intermediateNodes = intermediateNodeRepository.findByDeviceId(deviceId);
            if (!intermediateNodes.isEmpty()) {
                intermediateNodes.forEach(intermediateNode -> {
                    Set<Long> gridPolicySetIds = gridTopologyPathRepository.findPoicySetIdByIntermediateDeviceId(intermediateNode.getId());
                    if (!gridPolicySetIds.isEmpty()) {
                        gridPolicySetIds.forEach(policySetId -> {
                            String policySetName = gridPolicySetRepository.findNameById(policySetId);
                            policySets.add(policySetName);
                        });
                    }
                });
                String deviceName = deviceRepository.findNameById(deviceId);
                if (!policySets.isEmpty()) {
                    if (deviceGridPolicyValidation.length() > 0) {
                        deviceGridPolicyValidation.append("<br>");
                    }
                    deviceGridPolicyValidation.append("Device Name [Grid Policy Name] -> ").append(deviceName).append(" [").append(policySets.stream().collect(Collectors.joining(","))).append("]");
                }
            }
        });
        if (deviceGridPolicyValidation.length() > 0) {
            deviceGridPolicyValidation.insert(0, "Cannot delete device as it is used in a grid policy.<br>");
            throw new ValidationException(deviceGridPolicyValidation.toString());
        }
    }

    /**
     * This method add/update the discovery job
     */
    @Override
    public List<DeviceAdditionResponse> addDevice(DeviceDiscoveryJob deviceDiscoveryJob) {
        log.debug("deviceDiscoveryJob  2:"+deviceDiscoveryJob.getCliPassword());
        List<XmlDiscoveryBaseJobVO> xmlDiscoveryJobList = constructDeviceListXml(deviceDiscoveryJob);
        List<DeviceAdditionResponse> deviceAdditionResponseList = new ArrayList<>();
        if (xmlDiscoveryJobList != null && !xmlDiscoveryJobList.isEmpty()) {
            int deviceCount = xmlDiscoveryJobList.size();
            ExecutorService executorService = Executors.newFixedThreadPool(deviceCount);
            List<Future> futureList = Lists.newArrayList();
            xmlDiscoveryJobList.forEach(xmlDiscoveryObject -> {
                Future future = executorService.submit(new AddDeviceJobCallable(stablenetConnection, xmlDiscoveryObject, addDeviceXmlDiscoveryUrl, jobResultListUrl, jobresultdata, deleteJobUrl, deviceDiscoveryJobRepository, modifyDeviceXmlDiscoveryUrl, jobIsRunningStatusUrl, jobStartUrl, snDiscoveryTimeoutMinutes, delayTocheckJobStatusInSeconds));
                futureList.add(future);

            });
            futureList.forEach(future -> {
                try {
                    deviceAdditionResponseList.add((DeviceAdditionResponse) future.get());
                } catch (InterruptedException | ExecutionException e) {
                    log.error(e.getMessage());
                }
            });
        }
        return deviceAdditionResponseList;
    }

    /**
     * Constructs discovery job request body
     */
    private List<XmlDiscoveryBaseJobVO> constructDeviceListXml(DeviceDiscoveryJob deviceDiscoveryJob) {
        String agentId = getAgentId();
        ApplicationConfig applicationConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername);
        UserIdList userIdList = getUserGroupIds();
        List<XmlDiscoveryBaseJobVO> xmlDiscoveryJobList = new ArrayList<>();
        deviceDiscoveryJob.getIps().forEach(ip -> {
            XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO = new XmlDiscoveryBaseJobVO();
            xmlDiscoveryBaseJobVO.setType(DeviceDiscoveryJob.Type.XML.getValue());
            xmlDiscoveryBaseJobVO.setAgentid(agentId);
            xmlDiscoveryBaseJobVO.setTemplatename(DeviceDiscoveryJob.TemplateName.SINGLE_DEVICE_XML.getValue());
            xmlDiscoveryBaseJobVO.setName(ip);
            if (deviceDiscoveryJob.getId() != null) {
                DeviceDiscoveryJob deviceDiscoveryJobDb = deviceDiscoveryJobRepository.findOne(deviceDiscoveryJob.getId());
                if (deviceDiscoveryJobDb != null) {
                    xmlDiscoveryBaseJobVO.setObid(deviceDiscoveryJobDb.getObjId());
                }
            }
            if (applicationConfig != null)
                xmlDiscoveryBaseJobVO.setUpdatedfrom(applicationConfig.getValue());
            if ((DeviceDiscoveryJob.TriggerType.INTERVAL).equals(deviceDiscoveryJob.getTriggerType()) && (deviceDiscoveryJob.getIntervalValue() != null)) {
                IntervalJobTrigger intervalJobTrigger = new IntervalJobTrigger();
                intervalJobTrigger.setActive(true);
                //Converting from minutes to milliseconds
                intervalJobTrigger.setInterval(deviceDiscoveryJob.getIntervalValue() * 60 * 1000);
                xmlDiscoveryBaseJobVO.setIntervaltrigger(intervalJobTrigger);
            } else {
                SingularJobTrigger singularJobTrigger = new SingularJobTrigger();
                xmlDiscoveryBaseJobVO.setSingletrigger(singularJobTrigger);
            }
            xmlDiscoveryBaseJobVO.setUsers(userIdList);
            SnPropertyType snPropertyType = new SnPropertyType();

            if (!Strings.isNullOrEmpty(deviceDiscoveryJob.getSnmpCommunity())) {
                SnPropertyEntryType snPropertyEntryType = new SnPropertyEntryType();
                snPropertyEntryType.setKey(DeviceDiscoveryJob.SNMP_COMMUNITY);
                snPropertyEntryType.setValue(deviceDiscoveryJob.getSnmpCommunity());
                snPropertyType.getEntry().add(snPropertyEntryType);
            }

            if (!Strings.isNullOrEmpty(deviceDiscoveryJob.getSnmpWriteCommunity())) {
                SnPropertyEntryType snWriteCommunityEntry = new SnPropertyEntryType();
                snWriteCommunityEntry.setKey(deviceDiscoveryJob.SNMP_WRITE_COMMUNITY);
                snWriteCommunityEntry.setValue(deviceDiscoveryJob.getSnmpWriteCommunity());
                snPropertyType.getEntry().add(snWriteCommunityEntry);
            }

            //default setting to have unique device added if IPV4 and IPv6 address given
            SnPropertyEntryType discoveryIpEntry = new SnPropertyEntryType();
            discoveryIpEntry.setKey(deviceDiscoveryJob.DISCOVERY_AUTO_USE_ALL_IP);
            discoveryIpEntry.setValue(TRUE);
            snPropertyType.getEntry().add(discoveryIpEntry);

            SnPropertyEntryType discoveryInterfaceDescriptionEntry = new SnPropertyEntryType();
            discoveryInterfaceDescriptionEntry.setKey(deviceDiscoveryJob.DISCOVERY_AUTO_USE_INTERFACE_DESCRIPTION);
            discoveryInterfaceDescriptionEntry.setValue(TRUE);
            snPropertyType.getEntry().add(discoveryInterfaceDescriptionEntry);

            xmlDiscoveryBaseJobVO.setProperties(snPropertyType);

            DiscoveryParameters discoveryParameters = new DiscoveryParameters();
            List discoveryParameterEntrySet = discoveryParameters.getEntry();
            DiscoveryParameter discoveryParameter = new DiscoveryParameter();
            discoveryParameter.setKey(deviceDiscoveryJob.CLI_USER);
            discoveryParameter.setValue(deviceDiscoveryJob.getCliUserName());

            discoveryParameterEntrySet.add(discoveryParameter);

            discoveryParameter = new DiscoveryParameter();
            discoveryParameter.setKey(deviceDiscoveryJob.IP);
            discoveryParameter.setValue(ip);
            discoveryParameterEntrySet.add(discoveryParameter);

            discoveryParameter = new DiscoveryParameter();
            discoveryParameter.setKey(deviceDiscoveryJob.CLI_PASSWORD);
            discoveryParameter.setValue(deviceDiscoveryJob.getCliPassword());
            discoveryParameterEntrySet.add(discoveryParameter);

            if (!Strings.isNullOrEmpty(deviceDiscoveryJob.getCliEnablePassword())) {
                discoveryParameter = new DiscoveryParameter();
                discoveryParameter.setKey(deviceDiscoveryJob.CLI_ENABLE_PASSWORD);
                discoveryParameter.setValue(deviceDiscoveryJob.getCliPassword());
                discoveryParameterEntrySet.add(discoveryParameter);
            }
            xmlDiscoveryBaseJobVO.setParameters(discoveryParameters);
            xmlDiscoveryJobList.add(xmlDiscoveryBaseJobVO);
            saveDiscoveryJob(xmlDiscoveryBaseJobVO, deviceDiscoveryJob);
        });
        return xmlDiscoveryJobList;
    }

    /**
     * Gets StableNet User Group ids from EVM
     */
    private UserIdList getUserGroupIds() {
        UserIdList userIdList = new UserIdList();
        List<Integer> userGroupIdList = new ArrayList<>();
        if (stablenetDeviceConfigRepository.findByName(StablenetDeviceConfig.USER_GROUP_ID_LIST) != null) {
            List<String> userGroupIdString = Arrays.asList(stablenetDeviceConfigRepository.findByName(StablenetDeviceConfig.USER_GROUP_ID_LIST).getValue().split(","));
            userGroupIdList = userGroupIdString.stream().map(id -> Integer.parseInt(id)).collect(Collectors.toList());
        } else {
            userGroupIdList = getUserList();
        }
        List<Integer> userIds = userIdList.getUserid();
        userIds.addAll(userGroupIdList);
        return userIdList;
    }

    /**
     * Gets StableNet User Group ids from StableNet
     */
    private List<Integer> getUserList() {
        List<Integer> userGroupIdList = new ArrayList<>();
        try {
            UserGroupListVO userGroups = JAXB.unmarshal(
                    new StringReader(stablenetConnection.get(userListGroupsUrl).readEntity(String.class)),
                    UserGroupListVO.class);
            if (userGroups != null && !userGroups.getUserGroups().isEmpty()) {
                userGroups.getUserGroups().forEach(userGroupVO -> {
                    userGroupIdList.add(Integer.valueOf(userGroupVO.getObid()));
                });
            }
        } catch (Exception e) {
            log.error("Error while fetching the user group list.Please add the StableNet agent and configuration job. :{}", e.getMessage());
            throw new ServerException("Error while fetching the user group list.Please add the StableNet agent and configuration job.");
        }
        if (!userGroupIdList.isEmpty()) {
            StablenetDeviceConfig stablenetDeviceConfig = new StablenetDeviceConfig();
            StringBuilder value = new StringBuilder();
            userGroupIdList.forEach(userGroupId -> {
                value.append(userGroupId != userGroupIdList.get(0) ? "," : "").append(userGroupId);
            });
            stablenetDeviceConfig.setName(StablenetDeviceConfig.USER_GROUP_ID_LIST);
            stablenetDeviceConfig.setValue(value.toString());
            stablenetDeviceConfigRepository.save(stablenetDeviceConfig);
        }
        log.debug("Saved StableNet user-group-ids in EVM.");
        return userGroupIdList;
    }

    /**
     * Gets the Agent from StableNet if id not configured in EVM.
     *
     * @return
     */
    private String getAgentId() {
        String agentId = null;
        StablenetAgentConfig stablenetAgentConfigs = stablenetAgentConfigRepository.findAnyOne(1);
        if (stablenetAgentConfigs != null && !Strings.isNullOrEmpty(stablenetAgentConfigs.getAgentId())) {
            agentId = stablenetAgentConfigs.getAgentId();
        }
        if (agentId == null) {
            try {
                AgentListVO agentVOList = JAXB.unmarshal(new StringReader(stablenetConnection.get(getAgentUrl).readEntity(String.class)), AgentListVO.class);
                if (agentVOList != null && agentVOList.getAgent() != null && !agentVOList.getAgent().isEmpty()) {
                    AgentVO agentVo = agentVOList.getAgent().get(0);
                    StablenetAgentConfig stablenetAgentConfig = new StablenetAgentConfig();
                    agentId = agentVo.getObid();
                    stablenetAgentConfig.setAgentId(agentId);
                    stablenetAgentConfig.setPortNo(agentVo.getPort());
                    stablenetAgentConfig.setIp(agentVo.getIp());
                    stablenetAgentConfigRepository.save(stablenetAgentConfig);
                    log.debug("Agent Id fetched from StableNet and saved in EVM.");
                } else {
                    log.debug("Agent not found in StableNet");
                    throw new ServerException("Agent not configured in StableNet. Please add agent manually and try again.");
                }
            } catch (Exception e) {
                log.error("Error occurred while fetching the Agent {}", e.getMessage());
                throw new ServerException("Agent not configured in StableNet. Please verify the agent manually and try again.");
            }
        }
        return agentId;
    }

    /**
     * Deletes discovery job from StableNet and EVM
     *
     * @param deviceDiscoveryJobIds
     */
    public void deleteDiscoveryJob(List<Long> deviceDiscoveryJobIds) {
        if (deviceDiscoveryJobIds != null && !deviceDiscoveryJobIds.isEmpty()) {
            List<DeviceDiscoveryJob> deviceDiscoveryJobs = deviceDiscoveryJobRepository.findByInIds(deviceDiscoveryJobIds);
            if (deviceDiscoveryJobs != null && !deviceDiscoveryJobs.isEmpty()) {
                deviceDiscoveryJobs.forEach(deviceDiscoveryJob -> {
                    if (deviceDiscoveryJob.getObjId() != null) {
                        try {
                            Response response = stablenetConnection.delete(deleteJobUrl, "/" + deviceDiscoveryJob.getObjId());
                            if (response != null && response.getStatus() == HttpStatus.OK.value()) {
                                log.debug("Removed discovery job with StableNet job id {} from StableNet.", deviceDiscoveryJob.getObjId());
                            }
                            deviceDiscoveryJobRepository.delete(deviceDiscoveryJob.getId());
                            log.debug("Removed discovery job with EVM id {} from StableNet.", deviceDiscoveryJob.getId());
                        } catch (Exception e) {
                            log.error("Error while deleting discovery job in StableNet with EVM id {}.", deviceDiscoveryJob.getId());
                            //Delete the stale entry in EVM if manually deleted from Stablenet
                            if (e.getMessage().contains("Unexpected response status: 404")) {
                                deviceDiscoveryJobRepository.delete(deviceDiscoveryJob.getId());
                                log.debug("Discovery Job not found in StableNet. Removed the discovery job having id {} from EVM.", deviceDiscoveryJob.getId());
                            }
                        }
                    } else {
                        deviceDiscoveryJobRepository.delete(deviceDiscoveryJob.getId());
                        log.debug("Removed discovery job with EVM id {} from EVM.", deviceDiscoveryJob.getId());
                    }
                });
            }
        }
    }

    /**
     * Starts the existing discovery job in StableNet
     *
     * @param deviceDiscoveryJobDb
     */
    @Override
    public void startJob(DeviceDiscoveryJob deviceDiscoveryJobDb) {

        String id = deviceDiscoveryJobDb.getObjId();
        if (!Strings.isNullOrEmpty(id)) {
            deviceDiscoveryJobDb.setRunning(true);
            deviceDiscoveryJobRepository.save(deviceDiscoveryJobDb);
            try {
                ResultVo resultVo = stablenetConnection.get(jobStartUrl, id).readEntity(ResultVo.class);
                if (resultVo.getState().equalsIgnoreCase(RestResultStateEnum.SUCCESS.value())) {
                    checkForRunningStatusAndGetLatestObjId(id, deviceDiscoveryJobDb);
                }
            } catch (Exception e) {
                deviceDiscoveryJobDb.setJob_status(DeviceDiscoveryJob.JOB_STATUS.FAILED);
                deviceDiscoveryJobDb.setResponse(e.getMessage());
                log.error("Error while starting the discovery job with StableNet object Id : {}.", id);
            }
            deviceDiscoveryJobDb.setRunning(false);
            deviceDiscoveryJobRepository.save(deviceDiscoveryJobDb);
        } else {
            log.error("Object Id not found in EVM.");
        }
    }

    /**
     * Gets the running status of discovery job started
     *
     * @param objId
     * @throws Exception
     */
    private void isRunning(String objId) throws Exception {
        boolean isJobRunning = true;
        long startTime = System.currentTimeMillis();
        while (isJobRunning) {
            Result result = JAXB.unmarshal(new StringReader(stablenetConnection.get(jobIsRunningStatusUrl, objId).readEntity(String.class)), Result.class);
            if (result.getInfo() != null && result.getInfo().equals(NOT_FOUND)) {
                log.debug("Discovery Job not found or deleted from StableNet.");
                throw new ServerException("Discovery Job not found or deleted from StableNet.");
            } else if (result.getInfo() != null && result.getInfo().equals(RUNNING)) {
                log.debug("Device discovery job is still running, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                TimeUnit.SECONDS.sleep(delayTocheckJobStatusInSeconds);
            } else if (result.getInfo() != null && result.getInfo().equals(IDLE)) {
                log.debug("Device discovery job is still not started, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                break;
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((snDiscoveryTimeoutMinutes + 1) * 1000 * 60)) {
                log.error(String.format("Stablenet job got timed out after {} minutes. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                throw new ServerException(String.format("Stablenet job got timed out after {} minutes. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
            }
        }

    }

    /**
     * Gets the latest executed discovery job, job analyzer object Id using the discovery obj id
     *
     * @param obid
     * @param deviceDiscoveryJob
     * @throws Exception
     */
    private void checkForRunningStatusAndGetLatestObjId(String obid, DeviceDiscoveryJob deviceDiscoveryJob) throws Exception {
        isRunning(obid);
        List<JobResultVO> jobResultList = stablenetConnection.get(jobResultListUrl, obid).readEntity(new GenericType<List<JobResultVO>>() {
        });
        if (jobResultList == null || jobResultList.isEmpty()) {
            log.debug("Discovery Job object Id not found");
        } else {
            Optional<JobResultVO> jobResultVO = jobResultList.stream().findFirst();
            String resultJobObjId = jobResultVO.get().getObid();
            checkIfJobCompleted(resultJobObjId, deviceDiscoveryJob);
        }
    }

    /**
     * Gets the job analyzer result content to save in EVM
     *
     * @param obid
     * @param deviceDiscoveryJob
     * @throws Exception
     */
    private void checkIfJobCompleted(String obid, DeviceDiscoveryJob deviceDiscoveryJob) throws Exception {
        boolean isJobRunning = true;
        long startTime = System.currentTimeMillis();
        while (isJobRunning) {
            String jobContent = stablenetConnection.getWithoutAcceptType(jobresultdata, obid).readEntity(String.class);
            if (jobContent == null || (jobContent != null && jobContent.equals("Job has not been finished yet!"))) {
                log.debug("Device discovery job is still running, retrying after {} seconds!", delayTocheckJobStatusInSeconds);
                TimeUnit.SECONDS.sleep(delayTocheckJobStatusInSeconds);
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime >= ((snDiscoveryTimeoutMinutes + 1) * 1000 * 60)) {
                    log.error(String.format("StableNet job got timed out after {} seconds. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                    throw new ServerException(String.format("StableNet job got timed out after {} seconds. Please check the StableNet for discovery job status.", snDiscoveryTimeoutMinutes));
                } else {
                    continue;
                }
            } else if (jobContent != null && jobContent.contains("Devices failed SNMP discovery")) {
                log.error("Device discovery failed :\n.{}", jobContent);
                throw new ServerException(jobContent);
            } else if (jobContent != null && jobContent.contains("successfully discovered")) {
                log.debug("Device discovery job added and discovered successfully.");
                break;
            } else {
                log.error("Device discovery failed :\n.{}", jobContent);
                throw new ServerException(jobContent);
            }
        }
    }

    /**
     * This method saves discovery jon in EVM.
     *
     * @param xmlDiscoveryBaseJobVO
     * @param deviceDiscoveryJobReq
     */
    private void saveDiscoveryJob(XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO, DeviceDiscoveryJob deviceDiscoveryJobReq) {
        List<DeviceDiscoveryJob> deviceDiscoveryJobs = deviceDiscoveryJobRepository.findByIpAddress(xmlDiscoveryBaseJobVO.getName());
        if (deviceDiscoveryJobs != null && !deviceDiscoveryJobs.isEmpty()) {
            deleteDiscoveryJob(deviceDiscoveryJobs.stream().map(job -> job.getId()).collect(Collectors.toList()));
        }
        initializeDiscoveryJobObject(deviceDiscoveryJobReq, xmlDiscoveryBaseJobVO);
        deviceDiscoveryJobReq.setRunning(true);
        deviceDiscoveryJobRepository.save(deviceDiscoveryJobReq);
    }

    private void initializeDiscoveryJobObject(DeviceDiscoveryJob deviceDiscoveryJob, XmlDiscoveryBaseJobVO xmlDiscoveryBaseJobVO) {
        if (xmlDiscoveryBaseJobVO.getIntervaltrigger() != null && xmlDiscoveryBaseJobVO.getIntervaltrigger().getInterval() != 0) {
            deviceDiscoveryJob.setTriggerType(DeviceDiscoveryJob.TriggerType.INTERVAL);
            deviceDiscoveryJob.setIntervalValue(xmlDiscoveryBaseJobVO.getIntervaltrigger().getInterval());
            deviceDiscoveryJob.setActive(true);
        } else {
            deviceDiscoveryJob.setTriggerType(DeviceDiscoveryJob.TriggerType.SINGLE);
        }
        xmlDiscoveryBaseJobVO.getParameters().getEntry().stream().forEach(discoveryParameter -> {
            if (discoveryParameter.getKey().equals(DeviceDiscoveryJob.IP)) {
                deviceDiscoveryJob.setIpAddress(discoveryParameter.getValue());
            }
            if (discoveryParameter.getKey().equals(DeviceDiscoveryJob.CLI_USER)) {
                deviceDiscoveryJob.setCliUserName(discoveryParameter.getValue());
            }
        });
        xmlDiscoveryBaseJobVO.getProperties().getEntry().stream().forEach(snPropertyEntryType -> {
            if (snPropertyEntryType.getKey().equals(DeviceDiscoveryJob.SNMP_COMMUNITY)) {
                deviceDiscoveryJob.setSnmpCommunity(snPropertyEntryType.getValue());
            }
            if (snPropertyEntryType.getKey().equals(DeviceDiscoveryJob.SNMP_WRITE_COMMUNITY)) {
                deviceDiscoveryJob.setSnmpWriteCommunity(snPropertyEntryType.getValue());
            }
        });

    }

}
