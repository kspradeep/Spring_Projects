package com.brocade.bvm.api.model;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.GridPolicy;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.grid.GridRuleSet;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@Getter
@Setter
public class GridUIPolicySummary {

    Set<UIGridPolicySet> policySets = new HashSet<>();

    public GridUIPolicySummary(List<GridPolicySet> gridPolicySets) {
        if (gridPolicySets != null && !gridPolicySets.isEmpty()) {
            gridPolicySets.stream().forEach(policySet -> {
                UIGridPolicySet eachSet = new UIGridPolicySet(policySet);
                policySets.add(eachSet);
            });
        }
    }
}

@Getter
@Setter
class UIGridPolicySet {

    WorkflowParticipant.WorkflowStatus workflowStatus;
    Long policyId;
    String policyName;
    ImmutableSet<ClusterNodeInterface> ingressPorts;
    private Long fieldOffset1;
    private Long fieldOffset2;
    private Long fieldOffset3;
    private Long fieldOffset4;
    private boolean isLoopbackEnabled;
    private String sourceMacTag;
    private String destinationMacTag;
    private String gtpProfile;
    private boolean createdFromSd;
    private boolean flexMatchEnabled;
    private boolean isGridPolicy = true;
    Set<UIGridPolicy> policies = new HashSet<>();

    public UIGridPolicySet(GridPolicySet gridPolicySet) {

        this.workflowStatus = gridPolicySet.getWorkflowStatus();
        this.policyId = gridPolicySet.getId();
        this.policyName = gridPolicySet.getName();
        ImmutableSortedSet<GridPolicy> flows = gridPolicySet.getGridPolicies();
        if (flows != null && !flows.isEmpty()) {
            GridPolicy flow = flows.first();
            this.ingressPorts = flow.getIngressClusterNodeInterfaces();
            this.sourceMacTag = flow.getSourceMacTag();
            this.destinationMacTag = flow.getDestinationMacTag();
            flows.stream().forEach(_flow -> {
                UIGridPolicy uiPolicy = new UIGridPolicy(_flow);
                this.policies.add(uiPolicy);
            });
        }
        this.fieldOffset1 = gridPolicySet.getFieldOffset1();
        this.fieldOffset2 = gridPolicySet.getFieldOffset2();
        this.fieldOffset3 = gridPolicySet.getFieldOffset3();
        this.fieldOffset4 = gridPolicySet.getFieldOffset4();
        this.isLoopbackEnabled = gridPolicySet.isLoopbackEnabled();
        this.flexMatchEnabled = !gridPolicySet.getFlexMatchProfiles().isEmpty();
    }
}

@Getter
@Setter
class UIGridPolicy {

    ImmutableSet<ClusterNodeInterface> egressPorts;
    ImmutableSet<String> vlans;
    Long flowId = 0L;
    Long l2RulesCount = 0L;
    Long l3RulesCount = 0L;
    Long l3IPV4Count = 0L;
    Long l3IPV6Count = 0L;
    Long l23Count = 0L;
    Long l23IPV4Count = 0L;
    Long l23IPV6Count = 0L;
    Long udaRulesCount = 0L;
    String l2RulesetName = "";
    String l3IPV4RulesetName = "";
    String l3IPV6RulesetName = "";
    String l23IPV4RulesetName = "";
    String l23IPV6RulesetName = "";
    String udaRulesetName = "";
    Integer sequence = 0;
    List<TunnelDevicePolicy> tunnelPolicies;

    public UIGridPolicy(GridPolicy gridPolicy) {
        this.flowId = gridPolicy.getId();
        this.sequence = gridPolicy.getSequence();
        this.egressPorts = gridPolicy.getEgressClusterNodeInterfaces();
        updateCountsForGridPolicy(gridPolicy);
        this.vlans = gridPolicy.getVlans();
    }

    private void updateCountsForGridPolicy(GridPolicy gridPolicy) {
        gridPolicy.getRuleSets().stream().forEach(ruleSet -> {
            if (ruleSet.getType() == GridRuleSet.Type.L2) {
                l2RulesCount += ruleSet.getRules().size();
                l2RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == GridRuleSet.Type.L3 && ruleSet.getIpVersion() == GridRuleSet.IpVersion.V6) {
                l3RulesCount += ruleSet.getRules().size();
                l3IPV6Count += ruleSet.getRules().size();
                l3IPV6RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == GridRuleSet.Type.L3 && ruleSet.getIpVersion() == GridRuleSet.IpVersion.V4) {
                l3RulesCount += ruleSet.getRules().size();
                l3IPV4Count += ruleSet.getRules().size();
                l3IPV4RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == GridRuleSet.Type.L23 && ruleSet.getIpVersion() == GridRuleSet.IpVersion.V4) {
                l23Count += ruleSet.getRules().size();
                l23IPV4Count += ruleSet.getRules().size();
                l23IPV4RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == GridRuleSet.Type.L23 && ruleSet.getIpVersion() == GridRuleSet.IpVersion.V6) {
                l23Count += ruleSet.getRules().size();
                l23IPV6Count += ruleSet.getRules().size();
                l23IPV6RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == GridRuleSet.Type.UDA) {
                udaRulesCount += ruleSet.getRules().size();
                udaRulesetName = ruleSet.getName();
            }
        });
    }
}
