package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.EventManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.EventRepository;
import com.brocade.bvm.model.db.Event;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The GenericEventManager class implements methods to update events status
 */
@Named
@Slf4j
public class GenericEventManager implements EventManager {

    @Inject
    EventRepository eventRepository;

    /**
     * This method is used to update event status to CLOSED in BVM DB
     *
     * @param closeEvents
     * @param status
     * @return Boolean
     */
    @Override
    public Boolean updateEvents(List<Long> closeEvents, Event.Status status) {

        log.info("Updating events {} to status {}", closeEvents, status);
        //update events to the given status
        List<Event> events = (List<Event>) eventRepository.findAll(closeEvents);
        if (events.size() == closeEvents.size()) {
            events.stream().forEach(event -> {
                event.setStatus(Event.Status.CLOSED);
            });
            eventRepository.save(events);
            log.info("Finished Updating events {} to status {}", events.stream().map(Event::getId).collect(Collectors.toList()), status);
            return true;
        }
        throw new ValidationException("events.invalid.id");
    }
}
