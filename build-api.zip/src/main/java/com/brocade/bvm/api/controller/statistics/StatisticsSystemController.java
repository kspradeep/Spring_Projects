package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.statistics.StatisticsSystemRepository;
import com.brocade.bvm.model.db.statistics.SystemUtilizationModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;

@RequestMapping(produces = "application/json", value = "/statistics")
@RestController
@Slf4j
public class StatisticsSystemController {

  @Inject private StatisticsSystemRepository statisticsSystemReposiroty;

  @RequestMapping(value = "{deviceId}/system")
  public SystemUtilizationModel getSystemUtilization(@PathVariable("deviceId") Long deviceId) {
    return statisticsSystemReposiroty.getSystemUtilization(deviceId);
  }
}
