package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.TemplatePolicy;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface TemplatePolicyManager {

    /**
     * return saved/updated template policies
     */
    List<Long> saveOrCommitPolicies(Set<? extends TemplatePolicy> templatePolicies, String action);

    Map<String, Set<TemplatePolicy>> getTemplatePolicies(Set<? extends TemplatePolicy> templatePolicies);

    Long deletePolicy(Long policyId);

    Long recoverPolicy(Long policyId);

    void validateTemplatePolicies(Set<? extends TemplatePolicy> templatePolicies);
}
