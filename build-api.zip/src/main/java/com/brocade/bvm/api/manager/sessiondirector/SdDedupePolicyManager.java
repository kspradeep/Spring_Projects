package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.dao.sessiondirector.DedupePolicyHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.DedupePolicyRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.DedupePolicyHistory;
import com.brocade.bvm.model.db.sessiondirector.DeDupePolicy;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;
import com.brocade.bvm.model.exception.ServerException;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * The SdDedupePolicyManager class implements methods to perform SdDedupePolicy create/update/delete/recover on the selected SD device
 */
@Slf4j
@Named(value = "SdDedupePolicyManager")
public class SdDedupePolicyManager extends AbstractSDPolicyManager {

    @Inject
    protected DedupePolicyRepository dedupePolicyRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected JobQueue jobQueue;

    @Value("${stablenet-response.timeout.minutes}")
    private int stablenetTimeoutMinutes;

    @Value("${job.poll.interval.seconds:3}")
    private int jobPollIntervalSeconds;

    @Inject
    protected JobRepository jobRepository;

    @Inject
    private EntityManager entityManager;

    private final static String DEDUPE_ALL = "dedupe-all";
    private final static String DEDUPE_UPLANE = "dedupe-uplane";

    @Inject
    protected DedupePolicyHistoryRepository dedupePolicyHistoryRepository;

    /**
     * This method is used to validate if the given DedupePolicy is valid to commit on the device
     *
     * @param policyToSave
     * @return
     * @throws ValidationException
     */
    protected boolean isValidDedupePolicyToCommit(DeDupePolicy policyToSave) {

        // check if Any Policy on the device is in Progress
        List<WorkflowParticipant.WorkflowStatus> notAcceptableStatus = new ArrayList<>();
        notAcceptableStatus.add(WorkflowParticipant.WorkflowStatus.SUBMITTED);

        if (policyToSave != null && (policyToSave.getTimeout() < 10 || policyToSave.getTimeout() > 250)) {
            throw new ValidationException("dedupe.invalid.timeout");
        }

        List<Long> inProgressOrErrorPoliciesOnDevice = dedupePolicyRepository
                .findByDeviceAndInWorkflowStatus(policyToSave.getDevice().getId(), notAcceptableStatus);
        if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
            throw new ValidationException("policy.commit.inprogress");
        }

        List<DedupePolicyHistory> dedupePolicyHistories = dedupePolicyHistoryRepository.findByIdAndWorkflowStatus(policyToSave.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (!dedupePolicyHistories.isEmpty() && policyToSave.getTimeout() == dedupePolicyHistories.get(0).buildParent().getTimeout()) {
            throw new ValidationException("dedupe.commit.sametimeout");
        }
        return true;
    }

    /**
     * This method checks if the DeDupePolicy name is already used by other SD policies for SAVE
     *
     * @param policyToUpdate
     * @throws ValidationException
     */
    protected void isValidDedupePolicyToSave(DeDupePolicy policyToUpdate) {
        List<DeDupePolicy> deDupePolicies = dedupePolicyRepository.findByNameAndDevice(policyToUpdate.getName(), policyToUpdate.getDevice().getId());
        if (!deDupePolicies.isEmpty()) {
            throw new ValidationException("policy.save.tagnotunique");
        }
    }

    /**
     * This method is used to SAVE DeDupePolicy in BVM db as DRAFT
     *
     * @param policy
     * @return
     */
    @Override
    public Long savePolicy(SdPolicy policy) {
        DeDupePolicy policyToSave = (DeDupePolicy) policy;
        Device device = deviceRepository.findById(policyToSave.getDevice().getId());
        // populate the DeDupePolicy with db entities
        if (policyToSave.getId() == null) {
            isValidDedupePolicyToSave(policyToSave);
        }
        List<DeDupePolicy> deDupePolicies = dedupePolicyRepository.findAllByDeviceId(device.getId());
        if (!deDupePolicies.isEmpty()) {
            for (DeDupePolicy deDupePolicy : deDupePolicies) {
                deDupePolicy.setTimeout(policyToSave.getTimeout());
                deDupePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            }
        } else {
            policyToSave.setDevice(device);
            policyToSave.setName(DEDUPE_ALL);
            policyToSave.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            deDupePolicies.add(policyToSave);
            int timeOut = policyToSave.getTimeout();
            policyToSave = new DeDupePolicy();
            policyToSave.setDevice(device);
            policyToSave.setName(DEDUPE_UPLANE);
            policyToSave.setTimeout(timeOut);
            policyToSave.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            deDupePolicies.add(policyToSave);
        }
        // save policy in DB
        dedupePolicyRepository.save(deDupePolicies);
        return deDupePolicies.get(0).getId();
    }

    @Override
    protected void isPolicyInputValid(SdPolicy policy, boolean isUpdate) {

    }


    /**
     * This method is used to COMMIT DeDupePolicy in the given SD device
     *
     * @param policyToCommit
     * @return
     * @throws ValidationException
     */
    @Override
    public Long commitPolicy(SdPolicy policyToCommit) {
        DeDupePolicy policy = (DeDupePolicy) policyToCommit;
        isValidDedupePolicyToCommit(policy);
        Device device = deviceRepository.findById(policy.getDevice().getId());
        policy.setDevice(device);
        boolean isNew = false;
        long jobId = -1;
        long policyId = -1;
        Job jobObject = null;
        // check if policy exists
        if (policy.getId() == null) {
            policyId = savePolicy(policy);
            isNew = true;
        } else {
            policyId = policy.getId();
        }
        DeDupePolicy policyInDb = dedupePolicyRepository.findOne(policyId);
        DeDupePolicy policyFromHistory = getPolicyFromHistory(policyInDb, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (policyInDb != null) {
            Job.Type type = Job.Type.SD_DEDUPE_POLICY_CREATE;
            if (!isNew) {
                savePolicy(policy);
                if (policyFromHistory != null) {
                    type = Job.Type.SD_DEDUPE_POLICY_UPDATE;
                }
            }
            List<Long> impactedObjectIds = new ArrayList<>();
            impactedObjectIds.add(policyId);

            jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(policy.getDevice().getId())
                    .parentObjectId(policyId).impactedObjectIds(impactedObjectIds).build());

            jobObject = getJobStatus(jobId);
            //Reverting the Configuration if the JOB fails as there is no recovery mechanism
            if (jobObject.getStatus().equals(Job.Status.FAILED)) {
                policyFromHistory.setDevice(device);
                dedupePolicyRepository.save(policyFromHistory);
                throw new ServerException(jobObject.getJobResult());
            }
            return jobObject.getId();
        }
        throw new ValidationException("policy.get.notfound");

    }

    /**
     * This method is used to DELETE DeDupePolicy in the given SD device
     *
     * @param policies
     * @return
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(List<? extends SdPolicy> policies) {
        return null;
    }

    /**
     * This method is used to recover DeDupePolicy which is in ERROR state
     *
     * @param policyId
     * @return
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        DeDupePolicy deDupePolicy = dedupePolicyRepository.findOne(policyId);
        if (deDupePolicy == null) {
            throw new ValidationException("policy.get.notfound");
        }
        deDupePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        dedupePolicyRepository.save(deDupePolicy);

        List<Long> impactedObjectIds = new ArrayList<>();
        impactedObjectIds.add(deDupePolicy.getId());
        Job.Type jobType = Job.Type.SD_DEDUPE_POLICY_RECOVER;
        long jobId = jobQueue.submit(JobTemplate
                .builder()
                .type(jobType)
                .deviceId(deDupePolicy.getDevice().getId())
                .impactedObjectIds(impactedObjectIds)
                .parentObjectId(policyId).build());

        return jobId;
    }

    /**
     * This method fetches the latest ACTIVE DedupePolicy from history for the current policy
     *
     * @param policy
     * @param workflowStatus
     * @return
     */
    protected DeDupePolicy getPolicyFromHistory(DeDupePolicy policy, List<WorkflowParticipant.WorkflowStatus> workflowStatus) {
        DeDupePolicy policyFromHistory = null;
        // get the previous policy name from the history.
        List<DedupePolicyHistory> policyHistoryList = dedupePolicyHistoryRepository.findByIdAndWorkflowStatus(policy.getId(),
                workflowStatus);
        if (!policyHistoryList.isEmpty()) {
            DedupePolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a DedupePolicyHistory entity with oldName {} and lasted DedupePolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * This method  polls for job status
     *
     * @param jobId
     * @return
     */
    private Job getJobStatus(Long jobId) {
        log.debug("********** Job Status polling **********");
        long startTime = System.currentTimeMillis();
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }
            try {
                TimeUnit.SECONDS.sleep(jobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((stablenetTimeoutMinutes + 1) * 1000 * 60)) {
                log.warn("Job status polling timeout!");
                break;
            }
        }
        throw new ValidationException("job.get.notfound");
    }
}
