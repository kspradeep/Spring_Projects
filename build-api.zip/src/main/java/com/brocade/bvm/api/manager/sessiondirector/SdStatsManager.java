package com.brocade.bvm.api.manager.sessiondirector;


import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.sessiondirector.SdStatsRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.Stats;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.util.*;

@Slf4j
@Named(value = "SdStatsManager")
public class SdStatsManager {

    @Inject
    private SdRestManager sdRestManager;

    @Inject
    private SdStatsRepository sdStatsRepository;

    private static final String TOTAL_NO_OF_PKTS = "Total No Of Packets";
    private static final String NO_OF_PKTS_RECEIVED = "Number of Packets Received";

    public Object getStats(String statsType, Device device) {
        log.info("Request for " + statsType + " process going to start.");
        if(statsType != null) {
            if (Stats.Request.valueOf(statsType).name().startsWith("PKT_STATS_")) {
                return getPacketStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("MEM_STATS_")) {
                return getMemoryStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("TRAFFIC_STATS_")) {
                return getTrafficStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("RULES_STATS_")) {
                return getRulesStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("ANOMALY_STATS_")) {
                return getAnomalyStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("MGMT_RULE_")) {
                return getManagementRuleStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("USER_COUNT_")) {
                return getUserCountStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("RULE_COUNT_")) {
                return getRuleCountStats(device, statsType);
            } else if (Stats.Request.valueOf(statsType).name().startsWith("SAMPLING_STATS_")) {
                return getSamplingStats(device, statsType);
            }
        }
        return null;
    }

    /**
     * This is generic method for Packet Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getPacketStats(Device device, String statsType) {
        if(statsType != null) {
            Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
            if (res != null) {
                if (res.getStatus() == HttpStatus.SC_OK) {
                    List<JSONObject> objects = new ArrayList<>();
                    try {
                        JSONObject responseJson = sdRestManager.getJsonFromResponse(res);
                        JSONArray jsonArray = (JSONArray) (responseJson.has(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new JSONArray());
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject statsObj = jsonArray.getJSONObject(i);
                            Iterator<String> keysItr = statsObj.keys();
                            while (keysItr.hasNext()) {
                                String key = keysItr.next();
                                if (statsObj.has(key)) {
                                    JSONArray statsDataArray = (JSONArray) statsObj.get(key);
                                    for (int j = 0; j < statsDataArray.length(); j++) {
                                        JSONObject obj = statsDataArray.getJSONObject(j);
                                        if (obj.has(TOTAL_NO_OF_PKTS) || obj.has(NO_OF_PKTS_RECEIVED)) {
                                            JSONObject jsonObject = new JSONObject();
                                            jsonObject.put(System.currentTimeMillis() / 1000 + "", obj);
                                            objects.add(jsonObject);
                                        }
                                    }
                                }
                            }
                        }
                        return !objects.isEmpty() ? objects.get(0).toString() : objects;
                    } catch (JSONException e) {
                        log.error("Exception while fetching PACKET_STATS {}", e.getMessage());
                    }
                } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                    return "";
                }
            }
        } else {
            return "";
        }
        throw new ValidationException("ERROR while fetching stats PACKET_STATS through BVM->REST->SD");
    }

    /**
     * This is generic method for Memory Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getMemoryStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.MEMORY_STATS.getValue()) ? responseJson.get(Stats.Response.MEMORY_STATS.getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching MEMORY_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching MEMORY_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for Traffic Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getTrafficStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.TRAFFIC_STATS.getValue()) ? responseJson.get(Stats.Response.TRAFFIC_STATS.getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching TRAFFIC_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching TRAFFIC_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for Rules Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getRulesStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching RULES_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching RULES_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for Anomaly Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getAnomalyStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching ANOMALY_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching ANOMALY_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for Management Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getManagementRuleStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching MGMT_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching MGMT_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for UserCount Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getUserCountStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, String> map = new HashMap<>();
                    JSONObject responseJson = sdRestManager.getJsonFromResponse(res);
                    JSONArray jsonArray = (JSONArray) (responseJson.has(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new JSONArray());
                    for (int i = 0; i < jsonArray.length(); i++) {
                        try {
                            if (jsonArray.get(i) != null) {
                                map.put(System.currentTimeMillis() / 1000 + "", jsonArray.get(i).toString());
                                return map;
                            }
                        } catch (Exception e) {
                            log.error("Exception while fetching USER_COUNT_STATS {}", e.getMessage());
                        }
                    }
                } catch (JSONException e) {
                    log.error("Exception while fetching USER_COUNT_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching USER_COUNT_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for RuleCount Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getRuleCountStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                try {
                    Map<String, Object> responseJson = sdRestManager.getJsonResponseInMap(res);
                    if (responseJson != null) {
                        List<Object> objectList = (List<Object>) (responseJson.containsKey(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new ArrayList<Object>());
                        if (objectList.size() > 0) {
                            return objectList.get(0);
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching RULE_COUNT_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching RULE_COUNT_STATS data through BVM->REST->SD");
    }

    /**
     * This is generic method for Packet Stats request and return packet stats according to request
     *
     * @param device
     * @param statsType
     * @return
     */
    private Object getSamplingStats(Device device, String statsType) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.valueOf(statsType).getValue());
        if (res != null) {
            if (res.getStatus() == HttpStatus.SC_OK) {
                List<JSONObject> objects = new ArrayList<>();
                try {
                    JSONObject responseJson = sdRestManager.getJsonFromResponse(res);
                    JSONArray jsonArray = (JSONArray) (responseJson.has(Stats.Response.valueOf(statsType).getValue()) ? responseJson.get(Stats.Response.valueOf(statsType).getValue()) : new JSONArray());
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject statsObj = jsonArray.getJSONObject(i);
                        JSONObject obj = new JSONObject();
                        obj.put(System.currentTimeMillis() / 1000 + "", statsObj);
                        objects.add(obj);
                    }
                    return !objects.isEmpty() ? objects.get(0).toString() : objects;
                } catch (JSONException e) {
                    log.error("Exception while fetching PACKET_STATS {}", e.getMessage());
                }
            } else if (res.getStatus() == HttpStatus.SC_NO_CONTENT) {
                return "";
            }
        }
        throw new ValidationException("ERROR while fetching stats PACKET_STATS through BVM->REST->SD");
    }

    /**
     * This method is used for clearing all stats
     *
     * @param device
     * @return
     */
    public int clearStats(Device device) {
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.CLEAR_STATS.getValue());
        if (res != null && res.getStatus() == HttpStatus.SC_OK) {
            return HttpStatus.SC_OK;
        }
        throw new ValidationException("ERROR while CLEAR_STATS through BVM->REST->SD");
    }

}
