package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Event;

import java.util.List;

/**
 * Created by nthatiko on 7/4/2016.
 */
public interface EventManager {

    Boolean updateEvents(List<Long> closeEvents, Event.Status status);
}
