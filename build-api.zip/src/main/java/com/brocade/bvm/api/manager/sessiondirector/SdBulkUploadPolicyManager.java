package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.controller.SdPolicyController;
import com.brocade.bvm.api.manager.BulkPolicyManager;
import com.brocade.bvm.api.model.SdPolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.sessiondirector.FilterPolicyRepository;
import com.brocade.bvm.model.db.sessiondirector.BulkFilterPolicyRequest;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterRule;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;

/**
 * The SdBulkUploadPolicyManager class implements methods to process bulk SdFilterPolicy data and return back the structured data to UI
 */
@Slf4j
@Named
public class SdBulkUploadPolicyManager implements BulkPolicyManager {

    @Inject
    protected FilterPolicyRepository sdFilterPolicyRepository;

    /**
     * This method is used to convert the bulk SdFilterPolicy data which is in BulkFilterPolicyRequest format to SdFilterPolicy SdRuleSets
     *
     * @param sdPolicyRequest
     * @param deviceId
     * @return
     */
    public FilterPolicy saveAndCommitPolcies(SdPolicyRequest sdPolicyRequest, Long deviceId) {

        Set<FilterRule> sdRuleSetUploaded = new HashSet<>();
        Set<FilterRule> sdRulesFromUi = new TreeSet<>();

        /* Collecting old structured SdRuleSets from UI to merge with freshly uploaded SdRuleSets*/
        sdPolicyRequest.getFilterPolicies().forEach(filterPolicy -> {
            sdRulesFromUi.addAll(filterPolicy.getRules());
        });

        /* Collecting freshly uploaded SdRuleSets*/
        for (FilterPolicy filterPolicy : sdPolicyRequest.getFilterPolicies()) {
            sdRuleSetUploaded.addAll(getValidFilterRuleSets(filterPolicy.getBulkFilterPolicyRequest()));
        }

        /* Merging sdRuleSetFromUi with sdRuleSetUploaded*/
        SortedSet<FilterRule> updatedRules = mergeAndReturnUpdatedSet(sdRulesFromUi, sdRuleSetUploaded);

        sdPolicyRequest.getFilterPolicies().forEach(filterPolicy -> {
            filterPolicy.setRules(updatedRules);
            filterPolicy.setBulkFilterPolicyRequest(null);
        });
        if (!sdPolicyRequest.getFilterPolicies().isEmpty()) {
            return Lists.newArrayList(sdPolicyRequest.getFilterPolicies()).get(0);
        }
        return null;
    }

    /**
     * This method is used merge uploadedSet with existingUiRuleSet
     *
     * @param existingUiRules
     * @param uploadedRules
     * @return
     */
    private SortedSet<FilterRule> mergeAndReturnUpdatedSet(Set<FilterRule> existingUiRules,
                                                           Set<FilterRule> uploadedRules) {
        SortedSet<FilterRule> updatedRules = new TreeSet<>();

        uploadedRules.forEach(eachUploaded -> {
            Optional<FilterRule> searchResult = existingUiRules.stream()
                    .filter(po ->
                            ((po.getImsi() == null && eachUploaded.getImsi() == null) || (po.getImsi() != null && eachUploaded.getImsi() != null && po.getImsi().compareTo(eachUploaded.getImsi()) == 0))
                                    && ((po.getApn() == null && eachUploaded.getApn() == null) || (po.getApn() != null && eachUploaded.getApn() != null && po.getApn().compareTo(eachUploaded.getApn()) == 0))
                                    && ((po.getQci() == null && eachUploaded.getQci() == null) || (po.getQci() != null && eachUploaded.getQci() != null && po.getQci().compareTo(eachUploaded.getQci()) == 0))
                                    && ((po.getImei() == null && eachUploaded.getImei() == null) || (po.getImei() != null && eachUploaded.getImei() != null && po.getImei().compareTo(eachUploaded.getImei()) == 0))
                                    && ((po.getSipCallingParty() == null && eachUploaded.getSipCallingParty() == null) || (po.getSipCallingParty() != null && eachUploaded.getSipCallingParty() != null && po.getSipCallingParty().compareTo(eachUploaded.getSipCallingParty()) == 0))
                                    && ((po.getSipCalledParty() == null && eachUploaded.getSipCalledParty() == null) || (po.getSipCalledParty() != null && eachUploaded.getSipCalledParty() != null && po.getSipCalledParty().compareTo(eachUploaded.getSipCalledParty()) == 0))
                    ).findFirst();
            if (!searchResult.isPresent()) {
                updatedRules.add(eachUploaded);
            } else {
                //perform update
                FilterRule existingRule = searchResult.get();
                existingRule.setImsi(eachUploaded.getImsi());
                existingRule.setPriority(eachUploaded.getPriority());
                existingRule.setPortGroup(eachUploaded.getPortGroup());
                existingRule.setReplicationPortGroup(eachUploaded.getReplicationPortGroup());
                existingRule.setApn(eachUploaded.getApn());
                existingRule.setQci(eachUploaded.getQci());
                existingRule.setImei(eachUploaded.getImei());
                existingRule.setSipCallingParty(eachUploaded.getSipCallingParty());
                existingRule.setSipCalledParty(eachUploaded.getSipCalledParty());
                existingRule.setSamplingPolicy(eachUploaded.getSamplingPolicy());
                if (eachUploaded.getPortGroup() == null) {
                    existingRule.setAction(SdPolicyController.DROP);
                } else {
                    existingRule.setAction(SdPolicyController.FORWARD);
                }
                updatedRules.add(existingRule);
            }
        });

        existingUiRules.forEach(eachExisting -> {
            Optional<FilterRule> searchResult = uploadedRules.stream()
                    .filter(po ->
                            ((po.getImsi() == null && eachExisting.getImsi() == null) || (po.getImsi() != null && eachExisting.getImsi() != null && po.getImsi().compareTo(eachExisting.getImsi()) == 0))
                                    && ((po.getApn() == null && eachExisting.getApn() == null) || (po.getApn() != null && eachExisting.getApn() != null && po.getApn().compareTo(eachExisting.getApn()) == 0))
                                    && ((po.getQci() == null && eachExisting.getQci() == null) || (po.getQci() != null && eachExisting.getQci() != null && po.getQci().compareTo(eachExisting.getQci()) == 0))
                                    && ((po.getImei() == null && eachExisting.getImei() == null) || (po.getImei() != null && eachExisting.getImei() != null && po.getImei().compareTo(eachExisting.getImei()) == 0))
                                    && ((po.getSipCallingParty() == null && eachExisting.getSipCallingParty() == null) || (po.getSipCallingParty() != null && eachExisting.getSipCallingParty() != null && po.getSipCallingParty().compareTo(eachExisting.getSipCallingParty()) == 0))
                                    && ((po.getSipCalledParty() == null && eachExisting.getSipCalledParty() == null) || (po.getSipCalledParty() != null && eachExisting.getSipCalledParty() != null && po.getSipCalledParty().compareTo(eachExisting.getSipCalledParty()) == 0))
                    ).findFirst();
            if (!searchResult.isPresent()) {
                updatedRules.add(eachExisting);
            }
        });
        return updatedRules;
    }

    /**
     * This method validates and transform the BulkFilterPolicyRequest data into Set of SdRuleSet
     *
     * @param filterPolicyRequest
     * @return
     */
    private Set<FilterRule> getValidFilterRuleSets(BulkFilterPolicyRequest filterPolicyRequest) {
        Set<FilterRule> sdRuleSets = new HashSet<>();
        Set<FilterRule> sdRules = new HashSet<>();
        if (filterPolicyRequest.getPriority() == null || (filterPolicyRequest.getPriority() != null && !(filterPolicyRequest.getPriority() >= FilterRule.PRIORITY_MIN && filterPolicyRequest.getPriority() <= FilterRule.PRIORITY_MAX))) {
            throw new ValidationException("sdfilterpolicy.save.prioritynotinrange");
        } else if (filterPolicyRequest.getPortGroup() == null && FilterRule.FORWARD.equalsIgnoreCase(filterPolicyRequest.getAction())) {
            throw new ValidationException("sdfilterpolicy.save.portGroup.mandatory");
        } else {
            List<String> dataHeaderList = Arrays.asList(filterPolicyRequest.getDataHeader().split(","));
            int imsiIndex = -1;
            int imeiIndex = -1;
            int apnIndex = -1;
            int sipCallingPartyIndex = -1;
            int sipCalledPartyIndex = -1;
            if (dataHeaderList.size() > 0) {
                int index = 0;
                for (String dataHeader : dataHeaderList) {
                    if (dataHeader != null) {
                        dataHeader = dataHeader.trim();
                        if (dataHeader.equalsIgnoreCase("imsi")) {
                            imsiIndex = index;
                        } else if (dataHeader.equalsIgnoreCase("imei")) {
                            imeiIndex = index;
                        } else if (dataHeader.equalsIgnoreCase("apn")) {
                            apnIndex = index;
                        } else if (dataHeader.equalsIgnoreCase("sipCallingParty")) {
                            sipCallingPartyIndex = index;
                        } else if (dataHeader.equalsIgnoreCase("sipCalledParty")) {
                            sipCalledPartyIndex = index;
                        }
                    }
                    index++;
                }

                List<String> dataList = Arrays.asList(filterPolicyRequest.getData().split(";"));
                if (dataList.size() > 0) {
                    for (String data : dataList) {
                        String[] filterInputArray = data.split(",");
                        FilterRule filterRule = new FilterRule();
                        filterRule.setPriority(filterPolicyRequest.getPriority());
                        filterRule.setPortGroup(filterPolicyRequest.getPortGroup());
                        filterRule.setApn(filterPolicyRequest.getApn());
                        filterRule.setQci(filterPolicyRequest.getQci());
                        filterRule.setImei(filterPolicyRequest.getImei());
                        filterRule.setSipCallingParty(filterPolicyRequest.getSipCallingParty());
                        filterRule.setSipCalledParty(filterPolicyRequest.getSipCalledParty());
                        filterRule.setSamplingPolicy(filterPolicyRequest.getSamplingPolicy());
                        filterRule.setReplicationPortGroup(filterPolicyRequest.getReplicationPortGroup());
                        if (filterRule.getPortGroup() == null) {
                            filterRule.setAction(SdPolicyController.DROP);
                        } else {
                            filterRule.setAction(SdPolicyController.FORWARD);
                        }
                        if (filterInputArray != null && filterInputArray.length > 0) {
                            if (imsiIndex > -1 && imsiIndex < filterInputArray.length) {
                                String imsi = filterInputArray[imsiIndex];
                                if (imsi != null && !(imsi.trim().length() >= FilterRule.IMSI_MIN && imsi.trim().length() <= FilterRule.IMSI_MAX)) {
                                    throw new ValidationException("invalid.imsi.value");
                                }
                                filterRule.setImsi(imsi);
                            } else if (imeiIndex > -1 && imeiIndex < filterInputArray.length) {
                                String imei = filterInputArray[imeiIndex];
                                if (imei != null && !(imei.trim().length() >= FilterRule.IMEI_MIN && imei.trim().length() <= FilterRule.IMEI_MAX)) {
                                    throw new ValidationException("invalid.imei.value");
                                }
                                filterRule.setImei(imei);
                            } else if (apnIndex > -1 && apnIndex < filterInputArray.length) {
                                String apn = filterInputArray[apnIndex];
                                if (apn == null) {
                                    throw new ValidationException("sdfilterpolicy.save.invalidapn");
                                }
                                filterRule.setApn(apn);
                            } else if (sipCallingPartyIndex > -1 && sipCallingPartyIndex < filterInputArray.length) {
                                String sipCallingParty = filterInputArray[sipCallingPartyIndex];
                                if (sipCallingParty != null && !(sipCallingParty.trim().length() >= FilterRule.SIP_CALL_PARTY_MIN && sipCallingParty.trim().length() <= FilterRule.SIP_CALL_PARTY_MAX)) {
                                    throw new ValidationException("invalid.range.sipPartyValue");
                                }
                                filterRule.setSipCallingParty(sipCallingParty);
                            } else if (sipCalledPartyIndex > -1 && sipCalledPartyIndex < filterInputArray.length) {
                                String sipCalledParty = filterInputArray[sipCalledPartyIndex];
                                if (sipCalledParty != null && !(sipCalledParty.trim().length() >= FilterRule.SIP_CALL_PARTY_MIN && sipCalledParty.trim().length() <= FilterRule.SIP_CALL_PARTY_MAX)) {
                                    throw new ValidationException("invalid.range.sipPartyValue");
                                }
                                filterRule.setSipCalledParty(sipCalledParty);
                            }
                            if (filterRule.getImsi() != null || filterRule.getApn() != null || filterRule.getQci() != null || filterRule.getImei() != null || filterRule.getSipCallingParty() != null || filterRule.getSipCalledParty() != null) {
                                sdRules.add(filterRule);
                            }
                        }
                    }
                }
            }
        }
        return sdRules;
    }

    /**
     * This method checks if the bulk SdFilterPolicy input data is valid
     *
     * @param sdPolicyRequest
     */
    public void isPolicyInputValid(SdPolicyRequest sdPolicyRequest) {
        sdPolicyRequest.getFilterPolicies().stream().forEach(sdFilterPolicy -> {
            sdFilterPolicy.getRules().forEach(sdRule -> {
                if (sdRule.getPriority() == null || (sdRule.getPriority() != null && !(sdRule.getPriority() >= FilterRule.PRIORITY_MIN && sdRule.getPriority() <= FilterRule.PRIORITY_MAX))) {
                    throw new ValidationException("sdfilterpolicy.save.prioritynotinrange");
                } else if (sdRule.getImsi() != null && !(sdRule.getImsi().length() >= FilterRule.IMSI_MIN && sdRule.getImsi().length() <= FilterRule.IMSI_MAX)) {
                    throw new ValidationException("invalid.imsi.value");
                } else if (sdRule.getImei() != null && !(sdRule.getImei().length() >= FilterRule.IMEI_MIN && sdRule.getImei().length() <= FilterRule.IMEI_MAX)) {
                    throw new ValidationException("invalid.imei.value");
                } else if (sdRule.getSipCalledParty() != null && !(sdRule.getSipCalledParty().length() >= FilterRule.SIP_CALL_PARTY_MIN && sdRule.getSipCalledParty().length() <= FilterRule.SIP_CALL_PARTY_MAX)) {
                    throw new ValidationException("invalid.range.sipPartyValue");
                } else if (sdRule.getSipCallingParty() != null && !(sdRule.getSipCallingParty().length() >= FilterRule.SIP_CALL_PARTY_MIN && sdRule.getSipCallingParty().length() <= FilterRule.SIP_CALL_PARTY_MAX)) {
                    throw new ValidationException("invalid.range.sipPartyValue");
                } else if (sdRule.getPortGroup() == null && FilterRule.FORWARD.equalsIgnoreCase(sdRule.getAction())) {
                    throw new ValidationException("sdfilterpolicy.portGroup.mandatory");
                } else {
                    List<FilterRule> sdRules = new ArrayList<>(sdFilterPolicy.getRules());
                    int duplicateRuleCount = Collections.binarySearch(sdRules, sdRule, new SdRuleComparator());
                    if (duplicateRuleCount > -1) {
                        throw new ValidationException("policy.save.rulenotunique");
                    }
                }
            });
        });
    }

    /**
     * This is used for to compare FilterRule
     */
    public class SdRuleComparator implements Comparator<FilterRule> {
        @Override
        public int compare(FilterRule filterRule1, FilterRule filterRule2) {
            if (filterRule1 != filterRule2) {
                return (Objects.hash(filterRule1.getImsi(), filterRule1.getApn(), filterRule1.getQci(), filterRule1.getImei(), filterRule1.getSipCallingParty(), filterRule1.getSipCalledParty()) - (Objects.hash(filterRule2.getImsi(), filterRule2.getApn(), filterRule2.getQci(), filterRule2.getImei(), filterRule2.getSipCallingParty(), filterRule2.getSipCalledParty())));
            } else {
                return -1;
            }
        }
    }
}
