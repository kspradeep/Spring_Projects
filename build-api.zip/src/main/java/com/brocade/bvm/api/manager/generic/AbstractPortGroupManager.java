package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.PortGroupManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.TargetHost.Mode;
import com.brocade.bvm.model.db.history.PortGroupHistory;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The AbstractPortGroupManager class implements methods to perform create/update/delete/recovery operations related to port group
 */
@Slf4j
public abstract class AbstractPortGroupManager implements PortGroupManager {

    private static final String typeMismatch = "%s port type is not set.";

    @Inject
    protected JobQueue jobQueue;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    private GTPDevicePolicyRepository gtpDevicePolicyRepository;

    @Inject
    private MPLSDevicePolicyRepository mplsDevicePolicyRepository;

    @Inject
    protected PacketSlicingModulePolicyRepository packetSlicingModulePolicyRepository;

    @Inject
    private PortGroupHistoryRepository portGroupHistoryRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    /**
     * This method is used to create and save port group
     *
     * @param portGroup
     * @param device
     * @return Long This returns db Id
     */
    public Long savePortGroup(PortGroup portGroup, Device device) {
        validatePortGroupName(device, portGroup.getName());
        boolean isPlainSLX = (device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN);
        if (portGroup.getPorts().isEmpty()) {
            if (isPlainSLX) {
                throw new ValidationException("Port Channel with empty Port not allowed.");
            } else {
                throw new ValidationException("Port Group with empty Port not allowed.");
            }
        }

        List<Long> portIds = portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        validateInterfacesWithPacketTruncation(portIds, device.getId());
        // Check if participating ports are all of type EGRESS / SERVICE PORT
        Set<Port> portsInDb = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
        if (!isPlainSLX) {
            validatePortsAreOfTypeAllEgressOrAllServicePort(portsInDb);
        }

        // Check if all participating ports are either part of packet slicing policy or not.
        List<Long> truncateEnabledPorts = portGroupRepository.findTruncateEnabledEgressPorts(portIds);
        if (!truncateEnabledPorts.isEmpty() && truncateEnabledPorts.size() != portIds.size()) {
            log.error("All participating port(s) are either egress truncate enabled or disabled. Aborting!");
            throw new ValidationException("port.egressTruncate.enabledOrDisabled");
        }

        // Checking if the selected egress ports are part of MPLS policy or not
        List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(device.getId(), portIds);
        if (!mplsPolicyIds.isEmpty()) {
            throw new ValidationException("port.egress.existsInMPLS");
        }

        // #3 Check if PortGroup name is already in use.
        if (portGroupRepository.findByNameAndDevice(portGroup.getName(), device) != null) {
            log.error(isPlainSLX ? "Port channel Id already in use. Aborting!" : "Port group name already in use. Aborting!");
            throw new ValidationException(isPlainSLX ? "portChannel.id.exists" : "portGroup.name.exists");
            // TODO :: Remove duplicate codes form i18 properties file. (3000)
        }
        // #4 Check if participating ports are in use by other port groups
        if (!portGroupRepository.findPortIdsByPortIds(portIds).isEmpty()) {
            log.error("Participating ports are in use by other port group. Aborting!");
            throw new ValidationException("port.exists.portGroup");
        }

        // #5 Check if participating ports are in use by policies(flows) as EGREES or SERVICE_PORT
        validatePortsIfUsedInPolicy(portIds, (Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode()));

        // Check if participating ports are in use by SD Ingress Ports as Service Ports
        validatePortsIfUsedInSDPorts(portIds);

        // #6 Check if participating ports are in use by policies(flows) as EGREES or SERVICE_PORT
        if ((device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN)) {
            if (!portGroupRepository.findsPortIdsUsedInPolicy(portIds).isEmpty()) {
                log.error("Participating ports are in use by policy. Aborting!");
                throw new ValidationException("port.exists.policy.portChannel.error");
            }

            if (!policyRepository.findByTimestampEgressPorts(portIds).isEmpty()) {
                log.error("Timestamp is enabled on selected port(s).");
                throw new ValidationException("port.timestamp.enabled");
            }

            if (!portGroupRepository.findByDeviceIdTvfDomainAndEgressPortsAndNotInCurrentPolicy(device.getId(), portIds).isEmpty()) {
                log.error("Selected egress interface is associated with a TVF domain.");
                throw new ValidationException("policy.tvfDomain.selected.egressPorts");
            }
        }

        // #7 Check if primary port exists in participating port list.
        if (!portIds.contains(portGroup.getPrimaryPort().getId())) {
            if (isPlainSLX) {
                log.error("Primary port should be part of port channel. Aborting!");
                throw new ValidationException("port.primary.portChannel");
            } else {
                log.error("Primary port should be part of port group. Aborting!");
                throw new ValidationException("port.primary.portGroup");
            }
        }

        /* Checking if the selected GTP profile id is valid or not*/
        Long gtpProfileId = portGroup.getGtpProfileId();
        if (gtpProfileId != null) {
            GTPDevicePolicy gtpProfile = gtpDevicePolicyRepository.findOne(gtpProfileId);
            if (gtpProfile != null) {
                portGroup.setGtpProfile(gtpProfile);
            } else {
                throw new ValidationException("portGroup.gtpProfile.invalid");
            }
        }

        if (portGroup.getLineSpeed() != null && portGroup.getLineSpeed() > 0 && isPlainSLX) {
            long lineSpeed = portGroup.getLineSpeed();
            portsInDb.stream().forEach(port -> {
                port.setLineSpeed(lineSpeed);
            });
        }

        portGroup.setPorts(portsInDb);
        portGroup.setDevice(device);
        for (Port port : portsInDb) {
            if (port.getId() == portGroup.getPrimaryPort().getId()) {
                portGroup.setPrimaryPort(port);
                break;
            }
        }
        portGroup.setLoopbackEnabled(portGroup.isLoopbackEnabled());
        portGroup.setWorkflowStatus(WorkflowStatus.DRAFT);
        portRepository.save(portsInDb);
        portGroup = portGroupRepository.save(portGroup);
        return portGroup.getId();
    }

    /**
     * This method is used to commit port group on the given device
     *
     * @param portGroup
     * @param device
     * @return Long This returns jobId
     */
    @Override
    public Long commitPortGroup(PortGroup portGroup, Device device) {
        Long portGroupId = savePortGroup(portGroup, device);
        portGroup = portGroupRepository.findOne(portGroupId);
        validateInterfacesTypeNullOrNone(portGroup);
        List<Long> portIds = portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Set<Port> portsInDb = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
        List<Long> portIdsInDb = portsInDb.stream().map(Port::getId).collect(Collectors.toList());

        boolean isPortChannel = Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode();
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(isPortChannel ? Job.Type.PORT_CHANNEL_CREATE : Job.Type.PORT_GROUP_CREATE)
                .deviceId(device.getId())
                .parentObjectId(portGroup.getId())
                .impactedObjectIds(portIdsInDb)
                .build());
        return jobId;
    }

    /**
     * This method is used to update port group, on the given device
     *
     * @param portGroup
     * @param device
     * @param portGroupId
     * @return Long This returns jobId
     */
    @Override
    public Long editPortGroup(PortGroup portGroup, Device device, Long portGroupId) {
        validatePortGroupName(device, portGroup.getName());
        boolean isPlainSLX = (device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN);
        if (portGroup.getPorts().isEmpty()) {
            if (isPlainSLX) {
                throw new ValidationException("Port Channel with empty Port not allowed.");
            } else {
                throw new ValidationException("Port Group with empty Port not allowed.");
            }
        }
        List<Long> newPortIds = portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        validateInterfacesTypeNullOrNone(portGroup);
        validateInterfacesWithPacketTruncation(newPortIds, device.getId());
        PortGroup oldPortGroup = portGroupRepository.findById(portGroupId);

        List<Long> oldPortIds = oldPortGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        updateAssociatedPortStatus(oldPortIds);

        if (oldPortGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }

        Set<Port> selectedPorts = StreamSupport.stream(portRepository.findAll(newPortIds).spliterator(), false).collect(Collectors.toSet());

        if (!(device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN)) {
            validatePortsAreOfTypeAllEgressOrAllServicePort(selectedPorts);
        }

        if (oldPortGroup.getWorkflowStatus() != WorkflowStatus.DRAFT && !isPortGroupDataChanged(oldPortGroup, portGroup, oldPortIds, newPortIds)) {
            if (device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN) {
                log.error("No changes in the Port Channel info to apply on Device. Aborting!");
                throw new ValidationException("portChannel.no.change");
            } else {
                log.error("No changes in the Port Group info to apply on Device. Aborting!");
                throw new ValidationException("portGroup.no.change");
            }
        }

        /* Check if ports of portGroup are part of any packet slicing policy */
        validateAllPortsInPacketSlicing(oldPortGroup);

        if (newPortIds != null && !newPortIds.isEmpty()) {
            // Check if all participating ports are either truncate enabled or not.
            List<Long> truncateEnabledPorts = portGroupRepository.findTruncateEnabledEgressPorts(newPortIds);
            if (!truncateEnabledPorts.isEmpty() && truncateEnabledPorts.size() != newPortIds.size()) {
                log.error("All participating port(s) are neither egress truncate enabled or disabled. Aborting!");
                throw new ValidationException("port.egressTruncate.enabledOrDisabled");
            }
        }

        //Added a validation to check if the primary port is changed and this old primary port is part of mpls pop egress list, reject it
        if (oldPortGroup.getPorts() != null && oldPortGroup.getPorts().isEmpty() && oldPortGroup.getPrimaryPort() != null && oldPortGroup.getPrimaryPort().getId() != portGroup.getPrimaryPort().getId()) {
            List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(device.getId(), Arrays.asList(oldPortGroup.getPrimaryPort().getId())); // remove primary port of old object before querying
            if (!mplsPolicyIds.isEmpty()) {
                throw new ValidationException("port.primary.existsInMPLS");
            }
        }

        if (newPortIds != null && !newPortIds.isEmpty()) {
            // Checking if the selected egress ports are part of MPLS policy or not
            List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(device.getId(), newPortIds); // remove primary port of old object before querying
            if (!mplsPolicyIds.isEmpty()) {
                throw new ValidationException("port.egress.existsInMPLS");
            }
        }

        if (!oldPortGroup.getName().equals(portGroup.getName()) && Mode.OPENFLOW.equals(device.getMode())) {
            log.error("Port group name for ICX can not be modified. Aborting!");
            throw new ValidationException("portGroup.name.exists");
        } else {
            Set<String> names = portGroupRepository.findName(device.getId(), portGroup.getName(), portGroupId);
            if (!names.isEmpty()) {
                log.error(isPlainSLX ? "Port channel Id already in use. Aborting!" : "Port group name already in use. Aborting!");
                throw new ValidationException(isPlainSLX ? "portChannel.id.exists" : "portGroup.name.exists");
            }
        }

        // Check if participating ports are in use by other port groups
        if (newPortIds != null && !newPortIds.isEmpty() && !portGroupRepository.findPortIdsByPortIdsAndIdNotIn(newPortIds, oldPortGroup.getId()).isEmpty()) {
            log.error("Participating ports are in use by other port group. Aborting!");
            throw new ValidationException("port.exists.portGroup");
        }
        // Check if participating ports are in use by policies(flows) as EGREES
        validatePortsIfUsedInPolicy(newPortIds, (Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode()));

        // Check if participating ports are in use by SD Ingress Ports as Service Ports
        validatePortsIfUsedInSDPorts(newPortIds);

        // Check if participating ports are in use by policies(flows) as EGREES or SERVICE_PORT
        if ((device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN) && newPortIds != null && !newPortIds.isEmpty()) {
            if (!portGroupRepository.findsPortIdsUsedInPolicy(newPortIds).isEmpty()) {
                log.error("Participating ports are in use by policy. Aborting!");
                throw new ValidationException("port.exists.policy.portChannel.error");
            }
            if (!portGroupRepository.findByDeviceIdTvfDomainAndEgressPortsAndNotInCurrentPolicy(device.getId(), newPortIds).isEmpty()) {
                log.error("Selected egress interface is associated with a TVF domain.");
                throw new ValidationException("policy.tvfDomain.selected.egressPorts");
            }
        }

        // Check if primary port exists in participating port list.
        if (!newPortIds.contains(portGroup.getPrimaryPort().getId())) {
            log.error("Primary port should be part of port group. Aborting!");
            throw new ValidationException("port.primary.portGroup");
        }

        for (Port port : selectedPorts) {
            if (port.getId() == portGroup.getPrimaryPort().getId()) {
                portGroup.setPrimaryPort(port);
                break;
            }
        }

        if (oldPortGroup == null || oldPortGroup.getWorkflowStatus().equals(WorkflowStatus.SUBMITTED)) {
            log.error("Can't edit as Port Group with name [{}] on device [{}] which is in progress ", portGroup.getName(), portGroup.getDevice().getId());
            throw new ValidationException("3011");
        }

        if (!oldPortGroup.getPorts().isEmpty() && oldPortGroup.getPrimaryPort() != null && !oldPortGroup.getPrimaryPort().getId().equals(portGroup.getPrimaryPort().getId())) {
            oldPortGroup.setPrimaryPort(portGroup.getPrimaryPort());
        }

        if ((oldPortGroup.getLineSpeed() == null && portGroup.getLineSpeed() != null) || oldPortGroup.getLineSpeed() != null && portGroup.getLineSpeed() != null && oldPortGroup.getLineSpeed().longValue() != portGroup.getLineSpeed().longValue()) {
            oldPortGroup.setLineSpeed(portGroup.getLineSpeed());
        }

        if (!oldPortGroup.getName().equals(portGroup.getName())) {
            oldPortGroup.setName(portGroup.getName());
        }
        oldPortGroup.setMinimumLinkEnabled(portGroup.isMinimumLinkEnabled());
        oldPortGroup.setLoopbackEnabled(portGroup.isLoopbackEnabled());
        for (Long newPortId : newPortIds) {
            if (!oldPortIds.contains(newPortId)) {
                oldPortIds.add(newPortId);
            }
        }

        if (portGroup.getLineSpeed() != null && portGroup.getLineSpeed() > 0 && device.getType() == Device.Type.SLX && device.getMode() == Mode.PLAIN) {
            selectedPorts.stream().forEach(port -> {
                port.setLineSpeed(portGroup.getLineSpeed());
            });
        }

        oldPortGroup.setPorts(selectedPorts);

        /* Checking if the selected GTP profile id is valid or not*/
        Long gtpProfileId = portGroup.getGtpProfileId();
        if (gtpProfileId != null) {
            GTPDevicePolicy gtpProfile = gtpDevicePolicyRepository.findOne(gtpProfileId);
            if (gtpProfile != null) {
                oldPortGroup.setGtpProfile(gtpProfile);
            } else {
                throw new ValidationException("portGroup.gtpProfile.invalid");
            }
        } else {
            oldPortGroup.setGtpProfile(null);
        }
        boolean isCreateNew = oldPortGroup.getWorkflowStatus() == WorkflowStatus.DRAFT;
        boolean isPortChannel = Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode();
        Job.Type type = isCreateNew ? Job.Type.PORT_GROUP_CREATE : Job.Type.PORT_GROUP_UPDATE;
        if (isPortChannel) {
            type = isCreateNew ? Job.Type.PORT_CHANNEL_CREATE : Job.Type.PORT_CHANNEL_UPDATE;
        }
        oldPortGroup.setWorkflowStatus(WorkflowStatus.DRAFT);
        portRepository.save(selectedPorts);
        portGroupRepository.save(oldPortGroup);
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(type)
                .deviceId(device.getId())
                .parentObjectId(portGroupId)
                .impactedObjectIds(isCreateNew ? newPortIds : oldPortIds)
                .build());
        return jobId;
    }

    protected abstract void validateAllPortsInPacketSlicing(PortGroup portGroup) throws ValidationException;

    protected abstract void validatePortGroupIfUsedInPolicy(Long portGroupId, boolean isPortChannel) throws ValidationException;

    protected abstract void validatePortsIfUsedInPolicy(List<Long> portIds, boolean isPortChannel) throws ValidationException;

    protected abstract void validatePortsIfUsedInSDPorts(List<Long> portIds) throws ValidationException;

    /**
     * This method is used to validate if the portGroup data is updated as part of update request
     *
     * @param oldPortGroup
     * @param portGroup
     * @param oldPortIds
     * @param newPortIds
     * @return boolean
     */
    private boolean isPortGroupDataChanged(PortGroup oldPortGroup, PortGroup portGroup, List<Long> oldPortIds, List<Long> newPortIds) {
        if (oldPortGroup.getPrimaryPort() != null && !oldPortGroup.getPrimaryPort().getId().equals(portGroup.getPrimaryPort().getId())) {
            return true;
        }
        if (oldPortIds.size() != newPortIds.size() || !newPortIds.containsAll(oldPortIds)) {
            return true;
        }
        if ((oldPortGroup.getGtpProfile() == null && portGroup.getGtpProfileId() != null)) {
            return true;
        }
        if (oldPortGroup.getGtpProfile() != null && portGroup.getGtpProfileId() == null) {
            return true;
        }
        if (oldPortGroup.getGtpProfile() != null && !oldPortGroup.getGtpProfile().getId().equals(portGroup.getGtpProfileId())) {
            return true;
        }
        if (oldPortGroup.getLineSpeed() == null && portGroup.getLineSpeed() != null) {
            return true;
        }
        if (oldPortGroup.isMinimumLinkEnabled() != portGroup.isMinimumLinkEnabled()) {
            return true;
        }
        if (oldPortGroup.getLineSpeed() != null && portGroup.getLineSpeed() != null && oldPortGroup.getLineSpeed().longValue() != portGroup.getLineSpeed().longValue()) {
            return true;
        }
        if (oldPortGroup.isLoopbackEnabled() != portGroup.isLoopbackEnabled()) {
            return true;
        }
        return false;
    }

    /**
     * This method is used to delete/recover port group, on the given device
     *
     * @param portGroup
     * @param portGroupIds
     * @return Long This returns jobId
     */
    @Override
    public Long deletePortGroup(PortGroup portGroup, List<Long> portGroupIds) {
        boolean recovery = false;
        if (portGroup.getWorkflowStatus() == WorkflowStatus.ERROR) {
            recovery = true;
        }
        List<Long> portIdsInDb = portGroup.getPorts().stream().map(Port::getId)
                .collect(Collectors.toList());
        PortGroup portGroupInDb = portGroupRepository.findOne(portGroup.getId());

        if (portGroup.getWorkflowStatus() == WorkflowStatus.DRAFT) {
            updateAssociatedPortStatus(portIdsInDb);
            portGroupRepository.delete(portGroup);
            log.info("PortGroup id {} is in Draft state, so nothing to do on device", portGroup.getId());
            return -1l;
        }

        /* Checking if ports of portGroup are part of any packet slicing policy*/
        validateAllPortsInPacketSlicing(portGroupInDb);

        Long gtpProfileId = portGroup.getGtpProfileId();
        /* Checking if the selected GTP profile id is valid or not*/
        if (gtpProfileId != null) {
            GTPDevicePolicy gtpProfile = gtpDevicePolicyRepository.findOne(gtpProfileId);
            if (gtpProfile != null) {
                portGroupInDb.setGtpProfile(gtpProfile);
            } else {
                throw new ValidationException("portGroup.gtpProfile.invalid");
            }
        }

        if (portIdsInDb != null && !portIdsInDb.isEmpty()) {
            List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(portGroup.getDevice().getId(), portIdsInDb);
            /* Checking if the selected ports are used as INGRESS in any MPLS policy, if yes, delete is not allowed */
            if (!mplsPolicyIds.isEmpty()) {
                throw new ValidationException("ports.exists.inMPLS");
            }
        }
        Device device = portGroup.getDevice();
        boolean isPortChannel = Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode();
        portGroupInDb.setWorkflowStatus(WorkflowStatus.DRAFT);
        portGroupRepository.save(portGroupInDb);

        long jobId;
        if (recovery) {
            jobId = jobQueue.submit(JobTemplate.builder()
                    .type(isPortChannel ? Job.Type.PORT_CHANNEL_RECOVER : Job.Type.PORT_GROUP_RECOVER)
                    .deviceId(device.getId())
                    .parentObjectId(portGroup.getId())
                    .impactedObjectIds(portIdsInDb).build());
        } else {
            jobId = jobQueue.submit(JobTemplate.builder()
                    .type(isPortChannel ? Job.Type.PORT_CHANNEL_DELETE : Job.Type.PORT_GROUP_DELETE)
                    .deviceId(device.getId())
                    .parentObjectId(portGroup.getId())
                    .impactedObjectIds(portIdsInDb).build());
        }
        return jobId;
    }

    /**
     * This method is used to delete/recover port group, on the given device
     *
     * @param portGroup
     * @param portGroupIds
     * @return Long This returns jobId
     */
    @Override
    public Long rollBackPortGroup(PortGroup portGroup, List<Long> portGroupIds) {
        List<Long> portIdsInDb = portGroup.getPorts().stream().map(Port::getId)
                .collect(Collectors.toList());
        PortGroup portGroupInDb = portGroupRepository.findOne(portGroup.getId());

        updateAssociatedPortStatus(portIdsInDb);

        PortGroup portGroupFromHistory = getPortGroupFromHistory(portGroup);
        List<Long> portIdsInHist = new ArrayList<>();
        if (portGroupFromHistory != null) {
            portIdsInHist = portGroupFromHistory.getPorts().stream().map(Port::getId)
                    .collect(Collectors.toList());
            portGroupInDb.setPorts(portGroupFromHistory.getPorts());
            portGroupInDb.setGtpProfile(portGroupFromHistory.getGtpProfile());
            portGroupInDb.setGtpProfileId(portGroupFromHistory.getGtpProfileId());
            portGroupInDb.setLineSpeed(portGroupFromHistory.getLineSpeed());
            portGroupInDb.setPrimaryPort(portRepository.findOne(portGroupFromHistory.getPrimaryPort().getId()));
        }
        boolean isRecovery = (portGroupFromHistory == null || (portIdsInDb.containsAll(portIdsInHist) && portIdsInHist.containsAll(portIdsInDb)));

        if (isRecovery) {
            throw new ValidationException("portGroup.rollback.noPrevActive");
        }

        /* Checking if ports of portGroup are part of any packet slicing policy*/
        validateAllPortsInPacketSlicing(portGroupInDb);

        Long gtpProfileId = portGroup.getGtpProfileId();
        /* Checking if the selected GTP profile id is valid or not*/
        if (gtpProfileId != null) {
            GTPDevicePolicy gtpProfile = gtpDevicePolicyRepository.findOne(gtpProfileId);
            if (gtpProfile != null) {
                portGroupInDb.setGtpProfile(gtpProfile);
            } else {
                throw new ValidationException("portGroup.gtpProfile.invalid");
            }
        }

        if (portIdsInDb != null && !portIdsInDb.isEmpty()) {
            List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(portGroup.getDevice().getId(), portIdsInDb);
            /* Checking if the selected ports are used as INGRESS in any MPLS policy, if yes, delete is not allowed */
            if (!mplsPolicyIds.isEmpty()) {
                throw new ValidationException("ports.exists.inMPLS");
            }
        }

        portGroupInDb.setWorkflowStatus(WorkflowStatus.DRAFT);
        portGroupRepository.save(portGroupInDb);
        Device device = portGroup.getDevice();
        boolean isPortChannel = Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode();
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(isPortChannel ? Job.Type.PORT_CHANNEL_UPDATE : Job.Type.PORT_GROUP_UPDATE)
                .deviceId(device.getId())
                .parentObjectId(portGroup.getId())
                .impactedObjectIds(portIdsInHist).build());

        return jobId;
    }

    /**
     * This method fetches the latest ACTIVE portgroup from history for the current portgroup
     *
     * @param portGroup
     * @return PortGroup returns latest ACTIVE PortGroup
     */
    protected PortGroup getPortGroupFromHistory(PortGroup portGroup) {
        PortGroup portGroupFromHist = null;
        if (portGroup != null && portGroup.getId() != null) {
            // get the previous port-group name from the history.
            List<PortGroupHistory> portGroupHistoryList = portGroupHistoryRepository.findByIdAndWorkflowStatus(portGroup.getId());
            if (!portGroupHistoryList.isEmpty()) {
                PortGroupHistory oldPortGroup = portGroupHistoryList.get(0);
                log.debug("Found a port-group-history entity with oldName{} and lasted PortGroup {}", oldPortGroup.getName(), portGroup.getName());
                portGroupFromHist = oldPortGroup.buildParent();
            }
        }
        return portGroupFromHist;
    }

    /**
     * This method validates if all the selected ports either EGRESS or SERVICEPORT
     *
     * @param portsInDb
     * @throws ValidationException
     */
    private void validatePortsAreOfTypeAllEgressOrAllServicePort(Set<Port> portsInDb) {
        if (portsInDb != null && !portsInDb.isEmpty()) {
            Set<Port.Type> portTypes = portsInDb.stream().map(Port::getType).collect(Collectors.toSet());
            if (portTypes.contains(Port.Type.INGRESS) || portTypes.size() > 1) {
                log.error("All participating ports should be of same type (EGRESS or SERVICE PORT). Aborting!");
                throw new ValidationException("port.type.egressOrService");
            }
        }
    }

    /**
     * This method is used to change port status from Error/Draft to Active state
     * when particular port is getting left out at time of Update/Rollback/Delete
     *
     * @param portIds
     */
    public void updateAssociatedPortStatus(List<Long> portIds) {
        if (portIds != null && !portIds.isEmpty()) {
            Set<Port> impactedPorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
            if (!impactedPorts.isEmpty()) {
                impactedPorts.forEach(mo -> mo.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE));
                portRepository.save(impactedPorts);
            }
        }
    }

    /**
     * Validate the Port Group name
     *
     * @param name
     */
    private void validatePortGroupName(Device device, String name) {
        if (device != null && name != null && name.contains(";")) {
            if (Device.Type.SLX == device.getType() && Mode.PLAIN == device.getMode()) {
                throw new ValidationException("portChannel.id.invalid.character.semicolon");
            } else {
                throw new ValidationException("portGroup.name.invalid.character.semicolon");
            }
        }
    }

    /**
     * Validates the interfaces, is it used in packet truncation or not
     *
     * @param managedObjectIds
     */
    private void validateInterfacesWithPacketTruncation(List<Long> managedObjectIds, Long deviceId) {
        if (!managedObjectIds.isEmpty()) {
            List<String> portNames = packetTruncationMappingRepository.findPortNamesByPortIdAndDeviceId(deviceId, managedObjectIds);
            if (!portNames.isEmpty()) {
                if (portNames.size() == PacketTruncationMapping.SIZE_ONE) {
                    throw new ValidationException(String.format("Cannot create/update the Port Channel. %s is used in a Packet Truncation profile.", portNames.get(0)));
                } else {
                    String portnames = portNames.stream().collect(Collectors.joining(", "));
                    throw new ValidationException(String.format("Cannot create/update the Port Channel. %s are used in a Packet Truncation profile.", portnames));
                }
            }
        }
    }

    /**
     * Validates the interfaces, is type is null or none
     *
     * @param portGroup
     */

    private void validateInterfacesTypeNullOrNone(PortGroup portGroup) {
        Set<String> misMatchTypePorts = Sets.newHashSet();
        portGroup.getPorts().stream().forEach(port -> {
            Port port1 = portRepository.findOne(port.getId());
            if (port1 != null && port1.getType() == null || port1.getType() == Port.Type.NONE) {
                misMatchTypePorts.add(port1.getName());
            }
        });
        if (!misMatchTypePorts.isEmpty()) {
            String portNames = misMatchTypePorts.stream().collect(Collectors.joining(","));
            throw new ValidationException(String.format(typeMismatch, portNames));
        }
    }
}
