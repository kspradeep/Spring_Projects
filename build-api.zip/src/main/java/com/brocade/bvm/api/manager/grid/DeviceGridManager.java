package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.api.manager.GridManager;
import com.brocade.bvm.api.manager.GridPolicyManager;
import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridCluster;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.history.DeviceGridHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.exception.ServerException;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Named
@Slf4j
public class DeviceGridManager implements GridManager {

    private static final String GRID_VIEW = "GridView";
    private static final String PATHS = "Paths";
    private static final String COUNT = "Count";
    private static final String NODES = "nodes";
    private static final String EDGES = "edges";

    @Inject
    private GridRepository gridRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private DeviceGridHistoryRepository deviceGridHistoryRepository;

    @Inject
    private GridPolicyManager deviceGridPolicyManager;

    @Inject
    private GridPolicySetHelper gridPolicySetHelper;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private GenericJobManager genericJobManager;

    /**
     * This method is used to create/update device grid in BVM database
     *
     * @param deviceGrid
     * @return Long This returns policyId
     */
    public Long saveGrid(DeviceGrid deviceGrid) throws ValidationException {
        if (deviceGrid != null) {
            validateGrid(deviceGrid);

            AtomicBoolean isNew = new AtomicBoolean(false);
            if (deviceGrid.getId() == null) {
                isNew.set(true);
            }
            if (isNew.get()) {
                try {
                    log.debug("New Grid to save, name :{}", deviceGrid.getName());
                    deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    gridRepository.save(deviceGrid);
                    markInterfaces(deviceGrid);
                    deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                    gridRepository.save(deviceGrid);
                } catch (Exception e) {
                    log.error("failed to save the grid, name:{} id:{}", deviceGrid.getName(), deviceGrid.getId());
                    deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                    try {
                        gridRepository.save(deviceGrid);
                    } catch (Exception e1) {
                    }
                    throw new ValidationException(e.getMessage());
                }
            } else {
                //adding ingress to aggregator and egress to distributor
                DeviceGrid deviceGridInDb = gridRepository.findOne(deviceGrid.getId());
                if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGridInDb.getWorkflowStatus()) {
                    throw new ValidationException("Cannot commit grid as another operation is in progress. Please try after sometime.");
                }
                if (WorkflowParticipant.WorkflowStatus.ERROR == deviceGridInDb.getWorkflowStatus()) {
                    throw new ValidationException("Cannot commit grid as it is in error state. Please recover the grid and try again.");
                }
                log.debug("Merging the grid, Id :{} name :{}", deviceGrid.getId(), deviceGrid.getName());
                DeviceGrid deviceGridHistory = getDeviceGridFromHistory(deviceGridInDb, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
                if (deviceGridHistory != null) {
                    gridPolicySetHelper.validateUpdatePolicySetFromGrid(deviceGrid, deviceGridHistory);
                }
                try {
                    deviceGridInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                    gridRepository.save(deviceGridInDb);
                    mergeGrid(deviceGridInDb, deviceGrid);
                    if (deviceGridHistory == null) {
                        markInterfaces(deviceGridInDb);
                    } else {
                        markAndUpdateLldpOnGridInterfaces(deviceGridHistory, deviceGridInDb);
                        gridPolicySetHelper.updatePolicySetFromGrid(deviceGridInDb, deviceGridHistory);
                    }
                    deviceGridInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                    gridRepository.save(deviceGridInDb);
                } catch (Exception e) {
                    log.error("Failed to save the grid, name:{} id:{}", deviceGrid.getName(), deviceGrid.getId());
                    deviceGridInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                    try {
                        gridRepository.save(deviceGridInDb);
                    } catch (Exception e1) {
                    }
                    throw new ValidationException(e.getMessage());
                }
            }

            return deviceGrid.getId();
        }
        throw new ValidationException("Grid does not exist.");
    }

    /**
     * This method is used to create/update grid
     *
     * @param deviceGrid
     * @return Long This returns jobId
     */
    public Long commitGrid(DeviceGrid deviceGrid) throws ValidationException {
        if (deviceGrid != null) {
            Long gridId = saveGrid(deviceGrid);
            return gridId;
        }
        throw new ValidationException("Grid does not exist.");
    }

    /**
     * This method is used to delete grid
     *
     * @param deviceGrid
     * @return Long This returns jobId
     */
    @Override
    public Long deleteGrid(DeviceGrid deviceGrid) throws ValidationException {
        if (deviceGrid != null) {
            if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot delete grid as another operation is in progress. Please try after sometime.");
            }
            if (WorkflowParticipant.WorkflowStatus.ERROR == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot delete grid as it is in error state. Please recover the grid and try again.");
            }
            Long gridId = deviceGrid.getId();
            List<String> policyNamesInSubmittedState = gridPolicySetRepository.findNameByGridIdAndWorkflowStatus(gridId, WorkflowParticipant.WorkflowStatus.SUBMITTED);
            if (!policyNamesInSubmittedState.isEmpty()) {
                if (policyNamesInSubmittedState.size() <= 1)
                    throw new ValidationException("Cannot delete grid as another operation is in progress on policy " + policyNamesInSubmittedState.stream().collect(Collectors.joining(", ")) + ". Please try after sometime.");
                else
                    throw new ValidationException("Cannot delete grid as another operation is in progress on policies " + policyNamesInSubmittedState.stream().collect(Collectors.joining(", ")) + ". Please try after sometime.");
            }
            List<String> policyNamesInErrorState = gridPolicySetRepository.findNameByGridIdAndWorkflowStatus(gridId, WorkflowParticipant.WorkflowStatus.ERROR);
            if (!policyNamesInErrorState.isEmpty()) {
                if (policyNamesInErrorState.size() <= 1)
                    throw new ValidationException("Cannot delete grid as policy " + policyNamesInErrorState.stream().collect(Collectors.joining(", ")) + " is in error state. Please recover the policy/policies and try again.");
                else
                    throw new ValidationException("Cannot delete grid as policies " + policyNamesInErrorState.stream().collect(Collectors.joining(", ")) + " is in error state. Please recover the policy/policies and try again.");
            }
            try {
                WorkflowParticipant.WorkflowStatus existingWorkflowStatus = deviceGrid.getWorkflowStatus();
                List<Long> gridPolicySetIds = gridPolicySetRepository.findIdsByGridId(gridId);
                deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                gridRepository.save(deviceGrid);
                if (existingWorkflowStatus != null && existingWorkflowStatus == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                    cleanUpLldpFromGridInterface(deviceGrid);
                }
                if (!gridPolicySetIds.isEmpty()) {
                    gridPolicySetIds.forEach(policySetId -> {
                        deviceGridPolicyManager.deleteGridPolicy(policySetId);
                    });
                    //to clean the draft policies after recovery.
                    gridPolicySetIds = gridPolicySetRepository.findIdsByGridId(gridId);
                    if (!gridPolicySetIds.isEmpty()) {
                        gridPolicySetIds.forEach(policySetId -> {
                            deviceGridPolicyManager.deleteGridPolicy(policySetId);
                        });
                    }
                    deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    gridRepository.save(deviceGrid);
                }
                gridRepository.deleteById(deviceGrid.getId());
                return gridId;
            } catch (Exception e) {
                deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                gridRepository.save(deviceGrid);
                throw new ValidationException(e.getMessage());
            }
        }
        throw new ValidationException("Grid does not exist.");
    }

    /**
     * This method is used to recover grid
     *
     * @param deviceGrid
     * @return Long This returns grid id
     */
    @Override
    public Long rollbackGrid(DeviceGrid deviceGrid) {
        if (deviceGrid != null) {
            if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Cannot recover grid as another operation is in progress. Please try after sometime.");
            }
            if (WorkflowParticipant.WorkflowStatus.ERROR != deviceGrid.getWorkflowStatus()) {
                throw new ValidationException("Invalid action! Recovery cannot be performed as grid is not in error state.");
            }
            Long gridId = deviceGrid.getId();
            List<String> policyNamesInSubmittedState = gridPolicySetRepository.findNameByGridIdAndWorkflowStatus(gridId, WorkflowParticipant.WorkflowStatus.SUBMITTED);
            if (!policyNamesInSubmittedState.isEmpty()) {
                if (policyNamesInSubmittedState.size() <= 1) {
                    throw new ValidationException("Cannot recover grid as another operation is in progress on policy " + policyNamesInSubmittedState.stream().collect(Collectors.joining(", ")) + ". Please try after sometime.");
                } else {
                    throw new ValidationException("Cannot recover grid as another operation is in progress on policies " + policyNamesInSubmittedState.stream().collect(Collectors.joining(", ")) + ". Please try after sometime.");
                }
            }
            List<String> policyNamesInErrorState = gridPolicySetRepository.findNameByGridIdAndWorkflowStatus(gridId, WorkflowParticipant.WorkflowStatus.ERROR);
            if (!policyNamesInErrorState.isEmpty()) {
                if (policyNamesInErrorState.size() <= 1) {
                    throw new ValidationException("Cannot recover grid as policy " + policyNamesInErrorState.stream().collect(Collectors.joining(", ")) + " is in error state. Please recover the policy and try again.");
                } else {
                    throw new ValidationException("Cannot recover grid as policies " + policyNamesInErrorState.stream().collect(Collectors.joining(", ")) + " is in error state. Please recover the policies and try again.");
                }
            }
            try {
                List<Long> gridPolicySetIds = gridPolicySetRepository.findIdsByGridId(gridId);
                if (!gridPolicySetIds.isEmpty()) {
                    deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
                    gridRepository.save(deviceGrid);
                    gridPolicySetIds.forEach(policySetId -> {
                        GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
                        if (WorkflowParticipant.WorkflowStatus.ACTIVE == gridPolicySet.getWorkflowStatus()) {
                            gridPolicySetHelper.deletePolicySet(gridPolicySet, false);
                        } else if (WorkflowParticipant.WorkflowStatus.DRAFT == gridPolicySet.getWorkflowStatus()) {
                            GridPolicySet policyFromHistory = gridPolicySetHelper.getGridPolicySetFromHistory(gridPolicySet, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                            if (WorkflowParticipant.WorkflowStatus.ACTIVE == policyFromHistory.getWorkflowStatus()) {
                                gridPolicySetHelper.deletePolicySet(gridPolicySet, false);
                            }
                        }
                    });
                }
                cleanUpLldpFromGridInterface(deviceGrid);
                cleanupInvalidInterfaceFromGrid(deviceGrid);
                deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                gridRepository.save(deviceGrid);
                return gridId;
            } catch (Exception e) {
                deviceGrid.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                gridRepository.save(deviceGrid);
                throw new ValidationException(e.getMessage());
            }
        }
        throw new ValidationException("Grid does not exist.");
    }

    /**
     * This method is returns the grid topology
     *
     * @param gridId
     * @return
     */
    @Override
    public Map getGridTopology(Long gridId) throws ValidationException {
        DeviceGrid deviceGrid = gridRepository.findOne(gridId);
        if (deviceGrid == null) {
            throw new ValidationException("Grid does not exist.");
        }
        Set<String> destinationChassisSet = Sets.newHashSet();
        Set<String> sourceChassisSet = Sets.newHashSet();
        Map<String, Map<String, Set<String>>> tapSourceMap = Maps.newHashMap();
        Map<String, Map<String, Set<String>>> toolDestinationMap = Maps.newHashMap();

        deviceGrid.getSourceNodes().forEach(gridCluster -> {
            String chassis = gridCluster.getDevice().getChassis();
            sourceChassisSet.add(chassis);
            Map<String, Set<String>> tapInterfaceMap = Maps.newHashMap();
            if (tapSourceMap.containsKey(chassis))
                tapInterfaceMap.putAll(tapSourceMap.get(chassis));
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                tapInterfaceMap.put(clusterNodeInterface.getName(), clusterNodeInterface.getPortsAndPortGroups().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
            });
            tapSourceMap.put(chassis, tapInterfaceMap);
        });
        deviceGrid.getDestinationNodes().forEach(gridCluster -> {
            String chassis = gridCluster.getDevice().getChassis();
            destinationChassisSet.add(chassis);
            Map<String, Set<String>> toolInterfaceMap = Maps.newHashMap();
            if (toolDestinationMap.containsKey(chassis))
                toolInterfaceMap.putAll(toolDestinationMap.get(chassis));
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                toolInterfaceMap.put(clusterNodeInterface.getName(), clusterNodeInterface.getPortsAndPortGroups().stream().map(ManagedObject::getName).collect(Collectors.toSet()));
            });
            toolDestinationMap.put(chassis, toolInterfaceMap);
        });
        Set<String> allChassisSet = Sets.newHashSet(sourceChassisSet);
        allChassisSet.addAll(destinationChassisSet);
        Map<String, Object> topologyMap = gridPolicySetHelper.getTopology(allChassisSet);
//        log.debug("Topology response {}", topologyMap);
        Set<String> pathsInGrid = Sets.newHashSet();
        if (topologyMap != null && topologyMap.containsKey(GRID_VIEW)) {
            Map sourceMap = ((Map) topologyMap.get(GRID_VIEW));
            if (sourceMap != null) {
                sourceMap.forEach((sourceKey, sourceValue) -> {
                    if ((sourceChassisSet.contains(sourceKey)) && sourceValue != null) {
                        Map destinationMap = ((Map) sourceValue);
                        destinationMap.forEach((destinationKey, destinationValue) -> {
                            if (destinationValue != null) {
                                Map paths = ((Map) destinationValue);
                                paths.forEach((pathKey, pathValue) -> {
                                    if (PATHS.equals(pathKey) && pathValue != null) {
                                        List<String> pathList = (List) pathValue;
                                        pathList.forEach(path -> {
                                            if (!Strings.isNullOrEmpty(path)) {
                                                pathsInGrid.add(path);
                                            }
                                        });
                                    } else if (COUNT.equals(pathKey)) {
                                        log.debug("Topology network path count between {} and {} is {}", sourceKey, destinationKey, pathValue);
                                    }
                                });
                            }
                        });
                    }
                });
            }
        }

        AtomicInteger sequence = new AtomicInteger(0);
        Map<String, DeviceInfo> deviceInfoMap = Maps.newHashMap();
        Set<EdgeInfo> edgeInfoSets = Sets.newHashSet();
        pathsInGrid.forEach(path ->
                parsePathResponse(tapSourceMap, toolDestinationMap, deviceInfoMap, edgeInfoSets, path, sequence)
        );

        Set nodes = Sets.newHashSet();
        deviceInfoMap.forEach((chassis, deviceInfo) -> {
            nodes.add(deviceInfo);
            allChassisSet.remove(chassis);
        });
        if (!allChassisSet.isEmpty()) {
            allChassisSet.forEach(chassis -> {
                Object deviceArray = deviceRepository.findByChassisAndIsNotDeleted(chassis);
                if (deviceArray != null) {
                    DeviceInfo deviceInfo = createDeviceInfo(String.valueOf(((Object[]) deviceArray)[1]), chassis, sequence.getAndIncrement(), null);
                    deviceInfo.setDeviceId(Long.parseLong(((Object[]) deviceArray)[0].toString()));
                    deviceInfo.setStatus(((Object[]) deviceArray)[2]);
                    if (tapSourceMap.containsKey(chassis)) {
                        deviceInfo.setType(DeviceInfo.TYPE.AGGREGATOR);
                        Map<String, Set<String>> tapInterfaceMap = tapSourceMap.get(chassis);
                        Set<String> ingressSet = Sets.newHashSet();
                        if (tapInterfaceMap != null) {
                            tapInterfaceMap.forEach((s, set) -> {
                                ingressSet.addAll(set);
                            });
                        }
                        deviceInfo.setIngressSet(ingressSet);

                        if (tapInterfaceMap != null) {
                            tapInterfaceMap.forEach((interfaceName, managedObject) -> {
                                DeviceInfo srcTapInfo = deviceInfoMap.get(interfaceName);
                                if (srcTapInfo == null) {
                                    srcTapInfo = createDeviceInfo(interfaceName, null, sequence.getAndIncrement(), DeviceInfo.TYPE.TAP);
                                    deviceInfoMap.put(interfaceName, srcTapInfo);
                                    nodes.add(srcTapInfo);
                                }
                                EdgeInfo edgeInfo = createEdgeInfo(managedObject.stream().collect(Collectors.joining(",")), null, srcTapInfo.getId(), deviceInfo.getId());
                                edgeInfoSets.add(edgeInfo);
                            });
                        }
                    } else if (toolDestinationMap.containsKey(chassis)) {
                        deviceInfo.setType(DeviceInfo.TYPE.DISTRIBUTOR);
                        Map<String, Set<String>> toolInterfaceMap = toolDestinationMap.get(chassis);
                        Set<String> egressSet = Sets.newHashSet();
                        if (toolInterfaceMap != null) {
                            toolInterfaceMap.forEach((s, set) -> {
                                egressSet.addAll(set);
                            });
                        }
                        deviceInfo.setEgressSet(egressSet);

                        if (toolInterfaceMap != null) {
                            toolInterfaceMap.forEach((interfaceName, managedObject) -> {
                                DeviceInfo destToolInfo = deviceInfoMap.get(interfaceName);
                                if (destToolInfo == null) {
                                    destToolInfo = createDeviceInfo(interfaceName, null, sequence.getAndIncrement(), DeviceInfo.TYPE.TOOL);
                                    deviceInfoMap.put(interfaceName, destToolInfo);
                                    nodes.add(destToolInfo);
                                }
                                EdgeInfo edgeInfoTool = createEdgeInfo(null, managedObject.stream().collect(Collectors.joining(",")), deviceInfo.getId(), destToolInfo.getId());
                                edgeInfoSets.add(edgeInfoTool);
                            });
                        }
                    }
                    nodes.add(deviceInfo);
                }
            });
        }

        Map topology = Maps.newHashMap();
        topology.put(NODES, nodes);
        topology.put(EDGES, edgeInfoSets);
        return topology;
    }

    private Map<String, DeviceInfo> parsePathResponse(Map<String, Map<String, Set<String>>> tapSourceMap, Map<String, Map<String, Set<String>>> toolDestinationMap,
                                                      Map<String, DeviceInfo> deviceInfoMap, Set<EdgeInfo> edgeInfoSets, String path, AtomicInteger sequence) {
        if (!Strings.isNullOrEmpty(path)) {
            Pattern pattern = Pattern.compile("^->([0-9a-f\\.]+->[A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)->(([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->[0-9a-f\\.]+->[A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->)+)*([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+->[0-9a-f\\.]+)$");
            Matcher matcher = pattern.matcher(path);
            if (matcher.matches()) {
                String firstGroup = matcher.group(1);
                String secondGroup = matcher.group(2);
                String thirdGroup = matcher.group(4);
                if (!Strings.isNullOrEmpty(firstGroup) && !Strings.isNullOrEmpty(thirdGroup)) {
                    List<String> firstGroupList = Lists.newArrayList(firstGroup.split("->"));
                    List<String> thirdGroupList = Lists.newArrayList(thirdGroup.split("->"));
                    AtomicInteger fromSequence = new AtomicInteger();
                    AtomicInteger toSequence = new AtomicInteger();

                    String srcDeviceChassis = firstGroupList.get(0);
                    String destDeviceChassis = thirdGroupList.get(1);
                    String ingress;
                    String egress = firstGroupList.get(1);
                    if ((tapSourceMap.containsKey(srcDeviceChassis) && toolDestinationMap.containsKey(destDeviceChassis)) ||
                            (toolDestinationMap.containsKey(srcDeviceChassis) && toolDestinationMap.containsKey(destDeviceChassis))) {
                        Map<String, Set<String>> tapInterfaceMap = tapSourceMap.get(srcDeviceChassis);
                        DeviceInfo srcDeviceInfo = deviceInfoMap.get(srcDeviceChassis);
                        if (srcDeviceInfo == null) {
                            srcDeviceInfo = createDeviceInfo(null, srcDeviceChassis, sequence.getAndIncrement(), null);
                            if (tapSourceMap.containsKey(srcDeviceChassis)) {
                                srcDeviceInfo.setType(DeviceInfo.TYPE.AGGREGATOR);
                            } else if (toolDestinationMap.containsKey(srcDeviceChassis)) {
                                srcDeviceInfo.setType(DeviceInfo.TYPE.DISTRIBUTOR);
                            }
                            Set<String> ingressSet = Sets.newHashSet();
                            if (tapInterfaceMap != null) {
                                tapInterfaceMap.forEach((s, set) -> {
                                    ingressSet.addAll(set);
                                });
                            }
                            srcDeviceInfo.setIngressSet(ingressSet);
                            Object srcDeviceArray = deviceRepository.findByChassisAndIsNotDeleted(srcDeviceChassis);
                            if (srcDeviceArray != null) {
                                srcDeviceInfo.setDeviceId(Long.parseLong(((Object[]) srcDeviceArray)[0].toString()));
                                srcDeviceInfo.setName(String.valueOf(((Object[]) srcDeviceArray)[1]));
                                srcDeviceInfo.setStatus(((Object[]) srcDeviceArray)[2]);
                            }
                        }
                        fromSequence.set(srcDeviceInfo.getId());
                        if (egress != null) {
                            srcDeviceInfo.addEgress(egress);
                        }

                        if (tapInterfaceMap != null) {
                            tapInterfaceMap.forEach((interfaceName, managedObject) -> {
                                DeviceInfo srcTapInfo = deviceInfoMap.get(interfaceName);
                                if (srcTapInfo == null) {
                                    srcTapInfo = createDeviceInfo(interfaceName, null, sequence.getAndIncrement(), DeviceInfo.TYPE.TAP);
                                    deviceInfoMap.put(interfaceName, srcTapInfo);
                                }

                                Integer fromSeqTap = srcTapInfo.getId();
                                Integer toSeqTap = fromSequence.get();
                                String ingressTap = managedObject.stream().collect(Collectors.joining(","));
                                if (edgeInfoSets.stream().noneMatch(edgeInfo -> edgeInfo.getIngress() != null
                                        && edgeInfo.getEgress() == null && edgeInfo.getIngress().equals(ingressTap) && edgeInfo.getFrom() == fromSeqTap && edgeInfo.getTo() == toSeqTap)) {
                                    EdgeInfo edgeInfo = createEdgeInfo(ingressTap, null, fromSeqTap, toSeqTap);
                                    edgeInfoSets.add(edgeInfo);
                                }
                            });
                        }

                        deviceInfoMap.put(srcDeviceChassis, srcDeviceInfo);
                        if (!Strings.isNullOrEmpty(secondGroup)) {
                            Pattern internalNetworkInfoPattern = Pattern.compile("(([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)->([0-9a-f\\.]+)->([A-Z\\-a-z\\s]+\\s*[\\d+\\/:]+)+)+");
                            Matcher internalNetworkInfoMatcher = internalNetworkInfoPattern.matcher(secondGroup);
                            while (internalNetworkInfoMatcher.find()) {
                                String intermediateDeviceChassis = internalNetworkInfoMatcher.group(3);
                                DeviceInfo intermediateDeviceInfo = deviceInfoMap.get(intermediateDeviceChassis);
                                if (intermediateDeviceInfo == null) {
                                    intermediateDeviceInfo = createDeviceInfo(null, intermediateDeviceChassis, sequence.getAndIncrement(), null);
                                    if (tapSourceMap.containsKey(intermediateDeviceChassis)) {
                                        intermediateDeviceInfo.setType(DeviceInfo.TYPE.AGGREGATOR);
                                    } else if (toolDestinationMap.containsKey(intermediateDeviceChassis)) {
                                        intermediateDeviceInfo.setType(DeviceInfo.TYPE.DISTRIBUTOR);
                                    } else {
                                        intermediateDeviceInfo.setType(DeviceInfo.TYPE.INTERMEDIATE);
                                    }
                                    Object intermediateDeviceArray = deviceRepository.findByChassisAndIsNotDeleted(intermediateDeviceChassis);
                                    if (intermediateDeviceArray != null) {
                                        intermediateDeviceInfo.setDeviceId(Long.parseLong(((Object[]) intermediateDeviceArray)[0].toString()));
                                        intermediateDeviceInfo.setName(String.valueOf(((Object[]) intermediateDeviceArray)[1]));
                                        intermediateDeviceInfo.setStatus(((Object[]) intermediateDeviceArray)[2]);
                                    }
                                }
                                toSequence.set(intermediateDeviceInfo.getId());
                                ingress = internalNetworkInfoMatcher.group(2);

                                String edgeIntermediateIngress = egress;
                                String edgeIntermediateEgress = ingress;
                                Integer fromSeqIntermediate = fromSequence.getAndIncrement();
                                Integer toSeqIntermediate = toSequence.get();
                                if (edgeInfoSets.stream().noneMatch(edgeInfo -> edgeInfo.getIngress() != null && edgeInfo.getEgress() != null
                                        && ((edgeInfo.getIngress().equals(edgeIntermediateEgress) && edgeInfo.getEgress().equals(edgeIntermediateIngress) && edgeInfo.getFrom() == fromSeqIntermediate && edgeInfo.getTo() == toSeqIntermediate)
                                        || (edgeInfo.getIngress().equals(edgeIntermediateIngress) && edgeInfo.getEgress().equals(edgeIntermediateEgress) && edgeInfo.getFrom() == toSeqIntermediate && edgeInfo.getTo() == fromSeqIntermediate))
                                )) {
                                    EdgeInfo edgeInfo = createEdgeInfo(ingress, egress, fromSeqIntermediate, toSeqIntermediate);
                                    edgeInfoSets.add(edgeInfo);
                                }

                                fromSequence.set(intermediateDeviceInfo.getId());
                                egress = internalNetworkInfoMatcher.group(4);

                                if (ingress != null) {
                                    intermediateDeviceInfo.addIngress(ingress);
                                }
                                if (egress != null) {
                                    intermediateDeviceInfo.addEgress(egress);
                                }
                                deviceInfoMap.put(intermediateDeviceChassis, intermediateDeviceInfo);
                            }
                        }

                        Map<String, Set<String>> toolInterfaceMap = toolDestinationMap.get(destDeviceChassis);
                        DeviceInfo destDeviceInfo = deviceInfoMap.get(destDeviceChassis);
                        if (destDeviceInfo == null) {
                            destDeviceInfo = createDeviceInfo(null, destDeviceChassis, sequence.getAndIncrement(), null);
                            if (tapSourceMap.containsKey(destDeviceChassis)) {
                                destDeviceInfo.setType(DeviceInfo.TYPE.AGGREGATOR);
                            } else if (toolDestinationMap.containsKey(destDeviceChassis)) {
                                destDeviceInfo.setType(DeviceInfo.TYPE.DISTRIBUTOR);
                            }
                            Set<String> egressSet = Sets.newHashSet();
                            if (toolInterfaceMap != null) {
                                toolInterfaceMap.forEach((s, set) -> {
                                    egressSet.addAll(set);
                                });
                            }
                            destDeviceInfo.setEgressSet(egressSet);
                            Object intermediateDeviceArray = deviceRepository.findByChassisAndIsNotDeleted(destDeviceChassis);
                            if (intermediateDeviceArray != null) {
                                destDeviceInfo.setDeviceId(Long.parseLong(((Object[]) intermediateDeviceArray)[0].toString()));
                                destDeviceInfo.setName(String.valueOf(((Object[]) intermediateDeviceArray)[1]));
                                destDeviceInfo.setStatus(((Object[]) intermediateDeviceArray)[2]);
                            }
                        }
                        toSequence.set(destDeviceInfo.getId());
                        ingress = thirdGroupList.get(0);

                        String edgeDestinationIngress = ingress;
                        String edgeDestinationEgress = egress;
                        Integer fromSeqDestination = fromSequence.get();
                        Integer toSeqDestination = toSequence.get();
                        if (edgeInfoSets.stream().noneMatch(edgeInfo -> edgeInfo.getIngress() != null && edgeInfo.getEgress() != null
                                && ((edgeInfo.getIngress().equals(edgeDestinationIngress) && edgeInfo.getEgress().equals(edgeDestinationEgress) && edgeInfo.getFrom() == fromSeqDestination && edgeInfo.getTo() == toSeqDestination)
                                || (edgeInfo.getIngress().equals(edgeDestinationEgress) && edgeInfo.getEgress().equals(edgeDestinationIngress) && edgeInfo.getFrom() == toSeqDestination && edgeInfo.getTo() == fromSeqDestination))
                        )) {
                            EdgeInfo edgeInfo = createEdgeInfo(ingress, egress, fromSeqDestination, toSeqDestination);
                            edgeInfoSets.add(edgeInfo);
                        }
                        if (ingress != null) {
                            destDeviceInfo.addIngress(ingress);
                        }
                        deviceInfoMap.put(destDeviceChassis, destDeviceInfo);
                        if (toolInterfaceMap != null) {
                            toolInterfaceMap.forEach((interfaceName, managedObject) -> {
                                DeviceInfo destToolInfo = deviceInfoMap.get(interfaceName);
                                if (destToolInfo == null) {
                                    destToolInfo = createDeviceInfo(interfaceName, null, sequence.getAndIncrement(), DeviceInfo.TYPE.TOOL);
                                    deviceInfoMap.put(interfaceName, destToolInfo);
                                }

                                Integer fromSeqTool = toSequence.get();
                                Integer toSeqTool = destToolInfo.getId();
                                String egressTool = managedObject.stream().collect(Collectors.joining(","));
                                if (edgeInfoSets.stream().noneMatch(edgeInfo -> edgeInfo.getEgress() != null
                                        && edgeInfo.getIngress() == null && edgeInfo.getEgress().equals(egressTool) && edgeInfo.getFrom() == fromSeqTool && edgeInfo.getTo() == toSeqTool)) {
                                    EdgeInfo edgeInfoTool = createEdgeInfo(null, egressTool, fromSeqTool, toSeqTool);
                                    edgeInfoSets.add(edgeInfoTool);
                                }
                            });
                        }
                    }
                }
            }
        }
        return deviceInfoMap;
    }

    /**
     * Create and return the DeviceInfo object.
     *
     * @param name
     * @param chassis
     * @param sequence
     * @param type
     * @return
     */
    private DeviceInfo createDeviceInfo(String name, String chassis, int sequence, DeviceInfo.TYPE type) {
        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.setId(sequence);
        deviceInfo.setType(type);
        deviceInfo.setName(name);
        deviceInfo.setChassis(chassis);
        return deviceInfo;
    }

    /**
     * Create and return the EdgeInfo object.
     *
     * @param ingress
     * @param egress
     * @param fromSequence
     * @param toSequence
     * @return
     */
    private EdgeInfo createEdgeInfo(String ingress, String egress, int fromSequence, int toSequence) {
        EdgeInfo edgeInfo = new EdgeInfo();
        edgeInfo.setIngress(ingress);
        edgeInfo.setEgress(egress);
        edgeInfo.setFrom(fromSequence);
        edgeInfo.setTo(toSequence);
        return edgeInfo;
    }

    /**
     * Merges the updated grid object into existing grid object retrieved from DB
     *
     * @param existingGrid
     * @param updatedGrid
     * @return
     */
    public DeviceGrid mergeGrid(DeviceGrid existingGrid, DeviceGrid updatedGrid) {
        existingGrid.setName(updatedGrid.getName());
        existingGrid.setDescription(updatedGrid.getDescription());

        Set<GridCluster> deletedSourceNodes = Sets.newHashSet();
        existingGrid.getSourceNodes().forEach(gridClusterExisting -> {
            Set<GridCluster> updatedGridClusters = updatedGrid.getSourceNodes().stream().filter(gridCluster -> gridClusterExisting.getId().equals(gridCluster.getId())).collect(Collectors.toSet());
            if (updatedGridClusters.size() > 0) {
                GridCluster updatedGridCluster = updatedGridClusters.stream().findFirst().get();
                updateNetworkNode(gridClusterExisting, updatedGridCluster);
            } else {
                deletedSourceNodes.add(gridClusterExisting);
            }
        });
        existingGrid.removeSourceNodes(deletedSourceNodes);

        Set<GridCluster> sourceNodesToAdd = updatedGrid.getSourceNodes().stream().filter(gridCluster -> gridCluster.getId() == null).collect(Collectors.toSet());
        existingGrid.addSourceNodes(sourceNodesToAdd);

        Set<GridCluster> deletedDestinationNodes = Sets.newHashSet();
        existingGrid.getDestinationNodes().forEach(gridClusterExisting -> {
            Set<GridCluster> updatedGridClusters = updatedGrid.getDestinationNodes().stream().filter(gridCluster -> gridClusterExisting.getId().equals(gridCluster.getId())).collect(Collectors.toSet());
            if (updatedGridClusters.size() > 0) {
                GridCluster updatedGridCluster = updatedGridClusters.stream().findFirst().get();
                updateNetworkNode(gridClusterExisting, updatedGridCluster);
            } else {
                deletedDestinationNodes.add(gridClusterExisting);
            }
        });
        existingGrid.removeDestinationNodes(deletedDestinationNodes);

        Set<GridCluster> destinationNodesToAdd = updatedGrid.getDestinationNodes().stream().filter(gridCluster -> gridCluster.getId() == null).collect(Collectors.toSet());
        existingGrid.addDestinationNodes(destinationNodesToAdd);

        return existingGrid;
    }

    /**
     * Merges the updated GridCluster object into existing GridCluster object.
     *
     * @param gridClusterExisting
     * @param updatedGridCluster
     */
    private void updateNetworkNode(GridCluster gridClusterExisting, GridCluster updatedGridCluster) {
        if (gridClusterExisting.getDevice().getId() == updatedGridCluster.getDevice().getId()) {
            gridClusterExisting.setDevice(updatedGridCluster.getDevice());
            Set<ClusterNodeInterface> clusterNodeInterfacesToDelete = Sets.newHashSet();
            gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterfaceExisting -> {
                Optional<ClusterNodeInterface> searchResult = updatedGridCluster.getClusterNodeInterfaces().stream().filter(clusterNodeInterface -> clusterNodeInterface.getId() == clusterNodeInterfaceExisting.getId()).findFirst();
                if (searchResult.isPresent()) {
                    ClusterNodeInterface networkInterfaceUpdated = searchResult.get();
                    clusterNodeInterfaceExisting.setName(networkInterfaceUpdated.getName());

                    Set<Port> networkNodeMergedPorts = (Set<Port>) mergeAndReturnUpdatedSet(clusterNodeInterfaceExisting.getPorts(), networkInterfaceUpdated.getPorts());
                    Set<Long> networkNodeMergedPortIds = networkNodeMergedPorts.stream().map(Port::getId).collect(Collectors.toSet());
                    Set<Long> networkNodePortsAdded = findNewObjectId(clusterNodeInterfaceExisting.getPorts(), networkInterfaceUpdated.getPorts());
                    networkNodePortsAdded.addAll(networkNodeMergedPortIds);

                    Set<PortGroup> ingressSourceNodeMergedPortGroups = (Set<PortGroup>) mergeAndReturnUpdatedSet(clusterNodeInterfaceExisting.getPortGroups(), networkInterfaceUpdated.getPortGroups());
                    Set<Long> networkNodeMergedPortGroupIds = ingressSourceNodeMergedPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());
                    Set<Long> networkNodePortGroupsAdded = findNewObjectId(clusterNodeInterfaceExisting.getPortGroups(), networkInterfaceUpdated.getPortGroups());
                    networkNodePortGroupsAdded.addAll(networkNodeMergedPortGroupIds);

                    clusterNodeInterfaceExisting.removePorts(clusterNodeInterfaceExisting.getPorts());
                    clusterNodeInterfaceExisting.removePortGroups(clusterNodeInterfaceExisting.getPortGroups());

                    List<Port> ingressSourceNodePortsFromDB = (List<Port>) portRepository.findAll(networkNodePortsAdded);
                    List<PortGroup> ingressSourceNodePortGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(networkNodePortGroupsAdded);
                    clusterNodeInterfaceExisting.addPorts(Sets.newHashSet(ingressSourceNodePortsFromDB));
                    clusterNodeInterfaceExisting.addPortGroups(Sets.newHashSet(ingressSourceNodePortGroupsFromDB));
                } else {
                    clusterNodeInterfacesToDelete.add(clusterNodeInterfaceExisting);
                }
            });
            gridClusterExisting.removeClusterNodeInterfaces(clusterNodeInterfacesToDelete);

            Set<ClusterNodeInterface> clusterNodeInterfacesToAdd = updatedGridCluster.getClusterNodeInterfaces().stream().filter(clusterNodeInterface -> clusterNodeInterface.getId() == null).collect(Collectors.toSet());
            gridClusterExisting.addClusterNodeInterfaces(clusterNodeInterfacesToAdd);
        } else {
            //TODO merge the data when the device ids are different
        }
    }


    /**
     * This method is used find the new port(s)/portGroup(s) to be updated in the policy on the device
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<Long> findNewObjectId(Set<? extends ManagedObject> existingSet,
                                      Set<? extends ManagedObject> updatedSet) {
        Set<Long> toAdd = new HashSet<>();
        for (ManagedObject eachUpdate : updatedSet) {
            if (!existingSet.stream().anyMatch(po -> po.getId().longValue() == eachUpdate.getId().longValue())) {
                toAdd.add(eachUpdate.getId());
            }
        }
        return toAdd;
    }


    /**
     * This method is used to copy all the updated data to existing object
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<? extends DomainObject> mergeAndReturnUpdatedSet(Set<? extends DomainObject> existingSet,
                                                                 Set<? extends DomainObject> updatedSet) {
        Set<DomainObject> toRetain = new HashSet<>();

        if (existingSet instanceof SortedSet) {
            toRetain = new TreeSet<>();
        }
        for (DomainObject eachExisting : existingSet) {
            // port does not exist - remove the port in the existing port list
            Optional<? extends DomainObject> searchResult = updatedSet.stream()
                    .filter(po -> (po.getId() != null && po.getId().equals(eachExisting.getId()))).findFirst();
            if (searchResult.isPresent()) {
                //merge properties
                DomainObject eachUpdated = searchResult.get();
                toRetain.add(eachUpdated);
            }
        }
        return toRetain;
    }

    /**
     * Mark the non marking ports of a grid to respective type and save.
     *
     * @param deviceGrid
     */
    private void markInterfaces(DeviceGrid deviceGrid) {
        List<Long> jobIds = Lists.newArrayList();
        deviceGrid.getSourceNodes().forEach(gridCluster -> {
            Set<Port> ingressPortsOfDevice = Sets.newHashSet();
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> nonePorts = clusterNodeInterface.getPorts().stream().filter(port -> port.getType() == null || Port.Type.NONE == port.getType()).collect(Collectors.toSet());
                if (!nonePorts.isEmpty()) {
                    nonePorts = Sets.newHashSet(portRepository.findAll(nonePorts.stream().map(Port::getId).collect(Collectors.toList())));
                    nonePorts.forEach(port -> {
                        port.setType(Port.Type.INGRESS);
                        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    });
                    portRepository.save(nonePorts);
                    ingressPortsOfDevice.addAll(nonePorts);
                }
                Set<Port> ingressPorts = clusterNodeInterface.getPorts().stream().filter(port -> Port.Type.INGRESS == port.getType()).collect(Collectors.toSet());
                if (!ingressPorts.isEmpty()) {
                    ingressPorts = Sets.newHashSet(portRepository.findAll(ingressPorts.stream().map(Port::getId).collect(Collectors.toList())));
                    ingressPortsOfDevice.addAll(ingressPorts);
                }
                Set<Port> ports = Sets.newHashSet(portRepository.findAll(clusterNodeInterface.getPorts().stream().map(Port::getId).collect(Collectors.toList())));
                Set<PortGroup> portGroups = Sets.newHashSet(portGroupRepository.findAll(clusterNodeInterface.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList())));
                clusterNodeInterface.clearPortsAndPortGroups();
                clusterNodeInterface.setPorts(ports);
                clusterNodeInterface.setPortGroups(portGroups);
            });
            if (!ingressPortsOfDevice.isEmpty()) {
                Long jobId = executeJob(Lists.newArrayList(ingressPortsOfDevice.stream().map(ManagedObject::getId).collect(Collectors.toList())), Job.Type.PORT_MARK_INGRESS_GRID, gridCluster.getDevice().getId());
                if (jobId != null && jobId > -1) {
                    jobIds.add(jobId);
                }
            }
        });
        deviceGrid.getDestinationNodes().forEach(gridCluster -> {
            Set<Port> egreeePortsOfDevice = Sets.newHashSet();
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> nonePorts = clusterNodeInterface.getPorts().stream().filter(port -> port.getType() == null || Port.Type.NONE == port.getType()).collect(Collectors.toSet());
                if (!nonePorts.isEmpty()) {
                    nonePorts = Sets.newHashSet(portRepository.findAll(nonePorts.stream().map(Port::getId).collect(Collectors.toList())));
                    nonePorts.forEach(port -> {
                        port.setType(Port.Type.EGRESS);
                        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    });
                    portRepository.save(nonePorts);
                    egreeePortsOfDevice.addAll(nonePorts);
                }
                Set<Port> egressPorts = clusterNodeInterface.getPorts().stream().filter(port -> Port.Type.EGRESS == port.getType()).collect(Collectors.toSet());
                if (!egressPorts.isEmpty()) {
                    egressPorts = Sets.newHashSet(portRepository.findAll(egressPorts.stream().map(Port::getId).collect(Collectors.toList())));
                    egreeePortsOfDevice.addAll(egressPorts);
                }
                Set<Port> ports = Sets.newHashSet(portRepository.findAll(clusterNodeInterface.getPorts().stream().map(Port::getId).collect(Collectors.toList())));
                Set<PortGroup> portGroups = Sets.newHashSet(portGroupRepository.findAll(clusterNodeInterface.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList())));
                clusterNodeInterface.clearPortsAndPortGroups();
                clusterNodeInterface.setPorts(ports);
                clusterNodeInterface.setPortGroups(portGroups);
            });
            if (!egreeePortsOfDevice.isEmpty()) {
                Long jobId = executeJob(Lists.newArrayList(egreeePortsOfDevice.stream().map(ManagedObject::getId).collect(Collectors.toList())), Job.Type.PORT_MARK_EGRESS_GRID, gridCluster.getDevice().getId());
                if (jobId != null && jobId > -1) {
                    jobIds.add(jobId);
                }
            }
        });
        jobIds.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                throw new ServerException(internalPolicyJob.getJobResult());
            }
        });
    }

    /**
     * Enable the LLDP protocol on ports which are removed from grid (aggregator and distributor)
     *
     * @param existingGrid
     * @param updatedGrid
     */
    private void markAndUpdateLldpOnGridInterfaces(DeviceGrid existingGrid, DeviceGrid updatedGrid) {
        if (existingGrid != null && updatedGrid != null) {
            List<Long> jobIds = Lists.newArrayList();
            updatedGrid.getSourceNodes().forEach(gridClusterUpdated -> {
                Set<Long> portsToAdd = Sets.newHashSet();
                Optional<GridCluster> existingGridClusterOptional = existingGrid.getSourceNodes().stream().filter(gridClusterExisting -> gridClusterUpdated.getId() != null && gridClusterUpdated.getId().equals(gridClusterExisting.getId())).findFirst();
                if (existingGridClusterOptional.isPresent()) {
                    GridCluster gridClusterExisting = existingGridClusterOptional.get();
                    Set<Long> portsExisting = Sets.newHashSet();
                    Set<Long> portsUpdated = Sets.newHashSet();
                    gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsUpdated.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsExisting.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    Sets.SetView<Long> idsToRemoved = Sets.difference(portsExisting, portsUpdated);
                    if (!idsToRemoved.isEmpty()) {
                        Long jobId = executeJob(Lists.newArrayList(idsToRemoved), Job.Type.PORT_MARK_NONE_GRID, gridClusterExisting.getDevice().getId());
                        if (jobId != null && jobId > -1) {
                            jobIds.add(jobId);
                        }
                    }
                    Sets.SetView<Long> idsToAdd = Sets.difference(portsUpdated, portsExisting);
                    if (!idsToAdd.isEmpty()) {
                        portsToAdd.addAll(idsToAdd);
                    }
                } else {
                    gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsToAdd.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                }
                if (!portsToAdd.isEmpty()) {
                    Set<Port> nonePorts = Sets.newHashSet(portRepository.findAll(portsToAdd)).stream().filter(port -> port.getType() == null || Port.Type.NONE == port.getType()).collect(Collectors.toSet());
                    if (!nonePorts.isEmpty()) {
                        nonePorts.forEach(port -> {
                            port.setType(Port.Type.INGRESS);
                            port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        });
                        portRepository.save(nonePorts);
                    }
                    Long jobId = executeJob(Lists.newArrayList(portsToAdd), Job.Type.PORT_MARK_INGRESS_GRID, gridClusterUpdated.getDevice().getId());
                    if (jobId != null && jobId > -1) {
                        jobIds.add(jobId);
                    }
                }
                gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                    Set<Port> ports = Sets.newHashSet(portRepository.findAll(clusterNodeInterface.getPorts().stream().map(Port::getId).collect(Collectors.toList())));
                    Set<PortGroup> portGroups = Sets.newHashSet(portGroupRepository.findAll(clusterNodeInterface.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList())));
                    clusterNodeInterface.clearPortsAndPortGroups();
                    clusterNodeInterface.setPorts(ports);
                    clusterNodeInterface.setPortGroups(portGroups);
                });
            });
            existingGrid.getSourceNodes().forEach(gridClusterExisting -> {
                if (updatedGrid.getSourceNodes().stream().noneMatch(gridCluster -> gridClusterExisting.getId() != null && gridClusterExisting.getId().equals(gridCluster.getId()))) {
                    Set<Long> idsToRemoved = Sets.newHashSet();
                    gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        idsToRemoved.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    if (!idsToRemoved.isEmpty()) {
                        Long jobId = executeJob(Lists.newArrayList(idsToRemoved), Job.Type.PORT_MARK_NONE_GRID, gridClusterExisting.getDevice().getId());
                        if (jobId != null && jobId > -1) {
                            jobIds.add(jobId);
                        }
                    }
                }
            });

            /*************************************************************************************************************************************/

            updatedGrid.getDestinationNodes().forEach(gridClusterUpdated -> {
                Set<Long> portsToAdd = Sets.newHashSet();
                Optional<GridCluster> existingGridClusterOptional = existingGrid.getDestinationNodes().stream().filter(gridClusterExisting -> gridClusterUpdated.getId() != null && gridClusterUpdated.getId().equals(gridClusterExisting.getId())).findFirst();
                if (existingGridClusterOptional.isPresent()) {
                    GridCluster gridClusterExisting = existingGridClusterOptional.get();
                    Set<Long> portsExisting = Sets.newHashSet();
                    Set<Long> portsUpdated = Sets.newHashSet();
                    gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsUpdated.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsExisting.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    Sets.SetView<Long> idsToRemoved = Sets.difference(portsExisting, portsUpdated);
                    if (!idsToRemoved.isEmpty()) {
                        Long jobId = executeJob(Lists.newArrayList(idsToRemoved), Job.Type.PORT_MARK_NONE_GRID, gridClusterExisting.getDevice().getId());
                        if (jobId != null && jobId > -1) {
                            jobIds.add(jobId);
                        }
                    }
                    Sets.SetView<Long> idsToAdd = Sets.difference(portsUpdated, portsExisting);
                    if (!idsToAdd.isEmpty()) {
                        portsToAdd.addAll(idsToAdd);
                    }
                } else {
                    gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        portsToAdd.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                }
                if (!portsToAdd.isEmpty()) {
                    Set<Port> nonePorts = Sets.newHashSet(portRepository.findAll(portsToAdd)).stream().filter(port -> port.getType() == null || Port.Type.NONE == port.getType()).collect(Collectors.toSet());
                    if (!nonePorts.isEmpty()) {
                        nonePorts.forEach(port -> {
                            port.setType(Port.Type.EGRESS);
                            port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        });
                        portRepository.save(nonePorts);
                    }
                    Long jobId = executeJob(Lists.newArrayList(portsToAdd), Job.Type.PORT_MARK_EGRESS_GRID, gridClusterUpdated.getDevice().getId());
                    if (jobId != null && jobId > -1) {
                        jobIds.add(jobId);
                    }
                }
                gridClusterUpdated.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                    Set<Port> ports = Sets.newHashSet(portRepository.findAll(clusterNodeInterface.getPorts().stream().map(Port::getId).collect(Collectors.toList())));
                    Set<PortGroup> portGroups = Sets.newHashSet(portGroupRepository.findAll(clusterNodeInterface.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList())));
                    clusterNodeInterface.clearPortsAndPortGroups();
                    clusterNodeInterface.setPorts(ports);
                    clusterNodeInterface.setPortGroups(portGroups);
                });
            });
            existingGrid.getDestinationNodes().forEach(gridClusterExisting -> {
                if (updatedGrid.getDestinationNodes().stream().noneMatch(gridCluster -> gridClusterExisting.getId() != null && gridClusterExisting.getId().equals(gridCluster.getId()))) {
                    Set<Long> idsToRemoved = Sets.newHashSet();
                    gridClusterExisting.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                        idsToRemoved.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                    });
                    if (!idsToRemoved.isEmpty()) {
                        Long jobId = executeJob(Lists.newArrayList(idsToRemoved), Job.Type.PORT_MARK_NONE_GRID, gridClusterExisting.getDevice().getId());
                        if (jobId != null && jobId > -1) {
                            jobIds.add(jobId);
                        }
                    }
                }
            });

            jobIds.forEach(aLong -> {
                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(internalPolicyJob.getJobResult());
                }
            });
        }
    }

    /**
     * Enable LLDP on grid interfaces while deleting the grid.
     *
     * @param deviceGrid
     */
    private void cleanUpLldpFromGridInterface(DeviceGrid deviceGrid) {
        if (deviceGrid != null) {
            List<Long> jobIds = Lists.newArrayList();
            deviceGrid.getSourceNodes().forEach(gridCluster -> {
                List<Long> portsIds = Lists.newArrayList();
                gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                    portsIds.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                });
                if (!portsIds.isEmpty()) {
                    Long jobId = executeJob(Lists.newArrayList(portsIds), Job.Type.PORT_MARK_NONE_GRID, gridCluster.getDevice().getId());
                    if (jobId != null && jobId > -1) {
                        jobIds.add(jobId);
                    }
                }
            });
            deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                List<Long> portsIds = Lists.newArrayList();
                gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                    portsIds.addAll(clusterNodeInterface.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                });
                if (!portsIds.isEmpty()) {
                    Long jobId = executeJob(Lists.newArrayList(portsIds), Job.Type.PORT_MARK_NONE_GRID, gridCluster.getDevice().getId());
                    if (jobId != null && jobId > -1) {
                        jobIds.add(jobId);
                    }
                }
            });
            jobIds.forEach(aLong -> {
                Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
                if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(internalPolicyJob.getJobResult());
                }
            });
        }
    }

    /**
     * @param impactedObjectIds
     * @param jobType
     * @param devideId
     * @return
     */
    private Long executeJob(List<Long> impactedObjectIds, Job.Type jobType, Long devideId) {
        Long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(devideId)
                .impactedObjectIds(impactedObjectIds)
                .build());
        return jobId;
    }

    /**
     * Removes the error ports and port groups from tool and tap interfaces of a grid
     *
     * @param deviceGrid
     */
    private void cleanupInvalidInterfaceFromGrid(DeviceGrid deviceGrid) {
        deviceGrid.getSourceNodes().forEach(gridCluster -> {
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> errorPorts = clusterNodeInterface.getPorts().stream().filter(port -> WorkflowParticipant.WorkflowStatus.ERROR == port.getWorkflowStatus()).collect(Collectors.toSet());
                Set<PortGroup> errorPortGroups = clusterNodeInterface.getPortGroups().stream().filter(portGroup -> WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()).collect(Collectors.toSet());
                clusterNodeInterface.removePorts(errorPorts);
                clusterNodeInterface.removePortGroups(errorPortGroups);
            });
        });
        deviceGrid.getDestinationNodes().forEach(gridCluster -> {
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> errorPorts = clusterNodeInterface.getPorts().stream().filter(port -> WorkflowParticipant.WorkflowStatus.ERROR == port.getWorkflowStatus()).collect(Collectors.toSet());
                Set<PortGroup> errorPortGroups = clusterNodeInterface.getPortGroups().stream().filter(portGroup -> WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()).collect(Collectors.toSet());
                clusterNodeInterface.removePorts(errorPorts);
                clusterNodeInterface.removePortGroups(errorPortGroups);
            });
        });
    }

    /**
     * validates the grid object
     *
     * @param deviceGrid
     */
    private void validateGrid(DeviceGrid deviceGrid) {
        if (deviceGrid.getName() == null) {
            throw new ValidationException("Grid name cannot be empty.");
        }
        if (deviceGrid.getName().length() > 250) {
            throw new ValidationException("Grid name cannot exceed 250 characters.");
        }
        if (deviceGrid.getDescription() != null && deviceGrid.getDescription().length() > 250) {
            throw new ValidationException("Grid description cannot exceed 250 characters.");
        }
        if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGrid.getWorkflowStatus()) {
            throw new ValidationException("Cannot commit as another operation is in progress. Please try after sometime.");
        }
        if (deviceGrid.getId() == null && gridRepository.findByName(deviceGrid.getName()) != null) {
            throw new ValidationException("Grid name already exists.");
        }
        if (deviceGrid.getSourceNodes().isEmpty()) {
            throw new ValidationException("Aggregator configuration is missing.");
        }
        if (deviceGrid.getDestinationNodes().isEmpty()) {
            throw new ValidationException("Distributor configuration is missing.");
        }
        deviceGrid.getSourceNodes().forEach(gridCluster -> {
            Device device = gridCluster.getDevice();
            if (device == null || device.getId() == null) {
                throw new ValidationException("Device configuration for the aggregator is missing.");
            }
            if (deviceRepository.findIdByIdAndIsDeleted(device.getId(), true) != null) {
                String message = "Aggregator device " + (device.getName() != null ? device.getName() : "") + " has been deleted from the inventory.";
                throw new ValidationException(message);
            }
            if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(device.getId()) == null) {
                String message = "Aggregator device " + (device.getName() != null ? device.getName() : "") + " is missing from inventory.";
                throw new ValidationException(message);
            }
            if (gridCluster.getClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Interface configuration for the aggregator is missing.");
            }
            if (gridCluster.getId() == null) {
                List<BigInteger> clusterIds = gridClusterRepository.findIdAllByDeviceId(device.getId());
                if (!clusterIds.isEmpty()) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    if (deviceGrid.getId() != null) {
                        clusterIds.forEach(object -> {
                            if (deviceGrid.getId() != object.longValue()) {
                                throw new ValidationException("Aggregator device " + deviceName + " is already used in a grid.");
                            }
                        });
                    } else {
                        throw new ValidationException("Aggregator device " + deviceName + " is already used in a grid.");
                    }
                }
            } else {
                List<Object[]> clusterIds = gridClusterRepository.findIdsByDeviceIdAndNotClusterId(device.getId(), gridCluster.getId());
                if (!clusterIds.isEmpty()) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    throw new ValidationException("Aggregator device " + deviceName + " is already used in a grid.");
                }
            }
            if (!deviceGrid.getDestinationNodes().isEmpty()) {
                if (deviceGrid.getDestinationNodes().stream().anyMatch(gridClusterDist -> gridClusterDist.getDevice() != null && gridClusterDist.getDevice().getId() == device.getId())) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    throw new ValidationException("Device " + deviceName + " cannot be configured as both aggregator and distributor.");
                }
            }
            Set<String> interfaceNames = Sets.newHashSet();
            Set<String> portsWithNoLineSpeed = Sets.newHashSet();
            StringBuilder portInPortGroupValidationMessage = new StringBuilder();
            StringBuilder interfaceInPolicyValidationMessage = new StringBuilder();
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> ports = clusterNodeInterface.getPorts();
                Set<PortGroup> portGroups = clusterNodeInterface.getPortGroups();
                if (Strings.isNullOrEmpty(clusterNodeInterface.getName())) {
                    throw new ValidationException("Tap name cannot be empty.");
                }
                if (clusterNodeInterface.getPortsAndPortGroups().isEmpty()) {
                    throw new ValidationException("Tap interface(s) cannot be empty.");
                }
                if (ports.stream().anyMatch(port -> Port.Type.EGRESS == port.getType() || Port.Type.SERVICE_PORT == port.getType())) {
                    throw new ValidationException("Tap ports should be of type Ingress/None.");
                }
                portGroups.forEach(portGroup -> {
                    PortGroup portGroupObj = portGroupRepository.findOne(portGroup.getId());
                    if (portGroupObj != null) {
                        Optional<Port> portOptional = portGroupObj.getPorts().stream().findAny();
                        if (portOptional.isPresent()) {
                            Port port = portRepository.findOne(portOptional.get().getId());
                            if (port != null && port.getType() != Port.Type.INGRESS) {
                                throw new ValidationException("Tap port-channels should be of type Ingress.");
                            }
                        }
                    }
                });
                if (interfaceNames.contains(clusterNodeInterface.getName())) {
                    throw new ValidationException("Duplicate tap name " + clusterNodeInterface.getName() + ". Please use a different tap name.");
                }
                interfaceNames.add(clusterNodeInterface.getName());
                ports.forEach(port -> {
                    Long lineSpeed = portRepository.findLineSpeedById(port.getId());
                    if (lineSpeed == null || lineSpeed == 0L) {
                        portsWithNoLineSpeed.add(port.getName());
                    }
                    if (WorkflowParticipant.WorkflowStatus.SUBMITTED == port.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tap port " + port.getName() + " as port configuration is in progress. Please try after sometime.");
                    } else if (WorkflowParticipant.WorkflowStatus.ERROR == port.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tap port " + port.getName() + " as port is in error state. Please recover the port and try again.");
                    }
                });
                portGroups.forEach(portGroup -> {
                    if (WorkflowParticipant.WorkflowStatus.SUBMITTED == portGroup.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tap port-channel " + portGroup.getName() + " as port-channel configuration is in progress. Please try after sometime.");
                    } else if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tap port-channel " + portGroup.getName() + " as port-channel is in error state. Please recover the port-channel and try again.");
                    }
                });

                Set<Long> portIds = ports.stream().map(Port::getId).collect(Collectors.toSet());
                Set<Long> portChannelIds = portGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());
                if (clusterNodeInterface.getId() != null) {
                    ClusterNodeInterface clusterNodeInterfaceInDB = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
                    if (clusterNodeInterfaceInDB != null) {
                        Set<Long> portIdsFromOldCluster = clusterNodeInterfaceInDB.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
                        Set<Long> portChannelIdsFromOldCluster = clusterNodeInterfaceInDB.getPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet());
                        if (portIdsFromOldCluster != null) {
                            portIds = Sets.difference(portIds, portIdsFromOldCluster);
                        }
                        if (portChannelIdsFromOldCluster != null) {
                            portChannelIds = Sets.difference(portChannelIds, portChannelIdsFromOldCluster);
                        }
                    }
                }
                if (!portIds.isEmpty()) {
                    List<Object[]> portChannelIdsForPorts = portGroupRepository.findPortGroupIdsByPortIds(Lists.newArrayList(portIds));
                    if (!portChannelIdsForPorts.isEmpty()) {
                        portChannelIdsForPorts.forEach(objects -> {
                            Long portGroupId = Long.valueOf(objects[0].toString());
                            Long portId = Long.valueOf(objects[1].toString());
                            String portName = portRepository.findNameById(portId);
                            PortGroup portGroup = portGroupRepository.findOne(portGroupId);
                            if (portInPortGroupValidationMessage.length() > 0) {
                                portInPortGroupValidationMessage.append(", ");
                            }
                            portInPortGroupValidationMessage.append(portName).append(" [").append(portGroup.getDevice().getName() + " / Port channel " + portGroup.getName()).append("]");
                        });
                    }
                    List<Object[]> policyInfoLists = flowRepository.findNonGridPolicyInfoInIngressPortMappingById(Lists.newArrayList(portIds));
                    if (!policyInfoLists.isEmpty()) {
                        policyInfoLists.forEach(objects -> {
                            Long policyId = Long.valueOf(objects[0].toString());
                            Long portId = Long.valueOf(objects[1].toString());
                            Long deviceId = Long.valueOf(objects[2].toString());
                            String portName = portRepository.findNameById(portId);
                            String policyName = policyRepository.findNameById(policyId);
                            String deviceName = deviceRepository.findNameById(deviceId);
                            if (interfaceInPolicyValidationMessage.length() > 0) {
                                interfaceInPolicyValidationMessage.append(", ");
                            }
                            interfaceInPolicyValidationMessage.append(portName).append(" [").append(deviceName + " / " + policyName).append("]");
                        });
                    }
                }
                if (!portChannelIds.isEmpty()) {
                    List<Object[]> policyInfoLists = flowRepository.findNonGridPolicyInfoInIngressPortMappingById(Lists.newArrayList(portChannelIds));
                    if (!policyInfoLists.isEmpty()) {
                        policyInfoLists.forEach(objects -> {
                            Long policyId = Long.valueOf(objects[0].toString());
                            Long portGroupId = Long.valueOf(objects[1].toString());
                            Long deviceId = Long.valueOf(objects[2].toString());
                            String portGroupName = portGroupRepository.findNameById(portGroupId);
                            String policyName = policyRepository.findNameById(policyId);
                            String deviceName = deviceRepository.findNameById(deviceId);
                            if (interfaceInPolicyValidationMessage.length() > 0) {
                                interfaceInPolicyValidationMessage.append(", ");
                            }
                            interfaceInPolicyValidationMessage.append("Port channel " + portGroupName).append(" [").append(deviceName + " / " + policyName).append("]");
                        });
                    }
                }
            });
            if (portInPortGroupValidationMessage.length() > 0) {
                log.error("Cannot commit grid as port(s) is in use in port channel. {}", portInPortGroupValidationMessage);
                throw new ValidationException("Cannot commit grid as port(s) is in use in port channel. " + portInPortGroupValidationMessage);
            }
            if (interfaceInPolicyValidationMessage.length() > 0) {
                log.error("Port/port channel already in use in another Policy {}", interfaceInPolicyValidationMessage);
                throw new ValidationException("Cannot perform grid operation. Port/port channel is already in use in another policy. " + interfaceInPolicyValidationMessage);
            }
            if (!portsWithNoLineSpeed.isEmpty()) {
                if (portsWithNoLineSpeed.size() == 1)
                    throw new ValidationException("The line speed of ingress port " + portsWithNoLineSpeed.stream().collect(Collectors.joining(", ")) + " is currently set to zero. Please set the correct line speed and try again.");
                else
                    throw new ValidationException("The line speed of ingress ports " + portsWithNoLineSpeed.stream().collect(Collectors.joining(", ")) + " are currently set to zero. Please set the correct line speed and try again.");
            }
        });
        deviceGrid.getDestinationNodes().forEach(gridCluster -> {
            Device device = gridCluster.getDevice();
            if (device == null || device.getId() == null) {
                throw new ValidationException("Device configuration for the distributor is missing.");
            }
            if (deviceRepository.findIdByIdAndIsDeleted(device.getId(), true) != null) {
                String message = "Distributor device " + (device.getName() != null ? device.getName() : "") + " has been deleted from the inventory.";
                throw new ValidationException(message);
            }
            if (deviceRepository.findIdByIdAndIsDeletedAndIsProfileConfigured(device.getId()) == null) {
                String message = "Distributor device " + (device.getName() != null ? device.getName() : "") + " is missing from inventory.";
                throw new ValidationException(message);
            }
            if (gridCluster.getClusterNodeInterfaces().isEmpty()) {
                throw new ValidationException("Interface configuration for the distributor is missing.");
            }
            if (gridCluster.getId() == null) {
                List<BigInteger> clusterIds = gridClusterRepository.findIdAllByDeviceId(device.getId());
                if (!clusterIds.isEmpty()) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    if (deviceGrid.getId() != null) {
                        clusterIds.forEach(object -> {
                            if (deviceGrid.getId() != object.longValue()) {
                                throw new ValidationException("Distributor device " + deviceName + " is already used in a grid.");
                            }
                        });
                    } else {
                        throw new ValidationException("Distributor device " + deviceName + " is already used in a grid.");
                    }
                }
            } else {
                List<Object[]> clusterIds = gridClusterRepository.findIdsByDeviceIdAndNotClusterId(device.getId(), gridCluster.getId());
                if (!clusterIds.isEmpty()) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    throw new ValidationException("Distributor device " + deviceName + " is already used in a grid.");
                }
            }
            if (!deviceGrid.getSourceNodes().isEmpty()) {
                if (deviceGrid.getSourceNodes().stream().anyMatch(gridClusterAgg -> gridClusterAgg.getDevice() != null && gridClusterAgg.getDevice().getId() == device.getId())) {
                    String deviceName = deviceRepository.findNameById(device.getId());
                    throw new ValidationException("Device " + deviceName + " cannot be configured as both aggregator and distributor.");
                }
            }
            Set<String> interfaceNames = Sets.newHashSet();
            StringBuilder portInPortGroupValidationMessage = new StringBuilder();
            gridCluster.getClusterNodeInterfaces().forEach(clusterNodeInterface -> {
                Set<Port> ports = clusterNodeInterface.getPorts();
                Set<PortGroup> portGroups = clusterNodeInterface.getPortGroups();
                if (Strings.isNullOrEmpty(clusterNodeInterface.getName())) {
                    throw new ValidationException("Tool name cannot be empty.");
                }
                if (clusterNodeInterface.getPortsAndPortGroups().isEmpty()) {
                    throw new ValidationException("Tool interface(s) cannot be empty.");
                }
                if (ports.stream().anyMatch(port -> port.getType() == Port.Type.INGRESS || port.getType() == Port.Type.SERVICE_PORT)) {
                    throw new ValidationException("Tool ports should be of type Egress/None.");
                }
                portGroups.forEach(portGroup -> {
                    PortGroup portGroupObj = portGroupRepository.findOne(portGroup.getId());
                    if (portGroupObj != null) {
                        Optional<Port> portOptional = portGroupObj.getPorts().stream().findAny();
                        if (portOptional.isPresent()) {
                            Port port = portRepository.findOne(portOptional.get().getId());
                            if (port != null && port.getType() != Port.Type.EGRESS) {
                                throw new ValidationException("Tool port-channels should be of type Egress.");
                            }
                        }
                    }
                });
                if (clusterNodeInterface.getPortsAndPortGroups().size() > 1) {
                    throw new ValidationException("Tool interface cannot have more than one port/port group.");
                }
                if (interfaceNames.contains(clusterNodeInterface.getName())) {
                    throw new ValidationException("Duplicate tool name " + clusterNodeInterface.getName() + ". Please use a different tool name.");
                }
                ports.forEach(port -> {
                            if (WorkflowParticipant.WorkflowStatus.SUBMITTED == port.getWorkflowStatus()) {
                                throw new ValidationException("Cannot use tool port " + port.getName() + " as port configuration is in progress. Please try after sometime.");
                            } else if (WorkflowParticipant.WorkflowStatus.ERROR == port.getWorkflowStatus()) {
                                throw new ValidationException("Cannot use tool port " + port.getName() + " as port is in error state. Please recover the port and try again.");
                            }
                        }
                );
                portGroups.forEach(portGroup -> {
                    if (WorkflowParticipant.WorkflowStatus.SUBMITTED == portGroup.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tool port-channel " + portGroup.getName() + " as port-channel configuration is in progress. Please try after sometime.");
                    } else if (WorkflowParticipant.WorkflowStatus.ERROR == portGroup.getWorkflowStatus()) {
                        throw new ValidationException("Cannot use tool port-channel " + portGroup.getName() + " as port-channel is in error state. Please recover the port-channel and try again.");
                    }
                });
                Set<Port> servicePorts = ports.stream().filter(port -> Port.Type.SERVICE_PORT == port.getType()).collect(Collectors.toSet());
                if (!servicePorts.isEmpty()) {
                    List<Long> portIdsInPT = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(device.getId(), servicePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()));
                    if (!portIdsInPT.isEmpty()) {
                        String portsInUse = portRepository.findNamesByIds(portIdsInPT).stream().collect(Collectors.joining(", "));
                        if (portIdsInPT.size() == 1) {
                            throw new ValidationException(String.format("Cannot commit grid as port %s is in use in a Packet Truncation profile.", portsInUse));
                        } else {
                            throw new ValidationException(String.format("Cannot commit grid as port(s) %s are in use in a Packet Truncation profile.", portsInUse));
                        }
                    }
                }
                Set<PortGroup> servicePortGroups = portGroups.stream().filter(portGroup -> Port.Type.SERVICE_PORT == portGroup.getType()).collect(Collectors.toSet());
                if (!servicePortGroups.isEmpty()) {
                    List<Long> portGroupIdsInPT = packetTruncationMappingRepository.findPortGroupsByDeviceIdAndPortGroupIds(device.getId(), servicePortGroups.stream().map(ManagedObject::getId).collect(Collectors.toList()));
                    if (!portGroupIdsInPT.isEmpty()) {
                        String portChannelsInUse = portGroupRepository.findNamesByIds(portGroupIdsInPT).stream().collect(Collectors.joining(", "));
                        if (portGroupIdsInPT.size() == 1) {
                            throw new ValidationException(String.format("Cannot commit grid as port-channel %s is in use in a Packet Truncation profile.", portChannelsInUse));
                        } else {
                            throw new ValidationException(String.format("Cannot commit grid as port-channel(s) %s are in use in a Packet Truncation profile.", portChannelsInUse));
                        }
                    }
                }
                interfaceNames.add(clusterNodeInterface.getName());
                Set<Long> portIds = ports.stream().map(Port::getId).collect(Collectors.toSet());
                if (clusterNodeInterface.getId() != null) {
                    ClusterNodeInterface clusterNodeInterfaceInDB = clusterNodeInterfaceRepository.findOne(clusterNodeInterface.getId());
                    Set<Long> portIdsFromOldCluster = clusterNodeInterfaceInDB.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
                    if (portIdsFromOldCluster != null) {
                        portIds = Sets.difference(portIds, portIdsFromOldCluster);
                    }
                }
                if (!portIds.isEmpty()) {
                    List<Object[]> portChannelIdsForPorts = portGroupRepository.findPortGroupIdsByPortIds(Lists.newArrayList(portIds));
                    if (!portChannelIdsForPorts.isEmpty()) {
                        portChannelIdsForPorts.forEach(objects -> {
                            Long portGroupId = Long.valueOf(objects[0].toString());
                            Long portId = Long.valueOf(objects[1].toString());
                            String portName = portRepository.findNameById(portId);
                            String portGroupName = portGroupRepository.findNameById(portGroupId);

                            if (portInPortGroupValidationMessage.length() > 0) {
                                portInPortGroupValidationMessage.append(", ");
                            }
                            portInPortGroupValidationMessage.append(portName).append("(").append(portGroupName).append(")");
                        });
                    }
                }
            });
            if (portInPortGroupValidationMessage.length() > 0) {
                log.error("Cannot commit grid as port(s) is in use in port group. {}", portInPortGroupValidationMessage);
                throw new ValidationException("Cannot commit grid as port(s) is in use in port group. " + portInPortGroupValidationMessage);
            }
        });
    }

    /**
     * This method fetches the latest Device Grid from history using the current device grid id and it's workflow statuses for delete/recovery validations.
     *
     * @param deviceGrid
     * @param statuses
     * @return Policy returns latest ACTIVE or ERROR device grid
     */
    protected DeviceGrid getDeviceGridFromHistory(DeviceGrid deviceGrid, List<WorkflowParticipant.WorkflowStatus> statuses) {
        DeviceGrid deviceGridFromHistory = null;
        if (deviceGrid != null && deviceGrid.getId() != null && statuses != null && !statuses.isEmpty()) {
            List<DeviceGridHistory> deviceGridHistoryList = deviceGridHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(deviceGrid.getId(), statuses);
            if (!deviceGridHistoryList.isEmpty()) {
                DeviceGridHistory oldDeviceGrid = deviceGridHistoryList.get(0);
                if (HistoryObject.RevisionType.DELETED != oldDeviceGrid.getRevisionType()) {
                    log.debug("Found a grid policy history with old name {} and latest name {}", oldDeviceGrid.getName(), deviceGrid.getName());
                    deviceGridFromHistory = oldDeviceGrid.buildParent();
                }
            }
        }
        return deviceGridFromHistory;
    }

    @Data
    static class DeviceInfo {
        private Integer id;
        private Long deviceId;
        private String name;
        private String chassis;
        private TYPE type;
        private Object status;
        private Set<String> ingressSet = Sets.newHashSet();
        private Set<String> egressSet = Sets.newHashSet();

        public void addIngress(String port) {
            ingressSet.add(port);
        }

        public void addEgress(String port) {
            egressSet.add(port);
        }

        public enum TYPE {
            AGGREGATOR, INTERMEDIATE, DISTRIBUTOR, TOOL, TAP
        }
    }

    @Data
    @JsonPropertyOrder({"name", "from", "to", "ingress", "egress"})
    class EdgeInfo {
        private String name;
        private Integer from;
        private Integer to;
        private String ingress;
        private String egress;
    }
}
