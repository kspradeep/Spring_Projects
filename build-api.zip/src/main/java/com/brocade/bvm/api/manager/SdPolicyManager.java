package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.SdPolicy;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface SdPolicyManager {
    /**
     * return saved/updated SdPolicy
     */
    Long saveOrCommitPolicies(Set<? extends SdPolicy> policies, Device device, String action, String policyName);

    Map<String, Set<SdPolicy>> getPolicies(Set<? extends SdPolicy> policies);

    Long deletePolicy(List<? extends SdPolicy> policies);

    Long recoverPolicy(Long policyId);

    void validatePolicies(Set<? extends SdPolicy> policies, Device device, String policyName, boolean isUpdate);
}
