package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.google.common.collect.Sets;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
public class GridPolicySetDiff {

    private Set<ClusterNodeInterface> clusterNodeSourcesAdded = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeSourcesDeleted = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeSourcesUpdated = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeSourcesUnchanged = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeDestinationsAdded = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeDestinationsDeleted = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeDestinationsUpdated = Sets.newHashSet();

    private Set<ClusterNodeInterface> clusterNodeDestinationsUnchanged = Sets.newHashSet();

    private Set<GridTopologyPath> topologyPathsAdded = Sets.newHashSet();

    private Set<GridTopologyPath> topologyPathsDeleted = Sets.newHashSet();

    private Set<GridTopologyPath> topologyPathsUpdated = Sets.newHashSet();

}
