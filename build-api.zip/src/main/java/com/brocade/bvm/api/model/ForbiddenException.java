package com.brocade.bvm.api.model;

import com.brocade.bvm.model.exception.UserVisibileException;

public class ForbiddenException extends UserVisibileException {
	
    public ForbiddenException(String messageId) {
        super(messageId);
    }
}
