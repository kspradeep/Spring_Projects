package com.brocade.bvm.api.controller;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.LoggedInUser;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@RestController
public class ApplicationConfigController {

    @Inject
    private LoggedInUser loggedInUser;

    @Inject
    private ConfigRepository configRepository;

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/app/config", method = RequestMethod.PUT, consumes = "application/json")
    public ResponseEntity<Object> updateConfig(@RequestBody Map<String, String> map) {
        List<ApplicationConfig> applicationConfigs = Lists.newArrayList();
        map.keySet().stream()
                .forEach(keyName -> {
                    Optional<ApplicationConfig.Key> key = ApplicationConfig.Key.findByName(keyName);
                    ApplicationConfig applicationConfig = null;
                    //StablenetRestUrl and OdlRestUrl cannot be updated
                    if (key.isPresent() && key.get() != ApplicationConfig.Key.StablenetRestUrl && key.get() != ApplicationConfig.Key.OdlRestUrl) {
                        applicationConfig = configRepository.findByKey(key.get());
                        if (applicationConfig == null) {
                            applicationConfig = new ApplicationConfig(key.get(), map.get(keyName));
                        } else {
                            applicationConfig.setValue(map.get(keyName));
                        }
                        applicationConfigs.add(applicationConfig);
                    }
                });
        configRepository.save(applicationConfigs);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
