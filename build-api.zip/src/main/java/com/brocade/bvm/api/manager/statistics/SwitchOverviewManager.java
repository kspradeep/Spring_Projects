package com.brocade.bvm.api.manager.statistics;

import com.brocade.bvm.model.db.statistics.PortBandwidth;
import com.brocade.bvm.model.db.statistics.PortPackets;
import org.springframework.scheduling.annotation.Async;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface SwitchOverviewManager {
    CompletableFuture<List<String>> findTopFiveSwitches();

    @Async
    CompletableFuture<List<String>> findBottomFiveSwitches();

    Set<String> findTopFiveTapPorts();
    Set<String> findBottomFiveTapPorts();
    Set<String> findTopFiveToolPorts();
    Set<String> findBottomFiveToolPorts();

    List<PortPackets> findSwitchPackets(Long switchId, int samples);
    List<PortBandwidth> findDeviceUtilization(Long deviceId, int samples);
    String getAuditDetails();
}
