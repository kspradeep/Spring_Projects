package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import com.brocade.bvm.model.db.sessiondirector.PhysicalInterface;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * This class manages MLXe/SLX policies and SD egress port parameters
 */

@Getter
@Setter
public class SdPortPolicyParameter {

    //MLXe/SLX paired device
    Device targetDevice;

    //MLXe/SLX ports and related SDEgressPort if exist
    List<SdPortParameter> sdPortParameters;

    //SD Ingress ports
    List<IngressPort> ingressPorts;

    //SD physical interfaces
    List<PhysicalInterface> physicalInterfaceList;

    //MLXe/SLX policy
    Policy policyOne;
    Policy policyTwo;
}
