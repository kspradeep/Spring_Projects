package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractDevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The MPLSDevicePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover MPLSDevicePolicy for NonOpenFlow
 */
@Named
public class MPLSDevicePolicyManagerNonOpenFlow extends AbstractDevicePolicyManager {

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private MPLSDevicePolicyRepository mplsDevicePolicyRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * This method checks if MPLSDevicePolicy data is valid to commit on the given device
     *
     * @param policy
     * @return boolean
     */
    @Override
    protected boolean isValidPolicy(DevicePolicy policy) {
        if (policy != null) {
            Device device = deviceRepository.findOne(policy.getDevice().getId());
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("mpls.header.stripping.not.supported.device");
            }
            MPLSDevicePolicy mplsDevicePolicy = (MPLSDevicePolicy) policy;
            if (mplsDevicePolicy.getDevice().getId() == null) {
                return false;
            }
            Set<MPLSPair> mplsPairs = mplsDevicePolicy.getMPLSPairs();
            if (mplsPairs.isEmpty()) {
                return false;
            } else {
                for (MPLSPair mplsPair : mplsPairs) {
                    if (mplsPair.getIngressPort() == null || mplsPair.getEgressPort() == null) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * This method is used to create MPLSDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long commitPolicy(DevicePolicy policy) {
        MPLSDevicePolicy mplsDevicePolicy = (MPLSDevicePolicy) policy;
        isValidPolicy(mplsDevicePolicy);

        List<Long> impactedObjects = Lists.newArrayList();
        final Long deviceId = mplsDevicePolicy.getDevice().getId();
        mplsDevicePolicy.getMPLSPairs().forEach(mplsPair -> {
            List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByDeviceIdAndIngressPort(deviceId, mplsPair.getIngressPort().getId());
            if (!mplsPolicyIds.isEmpty()) {
                throw new ValidationException("mplsDevicePolicy.exists.ingressPort");
            }

            mplsPair.setIngressPort(portRepository.findOne(mplsPair.getIngressPort().getId()));
            mplsPair.setEgressPort(portRepository.findOne(mplsPair.getEgressPort().getId()));

            isEgressInPortGroup(deviceId, mplsPair.getEgressPort());

            impactedObjects.add(mplsPair.getIngressPort().getId());
            impactedObjects.add(mplsPair.getEgressPort().getId());
        });
        isValidPolicyToCommit(deviceId, mplsDevicePolicy.getMPLSPairs());

        mplsDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        mplsDevicePolicy = devicePolicyRepository.save(mplsDevicePolicy);
        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.HEADER_STRIPPING_MPLS_POP_CREATE)
                .deviceId(mplsDevicePolicy.getDevice().getId()).impactedObjectIds(impactedObjects)
                .parentObjectId(mplsDevicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method checks if selected egress port is part of PortGroup and port is a secondary port
     *
     * @param deviceId
     * @param egressPort
     * @throws ValidationException
     */
    private void isEgressInPortGroup(Long deviceId, Port egressPort) {
        List<PortGroup> portGroups = portGroupRepository.findByDeviceIdAndEgress(deviceId, egressPort.getId());
        if (!portGroups.isEmpty() && portGroups.get(0).getPrimaryPort().getId() != egressPort.getId()) {
            throw new ValidationException("mplsDevicePolicy.portGroup.secondaryPortNotAllowed");
        }
    }

    /**
     * This method validates if the selected ingress & egress combination is valid
     * <p>
     * PPCR is computed with no.of.ports/2, first part belongs to PPCR 1, second part belongs to PPCR 2
     * Ex: Ports 1/1 to 1/20, 1/1 to 1/10 belongs to PPCR 1, 1/11 to 1/20 belongs to PPCR 2
     * <p>
     * Ingress Ports belonging to same PPCR, should have common end point(egress port)
     * Ex: Ingress 1/1, 1/2 & Egress 1/11 - is valid combination
     * Ex: Ingress 1/1, 1/2 & Egress 1/11, 1/12 - is invalid combination
     *
     * @param deviceId
     * @param mplsPairs
     */
    private void isValidPolicyToCommit(Long deviceId, Set<MPLSPair> mplsPairs) {
        List<Long> mplsPairIds = mplsPairs.stream().map(MPLSPair::getId).collect(Collectors.toList());
        mplsPairs.forEach(mplsPair -> {
            if (mplsPair.getIngressPort().getType() != Port.Type.INGRESS) {
                throw new ValidationException("mplsDevicePolicy.port.ingressError");
            }
            if (mplsPair.getEgressPort().getType() == Port.Type.INGRESS) {
                throw new ValidationException("mplsDevicePolicy.data.egressError");
            }

            // Finding the mpls pair with selected egress
            List<MPLSPair> mplsPairList = mplsDevicePolicyRepository.findByDeviceIdAndEgressPort(deviceId, mplsPair.getEgressPort().getId());
            if (mplsPairList.isEmpty()) {
                // Finding the mpls pair with selected egress module id & ppcr
                List<MPLSPair> mplsPairEgressList = mplsDevicePolicyRepository.findByEgressPortModuleAndPPCR(deviceId, mplsPair.getEgressPort().getModule().getId(), mplsPair.getEgressPort().getPpcr());
                if (mplsPairEgressList.isEmpty()) {
                    // Finding the mpls pair with selected ingress module id & ppcr
                    List<MPLSPair> mplsPairIngressList = mplsDevicePolicyRepository.findByIngressPortModuleAndPPCR(deviceId, mplsPair.getIngressPort().getModule().getId(), mplsPair.getIngressPort().getPpcr());
                    if (!mplsPairIngressList.isEmpty()) {
                        mplsPairIngressList.forEach(mplsPair1 -> {
                            // This is for update scenario, ignoring the current MPLS pair which is being edited. If MPLS pair with ingress from same ppcr as other policy and with end point as some other egress
                            if (!mplsPairIds.contains(mplsPair1.getId())) {
                                throw new ValidationException("mplsDevicePolicy.ingressEgress.invalidPPCRCombination");
                            }
                        });
                    }
                } else {
                    List<Long> mplsEgressIdList = mplsPairEgressList.stream().map(MPLSPair::getId).collect(Collectors.toList());
                    // Added this check to ignore the current MPLS pair which is being edited.
                    if (!mplsEgressIdList.containsAll(mplsPairIds)) {
                        mplsPairEgressList.forEach(mplsPair1 -> {
                            // Ingress ports of same ppcr should have same end point(egress)
                            if (((mplsPair1.getIngressPort().getModule().getId() == mplsPair.getIngressPort().getModule().getId()) && (mplsPair1.getIngressPort().getPpcr() == mplsPair.getIngressPort().getPpcr())) && !mplsPair1.getEgressPort().getId().equals(mplsPair.getEgressPort().getId())) {
                                throw new ValidationException("mplsDevicePolicy.ingressEgress.invalidPPCRCombination");
                            }
                        });
                    }
                }
            } else {
                // Finding the mpls pair with selected ingress module id & ppcr
                List<MPLSPair> mplsPairIngressList = mplsDevicePolicyRepository.findByIngressPortModuleAndPPCR(deviceId, mplsPair.getIngressPort().getModule().getId(), mplsPair.getIngressPort().getPpcr());
                if (mplsPairIngressList.isEmpty()) {
                    // Finding the mpls pair with selected egress module id & ppcr
                    List<MPLSPair> mplsPairEgressList = mplsDevicePolicyRepository.findByEgressPortModuleAndPPCR(deviceId, mplsPair.getEgressPort().getModule().getId(), mplsPair.getEgressPort().getPpcr());
                    if (mplsPairEgressList.isEmpty()) {
                        throw new ValidationException("mplsDevicePolicy.ingressEgress.invalidPPCRCombination");
                    }
                } else {
                    mplsPairIngressList.forEach(mplsPair1 -> {
                        // This is for update scenario, ignoring the current MPLS pair which is being edited. Ingress ports of same ppcr should have same end point(egress)
                        if (!mplsPairIds.contains(mplsPair1.getId()) && !mplsPair1.getEgressPort().getId().equals(mplsPair.getEgressPort().getId())) {
                            throw new ValidationException("mplsDevicePolicy.ingressEgress.invalidPPCRCombination");
                        }
                    });
                }
            }
        });
    }

    /**
     * This method is used to update MPLSDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long updatePolicy(DevicePolicy policy) {
        MPLSDevicePolicy mplsDevicePolicy = (MPLSDevicePolicy) policy;
        isValidPolicy(mplsDevicePolicy);
        MPLSDevicePolicy oldDevicePolicy = (MPLSDevicePolicy) devicePolicyRepository.findOne(mplsDevicePolicy.getId());
        if (isPolicyUnChanged(oldDevicePolicy, mplsDevicePolicy)) {
            throw new ValidationException("mplsDevicePolicy.data.unChanged");
        }
        Set<MPLSPair> mplsPairs = mplsDevicePolicy.getMPLSPairs();
        List<Long> impactedObjects = Lists.newArrayList();
        final Long deviceId = mplsDevicePolicy.getDevice().getId();
        mplsPairs.forEach(mplsPair -> {
            mplsPair.setIngressPort(portRepository.findOne(mplsPair.getIngressPort().getId()));
            mplsPair.setEgressPort(portRepository.findOne(mplsPair.getEgressPort().getId()));

            isEgressInPortGroup(deviceId, mplsPair.getEgressPort());

            impactedObjects.add(mplsPair.getIngressPort().getId());
            impactedObjects.add(mplsPair.getEgressPort().getId());
        });

        isValidPolicyToCommit(deviceId, mplsPairs);
        oldDevicePolicy.setMPLSPairs(mplsPairs);

        oldDevicePolicy = devicePolicyRepository.save(oldDevicePolicy);
        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.HEADER_STRIPPING_MPLS_POP_UPDATE)
                .deviceId(oldDevicePolicy.getDevice().getId()).impactedObjectIds(impactedObjects)
                .parentObjectId(oldDevicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method checks if MPLSDevicePolicy data is updated
     *
     * @param oldDevicePolicy
     * @param newDevicePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(MPLSDevicePolicy oldDevicePolicy, MPLSDevicePolicy newDevicePolicy) {
        Set<MPLSPair> oldMPLSPairs = oldDevicePolicy.getMPLSPairs();
        Set<MPLSPair> newMPLSPairs = newDevicePolicy.getMPLSPairs();

        if (oldMPLSPairs.size() == newMPLSPairs.size()) {
            for (MPLSPair oldMPLSPair : oldMPLSPairs) {
                for (MPLSPair newMPLSPair : newMPLSPairs) {
                    if (oldMPLSPair.getId().equals(newMPLSPair.getId())) {
                        if (!oldMPLSPair.getIngressPort().getId().equals(newMPLSPair.getIngressPort().getId())) {
                            return false;
                        }
                        if (!oldMPLSPair.getEgressPort().getId().equals(newMPLSPair.getEgressPort().getId())) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     * This method is used to delete MPLSDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(Long policyId) {
        MPLSDevicePolicy devicePolicy = (MPLSDevicePolicy) devicePolicyRepository.findOne(policyId);
        // Validate
        // 1. DevicePolicy present in DB
        if (devicePolicy == null) {
            throw new ValidationException("mplsDevicePolicy.id.invalid");
        }
        isValidPolicy(devicePolicy);
        // 2. DevicePolicy not in SUBMITTED state.
        if (devicePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            throw new ValidationException("mplsDevicePolicy.delete.policyApplied");
        }
        Set<MPLSPair> mplsPairs = devicePolicy.getMPLSPairs();
        List<Long> impactedObjects = Lists.newArrayList();
        mplsPairs.forEach(mplsPair -> {
            impactedObjects.add(mplsPair.getIngressPort().getId());
            impactedObjects.add(mplsPair.getEgressPort().getId());
        });

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.HEADER_STRIPPING_MPLS_POP_DELETE)
                .deviceId(devicePolicy.getDevice().getId()).impactedObjectIds(impactedObjects)
                .parentObjectId(devicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to recover MPLSDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        return deletePolicy(policyId);
    }
}
