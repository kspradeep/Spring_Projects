package com.brocade.bvm.api.security;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.LoggedInUser;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.outbound.exception.OutboundApiException;
import com.brocade.bvm.outbound.stablenet.service.StablenetMeasurementService;
import com.brocade.bvm.outbound.stablenet.service.StablenetUserGroupService;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Provides authorization functionalities to help filter {@link ManagedObject}, deviceIds and portNames.
 * The class uses Stablenet measurements to provide granular authorization on ports.
 */
@Slf4j
@Named
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ManagedObjectAuthorityProvider {

    @Inject
    private StablenetMeasurementService measurementService;

    @Inject
    private StablenetUserGroupService groupService;

    @Inject
    @Getter //Visible for spel below
    private LoggedInUser loggedInUser;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PortRepository portRepository;

    @Value("${flow.vlan.flood.validation:false}")
    private Boolean isVlanFloodValidation;

    @Value("${flow.vlan.filter.validation:false}")
    private Boolean isVlanFilterValidation;

    @Value("${flow.smac.flood.validation:false}")
    private Boolean isSMACFloodValidationRequired;

    @Value("${flow.smac.filter.validation:false}")
    private Boolean isSMACFilterValidationRequired;

    @Value("${flow.dmac.flood.validation:false}")
    private Boolean isDMACFloodCValidationRequired;

    @Value("${flow.dmac.filter.validation:false}")
    private Boolean isDMACFilterCValidationRequired;

    private static final String VLAN_KEY = "VLAN";
    private static final String SMAC_KEY = "SMAC";
    private static final String DMAC_KEY = "DMAC";

    public boolean hasAuthorityOnPorts(Long deviceId, List<Long> portIds) {
        List<Long> authorizedPortIds = getAuthorizedPortsOfDevice(deviceId);
        return authorizedPortIds.containsAll(portIds);
    }

    public Multimap<Long, Long> getAuthorizedPortIdsOfDevices(List<Long> deviceIds) {
        Multimap<Long, Long> devicePortIdsMap = ArrayListMultimap.create();
        //TODO Create RequestContextListener to propagate requests to child threads
        //deviceIds.parallelStream()
        //.forEach(deviceId -> devicePorts.putAll(deviceId, measurementService.getDeviceMeasurements(deviceId.toString()).getPortFullNames()));
        List<Long> authorizedDeviceIds = getAuthorizedDeviceIds().stream()
                .filter(deviceIds::contains)
                .collect(Collectors.toList());
        for (Long deviceId : authorizedDeviceIds) {
            devicePortIdsMap.putAll(deviceId, getAuthorizedPortsOfDevice(deviceId));
        }
        return devicePortIdsMap;
    }

    @Cacheable(value = "authorizedDevices", key = "#root.target.getLoggedInUser().getUsername()")
    public List<Long> getAuthorizedDeviceIds() {
        log.trace("Calling measurement service to getAuthorizedDeviceIds");
        try {
            List<Long> stablenetDeviceIds = measurementService.getStablenetDeviceIds();
            if (stablenetDeviceIds.isEmpty()) {
                return Collections.emptyList();
            } else {
                return deviceRepository.findIdsByStablenetIdIn(stablenetDeviceIds);
            }
        } catch (OutboundApiException e) {
            log.error("Failed to get authorized devices from Stablenet", e);
            return Collections.emptyList();
        }
    }

    @Cacheable(value = "authorizedPorts", key = "{#root.target.getLoggedInUser().getUsername(), #deviceId}")
    public List<Long> getAuthorizedPortsOfDevice(Long deviceId) {
        Device device = deviceRepository.findById(deviceId);
        log.trace("Calling measurement service to getAuthorizedPortsOfDevice {}", deviceId);
        try {
            List<Long> portIndices = measurementService.getPortIndices(device.getStablenetId());
            if (portIndices.isEmpty()) {
                return Collections.emptyList();
            } else {
                return portRepository.findIdsByDeviceIdAndPortIndex(deviceId, portIndices);
            }
        } catch (OutboundApiException e) {
            log.error("Failed to get authorized ports from Stablenet", e);
            return Collections.emptyList();
        }
    }

    public Device applyRBACOnDevice(Device device) {
        if (device != null && Device.Type.SD != device.getType()) {
            List<Long> authorizedPortsOnDevice = getAuthorizedPortsOfDevice(device.getId());
            Set<Module> modules = device.getModules();
            for (Module eachModule : modules) {
                Set<Port> authorizedPorts = eachModule.getPorts().stream().filter(port -> authorizedPortsOnDevice.contains(port.getId())).collect(Collectors.toSet());
                eachModule.setPorts(authorizedPorts);
            }
            device.setModules(modules);
            //TODO: Need to apply rbac on portgroups as well
        }
        return device;
    }

    public Set<Policy> applyRBACOnPolicies(Set<Policy> policies, Long deviceId) {
        Set<Policy> policesAfterRBAC = new HashSet<>();
        //remove all unauthorized policies
        List<Long> ports = getAuthorizedPortsOfDevice(deviceId);
        policies.stream().forEach(policy -> {
            Set<Long> portIds = new HashSet<>();
            policy.getFlows().forEach(flow -> {
                if (!flow.getIngressPortGroups().isEmpty()) {
                    portIds.addAll(flow.getIngressPortGroups().stream().flatMap(portGroup -> portGroup.getPorts().stream().map(Port::getId)).collect(Collectors.toSet()));
                }
                if (!flow.getIngressPorts().isEmpty()) {
                    portIds.addAll(flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
                }
                if (!flow.getEgressPortGroups().isEmpty()) {
                    portIds.addAll(flow.getEgressPortGroups().stream().flatMap(portGroup -> portGroup.getPorts().stream().map(Port::getId)).collect(Collectors.toSet()));
                }
                if (!flow.getEgressPorts().isEmpty()) {
                    portIds.addAll(flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
                }
            });
            if (portIds.stream().allMatch(ports::contains)) {
                policesAfterRBAC.add(policy);
            }
        });
        return policesAfterRBAC;
    }

    @Cacheable(value = "authorizedVlans", key = "{#root.target.getLoggedInUser().getUsername(), #vlanId}")
    private List<String> getAuthorizedVlansForUser() {
        log.trace("Calling measurement service to getAuthorizedVlansForUser {}", loggedInUser.getUsername());
        Map<String, List<String>> vlanIdsSMACAndDMAC;
        try {
            vlanIdsSMACAndDMAC = groupService.getVlanSmacAndDmacForUser(loggedInUser.getUsername());
        } catch (OutboundApiException e) {
            log.error("", e);
            return Collections.emptyList();
        }
        return vlanIdsSMACAndDMAC.get(VLAN_KEY);
    }

    @Cacheable(value = "authorizedSMAC", key = "{#root.target.getLoggedInUser().getUsername(), #SMAC}")
    private List<String> getAuthorizedSMACForUser() {
        log.trace("Calling measurement service to getAuthorizedSMACForUser {}", loggedInUser.getUsername());
        Map<String, List<String>> vlanIdsSMACAndDMAC = new HashMap<>();
        try {
            vlanIdsSMACAndDMAC = groupService.getVlanSmacAndDmacForUser(loggedInUser.getUsername());
        } catch (OutboundApiException e) {
            log.error("", e);
            return Collections.emptyList();
        }
        return vlanIdsSMACAndDMAC.get(SMAC_KEY);
    }

    @Cacheable(value = "authorizedDMAC", key = "{#root.target.getLoggedInUser().getUsername(), #DMAC}")
    private List<String> getAuthorizedDMACForUser() {
        log.trace("Calling measurement service to getAuthorizedDMACForUser {}", loggedInUser.getUsername());
        Map<String, List<String>> vlanIdsSMACAndDMAC = new HashMap<>();
        try {
            vlanIdsSMACAndDMAC = groupService.getVlanSmacAndDmacForUser(loggedInUser.getUsername());
        } catch (OutboundApiException e) {
            log.error("", e);
            return Collections.emptyList();
        }
        return vlanIdsSMACAndDMAC.get(DMAC_KEY);
    }


    public boolean isVlansInPolicyAuthorized(Policy policy) {
        if (isVlanFloodValidation || isVlanFilterValidation) {
            List<String> allowedVlans = getAuthorizedVlansForUser();
            for (Flow eachFlow : policy.getFlows()) {
                //validation check on flood vlan
                if (isVlanFloodValidation) {
                    for (String eachFloodVlanId : eachFlow.getVlans()) {
                        try {
                            if (eachFloodVlanId != null && !allowedVlans.contains(eachFloodVlanId)) {
                                return false;
                            }
                        } catch (NumberFormatException ex) {
                            log.info("Invalid Vlan Id :{}", eachFloodVlanId);
                        }
                    }
                }
                //validation check on filter vlan inside rule
                if (isVlanFilterValidation) {
                    for (RuleSet eachRuleSet : eachFlow.getRuleSets()) {
                        for (Rule eachRule : eachRuleSet.getRules()) {
                            if (eachRule.getVlanId() != -1 && !allowedVlans.contains(String.valueOf(eachRule.getVlanId()))) {
                                return false;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    public boolean isSourceMacTagInPolicyAuthorized(Policy policy) {
        if (isSMACFilterValidationRequired || isSMACFloodValidationRequired) {
            List<String> allowedSMAC = getAuthorizedSMACForUser();
            for (Flow eachFlow : policy.getFlows()) {
                //validation check on SMAC
                if (isSMACFloodValidationRequired) {
                    String smac = eachFlow.getSourceMacTag();
                    try {
                        if (smac != null && smac != "" && !allowedSMAC.contains(smac)) {
                            return false;
                        }
                    } catch (NumberFormatException ex) {
                        log.info("Invalid SMAC Tag :{}", smac);
                    }
                }

                if (isSMACFilterValidationRequired) {
                    for (RuleSet eachRuleSet : eachFlow.getRuleSets()) {
                        for (Rule eachRule : eachRuleSet.getRules()) {
                            if (eachRule.getSourceMac() != null && eachRule.getSourceMac() != "" && !allowedSMAC.contains(String.valueOf(eachRule.getSourceMac()))) {
                                return false;
                            }
                        }
                    }
                }

            }
        }
        return true;
    }

    public boolean isDestinationMacTagInPolicyAuthorized(Policy policy) {
        if (isDMACFloodCValidationRequired || isDMACFilterCValidationRequired) {
            List<String> allowedDMAC = getAuthorizedDMACForUser();
            for (Flow eachFlow : policy.getFlows()) {
                //validation check on DMAC
                if (isDMACFloodCValidationRequired) {
                    String dmac = eachFlow.getDestinationMacTag();
                    try {
                        if (dmac != null && dmac != "" && !allowedDMAC.contains(dmac)) {
                            return false;
                        }
                    } catch (NumberFormatException ex) {
                        log.info("Invalid DMAC Tag :{}", dmac);
                    }
                }

                if (isSMACFloodValidationRequired) {
                    for (RuleSet eachRuleSet : eachFlow.getRuleSets()) {
                        for (Rule eachRule : eachRuleSet.getRules()) {
                            if (eachRule.getDestinationMac() != null && eachRule.getDestinationMac() != "" && !allowedDMAC.contains(String.valueOf(eachRule.getDestinationMac()))) {
                                return false;
                            }
                        }
                    }
                }

            }
        }
        return true;
    }

    public boolean isValidAdminUser() {
        return groupService.isValidAdminUser(loggedInUser.getUsername());
    }
}
