package com.brocade.bvm.api.utility;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.dao.EventRepository;
import com.brocade.bvm.model.db.Event;
import com.brocade.bvm.model.db.Job;
import com.google.common.base.Strings;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.time.Instant;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * GenericHelper is utility class for handling generic operations.
 *
 */
@Named
public class GenericHelper {

    @Inject
    private EventRepository eventRepository;

    @Inject
    private ConfigRepository configRepository;

    /**
     * Validate the slx versions for with the base version and return the result
     *
     * @param deviceOs
     * @return
     */
    public int isSLXVersionValid(String deviceOs, String baseVersion) {
        if (!Strings.isNullOrEmpty(deviceOs)) {
            Pattern pattern = Pattern.compile("^([A-Za-z\\s]*)([\\d]+)([a-z])([\\.])([\\d+])([\\.])([0-9]+)");
            Matcher matcher = pattern.matcher(String.valueOf(deviceOs));
            if (matcher.find() && matcher.groupCount() == 7) {
                if ("s".equals(matcher.group(3))) {
                    StringBuilder currentVersion = new StringBuilder();
                    currentVersion.append(matcher.group(2)).append(".").append(matcher.group(5)).append(".").append(matcher.group(7));
                    if (!currentVersion.toString().isEmpty()) {
                        int compareOutput = compareVersions(currentVersion.toString(), baseVersion);
                        return compareOutput;
                    }
                }
            }
        }
        return -1;
    }

    /**
     * Compares two versions and return the result.
     *
     * @param version1
     * @param version2
     * @return
     */
    private int compareVersions(String version1, String version2) {
        if (version1 != null && version2 != null) {
            String[] components1 = (version1.trim()).split("\\.");
            String[] components2 = (version2.trim()).split("\\.");
            int length = Math.min(components1.length, components2.length);
            for (int i = 0; i < length; i++) {
                int result = new Integer(components1[i]).compareTo(Integer.parseInt(components2[i]));
                if (result != 0) {
                    return result;
                }
            }
            return Integer.compare(components1.length, components2.length);
        } else {
            return -1;
        }
    }

    /**
     * Generate the event for the failed/errored actions.
     *
     * @param parentId
     * @param deviceName
     * @param userName
     * @param severity
     * @param type
     * @param status
     * @param result
     */
    public void sendNotification(Long parentId, String deviceName, String userName, Event.Severity severity, Job.Type type, Job.Status status, String result) {
        Event event = new Event();
        event.setParentObjectId(parentId);
        event.setType(type.toString());
        event.setJobStatus(status.toString());
        event.setSeverity(severity);
        event.setCreatedByUser(userName);
        event.setCreatedTime(Instant.now());
        event.setTargetHost(deviceName);
        event.setLastUpdatedTime(Instant.now());
        event.setResult(result);
        eventRepository.save(event);
    }
}
