package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The HeaderStrippingModulePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover HeaderStripping module policy for NonOpenFlow
 */
@Slf4j
@Named
public class HeaderStrippingModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {

    private static final String SLX_9850 = "SLX9850";

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private EntityManager entityManager;

    /**
     * This method is used to create HeaderStripping module policy, on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy) {
        HeaderStrippingModulePolicy headerStrippingModulePolicy = modulePolicy.getHeaderStrippingModulePolicy();
        isValidPolicy(headerStrippingModulePolicy, deviceId);
        List<Long> moduleIds = headerStrippingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Long> portIds = headerStrippingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Device device = deviceRepository.findOne(headerStrippingModulePolicy.getDevice().getId());
        if (device != null && (device.getType() == Device.Type.SD || device.getType() == Device.Type.ICX)) {
            throw new ValidationException("policy.action.invalid");
        }
        List<String> processorNumbers = new ArrayList<>();
        processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.ALL.name());
        List<String> processors = new ArrayList<>();
        if (headerStrippingModulePolicy.getProcessor() == HeaderStrippingModulePolicy.ProcessorNumber.ALL) {
            processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.ONE.name());
            processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.TWO.name());

            processors.add(HeaderStrippingModulePolicy.ProcessorNumber.ONE.getProcessorNumber());
            processors.add(HeaderStrippingModulePolicy.ProcessorNumber.TWO.getProcessorNumber());
        } else {
            processorNumbers.add(headerStrippingModulePolicy.getProcessor().name());
            processors.add(headerStrippingModulePolicy.getProcessor().getProcessorNumber());
        }

        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
        headerStrippingModulePolicy.setModules(Sets.newHashSet(modules));
        isValidPolicyToCommit(headerStrippingModulePolicy, moduleIds, modules, processors, device, portIds, portIds);

        if (Device.Type.MLXE == device.getType()) {
            /** 1. Check if modulePolicy already present on same device and module.
             * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs.
             */
            List<HeaderStrippingModulePolicy> headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndModuleIds(headerStrippingModulePolicy.getDevice().getId(), moduleIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.SUBMITTED));
            if (!headerPolicies.isEmpty()) {
                for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                    if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header)) {
                        log.error("Already a Header Stripping Module Policy applied for the selected Module(s) and Header. Aborting!");
                        throw new ValidationException("headerStripping.edit.exists");
                    }
                }
            }

            /** 2. Validation for not to allow header stripping & preserve on the same set of ppcrs.
             * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs..
             */
            headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndModuleIdsAndOppositePreserve(headerStrippingModulePolicy.getDevice().getId(), moduleIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            if (!headerPolicies.isEmpty()) {
                for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                    if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header)) {
                        log.error("Already a Header Stripping/Preserve Module Policy applied for the selected Module(s) and Header. Aborting!");
                        throw new ValidationException("header.stripping.and.preserve.cannot.coexists");
                    }
                }
            }
        } else if (Device.Type.SLX == device.getType()) {
            portIds = headerStrippingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
            /** 1. Check if modulePolicy already present on same device and module.
             * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs.
             */
            if (!portIds.isEmpty()) {
                List<HeaderStrippingModulePolicy> headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndPortIds(headerStrippingModulePolicy.getDevice().getId(), portIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR, WorkflowParticipant.WorkflowStatus.SUBMITTED));
                if (!headerPolicies.isEmpty()) {
                    for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                        if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header)) {
                            log.error("Already a Header Stripping Module Policy applied for the selected Module(s) and Header. Aborting!");
                            throw new ValidationException("headerStripping.edit.exists");
                        }
                    }
                }
                List<Long> packetTruncationPortIds = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(device.getId(), portIds);
                if (!packetTruncationPortIds.isEmpty()) {
                    List<String> portNames = portRepository.findNamesByIds(packetTruncationPortIds);
                    String portNameString = portNames.stream().collect(Collectors.joining(", "));
                    log.error("A Packet Truncation profile has already been applied for the selected port(s). " + portNameString);
                    throw new ValidationException("A Packet Truncation profile has already been applied for the selected port(s) " + portNameString + ".");
                }
            }
        }

        headerStrippingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        headerStrippingModulePolicy = modulePolicyRepository.save(headerStrippingModulePolicy);
        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.HEADER_STRIPPING_SLX_CREATE : Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_CREATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(device.getId()).impactedObjectIds(moduleIds)
                .parentObjectId(headerStrippingModulePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to update HeaderStripping module policy, on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicy) {
        HeaderStrippingModulePolicy headerStrippingModulePolicy = modulePolicy.getHeaderStrippingModulePolicy();
        isValidPolicy(headerStrippingModulePolicy, deviceId);
        HeaderStrippingModulePolicy oldheaderStrippingModulePolicy = (HeaderStrippingModulePolicy) modulePolicyRepository
                .findById(modulePolicyId);

        // If no lag is available with id
        if (oldheaderStrippingModulePolicy == null) {
            throw new ValidationException("headerStripping.id.invalid");
        }
        Device device = deviceRepository.findOne(headerStrippingModulePolicy.getDevice().getId());
        if (device != null && (device.getType() == Device.Type.SD || device.getType() == Device.Type.ICX)) {
            throw new ValidationException("policy.action.invalid");
        }
        // If Policy is not in committed status or in error state, do not allow
        // modify
        if (oldheaderStrippingModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ACTIVE
                || oldheaderStrippingModulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("headerStripping.edit.failed");
        }
        List<Long> moduleIds = headerStrippingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Long> portIds = headerStrippingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        List<Long> historyPorts = oldheaderStrippingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        List<Long> uniquePort = headerStrippingModulePolicy.getPorts().stream().filter(port -> !historyPorts.contains(port.getId())).map(Port::getId).collect(Collectors.toList());
        List<String> processorNumbers = new ArrayList<>();
        processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.ALL.name());
        List<String> processors = new ArrayList<>();
        if (headerStrippingModulePolicy.getProcessor() == HeaderStrippingModulePolicy.ProcessorNumber.ALL) {
            processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.ONE.name());
            processorNumbers.add(HeaderStrippingModulePolicy.ProcessorNumber.TWO.name());

            processors.add(HeaderStrippingModulePolicy.ProcessorNumber.ONE.getProcessorNumber());
            processors.add(HeaderStrippingModulePolicy.ProcessorNumber.TWO.getProcessorNumber());
        } else {
            processorNumbers.add(headerStrippingModulePolicy.getProcessor().name());
            processors.add(headerStrippingModulePolicy.getProcessor().getProcessorNumber());
        }

        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        isPolicyUnChanged(oldheaderStrippingModulePolicy, headerStrippingModulePolicy);
        isValidPolicyToCommit(headerStrippingModulePolicy, moduleIds, modules, processors, device, portIds, uniquePort);
        isValidPolicyToUpdateOrDelete(device.getId(), headerStrippingModulePolicy.getReplaceVlan(), true);

        if (Device.Type.MLXE == device.getType()) {
            /** 1. Check if modulePolicy already present on same device and module.
             * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs.
             */
            List<HeaderStrippingModulePolicy> headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndModuleIds(headerStrippingModulePolicy.getDevice().getId(), moduleIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            headerPolicies.remove(oldheaderStrippingModulePolicy);
            if (!headerPolicies.isEmpty()) {
                for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                    if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header)) {
                        log.error("Already a Header Stripping Module Policy applied for the selected Module(s) and Header. Aborting!");
                        throw new ValidationException("headerStripping.edit.exists");
                    }
                }
            }

            /** 2. Validation for not to allow header stripping & preserve on the same set of ppcrs.
             * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs..
             */
            headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndModuleIdsAndOppositePreserve(headerStrippingModulePolicy.getDevice().getId(), moduleIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            headerPolicies.remove(oldheaderStrippingModulePolicy);
            if (!headerPolicies.isEmpty()) {
                for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                    if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header)) {
                        log.error("Already a Header Stripping/Preserve Module Policy applied for the selected Module(s) and Header. Aborting!");
                        throw new ValidationException("header.stripping.and.preserve.cannot.coexists");
                    }
                }
            }
        } else if (Device.Type.SLX == device.getType()) {
            portIds = headerStrippingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
            if(!portIds.isEmpty()) {
                /** 1. Check if modulePolicy already present on same device and module.
                 * Because: Header stripping and preserve features can not be enabled together for same set of ppcrs.
                 */
                List<HeaderStrippingModulePolicy> headerPolicies = headerStrippingModulePolicyRepository.findHeaderStrippingModulePolicyByDeviceIdAndPortIds(headerStrippingModulePolicy.getDevice().getId(), portIds, headerStrippingModulePolicy.isPreserve(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                headerPolicies.remove(oldheaderStrippingModulePolicy);
                if (!headerPolicies.isEmpty()) {
                    for (HeaderStrippingModulePolicy.Headers header : headerStrippingModulePolicy.getStripHeaders()) {
                        if (headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getStripHeaders().stream()).collect(Collectors.toList()).contains(header) && headerPolicies.stream().flatMap(headerPolicy -> headerPolicy.getPorts().stream()).collect(Collectors.toList()).containsAll(headerStrippingModulePolicy.getPorts()) && headerPolicies.stream().findAny().get().getPorts().size() == headerStrippingModulePolicy.getPorts().size()) {
                            log.error("Already a Header Stripping Module Policy applied for the selected Module(s) and Header. Aborting!");
                            throw new ValidationException("headerStripping.edit.exists");
                        }
                    }
                }
                List<Long> packetTruncationPortIds = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(device.getId(), portIds);
                if (!packetTruncationPortIds.isEmpty()) {
                    List<String> portNames = portRepository.findNamesByIds(packetTruncationPortIds);
                    String portNameString = portNames.stream().collect(Collectors.joining(", "));
                    log.error("A Packet Truncation profile has already been applied for the selected port(s). " + portNameString);
                    throw new ValidationException("A Packet Truncation profile has already been applied for the selected port(s) " + portNameString + ".");
                }
            }
        }

        /*Merging updated policy data into old policy*/
        oldheaderStrippingModulePolicy.setStripHeaders(headerStrippingModulePolicy.getStripHeaders());
        oldheaderStrippingModulePolicy.setProcessor(headerStrippingModulePolicy.getProcessor());
        oldheaderStrippingModulePolicy.setModules(Sets.newHashSet(modules));
        oldheaderStrippingModulePolicy.setPorts(headerStrippingModulePolicy.getPorts());
        oldheaderStrippingModulePolicy.setPreserve(headerStrippingModulePolicy.isPreserve());
        oldheaderStrippingModulePolicy.setIntermediatePortId(headerStrippingModulePolicy.getIntermediatePortId());
        oldheaderStrippingModulePolicy.setIntermediateVlan(headerStrippingModulePolicy.getIntermediateVlan());
        oldheaderStrippingModulePolicy.setReplaceVlan(headerStrippingModulePolicy.getReplaceVlan());
        oldheaderStrippingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(oldheaderStrippingModulePolicy);

        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.HEADER_STRIPPING_SLX_UPDATE : Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_UPDATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(device.getId()).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * Validating the Header Stripping Policy
     *
     * @param policy
     * @param deviceId
     * @return
     */
    protected boolean isValidPolicy(ModulePolicy policy, Long deviceId) {
        if (policy != null) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (device.getType() == Device.Type.ICX || device.getMode() != Device.Mode.PLAIN) ||
                    (Device.Type.SLX == device.getType() && device.getModel() != null && device.getModel().contains(SLX_9850))) {
                throw new ValidationException("header.stripping.not.supported.device");
            }
        }
        return true;
    }

    /**
     * This method checks if headerStripping policy data is valid to commit on the given device
     *
     * @param headerStrippingModulePolicy
     * @param moduleIds
     * @param modules
     * @param processors
     * @param device
     * @param portIds
     * @param uniquePorts
     */
    private void isValidPolicyToCommit(HeaderStrippingModulePolicy headerStrippingModulePolicy, List<Long> moduleIds, List<Module> modules, List<String> processors, Device device, List<Long> portIds, List<Long> uniquePorts) {

        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (headerStrippingModulePolicy.getStripHeaders() == null || headerStrippingModulePolicy.getStripHeaders().isEmpty()) {
            throw new ValidationException("empty.headers.not.allowed");
        }
        if (Device.Type.MLXE == device.getType() && (moduleIds == null || moduleIds.isEmpty())) {
            throw new ValidationException("empty.module.not.allowed");
        }

        if (Device.Type.SLX == device.getType()) {
            if (portIds == null || portIds.isEmpty()) {
                throw new ValidationException("empty.port.notallowed");
            }
            if (uniquePorts != null && !uniquePorts.isEmpty()) {
                List<Long> ids = headerStrippingModulePolicyRepository.findModulePolicyByPortIdsAndVNTAGAndBR(device.getId(), uniquePorts, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR), Arrays.asList(HeaderStrippingModulePolicy.Headers.BR802, HeaderStrippingModulePolicy.Headers.VNTAG));
                if (!ids.isEmpty())
                    throw new ValidationException("802BRVNTAG.together.not.allowed");
            }
        }
        // #1 Check if the modules selected are valid modules
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("headerStripping.edit.failed");
        }
        // #2 Check if the process number is valid
        HeaderStrippingModulePolicy.ProcessorNumber processorNumber = headerStrippingModulePolicy.getProcessor();
        List<HeaderStrippingModulePolicy.ProcessorNumber> processorNumberList = Arrays.asList(HeaderStrippingModulePolicy.ProcessorNumber.ONE, HeaderStrippingModulePolicy.ProcessorNumber.TWO, HeaderStrippingModulePolicy.ProcessorNumber.ALL);
        if (!processorNumberList.contains(processorNumber)) {
            log.error("Invalid Process Number. Aborting!");
            throw new ValidationException("headerStripping.processNumber.invalid");
        }
        if (headerStrippingModulePolicy.isPreserve()) {
            Long intermediatePortId = headerStrippingModulePolicy.getIntermediatePortId();
            if (intermediatePortId != null) {
                ManagedObject managedObject = getManagedObject(intermediatePortId);
                if (managedObject instanceof Port) {
                    Port port = (Port) managedObject;
                    if (!processors.contains(port.getPpcr().toString())) {
                        throw new ValidationException("headerStripping.port.ppcrInvalid");
                    }
                } else if (managedObject instanceof PortGroup) {
                    PortGroup portGroup = (PortGroup) managedObject;
                    portGroup.getPorts().forEach(port -> {
                        if (!processors.contains(port.getPpcr().toString())) {
                            throw new ValidationException("headerStripping.port.ppcrInvalid");
                        }
                    });
                }
                headerStrippingModulePolicy.setIntermediatePort(managedObject);
            } else {
                throw new ValidationException("headerStripping.port.invalid");
            }
        }

        Integer replaceVlan = headerStrippingModulePolicy.getReplaceVlan();
        Integer intermediateVlan = headerStrippingModulePolicy.getIntermediateVlan();
        Long deviceId = headerStrippingModulePolicy.getDevice().getId();

        if (headerStrippingModulePolicy.isPreserve()) {
            //#1 Validating if the given intermediate VLAN and replace VLAN are same
            if (replaceVlan == intermediateVlan) {
                throw new ValidationException("intermediateAndReplace.vlan.same");
            }

            //#2 Validating if the given intermediate VLAN is with in the allowed range
            if (intermediateVlan < HeaderStrippingModulePolicy.VLAN_MIN_VALUE || intermediateVlan > HeaderStrippingModulePolicy.VLAN_MAX_VALUE) {
                throw new ValidationException("intermediate.vlan.notvalid");
            }

            //#3 Validating if the selected intermediate VLAN is already used in any other flow
            List<Long> flowIds = headerStrippingModulePolicyRepository.findFlowIdsByDeviceIdAndVlanId(deviceId, intermediateVlan);
            if (!flowIds.isEmpty()) {
                throw new ValidationException("intermediate.vlan.exists");
            }

            //#4 Validating if the given replace VLAN is with in the allowed range
            if (replaceVlan < HeaderStrippingModulePolicy.VLAN_MIN_VALUE || replaceVlan > HeaderStrippingModulePolicy.VLAN_MAX_VALUE) {
                throw new ValidationException("replace.vlan.notvalid");
            }

            //#5 Validating if the selected reserved VLAN is already used in any other flow
            flowIds = headerStrippingModulePolicyRepository.findFlowIdsByDeviceIdAndVlanId(deviceId, replaceVlan);
            if (!flowIds.isEmpty()) {
                throw new ValidationException("replace.vlan.exists");
            }
        }
    }

    /**
     * This method checks if headerStripping policy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(HeaderStrippingModulePolicy oldModulePolicy, HeaderStrippingModulePolicy newModulePolicy) {
        if (oldModulePolicy.getProcessor() != null ? !oldModulePolicy.getProcessor().equals(newModulePolicy.getProcessor()) : newModulePolicy.getProcessor() != null)
            return false;
        if (!oldModulePolicy.getStripHeaders().isEmpty() ? !oldModulePolicy.getStripHeaders().containsAll(newModulePolicy.getStripHeaders()) : !newModulePolicy.getStripHeaders().isEmpty())
            return false;
        Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        Set<Long> newModuleIds = newModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        if (!oldModuleIds.containsAll(newModuleIds)) {
            return false;
        }
        if (oldModulePolicy.isPreserve() != newModulePolicy.isPreserve()) {
            return false;
        }
        if (oldModulePolicy.isPreserve() && newModulePolicy.isPreserve()) {
            if (oldModulePolicy.getIntermediatePortId() != newModulePolicy.getIntermediatePortId()) {
                return false;
            }

            if (oldModulePolicy.getIntermediateVlan() != newModulePolicy.getIntermediateVlan()) {
                return false;
            }
            if (oldModulePolicy.getReplaceVlan() != newModulePolicy.getReplaceVlan()) {
                return false;
            }
        }
        return true;
    }

    private void isValidPolicyToUpdateOrDelete(Long deviceId, Integer replaceVlan, boolean isUpdate) {
        //#4 Validating if the preserve Header is enabled in any of the policy on the device
        List<Long> policiesWithPreserveHeader = policyRepository.findPoliciesByDeviceIdAndPreserveHeader(deviceId, true);
        if (!policiesWithPreserveHeader.isEmpty()) {
            if (isUpdate)
                throw new ValidationException("headerStripping.update.port.ppcrInvalid");
            else
                throw new ValidationException("headerStripping.delete.port.ppcrInvalid");
        }

        //#5 Validating if the selected reserved VLAN is already used in any other flow from ACTIVE policies (SAVED over COMMIT)
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(deviceId, 0L);
        if (!activePolicies.isEmpty()) {
            validateIfReplaceVlanUsedInActivePolicies(activePolicies, replaceVlan);
        }
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    private List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        //
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    /**
     * This method validates if the reserved VLAN is used in ACTIVE policies
     *
     * @param activePolicies
     * @param replaceVlan
     * @throws ValidationException
     */
    private void validateIfReplaceVlanUsedInActivePolicies(List<Policy> activePolicies, Integer replaceVlan) {
        activePolicies.forEach(activePolicy -> {
            final Set<String> activeVlans = Sets.newHashSet();
            activePolicy.getFlows().forEach(flow -> {
                // Checking if PreserveHeader is enabled on any policy (If preserve header is enabled, reserved VLAN will be used to build command in route-map on device)
                if (activePolicy.isPreserveHeader()) {
                    throw new ValidationException("replaceVlan.used.inPolicy");
                } else {
                    activeVlans.addAll(flow.getVlans().stream().collect(Collectors.toSet()));
                }
            });

            // Finding if the reserved VLAN is used in ACTIVE policies, which are currently in DRAFT state
            if (activeVlans.contains(String.valueOf(replaceVlan))) {
                throw new ValidationException("replaceVlan.used.inPolicy");
            }
        });
    }

    /**
     * This method is used to delete headerStripping policy from the device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        ModulePolicy modulePolicy = modulePolicyRepository.findOne(modulePolicyId);
        HeaderStrippingModulePolicy headerStrippingModulePolicy = (HeaderStrippingModulePolicy) modulePolicy;
        // Validate
        // 1. ModulePolicy present in DB
        if (modulePolicy == null) {
            throw new ValidationException("headerStripping.id.invalid");
        }
        isValidPolicy(headerStrippingModulePolicy, deviceId);

        isValidPolicyToUpdateOrDelete(deviceId, headerStrippingModulePolicy.getReplaceVlan(), false);

        // 2. ModulePolicy not in active state.
        if (modulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            if (headerStrippingModulePolicy.isPreserve()) {
                throw new ValidationException("headerPreserve.delete.policy.in.progress");
            } else {
                throw new ValidationException("headerStripping.delete.policyApplied");
            }
        }
        Device device = deviceRepository.findOne(headerStrippingModulePolicy.getDevice().getId());
        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.HEADER_STRIPPING_SLX_DELETE : Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_DELETE;

        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(device.getId()).impactedObjectIds(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover failed headerStripping policy on the device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        ModulePolicy modulePolicy = modulePolicyRepository.findOne(modulePolicyId);
        HeaderStrippingModulePolicy headerStrippingModulePolicy = (HeaderStrippingModulePolicy) modulePolicy;
        // Validate
        // 1. ModulePolicy present in DB
        if (modulePolicy == null) {
            throw new ValidationException("headerStripping.id.invalid");
        }
        isValidPolicy(headerStrippingModulePolicy, deviceId);
        // 2. ModulePolicy not in ERROR state.
        if (modulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("policy.recovery.not.in.error");
        }

        modulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(modulePolicy);
        Device device = deviceRepository.findOne(headerStrippingModulePolicy.getDevice().getId());
        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.HEADER_STRIPPING_SLX_ROLLBACK : Job.Type.HEADER_STRIPPING_8021BR_AND_VNTAG_ROLLBACK;

        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(device.getId()).impactedObjectIds(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    private ManagedObject getManagedObject(Long intermediatePortId) {
        Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
        List<Long> ids = new ArrayList<>();
        ids.add(intermediatePortId);
        query.setParameter("ids", ids);
        return (ManagedObject) query.getSingleResult();
    }
}
