package com.brocade.bvm.api.validation;

import java.util.List;
import java.util.Set;

import org.springframework.validation.Errors;

public class ValidatorUtility {
    
    public static boolean notNull(Object value, Errors errors, String fieldName) {
        if (null == value) {
            errors.reject("", String.format("%s field should not be Null", fieldName));
            return false;
        }
        return true;
    }

    public static boolean isNull(Object value, Errors errors, String fieldName) {
        if (null != value) {
            errors.reject("", String.format("%s field should be Null", fieldName));
            return false;
        }
        return true;
    }

    public static boolean checkNumber(int number, int min, int max, Errors errors, String fieldName) {
        if (!(number >= min && number <= max)) {
            errors.reject("10000", String.format("%s should be within min = %s max = %s", fieldName, min, max));
            return false;
        }
        return true;
    }

    public static boolean checkStringNumber(String number, int min, int max, Errors errors, String fieldName) {
        if (number == null || number.isEmpty()) {
            errors.reject("10000", String.format("%s cannot be null ", fieldName));
            return false;
        } else {
            int num = Integer.parseInt(number);
            if (!(num >= min && num <= max)) {
                errors.reject("10000", String.format("Number should be within min = %s max = %s", min, max));
                return false;
            }
            return true;
        }
    }

    public static void checkPorts(List<String> ports, Errors errors, String fieldName) {
        if (ports == null || ports.isEmpty()) {
            errors.reject("", String.format("%s cannot be Empty", fieldName));
        } else {
            for (String port : ports) {
                if (port == null || port.isEmpty()) {
                    errors.reject("", "Null or Empty Port Values are not allowed");
                    return;
                } else {
                    int portNum = Integer.parseInt(port);
                    if (portNum < 0 || portNum > 65535) {
                        errors.reject("", "Invalid Port NUmber");
                    }
                }
            }
        }
    }

    public static boolean listContainsNullOrEmptyValue(Set<String> set,Errors errors,String fieldName){
        if(set.contains("")|| set.contains(null)){
            errors.reject("", String.format("%s field contains Empty or Null Value", fieldName));
            return true;
        }
        return false;
    }
}
