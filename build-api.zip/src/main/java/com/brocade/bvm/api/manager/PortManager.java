package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Port;

import java.util.List;

public interface PortManager {
	long changeType(Long deviceId, List<Long> portIds, Port.Type type, boolean loopbackEnable);
	long changeAdminStatus(Long deviceId, List<Long> portIds, Port.AdminStatus status, Port.Mode mode);
	long recoverPort(Long deviceId, List<Long> portIds);
	long updateDescription(Long deviceId, List<Long> portIds, String description);
	long updatePortSpeed(Long deviceId, List<Long> portIds, Long lineSpeed);
	long applyOrRemoveBreakout(Long deviceId, List<Long> portIds, boolean breakout, Long breakoutSpeed);
	long getAdminStatus(Long deviceId, List<Long> portIds);
}
