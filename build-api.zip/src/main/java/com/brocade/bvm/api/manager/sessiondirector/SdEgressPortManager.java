package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.manager.SdPortPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.EgressPortHistoryRepository;
import com.brocade.bvm.dao.sessiondirector.EgressPortRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.EgressPortHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import com.brocade.bvm.model.db.sessiondirector.SdPortVlanMapping;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The SdEgressPortManager class implements methods to perform CRUD operations of egress ports
 */
@Named
@Slf4j
public class SdEgressPortManager implements SdPortPolicyManager {

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    private EgressPortHistoryRepository egressPortHistoryRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected JobQueue jobQueue;


    /**
     * This method is used to save port to database
     *
     * @param ports
     * @return Long This returns jobId
     */
    @Override
    public Long savePort(Long deviceId, List<EgressPort> ports) {
        return null;
    }


    /**
     * This method is used to commit port on the given device
     *
     * @param ports
     * @return Long This returns jobId
     */
    @Override
    public Long commitPort(Device device, List<EgressPort> ports) {
        if (!ports.isEmpty()) {
            List<EgressPort> egressPortsDb = egressPortRepository.findByDeviceId(device.getId());
            Set<EgressPort> portsToDelete = egressPortsDb.stream()
                    .filter(dbPort -> ports.stream().noneMatch(newEgressPort -> newEgressPort.getId() != null && newEgressPort.getId().equals(dbPort.getId())))
                    .collect(Collectors.toSet());
            portsToDelete = portsToDelete.stream().filter(egressPort -> !egressPort.isDefault()).collect(Collectors.toSet());
            long jobId = -1;
            if (!portsToDelete.isEmpty()) {
                Job.Type deleteJobType = Job.Type.SD_EGRESS_PORT_DELETE;
                jobId = jobQueue.submit(JobTemplate.builder()
                        .type(deleteJobType)
                        .deviceId(device.getId())
                        .impactedObjectIds(portsToDelete.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                        .build());
            }

            List<EgressPort> updatedPorts = getUpdatedPorts(ports);
            if (!updatedPorts.isEmpty()) {
                egressPortRepository.save(updatedPorts);
                Job.Type jobType = Job.Type.SD_EGRESS_PORT_UPDATE;
                jobId = jobQueue.submit(JobTemplate.builder()
                        .type(jobType)
                        .deviceId(device.getId())
                        .impactedObjectIds(updatedPorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                        .build());
                return jobId;
            }
            return jobId;
        } else {
            throw new ValidationException("port.get.not.found");
        }
    }

    /**
     * This method gets the update SdPort for update
     *
     * @param ports
     * @return
     */
    private List<EgressPort> getUpdatedPorts(List<EgressPort> ports) {
        List<EgressPort> updatedPorts = Lists.newArrayList();
        if (ports != null && !ports.isEmpty()) {
            ports.stream().forEach(updatedSdPort -> {
                if (WorkflowParticipant.WorkflowStatus.ERROR != updatedSdPort.getWorkflowStatus()) {
                    if (updatedSdPort.getId() == null || updatedSdPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                        updatedPorts.add(updatedSdPort);
                    } else {
                        EgressPort existingSdPort = getPortHistory(updatedSdPort.getId(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
                        if (existingSdPort == null && updatedSdPort.isDefault()) {
                            existingSdPort = getPortHistoryByRevisionTypes(updatedSdPort.getId(), Arrays.asList(HistoryObject.RevisionType.CREATED));
                        }

                        boolean isUpdated = false;
                        if (existingSdPort != null && (updatedSdPort.getImsiLimit() != null && existingSdPort.getImsiLimit() != null && !updatedSdPort.getImsiLimit().equals(existingSdPort.getImsiLimit())) ||
                                (updatedSdPort.getLoadBalance() != null && existingSdPort.getLoadBalance() != null &&
                                        !(updatedSdPort.getLoadBalance().getName()).equals((existingSdPort.getLoadBalance().getName())))) {
                            isUpdated = true;
                        }
                        if (existingSdPort != null && updatedSdPort.getVlanMappings() != null && !updatedSdPort.getVlanMappings().isEmpty() &&
                                existingSdPort.getVlanMappings() != null && !existingSdPort.getVlanMappings().isEmpty()) {
                            Set<SdPortVlanMapping> updatedSdPortVlanIds = updatedSdPort.getVlanMappings();
                            Set<SdPortVlanMapping> existingSdPortVlanIds = existingSdPort.getVlanMappings();
                            if (updatedSdPortVlanIds != null && existingSdPortVlanIds != null &&
                                    !updatedSdPortVlanIds.isEmpty() && !existingSdPortVlanIds.isEmpty()) {
                                for (SdPortVlanMapping vlanMapping : updatedSdPortVlanIds) {
                                    SdPortVlanMapping portVlanMappingUpdated = existingSdPortVlanIds.stream().filter(sdPortVlanMapping -> sdPortVlanMapping.getVlanId().longValue() == vlanMapping.getVlanId().longValue()
                                            && sdPortVlanMapping.isTagged() == vlanMapping.isTagged()).findAny().orElse(null);
                                    if (portVlanMappingUpdated == null) {
                                        isUpdated = true;
                                    }
                                }
                                for (SdPortVlanMapping vlanMapping : existingSdPortVlanIds) {
                                    SdPortVlanMapping portVlanMappingUpdated = updatedSdPortVlanIds.stream().filter(sdPortVlanMapping -> sdPortVlanMapping.getVlanId().longValue() == vlanMapping.getVlanId().longValue()
                                            && sdPortVlanMapping.isTagged() == vlanMapping.isTagged()).findAny().orElse(null);
                                    if (portVlanMappingUpdated == null) {
                                        isUpdated = true;
                                    }
                                }
                            } else if (((updatedSdPortVlanIds == null || updatedSdPortVlanIds.isEmpty()) && existingSdPortVlanIds != null &&
                                    !existingSdPortVlanIds.isEmpty()) || ((existingSdPortVlanIds == null || existingSdPortVlanIds.isEmpty()) && updatedSdPortVlanIds != null &&
                                    !updatedSdPortVlanIds.isEmpty())) {
                                isUpdated = true;
                            }
                        }
                        if (isUpdated) {
                            updatedPorts.add(updatedSdPort);
                        }
                    }
                }
            });
        }
        updatedPorts.stream().forEach(port -> port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT));
        return updatedPorts;
    }


    /**
     * This method is used to delete/recover port on the given device
     *
     * @param ports
     * @return Long This returns jobId
     */
    @Override
    public Long deletePort(Device device, List<EgressPort> ports) {
        if (!ports.isEmpty()) {
            List<EgressPort> activePortsToDelete = new ArrayList<>();
            ports.stream().forEach(port -> {
                EgressPort egressPort = egressPortRepository.findOne(port.getId());
                if (egressPort == null) {
                    throw new ValidationException("port.get.not.found");
                } else if (egressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                    // should not delete a port if in Submitted state
                    log.error("Cannot delete a port id {} which is in progress.", egressPort.getId());
                    throw new ValidationException("port.delete.inprogress");
                } else if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    // should not delete a port if in error state
                    log.error("Cannot delete a port id {} which is in error state.", egressPort.getId());
                    throw new ValidationException("port.delete.inError.state");
                } else if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE && !port.isDefault()) {
                    activePortsToDelete.add(port);
                }
            });

            if (!activePortsToDelete.isEmpty()) {
                Job.Type jobType = Job.Type.SD_EGRESS_PORT_DELETE;
                long jobId = jobQueue.submit(JobTemplate.builder()
                        .type(jobType)
                        .deviceId(device.getId())
                        .impactedObjectIds(activePortsToDelete.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                        .build());

                return jobId;
            }
        }
        throw new ValidationException("port.get.not.found");
    }

    /**
     * This method is used to recover port which is in ERROR state
     *
     * @param ports
     * @return
     * @throws ValidationException
     */
    @Override
    public Long rollbackPort(Device device, List<EgressPort> ports) {
        if (!ports.isEmpty()) {
            long jobId = -1;
            List<EgressPort> portsToRecover = new ArrayList<>();
            for (EgressPort port : ports) {
                EgressPort egressPort = egressPortRepository.findOne(port.getId());
                if (egressPort != null && egressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    if (!egressPort.isDefault()) {
                        egressPort.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        portsToRecover.add(egressPort);
                    } else {
                        EgressPort portFromHistory = getPortHistory(egressPort.getId(), Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE));
                        if (portFromHistory == null) {
                            portFromHistory = getPortHistoryByRevisionTypes(egressPort.getId(), Arrays.asList(HistoryObject.RevisionType.CREATED));
                        }
                        if (portFromHistory != null) {
                            egressPortRepository.save(portFromHistory);
                            Job.Type jobType = Job.Type.SD_DEFAULT_PORT_ROLLBACK;
                            jobId = jobQueue.submit(JobTemplate.builder()
                                    .type(jobType)
                                    .deviceId(device.getId())
                                    .impactedObjectIds(Lists.newArrayList())
                                    .parentObjectId(portFromHistory.getId())
                                    .build());
                        }
                    }
                }
            }
            if (!portsToRecover.isEmpty()) {
                Job.Type jobType = Job.Type.SD_EGRESS_PORT_ROLLBACK;
                jobId = jobQueue.submit(JobTemplate.builder()
                        .type(jobType)
                        .deviceId(device.getId())
                        .impactedObjectIds(portsToRecover.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                        .build());
            }
            return jobId;
        }
        return -1L;
    }

    /**
     * This method fetches the ACTIVE Egress Port from history
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistory(Long portId, List<WorkflowParticipant.WorkflowStatus> workflowStatuses) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndWorkflowStatus(portId, workflowStatuses);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }

    /**
     * This method fetches the ACTIVE Egress Port from history using revision type
     *
     * @param portId
     * @return returns EgressPort from history
     */
    protected EgressPort getPortHistoryByRevisionTypes(Long portId, List<HistoryObject.RevisionType> revisionTypes) {
        List<EgressPortHistory> egressPortHistories = egressPortHistoryRepository.findByIdAndRevisionTypes(portId, revisionTypes);
        EgressPort egressPort = null;
        if (egressPortHistories != null && egressPortHistories.size() > 0) {
            EgressPortHistory egressPortHistory = egressPortHistories.get(0);
            egressPort = egressPortHistory.buildParent();
        }
        return egressPort;
    }
}
