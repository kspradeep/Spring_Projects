package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.factory.*;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.exception.ServerException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;

@Slf4j
@Named
public class ManagerFactoryBuilder {

    @Getter
    @Inject
    private OpenFlowFactory openFlowOperationsFactory;

    @Getter
    @Inject
    private NonOpenFlowFactory nonOpenFlowOperationsFactory;

    @Getter
    @Inject
    private SDFlowFactory sdFlowFactory;

    @Getter
    @Inject
    private TemplateFlowFactory templateFlowFactory;

    public ManagerFactory getOperationsFactory(Device device) throws ServerException {
        if (device != null) {
            if (device.getType() == null && device.getMode() == null)
                return templateFlowFactory;
            if (device.getType() == Device.Type.SD)
                return sdFlowFactory;

            switch (device.getMode()) {
                case OPENFLOW:
                    return openFlowOperationsFactory;
                default:
                    return nonOpenFlowOperationsFactory;
            }
        } else {
            return templateFlowFactory;
        }
    }
}
