package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.FirmwareManager;
import com.brocade.bvm.api.model.HostInfoRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceFirmwareInfoRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.job.FirmwareJobQueue;
import com.brocade.bvm.job.FirmwareJobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.model.db.FirmwareJob;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.firmware.FirmwareHistoryObject;
import com.brocade.bvm.outbound.stablenet.service.StablenetDiscoveryService;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Named
public class GenericFirmwareManager implements FirmwareManager {

    @Inject
    private DeviceFirmwareInfoRepository deviceFirmwareInfoRepository;

    @Inject
    private FirmwareJobQueue firmwareJobQueue;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private StablenetDiscoveryService stablenetService;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    private static final String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$";
    private static final String IPV6_PATTERN_SHORT = "^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$";
    private static final String IPV6_PATTERN_LONG = "^((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))$";
    private static final String FIRMWARE_HISTORY_PATTERN = "^[\\d]+\\s+(\\p{Alpha}+\\s\\p{Alpha}+\\s\\d+\\s\\d+:\\d+:\\d+\\s\\d+)\\s+([\\w\\-\\.]*)\\s+([\\d]+)\\s+([\\d]+)\\s+([\\w\\-\\.]*)\\r*";
    private static final String USERNAME = "HOST_USERNAME";
    private static final String PASSWORD = "HOST_PASSWORD";
    private static final String IP = "HOST_IP";

    @Override
    public Long upgradeFirmware(List<DeviceFirmwareInfo> deviceFirmwareInfos) throws ValidationException {
        Long jobId = 0l;
        for (DeviceFirmwareInfo deviceFirmwareInfo : deviceFirmwareInfos) {
            Device device = deviceRepository.findById(deviceFirmwareInfo.getDevice().getId());
            if (device != null && device.getType() == Device.Type.SLX) {
                deviceFirmwareInfo.setDevice(device);
                deviceFirmwareInfo.setDeleted(false);
                deviceFirmwareInfo.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                deviceFirmwareInfoRepository.save(deviceFirmwareInfo);
                jobId = firmwareJobQueue.submit(FirmwareJobTemplate.builder().type(FirmwareJob.Type.FIRMWARE_UPGRADE).deviceId(deviceFirmwareInfo.getDevice().getId())
                        .parentObjectId(deviceFirmwareInfo.getId()).build());
            } else {
                throw new ValidationException("firmware.device.notSupported");
            }
        }
        return jobId;
    }

    @Override
    public List<FirmwareHistoryObject> getFirmwareHistory(Device device) {
        List<FirmwareHistoryObject> firmwareHistoryObjects = new ArrayList<>();
        String slxFirmwareHistory = stablenetService.getSLXUpgradeVersion(device);
        if (!Strings.isNullOrEmpty(slxFirmwareHistory)) {
            List<String> slxFirmwareHistoryLines = Arrays.asList(slxFirmwareHistory.split("\n"));
            slxFirmwareHistoryLines.stream().forEach(line -> {
                Matcher matcher = Pattern.compile(FIRMWARE_HISTORY_PATTERN).matcher(line);
                if (matcher.matches() && matcher.groupCount() == 5) {
                    FirmwareHistoryObject firmwareHistoryObject = new FirmwareHistoryObject();
                    firmwareHistoryObject.setDateAndTime(matcher.group(1));
                    firmwareHistoryObject.setDeviceName(matcher.group(2));
                    firmwareHistoryObject.setSlotNumber(matcher.group(3));
                    firmwareHistoryObject.setPId(matcher.group(4));
                    firmwareHistoryObject.setOsVersion(matcher.group(5));
                    firmwareHistoryObjects.add(firmwareHistoryObject);
                }
            });
        }
        return firmwareHistoryObjects;
    }

    @Override
    public Long rebootUpgradedDevice(List<Long> ids) throws ValidationException {
        Long jobId = 0l;
        List<DeviceFirmwareInfo> deviceFirmwareInfos = (List<DeviceFirmwareInfo>) deviceFirmwareInfoRepository.findAll(ids);
        List<DeviceFirmwareInfo> deviceFirmwareInfoList = Lists.newArrayList();
        deviceFirmwareInfos.forEach(deviceFirmwareInfo -> {
            if (deviceFirmwareInfo != null && !deviceFirmwareInfo.getRebootRequired()) {
                DeviceFirmwareInfo firmwareInfo = deviceFirmwareInfo;
                firmwareInfo.setRebootRequired(true);
                firmwareInfo.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                deviceFirmwareInfoList.add(firmwareInfo);
            }
        });

        for (DeviceFirmwareInfo deviceFirmwareInfo : deviceFirmwareInfoList) {
            deviceFirmwareInfoRepository.save(deviceFirmwareInfo);
            jobId = firmwareJobQueue.submit(FirmwareJobTemplate.builder().type(FirmwareJob.Type.DEVICE_RELOAD).deviceId(deviceFirmwareInfo.getDevice().getId())
                    .parentObjectId(deviceFirmwareInfo.getId()).build());
        }
        return jobId;
    }

    @Override
    public Long saveHostInfo(HostInfoRequest hostInfoRequest) {
        ApplicationConstant usernameConstant = featureConstantsRepository.findByName(USERNAME);
        ApplicationConstant passwordConstant = featureConstantsRepository.findByName(PASSWORD);
        ApplicationConstant ipConstant = featureConstantsRepository.findByName(IP);
        if (usernameConstant == null) {
            usernameConstant = new ApplicationConstant();
        }
        usernameConstant.setName(USERNAME);
        usernameConstant.setConstantValue(hostInfoRequest.getUsername());

        if (passwordConstant == null) {
            passwordConstant = new ApplicationConstant();
        }
        passwordConstant.setName(PASSWORD);
        passwordConstant.setConstantValue(hostInfoRequest.getPassword());

        if (ipConstant == null) {
            ipConstant = new ApplicationConstant();
        }

        String ipAddress = hostInfoRequest.getHostIp();
        if (!Strings.isNullOrEmpty(ipAddress)) {
            if (ipAddress.contains(":")) {
                if (!validateIpv6(ipAddress)) {
                    throw new ValidationException("host.server.invalidIp");
                }
            } else if (!validateIpv4(ipAddress)) {
                throw new ValidationException("host.server.invalidIp");
            }
        } else {
            throw new ValidationException("host.server.invalidIp");
        }

        ipConstant.setName(IP);
        ipConstant.setConstantValue(hostInfoRequest.getHostIp());

        List<ApplicationConstant> applicationConstants = Lists.newArrayList();

        applicationConstants.add(usernameConstant);
        applicationConstants.add(passwordConstant);
        applicationConstants.add(ipConstant);
        featureConstantsRepository.save(applicationConstants);
        return ipConstant.getId();
    }

    /**
     * This method validates if the given ip is a valid IPV4
     *
     * @param ip
     * @return boolean
     */
    private boolean validateIpv4(String ip) {
        if (ip != null) {
            Pattern pattern = Pattern.compile(IPV4_PATTERN);
            return pattern.matcher(ip).matches();

        }
        return true;
    }

    private boolean validateIpv6(String ip) {
        if (ip != null) {
            if (ip.contains("::") && ip.split(":").length <= 8) {
                Pattern pattern = Pattern.compile(IPV6_PATTERN_SHORT);
                return pattern.matcher(ip).matches();
            } else if (ip.contains(":") && ip.split(":").length != 8) {
                return false;
            } else {
                Pattern pattern = Pattern.compile(IPV6_PATTERN_LONG);
                return pattern.matcher(ip).matches();
            }
        }
        return true;
    }
}
