package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.DeDupePolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collections;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class SdPolicyRequest {
    private Device device;

    private String name;

    private Set<FilterPolicy> filterPolicies = Collections.emptySet();

    private Set<DeDupePolicy> dedupePolicies = Collections.emptySet();

    private Set<SamplingPolicy> samplingPolicies = Collections.emptySet();
}
