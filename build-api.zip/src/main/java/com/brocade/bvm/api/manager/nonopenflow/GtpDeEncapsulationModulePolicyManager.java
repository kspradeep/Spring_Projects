package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Manager class for GTP deEncapsulation policy
 */
@Named
@Slf4j
public class GtpDeEncapsulationModulePolicyManager extends AbstractModulePolicyManager {

    private static final String SLX_9850 = "SLX9850";

    @Inject
    private GtpDeEncapsulationModulePolicyRepository gtpDeEncapsulationModulePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    private JobQueue jobQueue;

    /**
     * This method is used to create GtpDeEncapsulationModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy) {
        GtpDeEncapsulationModulePolicy gtpDeEncapsulationModulePolicy = modulePolicy.getGtpDeEncapsulationModulePolicy();
        Device device = deviceRepository.findOne(gtpDeEncapsulationModulePolicy.getDevice().getId());
        isValidPolicy(gtpDeEncapsulationModulePolicy, device);

        List<Long> portIds = gtpDeEncapsulationModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Set<Port> ports = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());

        isValidPolicyToCommit(ports, device);

        gtpDeEncapsulationModulePolicy.setPorts(Sets.newHashSet(ports));
        gtpDeEncapsulationModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gtpDeEncapsulationModulePolicy = gtpDeEncapsulationModulePolicyRepository.save(gtpDeEncapsulationModulePolicy);

        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_CREATE : Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_CREATE;

        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(gtpDeEncapsulationModulePolicy.getDevice().getId()).impactedObjectIds(portIds)
                .parentObjectId(gtpDeEncapsulationModulePolicy.getId()).build());

        return jobId;
    }

    /**
     * Validating the GTP DeEncapsulation policy
     *
     * @param policy
     * @param device
     * @return
     */
    protected boolean isValidPolicy(GtpDeEncapsulationModulePolicy policy, Device device) {
        if (policy != null) {
            if (device != null && ((!(device.getType() == Device.Type.SLX || device.getType() == Device.Type.MLXE) || device.getMode() != Device.Mode.PLAIN)) ||
                    (Device.Type.SLX == device.getType() && device.getModel() != null && device.getModel().contains(SLX_9850))) {
                throw new ValidationException("gTPDeEncapsulation.not.supported.device");
            }
            if (policy.getPorts() == null || policy.getPorts().isEmpty()) {
                throw new ValidationException("empty.port.notallowed");
            }
        }
        return true;
    }

    /**
     * This method checks if GtpDeEncapsulationModulePolicy data is valid to commit on the given device
     *
     * @param ports
     * @param device
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(Set<Port> ports, Device device) {
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (ports == null || ports.isEmpty()) {
            throw new ValidationException("empty.port.notallowed");
        }

        if (Device.Type.MLXE == device.getType()) {
            // #1 Check if all participating ports are of either EGRESS type or SERVICE_PORT type
            ports.stream().forEach(port -> {
                if (!(Port.Type.EGRESS == port.getType() || Port.Type.SERVICE_PORT == port.getType())) {
                    log.error("Please select either Egress or Service port.");
                    throw new ValidationException("port.type.serviceOrEgress");
                }
            });
        } else if (Device.Type.SLX == device.getType()) {
            List<Long> portIds = ports.stream().map(ManagedObject::getId).collect(Collectors.toList());
            List<Long> packetTruncationPortIds = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(device.getId(), portIds);
            if (!packetTruncationPortIds.isEmpty()) {
                List<String> portNames = portRepository.findNamesByIds(packetTruncationPortIds);
                String portNameString = portNames.stream().collect(Collectors.joining(", "));
                log.error("A GTP DeEncapsulation policy has already been applied for the selected port(s). " + portNameString);
                throw new ValidationException("A GTP DeEncapsulation policy has already been applied for the selected port(s) " + portNameString + ".");
            }
        }
        return true;
    }

    /**
     * This method checks if GtpDeEncapsulationModulePolicy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    public boolean isPolicyUnChanged(GtpDeEncapsulationModulePolicy oldModulePolicy, GtpDeEncapsulationModulePolicy newModulePolicy) {
        if (oldModulePolicy.getPorts() != null && newModulePolicy.getPorts() != null) {
            Set<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> newPortIds = newModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            if (oldPortIds.size() != newPortIds.size() || !newPortIds.containsAll(oldPortIds)) {
                return false;
            }
        } else {
            throw new ValidationException("policy.ports.invalid");
        }
        return true;
    }

    /**
     * This method is used to delete GtpDeEncapsulationModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        GtpDeEncapsulationModulePolicy gtpDeEncapsulationModulePolicy = gtpDeEncapsulationModulePolicyRepository.findOne(modulePolicyId);
        if (gtpDeEncapsulationModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        Device device = deviceRepository.findOne(gtpDeEncapsulationModulePolicy.getDevice().getId());
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        isValidPolicy(gtpDeEncapsulationModulePolicy, device);
        if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gtpDeEncapsulationModulePolicy.getWorkflowStatus()) {
            throw new ValidationException("gTPDeEncapsulation.delete.policy.in.progress");
        }
        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_DELETE : Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_DELETE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(gtpDeEncapsulationModulePolicy.getDevice().getId()).impactedObjectIds(gtpDeEncapsulationModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to update GtpDeEncapsulationModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicy) {
        if (modulePolicyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        GtpDeEncapsulationModulePolicy gtpDeEncapsulationModulePolicy = modulePolicy.getGtpDeEncapsulationModulePolicy();
        Device device = deviceRepository.findOne(gtpDeEncapsulationModulePolicy.getDevice().getId());
        isValidPolicy(gtpDeEncapsulationModulePolicy, device);

        GtpDeEncapsulationModulePolicy oldModulePolicy = gtpDeEncapsulationModulePolicyRepository.findOne(modulePolicyId);
        if (isPolicyUnChanged(oldModulePolicy, gtpDeEncapsulationModulePolicy)) {
            log.error("gtpDeEncapsulationModulePolicy data is unchanged. Aborting!");
            throw new ValidationException("gTPDeEncapsulation.data.unChanged");
        }

        // Adding newly selected ports as impacted objects
        List<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        List<Long> impactedObjects = Lists.newArrayList();
        gtpDeEncapsulationModulePolicy.getPorts().forEach(newPort -> {
            if (!oldPortIds.contains(newPort.getId())) {
                impactedObjects.add(newPort.getId());
            }
        });

        List<Long> portIds = gtpDeEncapsulationModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Set<Port> ports = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
        isValidPolicyToCommit(ports, device);
        // merging updated data
        oldModulePolicy.setPorts(ports);

        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gtpDeEncapsulationModulePolicyRepository.save(oldModulePolicy);

        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_UPDATE : Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_UPDATE;

        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(gtpDeEncapsulationModulePolicy.getDevice().getId()).impactedObjectIds(impactedObjects)
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover GtpDeEncapsulationModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        GtpDeEncapsulationModulePolicy gtpDeEncapsulationModulePolicy = gtpDeEncapsulationModulePolicyRepository.findOne(modulePolicyId);
        if (gtpDeEncapsulationModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }

        Device device = deviceRepository.findOne(gtpDeEncapsulationModulePolicy.getDevice().getId());
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        isValidPolicy(gtpDeEncapsulationModulePolicy, device);

        if (gtpDeEncapsulationModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("policy.recovery.not.in.error");
        }
        gtpDeEncapsulationModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gtpDeEncapsulationModulePolicyRepository.save(gtpDeEncapsulationModulePolicy);

        Job.Type jobType = Device.Type.SLX == device.getType() ? Job.Type.SLX_GTP_DE_ENCAPSULATION_MODULE_POLICY_ROLLBACK : Job.Type.GTP_DE_ENCAPSULATION_MODULE_POLICY_ROLLBACK;

        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(gtpDeEncapsulationModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }
}
