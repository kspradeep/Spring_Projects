package com.brocade.bvm.api.model;

import com.brocade.bvm.model.exception.UserVisibileException;


public class ValidationException extends UserVisibileException {
    public ValidationException(String messageId) {
        super(messageId);
    }
}
