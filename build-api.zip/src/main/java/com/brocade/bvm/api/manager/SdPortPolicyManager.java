package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;

import java.util.List;

public interface SdPortPolicyManager {
    /**
     * return saved/updated SD port
     */
    Long savePort(Long deviceId, List<EgressPort> ports);

    Long commitPort(Device device, List<EgressPort> ports);

    Long deletePort(Device device, List<EgressPort> ports);

    Long rollbackPort(Device device, List<EgressPort> ports);
}
