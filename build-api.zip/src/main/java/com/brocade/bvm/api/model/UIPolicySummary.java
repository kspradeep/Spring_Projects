package com.brocade.bvm.api.model;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSortedSet;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
public class UIPolicySummary {

    Set<UIPolicySet> policySets = new HashSet<>();

    public UIPolicySummary(Set<Policy> policies) {
        if (policies != null && !policies.isEmpty()) {
            policies.stream().forEach(policy -> {
                UIPolicySet eachSet = new UIPolicySet(policy);
                policySets.add(eachSet);
            });
        }
    }
}

@Getter
@Setter
class UIPolicySet {

    WorkflowParticipant.WorkflowStatus workflowStatus;
    Long policyId;
    String policyName;
    String devicePolicyName;
    String auditName;
    ImmutableSet<Port> ingressPorts;
    ImmutableSet<PortGroup> ingressPortGroups;
    private Long fieldOffset1;
    private Long fieldOffset2;
    private Long fieldOffset3;
    private Long fieldOffset4;
    private boolean isLoopbackEnabled;
    private String sourceMacTag;
    private String destinationMacTag;
    private String gtpProfile;
    private boolean createdFromSd;
    private boolean flexMatchEnabled;
    private boolean isGridPolicy = false;
    Set<UIPolicy> policies = new HashSet<>();

    public UIPolicySet(Policy policy) {
        this.workflowStatus = policy.getWorkflowStatus();
        this.policyId = policy.getId();
        this.policyName = policy.getName();
        this.auditName = policy.getAuditFlowName();
        if (policy.isLegacy() || policy.isCustomRmName()) {
            this.devicePolicyName = policyName;
        } else {
            this.devicePolicyName = "rm_" + policy.getId();
        }

        ImmutableSortedSet<Flow> flows = policy.getFlows();
        if (flows != null && !flows.isEmpty()) {
            Flow flow = flows.first();
            this.ingressPortGroups = flow.getIngressPortGroups();
            this.ingressPorts = flow.getIngressPorts();
            this.sourceMacTag = flow.getSourceMacTag();
            this.destinationMacTag = flow.getDestinationMacTag();
            flows.stream().forEach(_flow -> {
                UIPolicy uiPolicy = new UIPolicy(_flow);
                this.policies.add(uiPolicy);
            });
        }
        this.gtpProfile = policy.getGtpProfile() != null ? policy.getGtpProfile().getName() : null;
        this.fieldOffset1 = policy.getFieldOffset1();
        this.fieldOffset2 = policy.getFieldOffset2();
        this.fieldOffset3 = policy.getFieldOffset3();
        this.fieldOffset4 = policy.getFieldOffset4();
        this.isLoopbackEnabled = policy.isLoopbackEnabled();
        this.createdFromSd = policy.isCreatedFromSd();
        this.flexMatchEnabled = !policy.getFlexMatchProfiles().isEmpty();
    }
}

@Getter
@Setter
class UIPolicy {

    Set<Port> egressPorts;
    Set<PortGroup> egressPortGroups;
    ManagedObject packetTruncationInterface;
    ImmutableSet<String> vlans;
    Long flowId = 0L;
    String flowName = null;
    Long l2RulesCount = 0L;
    Long l3RulesCount = 0L;
    Long l3IPV4Count = 0L;
    Long l3IPV6Count = 0L;
    Long l23Count = 0L;
    Long l23IPV4Count = 0L;
    Long l23IPV6Count = 0L;
    Long udaRulesCount = 0L;
    String l2RulesetName = "";
    String l3IPV4RulesetName = "";
    String l3IPV6RulesetName = "";
    String l23IPV4RulesetName = "";
    String l23IPV6RulesetName = "";
    String udaRulesetName = "";
    Integer sequence = 0;
    Boolean isTvfDomain;
    List<TunnelDevicePolicy> tunnelPolicies;

    public UIPolicy(Flow eachFlow) {
        this.flowId = eachFlow.getId();
        this.sequence = eachFlow.getSequence();
        this.flowName = eachFlow.getFlowName();
        this.egressPorts = eachFlow.getEgressPorts();
        this.egressPortGroups = eachFlow.getEgressPortGroups();
        updateCountsForFlow(eachFlow);
        this.vlans = eachFlow.getVlans();
        isTvfDomain = eachFlow.getTvfDomain();
        List<TunnelDevicePolicy> tunnelPolicies = new ArrayList<>();
        eachFlow.getTunnelPolicies().forEach(tunnelDevicePolicy -> {
            TunnelDevicePolicy tunnelPolicy = new TunnelDevicePolicy();
            tunnelPolicy.setName(tunnelDevicePolicy.getName());
            tunnelPolicy.setType(tunnelDevicePolicy.getType());
            tunnelPolicy.setEnabled(tunnelDevicePolicy.isEnabled());
            tunnelPolicies.add(tunnelPolicy);
        });
        this.tunnelPolicies = tunnelPolicies;
        PacketTruncationMapping packetTruncationMapping = eachFlow.getPacketTruncationMapping();
        if (packetTruncationMapping != null) {
            if (packetTruncationMapping.getPort() != null) {
                packetTruncationInterface = packetTruncationMapping.getPort();
            } else if (packetTruncationMapping.getPortGroup() != null) {
                packetTruncationInterface = packetTruncationMapping.getPortGroup();
            }
        }
    }

    private void updateCountsForFlow(Flow eachFlow) {
        eachFlow.getRuleSets().stream().forEach(ruleSet -> {
            if (ruleSet.getType() == RuleSet.Type.L2) {
                l2RulesCount += ruleSet.getRules().size();
                l2RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == RuleSet.Type.L3 && ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                l3RulesCount += ruleSet.getRules().size();
                l3IPV4Count += ruleSet.getRules().size();
                l3IPV4RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == RuleSet.Type.L3 && ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                l3RulesCount += ruleSet.getRules().size();
                l3IPV6Count += ruleSet.getRules().size();
                l3IPV6RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == RuleSet.Type.L23 && ruleSet.getIpVersion() == RuleSet.IpVersion.V4) {
                l23Count += ruleSet.getRules().size();
                l23IPV4Count += ruleSet.getRules().size();
                l23IPV4RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == RuleSet.Type.L23 && ruleSet.getIpVersion() == RuleSet.IpVersion.V6) {
                l23Count += ruleSet.getRules().size();
                l23IPV6Count += ruleSet.getRules().size();
                l23IPV6RulesetName = ruleSet.getName();
            } else if (ruleSet.getType() == RuleSet.Type.UDA) {
                udaRulesCount += ruleSet.getRules().size();
                udaRulesetName = ruleSet.getName();
            }
        });
    }
}
