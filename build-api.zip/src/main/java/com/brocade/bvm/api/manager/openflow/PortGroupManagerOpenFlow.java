package com.brocade.bvm.api.manager.openflow;

import com.brocade.bvm.api.manager.generic.AbstractPortGroupManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.PortGroup;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Named;
import java.util.List;

/**
 * The PortGroupManagerOpenFlow class implements methods related to port group for OpenFlow
 */
@Named
@Slf4j
public class PortGroupManagerOpenFlow extends AbstractPortGroupManager {

    /**
     * This method does nothing for open flow
     *
     * @param portGroup
     * @throws ValidationException
     */
    @Override
    protected void validateAllPortsInPacketSlicing(PortGroup portGroup) throws ValidationException {

    }

    /**
     * This method does validates if the portGroup is used in Open Flow policy as ingress or egress
     *
     * @param portGroupId
     * @throws ValidationException
     */
    @Override
    protected void validatePortGroupIfUsedInPolicy(Long portGroupId, boolean isPortChannel) throws ValidationException {
        //if portgroup is part of ingress which is a case of service port group dont allow
        //if portgroup part of egress then allow
        if (portGroupId != null && !portGroupRepository.findServicePortGroupIsUseInPolicy(portGroupId).isEmpty()) {
            if (isPortChannel) {
                throw new ValidationException("portChannel.operation.notallowed");
            } else {
                throw new ValidationException("portGroup.operation.notallowed");
            }
        }
    }

    protected void validatePortsIfUsedInPolicy(List<Long> portIds, boolean isPortChannel) throws ValidationException {

    }

    @Override
    protected void validatePortsIfUsedInSDPorts(List<Long> portIds) throws ValidationException {

    }

}
