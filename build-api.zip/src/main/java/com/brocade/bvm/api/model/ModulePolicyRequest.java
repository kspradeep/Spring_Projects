package com.brocade.bvm.api.model;

import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.db.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ModulePolicyRequest {

    private LoadBalanceModulePolicy loadBalanceModulePolicy;

    private SlxLoadBalanceModulePolicy slxLoadBalanceModulePolicy;

    private PacketSlicingModulePolicy packetSlicingModulePolicy;

    private PacketStampingModulePolicy packetStampingModulePolicy;

    private HeaderStrippingModulePolicy headerStrippingModulePolicy;

    private PacketLabelingModulePolicy packetLabelingModulePolicy;

    private GtpDeEncapsulationModulePolicy gtpDeEncapsulationModulePolicy;

    private IpPayloadLengthPolicy ipPayloadLengthPolicy;

}

