package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collections;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class SdConfigRequest {
    private Set<IngressPort> sdIngressPorts = Collections.emptySet();
}
