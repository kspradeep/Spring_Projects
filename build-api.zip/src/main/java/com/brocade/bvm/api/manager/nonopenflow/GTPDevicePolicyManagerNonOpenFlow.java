package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractDevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.GTPDevicePolicy;
import com.brocade.bvm.model.db.Job;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The GTPDevicePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover GTPDevicePolicy for NonOpenFlow
 */
@Named
public class GTPDevicePolicyManagerNonOpenFlow extends AbstractDevicePolicyManager {

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private GTPDevicePolicyRepository gtpDevicePolicyRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * This method checks if GTPDevicePolicy data is valid to commit on the given device
     *
     * @param policy
     * @return boolean
     */
    @Override
    protected boolean isValidPolicy(DevicePolicy policy) {
        if (policy != null) {
            GTPDevicePolicy gtpDevicePolicy = (GTPDevicePolicy) policy;
            Device device = deviceRepository.findOne(policy.getDevice().getId());
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("gtp.profile.not.supported.device");
            }
            if (gtpDevicePolicy.getProfileId() == null || gtpDevicePolicy.getProfileId() < GTPDevicePolicy.ID_MIN || gtpDevicePolicy.getProfileId() > GTPDevicePolicy.ID_MAX) {
                throw new ValidationException("gtp.profile.id.invalid");
            }
            if (gtpDevicePolicy.getName() == null) {
                throw new ValidationException("gtp.profile.name.invalid");
            }
        }
        return true;
    }

    /**
     * This method is used to create GTPDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long commitPolicy(DevicePolicy policy) {
        GTPDevicePolicy gtpDevicePolicy = (GTPDevicePolicy) policy;
        isValidPolicy(gtpDevicePolicy);
        isValidPolicyToCommit(gtpDevicePolicy);
        gtpDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gtpDevicePolicy = devicePolicyRepository.save(gtpDevicePolicy);
        Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.GTP_PROFILE_CREATE)
                .deviceId(gtpDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(gtpDevicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method checks if GTPDevicePolicy data is valid to commit on the given device
     *
     * @param gtpDevicePolicy
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(GTPDevicePolicy gtpDevicePolicy) {
        Long id = gtpDevicePolicy.getId();
        Set<Long> ids = new HashSet<>();
        Set<Long> names = new HashSet<>();
        if (id == null) {
            ids.addAll(gtpDevicePolicyRepository.findByDeviceIdAndProfileId(gtpDevicePolicy.getDevice().getId(), gtpDevicePolicy.getProfileId()));
            names.addAll(gtpDevicePolicyRepository.findByDeviceIdAndName(gtpDevicePolicy.getDevice().getId(), gtpDevicePolicy.getName()));
        } else {
            ids.addAll(gtpDevicePolicyRepository.findByDeviceIdAndProfileIdAndIdNotIn(gtpDevicePolicy.getDevice().getId(), gtpDevicePolicy.getProfileId(), id));
            names.addAll(gtpDevicePolicyRepository.findByDeviceIdAndNameAndIdNotIn(gtpDevicePolicy.getDevice().getId(), gtpDevicePolicy.getName(), id));
        }
        // 1. Checking if the given profileId is used by other policies
        if (!ids.isEmpty()) {
            throw new ValidationException("same.id.exists.in.policy");
        }
        // 2. Checking if the given device policy name is used by other policies
        if (!names.isEmpty()) {
            throw new ValidationException("same.name.exists.in.policy");
        }
        return true;
    }

    /**
     * This method is used to update GTPDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long updatePolicy(DevicePolicy policy) {
        GTPDevicePolicy gtpDevicePolicy = (GTPDevicePolicy) policy;
        isValidPolicy(gtpDevicePolicy);
        GTPDevicePolicy oldDevicePolicy = (GTPDevicePolicy) devicePolicyRepository.findOne(gtpDevicePolicy.getId());
        if (oldDevicePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        boolean isSave = false;
        if (isPolicyUnChanged(oldDevicePolicy, gtpDevicePolicy)) {
            if (!oldDevicePolicy.getDescription().equals(gtpDevicePolicy.getDescription())) {
                isSave = true;
            } else {
                throw new ValidationException("gtpDevicePolicy.data.unChanged");
            }
        }

        if (!oldDevicePolicy.getName().equals(gtpDevicePolicy.getName()) || !oldDevicePolicy.getProfileId().equals(gtpDevicePolicy.getProfileId())) {
            // Checking if the current GTPDevicePolicy is used by any policy on the device
            List<Long> policyIds = policyRepository.findByDeviceIdAndGTPProfile(oldDevicePolicy.getDevice().getId(), oldDevicePolicy.getId());
            if (!policyIds.isEmpty()) {
                throw new ValidationException("gtpDevicePolicy.used.inPolicy");
            }

            // Checking if the current GTPDevicePolicy is used by any portGroup on the device
            List<Long> portGroupIds = portGroupRepository.findByDeviceIdAndGTPProfile(oldDevicePolicy.getDevice().getId(), oldDevicePolicy.getId());
            if (!portGroupIds.isEmpty()) {
                throw new ValidationException("gtpDevicePolicy.used.inPortGroup");
            }
        }

        isValidPolicyToCommit(gtpDevicePolicy);

        // Merging updated data
        oldDevicePolicy.setProfileId(gtpDevicePolicy.getProfileId());
        oldDevicePolicy.setName(gtpDevicePolicy.getName());
        oldDevicePolicy.setDescription(gtpDevicePolicy.getDescription());
        oldDevicePolicy.setGTPCTeIdEnabled(gtpDevicePolicy.isGTPCTeIdEnabled());
        oldDevicePolicy.setGTPUInnerL3Enabled(gtpDevicePolicy.isGTPUInnerL3Enabled());
        oldDevicePolicy.setGTPUTeIdEnabled(gtpDevicePolicy.isGTPUTeIdEnabled());
        if (!isSave) {
            oldDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        }
        oldDevicePolicy = devicePolicyRepository.save(oldDevicePolicy);
        Long jobId = oldDevicePolicy.getId();
        if (!isSave) {
            jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.GTP_PROFILE_UPDATE)
                    .deviceId(oldDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                    .parentObjectId(oldDevicePolicy.getId()).build());
        }
        return jobId;
    }

    /**
     * This method checks if GTPDevicePolicy data is updated
     *
     * @param oldDevicePolicy
     * @param newDevicePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(GTPDevicePolicy oldDevicePolicy, GTPDevicePolicy newDevicePolicy) {
        if (newDevicePolicy.getProfileId() != null && !newDevicePolicy.getProfileId().equals(oldDevicePolicy.getProfileId())) {
            return false;
        }
        if (newDevicePolicy.getName() != null && !newDevicePolicy.getName().equals(oldDevicePolicy.getName())) {
            return false;
        }
        if (oldDevicePolicy.isGTPCTeIdEnabled() != newDevicePolicy.isGTPCTeIdEnabled()) {
            return false;
        }
        if (oldDevicePolicy.isGTPUInnerL3Enabled() != newDevicePolicy.isGTPUInnerL3Enabled()) {
            return false;
        }
        if (oldDevicePolicy.isGTPUTeIdEnabled() != newDevicePolicy.isGTPUTeIdEnabled()) {
            return false;
        }
        return true;
    }

    /**
     * This method is used to delete GTPDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(Long policyId) {
        GTPDevicePolicy devicePolicy = (GTPDevicePolicy) devicePolicyRepository.findOne(policyId);
        // Validate
        // 1. DevicePolicy present in DB
        if (devicePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(devicePolicy);
        // 2. Checking if the current GTPDevicePolicy is used by any policy on the device
        List<Long> policyIds = policyRepository.findByDeviceIdAndGTPProfile(devicePolicy.getDevice().getId(), devicePolicy.getId());
        if (!policyIds.isEmpty()) {
            throw new ValidationException("gtpDevicePolicy.used.inPolicy");
        }
        // 3. Checking if the current GTPDevicePolicy is used by any portGroup on the device
        List<Long> portGroupIds = portGroupRepository.findByDeviceIdAndGTPProfile(devicePolicy.getDevice().getId(), devicePolicy.getId());
        if (!portGroupIds.isEmpty()) {
            throw new ValidationException("gtpDevicePolicy.used.inPortGroup");
        }
        // 4. DevicePolicy not in active state.
        if (WorkflowParticipant.WorkflowStatus.SUBMITTED == devicePolicy.getWorkflowStatus()) {
            throw new ValidationException("gtp.profile.delete.policy.in.progress");
        }
        Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.GTP_PROFILE_DELETE)
                .deviceId(devicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(devicePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to recover GTPDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        GTPDevicePolicy gtpDevicePolicy = gtpDevicePolicyRepository.findOne(policyId);
        if (gtpDevicePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(gtpDevicePolicy);
        if (gtpDevicePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("policy.recovery.not.in.error");
        }
        gtpDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        gtpDevicePolicyRepository.save(gtpDevicePolicy);
        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.GTP_PROFILE_ROLLBACK)
                .deviceId(gtpDevicePolicy.getDevice().getId()).impactedObjectIds(Collections.emptyList())
                .parentObjectId(gtpDevicePolicy.getId()).build());
        return jobId;
    }
}
