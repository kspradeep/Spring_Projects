package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.controller.SdPolicyController;
import com.brocade.bvm.api.manager.SdInterfaceManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.PairedDevice;
import com.brocade.bvm.model.db.sessiondirector.ProfileMapping;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@Named(value = "SdActiveInterfaceManager")
public class SdActiveInterfaceManager implements SdInterfaceManager {

    @Inject
    private ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    private ProfileRepository profileRepository;

    @Inject
    private ProfileInterfaceMappingRepository profileInterfaceMappingRepository;

    @Inject
    private FilterPolicyRepository filterPolicyRepository;

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    private JobQueue jobQueue;

    @Override
    public Long saveOrCommitActiveInterface(ActiveInterface activeInterface, Device device, String action) {
        activeInterface.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        Long id = -1l;
        if (action == null || action.equalsIgnoreCase(SdPolicyController.SAVE) || action.equalsIgnoreCase(SdPolicyController.UPDATE)) {
            id = saveInterface(activeInterface, device);
        } else if (action.equalsIgnoreCase(SdPolicyController.COMMIT)) {
            id = commitInterface(activeInterface, device);
        } else {
            throw new ValidationException("interface.action.invalid");
        }
        return id;
    }

    /**
     * This method is used for saving interface
     *
     * @param activeInterface
     * @return
     */
    private Long saveInterface(ActiveInterface activeInterface, Device device) {
        isValidInterface(activeInterface, device);
        activeInterfaceRepository.save(activeInterface);
        return activeInterface.getId();
    }

    /**
     * This method is used for committing active interface
     *
     * @param activeInterface
     * @param device
     * @return
     */
    private Long commitInterface(ActiveInterface activeInterface, Device device) {
        isInProgress(activeInterface, device, "interface.operation.inprogress");
        Job.Type jobType = activeInterface.getId() == null ? Job.Type.SD_ACTIVE_INTERFACE_CREATE : Job.Type.SD_ACTIVE_INTERFACE_UPDATE;
        long interfaceId = -1;
        interfaceId = saveInterface(activeInterface, device);
        Long jobId = jobQueue.submit(JobTemplate.builder().type(jobType).deviceId(device.getId())
                .parentObjectId(interfaceId).impactedObjectIds(Lists.newArrayList(activeInterface.getId())).build());
        return jobId;
    }

    /**
     * This method is used for deleting an interface
     *
     * @param activeInterfaces
     * @param device
     * @return
     */
    public long deleteInterface(List<ActiveInterface> activeInterfaces, Device device) {
        long jobId = -1;
        if (!activeInterfaces.isEmpty()) {
            List<Long> impactedObjectIds = new ArrayList<>();
            for (ActiveInterface activeInterface : activeInterfaces) {
                impactedObjectIds.add(activeInterface.getId());
                isInProgress(activeInterface, device, "interface.operation.inprogress");
            }
            jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.SD_ACTIVE_INTERFACE_DELETE).deviceId(device.getId())
                    .impactedObjectIds(impactedObjectIds).build());
        }
        return jobId;
    }

    /**
     * This method is used to add validate whether Interface is valid or not.
     *
     * @param activeInterface
     */
    private void isValidInterface(ActiveInterface activeInterface, Device device) {
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(device.getId());
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(device.getId());
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", device.getId());
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", device.getId());
            throw new ValidationException("sd.profile.not.configured");
        }

        List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findAllActiveInterfaceByDeviceIdAndInterfaceId(device.getId(), activeInterface.getProfileInterfaceMapping().getId());
        if (!activeInterfaces.isEmpty() && activeInterface.getId() == null) {
            throw new ValidationException("interface.already.configured");
        }
        if (activeInterface.getName() == null) {
            throw new ValidationException("interface.name.not.valid");
        }
        if (activeInterface.getDeDupePolicy() != null && ActiveInterface.VOLTE.equals(activeInterface.getProfileInterfaceMapping().getName())) {
            throw new ValidationException("dedupe.not.allowed.in.volte");
        }

        if (activeInterface.getFilterPolicy() != null) {
            FilterPolicy filterPolicy = filterPolicyRepository.findOne(activeInterface.getFilterPolicy().getId());
            if (!activeInterface.getProfileInterfaceMapping().getName().equalsIgnoreCase(filterPolicy.getTrafficType())) {
                throw new ValidationException("trafficType.different.in.filterPolicy");
            }
        }

        if (activeInterface.getProfileInterfaceMapping() == null) {
            throw new ValidationException("interface.is.missing");
        }
    }

    @Override
    public Map<String, Set<ActiveInterface>> getActiveInterfaces(ActiveInterface activeInterface, Device device) {
        return null;
    }

    /**
     * @param activeInterface
     * @param device
     * @param operation
     */
    protected void isInProgress(ActiveInterface activeInterface, Device device, String operation) {
        List<ActiveInterface> inProgressOrErrorPoliciesOnDevice = activeInterfaceRepository
                .findByDeviceAndInWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
            throw new ValidationException(operation);
        }
    }
}
