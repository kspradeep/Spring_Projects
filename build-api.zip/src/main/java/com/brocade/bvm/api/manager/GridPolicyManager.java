package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.grid.GridPolicySet;

import java.util.Set;

public interface GridPolicyManager {

    Long saveGridPolicy(GridPolicySet gridPolicySet);

    Long commitGridPolicy(GridPolicySet gridPolicySet);

    Long deleteGridPolicy(Long policyId);

    Long rollbackGridPolicy(Long policyId);

    void updatePath(Long pathId);

    void updateFailedPoliciesManually(Long policySetId);

    void abortGridPolicy(GridPolicySet gridPolicySet);
}
