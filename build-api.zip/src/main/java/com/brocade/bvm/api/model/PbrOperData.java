package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.Sets;
import lombok.Getter;

import java.util.Set;

@Getter
public class PbrOperData {

    @JsonProperty
    private String ifName;

    @JsonProperty
    private String aclName;

    @JsonProperty
    private Long numberOfRules;

    @JsonProperty
    private Set<ACLResponse> counters = Sets.newHashSet();
}
