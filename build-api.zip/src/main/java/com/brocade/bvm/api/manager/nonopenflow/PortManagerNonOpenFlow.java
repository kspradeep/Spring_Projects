package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractPortManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.MPLSDevicePolicyRepository;
import com.brocade.bvm.dao.PacketSlicingModulePolicyRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.Port.AdminStatus;
import com.brocade.bvm.model.db.Port.Mode;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The PortManagerNonOpenFlow class implements methods related to port for NonOpenFlow
 */
@Named
@Slf4j
public class PortManagerNonOpenFlow extends AbstractPortManager {

    @Inject
    private PortRepository portRepository;

    @Inject
    private PacketSlicingModulePolicyRepository packetSlicingModulePolicyRepository;

    @Inject
    private MPLSDevicePolicyRepository mplsDevicePolicyRepository;

    @Override
    protected boolean isPortTypeJobRequired() {
        return true;
    }

    /**
     * This method used to find the applicable ports, whose admin status is not same as the selected admin status
     *
     * @param portIds
     * @param status
     * @param mode
     * @throws ValidationException
     */
    @Override
    protected List<Port> filterAdminPorts(List<Long> portIds, AdminStatus status, Mode mode) {
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .filter(port -> (port.getAdminStatus() != status)).collect(Collectors.toList());
        return applicablePorts;
    }

    protected void isValidForAdminStatus(List<Long> portIds) {
        return;
    }

    /**
     * This method validates if all the selected ports are qualified for type change
     *
     * @param deviceId
     * @param portIds
     * @throws ValidationException
     */
    protected void isValidForTypeChange(Long deviceId, List<Long> portIds) {
        List<Long> policyIds = packetSlicingModulePolicyRepository.findPoliciesByEgressPorts(portIds);
        if (policyIds != null && policyIds.size() > 0) {
            log.error("Selected ports are used Egress in Packet Slicing Policy, Aborting!");
            throw new ValidationException("port.operation.usedinPSPolicy");
        }

        List<Long> mplsPolicyIds = mplsDevicePolicyRepository.findByEgressPort(deviceId, portIds);
        if (!mplsPolicyIds.isEmpty()) {
            log.error("Selected ports are used in MPLS Policy as Egress, Aborting!");
            throw new ValidationException("port.operation.usedInMPLS");
        }

        mplsPolicyIds = mplsDevicePolicyRepository.findByIngressPort(deviceId, portIds);
        if (!mplsPolicyIds.isEmpty()) {
            log.error("Selected ports are used in MPLS Policy as Ingress, Aborting!");
            throw new ValidationException("port.operation.usedInMPLS");
        }

    }

    /**
     * This method validates and sets the line-speed for interface(s)
     *
     * @param deviceId
     * @param portIds
     * @param lineSpeed
     * @throws ValidationException
     */
    public long updatePortSpeed(Long deviceId, List<Long> portIds, Long lineSpeed){
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .collect(Collectors.toList());

        //Validate
        //1. WorkflowStatus
        if (applicablePorts.stream().anyMatch(port -> {

            return port.getWorkflowStatus() != null && port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR;})) {
            throw new ValidationException("port.speed.notallowed");
        }

        applicablePorts.stream().forEach(port -> {
            port.setLineSpeed(lineSpeed);
        });

        portRepository.save(applicablePorts);
        long jobId = 0; // Return 0 if no job is created
        Job.Type jobType = Job.Type.PORT_SPEED_UPDATE;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());

        return jobId;
    }
}
