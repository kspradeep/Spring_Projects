//package com.brocade.bvm.api.validation;
//
//import com.brocade.bvm.api.db.beans.Lag;
//import com.brocade.bvm.api.db.beans.LagInterfaceMap;
//import com.brocade.bvm.api.model.db.NetworkNode;
//import com.brocade.bvm.api.model.db.NetworkInterface;
//import com.brocade.bvm.dao.PortGroupRepository;
//import com.brocade.bvm.dao.PortRepository;
//import com.brocade.bvm.outbound.stablenet.StablenetConnection;
//import com.brocade.bvm.outbound.stablenet.StablenetMeasurementService;
//import com.brocade.bvm.outbound.stablenet.model.DeviceVO;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.env.Environment;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Service;
//import org.springframework.validation.Errors;
//import org.springframework.validation.Validator;
//
//import javax.inject.Inject;
//import javax.ws.rs.core.Response;
//import javax.xml.bind.JAXB;
//import java.io.StringReader;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//@Slf4j
//@Service
//@NoArgsConstructor
//@Getter
//@Setter
//public class LagValidator implements Validator {
//
//    private Operations operationtype;
//    private String deviceId;
//    private Lag lag;
//    private Errors errors;
//
//    /** application/xml | application/json */
//    private String acceptType = MediaType.APPLICATION_XML.toString();
//    private String baseUrl;
//    private String resourceUrl;
//
//    @Autowired
//    private PortGroupRepository portGroupRepository;
//
//    @Autowired
//    private PortRepository portRepository;
//
//    @Autowired
//    private Environment env;
//
//    @Inject
//    private StablenetMeasurementService deviceUtility;
//
//    @Inject
//    private StablenetConnection stablenetConnection;
//
//    @Override
//    public boolean supports(Class<?> clazz) {
//        // TODO Auto-generated method stub
//        return false;
//    }
//
//    @Override
//    public void validate(Object target, Errors errors) {
//        if (!(target != null && target instanceof Lag)) {
//            log.error("Invalid Lag instance Passed");
//            errors.reject("10006", "Invalid Lag Instance. ");
//            return;
//        }
//
//        this.lag = (Lag) target;
//        this.errors = errors;
//
//        switch (operationtype) {
//        case Create:
//            /*
//             * ValidatorUtility.isNull(lag.getId(), errors, "Lag Id");
//             * ValidatorUtility.notNull(lag.getName(), errors, "Lag Name");
//             * ValidatorUtility.checkStringNumber(lag.getPrimaryPort(), 0,
//             * 65535, errors, "Primary Port");
//             * ValidatorUtility.notNull(lag.getDeviceId(), errors,
//             * "Lag Device Id"); ValidatorUtility.notNull(lag.getDeviceName(),
//             * errors, "Lag Device Name");
//             * ValidatorUtility.notNull(lag.getDeviceType(), errors,
//             * "Lag Device Type");
//             * ValidatorUtility.listContainsNullOrEmptyValue(lag.getEgressPorts(
//             * ), errors, "Egress Ports");
//             */
//            getDeviceDetails();
//            areEgressesInUse();
//            checklagNameAlreadyPresent();
//            break;
//        case Update:
//            getDeviceDetails();
//            areEgressesInUse();
//            onUpdateValidatePortGroupName(lag);
//            break;
//        default:
//
//            break;
//
//        }
//
//    }
//
//    public void getDeviceDetails() {
//        this.deviceId = String.valueOf(lag.getDeviceId());
//        String resourceUrl = env.getProperty("stablenet.resource-url.device.get");
//        Response res = stablenetConnection.get(resourceUrl, deviceId);
//        if (res != null) {
//            log.debug("Status recieved is {}", res.getStatus());
//            if (res.getStatus() == 200) {
//                DeviceVO deviceVO = JAXB.unmarshal(new StringReader(res.readEntity(String.class)), DeviceVO.class);
//                if (deviceVO != null && deviceVO.getModules() != null && deviceVO.getModules().getModule() != null && deviceVO.getInterfaces() != null
//                                && deviceVO.getInterfaces().getInterface() != null) {
//                    Set<String> authPortNames = null; //deviceUtility.getDeviceMeasurements(deviceVO.getObid(), true);
//                    Set<String> egressPort = lag.getEgressPorts();
//                    if (egressPort == null) {
//                        errors.reject("10104", "Invalid Input Lag Object.");
//                        return;
//                    }
//                    if (authPortNames != null && !authPortNames.containsAll(egressPort)) {
//                        errors.reject("10000", "User dosent have permission on the ports of Lag.");
//                    }
//                } else {
//                    log.info("Error while fetching device details");
//                    errors.reject("10001", "Error while fetching device details");
//                }
//            } else {
//                log.info(String.format("Device with Id %s Not found ", deviceId));
//                errors.reject("10002", String.format("Device with Id %s Not found ", deviceId));
//            }
//        } else {
//            log.error("Response is null");
//            errors.reject("10003", "Response is null for Url");
//        }
//    }
//
//    private void areEgressesInUse() {
//        int preSize = 0;
//        int postSize = 0;
//        List<LagInterfaceMap> lim = null;
////        if (operationtype == Operations.Create) {
////            lim = portGroupRepository.findByDeviceIdAndPortIn(lag.getDeviceId(), lag.getEgressPorts());
////        } else {
////            Lag oldlag = lagRepository.findByParentId(lag.getId());
////            if (oldlag != null) {
////                lim = portGroupRepository.findByDeviceIdAndPortInAndLagNameNotIn(lag.getDeviceId(), lag.getEgressPorts(), oldlag.getName());
////            } else {
////                errors.reject("10100", "Lag Details Not found in the Lag Id.");
////                return;
////            }
////        }
//        if (!lim.isEmpty()) {
//            errors.reject("10101", "Egress Ports Already in Use by other lags");
//            return;
//        }
//
//        Iterable<NetworkInterface> networkInterfaces = null; //portRepository.findByDeviceIdAndEgressAndPolicy(lag.getDeviceId());
//        Set<String> policyEgressList = new HashSet<String>();
//        for (NetworkInterface networkInterface : networkInterfaces) {
//            policyEgressList.add(networkInterface.getName());
//        }
//
//        preSize = policyEgressList.size();
//        policyEgressList.removeAll(lag.getEgressPorts());
//        postSize = policyEgressList.size();
//        if (preSize != 0 && preSize != postSize) {
//            errors.reject("10102", "Egress Ports Already in Use by other policies");
//            return;
//        }
//
//    }
//
//    public void checklagNameAlreadyPresent() {
//        NetworkNode networkDevice = new NetworkNode();
//        networkDevice.setId(lag.getDeviceId());
////        Lag oldLag = lagRepository.findByNameAndDevice(lag.getName(), networkDevice);
////        if (oldLag != null) {
////            errors.reject("10103", "Lag by Name Already Exists.");
////        }
//    }
//
//    private void onUpdateValidatePortGroupName(Lag lag) {
////        Lag lagInDB = lagRepository.findByParentId(lag.getId());
////        if (!lag.getName().equals(lagInDB.getName())) {
////            checklagNameAlreadyPresent();
////        }
//    }
//}
