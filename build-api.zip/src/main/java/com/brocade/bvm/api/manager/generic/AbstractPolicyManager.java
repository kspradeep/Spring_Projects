package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.PolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.api.utility.GenericPolicyComparator;
import com.brocade.bvm.api.utility.PolicyValidator;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridClusterRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The AbstractPolicyManager class implements methods to perform policy create/update/delete/recover on the selected device
 */
@Slf4j
public abstract class AbstractPolicyManager implements PolicyManager {

    private static final long MIN_OFFSET = -1;
    private static final long MAX_OFFSET = 124;
    private static final long MIN_SLX_9850_OFFSET = 0;
    private static final long MAX_SLX_9850_OFFSET = 63;

    protected static final String MASK_HEX_PATTERN = "^([Ff0]{0,8})$";
    protected static final String VALUE_HEX_PATTERN = "^([A-Fa-f0-9]{0,8})$";
    protected static final String VALUE_DECIMAL_PATTERN = "^([\\d]+)$";

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    protected RuleRepository ruleRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    protected JobRepository jobRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private GTPDevicePolicyRepository gtpDevicePolicyRepository;

    @Inject
    private TunnelDevicePolicyRepository tunnelDevicePolicyRepository;

    @Inject
    protected PolicyHistoryRepository policyHistoryRepository;

    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private ReservedVlanDevicePolicyRepository reservedVlanDevicePolicyRepository;

    @Inject
    private FlowEgressManagedObjectRepository flowEgressManagedObjectRepository;

    @Inject
    protected PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private RuleSetRepository ruleSetRepository;

    @Inject
    private GenericHelper genericHelper;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private FlexMatchProfileRepository flexMatchProfileRepository;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private GenericPolicyComparator genericPolicyComparator;

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    protected static final String RULE_SET_NAME_FORMAT = "acl_%s_%s_seq_%s_%s";
    private static final String IPV6_PATTERN1 = "^(((?=(?>.*?::)(?!.*::)))(::)?([0-9A-F]{1,4}::?){0,5}|([0-9A-F]{1,4}:){6})(\\2([0-9A-F]{1,4}(::?|$)){0,2}|((25[0-5]|(2[0-4]|1\\d|[1-9])?\\d)(\\.|$)){4}|[0-9A-F]{1,4}:[0-9A-F]{1,4})(?<![^:]:|\\.)\\z";
    private static final String IPV6_PATTERN2 = "^((:|[0-9a-fA-F]{0,4}):)([0-9a-fA-F]{0,4}:){0,5}((([0-9a-fA-F]{0,4}:)?(:|[0-9a-fA-F]{0,4}))|(((25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9]?[0-9])))(/(([0-9])|([0-9]{2})|(1[0-1][0-9])|(12[0-8])))$";
    private static final String IPV6_PATTERN3 = "^(((?=(?>.*?::)(?!.*::)))(::)?([0-9A-F]{1,4}::?){0,5}|([0-9A-F]{1,4}:){6})(\\2([0-9A-F]{1,4}(::?|$)){0,2}|((25[0-5]|(2[0-4]|1[0-9]|[1-9])?[0-9])(\\.|$)){4}|[0-9A-F]{1,4}:[0-9A-F]{1,4})(?<![^:]:)(?<!\\.)\\z";
    private static final String IPV6_PATTERN4 = "^\\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(\\.(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}))|:)))(%.+)?\\s*$";
    private static final String IPV6_PATTERN5 = "^(?:(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){6})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:::(?:(?:(?:[0-9a-fA-F]{1,4})):){5})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){4})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,1}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){3})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,2}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:(?:[0-9a-fA-F]{1,4})):){2})(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,3}(?:(?:[0-9a-fA-F]{1,4})))?::(?:(?:[0-9a-fA-F]{1,4})):)(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,4}(?:(?:[0-9a-fA-F]{1,4})))?::)(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9]))\\.){3}(?:(?:25[0-5]|(?:[1-9]|1[0-9]|2[0-4])?[0-9])))))))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,5}(?:(?:[0-9a-fA-F]{1,4})))?::)(?:(?:[0-9a-fA-F]{1,4})))|(?:(?:(?:(?:(?:(?:[0-9a-fA-F]{1,4})):){0,6}(?:(?:[0-9a-fA-F]{1,4})))?::))))$";
    private static final String MLXE_ALLOWED_SPECIAL_CHARACTERS = "\\@\\#\\$\\%\\&\\*\\(\\)\\+\\{\\}\\[\\]\\<\\>\\=\\-\\\\\\/\\:\\;\\~\\^\\.!`";
    private static final String MLXE_POLICY_NAME_PATTERN = "^([0-9 " + MLXE_ALLOWED_SPECIAL_CHARACTERS + "]*)([a-zA-Z_]+)([0-9a-zA-Z_" + MLXE_ALLOWED_SPECIAL_CHARACTERS + "]*)$";


    private static final String MLXE_RULESET_NAME_PATTERN = "^[\\p{Alnum}][\\w" + MLXE_ALLOWED_SPECIAL_CHARACTERS + "]*";

    private Pattern pattern1 = Pattern.compile(IPV6_PATTERN1);
    private Pattern pattern2 = Pattern.compile(IPV6_PATTERN2);
    private Pattern pattern3 = Pattern.compile(IPV6_PATTERN3);
    private Pattern pattern4 = Pattern.compile(IPV6_PATTERN4);
    private Pattern pattern5 = Pattern.compile(IPV6_PATTERN5);
    private Pattern slxPolicyNamePattern = Pattern.compile(Policy.SLX_POLICY_NAME_PATTERN);
    private Pattern slxRulesetNamePattern = Pattern.compile(RuleSet.SLX_RULESET_NAME_PATTERN);
    private Pattern mlxeRulesetNamePattern = Pattern.compile(MLXE_RULESET_NAME_PATTERN);
    private Pattern mlxePolicyNamePattern = Pattern.compile(MLXE_POLICY_NAME_PATTERN);

    private static final Integer TVF_DOMAIN_MIN = 1;
    private static final Integer TVF_DOMAIN_MAX = 4096;


    private static final String MLXE_POLICY_NAME_ERROR_MESSAGE = "Invalid Policy Set name!$" +
            "Policy Set name:$" +
            "1.\tCan contain up to 80 alphanumeric characters, and must include a letter or an underscore$" +
            "2.\tCannot include spaces, but can include these special characters along with character dollar: %@\\/#%*&~`^()_+{}[]<>-=";

    private static final String MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE = "%s %s is not marked as %s";
    private static final String MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE = "%s %s are not marked as %s";
    private static final String EMPTY_INTERFACE_ERROR_MESSAGE_FOR_SINGLE = "%s %s does not exist.";
    private static final String EMPTY_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE = "%s %s do not exist.";
    private static final String MISMATCH_PORTGROUP_ERROR_MESSAGE = "- Mismatch of ports for Port Group %s. Expected ports: %s.";
    private static final String MISMATCH_PORTCHANNEL_ERROR_MESSAGE = "- Mismatch of ports for Port Channel %s. Expected ports: %s.";
    private static final String MISMATCH_PRIMARY_PORT_ERROR_MESSAGE = "- Mismatch of primary port for Port Group %s. Expected primary port: %s.";

    /**
     * This method is used to create/update policy on the given device
     *
     * @param policy
     * @return Long This returns jobId
     */
    public Long commitPolicy(Policy policy, boolean isStandalone) throws ValidationException {

        setPortsAndPortGroupsInPolicy(policy);
        isValidPolicyToCommit(policy, isStandalone);
        if (policy.isCreatedFromSd()) {
            //update ruleset names only for policy created from SD
            constructAndUpdateRuleSetNames(policy);
        }

        boolean isNew = false;
        long jobId = -1;
        // check if policy exists
        if (policy.getId() == null) {
            savePolicyObject(policy, isStandalone, true);
            isNew = true;
        }
        Policy policyInDb = policyRepository.findOne(policy.getId());
        if (policyInDb != null) {
            Job.Type type = Job.Type.POLICY_CREATE;
            if (!isNew) {
                WorkflowStatus existingWorkflowStatus = policyInDb.getWorkflowStatus();
                savePolicyObject(policy, isStandalone, true);
                Policy oldPolicyFromHistory = getPolicyNameFromHistory(policyInDb, Lists.newArrayList(WorkflowStatus.ACTIVE, WorkflowStatus.ERROR, WorkflowStatus.WARNING));
                if (oldPolicyFromHistory != null) {
                    if (WorkflowStatus.ACTIVE == oldPolicyFromHistory.getWorkflowStatus() || WorkflowStatus.WARNING == oldPolicyFromHistory.getWorkflowStatus()) {
                        type = Job.Type.POLICY_UPDATE;
                    } else if (WorkflowStatus.ERROR == existingWorkflowStatus && (policyInDb.isLegacy() || getPolicyNameFromHistory(policyInDb, Lists.newArrayList(WorkflowStatus.ACTIVE, WorkflowStatus.WARNING)) != null)) {
                        type = Job.Type.POLICY_UPDATE;
                    }
                }
            }
            policy = policyRepository.findOne(policy.getId());
            // get all flows ids in a policy
            List<Long> impactedObjectIds = Collections.emptyList();
            jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(policy.getDevice().getId())
                    .parentObjectId(policy.getId()).impactedObjectIds(impactedObjectIds).build());
            return jobId;
        }
        throw new ValidationException("Invalid policy Id!");
    }

    /**
     * This method is used to create/update policy in BVM database
     *
     * @param policyToSave
     * @param isStandalone
     * @return Long This returns policyId
     */
    public Long savePolicy(Policy policyToSave, boolean isStandalone) throws ValidationException {
        return savePolicyObject(policyToSave, isStandalone, false);
    }

    /**
     * This method is used to create/update policy in BVM database
     *
     * @param policyToSave
     * @param isStandalone
     * @return Long This returns policyId
     */
    public Long savePolicyObject(Policy policyToSave, boolean isStandalone, boolean isInternal) throws ValidationException {
        isPolicyNameValid(policyToSave.getName(), policyToSave.getDevice());
        isFlowPriorityValid(policyToSave);
        isVLanValid(policyToSave);
        isValidForUda(policyToSave);
        isRuleSetValid(policyToSave, isInternal);

        setPortsAndPortGroupsInPolicy(policyToSave);
        updatePacketTruncationMapping(policyToSave);

        // populate the policy with db entities
        if (policyToSave.getId() != null) {
            // get existing policy and merge the policy object
            Policy existingPolicy = policyRepository.findOne(policyToSave.getId());
            // merge policy attributes
            if (existingPolicy != null) {
                if (WorkflowStatus.SUBMITTED == existingPolicy.getWorkflowStatus()) {
                    throw new ValidationException("Cannot commit policy as another policy creation is in progress. Please try after sometime.");
                }
                // merge flows/ruleset/rules
                mergePolicies(existingPolicy, policyToSave);
                policyToSave = existingPolicy;
                isValidPolicyToUpdate(policyToSave, isStandalone);
            } else {
                throw new ValidationException("Invalid policy Id!");
            }

        } else {
            addFlowEgressToPolicy(policyToSave);
            // validate the policy based on openflow/non open flow
            isValidPolicyToSave(policyToSave, isStandalone);
        }
        if (policyToSave.getGridPolicySetId() == null) {
            generateAndSetTvfDomainIds(policyToSave);
        }
        policyToSave.setWorkflowStatus(WorkflowStatus.DRAFT);
        // save policy in DB
        try {
            policyToSave = policyRepository.save(policyToSave);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return policyToSave.getId();
    }

    /**
     * This method is used to generate tvf-domain id for SLX classic device
     *
     * @param policyToSave
     */
    private synchronized void generateAndSetTvfDomainIds(Policy policyToSave) {
        Device device = deviceRepository.findById(policyToSave.getDevice().getId());
        if (device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN) {
            List<String> existingTvfDomainIds = reservedVlanDevicePolicyRepository.findVlanIdsByDeviceId(device.getId());

            List<String> vlanIdAll = new ArrayList();
            for (long i = TVF_DOMAIN_MIN; i <= TVF_DOMAIN_MAX; i++) {
                vlanIdAll.add(Long.toString(i));
            }
            if (!existingTvfDomainIds.isEmpty()) {
                existingTvfDomainIds.stream().forEach(aLong -> {
                    vlanIdAll.remove(aLong);
                });
            }
            for (Flow eachFlow : policyToSave.getFlows()) {
                if (!eachFlow.getTvfDomain() && (eachFlow.getEgressPorts().size() > 1 || eachFlow.getEgressPortGroups().size() > 1 || (eachFlow.getEgressPorts().size() > 0 && eachFlow.getEgressPortGroups().size() > 0))) {
                    Set<String> tvfDomainIds = Sets.newHashSet();
                    Set<Integer> precedenceAll = new HashSet<>();
                    precedenceAll.addAll(eachFlow.getEgressPorts().stream().map(port -> port.getPrecedence()).collect(Collectors.toSet()));
                    precedenceAll.addAll(eachFlow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrecedence()).collect(Collectors.toSet()));

                    precedenceAll.forEach(precedence -> {
                        Set<FlowEgressManagedObject> flowEgressPorts = eachFlow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getPrecedence() == precedence).collect(Collectors.toSet());
                        Set<FlowEgressManagedObject> flowEgressPortGroups = eachFlow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getPrecedence() == precedence).collect(Collectors.toSet());

                        if ((flowEgressPorts.size() > 1 || flowEgressPortGroups.size() > 1 || (flowEgressPorts.size() > 0 && flowEgressPortGroups.size() > 0))) {
                            String tvf_domainId;
                            List<String> flowTvfDomainIds = flowEgressManagedObjectRepository.findTvfDomainIdsByFlowIdAndPrecedence(eachFlow.getId(), precedence);
                            if (flowTvfDomainIds != null && !flowTvfDomainIds.isEmpty()) {
                                tvf_domainId = flowTvfDomainIds.stream().findAny().get();
                            } else {
                                if (!vlanIdAll.isEmpty()) {
                                    tvf_domainId = vlanIdAll.stream().findFirst().get();
                                    vlanIdAll.remove(tvf_domainId);
                                } else {
                                    throw new ValidationException("Cannot add TVF domain ID as the maximum limit for TVF domain IDs reached.");
                                }
                            }
                            tvfDomainIds.add(tvf_domainId);
                            flowEgressPorts.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(tvf_domainId));
                            flowEgressPortGroups.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(tvf_domainId));
                        } else {
                            flowEgressPorts.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(null));
                            flowEgressPortGroups.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(null));
                        }
                    });
                    if (tvfDomainIds.size() > 0) {
                        eachFlow.setVlans(tvfDomainIds);
                        eachFlow.setTvfDomain(true);
                    } else {
                        eachFlow.setVlans(Sets.newHashSet());
                        eachFlow.setTvfDomain(false);
                    }
                } else if (eachFlow.getTvfDomain()) {
                    Set<Integer> precedenceAll = new HashSet<>();
                    precedenceAll.addAll(eachFlow.getEgressPorts().stream().map(port -> port.getPrecedence()).collect(Collectors.toSet()));
                    precedenceAll.addAll(eachFlow.getEgressPortGroups().stream().map(portGroup -> portGroup.getPrecedence()).collect(Collectors.toSet()));

                    precedenceAll.forEach(precedence -> {
                        Set<FlowEgressManagedObject> flowEgressPorts = eachFlow.getFlowEgressPorts().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getPrecedence() == precedence).collect(Collectors.toSet());
                        Set<FlowEgressManagedObject> flowEgressPortGroups = eachFlow.getFlowEgressPortGroups().stream().filter(flowEgressManagedObject -> flowEgressManagedObject.getPrecedence() == precedence).collect(Collectors.toSet());
                        if (flowEgressPorts.size() + flowEgressPortGroups.size() < 2) {
                            flowEgressPorts.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(null));
                            flowEgressPortGroups.forEach(flowEgressManagedObject -> flowEgressManagedObject.setTvfDomainId(null));
                            eachFlow.setVlans(Sets.newHashSet());
                            eachFlow.setTvfDomain(false);
                        }
                    });
//                    eachFlow.setVlans(Sets.newHashSet());
//                    eachFlow.setTvfDomain(false);
                }
            }
        } else if (device.getType() == Device.Type.MLXE && device.getMode() == Device.Mode.PLAIN) {
            for (Flow eachFlow : policyToSave.getFlows()) {
                ImmutableSet<String> vlans = eachFlow.getVlans();
                if (eachFlow.getTvfDomain() && (eachFlow.getEgressPorts().size() > 0 || eachFlow.getEgressPortGroups().size() > 0) && (vlans != null && !vlans.isEmpty())) {
                    eachFlow.getFlowEgressPorts().stream().forEach(flowEgressManagedObject -> {
                        flowEgressManagedObject.setTvfDomainId(String.join(",", vlans));
                    });
                    eachFlow.getFlowEgressPortGroups().stream().forEach(flowEgressPortGroupManagedObject -> {
                        flowEgressPortGroupManagedObject.setTvfDomainId(String.join(",", vlans));
                    });
                }
            }
        }
    }

    /**
     * This method is used to set full port(s)/portGroup(s)/GTPProfile/TunnelPolicies objects selected in policy by fetching them from BVM database
     *
     * @param policyToSave
     */
    private void setPortsAndPortGroupsInPolicy(Policy policyToSave) {
        Device device = deviceRepository.findById(policyToSave.getDevice().getId());
        // new policy
        policyToSave.setDevice(device);
        if (policyToSave.getGtpProfile() != null) {
            policyToSave.setGtpProfile(gtpDevicePolicyRepository.findOne(policyToSave.getGtpProfile().getId()));
        }
        // populate Device
        SortedSet<Flow> flows = new TreeSet<>();
        for (Flow flow : policyToSave.getFlows()) {
            //ingress
            Set<Long> portIds = flow.getIngressPorts().parallelStream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> portGroupIds = flow.getIngressPortGroups().parallelStream().map(PortGroup::getId)
                    .collect(Collectors.toSet());
            List<Port> portsFromDB = (List<Port>) portRepository.findAll(portIds);
            List<PortGroup> portGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(portGroupIds);
            flow.removeIngressPorts(flow.getIngressPorts());
            flow.removeIngressPortGroups(flow.getIngressPortGroups());
            flow.addIngressPortGroups(Sets.newHashSet(portGroupsFromDB));
            flow.addIngressPorts(Sets.newHashSet(portsFromDB));

            //egress
            portIds = flow.getEgressPorts().parallelStream().map(Port::getId).collect(Collectors.toSet());
            portGroupIds = flow.getEgressPortGroups().parallelStream().map(PortGroup::getId)
                    .collect(Collectors.toSet());
            portsFromDB = (List<Port>) portRepository.findAll(portIds);
            portGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(portGroupIds);
            flow.removeEgressPorts(flow.getEgressPorts());
            flow.removeEgressPortGroups(flow.getEgressPortGroups());
            flow.addEgressPortGroups(Sets.newHashSet(portGroupsFromDB));
            flow.addEgressPorts(Sets.newHashSet(portsFromDB));
            if (!flow.getTunnelPolicies().isEmpty()) {
                List<TunnelDevicePolicy> tunnelDevicePolicyList = new ArrayList<>();
                flow.getTunnelPolicies().forEach(tunnelDevicePolicy -> {
                    tunnelDevicePolicyList.add(tunnelDevicePolicyRepository.findOne(tunnelDevicePolicy.getId()));
                });
                flow.setTunnelPolicies(tunnelDevicePolicyList);
            } else {
                flow.setTunnelPolicies(Lists.newArrayList());
            }
            flows.add(flow);
        }
        policyToSave.addFlows(flows);
    }

    /**
     * Update the packet truncation mapping from database
     *
     * @param policy
     * @return
     */
    private void updatePacketTruncationMapping(Policy policy) {
        SortedSet<Flow> flows = policy.getFlows();
        if (flows != null && !flows.isEmpty()) {
            flows.forEach(flow -> {
                if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getId() != null) {
                    PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findOne(flow.getPacketTruncationMapping().getId());
                    if (packetTruncationMapping != null) {
                        flow.setPacketTruncationMapping(packetTruncationMapping);
                    }
                }
            });
        }
    }

    /**
     * Reconfiguring the interfaces of policy by fetching from database
     *
     * @param policy
     */
    private void reConfigurePolicyInterface(Policy policy) {
        if (policy != null) {
            policy.getFlows().forEach(flow -> {
                List<Long> ingressPortIds = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toList());
                List<Long> egressPortIds = flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toList());
                List<Long> ingressPortGroupIds = flow.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList());
                List<Long> egressPortGroupIds = flow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList());

                flow.clearIngressPortsAndPortGroups();
                flow.clearEgressPortsAndPortGroups();
                if (ingressPortIds != null && !ingressPortIds.isEmpty()) {
                    flow.setIngressPorts(Sets.newHashSet(portRepository.findAll(ingressPortIds)));
                }
                if (ingressPortGroupIds != null && !ingressPortGroupIds.isEmpty()) {
                    flow.setIngressPortGroups(Sets.newHashSet(portGroupRepository.findAll(ingressPortGroupIds)));
                }
                if (egressPortIds != null && !egressPortIds.isEmpty()) {
                    flow.setEgressPorts(Sets.newHashSet(portRepository.findAll(egressPortIds)));
                }
                if (egressPortGroupIds != null && !egressPortGroupIds.isEmpty()) {
                    flow.setEgressPortGroups(Sets.newHashSet(portGroupRepository.findAll(egressPortGroupIds)));
                }
            });
        }
    }

    /**
     * This method is used to delete/recover policy on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     */
    @Override
    public Long deletePolicy(Long policyId, boolean isRetainAsDraft, boolean isStandalone) throws ValidationException {
        Policy policy = policyRepository.findOne(policyId);
        if (policy != null) {
            if (policy.getGridPolicySetId() != null && isStandalone) {
                log.error("Cannot delete/recover policy as it is associated with a grid policy.");
                throw new ValidationException("Cannot delete/recover policy as it is associated with a grid policy.");
            }
            if (policy.getWorkflowStatus() == WorkflowStatus.DRAFT) {
                Policy policyFromHistory = getPolicyFromHistoryForDelete(policy, Arrays.asList(WorkflowStatus.ACTIVE, WorkflowStatus.WARNING, WorkflowStatus.ERROR));
                if (policyFromHistory != null && (policyFromHistory.getWorkflowStatus() == WorkflowStatus.ACTIVE || policyFromHistory.getWorkflowStatus() == WorkflowStatus.WARNING)) {
                    //restore the committed policy copy from history and set status to active
                    //ensure that the policy from history has the same id.
                    policy.setDevice(policyFromHistory.getDevice());
                    policy.setFlows(Sets.newTreeSet(policyFromHistory.getFlows()));
                    policy.setName(policyFromHistory.getName());
                    policy.setWorkflowStatus(policyFromHistory.getWorkflowStatus());
                    policy.setFlexMatchProfiles(Sets.newHashSet(policyFromHistory.getFlexMatchProfiles()));
                    reConfigurePolicyInterface(policy);
                    policyRepository.save(policy);
                    log.info("Policy moved to committed state", policy.getId());
                    return -1l;
                } else {
                    policyRepository.delete(policy);
                    log.info("Policy id {} is in Draft state, so nothing to do on device", policy.getId());
                    return -1l;
                }
            } else if (policy.getWorkflowStatus() == WorkflowStatus.SUBMITTED) {
                // should not delete a policy if in Submitted state
                log.error("Cannot delete a policy id {} which is in progress.", policy.getId());
                throw new ValidationException("Cannot delete policy as another policy operation is in progress. Please try after sometime.");
            } else if (WorkflowStatus.ACTIVE == policy.getWorkflowStatus() || (WorkflowStatus.WARNING == policy.getWorkflowStatus() && policy.getDevice() != null && Device.Type.MLXE == policy.getDevice().getType())) {
                if (isAnyOtherPolicySequenceGettingDeleted(policy)) {
                    throw new ValidationException("Cannot delete policy as deletion of related policy is in progress. Please try after sometime.");
                }
                //new request , so setting it to DRAFT
                policy.setWorkflowStatus(WorkflowStatus.DRAFT);
                policyRepository.save(policy);

                Job.Type jobType = isRetainAsDraft ? Job.Type.POLICY_DELETE_DRAFT : Job.Type.POLICY_DELETE;
                long jobId = jobQueue.submit(JobTemplate
                        .builder()
                        .type(jobType)
                        .deviceId(policy.getDevice().getId())
                        .impactedObjectIds(Collections.emptyList())
                        .parentObjectId(policy.getId()).build());

                return jobId;
            } else if (policy.getWorkflowStatus() == WorkflowStatus.ERROR) {
                //do recovery
                //new request , so setting it to DRAFT
                policy.setWorkflowStatus(WorkflowStatus.DRAFT);
                policyRepository.save(policy);

                Job.Type jobType = Job.Type.POLICY_ROLLBACK;
                long jobId = jobQueue.submit(JobTemplate
                        .builder()
                        .type(jobType)
                        .deviceId(policy.getDevice().getId())
                        .impactedObjectIds(Collections.emptyList())
                        .parentObjectId(policy.getId()).build());

                return jobId;
            }
        }
        throw new ValidationException("Invalid policy Id!");
    }

    /**
     * This method is used to rollback policy on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     */
    @Override
    public Long rollbackPolicy(Long policyId, boolean isStandalone) throws ValidationException {

        Policy policy = policyRepository.findOne(policyId);
        if (policy != null) {
            if (policy.getGridPolicySetId() != null && isStandalone) {
                log.error("Cannot rollback policy as it is associated with a grid policy.");
                throw new ValidationException("Cannot rollback policy as it is associated with a grid policy.");
            }
            Policy policyFromHistory = getPolicyFromHistoryForDelete(policy, Arrays.asList(WorkflowStatus.ACTIVE));
            if (policyFromHistory != null && policyFromHistory.getWorkflowStatus() == WorkflowStatus.ACTIVE) {
                //restore the commited policy copy from history and set status to active
                //ensure that the policy from history has the same id.
                policy.setDevice(policyFromHistory.getDevice());
                policy.setFlows(policyFromHistory.getFlows());
                policy.setName(policyFromHistory.getName());
                policy.setFieldOffset1(policyFromHistory.getFieldOffset1());
                policy.setFieldOffset2(policyFromHistory.getFieldOffset2());
                policy.setFieldOffset3(policyFromHistory.getFieldOffset3());
                policy.setFieldOffset4(policyFromHistory.getFieldOffset4());
                policy.setGtpProfile(policyFromHistory.getGtpProfile());
                policy.setLoopbackEnabled(policyFromHistory.isLoopbackEnabled());
                policy.setPreserveHeader(policyFromHistory.isPreserveHeader());

                policyRepository.save(policy);
                log.info("Policy moved to committed state", policy.getId());
                Job.Type jobType = Job.Type.POLICY_REVERT;
                long jobId = jobQueue.submit(JobTemplate
                        .builder()
                        .type(jobType)
                        .deviceId(policy.getDevice().getId())
                        .impactedObjectIds(Collections.emptyList())
                        .parentObjectId(policy.getId()).build());

                return jobId;
            } else {
                throw new ValidationException("Cannot roll back as no previous committed state found.");
            }
        }
        throw new ValidationException("Invalid policy Id!");
    }

    /**
     * This method is used to copy all the updated data to existing object
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<? extends DomainObject> mergeAndReturnUpdatedSet(Set<? extends DomainObject> existingSet,
                                                                 Set<? extends DomainObject> updatedSet) {

        Set<DomainObject> toRetain = new HashSet<>();

        if (existingSet instanceof SortedSet) {
            toRetain = new TreeSet<>();
        }

        // merge ports/portgorups/ruleset/rule
        for (DomainObject eachExisting : existingSet) {
            // port does not exist - remove the port in the existing port list
            Optional<? extends DomainObject> searchResult = updatedSet.stream()
                    .filter(po -> (po.getId() != null && po.getId().equals(eachExisting.getId()))).findFirst();
            if (searchResult.isPresent()) {
                //merge properties
                DomainObject eachUpdated = searchResult.get();
                toRetain.add(eachUpdated);
                if (eachExisting instanceof RuleSet) {
                    ((RuleSet) eachExisting).setIpVersion(((RuleSet) eachUpdated).getIpVersion());
                    ((RuleSet) eachExisting).setSequence(((RuleSet) eachUpdated).getSequence());
                    ((RuleSet) eachExisting).setType(((RuleSet) eachUpdated).getType());
                    //remove all rules on existing and replace from updated
                    //((RuleSet) eachExisting).getRules().clear();
                    SortedSet<Rule> mergedRules = new TreeSet<>();
                    SortedSet<Rule> newRules = new TreeSet<>();
                    for (Rule eachUpdatedRule : ((RuleSet) eachUpdated).getRules()) {
                        if (eachUpdatedRule.getId() != null) {
                            //get existing rule and merge the same
                            Optional<? extends DomainObject> searchRule = ((RuleSet) eachExisting).getRules().stream().filter(ru -> ru.getId().equals(eachUpdatedRule.getId())).findFirst();
                            if (searchRule.isPresent()) {
                                Rule rule = (Rule) searchRule.get();
                                BeanUtils.copyProperties(eachUpdatedRule, rule);
                                mergedRules.add(rule);
                            }
                        } else {
                            newRules.add(eachUpdatedRule);
                        }
                    }
                    ((RuleSet) eachUpdated).setRules(mergedRules);
                    ((RuleSet) eachUpdated).addRules(newRules);
                } else if (eachExisting instanceof Flow) {
                    ((Flow) eachExisting).setSequence(((Flow) eachExisting).getSequence());
                }
            }
        }
        return toRetain;
    }

    /**
     * This method updates the flow egress managed object with latest precedence for the existing objects.
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<FlowEgressManagedObject> updateFlowEgressManagedObjects(Set<FlowEgressManagedObject> existingSet, Set<FlowEgressManagedObject> updatedSet) {
        Set<FlowEgressManagedObject> toUpdate = new HashSet<>();
        for (FlowEgressManagedObject eachExisting : existingSet) {
            Optional<FlowEgressManagedObject> optionalFlowEgressManagedObject = updatedSet.stream().filter(po -> po.getId() != null && eachExisting.getId() != null && po.getId().longValue() == eachExisting.getId().longValue()).findAny();
            if (optionalFlowEgressManagedObject != null && optionalFlowEgressManagedObject.isPresent()) {
                eachExisting.setPrecedence(optionalFlowEgressManagedObject.get().getPrecedence());
            }
            toUpdate.add(eachExisting);
        }
        return toUpdate;
    }

    /**
     * This method is used find the new port(s)/portGroup(s) to be updated in the policy on the device
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<Long> findNewObjectId(Set<? extends ManagedObject> existingSet,
                                      Set<? extends ManagedObject> updatedSet) {

        // look for new Ports/portgroups - as these are partial filled objects
        // from UI
        Set<Long> toAdd = new HashSet<>();
        for (ManagedObject eachUpdate : updatedSet) {
            if (!existingSet.stream().anyMatch(po -> po.getId() == eachUpdate.getId())) {
                toAdd.add(eachUpdate.getId());
            }
        }
        return toAdd;
    }

    /**
     * This method is used find the old port(s)/portGroup(s) to be deleted from the policy
     *
     * @param existingSet
     * @param updatedSet
     * @return Set<DomainObject> This returns Set of updated objects to be applied on the device
     */
    private Set<Long> findDeletedObjectId(Set<? extends ManagedObject> existingSet,
                                          Set<? extends ManagedObject> updatedSet) {

        // look for new Ports/portgroups - as these are partial filled objects
        // from UI
        Set<Long> toDelete = new HashSet<>();
        for (ManagedObject eachExisting : existingSet) {
            if (!updatedSet.stream().anyMatch(po -> po.getId() == eachExisting.getId())) {
                toDelete.add(eachExisting.getId());
            }
        }
        return toDelete;
    }

    private void addFlowEgressToPolicy(Policy policy) {
        policy.getFlows().forEach(flow -> {
            flow.addFlowEgressManagedObjects(flow.getEgressPorts());
            flow.addFlowEgressManagedObjects(flow.getEgressPortGroups());
        });
    }

    /**
     * This method is used to merge updated policy with existing policy on the device
     *
     * @param existingPolicy
     * @param updatedPolicy
     */
    private void mergePolicies(Policy existingPolicy, Policy updatedPolicy) {

        existingPolicy.setName(updatedPolicy.getName());
        existingPolicy.setFieldOffset1(updatedPolicy.getFieldOffset1());
        existingPolicy.setFieldOffset2(updatedPolicy.getFieldOffset2());
        existingPolicy.setFieldOffset3(updatedPolicy.getFieldOffset3());
        existingPolicy.setFieldOffset4(updatedPolicy.getFieldOffset4());
        existingPolicy.setLoopbackEnabled(updatedPolicy.isLoopbackEnabled());
        existingPolicy.setGtpProfile(updatedPolicy.getGtpProfile());
        existingPolicy.setPreserveHeader(updatedPolicy.isPreserveHeader());
        existingPolicy.setTimestamp(updatedPolicy.isTimestamp());
        existingPolicy.setGtpHttpFiltered(updatedPolicy.isGtpHttpFiltered());
        existingPolicy.setIngressValid(updatedPolicy.isIngressValid());
        existingPolicy.setEgressAction(updatedPolicy.getEgressAction());
        existingPolicy.setCreatedFromSd(updatedPolicy.isCreatedFromSd());
        existingPolicy.setFlexMatchProfiles(updatedPolicy.getFlexMatchProfiles());

        List<Long> updatedFlowIds = updatedPolicy.getFlows().stream().map(Flow::getId).collect(Collectors.toList());

        SortedSet<Flow> deletedFlows = new TreeSet<>();

        Device device = existingPolicy.getDevice();
        // merge existing flows
        for (Flow existingFlow : existingPolicy.getFlows()) {
            if (existingFlow.getId() != null) {
                SortedSet<Flow> updatedFlows = updatedPolicy.getFlows().stream().filter(flow -> existingFlow.getId().equals(flow.getId())).collect(Collectors.toCollection(TreeSet::new));
                if (updatedFlows.size() > 0) {
                    Flow updatedFlow = updatedFlows.first();
                    //merge Ingress ports
                    log.debug("Merging Ingress Ports");
                    Set<Port> ingressMergedPorts = (Set<Port>) mergeAndReturnUpdatedSet(existingFlow.getIngressPorts(), updatedFlow.getIngressPorts());
                    Set<Long> ingressMergedPortIds = ingressMergedPorts.stream().map(Port::getId).collect(Collectors.toSet());

                    Set<Long> ingressPortsAdded = findNewObjectId(existingFlow.getIngressPorts(), updatedFlow.getIngressPorts());
                    ingressPortsAdded.addAll(ingressMergedPortIds);
                    if (((existingFlow.getFlowName() != null && !existingFlow.getFlowName().equals(updatedFlow.getFlowName())) || (Strings.isNullOrEmpty(existingFlow.getFlowName()) && !Strings.isNullOrEmpty(updatedFlow.getFlowName())))) {
                        //updating flow name to existing flow
                        log.debug("Updating the flow name");
                        existingFlow.setFlowName(updatedFlow.getFlowName());
                    }

                    //merge Ingress port groups
                    log.debug("Merging Ingress Port Groups");
                    Set<PortGroup> ingressMergedPortGroups = (Set<PortGroup>) mergeAndReturnUpdatedSet(existingFlow.getIngressPortGroups(), updatedFlow.getIngressPortGroups());
                    Set<Long> ingressMergedPortGroupIds = ingressMergedPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());

                    Set<Long> ingresssPortGroupsAdded = findNewObjectId(existingFlow.getIngressPortGroups(), updatedFlow.getIngressPortGroups());
                    ingresssPortGroupsAdded.addAll(ingressMergedPortGroupIds);
                    //load new ingress entites from db
                    List<Port> ingressPortsFromDB = (List<Port>) portRepository.findAll(ingressPortsAdded);
                    List<PortGroup> ingressPortGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(ingresssPortGroupsAdded);

                    //update Ingress ports and port groups
                    existingFlow.removeIngressPorts(existingFlow.getIngressPorts());
                    existingFlow.removeIngressPortGroups(existingFlow.getIngressPortGroups());
                    existingFlow.addIngressPorts(Sets.newHashSet(ingressPortsFromDB));
                    existingFlow.addIngressPortGroups(Sets.newHashSet(ingressPortGroupsFromDB));

                    //merge Egress ports
                    log.debug("Merging Egress Ports");
                    Set<Port> egressMergedPorts = (Set<Port>) mergeAndReturnUpdatedSet(existingFlow.getEgressPorts(), updatedFlow.getEgressPorts());
                    Set<Long> egressMergedPortIds = egressMergedPorts.stream().map(Port::getId).collect(Collectors.toSet());

                    Set<Long> egressPortsAdded = findNewObjectId(existingFlow.getEgressPorts(), updatedFlow.getEgressPorts());
                    Set<Long> egressPortsDeleted = findDeletedObjectId(existingFlow.getEgressPorts(), updatedFlow.getEgressPorts());

                    existingFlow.removeFlowEgressManagedObjects(Sets.newHashSet(portRepository.findAll(egressPortsDeleted)));
                    existingFlow.setFlowEgressPorts(updateFlowEgressManagedObjects(existingFlow.getFlowEgressPorts(), updatedFlow.getFlowEgressPorts()));
                    existingFlow.addFlowEgressManagedObjects(Sets.newHashSet(portRepository.findAll(egressPortsAdded)));

                    egressPortsAdded.addAll(egressMergedPortIds);

                    //merge port groups
                    log.debug("Merging Egress Port Groups");
                    Set<PortGroup> egressMergedPortGroups = (Set<PortGroup>) mergeAndReturnUpdatedSet(existingFlow.getEgressPortGroups(), updatedFlow.getEgressPortGroups());
                    Set<Long> egressMergedPortGroupIds = egressMergedPortGroups.stream().map(PortGroup::getId).collect(Collectors.toSet());

                    Set<Long> egressPortGroupsAdded = findNewObjectId(existingFlow.getEgressPortGroups(), updatedFlow.getEgressPortGroups());
                    Set<Long> egressPortGroupsDeleted = findDeletedObjectId(existingFlow.getEgressPortGroups(), updatedFlow.getEgressPortGroups());

                    existingFlow.removeFlowEgressManagedObjects(Sets.newHashSet(portGroupRepository.findAll(egressPortGroupsDeleted)));
                    existingFlow.setFlowEgressPortGroups(updateFlowEgressManagedObjects(existingFlow.getFlowEgressPortGroups(), updatedFlow.getFlowEgressPortGroups()));
                    existingFlow.addFlowEgressManagedObjects(Sets.newHashSet(portGroupRepository.findAll(egressPortGroupsAdded)));

                    egressPortGroupsAdded.addAll(egressMergedPortGroupIds);
                    //load new entites from db
                    List<Port> egressPortsFromDB = (List<Port>) portRepository.findAll(egressPortsAdded);
                    List<PortGroup> egressPortGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(egressPortGroupsAdded);

                    //update Egress ports and port groups
                    existingFlow.removeEgressPorts(existingFlow.getEgressPorts());
                    existingFlow.removeEgressPortGroups(existingFlow.getEgressPortGroups());
                    existingFlow.addEgressPorts(Sets.newHashSet(egressPortsFromDB));
                    existingFlow.addEgressPortGroups(Sets.newHashSet(egressPortGroupsFromDB));

                    //update vlans, SMAC and DMAC
                    existingFlow.setVlans(updatedFlow.getVlans());
                    existingFlow.setSourceMacTag(updatedFlow.getSourceMacTag());
                    existingFlow.setDestinationMacTag(updatedFlow.getDestinationMacTag());
                    existingFlow.setTunnelPolicies(updatedFlow.getTunnelPolicies());
                    //merge ruleset
                    log.debug("Merging RuleSets");
                    //new rulesets and rules
                    SortedSet<RuleSet> newRuleSets = updatedFlow.getRuleSets().stream().filter(rs -> rs.getId() == null).collect(Collectors.toCollection(TreeSet::new));
                    SortedSet<RuleSet> mergedRuleSets = (SortedSet<RuleSet>) mergeAndReturnUpdatedSet(Sets.newTreeSet(existingFlow.getRuleSets()), Sets.newTreeSet(updatedFlow.getRuleSets()));
                    existingFlow.setRuleSets(mergedRuleSets);
                    existingFlow.addRuleSets(newRuleSets);
                    existingFlow.setSequence(updatedFlow.getSequence());
                    //Merging the set interface null0 for MLXE as field not exposed to user.
                    if (Device.Type.MLXE == device.getType()) {
                        existingFlow.setIsDefaultRouteMapDrop(true);
                    } else {
                        existingFlow.setIsDefaultRouteMapDrop(updatedFlow.getIsDefaultRouteMapDrop());
                    }
                    existingFlow.setIsTagged(updatedFlow.getIsTagged());
                    existingFlow.setTvfDomain(updatedFlow.getTvfDomain());
                    existingFlow.setVlanStripping(updatedFlow.getVlanStripping());
                    existingFlow.setTaggedVlanId(updatedFlow.getTaggedVlanId());
                    log.debug("Merging PacketTruncationMapping ");
                    if (updatedFlow.getPacketTruncationMapping() == null) {
                        existingFlow.setPacketTruncationMapping(null);
                    } else if ((updatedFlow.getPacketTruncationMapping() != null && existingFlow.getPacketTruncationMapping() == null)) {
                        existingFlow.setPacketTruncationMapping(updatedFlow.getPacketTruncationMapping());
                    } else if ((updatedFlow.getPacketTruncationMapping() != null && existingFlow.getPacketTruncationMapping() != null) && (existingFlow.getPacketTruncationMapping().getId() != null && updatedFlow.getPacketTruncationMapping().getId() != null) && !existingFlow.getPacketTruncationMapping().getId().equals(updatedFlow.getPacketTruncationMapping().getId())) {
                        existingFlow.setPacketTruncationMapping(updatedFlow.getPacketTruncationMapping());
                    }
                } else if (!updatedFlowIds.contains(existingFlow.getId())) {
                    // adding deleted flow to deleted flows
                    deletedFlows.add(existingFlow);
                }
            }
        }
        //removing deleted flows from existing policy
        existingPolicy.removeFlows(deletedFlows);

        // add new flows
        SortedSet<Flow> newFlows = updatedPolicy.getFlows().stream().filter(fl -> fl.getId() == null)
                .collect(Collectors.toCollection(TreeSet::new));
        for (Flow flow : newFlows) {
            Set<Long> ingressPortIds = flow.getIngressPorts().parallelStream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> ingressPortGroupIds = flow.getIngressPortGroups().parallelStream().map(PortGroup::getId)
                    .collect(Collectors.toSet());
            Set<Long> egressPortIds = flow.getEgressPorts().parallelStream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> egressPortGroupIds = flow.getEgressPortGroups().parallelStream().map(PortGroup::getId)
                    .collect(Collectors.toSet());
            List<Port> ingressPortsFromDB = (List<Port>) portRepository.findAll(ingressPortIds);
            List<PortGroup> ingressPortGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(ingressPortGroupIds);

            List<Port> egressPortsFromDB = (List<Port>) portRepository.findAll(egressPortIds);
            List<PortGroup> egressPortGroupsFromDB = (List<PortGroup>) portGroupRepository.findAll(egressPortGroupIds);

            flow.removeIngressPortGroups(flow.getIngressPortGroups());
            flow.removeIngressPorts(flow.getIngressPorts());
            flow.addIngressPortGroups(Sets.newHashSet(ingressPortGroupsFromDB));
            flow.addIngressPorts(Sets.newHashSet(ingressPortsFromDB));

            flow.removeEgressPortGroups(flow.getEgressPortGroups());
            flow.removeEgressPorts(flow.getEgressPorts());
            flow.addEgressPortGroups(Sets.newHashSet(egressPortGroupsFromDB));
            flow.addEgressPorts(Sets.newHashSet(egressPortsFromDB));

            flow.addFlowEgressManagedObjects(Sets.newHashSet(egressPortsFromDB));
            flow.addFlowEgressManagedObjects(Sets.newHashSet(egressPortGroupsFromDB));
            //For newly created flows set interface null0 is always defined in MLXE
            if (Device.Type.MLXE == device.getType()) {
                flow.setIsDefaultRouteMapDrop(true);
            }
            log.debug("Add new PacketTruncationMapping to the existing flows.");
            if (flow.getPacketTruncationMapping() != null) {
                flow.setPacketTruncationMapping(flow.getPacketTruncationMapping());
            }
            SortedSet<Flow> flows = new TreeSet<>();
            flows.add(flow);
            existingPolicy.addFlows(flows);
        }
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    protected List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        if (policyId == null) {
            policyId = 0L;
        }

        /* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    /**
     * This will return last WorkFlowStatus of the current policy on the device from history, if WorkFlowStatus is ACTIVE, policy will be updated and if the WorkFlowStatus is ERROR, policy will be created
     *
     * @param policy
     * @return Policy returns latest ACTIVE policy
     */
    protected Policy getPolicyNameFromHistory(Policy policy, List<WorkflowStatus> statusses) {
        Policy policyFromHistory = null;
        List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(), statusses);
        if (!policyHistoryList.isEmpty()) {
            PolicyHistory oldPolicy = policyHistoryList.get(0);
            if (HistoryObject.RevisionType.DELETED != oldPolicy.getRevisionType()) {
                log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
                policyFromHistory = oldPolicy.buildParent();
            }
        }
        return policyFromHistory;
    }

    /**
     * This method fetches the latest policy from history for the current policy for delete
     *
     * @param policy
     * @return Policy returns latest ACTIVE or ERROR policy
     */
    protected Policy getPolicyFromHistoryForDelete(Policy policy, List<WorkflowStatus> statuses) {
        Policy policyFromHistory = null;
        if (policy != null && policy.getId() != null && statuses != null && !statuses.isEmpty()) {
            // get the previous policy name from the history.
            List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                    statuses);
            if (!policyHistoryList.isEmpty()) {
                PolicyHistory oldPolicy = policyHistoryList.get(0);
                if (HistoryObject.RevisionType.DELETED != oldPolicy.getRevisionType()) {
                    log.debug("Found a policyhistory entity with oldName {} and latest PolicyName {}", oldPolicy.getName(), policy.getName());
                    policyFromHistory = oldPolicy.buildParent();
                }
            }
        }
        return policyFromHistory;
    }

    /**
     * This method checks if the selected ingress port(s)/portGroup(s) matches with ingress port(s)/portGroup(s) in use by other policies
     *
     * @param ingressInUse
     * @param ingressSet
     * @return boolean returns if ingress matches with ingress in use or not
     */
    private boolean atLeastOnIngressMatch(Set<Long> ingressInUse, Set<Long> ingressSet) {
        for (Long ingress : ingressInUse) {
            if (ingressSet.contains(ingress)) {
                return true;
            }
        }
        return false;
    }

    protected abstract boolean isValidPolicyToSave(Policy policy, boolean isStandalone) throws
            ValidationException;

    protected abstract boolean isValidPolicyToUpdate(Policy policy, boolean isStandalone) throws
            ValidationException;

    protected abstract boolean isValidPolicyToCommit(Policy policy, boolean isStandalone) throws
            ValidationException;

    protected abstract boolean isFlowPriorityValid(Policy policy) throws ValidationException;

    protected abstract boolean isVLanValid(Policy policy) throws ValidationException;

    /**
     * Validates the rule name
     * 1.	No special character is allowed in ACL name except for “_”
     * 2.	Max character length is 63
     * 3.	Cannot start with special character(ACL name can start with number or alphabet and can contain “_”)
     *
     * @param policy
     */
    private void isRuleSetValid(Policy policy, boolean isCommit) {
        SortedSet<Flow> flows = policy.getFlows();
        Device.Type deviceType = policy.getDevice().getType();
        if (flows != null && !flows.isEmpty()) {
            List<String> ruleSetNames = Lists.newArrayList();
            List<String> newRuleSetNames = Lists.newArrayList();
            List<RuleSet> policyRuleSets = Lists.newArrayList();
            flows.stream().forEach(flow -> {
                if (flow.getRuleSets() != null) {
                    flow.getRuleSets().forEach(ruleSet -> {
                        String name = ruleSet.getName();
                        if (ruleSet.getId() == null) {
                            if (name == null || Strings.isNullOrEmpty(name.trim())) {
                                // Check if any of the Ruleset name is null
                                log.error("Ruleset name cannot be empty.");
                                throw new ValidationException("Ruleset name cannot be empty.");
                            } else if (Device.Type.SLX == deviceType && !slxRulesetNamePattern.matcher(name).matches()) {
                                //Check if all the Ruleset name adhere to the pattern as on device
                                log.error(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                                throw new ValidationException(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                            } else if (Device.Type.MLXE == deviceType && !mlxeRulesetNamePattern.matcher(name).matches()) {
                                //Check if all the Ruleset name adhere to the pattern as on device
                                log.error(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                                throw new ValidationException(RuleSet.RULESET_PATTERN_MISMATCH_ERROR);
                            } else if (name.length() > RuleSet.RULESET_NAME_MAX_LENGTH) {
                                log.error("Ruleset name cannot exceed 63 characters.");
                                throw new ValidationException("Ruleset name cannot exceed 63 characters.");
                            }
                            newRuleSetNames.add(name);
                        }
                        ruleSetNames.add(name);
                        policyRuleSets.add(ruleSet);
                    });
                }
            });

            //Check for the Ruleset name for existing Policies
            Set<RuleSet> matchingRuleSets = new HashSet<>();
            Long deviceId = policy.getDevice().getId();
            Long policyId = policy.getId();
            if (!newRuleSetNames.isEmpty() || !ruleSetNames.isEmpty()) {
                Set<RuleSet> ruleSets = null;
                if (policyId != null) {
                    ruleSets = ruleSetRepository.findByNameAndDeviceIdAndNotPolicyId(ruleSetNames, deviceId, policyId);

                } else {
                    ruleSets = ruleSetRepository.findByNameAndDeviceId(ruleSetNames, deviceId);
                }
                if (ruleSets != null && !ruleSets.isEmpty()) {
                    matchingRuleSets.addAll(ruleSets);
                }
            }
            if (Device.Type.SLX == policy.getDevice().getType()) {
                List<String> uniqueRuleSetNames = ruleSetNames.stream().distinct().collect(Collectors.toList());
                //Check if the new Policy has unique Ruleset name across the flows
                if (!ruleSetNames.isEmpty() && ruleSetNames.size() != uniqueRuleSetNames.size()) {
                    log.error("Cannot import same ruleset in different flows.");
                    throw new ValidationException("Cannot import same ruleset to different flows.");
                }
            }
            if (policyRuleSets != null && !policyRuleSets.isEmpty()) {
                policyRuleSets.stream().forEach(ruleSet -> {
                    List<RuleSet> duplicateRulesets = policyRuleSets.stream().filter(eachRuleSet -> ruleSet.getName().equals(eachRuleSet.getName())).collect(Collectors.toList());
                    //Check all the multiple ruleset defined in the same Policy are same imported/new for Create/Save Policy
                    if (duplicateRulesets != null && duplicateRulesets.size() > 1) {
                        RuleSet firstRuleset = duplicateRulesets.get(0);
                        duplicateRulesets.stream().forEach(duplicateRuleset -> {
                            if (duplicateRuleset.getType() == firstRuleset.getType() && duplicateRuleset.getIpVersion() == firstRuleset.getIpVersion()) {
                                if (!genericPolicyComparator.compareRule(duplicateRuleset.getRules().asList(), firstRuleset.getRules().asList())) {
                                    throw new ValidationException("Multiple Ruleset with name \"" + duplicateRuleset.getName() + "\" defined with different set of rules.");
                                }
                            } else {
                                throw new ValidationException("Multiple Ruleset with name \"" + duplicateRuleset.getName() + "\" defined with different ruleset type.");
                            }
                        });
                    } else {
                        Set<RuleSet> matchingInactiveRuleSetFromOtherPolicy = ruleSetRepository.findByNameAndDeviceIdAndNonActiveAndNotCreatedBySD(ruleSet.getName(), deviceId, true);
                        if (matchingInactiveRuleSetFromOtherPolicy != null && !matchingInactiveRuleSetFromOtherPolicy.isEmpty() && policyId != null) {
                            Policy policyFromDb = policyRepository.findOne(policyId);
                            if (policyFromDb != null) {
                                Flow flowFromDb = policyFromDb.getFlows().stream().filter(flow -> flow.getId().longValue() == ruleSet.getFlow().getId().longValue()).findFirst().orElse(null);
                                if (flowFromDb != null) {
                                    RuleSet rulesetFromDb = flowFromDb.getRuleSets().stream().filter(ruleSet1 -> ruleSet1.getId().longValue() == ruleSet.getId().longValue() && ruleSet1.getName().equals(ruleSet.getName())).findFirst().orElse(null);
                                    if (rulesetFromDb != null) {
                                        if (!genericPolicyComparator.compareRule(rulesetFromDb.getRules().asList(), ruleSet.getRules().asList())) {
                                            throw new ValidationException("The modified RuleSet " + rulesetFromDb.getName() + " shared in the Policy " + rulesetFromDb.getFlow().getPolicy().getName() + " is in Error state.Please recover the Policy and Try again!");
                                        }
                                    }
                                }
                            }
                        }

                    }
                });
            }
        }
    }

    /**
     * This method checks if the sequence number used in the current policy is used by any other policy on the device
     *
     * @param policyToSave
     * @throws ValidationException if sequence is already used
     */
    protected void isSequenceInUseByAnyPolicyOnDevice(Policy policyToSave) {
        // Method to verify if sequence is in used by any sequence belonging to
        // same policy
        Long deviceId = policyToSave.getDevice().getId();
        Set<Long> ingressPort = null;
        Set<Long> ingressPortGroups = null;
        for (Flow flow : policyToSave.getFlows()) {
            ingressPort = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            ingressPortGroups = flow.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet());
            if (!ingressPortGroups.isEmpty()) {
                ingressPort.addAll(ingressPortGroups);
            }
        }
        // TODO: need to do this check for each flow?, so sequence changes
        List<Long> policies = Collections.emptyList();
        for (Flow flow : policyToSave.getFlows()) {
            if (flow != null) {
                Integer sequence = flow.getSequence();
                if (policyToSave.getId() == null) {
                    //new policy
                    policies = flowRepository.findByDeviceIdAndIngressPortsAndSequence(deviceId, ingressPort, sequence);
                } else {
                    //old policy
                    if (ingressPort != null && !ingressPort.isEmpty())
                        policies = flowRepository.findByDeviceIdAndIngressPortsAndSequenceAndId(deviceId, ingressPort, sequence, policyToSave.getId());
                }
                if (!policies.isEmpty()) {
                    throw new ValidationException("policy.save.sequenceerror");
                }
            }
        }
    }

    /**
     * This method checks if the name and deviceId given is used in any other policy on the device for create
     *
     * @param policyToSave
     * @throws ValidationException if name and deviceId is already used
     */
    protected void isTagAndDeviceIdUnique(Policy policyToSave) {
        List<Policy> policies = policyRepository.findByNameAndDevice(policyToSave.getName(), policyToSave.getDevice().getId());
        if (!policies.isEmpty()) {
            throw new ValidationException("Policy name already exists.");
        }
        isPolicyNameUniqueforDraftPolicy(policyToSave);
    }

    /**
     * This method checks if the name and deviceId given is used in any other policy on the device for update
     *
     * @param policyToSave
     * @throws ValidationException if name and deviceId is already used
     */
    protected void isTagAndDeviceIdUniqueForUpdate(Policy policyToSave) {
        List<Policy> policies = policyRepository.findByNameAndDeviceForUpdate(policyToSave.getName(), policyToSave.getDevice().getId(), policyToSave.getId());
        if (!policies.isEmpty()) {
            throw new ValidationException("Policy name already exists.");
        }
        isPolicyNameUniqueforDraftPolicy(policyToSave);
    }

    /**
     * This method checks if the name given is used in any other DRAFT policy on the device
     *
     * @param policyToSave
     * @throws ValidationException if name and deviceId is already used
     */
    protected void isPolicyNameUniqueforDraftPolicy(Policy policyToSave) {
        Long policyId = 0L;
        if (policyToSave.getId() != null) {
            policyId = policyToSave.getId();
        }
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(policyToSave.getDevice().getId(), policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(policyToSave.getDevice().getId(), draftPolicyId);
                if (activePolicyFromHistroy != null && activePolicyFromHistroy.getName().equalsIgnoreCase(policyToSave.getName())) {
                    throw new ValidationException("Policy name already exists.");
                }
            });
        }
    }

    /**
     * This method checks if the policy is valid to save
     *
     * @param policyToSave
     * @throws ValidationException if selected policy data is not valid
     */
    protected boolean isPolicyCandidateToSave(Policy policyToSave) {
        boolean result = true;
        Set<Long> ingressPorts = null;
        Set<Long> ingressPrimaryPortIds = null;
        Device device = policyToSave.getDevice();
        for (Flow flow : policyToSave.getFlows()) {
            ingressPorts = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                ingressPrimaryPortIds = flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getId()).collect(Collectors.toSet());
                if (ingressPrimaryPortIds != null && !ingressPrimaryPortIds.isEmpty()) {
                    ingressPorts.addAll(ingressPrimaryPortIds);
                }
            } else {
                ingressPrimaryPortIds = flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getId()).collect(Collectors.toSet());
                if (ingressPrimaryPortIds != null && !ingressPrimaryPortIds.isEmpty()) {
                    ingressPorts.addAll(ingressPrimaryPortIds);
                }
            }
        }

        if (!policyToSave.isInWarningState() && (ingressPorts == null || ingressPorts.isEmpty())) {
            log.error("Ingress port/port group is empty. policy name: {}", policyToSave.getName());
            throw new ValidationException("Cannot commit policy as ingress port/port group information is invalid.");
        }

        List<Policy> policies = new ArrayList<>();
        if (policyToSave.getId() != null) {
            policies = policyRepository.findByDeviceIdAndNotInpolicyId(policyToSave.getDevice().getId(), policyToSave.getId());
        } else {
            policies = policyRepository.findByDeviceId(policyToSave.getDevice().getId());
        }
        // No policy set on device Safe to save new policy
        if (policies == null || policies.isEmpty()) {
            return true;
        }
        List<Long> policyIds = null;
        if (policyToSave.getId() == null) {
            policyIds = flowRepository.findByDeviceIdAndIngressPorts(policyToSave.getDevice().getId(), ingressPorts);
        } else {
            if (ingressPorts != null && !ingressPorts.isEmpty())
                policyIds = flowRepository.findByDeviceIdAndIngressPortsAndPolicyId(policyToSave.getDevice().getId(), ingressPorts, policyToSave.getId());
        }

        if (policyIds != null && !policyIds.isEmpty()) {
            log.error("Cannot apply this policy as another policy exists with same set of Ingress ports");
            throw new ValidationException("Cannot apply this policy as another policy exists with same set of Ingress ports.");
        }

        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(policyToSave.getDevice().getId(), policyToSave.getId());
        if (!activePolicies.isEmpty()) {
            validateIfIngressUsedInActivePolicies(activePolicies, ingressPorts);
        }
        Set<Long> ingressInUse = new HashSet<>();
        for (Policy policy : policies) {
            // Match should be exactly equal so need to create new data
            // structure
            ingressInUse.clear();
            Flow flow = policy.getFlows().stream().findFirst().orElse(null);
            if (flow != null) {
                flow.getIngressPorts().forEach(ingress -> ingressInUse.add(ingress.getId()));
                if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                    flow.getIngressPortGroups().forEach(ingress -> {
                        if (ingress != null) {
                            Port port = ingress.getPrimaryPort();
                            if (port != null && port.getId() != null) {
                                ingressInUse.add(port.getId());
                            }
                        }
                    });
                } else {
                    flow.getIngressPortGroups().forEach(ingress -> {
                        if (ingress != null && ingress.getId() != null) {
                            ingressInUse.add(ingress.getId());
                        }
                    });
                }
            }
            // 1.) if ingress set is totally Different do nothing
            if (atLeastOnIngressMatch(ingressInUse, ingressPorts)) {
                if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                    log.error("Cannot apply this policy as another policy exists with same set of Ingress port(s) or port-group.");
                    throw new ValidationException("Cannot apply this policy as another policy exists with same set of Ingress port(s) or port-group.");
                } else {
                    log.error("Cannot apply this policy as another policy exists with same set of Ingress port(s) or port-channel.");
                    throw new ValidationException("Cannot apply this policy as another policy exists with same set of Ingress port(s) or port-channel.");
                }
            }
        }
        return result;
    }

    /**
     * This method validates if all the selected ingress ports/portGroups are used in ACTIVE policies
     *
     * @param activePolicies
     * @param ingressPorts
     * @throws ValidationException
     */
    private void validateIfIngressUsedInActivePolicies(List<Policy> activePolicies, Set<Long> ingressPorts) {
        activePolicies.forEach(activePolicy -> {
            Device device = activePolicy.getDevice();
            final Set<Long> activeIngressPorts = Sets.newHashSet();
            for (Flow flow : activePolicy.getFlows()) {
                activeIngressPorts.addAll(flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
                if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                    activeIngressPorts.addAll(flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getId()).collect(Collectors.toSet()));
                } else {
                    activeIngressPorts.addAll(flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getId()).collect(Collectors.toSet()));
                }
            }
            /* Finding if the selected ingress ports of currently policy matches with ingress ports of ACTIVE policies*/
            List<Long> ingressMatch = ingressPorts.stream()
                    .filter(ingressPort -> activeIngressPorts.stream().anyMatch(activeIngressPort -> activeIngressPort.equals(ingressPort)))
                    .collect(Collectors.toList());
            if (!ingressMatch.isEmpty()) {
                log.error("Cannot apply this policy as another policy exists with same set of Ingress ports");
                throw new ValidationException("Cannot apply this policy as another policy exists with same set of Ingress ports.");
            }
        });
    }

    /**
     * This method checks if the selected ingress port(s)/portGroup(s) are in-progress state
     *
     * @param policyToSave
     * @return boolean returns true
     * @throws ValidationException if port(s)/portGroup(s) are in-progress
     */
    protected boolean isAnyPolicyInProgessOrError(Policy policyToSave) {
        Set<Long> ingressPorts = null;
        List<Long> egressPorts = null;
        Set<Long> ingressPrimaryPortIds;
        Set<Long> ingressPortChannelIds = new HashSet<>();
        List<Long> egressPortChannelIds = new ArrayList<>();
        Device device = policyToSave.getDevice();
        for (Flow flow : policyToSave.getFlows()) {
            ingressPorts = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            egressPorts = flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toList());
            if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                ingressPrimaryPortIds = flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getPrimaryPort().getId()).collect(Collectors.toSet());
                if (ingressPrimaryPortIds != null && !ingressPrimaryPortIds.isEmpty()) {
                    ingressPorts.addAll(ingressPrimaryPortIds);
                }
            } else {
                ingressPortChannelIds = flow.getIngressPortGroups().stream().map(portGroup -> portGroup.getId()).collect(Collectors.toSet());
                egressPortChannelIds = flow.getEgressPortGroups().stream().map(portGroup -> portGroup.getId()).collect(Collectors.toList());
            }
            if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getId() != null) {
                PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findOne(flow.getPacketTruncationMapping().getId());
                if (packetTruncationMapping == null) {
                    log.error("Packet Truncation Profile is not available ");
                    throw new ValidationException("Invalid Packet Truncation Profile Id!");
                }
            }
        }
        // check if Any Policy on the device is in Progress
        List<WorkflowStatus> notAcceptableStatus = new ArrayList<>();
        notAcceptableStatus.add(WorkflowStatus.SUBMITTED);
        List<Long> inProgressOrErrorPorts = null;
        List<Long> inProgressOrErrorPortChannel = null;
        if (ingressPorts.size() > 0) {
            inProgressOrErrorPorts = portRepository.findAllPortAndInWorkflowStatus(ingressPorts,
                    notAcceptableStatus);
        }
        if (ingressPortChannelIds.size() > 0) {
            inProgressOrErrorPortChannel = portGroupRepository.findAllPortChannelsInWorkflowStatus(ingressPortChannelIds,
                    notAcceptableStatus);
        }
        if ((inProgressOrErrorPorts != null && !inProgressOrErrorPorts.isEmpty()) || (inProgressOrErrorPortChannel != null && !inProgressOrErrorPortChannel.isEmpty())) {
            throw new ValidationException("Cannot commit policy set as another policy set creation is in progress. Please try after some time.");
        }
        validatePortsUsedInPacketTruncation(ingressPorts, ingressPortChannelIds, egressPorts, egressPortChannelIds, policyToSave);
        return true;
    }

    private void validatePortsUsedInPacketTruncation(Set<Long> ingressPorts, Set<Long> ingressPortChannelIds, List<Long> egressPorts, List<Long> egressPortChannelIds, Policy policyToSave) {
        StringBuilder packetTruncationErrorMessage = new StringBuilder();
        Long deviceId = policyToSave.getDevice().getId();
        if (ingressPorts != null && !ingressPorts.isEmpty()) {
            List<Long> packetTruncationParticipatingIngressPortIds = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(deviceId, Lists.newArrayList(ingressPorts));
            if (packetTruncationParticipatingIngressPortIds != null && !packetTruncationParticipatingIngressPortIds.isEmpty()) {
                Flow flow = policyToSave.getFlows().stream().findFirst().orElse(null);
                if (flow != null) {
                    packetTruncationErrorMessage.append(" ").append(flow.getIngressPorts().stream().filter(port -> packetTruncationParticipatingIngressPortIds.contains(port.getId())).map(port -> port.getPortNumber()).collect(Collectors.joining(", ")));
                }
            }
        }
        if (ingressPortChannelIds != null && !ingressPortChannelIds.isEmpty()) {
            List<Long> packetTruncationParticipatingIngressPortChannelIds = packetTruncationMappingRepository.findPortGroupsByDeviceIdAndPortGroupIds(deviceId, Lists.newArrayList(ingressPortChannelIds));
            if (packetTruncationParticipatingIngressPortChannelIds != null && !packetTruncationParticipatingIngressPortChannelIds.isEmpty()) {
                Flow flow = policyToSave.getFlows().stream().findFirst().orElse(null);
                if (flow != null) {
                    packetTruncationErrorMessage.append(packetTruncationErrorMessage.length() > 0 ? " , " : " ").append(flow.getIngressPortGroups().stream().filter(portGroup -> packetTruncationParticipatingIngressPortChannelIds.contains(portGroup.getId())).map(group -> group.getName()).collect(Collectors.joining(", ")));
                }
            }
        }
        if (egressPorts != null && !egressPorts.isEmpty()) {
            List<Long> packetTruncationParticipatingEgressPortIds = packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(deviceId, Lists.newArrayList(egressPorts));
            if (packetTruncationParticipatingEgressPortIds != null && !packetTruncationParticipatingEgressPortIds.isEmpty()) {
                Set<String> ports = new HashSet<>();
                policyToSave.getFlows().stream().forEach(flow -> {
                    ports.addAll(flow.getEgressPorts().stream().filter(port -> packetTruncationParticipatingEgressPortIds.contains(port.getId())).map(port -> port.getPortNumber()).collect(Collectors.toSet()));
                });
                if (ports != null && !ports.isEmpty()) {
                    packetTruncationErrorMessage.append(packetTruncationErrorMessage.length() > 0 ? " , " : " ").append(String.join(", ", ports));
                }
            }
        }
        if (egressPortChannelIds != null && !egressPortChannelIds.isEmpty()) {
            List<Long> packetTruncationParticipatingEgressPortChannelIds = packetTruncationMappingRepository.findPortGroupsByDeviceIdAndPortGroupIds(deviceId, Lists.newArrayList(egressPortChannelIds));
            if (packetTruncationParticipatingEgressPortChannelIds != null && !packetTruncationParticipatingEgressPortChannelIds.isEmpty()) {
                Set<String> ports = new HashSet<>();
                policyToSave.getFlows().stream().forEach(flow -> {
                    ports.addAll(flow.getEgressPortGroups().stream().filter(port -> packetTruncationParticipatingEgressPortChannelIds.contains(port.getId())).map(port -> port.getName()).collect(Collectors.toSet()));
                });
                if (ports != null && !ports.isEmpty()) {
                    packetTruncationErrorMessage.append(packetTruncationErrorMessage.length() > 0 ? " , " : " ").append(String.join(", ", ports));
                }
            }
        }

        if (!Strings.isNullOrEmpty(packetTruncationErrorMessage.toString())) {
            packetTruncationErrorMessage.append(" is used in a Packet Truncation profile.");
            log.debug("Cannot create/update the policy as port/port-channel" + packetTruncationErrorMessage.toString());
            throw new ValidationException("Cannot create/update the policy as port/port-channel" + packetTruncationErrorMessage.toString());
        }
    }

    /**
     * This method checks if the selected ingress port(s)/portGroup(s) used in other policies and policies getting deleted
     *
     * @param policyToDelete
     * @return boolean returns if ingress matches with ingress in use or not
     */
    protected boolean isAnyOtherPolicySequenceGettingDeleted(Policy policyToDelete) {
        Set<Long> ingressIds = policyToDelete.getFlows().stream().flatMap(flow -> flow.getIngressPorts().stream()).map(Port::getId).collect(Collectors.toSet());
        Set<Long> ingressGroupIds = policyToDelete.getFlows().stream().flatMap(flow -> flow.getIngressPortGroups().stream()).map(PortGroup::getId).collect(Collectors.toSet());
        if (ingressGroupIds != null && !ingressGroupIds.isEmpty()) {
            ingressIds.addAll(ingressGroupIds);
        }
        List<Long> policiesInSubmittedStateForIngress = Lists.newArrayList();
        if (!ingressIds.isEmpty()) {
            policiesInSubmittedStateForIngress = policyRepository.getCountOfPolicyGettingDeletedByIngressPorts(policyToDelete.getDevice().getId(), ingressIds);
        }
        if (!policiesInSubmittedStateForIngress.isEmpty()) {
            List<Job.Type> types = new ArrayList<>();
            types.add(Job.Type.POLICY_DELETE);
            types.add(Job.Type.POLICY_DELETE_DRAFT);
            Long count = jobRepository.getAllJobsOnAPolicyAndInType(policiesInSubmittedStateForIngress, types);
            return count == null || count == 0 ? false : true;
        } else {
            return false;
        }
    }

    /**
     * This method verifies if the Policy Set name given is valid
     *
     * @param policyName
     */
    private void isPolicyNameValid(String policyName, Device device) {
        if (Strings.isNullOrEmpty(policyName)) {
            log.error("No or Empty Policy set name found.");
            throw new ValidationException("No or Empty Policy set name found.");
        } else if (device != null) {
            if (Device.Type.SLX == device.getType() && !(slxPolicyNamePattern.matcher(policyName).matches())) {
                log.error(Policy.SLX_POLICY_NAME_ERROR_MESSAGE);
                throw new ValidationException(Policy.SLX_POLICY_NAME_ERROR_MESSAGE);
            } else if (Device.Type.MLXE == device.getType() && !(mlxePolicyNamePattern.matcher(policyName).matches() && policyName.length() <= Policy.MLXE_POLICY_NAME_MAX_LENGTH)) {
                log.error(MLXE_POLICY_NAME_ERROR_MESSAGE);
                throw new ValidationException(MLXE_POLICY_NAME_ERROR_MESSAGE);
            }
        }
    }

    /**
     * This method checks if same port(s)/portGroup(s) are used as both ingress and egress (in case if the selected port is a SERVICE PORT)
     *
     * @param policy
     * @throws ValidationException if same port(s)/portGroup(s) are used as both ingress and egress
     */
    protected void validateIfIngressAndEgressPortsAndPortGroupAreValid(Policy policy) {

        Set<Port.Type> ingressTypes = Sets.newHashSet();
        Set<Port> ingressPorts = Sets.newHashSet();
        Set<Long> currentEgressIds = Sets.newHashSet();
        Device device = policy.getDevice();
        policy.getFlows().forEach(flow -> {
            if (!policy.isInWarningState()) {
                if (flow.getIngressPortGroups().isEmpty() && flow.getIngressPorts().isEmpty()) {
                    log.error("Ingress port/port group is empty. policy {}", policy.getName());
                    throw new ValidationException("Cannot commit policy as ingress port/port group information is empty.");
                }
                if (flow.getEgressPortGroups().isEmpty() && flow.getEgressPorts().isEmpty()) {
                    log.error("Egress port/port group is empty. policy {}", policy.getName());
                    throw new ValidationException("Cannot commit policy as egress port/port group information is empty.");
                }
            }
            flow.getIngressPortGroups().forEach(portGroup -> {
                if (portGroup.getWorkflowStatus() == WorkflowStatus.ERROR) {
                    if (device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.PLAIN) {
                        throw new ValidationException("Port Channel " + portGroup.getName() + " used as Ingress is in ERROR state.");
                    } else {
                        throw new ValidationException("Port Group " + portGroup.getName() + " used as Ingress is in ERROR state.");
                    }
                }
                if (portGroup.getPrimaryPort() == null) {
                    throw new ValidationException("Primary port should be part of the Port Group.");
                }
            });
            flow.getEgressPortGroups().forEach(portGroup -> {
                if (portGroup.getWorkflowStatus() == WorkflowStatus.ERROR) {
                    if (device.getType() == Device.Type.SLX && device.getMode() == TargetHost.Mode.PLAIN) {
                        throw new ValidationException("Port Channel " + portGroup.getName() + " used as Egress is in ERROR state.");
                    } else {
                        throw new ValidationException("Port Group " + portGroup.getName() + " used as Egress is in ERROR state.");
                    }
                }
                if (portGroup.getPrimaryPort() == null) {
                    throw new ValidationException("Primary port should be part of the Port Group.");
                }
            });

            Set<Long> ingress = flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> egress = flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet());

            ingress.addAll(flow.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
            egress.addAll(flow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
            currentEgressIds.addAll(egress);

            // Validating if the same port(s)/portGroup(s) exists as both source port and destination port
            Sets.SetView commonPortsOrPortGroupIds = Sets.intersection(ingress, egress);
            if (commonPortsOrPortGroupIds.size() > 0) {
                log.debug("Policy with name {} cannot have same port/portGroup exists as both source and destination port on device {}", policy.getName(), device.getName());
                throw new ValidationException("Same port/port group cannot be selected as both ingress and egress");
            }

            // For destination port(s)/portGroup(s) Tagged should always be enabled
            if (policy.isPreserveHeader() && !flow.getTvfDomain() && !flow.getIsTagged()) {
                log.debug("Policy with name {} cannot enable Preserve Header as destination port(s)/portGroup(s) are not tagged", policy.getName());
                throw new ValidationException("While creating policy, if Preserve Header is selected, Egress Ports cannot be untagged in a VLAN.");
            }

            ingressTypes.addAll(flow.getIngressPorts().stream().map(Port::getType).collect(Collectors.toSet()));
            if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                flow.getIngressPortGroups().forEach(portGroup -> {
                    ingressTypes.add(portGroup.getPrimaryPort().getType());
                });
            }

            ingressPorts.addAll(flow.getIngressPorts());
            if (!(device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN)) {
                ingressPorts.addAll(flow.getIngressPortGroups().stream().map(PortGroup::getPrimaryPort).collect(Collectors.toSet()));
            }
        });

        if (policy.isPreserveHeader()) {
            // Validating if the selected service port's module & PPCR are matching with module & PPCR of HeaderStrippingModulePolicy, which is enabled with Preserve Header
            List<HeaderStrippingModulePolicy> strippingModulePolicies = headerStrippingModulePolicyRepository.findModulePoliciesByDeviceId(policy.getDevice().getId());
            if (strippingModulePolicies.isEmpty()) {
                log.debug("Policy with name {} cannot enable Preserve Header as the header preserve module policy is not created", policy.getName());
                throw new ValidationException("Preserve Header cannot be enabled as the header preserve module policy is not created.");
            }

            // Validating whether the egress port(s)/portGroup(s) selected are untagged in any other ACTIVE policies on the device(including SAVED over COMMITTED)
            List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(policy.getDevice().getId(), policy.getId());
            activePolicies.addAll(policyRepository.findAllActivePoliciesByDeviceIdNotCurrentPolicy(policy.getDevice().getId(), policy.getId() == null ? 0L : policy.getId()));
            activePolicies.forEach(activePolicy -> {
                activePolicy.getFlows().forEach(activeFlow -> {
                    Set<Long> activeEgressIds = Sets.newHashSet();
                    activeEgressIds.addAll(activeFlow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toSet()));
                    activeEgressIds.addAll(activeFlow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toSet()));
                    Set<Long> egressMatch = activeEgressIds.stream()
                            .filter(activeEgressId -> currentEgressIds.stream().anyMatch(currentEgressId -> currentEgressId.equals(activeEgressId)))
                            .collect(Collectors.toSet());
                    if (!egressMatch.isEmpty() && !activeFlow.getIsTagged()) {
                        log.debug("Policy with name {} cannot enable Preserve Header as egress port(s) selected are untagged in some other policy, Aborting!!", policy.getName());
                        throw new ValidationException("Preserve Header cannot be enabled as egress port(s) selected are untagged in some other policy.");
                    }
                });
            });
        }
    }

    /**
     * This method validates if the given ip is a valid IPV6
     *
     * @param ip
     * @return boolean
     */
    protected boolean validateIpv6(String ip) {
        if (ip != null) {
            if ("any".equalsIgnoreCase(ip)) {
                return true;
            } else {
                return (pattern1.matcher(ip).matches() || pattern2.matcher(ip).matches() || pattern3.matcher(ip).matches() || pattern4.matcher(ip).matches() || pattern5.matcher(ip).matches());
            }
        }
        return true;
    }

    /**
     * This method validates if the policy contains valid data for UDA
     *
     * @param policy
     * @return boolean
     */
    private boolean isValidForUda(Policy policy) {
        Set<RuleSet.Type> typeList = Sets.newHashSet();
        policy.getFlows().forEach(flow -> {
            typeList.addAll(flow.getRuleSets().stream().map(RuleSet::getType).collect(Collectors.toSet()));
        });
        if (!policy.getFlexMatchProfiles().isEmpty() && !typeList.contains(RuleSet.Type.UDA)) {
            log.error("Cannot save FlexMatch policy {} as the RuleSet Type UDA does not exist in the policy.", policy.getId());
            throw new ValidationException("The policy does not have a UDA ruleset. Either uncheck FlexMatch or add a UDA ruleset. ");
        }
        Device device = policy.getDevice();
        if (device.getModel() != null && device.getModel().contains(FlexMatchProfile.SLX_9850) && typeList.contains(RuleSet.Type.UDA) && typeList.contains(RuleSet.Type.L2)) {
            log.error("Can't save policy {} as the RuleSet Type UDA and L2 can't co-exist for the same policy.", policy.getId());
            throw new ValidationException("Cannot save policy as the RuleSet Type UDA and L2 cannot co-exist for the same policy");
        }
        if (typeList.contains(RuleSet.Type.UDA)) {
            Policy policyInDb = policyRepository.findOne(policy.getId());
            if (policyInDb != null && policy.getFlexMatchProfiles() != null && policyInDb.getFlexMatchProfiles() != null &&
                    !policy.getFlexMatchProfiles().isEmpty() && !policyInDb.getFlexMatchProfiles().isEmpty()) {
                if (policy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != policyInDb.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                    Set<RuleSet> ruleSets = Sets.newHashSet();
                    policy.getFlows().forEach(flow -> {
                        ruleSets.addAll(flow.getRuleSets().stream().filter(ruleSet -> ruleSet.getId() != null && ruleSet.getType() == RuleSet.Type.UDA).collect(Collectors.toList()));
                        if (!ruleSets.isEmpty()) {
                            log.error("Cannot update the Profile for an existing flow.");
                            throw new ValidationException("Cannot update the Profile for an existing UDA flow.");
                        }
                    });
                }
            }
            isOffsetValuesValid(policy);
            isProfileAssociationAllowed(policy);
            isValidRulesForUda(policy);

        }
        return true;
    }

    /*
    This method is used to check if there exists policy already mapped with UDA profile in device
    */
    private void isProfileAssociationAllowed(Policy policy) {
        Device device = deviceRepository.findOne(policy.getDevice().getId());
        if (Device.Type.SLX.equals(device.getType())) {
            List<Policy> policies = policy.getId() == null ? policyRepository.findAllPoliciesByDeviceId(policy.getDevice().getId()) : policyRepository.findAllPoliciesByDeviceIdNotCurrentPolicy(policy.getDevice().getId(), policy.getId());
            if (policies != null && !policies.isEmpty()) {
                Map<Integer, Long> requestIngressPpcrProfileMap = new HashMap<>();
                policy.getFlows().first().getIngressPorts().forEach(ingress -> {
                    Integer ppcr = portRepository.findOne(ingress.getId()).getPpcr();
                    if (!requestIngressPpcrProfileMap.containsKey(ppcr)) {
                        //TODO this is valid as we have restricted to 1 profile if changed this needs to changed
                        policy.getFlexMatchProfiles().forEach(profile -> {
                            requestIngressPpcrProfileMap.put(ppcr, profile.getId());
                        });
                    }
                });
                policies.forEach(existingPolicy -> {
                    if (isExistingPolicyProfileActive(existingPolicy)) {
                        existingPolicy.getFlows().first().getIngressPorts().forEach(ingress -> {
                            Integer ppcr = ingress.getPpcr();
                            if (requestIngressPpcrProfileMap.containsKey(ppcr)) {
                                //TODO this is valid as we have restricted to 1 profile if changed this needs to changed
                                existingPolicy.getFlexMatchProfiles().forEach(profile -> {
                                    if (requestIngressPpcrProfileMap.containsKey(ppcr)) {
                                        if (requestIngressPpcrProfileMap.get(ppcr) != profile.getId()) {
                                            log.error("Ingress Port\"" + ingress.getPortNumber() + "\" with same PPCR \"" + ppcr + " \"is already mapped to a profile \"" + profile.getName() + "\".UDA profile has to be unique per PPCR. Different UDA profiles cannot be applied on interfaces belonging to same PPCR.");
                                            if (existingPolicy.getDevice().getModel().contains(FlexMatchProfile.SLX_9850)) {
                                                throw new ValidationException("Ingress Port" + ingress.getPortNumber() + " with same PPCR \"" + ppcr + "\" is already mapped to profile \"" + profile.getName() + "\".,UDA profile has to be unique per PPCR., Different UDA profiles cannot be applied on interfaces belonging to the same PPCR.");
                                            } else {
                                                throw new ValidationException("Only one profile can be associated across the ports.");
                                            }
                                        }
                                    }
                                });
                            }
                        });
                    }
                });
            }
        }
    }

    /**
     * This method is used to verify if the Flexmatch profile of the policy is applied on the device
     *
     * @param policy
     * @return
     */
    protected boolean isExistingPolicyProfileActive(Policy policy) {
        boolean isExistingPolicyProfileActive = true;
        if (policy.getWorkflowStatus().equals(WorkflowStatus.DRAFT)) {
            List<PolicyHistory> policyHistoryList = policyHistoryRepository.findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(policy.getId(),
                    Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowStatus.ERROR));
            if ((policyHistoryList.isEmpty()) || (policyHistoryList.get(0).getWorkflowStatus().equals(WorkflowStatus.ERROR))) {
                isExistingPolicyProfileActive = false;
            }
        }
        return isExistingPolicyProfileActive;
    }

    /**
     * TThis method validates is the given value a valid hexadecimal value
     *
     * @param value
     * @param mask
     * @return boolean
     */
    protected boolean isValidHexaValueAndMask(String value, String mask) {
        Pattern maskPattern = Pattern.compile(MASK_HEX_PATTERN);
        Pattern valuePattern = Pattern.compile(VALUE_HEX_PATTERN);
        if (!"any".equals(value)) {
            if ("any".equals(mask)) {
                return false;
            }
            Matcher maskMatcher = maskPattern.matcher(mask);
            Matcher valueMatcher = valuePattern.matcher(value);
            return (maskMatcher.matches() && valueMatcher.matches());
        }
        return true;
    }

    /**
     * This method validates is the given value a valid decimal and hexadecimal value
     *
     * @param value
     * @param mask
     * @return boolean
     */
    protected boolean isValidValueAndMask(String value, String mask) {
        Pattern maskHexaPattern = Pattern.compile(MASK_HEX_PATTERN);
        Pattern valueDecimalPattern = Pattern.compile(VALUE_DECIMAL_PATTERN);
        if (!"any".equals(value)) {
            if ("any".equals(mask)) {
                return false;
            }
            Matcher maskMatcher = maskHexaPattern.matcher(mask);
            Matcher valueMatcher = valueDecimalPattern.matcher(value);
            return (maskMatcher.matches() && valueMatcher.matches());
        }
        return true;
    }

    /**
     * This method validates if the policy rules are having valid data for UDA
     *
     * @param policy
     * @return boolean
     */
    private boolean isValidRulesForUda(Policy policy) {
        policy.getFlows().forEach(flow -> {
            flow.getRuleSets().forEach(ruleSet -> {
                if (RuleSet.Type.UDA == ruleSet.getType()) {
                    ruleSet.getRules().forEach(rule -> {
                        if ((rule.getIsHexadecimalType1() && !isValidHexaValueAndMask(rule.getFieldValue1(), rule.getFieldmask1()))
                                || (rule.getIsHexadecimalType2() && !isValidHexaValueAndMask(rule.getFieldValue2(), rule.getFieldmask2()))
                                || (rule.getIsHexadecimalType3() && !isValidHexaValueAndMask(rule.getFieldValue3(), rule.getFieldmask3()))
                                || (rule.getIsHexadecimalType4() && !isValidHexaValueAndMask(rule.getFieldValue4(), rule.getFieldmask4()))) {
                            log.error("Can't save policy as the Rule Field Value and Mask are invalid");
                            throw new ValidationException("Cannot save policy as the values for Rule Field and Mask are invalid.");
                        }
                        if ((!rule.getIsHexadecimalType1() && !isValidValueAndMask(rule.getFieldValue1(), rule.getFieldmask1()))
                                || (!rule.getIsHexadecimalType2() && !isValidValueAndMask(rule.getFieldValue2(), rule.getFieldmask2()))
                                || (!rule.getIsHexadecimalType3() && !isValidValueAndMask(rule.getFieldValue3(), rule.getFieldmask3()))
                                || (!rule.getIsHexadecimalType4() && !isValidValueAndMask(rule.getFieldValue4(), rule.getFieldmask4()))) {
                            log.error("Can't save policy as the Rule Field Value and Mask are invalid");
                            throw new ValidationException("Cannot save policy as the values for Rule Field and Mask are invalid.");
                        }
                    });
                }
            });
        });
        return true;
    }

    /**
     * This method validates if Offset is in between -1 and 116, where -1 implies for ignore
     *
     * @param fieldOffset
     * @return boolean
     */
    private boolean isOffsetValid(Long fieldOffset, boolean isSlx9850) {
        if (isSlx9850) {
            if ((fieldOffset < MIN_SLX_9850_OFFSET || fieldOffset > MAX_SLX_9850_OFFSET)) {
                return false;
            }
        } else {
            if ((fieldOffset < MIN_OFFSET || fieldOffset > MAX_OFFSET)) {
                return false;
            }
        }

        return true;
    }

    /**
     * This method validates if all the Offset values of policy are valid
     *
     * @param policy
     * @return boolean
     */
    private boolean isOffsetValuesValid(Policy policy) {
        boolean isSLX9850 = Device.Type.SLX.equals(policy.getDevice().getType()) && policy.getDevice().getModel().contains(FlexMatchProfile.SLX_9850);
        if (isSLX9850) {
            policy.getFlexMatchProfiles().forEach(flexProfile -> {
                if (flexProfile.getFlexHeaders() != null) {
                    flexProfile.getFlexHeaders().forEach(flexHeader -> {
                        flexHeader.getFlexHeaderFields().forEach(flexHeaderField -> {
                            Integer validOffset = flexHeaderField.getCustomOffset() > -1 ? flexHeaderField.getCustomOffset() + flexHeaderField.getOffset() : flexHeaderField.getOffset();
                            if (!isOffsetValid(Long.valueOf(validOffset), isSLX9850)) {
                                log.error("Can't save policy as the Field Offset range is invalid");
                                throw new ValidationException("FlexMatch profile field Offset range is invalid.");
                            }
                        });
                    });
                }
            });
        } else {
            if (!isOffsetValid(policy.getFieldOffset1(), isSLX9850)
                    || !isOffsetValid(policy.getFieldOffset2(), isSLX9850)
                    || !isOffsetValid(policy.getFieldOffset3(), isSLX9850)
                    || !isOffsetValid(policy.getFieldOffset4(), isSLX9850)) {
                log.error("Can't save policy as the Field Offset range is invalid");
                throw new ValidationException("policy.save.fieldOffsetRangeInvalid");
            } else if ((policy.getFieldOffset1() != MIN_OFFSET && policy.getFieldOffset1() % 4 != 0)
                    || (policy.getFieldOffset2() != MIN_OFFSET && policy.getFieldOffset2() % 4 != 0)) {
                log.error("Cannot save policy as the 1st/2nd Field Offset value of is not a multiple of 4.");
                throw new ValidationException("Cannot save policy as the 1st/2nd Field Offset value is not a multiple of 4.");
            }
        }
        return true;
    }

    /**
     * This to verify if the given device is of type SLX 9240/9140
     *
     * @param device
     * @return
     */
    protected boolean isSlx9240Slx9140(Device device) {
        return (device.getType() == Device.Type.SLX && device.getModel() != null && (device.getModel().contains(FlexMatchProfile.SLX_9140) || device.getModel().contains(FlexMatchProfile.SLX_9240)));
    }

    /**
     * Validates the interfaces, is it used in device grid or not
     *
     * @param managedObjectIds
     */
    protected void validateInterfacesWithGrid(List<Long> managedObjectIds) {
        if (!managedObjectIds.isEmpty() && !gridClusterRepository.findInterfaceByManagedObjectId(managedObjectIds).isEmpty()) {
            throw new ValidationException("Cannot perform this action as the port(s)/port channel(s) are used in a grid.");
        }
    }

    /**
     * This method is used to copy the policy on the given device
     *
     * @param policy
     * @return Long This returns jobId
     */
    public Long copyPolicy(Policy policy, boolean isStandalone) throws ValidationException {
        setPortsAndPortGroupsInPolicy(policy);
        long jobId = -1;
        saveCopyPolicyObject(policy, isStandalone, true);
        Policy policyInDb = policyRepository.findOne(policy.getId());
        if (policyInDb != null) {
            Job.Type type = Job.Type.POLICY_CREATE;
            policy = policyRepository.findOne(policy.getId());
            // get all flows ids in a policy
            List<Long> impactedObjectIds = Collections.emptyList();
            jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(policy.getDevice().getId())
                    .parentObjectId(policy.getId()).impactedObjectIds(impactedObjectIds).build());
        }
        return jobId;
    }

    /**
     * This method is used to save the copy policy  in BVM database
     *
     * @param policyToSave
     * @param isStandalone
     * @return Long This returns policyId
     */
    public Long saveCopyPolicyObject(Policy policyToSave, boolean isStandalone, boolean isInternal) throws ValidationException {
        setPortsAndPortGroupsInPolicy(policyToSave);
        updatePacketTruncationMapping(policyToSave);

        // populate the policy with db entities
        addFlowEgressToPolicy(policyToSave);
        // validate the policy based on openflow/non open flow
        isValidPolicyToSave(policyToSave, isStandalone);
        if (policyToSave.getGridPolicySetId() == null) {
            generateAndSetTvfDomainIds(policyToSave);
        }
        policyToSave.setWorkflowStatus(WorkflowStatus.DRAFT);
        // save policy in DB
        try {
            policyToSave = policyRepository.save(policyToSave);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return policyToSave.getId();
    }

    public void validateCopyPolicy(Policy policy) {
        String errorMessage = "%s : \n - %s \n";
        if (policy == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (policy.getDevice() == null) {
            throw new ValidationException("policy.get.invaliddevice");
        }
        Device device = null;
        try {
            device = validateAndReturnDevice(policy.getDevice().getId());
        } catch (Exception e) {
            throw new ValidationException(e.getMessage());
        }
        Map<String, StringBuilder> validationMap = PolicyValidator.isValidPolicy(policy, device.getMode(), device.getType());
        if (device != null && validationMap != null && !validationMap.isEmpty()) {
            throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "policy.data.invalid"));
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(policy.getDevice().getId())) {
            throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "rbac.device.notAuthorized"));
        }

        if (device != null) {
            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isVlansInPolicyAuthorized(policy)) {
                throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "rbac.vlan.notAuthorized"));
            }

            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isSourceMacTagInPolicyAuthorized(policy)) {
                throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "rbac.smac.notAuthorized"));
            }
            if ((device.getMode() == Device.Mode.OPENFLOW) && !authorityProvider.isValidAdminUser() && !authorityProvider.isDestinationMacTagInPolicyAuthorized(policy)) {
                throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "rbac.dmac.notAuthorized"));
            }
            String deviceName = device.getName();
            //required for copy policy
            flushIdsForPolicy(policy);
            updateNullFieldsForPolicy(policy);
            Set<FlexMatchProfile> profiles = new HashSet<>();
            if (policy.getFlexMatchProfiles() != null && !policy.getFlexMatchProfiles().isEmpty()) {
                policy.getFlexMatchProfiles().forEach(profile -> {
                    FlexMatchProfile flexMatchProfile = flexMatchProfileRepository.findOne(profile.getId());
                    if (flexMatchProfile != null) {
                        profiles.add(flexMatchProfile);
                    } else {
                        throw new ValidationException(String.format(errorMessage, deviceName, "profile.id.invalid"));
                    }
                });
                policy.setFlexMatchProfiles(profiles);
            }
            try {
                setPortsAndPortGroupsInPolicy(policy);
                isValidPolicyToCommit(policy, true);
                isPolicyNameValid(policy.getName(), device);
                isFlowPriorityValid(policy);
                isVLanValid(policy);
                isValidForUda(policy);
                isTagAndDeviceIdUnique(policy);
                isValidPolicyToSave(policy, true);
                isRuleSetValid(policy, true);
            } catch (ValidationException e) {
                throw new ValidationException(String.format(errorMessage, deviceName, e.getMessage()));
            }
        } else {
            throw new ValidationException(String.format(errorMessage, policy.getDevice().getId(), "device.id.invalid"));
        }
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }

    /**
     * This method is used to clear ids of flow, ruleSet and rule from policy object for copy policy
     *
     * @param policy
     * @return ResponseEntity<Object> This returns policy
     */
    private Policy flushIdsForPolicy(Policy policy) {
        policy.clearId();
        policy.setLegacy(Boolean.FALSE);
        policy.getFlows().stream().forEach(flow -> {
            flow.clearId();
            flow.getRuleSets().stream().forEach(ruleSet -> {
                ruleSet.clearId();
                ruleSet.getRules().stream().forEach(rule -> {
                    rule.clearId();
                });
            });
        });
        return policy;
    }

    /**
     * This method is used to set the default value for null fields
     *
     * @param policy
     * @return ResponseEntity<Object> This returns policy
     */
    private Policy updateNullFieldsForPolicy(Policy policy) {
        if (policy.getLoopbackEnabled() == null) {
            policy.setLoopbackEnabled(false);
        }
        if (policy.getFlows() != null) {
            policy.getFlows().stream().forEach(flow -> {
                if (flow.getIsTagged() == null)
                    flow.setIsTagged(false);
                if (flow.getIsDefaultRouteMapDrop() == null)
                    flow.setIsDefaultRouteMapDrop(false);
                if (flow.getRuleSets() != null) {
                    flow.getRuleSets().forEach(ruleSet -> {
                        if (ruleSet.getRules() != null) {
                            ruleSet.getRules().forEach(rule -> {
                                if (rule.getSourcePort() == null)
                                    rule.setSourcePort(0);
                                if (rule.getDestinationPort() == null)
                                    rule.setDestinationPort(0);
                                if (rule.getVlanId() == null)
                                    rule.setVlanId(-1);
                                if (rule.getIsPermit() == null)
                                    rule.setIsPermit(false);
                            });
                        }
                    });
                }
            });
        }
        return policy;
    }

    private String isValidPacketTruncationProfileOnDevice(Policy policy, Device device) {
        String errorMessage = null;
        Set<String> packetTruncationNames = Sets.newHashSet();
        StringBuilder errorResponse = new StringBuilder();
        for (Flow flow : policy.getFlows()) {
            if (flow.getPacketTruncationMapping() != null && flow.getPacketTruncationMapping().getId() != null) {
                PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findOne(flow.getPacketTruncationMapping().getId());
                if (packetTruncationMapping != null) {
                    List<PacketTruncationMapping> packetTruncationMappings = packetTruncationMappingRepository.findByProfileNameAndDeviceId(packetTruncationMapping.getName(), device.getId());
                    if (packetTruncationMappings.size() == 0) {
                        packetTruncationNames.add(packetTruncationMapping.getName());
                    }
                } else {
                    log.error("Packet Truncation Profile is not available ");
                    packetTruncationNames.add(packetTruncationMapping.getName());
                }
            }
        }
        String packetTruncationName = packetTruncationNames.stream().collect(Collectors.joining(","));
        if (packetTruncationName != null && packetTruncationNames.size() == 1) {
            errorResponse.append("- ");
            errorResponse.append(String.format("Packet Truncation Profile %s does not exist.", packetTruncationName));
            errorResponse.append("\n");
            //  throw new ValidationException(errorResponse.toString());
        } else if (packetTruncationName != null && packetTruncationNames.size() > 1) {
            errorResponse.append("- ");
            errorResponse.append(String.format("Packet Truncation Profiles %s do not exist.", packetTruncationName));
            errorResponse.append("\n");
            //throw new ValidationException(errorResponse.toString());
        }
        if (errorResponse.length() != 0) {
            errorMessage = errorResponse.toString();
        }
        return errorMessage;
    }

    public Policy getCopyPolicy(Policy existingPolicy, Long deviceId) {
        Set<String> errorResponses = Sets.newHashSet();
        Policy copyPolicy = new Policy();
        Device device = deviceRepository.findOne(deviceId);
        String deviceName = device.getName();
        Device.Type deviceType = device.getType();
        copyPolicy.setDevice(device);
        copyPolicy.setName(existingPolicy.getName());
        copyPolicy.setFieldOffset1(existingPolicy.getFieldOffset1());
        copyPolicy.setFieldOffset2(existingPolicy.getFieldOffset2());
        copyPolicy.setFieldOffset3(existingPolicy.getFieldOffset3());
        copyPolicy.setFieldOffset4(existingPolicy.getFieldOffset4());
        copyPolicy.setGtpHttpFiltered(existingPolicy.isGtpHttpFiltered());
        copyPolicy.setGtpProfile(existingPolicy.getGtpProfile() != null ? existingPolicy.getGtpProfile() : null);
        copyPolicy.setPreserveHeader(existingPolicy.isPreserveHeader());
        copyPolicy.setLoopbackEnabled(existingPolicy.isLoopbackEnabled());
        device = authorityProvider.applyRBACOnDevice(device);
        List<Long> authorizedPortsOnDevice = new ArrayList<>();
        device.getModules().stream().forEach(module -> module.getPorts().stream().forEach(port -> authorizedPortsOnDevice.add(port.getId())));
        List<String> portGroupNames = device.getPortGroups().stream().map(ManagedObject::getName).collect(Collectors.toList());
        Set<Port> ports = device.getModules().stream().map(module -> module.getPorts()).flatMap(c -> c.stream()).collect(Collectors.toSet());
        SortedSet<Flow> flows = new TreeSet<>();
        if (existingPolicy.getFlows() != null) {
            existingPolicy.getFlows().stream().forEach(oldFlow -> {
                Flow flow = new Flow();
                SortedSet<RuleSet> ruleSets = new TreeSet<>();
                //set new rulset objects by using existing object
                if (oldFlow.getRuleSets() != null) {
                    oldFlow.getRuleSets().stream().forEach(oldRuleSet -> {
                        RuleSet newRuleSet = new RuleSet();
                        newRuleSet.setName(oldRuleSet.getName());
                        newRuleSet.setType(oldRuleSet.getType());
                        newRuleSet.setSequence(oldRuleSet.getSequence());
                        newRuleSet.setIpVersion(oldRuleSet.getIpVersion() != null ? oldRuleSet.getIpVersion() : null);
                        SortedSet<Rule> newRules = new TreeSet<>();
                        oldRuleSet.getRules().stream().forEach(rule -> {
                            Rule newRuleObj = new Rule();
                            BeanUtils.copyProperties(rule, newRuleObj);
                            newRules.add(newRuleObj);
                        });
                        newRuleSet.setRules(newRules);
                        ruleSets.add(newRuleSet);
                    });
                }
                flow.setRuleSets(ruleSets);
                //set new ingress port objs by using existing objects
                Set<Port> ingressPorts = Sets.newHashSet();
                Set<Port> emptyIngressPorts = Sets.newHashSet();
                Set<Port> misMatchIngressPorts = Sets.newHashSet();
                oldFlow.getIngressPorts().stream().forEach(port -> {
                    Port portOld = portRepository.findOne(port.getId());
                    Optional<Port> portOptional = ports.stream().filter(port1 -> port1.getName().equals(portOld.getName())).findAny();
                    if (portOptional.isPresent()) {
                        if ((portOptional.get().getType() == portOld.getType() && port.isLoopbackEnabled() == portOptional.get().isLoopbackEnabled())) {
                            ingressPorts.add(portOptional.get());
                        } else {
                            misMatchIngressPorts.add(portOld);
                        }
                    } else {
                        emptyIngressPorts.add(portOld);
                    }
                });
                if (emptyIngressPorts.size() != 0) {
                    errorResponses.add(validateEmptyPorts(emptyIngressPorts));
                } else if (misMatchIngressPorts.size() != 0) {
                    errorResponses.add(validateMismatchPorts(misMatchIngressPorts));
                }
                flow.setIngressPorts(ingressPorts != null ? ingressPorts : Collections.emptySet());
                Set<Port> egressPorts = Sets.newHashSet();
                Set<Port> emptyEgressPorts = Sets.newHashSet();
                Set<Port> misMatchEgressPorts = Sets.newHashSet();
                // set new egress port objs by using existing objects
                oldFlow.getEgressPorts().stream().forEach(port -> {
                    Port portOld = portRepository.findOne(port.getId());
                    Optional<Port> portOptional = ports.stream().filter(port1 -> port1.getName().equals(portOld.getName())).findAny();
                    if (portOptional.isPresent()) {
                        if ((portOptional.get().getType() == portOld.getType() && port.isLoopbackEnabled() == portOptional.get().isLoopbackEnabled())) {
                            egressPorts.add(portOptional.get());
                        } else {
                            misMatchEgressPorts.add(portOld);
                        }
                    } else {
                        emptyEgressPorts.add(portOld);
                    }

                });
                if (emptyEgressPorts.size() != 0) {
                    errorResponses.add(validateEmptyPorts(emptyEgressPorts));
                } else if (misMatchEgressPorts.size() != 0) {
                    errorResponses.add(validateMismatchPorts(misMatchEgressPorts));
                }
                flow.setEgressPorts(egressPorts != null ? egressPorts : Collections.emptySet());
                //set new  ingress port group objs by using existing objects
                Set<PortGroup> ingressPortGroups = Sets.newHashSet();
                Set<PortGroup> emptyIngressPortGroups = Sets.newHashSet();
                Set<PortGroup> misMatchIngressPortGroups = Sets.newHashSet();
                oldFlow.getIngressPortGroups().stream().forEach(portGroup -> {
                    PortGroup portGroupOld = portGroupRepository.findOne(portGroup.getId());
                    Optional<String> portOptional = portGroupNames.stream().filter(port1 -> port1.equals(portGroupOld.getName())).findAny();
                    if (portOptional.isPresent()) {
                        PortGroup portGroupNew = portGroupRepository.findByNameAndDeviceId(portOptional.get(), deviceId);
                        Set<Port> latestPorts = portGroupOld.getPorts().stream().filter(portGroupOldObj -> portGroupNew.getPorts().stream().noneMatch(portGroupNewObj -> portGroupNewObj.getPortNumber().equals(portGroupOldObj.getPortNumber()))).collect(Collectors.toSet());
                        if (portGroupOld.getPorts().size() != portGroupNew.getPorts().size() || latestPorts.size() != 0) {
                            if (Device.Type.MLXE == deviceType) {
                                errorResponses.add(String.format(MISMATCH_PORTGROUP_ERROR_MESSAGE, portGroupOld.getName(), getPortNames(latestPorts)));
                            } else if (Device.Type.SLX == deviceType) {
                                errorResponses.add(String.format(MISMATCH_PORTCHANNEL_ERROR_MESSAGE, portGroupOld.getName(), getPortNames(latestPorts)));
                            }
                        }
                        if ((portGroupNew.getType() == portGroupOld.getType() && portGroupNew.isLoopbackEnabled() == portGroupOld.isLoopbackEnabled())) {
                            ingressPortGroups.add(portGroupNew);
                        } else {
                            misMatchIngressPortGroups.add(portGroupOld);
                        }
                        if (Device.Type.MLXE == deviceType && !portGroupOld.getPrimaryPort().getName().equals(portGroupOld.getPrimaryPort().getName())) {
                            errorResponses.add(String.format(MISMATCH_PRIMARY_PORT_ERROR_MESSAGE, portGroupOld.getName(), portGroupOld.getPrimaryPort().getName()));
                        }
                    } else {
                        emptyIngressPortGroups.add(portGroupOld);
                    }
                });
                if (emptyIngressPortGroups.size() != 0) {
                    errorResponses.add(validateEmptyPortGroups(emptyIngressPortGroups, deviceType));
                } else if (misMatchIngressPortGroups.size() != 0) {
                    errorResponses.add(validateMismatchPortGroups(misMatchIngressPortGroups, deviceType));
                }
                flow.setIngressPortGroups(ingressPortGroups != null ? ingressPortGroups : Collections.emptySet());
                //set new  egress port group objs by using existing objects
                Set<PortGroup> egressPortGroups = Sets.newHashSet();
                Set<PortGroup> misMatchEgressPortGroups = Sets.newHashSet();
                Set<PortGroup> emptyEgressPortGroups = Sets.newHashSet();
                oldFlow.getEgressPortGroups().stream().forEach(portGroup -> {
                    PortGroup portGroupOld = portGroupRepository.findOne(portGroup.getId());
                    Optional<String> portOptional = portGroupNames.stream().filter(port1 -> port1.equals(portGroupOld.getName())).findAny();
                    if (portOptional.isPresent()) {
                        PortGroup portGroupNew = portGroupRepository.findByNameAndDeviceId(portOptional.get(), deviceId);
                        Set<Port> latestPorts = portGroupOld.getPorts().stream().filter(portGroupOldObj -> portGroupNew.getPorts().stream().noneMatch(portGroupNewObj -> portGroupNewObj.getPortNumber().equals(portGroupOldObj.getPortNumber()))).collect(Collectors.toSet());
                        if (portGroupOld.getPorts().size() != portGroupNew.getPorts().size() || latestPorts.size() != 0) {
                            if (Device.Type.MLXE == deviceType) {
                                errorResponses.add(String.format(MISMATCH_PORTGROUP_ERROR_MESSAGE, portGroupOld.getName(), getPortNames(latestPorts)));
                            } else if (Device.Type.SLX == deviceType) {
                                errorResponses.add(String.format(MISMATCH_PORTCHANNEL_ERROR_MESSAGE, portGroupOld.getName(), getPortNames(latestPorts)));
                            }
                        }
                        if ((portGroupNew.getType() == portGroupOld.getType() && portGroupNew.isLoopbackEnabled() == portGroupOld.isLoopbackEnabled())) {
                            egressPortGroups.add(portGroupNew);
                        } else {
                            misMatchEgressPortGroups.add(portGroupOld);
                        }
                        if (Device.Type.MLXE == deviceType && !portGroupOld.getPrimaryPort().getName().equals(portGroupOld.getPrimaryPort().getName())) {
                            errorResponses.add(String.format(MISMATCH_PRIMARY_PORT_ERROR_MESSAGE, portGroupOld.getName(), portGroupOld.getPrimaryPort().getName()));
                        }
                    } else {
                        emptyEgressPortGroups.add(portGroupOld);
                    }
                });
                if (emptyEgressPortGroups.size() != 0) {
                    errorResponses.add(validateEmptyPortGroups(emptyEgressPortGroups, deviceType));
                } else if (misMatchEgressPortGroups.size() != 0) {
                    errorResponses.add(validateMismatchPortGroups(misMatchEgressPortGroups, deviceType));
                }
                flow.setEgressPortGroups(egressPortGroups != null ? egressPortGroups : Collections.emptySet());
                flow.setFlowName(oldFlow.getFlowName() != null ? oldFlow.getFlowName() : null);
                flow.setSequence(oldFlow.getSequence());
                flow.setDestinationMacTag(oldFlow.getDestinationMacTag() != null ? oldFlow.getDestinationMacTag() : null);
                flow.setVlans(oldFlow.getVlans() != null ? oldFlow.getVlans() : Collections.emptySet());
                flow.setTunnelPolicies(oldFlow.getTunnelPolicies() != null ? oldFlow.getTunnelPolicies() : Collections.emptyList());
                flow.setTaggedVlanId(oldFlow.getTaggedVlanId() != null ? oldFlow.getTaggedVlanId() : null);
                flow.setTvfDomain(false);
                flow.setVlanStripping(oldFlow.getVlanStripping());
                flow.setIsDefaultRouteMapDrop(oldFlow.getIsDefaultRouteMapDrop() != null ? oldFlow.getIsDefaultRouteMapDrop() : false);
                flow.setIsTagged(oldFlow.getIsTagged() != null ? oldFlow.getIsTagged() : false);
                if (oldFlow.getPacketTruncationMapping() != null) {
                    PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findOne(oldFlow.getPacketTruncationMapping().getId());
                    if (packetTruncationMapping != null) {
                        packetTruncationMapping = packetTruncationMappingRepository.findByProfileNameAndDevice(packetTruncationMapping.getName(), deviceId);
                    }
                    flow.setPacketTruncationMapping(packetTruncationMapping);
                }
                flows.add(flow);
            });
        }
        if (isValidPacketTruncationProfileOnDevice(existingPolicy, device) != null) {
            errorResponses.add(isValidPacketTruncationProfileOnDevice(existingPolicy, device));
        }
        if (flows != null) {
            copyPolicy.setFlows(flows);
        }
        copyPolicy.setFlexMatchProfiles(existingPolicy.getFlexMatchProfiles() != null ? existingPolicy.getFlexMatchProfiles() : null);
        copyPolicy.setWorkflowStatus(existingPolicy.getWorkflowStatus() != null ? existingPolicy.getWorkflowStatus() : WorkflowParticipant.WorkflowStatus.DRAFT);
        copyPolicy.setTimestamp(existingPolicy.isTimestamp());
        copyPolicy.setEgressAction(existingPolicy.getEgressAction() != null ? existingPolicy.getEgressAction() : null);
        copyPolicy.setIngressValid(existingPolicy.isIngressValid());
        if (errorResponses != null && errorResponses.size() != 0) {
            String policyErrorResults = errorResponses.stream().map(mismatchPorts -> {
                return mismatchPorts;
            }).collect(Collectors.joining("\n"));
            String error = deviceName + " :\n" + policyErrorResults;
            throw new ValidationException(error);
        }
        return copyPolicy;
    }

    /**
     * validate the empty ports on the destination device
     *
     * @param emptyPorts
     */
    private String validateEmptyPorts(Set<Port> emptyPorts) {
        StringBuilder errorResponses = new StringBuilder();
        errorResponses.append("- ");
        if (emptyPorts.size() != 0 && emptyPorts.size() == 1) {
            errorResponses.append(String.format(EMPTY_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, "Port", getPortNames(emptyPorts)));
            errorResponses.append("\n");
        } else if (emptyPorts.size() != 0 && emptyPorts.size() > 1) {
            errorResponses.append(String.format(EMPTY_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, "Ports", getPortNames(emptyPorts)));
            errorResponses.append("\n");
        }
        return errorResponses.toString();
    }

    /**
     * validate the port type on the destination device
     *
     * @param misMatchPorts
     */
    private String validateMismatchPorts(Set<Port> misMatchPorts) {
        StringBuilder errorResponses = new StringBuilder();
        Set<Port> ingressPorts = misMatchPorts.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.INGRESS).collect(Collectors.toSet());
        Set<Port> ServicePorts = misMatchPorts.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet());
        Set<Port> egressPorts = misMatchPorts.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.EGRESS).collect(Collectors.toSet());
        if (ingressPorts.size() != 0 && ingressPorts.size() == 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, "Port", ingressPorts, Port.Type.INGRESS.name().toLowerCase()));
        } else if (ingressPorts.size() != 0 && ingressPorts.size() > 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, "Ports", ingressPorts, Port.Type.INGRESS.name().toLowerCase()));
        }
        if (ServicePorts.size() != 0 && ServicePorts.size() == 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, "Port", ServicePorts, "service port/loopback"));
        } else if (ServicePorts.size() != 0 && ServicePorts.size() > 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, "Ports", ServicePorts, "service port/loopback"));
        }
        if (egressPorts.size() != 0 && egressPorts.size() == 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, "Port", egressPorts, Port.Type.EGRESS.name().toLowerCase()));
        } else if (egressPorts.size() != 0 && egressPorts.size() > 1) {
            errorResponses.append(getErrorMessageForPorts(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, "Ports", egressPorts, Port.Type.EGRESS.name().toLowerCase()));
        }
        return errorResponses.toString();
    }

    /**
     * validate the empty portgroups on the destination device
     *
     * @param emptyPortGroups
     */
    private String validateEmptyPortGroups(Set<PortGroup> emptyPortGroups, Device.Type deviceType) {
        StringBuilder errorResponses = new StringBuilder();
        errorResponses.append("- ");
        if (emptyPortGroups.size() == 1) {
            String interfaceChannel = Device.Type.MLXE == deviceType ? "Port Group" : "Port Channel";
            errorResponses.append(String.format(EMPTY_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, interfaceChannel, getPortGroupNames(emptyPortGroups)));
            errorResponses.append("\n");
        } else if (emptyPortGroups.size() > 1) {
            String interfaceChannel = Device.Type.MLXE == deviceType ? "Port Groups" : "Port Channels";
            errorResponses.append(String.format(EMPTY_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, interfaceChannel, getPortGroupNames(emptyPortGroups)));
            errorResponses.append("\n");
        }
        return errorResponses.toString();
    }

    /**
     * validate the  portgroup type on the destination device
     *
     * @param misMatchPortGroups
     */
    private String validateMismatchPortGroups(Set<PortGroup> misMatchPortGroups, Device.Type deviceType) {
        StringBuilder errorResponses = new StringBuilder();
        Set<PortGroup> ingressPortGroups = misMatchPortGroups.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.INGRESS).collect(Collectors.toSet());
        Set<PortGroup> ServicePortGroups = misMatchPortGroups.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.SERVICE_PORT).collect(Collectors.toSet());
        Set<PortGroup> egressPortGroups = misMatchPortGroups.stream().filter(misMatchPort -> misMatchPort.getType() == Port.Type.EGRESS).collect(Collectors.toSet());
        String interfaceChannel = Device.Type.MLXE == deviceType ? "Port Group" : "Port Channel";
        if (ingressPortGroups.size() != 0 && ingressPortGroups.size() == 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, interfaceChannel, ingressPortGroups, Port.Type.INGRESS.name().toLowerCase()));
        } else if (ingressPortGroups.size() != 0 && ingressPortGroups.size() > 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, interfaceChannel, ingressPortGroups, Port.Type.INGRESS.name().toLowerCase()));
        }
        if (ServicePortGroups.size() != 0 && ServicePortGroups.size() == 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, interfaceChannel, ServicePortGroups, "service port/loopback"));
        } else if (ServicePortGroups.size() != 0 && ServicePortGroups.size() > 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, interfaceChannel, ServicePortGroups, "service port/loopback"));
        }
        if (egressPortGroups.size() != 0 && egressPortGroups.size() == 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_SINGLE, interfaceChannel, egressPortGroups, Port.Type.EGRESS.name().toLowerCase()));
        } else if (egressPortGroups.size() != 0 && egressPortGroups.size() > 1) {
            errorResponses.append(getErrorMessageForPortGroups(MISMATCH_INTERFACE_ERROR_MESSAGE_FOR_MULTIPLE, interfaceChannel, egressPortGroups, Port.Type.EGRESS.name().toLowerCase()));
        }
        return errorResponses.toString();
    }

    /**
     * Join the port names to a one string
     *
     * @param ports
     * @return
     */
    private String getPortNames(Set<Port> ports) {
        String portNames = ports.stream().map(port -> {
            return port.getName();
        }).collect(Collectors.joining(","));
        return portNames;
    }

    /**
     * Join the port group names to a one string
     *
     * @param portGroups
     * @return
     */
    private String getPortGroupNames(Set<PortGroup> portGroups) {
        String portGroupNames = portGroups.stream().map(portGroup -> {
            return portGroup.getName();
        }).collect(Collectors.joining(","));
        return portGroupNames;
    }

    private String getErrorMessageForPorts(String mismatchErrorMsg, String interfaceChannel, Set<Port> ports, String type) {
        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append("- ");
        errorMessage.append(String.format(mismatchErrorMsg, interfaceChannel, getPortNames(ports), type));
        errorMessage.append("\n");
        return errorMessage.toString();
    }

    private String getErrorMessageForPortGroups(String mismatchErrorMsg, String interfaceChannel, Set<PortGroup> portGroups, String type) {
        StringBuilder errorMessage = new StringBuilder();
        errorMessage.append("- ");
        errorMessage.append(String.format(mismatchErrorMsg, interfaceChannel, getPortGroupNames(portGroups), type));
        errorMessage.append("\n");
        return errorMessage.toString();
    }

    /**
     * This method is used to construct RuleSet names to be created on the device
     *
     * @param policy
     */
    public Policy constructAndUpdateRuleSetNames(Policy policy) {
        SortedSet<Flow> flows = policy.getFlows();
        Device device = deviceRepository.findById(policy.getDevice().getId());
        for (Flow flow : flows) {
            SortedSet<RuleSet> updatedRuleSets = new TreeSet<>();
            for (RuleSet ruleSet : flow.getRuleSets()) {
                if (ruleSet.getName() == null) {
                    if (flow.getSequence() != -1) {
                        if (device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN && ruleSet.getIpVersion() != null) {
                            ruleSet.setName(String.format(RULE_SET_NAME_FORMAT, (ruleSet.getType().toString() + "_" + ruleSet.getIpVersion()), policy.getComputedName(), flow.getSequence()).toLowerCase());
                        } else {
                            ruleSet.setName(String.format(RULE_SET_NAME_FORMAT, ruleSet.getType(), policy.getComputedName(), flow.getSequence(), ruleSet.getSequence()).toLowerCase());
                        }
                    } else {
                        if (device.getType() == Device.Type.SLX && device.getMode() == Device.Mode.PLAIN && ruleSet.getIpVersion() != null) {
                            ruleSet.setName(String.format(RULE_SET_NAME_FORMAT, (ruleSet.getType().toString() + "_" + ruleSet.getIpVersion()), policy.getComputedName(), "@").toLowerCase());
                        } else {
                            ruleSet.setName(String.format(RULE_SET_NAME_FORMAT, ruleSet.getType(), policy.getComputedName(), "@").toLowerCase());
                        }
                    }
                }
                log.debug("Rule Set Name: {}", ruleSet.getName());
                updatedRuleSets.add(ruleSet);
            }
            flow.setRuleSets(updatedRuleSets);
        }
        return policy;
    }
}
