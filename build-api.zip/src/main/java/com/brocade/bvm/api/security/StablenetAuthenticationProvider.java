package com.brocade.bvm.api.security;

import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.dao.StablenetAgentConfigRepository;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.stablenet.model.UserGroupVO;
import com.brocade.bvm.outbound.stablenet.model.UserProfileVO;
import com.brocade.bvm.outbound.stablenet.model.UserVO;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.AuthorityUtils;

import javax.inject.Inject;
import javax.inject.Named;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXB;
import java.io.StringReader;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Auth provider to delegate authentication to Stablenet
 */
@Named
@Slf4j
public class StablenetAuthenticationProvider implements AuthenticationProvider {

    @Value("${stablenet.authentication.timeout.seconds:30}")
    private Integer restConnectionTimeoutSeconds;

    public static final String STABLENET_DEFAULT_USER = "infosim";

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String resourceUrl;

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String userGroupsUrl;

    @Value("${stablenet.resource-url.users.add}")
    private String userAddUrl;

    @Value("${stablenet.resource-url.users.remove}")
    private String userRemoveUrl;

    private String getGroupByNameUrl = "/users/getgroupbyname";

    private String getProfileByNameUrl = "/users/getprofilebyname";

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private StablenetAgentConfigRepository stablenetAgentConfigRepository;

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        AtomicBoolean isEndPointNotAvailable = new AtomicBoolean(false);
        try {
            ApplicationConfig stablenetRestUrlConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetRestUrl);
            if (stablenetRestUrlConfig != null) {
                String baseUrl = stablenetRestUrlConfig.getValue();
                String adminUser = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue();
                String adminPassword = configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue();
                try {
                    //Authenticating the logged-in user using Stablenet. If Stablenet fails to authenticate then retry using Open Stack.
                    //User "infosim" should be present in Stablenet and Open Stack for authentication.
                    if (!Strings.isNullOrEmpty(baseUrl)) {
                        Response response = new RestConnection().getClient(authentication.getName(), authentication.getCredentials().toString())
                                .target(baseUrl).path(resourceUrl).path(authentication.getName())
                                .request().accept(MediaType.APPLICATION_XML).get();
                        if (response != null) {
                            if (response.getStatus() == HttpStatus.OK.value()) {
                                //infosim username is admin, everyone else is a role_user
                                String role = authentication.getName().equalsIgnoreCase(STABLENET_DEFAULT_USER) ? "ROLE_ADMIN" : "ROLE_USER";
                                return new UsernamePasswordAuthenticationToken(authentication.getName(), authentication.getCredentials(),
                                        AuthorityUtils.commaSeparatedStringToAuthorityList(role));
                            } else if (!adminUser.equals(authentication.getName()) &&
                                    !"undefined".equals(authentication.getName()) && !"undefined".equals(authentication.getCredentials())) {
                                boolean isUserToBeAdded = true;
                                boolean isUserPresent = false;
                                try {
                                    Response userResponse = new RestConnection().getClient(adminUser, adminPassword)
                                            .target(baseUrl).path(userGroupsUrl).path("/" + authentication.getName())
                                            .request().accept(MediaType.APPLICATION_XML).get();

                                    if (userResponse != null) {
                                        if (userResponse.getStatus() == HttpStatus.OK.value()) {
                                            isUserToBeAdded = false;
                                            isUserPresent = true;
                                        }
                                    }
                                } catch (Exception e) {
                                    isUserToBeAdded = true;
                                }

                                if (isUserToBeAdded) {
                                    isUserPresent = addUser(authentication, baseUrl, true);
                                }
                                if (isUserPresent) {
                                    Response authResponse = new RestConnection().getClient(authentication.getName(), authentication.getCredentials().toString())
                                            .target(baseUrl).path(resourceUrl).path(authentication.getName())
                                            .request().accept(MediaType.APPLICATION_XML).get();

                                    if (authResponse != null && authResponse.getStatus() == HttpStatus.OK.value()) {
                                        //infosim username is admin, everyone else is a role_user
                                        String role = authentication.getName().equalsIgnoreCase(STABLENET_DEFAULT_USER) ? "ROLE_ADMIN" : "ROLE_USER";
                                        return new UsernamePasswordAuthenticationToken(authentication.getName(), authentication.getCredentials(),
                                                AuthorityUtils.commaSeparatedStringToAuthorityList(role));
                                    } else {
                                        if (isUserToBeAdded) {
                                            UserVO user = null;
                                            try {
                                                user = JAXB.unmarshal(new StringReader(new RestConnection().getClient(adminUser, adminPassword)
                                                        .target(baseUrl).path(userGroupsUrl).path("/" + authentication.getName())
                                                        .request().accept(MediaType.APPLICATION_XML).get().readEntity(String.class)), UserVO.class);
                                            } catch (Exception e) {
                                                log.error("Failed to get the user information from StableNet. {}", e.getMessage());
                                            }
                                            if (user != null && user.getObid() != null) {
                                                Response deleteResponse = new RestConnection().getClient(adminUser, adminPassword)
                                                        .target(baseUrl).path(userRemoveUrl).path("/" + user.getObid())
                                                        .request().accept(MediaType.APPLICATION_XML).delete();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (javax.ws.rs.ProcessingException e) {
                    log.error("Service endpoint unavailable! '{}{}'", baseUrl, resourceUrl);
                    isEndPointNotAvailable.set(true);
                }
            }
        } catch (Exception e) {
            log.error("Failed to authenticate : {}", e.getMessage());
        }

        try {
            boolean isStablenetNotInitialized = isStablenetNotInitialized();
            if (isStablenetNotInitialized) {
                return authenticateForApplicationConfigUpdate(authentication);
            }
        } catch (javax.ws.rs.ProcessingException e1) {
            log.error("Service endpoint unavailable! {}", e1);
            throw new InternalAuthenticationServiceException("Service endpoint unavailable!", e1);
        } catch (ServerException e2) {
            return authenticateForApplicationConfigUpdate(authentication);
        }
        if (isEndPointNotAvailable.get()) {
            log.error("Extreme Visibility Manager is unable to authenticate as StableNet service is not up/running. Please check the status of StableNet service.");
            throw new InternalAuthenticationServiceException("Extreme Visibility Manager is unable to authenticate as StableNet service is not up/running. Please check the status of StableNet service.");
        }
        throw new BadCredentialsException("Please enter valid credentials!");
    }

    private boolean isStablenetNotInitialized() {
        boolean isAgentToBeAdded = stablenetAgentConfigRepository.findAnyOne(1) == null;
        boolean isConfigurationJobsToBeAdded = configRepository.findByKey(ApplicationConfig.Key.StablenetDeleteJobId) == null || configRepository.findByKey(ApplicationConfig.Key.StablenetRediscoverJobId) == null || configRepository.findByKey(ApplicationConfig.Key.StablenetJobId) == null;
        return isAgentToBeAdded || isConfigurationJobsToBeAdded;
    }

    private Authentication authenticateForApplicationConfigUpdate(Authentication authentication) throws AuthenticationException {
        if ("bvmadmin".equalsIgnoreCase(authentication.getName()) && "3Vm@Dm1n".equals(authentication.getCredentials())) {
            String role = authentication.getName().equalsIgnoreCase("bvmadmin") ? "ROLE_ADMIN" : "ROLE_USER";
            return new UsernamePasswordAuthenticationToken(authentication.getName(), authentication.getCredentials(),
                    AuthorityUtils.commaSeparatedStringToAuthorityList(role));
        }
        throw new BadCredentialsException("Please enter valid credentials!");
    }

    private boolean addUser(Authentication authentication, String baseUrl, boolean isExternal) {
        String groupId = "100";
        String profileId = "500";
        String adminUser = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue();
        String adminPassword = configRepository.findByKey(ApplicationConfig.Key.StablenetPassword).getValue();
        try {
            UserProfileVO userProfileVO = JAXB.unmarshal(
                    new StringReader(new RestConnection().getClient(adminUser, adminPassword)
                            .target(baseUrl).path(getProfileByNameUrl).path("/Administrator Set")
                            .request().accept(MediaType.APPLICATION_XML).get().readEntity(String.class)),
                    UserProfileVO.class);

            UserGroupVO userGroupVO = JAXB.unmarshal(
                    new StringReader(new RestConnection().getClient(adminUser, adminPassword)
                            .target(baseUrl).path(getGroupByNameUrl).path("/Administrators")
                            .request().accept(MediaType.APPLICATION_XML).get().readEntity(String.class)),
                    UserGroupVO.class);
            if (userGroupVO != null) {
                groupId = userGroupVO.getObid();
            }
            if (userProfileVO != null) {
                profileId = userProfileVO.getObid();
            }
        } catch (Exception e) {
            log.error("Failed to get the group and profile information from StableNet. {}", e.getMessage());
        }

        String payload = "<user active=\"true\" name=\"" + authentication.getName() + "\" password=\"" + authentication.getCredentials().toString() + "\" externalauthentication=\"" + isExternal + "\">\n" +
                "<assignedgroups>\n" +
                "        <groupid>" + groupId + "</groupid>\n" +
                "    </assignedgroups>\n" +
                "    <assignedprofiles>\n" +
                "        <profileid>" + profileId + "</profileid>\n" +
                "    </assignedprofiles>\n" +
                "    <effectivegroups>\n" +
                "        <groupid>" + groupId + "</groupid>\n" +
                "    </effectivegroups>\n" +
                "</user>";

        try {
            Response response = new RestConnection().getClient(adminUser, adminPassword)
                    .target(baseUrl).path(userAddUrl)
                    .request().accept(MediaType.APPLICATION_XML).post(Entity.entity(payload, MediaType.APPLICATION_XML_TYPE));

            if (response != null && response.getStatus() == HttpStatus.OK.value()) {
                return true;
            }
        } catch (Exception e) {
            log.error("Failed to add the external user {}", authentication.getName());
            return false;
        }
        return false;
    }

    //TODO
    private class RestConnection {
        private TrustManager[] trustAllCerts() {
            return new TrustManager[]{new X509TrustManager() {

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
                }

                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1) throws CertificateException {
                }
            }};
        }

        private HostnameVerifier hostnameVerifier() {
            return (hostname, session) -> true;
        }

        private SSLContext sslContext() {
            try {
                SSLContext sslContext = SSLContext.getInstance("SSL");
                sslContext.init(null, trustAllCerts(), new SecureRandom());
                return sslContext;
            } catch (KeyManagementException | NoSuchAlgorithmException e) {
                throw new InternalAuthenticationServiceException("Service endpoint unavailable!", e);
            }
        }

        public Client getClient(String username, String password) {
            Client client = new JerseyClientBuilder()
                    .sslContext(sslContext())
                    .hostnameVerifier(hostnameVerifier()).build()
                    .register(HttpAuthenticationFeature.basic(username, password));
            client.property(ClientProperties.CONNECT_TIMEOUT, (restConnectionTimeoutSeconds * 1000));
            client.property(ClientProperties.READ_TIMEOUT, (restConnectionTimeoutSeconds * 1000));
            return client;
        }
    }

}
