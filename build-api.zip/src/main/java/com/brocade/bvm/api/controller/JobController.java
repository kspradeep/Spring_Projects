package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.model.db.Job;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.Map;

/**
 * This class implements methods get the JOB status
 */
@RestController
@Slf4j
@RequestMapping(value = "/job", produces = "application/json")
public class JobController {

    @Inject
    private JobRepository jobRepository;

//    @Autowired
//    private IJobService jobService;
//
//    @ApiOperation("get result by job id")
//    @ApiResponses(value = {@ApiResponse(code = 200, message = "Return result", response = ResponseMessage.class),
//            @ApiResponse(code = 400, message = "6007/6008", response = ResponseMessage.class),
//            @ApiResponse(code = 500, message = "Internal server error", response = ErrorMessage.class)})
//    @RequestMapping(method = RequestMethod.GET, value = "/{jobId}")
//    public ResponseEntity<Object> getJobById(@RequestHeader HttpHeaders headers,
//                                             @ApiParam(name = "jobid", value = "Please enter the JobId.", required = true) @PathVariable("jobId") long jobId) {
//        log.info("********** Start: Get Job Result **********");
//        return jobService.getJob(jobId);
//    }

    /**
     * This method is used to get job status for the given job id
     *
     * @param id
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{jobid}")
    public ResponseEntity<Object> getJobStatus(@PathVariable("jobid") Long id) {
        log.debug("********** Start: Get Job Status **********");
        Job job = jobRepository.findOne(id);
        if (job != null) {
            Map<String, Job.Status> map = new HashMap<>();
            map.put("status", job.getStatus());
            return new ResponseEntity<>(map, HttpStatus.OK);
        }
        throw new ValidationException("job.get.notfound");
    }
}
