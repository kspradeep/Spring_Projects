package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.controller.ModulePolicyController;
import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.LoadBalanceModulePolicy;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.ModulePolicy;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The LoadBalanceModulePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover LoadBalanceModulePolicy for NonOpenFlow
 */
@Named("loadBalanceModulePolicyManagerNonOpenFlow")
public class LoadBalanceModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {
	@Inject
	private ModulePolicyRepository modulePolicyRepository;

	@Inject
	private ModuleRepository moduleRepository;

	@Inject
	private JobQueue jobQueue;

	/**
	 * This method is used to delete LoadBalanceModulePolicy, on the given device
	 *
	 * @param deviceId
	 * @param modulePolicyId
	 * @return Long This returns jobId
	 * @throws ValidationException
	 */
	@Override
	public Long deleteModulePolicy(Long deviceId,
								   Long modulePolicyId) {

		ModulePolicy modulePolicy = modulePolicyRepository
				.findOne(modulePolicyId);
		// Validate
		// 1. ModulePolicy present in DB
		if (modulePolicy == null) {
			throw new ValidationException("loadBalancePolicy.id.invalid");
		}
		// 2. ModulePolicy not in active state.
		if (modulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
			throw new ValidationException("loadBalancePolicy.delete.policyApplied");
		}
		Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_DELETE;
		long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
				.deviceId(deviceId).impactedObjectIds(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
				.parentObjectId(modulePolicyId).build());
		return jobId;
	}

	/**
	 * This method is used to create LoadBalanceModulePolicy, on the given device
	 *
	 * @param deviceId
	 * @param modulePolicy
	 * @return Long This returns jobId
	 * @throws ValidationException
	 */
	@Override
	public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy) {

		// Validate
		// 1. Check if modulePolicy already present on same device and module.
		LoadBalanceModulePolicy loadBalanceModulePolicy = modulePolicy.getLoadBalanceModulePolicy();
		List<Long> moduleIds = loadBalanceModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
		List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
		if (modules.size() != moduleIds.size()) {
			throw new ValidationException("loadBalancePolicy.edit.failed");
		}
		validateRequest(loadBalanceModulePolicy);
		loadBalanceModulePolicy.setModules(Sets.newHashSet(modules));
		loadBalanceModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
		loadBalanceModulePolicy = modulePolicyRepository.save(loadBalanceModulePolicy);
		Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_CREATE;
		long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
				.deviceId(deviceId).impactedObjectIds(moduleIds)
				.parentObjectId(loadBalanceModulePolicy.getId()).build());

		return jobId;

	}

	/**
	 * This method is used to update LoadBalanceModulePolicy, on the given device
	 *
	 * @param deviceId
	 * @param modulePolicyId
	 * @param modulePolicyFromRequest
	 * @return Long This returns jobId
	 * @throws ValidationException
	 */
	public Long updateModulePolicy(Long deviceId,
								   Long modulePolicyId, ModulePolicyRequest modulePolicyFromRequest) {

		LoadBalanceModulePolicy modulePolicy = modulePolicyFromRequest.getLoadBalanceModulePolicy();
		LoadBalanceModulePolicy oldModulePolicy = (LoadBalanceModulePolicy) modulePolicyRepository
				.findById(modulePolicyId);

		// If no lag is available with id
		if (oldModulePolicy == null) {
			throw new ValidationException("loadBalancePolicy.id.invalid");
		}
		validateRequest(modulePolicy);
		// If Lag is not in committed status or in error state, do not allow
		// modify
		if (oldModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ACTIVE
				|| oldModulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
			throw new ValidationException("loadBalancePolicy.edit.failed");
		}

		// Merging oldModulePolicy with updated ModulePolicy data
		oldModulePolicy.setBiDirectional(modulePolicy.isBiDirectional());
		oldModulePolicy.setDestinationIpIncluded(modulePolicy
				.isDestinationIpIncluded());
		oldModulePolicy.setDestinationPortIncluded(modulePolicy
				.isDestinationPortIncluded());
		oldModulePolicy.setInnerIpIncluded(modulePolicy.isInnerIpIncluded());
		oldModulePolicy.setProtocolMaskIncluded(modulePolicy
				.isProtocolMaskIncluded());
		oldModulePolicy.setSourceIpIncluded(modulePolicy.isSourceIpIncluded());
		oldModulePolicy.setSourcePortIncluded(modulePolicy
				.isSourcePortIncluded());
		oldModulePolicy.setTeIdIncluded(modulePolicy.isTeIdIncluded());
		oldModulePolicy.setTunnelingProtocol(modulePolicy
				.getTunnelingProtocol());
		//merge modules
		List<Long> moduleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
		List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
		if (modules.size() != moduleIds.size()) {
			throw new ValidationException("loadBalancePolicy.edit.failed");
		}
		oldModulePolicy.setModules(new HashSet<>(modules));
		oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
		modulePolicyRepository.save(oldModulePolicy);

		Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_UPDATE;
		//TODO: Add only the new updated module ids in impacted list
		long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
				.deviceId(deviceId).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
				.parentObjectId(modulePolicyId).build());

		return jobId;
	}

	public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
		throw new ValidationException("loadBalancePolicy.recovery.invalid");
	}

	/**
	 * This checks if the LoadBalanceModulePolicy is data is valid
	 *
	 * @param modulePolicy
	 */
	private void validateRequest(LoadBalanceModulePolicy modulePolicy) {
		if (modulePolicy.isBiDirectional()) {

			if (modulePolicy.isSourceIpIncluded() && modulePolicy.isDestinationIpIncluded() && !modulePolicy.isInnerIpIncluded() &&
					modulePolicy.isProtocolMaskIncluded() && modulePolicy.isSourcePortIncluded() && modulePolicy.isDestinationPortIncluded()) {
				return;
			}
			if (modulePolicy.isProtocolMaskIncluded() && modulePolicy.isSourcePortIncluded() && modulePolicy.isDestinationPortIncluded()) {
				if (!modulePolicy.isSourceIpIncluded() && !modulePolicy.isDestinationIpIncluded() && !modulePolicy.isInnerIpIncluded()) {
					return;
				}
			}
			if (modulePolicy.isSourceIpIncluded() && modulePolicy.isDestinationIpIncluded() && !modulePolicy.isInnerIpIncluded()) {
				if (modulePolicy.isProtocolMaskIncluded() && modulePolicy.isSourcePortIncluded() && modulePolicy.isDestinationPortIncluded()) {
					return;
				}else if (!modulePolicy.isProtocolMaskIncluded() && !modulePolicy.isSourcePortIncluded() && !modulePolicy.isDestinationPortIncluded()){
                    return;
                }
			}
			throw new ValidationException("loadBalancePolicy.commit.invalidCombination");
		}
	}
}
