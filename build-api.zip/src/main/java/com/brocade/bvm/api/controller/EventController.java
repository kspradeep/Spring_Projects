package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.EventManager;
import com.brocade.bvm.dao.EventRepository;
import com.brocade.bvm.model.db.Event;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The EventController class implements methods to perform operations related to events
 */
@Slf4j
@RequestMapping(produces = "application/json", value = "/event")
@RestController
public class EventController {

    @Inject
    EventManager eventManager;

    @Inject
    EventRepository eventRepository;

    /**
     * This method fetches all the events by given status
     *
     * @param deviceId
     * @param status
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Object> getAllEventsByStatus(
            @RequestParam(value = "deviceid", required = false) Long deviceId,
            @RequestParam(value = "status", required = false) Event.Status status) {
        log.info("Start: List all events by status");
        List<Event> events = new ArrayList<>();
        if (deviceId != null && deviceId > 0 && status != null) {
            events = eventRepository.findByTargetHostIdAndStatusIn(deviceId, Sets.newHashSet(status));
        } else if (deviceId != null && deviceId > 0) {
            events = eventRepository.findByTargetHostIdAndStatusIn(deviceId, Sets.newHashSet(Event.Status.values()));
        } else if (status != null) {
            events = eventRepository.findByStatusIn(Collections.singletonList(status));
        } else {
            events = eventRepository.findByStatusIn(Collections.singletonList(Event.Status.NEW));
        }
        return new ResponseEntity<>(events, HttpStatus.OK);
    }

    /**
     * This method fetches the list of events by job id
     *
     * @param jobId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/result")
    public ResponseEntity<Object> getEventByJobId(@RequestParam("jobid") Long jobId) {
        log.info("Start: Get Job Result");
        List<Event> events = eventRepository.findByJobId(Collections.singletonList(jobId));
        return new ResponseEntity<>(events, HttpStatus.OK);
    }

    /**
     * This method is used to update events status to CLOSED
     *
     * @param closeEvents
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT)
    public ResponseEntity<Object> closeEvent(@RequestBody List<Long> closeEvents) {
        log.info("Start: Update event status");
        Boolean result = eventManager.updateEvents(closeEvents, Event.Status.CLOSED);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    /**
     * This method closes the given event
     *
     * @param eventId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{eventid}")
    public ResponseEntity<Object> closeEvent(@PathVariable("eventid") Long eventId) {
        log.info("Start: Update event status");
            Boolean result = eventManager.updateEvents(Collections.singletonList(eventId), Event.Status.CLOSED);
            return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
