package com.brocade.bvm.api.manager;

import java.util.List;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PortGroup;
public interface PortGroupManager {
	Long savePortGroup(PortGroup portGroup, Device device);
	Long commitPortGroup(PortGroup portGroup, Device device);
	Long editPortGroup(PortGroup portGroup, Device device, Long portGroupId);
    Long deletePortGroup(PortGroup portGroup, List<Long> portGroupIds);
	Long rollBackPortGroup(PortGroup portGroup, List<Long> portGroupIds);
}
