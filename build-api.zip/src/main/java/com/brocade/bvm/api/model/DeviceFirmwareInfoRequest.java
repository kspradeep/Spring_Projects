package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DeviceFirmwareInfoRequest {

    List<DeviceFirmwareInfo> deviceFirmwareInfos;
    List<Long> ids;

}
