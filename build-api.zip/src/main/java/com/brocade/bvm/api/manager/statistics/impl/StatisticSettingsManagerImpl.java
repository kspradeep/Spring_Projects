package com.brocade.bvm.api.manager.statistics.impl;

import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.manager.statistics.StatisticsSettingsManager;
import com.brocade.bvm.api.model.grid.GridDeviceInfoRequest;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.exception.ServerException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@Named
@Slf4j
public class StatisticSettingsManagerImpl implements StatisticsSettingsManager {

    @Inject
    private JobQueue jobQueue;

    @Inject
    private GridRepository gridRepository;

    @Inject
    private GenericJobManager genericJobManager;

    @Override
    public boolean clearCounters(GridDeviceInfoRequest gridDeviceInfoRequest) {
        Set<Long> deviceIds = Sets.newHashSet();
        gridDeviceInfoRequest.getTargetHosts().forEach(targetType -> {
            if (GridDeviceInfoRequest.TargetType.TYPE.GRID == targetType.getType()) {
                DeviceGrid deviceGrid = gridRepository.findOne(targetType.getId());
                if (deviceGrid != null) {
                    deviceGrid.getSourceNodes().forEach(gridCluster -> {
                        Device device = gridCluster.getDevice();
                        if (!device.isDeleted()) {
                            deviceIds.add(device.getId());
                        }
                    });
                    deviceGrid.getDestinationNodes().forEach(gridCluster -> {
                        Device device = gridCluster.getDevice();
                        if (!device.isDeleted()) {
                            deviceIds.add(device.getId());
                        }
                    });
                }
            } else {
                deviceIds.add(targetType.getId());
            }
        });
        List<Long> jobIds = Lists.newArrayList();
        deviceIds.forEach(deviceId -> {
            long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.TELEMETRY_CLEAR_COUNTER).deviceId(deviceId)
                    .impactedObjectIds(Collections.emptyList()).build());
            if (jobId != -1) {
                jobIds.add(jobId);
            }
        });
        jobIds.forEach(aLong -> {
            Job internalPolicyJob = genericJobManager.getJobStatus(aLong);
            if (internalPolicyJob != null && internalPolicyJob.getStatus() == Job.Status.FAILED) {
                String errorMessage = internalPolicyJob.getJobResult();
                Device device = internalPolicyJob.getDevice();
                log.error("Failed to clear telemetry counters on device {} : {}", device != null ? device.getId() : null, errorMessage);
                throw new ServerException(errorMessage);
            }
        });
        return true;
    }
}
