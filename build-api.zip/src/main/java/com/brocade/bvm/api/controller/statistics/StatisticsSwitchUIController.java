package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.manager.statistics.SwitchOverviewManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsSwitchRepository;
import com.brocade.bvm.dao.statistics.cache.PortCache;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.statistics.*;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RequestMapping(produces = "application/json", value = "/statistics")
@RestController
@Slf4j
public class StatisticsSwitchUIController {

  @Inject StatisticsPortRepository statisticsPortRepository;
  @Inject private DeviceRepository deviceRepository;
  @Inject private PolicyRepository policyRepository;
  @Inject private SwitchOverviewManager switchOverviewManager;
  @Inject private StatisticsSwitchRepository statisticsSwitchRepository;
  @Inject private PortCache portCache;
  @Inject private StatisticsPolicyRepository statisticsPolicyRepository;

  /** This endpoint returns ports packets information for individual switch. */
  @RequestMapping(method = RequestMethod.GET, value = "/{switchId}/{samples}/device-packets")
  public List<PortPackets> switchPackets(
      @PathVariable("switchId") Long switchId, @PathVariable("samples") int samples) {
    log.debug("Start: switch packets for switch id : {}", switchId);
    if (StringUtils.isEmpty(switchId) || samples == 0 || samples < 0) {
      throw new ValidationException("policy.get.invaliddevice");
    }

    List<PortPackets> result = switchOverviewManager.findSwitchPackets(switchId, samples);

    result.sort(Comparator.comparing(PortPackets::getLastUpdatedTime));
    log.debug("End: device packets for device id : {}", switchId);
    return result;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{switchId}/{samples}/system-utilization")
  public List<PortBandwidth> switchUtilization(
          @PathVariable("switchId") Long switchId, @PathVariable("samples") int samples) {
    log.debug("Start: switch utilization for switch id : {}", switchId);
    if (StringUtils.isEmpty(switchId) || samples == 0 || samples < 0) {
      throw new ValidationException("policy.get.invaliddevice");
    }

    List<PortBandwidth> result = switchOverviewManager.findDeviceUtilization(switchId, samples);
    log.debug("End: device utilization for device id : {}", switchId);
    return result;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{switchId}/{samples}/system-throughput")
  public List<PortBandwidth> switchBandwidth(
          @PathVariable("switchId") Long switchId, @PathVariable("samples") int samples) {
    log.debug("Start: switch bandwidth for switch id : {}", switchId);
    if (StringUtils.isEmpty(switchId) || samples == 0 || samples < 0) {
      throw new ValidationException("policy.get.invaliddevice");
    }

    List<PortBandwidth> result = switchOverviewManager.findDeviceUtilization(switchId, samples);
    log.debug("End: device utilization for device id : {}", switchId);
    return result;
  }

  /** This endpoint returns the switch overview for single switch */
  @RequestMapping(method = RequestMethod.GET, value = "/{switchId}/switch-overview")
  public ResponseEntity<SwitchOverview> switchOverview(@PathVariable("switchId") Long switchId) {
    log.debug("Start: switch overview for switch id : {}", switchId);
    if (StringUtils.isEmpty(switchId)) {
      throw new ValidationException("policy.get.invaliddevice");
    }

    Device device = deviceRepository.findByIdAndTypeAndIsReconciled(switchId, Device.Type.SLX);
    SwitchOverview switchOverview = new SwitchOverview();
    if(device != null){
      switchOverview.setOs(device.getSystemDescription());
      switchOverview.setIpAddress(device.getIpAddress());
      device
              .getModules()
              .forEach(
                      module -> {
                        switchOverview.setPorts(switchOverview.getPorts() + module.getPorts().size());
                        module
                                .getPorts()
                                .forEach(
                                        port -> {
                                          if (port.getLinkStatus().equals(Port.LinkStatus.DOWN)) {
                                            switchOverview.setDownPorts(switchOverview.getDownPorts() + 1);
                                          } else {
                                            switchOverview.setActivePorts(switchOverview.getActivePorts() + 1);
                                          }
                                        });
                      });
      switchOverview.setPolicies(policyRepository.findActivePoliciesByDeviceId(switchId).size());
    }

    log.debug("End: switch overview for switch id : {}", switchId);
    return new ResponseEntity<>(switchOverview, HttpStatus.OK);
  }

  /** returns overall overview of switches */
  @RequestMapping("/switch-overview")
  public ResponseEntity<SwitchesOverview> switchOverview() {
    log.debug("Start: switch overview for all switches");
    SwitchesOverview switchesOverview = new SwitchesOverview();
    switchesOverview.setTotalOperationalSwitches(
        statisticsSwitchRepository.findAllActiveSwitchesCount());
    List<Long> devices = statisticsSwitchRepository.findALLSLXDevices();
    switchesOverview.setTotalTapPorts(statisticsPortRepository.getAllIngressAndEgressTapPorts().get("ingress"));
    switchesOverview.setTotalToolPorts(statisticsPortRepository.getAllIngressAndEgressTapPorts().get("egress"));
    switchesOverview.setOperationalSwitchedPolicies(
        statisticsPolicyRepository.operationalSwitchesPoliciesCount());
    switchesOverview.setStandaloneSwitches(
        statisticsSwitchRepository.findAllStandaloneSwitchesCount());
    switchesOverview.setGridSwitches(statisticsSwitchRepository.findALLGridsSwitchesCount());
    switchesOverview.setGridPolices(statisticsPortRepository.getAllGridPolicies()); //Grid policies
    log.debug("End: switch overview for all switches");
    return new ResponseEntity<>(switchesOverview, HttpStatus.OK);
  }

  @RequestMapping("/switch-statistics-overview")
  public ResponseEntity<SwitchesStatisticsOverview> switchesStatisticsOverview()
      throws ExecutionException, InterruptedException {
    log.debug("Start: switch statistics overview for all switches");
    SwitchesStatisticsOverview switchesStatisticsOverview = new SwitchesStatisticsOverview();

    CompletableFuture topFiveSwitches = switchOverviewManager.findTopFiveSwitches();
    CompletableFuture bottomFiveSwitches = switchOverviewManager.findBottomFiveSwitches();

    CompletableFuture.allOf(topFiveSwitches, bottomFiveSwitches).join();

    switchesStatisticsOverview.setTopFiveDevices((List) topFiveSwitches.get());
    switchesStatisticsOverview.setBottomFiveDevices(new ArrayList<>());
    switchesStatisticsOverview.setTopFiveTapPorts(portCache.getTopFiveIngress());
    switchesStatisticsOverview.setBottomFiveTapPorts(new HashSet<>());
    switchesStatisticsOverview.setTopFiveToolPorts(portCache.getTopFiveEgress());
    switchesStatisticsOverview.setBottomFiveToolPorts(new HashSet<>());
    switchesStatisticsOverview.setTopFivePolicies(statisticsPolicyRepository.getTopFivePolices().get("device"));


    log.debug("End: switch statistics overview for all switches");
    return new ResponseEntity<>(switchesStatisticsOverview, HttpStatus.OK);
  }
}
