package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.model.db.statistics.Policy;
import com.brocade.bvm.model.db.statistics.PolicyStatistics;
import com.brocade.bvm.model.db.statistics.PolicyStatisticsWrapper;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.List;

@RestController
@RequestMapping(value = "/statistics")
public class StatisticsPolicyController {

    @Inject
    private StatisticsPolicyRepository policyRepository;

    @RequestMapping(value = "/policies")
    public List<Policy> getAllPolicies() {
        return policyRepository.getPolicies();
    }

    @RequestMapping(value = "{policyId}/policy")
    public PolicyStatisticsWrapper getPolicyStatistics(@PathVariable("policyId") Long policyId) {
        return policyRepository.getPolicyStatistics(policyId);
    }
}
