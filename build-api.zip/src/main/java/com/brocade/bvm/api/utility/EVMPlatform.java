package com.brocade.bvm.api.utility;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import javax.management.Attribute;
import javax.management.InstanceNotFoundException;
import javax.management.ReflectionException;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class EVMPlatform {
  public static final int UNSPECIFIED = -1;
  public static final int MAC = 0;
  public static final int LINUX = 1;
  public static final int WINDOWS = 2;
  public static final int SOLARIS = 3;
  public static final int FREEBSD = 4;
  public static final int OPENBSD = 5;
  public static final int WINDOWSCE = 6;
  public static final int AIX = 7;
  public static final int ANDROID = 8;
  public static final int GNU = 9;
  public static final int KFREEBSD = 10;
  public static final int NETBSD = 11;

  private static final int osType;

  static {
    String osName = System.getProperty("os.name");
    if (osName.startsWith("Linux")) {
      if ("dalvik".equals(System.getProperty("java.vm.name").toLowerCase())) {
        osType = ANDROID;
        // Native libraries on android must be bundled with the APK
        System.setProperty("jna.nounpack", "true");
      } else {
        osType = LINUX;
      }
    } else if (osName.startsWith("AIX")) {
      osType = AIX;
    } else if (osName.startsWith("Mac") || osName.startsWith("Darwin")) {
      osType = MAC;
    } else if (osName.startsWith("Windows CE")) {
      osType = WINDOWSCE;
    } else if (osName.startsWith("Windows")) {
      osType = WINDOWS;
    } else if (osName.startsWith("Solaris") || osName.startsWith("SunOS")) {
      osType = SOLARIS;
    } else if (osName.startsWith("FreeBSD")) {
      osType = FREEBSD;
    } else if (osName.startsWith("OpenBSD")) {
      osType = OPENBSD;
    } else if (osName.equalsIgnoreCase("gnu")) {
      osType = GNU;
    } else if (osName.equalsIgnoreCase("gnu/kfreebsd")) {
      osType = KFREEBSD;
    } else if (osName.equalsIgnoreCase("netbsd")) {
      osType = NETBSD;
    } else {
      osType = UNSPECIFIED;
    }
  }

  public static final int getOSType() {
    return osType;
  }

  public static final boolean isMac() {
    return osType == MAC;
  }

  public static final boolean isAndroid() {
    return osType == ANDROID;
  }

  public static final boolean isLinux() {
    return osType == LINUX;
  }

  public static final boolean isAIX() {
    return osType == AIX;
  }

  public static final boolean isWindowsCE() {
    return osType == WINDOWSCE;
  }
  /** Returns true for any windows variant. */
  public static final boolean isWindows() {
    return osType == WINDOWS || osType == WINDOWSCE;
  }

  public static final boolean isSolaris() {
    return osType == SOLARIS;
  }

  public static final boolean isFreeBSD() {
    return osType == FREEBSD;
  }

  public static final boolean isOpenBSD() {
    return osType == OPENBSD;
  }

  public static final boolean isNetBSD() {
    return osType == NETBSD;
  }

  public static final boolean isGNU() {
    return osType == GNU;
  }

  public static final boolean iskFreeBSD() {
    return osType == KFREEBSD;
  }

  public static final boolean hasRuntimeExec() {
    if (isWindowsCE() && "J9".equals(System.getProperty("java.vm.name"))) return false;
    return true;
  }

  public static int getNumberOfCPUCores() {
    String command = "cmd /C WMIC CPU Get /Format:List";
    if (isMac()) {
      command = "sysctl -n machdep.cpu.core_count";
    } else if (isLinux()) {
      command = "lscpu";
    } else if (isWindows()) {
      command = "cmd /C WMIC CPU Get /Format:List";
    }
    Process process = null;
    int numberOfCores = 0;
    int sockets = 0;
    try {
      if (isMac()) {
        String[] cmd = {"/bin/sh", "-c", command};
        process = Runtime.getRuntime().exec(cmd);
      } else {
        process = Runtime.getRuntime().exec(command);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    if(StringUtils.isEmpty(process)){
      log.error("No cpu core stat available");
      return 0;
    }

    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    String line;

    try {
      while ((line = reader.readLine()) != null) {
        if (isMac()) {
          numberOfCores = line.length() > 0 ? Integer.parseInt(line) : 0;
        } else if (isLinux()) {
          if (line.contains("Core(s) per socket:")) {
            numberOfCores = Integer.parseInt(line.split("\\s+")[line.split("\\s+").length - 1]);
          }
          if (line.contains("Socket(s):")) {
            sockets = Integer.parseInt(line.split("\\s+")[line.split("\\s+").length - 1]);
          }
        } else if (isWindows()) {
          if (line.contains("NumberOfCores")) {
            numberOfCores = Integer.parseInt(line.split("=")[1]);
          }
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    if (isLinux()) {
      return numberOfCores * sockets;
    }
    return numberOfCores;
  }

  public static String getProcessCpuLoad() throws Exception {
    String usage = "0";
    try {
      Process P = Runtime.getRuntime().exec("top -b -n 1");
      P.waitFor();
      BufferedReader StdInput = new BufferedReader(new InputStreamReader(P.getInputStream()));
      String TopS = "";
      int i = 0;

      while ((TopS = StdInput.readLine()) != null) {
        if (i == 2) {
          usage = TopS.split(",")[0].trim().split(":")[1].trim().split(" ")[0];
          break;
        }

        if (i > 6 && i < 17) {
          TopS = TopS.replaceAll("  ", " ");
          TopS = TopS.replaceAll("  ", " ");
          TopS = TopS.replaceAll("  ", " ");
          String[] tokens1 = TopS.split(" ");
          int j = 8;
          if (tokens1[0].isEmpty()) j = j + 1;
          String ProcCpuUtil = new String(tokens1[j]);
          j++;
          Float ProcMemUtil = Float.parseFloat(tokens1[j]);
          j = j + 2;
          String ProcName = new String(tokens1[j]);

          System.out.println(ProcName + "\t" + ProcCpuUtil + "\t" + ProcMemUtil);
        }
        i++;
      }

    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return usage;
  }

  public static long memoryUtilization() {
    if(isWindows()) {
      List<Attribute> attributes = getMemory();
      AtomicLong totalMem = new AtomicLong(0);
      AtomicLong freeMem = new AtomicLong(0);
      attributes.forEach(
              attribute -> {
                if (attribute.getName().equalsIgnoreCase("TotalPhysicalMemorySize")) {
                  totalMem.set((long) attribute.getValue());
                }
                if (attribute.getName().equalsIgnoreCase("FreePhysicalMemorySize")) {
                  freeMem.set((long) attribute.getValue());
                }
              });
      long usedMem = totalMem.longValue() - freeMem.longValue();
      double memUsed = ((usedMem) * 1.0 / totalMem.longValue()) * 100;
      return (long) memUsed;
    }else{
      Map<String, Long> map = getTotalAndUsedMemory();
      long total = map.get("total");
      long used = map.get("used");
      double util  = ((used) *1.0 / total) * 100;
      if(util >= 100) {
        util = 100;
      }
      return (long) util;
    }

  }

  public static double totalMemory() {
    if (isWindows()) {
      List<Attribute> attributes = getMemory();
      AtomicLong totalMem = new AtomicLong(0);
      attributes.forEach(
          attribute -> {
            if (attribute.getName().equalsIgnoreCase("TotalPhysicalMemorySize")) {
              totalMem.set((long) attribute.getValue());
            }
          });

      BigDecimal bd = new BigDecimal(totalMem.longValue() * 1.0 / 1024 / 1024 / 1024);
      bd = bd.setScale(1, BigDecimal.ROUND_HALF_UP);
      return bd.doubleValue();
    } else {
      long total = getTotalAndUsedMemory().get("total");
      BigDecimal bd = new BigDecimal(total * 1.0 / 1024 / 1024);
      bd = bd.setScale(1, BigDecimal.ROUND_HALF_UP);
      return bd.doubleValue();
    }
  }

  public static List<Attribute> getMemory() {
    String[] attr = {"TotalPhysicalMemorySize", "FreePhysicalMemorySize"};
    OperatingSystemMXBean op = ManagementFactory.getOperatingSystemMXBean();
    List<Attribute> al;
    try {
      al =
          ManagementFactory.getPlatformMBeanServer()
              .getAttributes(op.getObjectName(), attr)
              .asList();
    } catch (InstanceNotFoundException | ReflectionException ex) {
      al = Collections.emptyList();
    }

    return al;
  }

  private static final String DEFAULT_VM_STAT_COMMAND = "vmstat -s";

  public static Map<String, Long> getTotalAndUsedMemory() {
    ProcessBuilder builder = new ProcessBuilder();
    builder.redirectErrorStream(true);
    builder.command(DEFAULT_VM_STAT_COMMAND.split("\\s"));
    Map<String, Long> tupleBuilder = new HashMap();
    Process process = null;
    String line;
    try {
      process = builder.start();

      InputStreamReader in =
          new InputStreamReader(new BufferedInputStream(process.getInputStream()));
      BufferedReader reader = new BufferedReader(in);

      while ((line = reader.readLine()) != null) {
        StringTokenizer tokenizer = new StringTokenizer(line);
        try {
          Pattern pattern = Pattern.compile("total memory");
          Matcher matcher = pattern.matcher(line);
          while (matcher.find()) {
            tupleBuilder.put("total", Long.parseLong(tokenizer.nextToken()));
          }
          pattern = Pattern.compile("used memory");
          matcher = pattern.matcher(line);
          while (matcher.find()){
            tupleBuilder.put("used", Long.parseLong(tokenizer.nextToken()));
          }
        } catch (Exception e) {
          log.error(e.getMessage());
        }
      }
    } catch (IOException e) {
      log.error(e.getMessage());
    } finally {
      if (process != null) {
        process.destroy();
      }
    }

    return tupleBuilder;
  }
}
