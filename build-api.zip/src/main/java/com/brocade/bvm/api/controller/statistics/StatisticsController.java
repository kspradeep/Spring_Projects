package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.model.*;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.statistics.CollectorDeviceMappingRepository;
import com.brocade.bvm.dao.statistics.InterfaceStatisticsRepository;
import com.brocade.bvm.dao.statistics.PBRStatisticsRepository;
import com.brocade.bvm.dao.statistics.SystemUtilizationStatisticsRepository;
import com.brocade.bvm.dao.statistics.cache.CacheReceiver;
import com.brocade.bvm.dao.statistics.cache.SwitchCache;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.statistics.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.math.BigInteger;
import java.sql.Date;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/statistics")
public class StatisticsController {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private CollectorDeviceMappingRepository collectorDeviceMappingRepository;

    @Inject
    private InterfaceStatisticsRepository interfaceStatisticsRepository;

    @Inject
    private SystemUtilizationStatisticsRepository systemUtilizationStatisticsRepository;

    @Inject
    private PBRStatisticsRepository pbrStatisticsRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private EventRepository eventRepository;

    @Inject
    private CacheReceiver cacheReceiver;

    @Inject
    private FlowRepository flowRepository;

    @Inject
    private SwitchCache switchCache;

    @Value("${statistics.data.timer.interval.seconds}")
    private Long STATISTICS_DATA_TIMER_INTERVAL_IN_SECONDS;

    /**
     * This method is used to receive interface statistics data based on device ipaddress from the
     * collector.
     *
     * @param ipAddress
     * @return
     */
    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json", value = "/interface")
    public ResponseEntity<Object> receiveInterfaceStatistics(
            @RequestParam(value = "deviceip", required = true) String ipAddress,
            @RequestBody InterfaceStatisticsResponse interfaceStatisticsResponse) {
        log.trace("Start: Receive Interface statistics from : {}", ipAddress);

        if (ipAddress == null) {
            throw new ValidationException("statistics.ipAddress.invalid");
        }

        if (interfaceStatisticsResponse == null) {
            throw new ValidationException("statistics.interface.response.invalid");
        }

        Device device = deviceRepository.findByIpAddress(ipAddress);
        if (device != null) {
            if (interfaceStatisticsResponse.getCounters() != null
                    && !interfaceStatisticsResponse.getCounters().isEmpty()) {
                CollectorDeviceMapping collectorDeviceMapping =
                        constructCollectorDevcieMapping(device, CollectorDeviceMapping.TYPE.Interface);
                Set<InterfaceStatistics> interfaceStatisticsSet = Sets.newHashSet();
                List<Long> portIndexes = Lists.newArrayList();
                interfaceStatisticsResponse.getCounters().stream()
                        .forEach(
                                counter -> {
                                    try {
                                        InterfaceStatistics interfaceStatistics = new InterfaceStatistics();
                                        interfaceStatistics.setCollectorDeviceMapping(collectorDeviceMapping);
                                        String ifName = counter.get("ifName");
                                        if (!Strings.isNullOrEmpty(ifName)) {
                                            if (ifName.contains("Port-channel ")) {
                                                ifName = ifName.replace("Port-channel ", "");
                                            }
                                            interfaceStatistics.setIfName(ifName);
                                        }
                                        String ifIndex = counter.get("ifIndex");
                                        if (!Strings.isNullOrEmpty(ifIndex)) {
                                            Long ifIndex1 = Long.parseLong(ifIndex);
                                            interfaceStatistics.setIfIndex(ifIndex1);
                                            if (Device.Type.SLX == device.getType()
                                                    && Device.Mode.PLAIN == device.getMode()
                                                    && ifName.contains("Ethernet")) {
                                                portIndexes.add(ifIndex1);
                                            } else {
                                                PortGroup portGroup =
                                                        portGroupRepository.findByNameAndDeviceId(ifName, device.getId());
                                                if (portGroup != null) {
                                                    interfaceStatistics.setPortId(portGroup.getId());
                                                } else {
                                                    portIndexes.add(ifIndex1);
                                                }
                                            }
                                        }

                                        String inPkts = counter.get("inPkts");
                                        if (!Strings.isNullOrEmpty(inPkts)) {
                                            interfaceStatistics.setInPackets(Long.parseLong(inPkts));
                                        }
                                        String outPkts = counter.get("outPkts");
                                        if (!Strings.isNullOrEmpty(outPkts)) {
                                            interfaceStatistics.setOutPackets(Long.parseLong(outPkts));
                                        }
                                        String inOctets = counter.get("inOctets");
                                        if (!Strings.isNullOrEmpty(inOctets)) {
                                            interfaceStatistics.setInOctets(Long.parseLong(inOctets));
                                        }
                                        String outOctets = counter.get("outOctets");
                                        if (!Strings.isNullOrEmpty(outOctets)) {
                                            interfaceStatistics.setOutOctets(Long.parseLong(outOctets));
                                        }
                                        String inErrors = counter.get("inErrors");
                                        if (!Strings.isNullOrEmpty(inErrors)) {
                                            interfaceStatistics.setInErrors(Long.parseLong(inErrors));
                                        }
                                        String outErrors = counter.get("outErrors");
                                        if (!Strings.isNullOrEmpty(outErrors)) {
                                            interfaceStatistics.setOutErrors(Long.parseLong(outErrors));
                                        }
                                        String inDrops = counter.get("inDiscards");
                                        if (!Strings.isNullOrEmpty(inDrops)) {
                                            interfaceStatistics.setInDiscards(Long.parseLong(inDrops));
                                        }
                                        String outDrops = counter.get("outDiscards");
                                        if (!Strings.isNullOrEmpty(outDrops)) {
                                            interfaceStatistics.setOutDiscards(Long.parseLong(outDrops));
                                        }
                                        String inMulticastPkts = counter.get("inMulticastPkts");
                                        if (!Strings.isNullOrEmpty(inMulticastPkts)) {
                                            interfaceStatistics.setInMulticastPkts(Long.parseLong(inMulticastPkts));
                                        }
                                        String outMulticastPkts = counter.get("outMulticastPkts");
                                        if (!Strings.isNullOrEmpty(outMulticastPkts)) {
                                            interfaceStatistics.setOutMulticastPkts(Long.parseLong(outMulticastPkts));
                                        }
                                        String inUnicastPkts = counter.get("inUnicastPkts");
                                        if (!Strings.isNullOrEmpty(inUnicastPkts)) {
                                            interfaceStatistics.setInUnicastPkts(Long.parseLong(inUnicastPkts));
                                        }
                                        String outUnicastPkts = counter.get("outUnicastPkts");
                                        if (!Strings.isNullOrEmpty(outUnicastPkts)) {
                                            interfaceStatistics.setOutUnicastPkts(Long.parseLong(outUnicastPkts));
                                        }

                                        String inBroadcastPkts = counter.get("inBroadcastPkts");
                                        if (!Strings.isNullOrEmpty(inBroadcastPkts)) {
                                            interfaceStatistics.setInBroadcastPkts(Long.parseLong(inBroadcastPkts));
                                        }
                                        String outBroadcastPkts = counter.get("outBroadcastPkts");
                                        if (!Strings.isNullOrEmpty(outBroadcastPkts)) {
                                            interfaceStatistics.setOutBroadcastPkts(Long.parseLong(outBroadcastPkts));
                                        }

                                        String inPktsPerSecond = counter.get("inPktsPerSecond");
                                        if (!Strings.isNullOrEmpty(inPktsPerSecond)) {
                                            interfaceStatistics.setInPktsPerSecond(Long.parseLong(inPktsPerSecond));
                                        }
                                        String outPktsPerSecond = counter.get("outPktsPerSecond");
                                        if (!Strings.isNullOrEmpty(outPktsPerSecond)) {
                                            interfaceStatistics.setOutPktsPerSecond(Long.parseLong(outPktsPerSecond));
                                        }

                                        String inBandwidth = counter.get("inBandwidth");
                                        if (!Strings.isNullOrEmpty(inBandwidth)) {
                                            interfaceStatistics.setInBandwidth(Long.parseLong(inBandwidth));
                                        }
                                        String outBandwidth = counter.get("outBandwidth");
                                        if (!Strings.isNullOrEmpty(outBandwidth)) {
                                            interfaceStatistics.setOutBandwidth(Long.parseLong(outBandwidth));
                                        }

                                        String inCrcErrors = counter.get("inCrcErrors");
                                        if (!Strings.isNullOrEmpty(inCrcErrors)) {
                                            interfaceStatistics.setInCrcErrors(Long.parseLong(inCrcErrors));
                                        }
                                        String outCrcErrors = counter.get("outCrcErrors");
                                        if (!Strings.isNullOrEmpty(outCrcErrors)) {
                                            interfaceStatistics.setOutCrcErrors(Long.parseLong(outCrcErrors));
                                        }
                                        String inLinkUtilization = counter.get("inLinkUtilization");
                                        if (!Strings.isNullOrEmpty(inLinkUtilization)) {
                                            interfaceStatistics.setInLinkUtilization(Double.parseDouble(inLinkUtilization));
                                        }
                                        String outLinkUtilization = counter.get("outLinkUtilization");
                                        if (!Strings.isNullOrEmpty(outLinkUtilization)) {
                                            interfaceStatistics.setOutLinkUtilization(
                                                    Double.parseDouble(outLinkUtilization));
                                        }

                                        interfaceStatistics.setLastUpdatedTime(
                                                Instant.parse(interfaceStatisticsResponse.getTimestamp().toString()));
                                        interfaceStatistics.setReceivedTime(new Date(System.currentTimeMillis()));
                                        interfaceStatisticsSet.add(interfaceStatistics);
                                    } catch (Exception e) {
                                        log.error("Failed to parse the Interface statistics for {} due to {}", ipAddress, e.getMessage());
                                    }
                                });
                // TODO: To update port_id to interface statistics object.
                List<Object[]> portIds = Lists.newArrayList();
                if (portIndexes != null && !portIndexes.isEmpty()) {
                    portIds = portRepository.findByDeviceIdAndPortIndex(device.getId(), portIndexes);
                }
                constructInterfaceStatistics(interfaceStatisticsSet, portIds);
                if (interfaceStatisticsSet != null) {
                    cacheReceiver.receiveDeviceStats(device, interfaceStatisticsSet);
                    interfaceStatisticsRepository.save(interfaceStatisticsSet);
                }
                log.trace("End: Receive Interface statistics from : {}", ipAddress);
            }
        } else {
            log.info("InterfaceStatistics : device is not part of EVM inventory. {}", ipAddress);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * This method is used to receive system utilization statistics data based on device ipaddress
     * from the collector.
     *
     * @param ipAddress
     * @return
     */
    @RequestMapping(
            method = RequestMethod.PUT,
            consumes = "application/json",
            value = "/systemutilization")
    public ResponseEntity<Object> receiveSystemUtilizationStatistics(
            @RequestParam(value = "deviceip", required = true) String ipAddress,
            @RequestBody SystemUtilizationStatisticsResponse systemUtilizationStatisticsResponse)
            throws JsonProcessingException, JSONException {
        log.trace("Start: Receive System Utilization statistics from : {}", ipAddress);

        if (ipAddress == null) {
            throw new ValidationException("statistics.ipAddress.invalid");
        }

        if (systemUtilizationStatisticsResponse == null) {
            throw new ValidationException("statistics.system.utilization.response.invalid");
        }
        Device device = deviceRepository.findByIpAddress(ipAddress);
        if (device != null) {
            CollectorDeviceMapping collectorDeviceMapping =
                    constructCollectorDevcieMapping(device, CollectorDeviceMapping.TYPE.SystemUtilization);
            Set<SystemUtilizationStatistics> systemUtilizationStatisticsSet = Sets.newHashSet();
            if (systemUtilizationStatisticsResponse.getCounters() != null) {
                systemUtilizationStatisticsResponse.getCounters().stream()
                        .forEach(
                                counter -> {
                                    try {
                                        SystemUtilizationStatistics systemUtilizationStatistics =
                                                new SystemUtilizationStatistics();
                                        String buffers = counter.get("buffers");
                                        if (!Strings.isNullOrEmpty(buffers)) {
                                            systemUtilizationStatistics.setBuffers(Long.parseLong(buffers));
                                        }
                                        String cachedMemory = counter.get("cachedMemory");
                                        if (!Strings.isNullOrEmpty(cachedMemory)) {
                                            systemUtilizationStatistics.setCachedMemory(Long.parseLong(cachedMemory));
                                        }
                                        systemUtilizationStatistics.setCollectorDeviceMapping(collectorDeviceMapping);
                                        String idleState = counter.get("idleState");
                                        if (!Strings.isNullOrEmpty(idleState)) {
                                            systemUtilizationStatistics.setIdleState(Long.parseLong(idleState));
                                        }
                                        String kernelFreeMemory = counter.get("kernelFreeMemory");
                                        if (!Strings.isNullOrEmpty(kernelFreeMemory)) {
                                            systemUtilizationStatistics.setKernelFreeMemory(
                                                    Long.parseLong(kernelFreeMemory));
                                        }
                                        String uptime = counter.get("uptime");
                                        if (!Strings.isNullOrEmpty(uptime)) {
                                            systemUtilizationStatistics.setUptime(Long.parseLong(uptime));
                                        }
                                        String systemProcess = counter.get("systemProcess");
                                        if (!Strings.isNullOrEmpty(systemProcess)) {
                                            systemUtilizationStatistics.setSystemProcess(Long.parseLong(systemProcess));
                                        }
                                        String totalFreeMemory = counter.get("totalFreeMemory");
                                        if (!Strings.isNullOrEmpty(totalFreeMemory)) {
                                            systemUtilizationStatistics.setTotalFreeMemory(Long.parseLong(totalFreeMemory));
                                        }
                                        String totalSystemMemory = counter.get("totalSystemMemory");
                                        if (!Strings.isNullOrEmpty(totalSystemMemory)) {
                                            systemUtilizationStatistics.setTotalSystemMemory(
                                                    Long.parseLong(totalSystemMemory));
                                        }
                                        String totalUsedMemory = counter.get("totalUsedMemory");
                                        if (!Strings.isNullOrEmpty(totalUsedMemory)) {
                                            systemUtilizationStatistics.setTotalUsedMemory(Long.parseLong(totalUsedMemory));
                                        }
                                        String userProcess = counter.get("userProcess");
                                        if (!Strings.isNullOrEmpty(userProcess)) {
                                            systemUtilizationStatistics.setUserProcess(Long.parseLong(userProcess));
                                        }
                                        String userFreeMemory = counter.get("userFreeMemory");
                                        if (!Strings.isNullOrEmpty(userFreeMemory)) {
                                            systemUtilizationStatistics.setUserFreeMemory(Long.parseLong(userFreeMemory));
                                        }
                                        systemUtilizationStatistics.setLastUpdatedTime(
                                                Instant.parse(systemUtilizationStatisticsResponse.getTimestamp().toString()));
                                        systemUtilizationStatistics.setReceivedTime(new Date(System.currentTimeMillis()));

                                        systemUtilizationStatisticsSet.add(systemUtilizationStatistics);
                                    } catch (Exception e) {
                                        log.error("Failed to parse the System Utilization statistics for {} due to {}", ipAddress, e.getMessage());
                                    }
                                });
            }
            if (systemUtilizationStatisticsSet != null) {
                deleteSystemUtilizationStatistics(collectorDeviceMapping.getDevice().getId());
                if (!systemUtilizationStatisticsSet.isEmpty()) {
                    systemUtilizationStatisticsRepository.save(systemUtilizationStatisticsSet);
                }
            }
            log.trace("End: Receive System Utilization statistics from : {}", ipAddress);
        } else {
            log.info("SystemUtilizationStatistics: device is not part of EVM inventory. {}", ipAddress);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * This method is used to receive PBR statistics data based on device ipaddress from the
     * collector.
     *
     * @param ipAddress
     * @return
     */
    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json", value = "/pbr")
    public ResponseEntity<Object> receivePBRStatistics(
            @RequestParam(value = "deviceip", required = true) String ipAddress,
            @RequestBody PBRStatisticsResponse pbrStatisticsResponse)
            throws JsonProcessingException {
        log.trace("Start: Receive PBR statistics from : {}", ipAddress);

        if (ipAddress == null) {
            throw new ValidationException("statistics.ipAddress.invalid");
        }

        if (pbrStatisticsResponse == null) {
            throw new ValidationException("statistics.pbr.response.invalid");
        }
        Device device = deviceRepository.findByIpAddress(ipAddress);
        if (device != null) {
            if (pbrStatisticsResponse.getPbrOperData() != null
                    && !pbrStatisticsResponse.getPbrOperData().isEmpty()) {
                CollectorDeviceMapping collectorDeviceMapping =
                        constructCollectorDevcieMapping(device, CollectorDeviceMapping.TYPE.PBR);
                Set<PBRStatistics> pbrStatisticsSet = Sets.newHashSet();
                pbrStatisticsResponse.getPbrOperData().stream()
                        .forEach(
                                pbrOperData -> {
                                    PBRStatistics pbrStatistics = new PBRStatistics();
                                    if (pbrOperData != null) {
                                        String ifName = pbrOperData.getIfName();
                                        String aclName = pbrOperData.getAclName();
                                        if (!Strings.isNullOrEmpty(ifName) && !Strings.isNullOrEmpty(aclName)) {
                                            pbrStatistics.setInterfaceName(ifName);
                                            pbrStatistics.setCollectorDeviceMapping(collectorDeviceMapping);
                                            if (pbrStatisticsResponse.getTimestamp() != null) {
                                                pbrStatistics.setLastUpdatedTime(
                                                        Instant.parse(pbrStatisticsResponse.getTimestamp().toString()));
                                            }
                                            pbrStatistics.setReceivedTime(new Date(System.currentTimeMillis()));
                                            Set<ACLStatistics> aclStatisticsSet = Sets.newHashSet();
                                            Set<ACLResponse> counters = pbrOperData.getCounters();
                                            Set<ACL> aclSet = Sets.newHashSet();
                                            ACLStatistics aclStatistics = new ACLStatistics();
                                            aclStatistics.setPbrStatistics(pbrStatistics);
                                            aclStatistics.setAclName(aclName);
                                            aclStatistics.setInterfaceName(ifName);
                                            aclStatistics.setNumberOfRules(pbrOperData.getNumberOfRules());
                                            PortGroup portGroup = null;
                                            if(ifName.contains("Port-channel")) {
                                                ifName = ifName.replaceAll("[^0-9]", "");
                                                portGroup = portGroupRepository.findByNameAndDeviceId(ifName, device.getId());
                                            }
                                            Long portId = null;
                                            Port port = null;
                                            if(portGroup != null) {
                                                portId = portGroup.getId();
                                            }else {
                                                port = portRepository.findPortByNameAndDeviceId(ifName, device.getId());
                                                if(port != null) {
                                                    portId = port.getId();
                                                }
                                            }

                                            if(port != null || portGroup != null) {
                                                List<BigInteger> policies =
                                                        flowRepository.findPolicyIdByDeviceIdAndACLName(device.getId(), portId);

                                                if (policies != null && !policies.isEmpty()) {
                                                    if (policies.get(0) != null) {
                                                        Long id = policies.get(0).longValue();
                                                        aclStatistics.setPolicyId(id);
                                                    }

                                                    if (counters != null) {
                                                        counters.forEach(
                                                                aclResponse -> {
                                                                    try {
                                                                        ACL acl = new ACL();
                                                                        String seqNum = aclResponse.getSeqNum();
                                                                        if (!Strings.isNullOrEmpty(seqNum)) {
                                                                            acl.setSeqNum(Long.parseLong(seqNum));
                                                                        }
                                                                        String hitCount = aclResponse.getHitCount();
                                                                        if (!Strings.isNullOrEmpty(hitCount)) {
                                                                            acl.setHitCount(Long.parseLong(hitCount));
                                                                        }
                                                                        String byteCount = aclResponse.getByteCount();
                                                                        if (!Strings.isNullOrEmpty(byteCount)) {
                                                                            acl.setByteCount(Long.parseLong(byteCount));
                                                                        }
                                                                        if (pbrStatisticsResponse.getTimestamp() != null) {
                                                                            acl.setLastUpdatedTime(
                                                                                    Instant.parse(
                                                                                            pbrStatisticsResponse.getTimestamp().toString()));
                                                                        }
                                                                        acl.setAclStatistics(aclStatistics);
                                                                        aclStatistics.setAcls(aclSet);
                                                                        aclStatisticsSet.add(aclStatistics);
                                                                        aclSet.add(acl);
                                                                    } catch (Exception e) {
                                                                        log.error("Failed to parse the PBR statistics for {} due to {}", ipAddress, e.getMessage());
                                                                    }
                                                                });

                                                        pbrStatistics.setAclStatistics(aclStatisticsSet);
                                                        pbrStatisticsSet.add(pbrStatistics);
                                                    }
                                                }
                                            }
                                        } else {
                                            log.trace("Interface/ACL name is invalid for device {}", ipAddress);
                                        }
                                    }
                                });
                if (pbrStatisticsSet != null) {
                    deletePBRStatistics(collectorDeviceMapping.getDevice().getId());
                    if (!pbrStatisticsSet.isEmpty()) {
                        pbrStatisticsRepository.save(pbrStatisticsSet);
                    }
                }
                log.trace("End: Receive PBR statistics from : {}", ipAddress);
            }
        } else {
            log.info("PBRStatistics: device is not part of EVM inventory. {}", ipAddress);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * This method is used to receive SLX device status from the collector.
     *
     * @return
     */
    @RequestMapping(
            method = RequestMethod.PUT,
            consumes = "application/json",
            value = "/device/status")
    public ResponseEntity<Object> receiveDeviceStatus(
            @RequestBody DeviceStatusResponse deviceStatusResponse) {
        if (deviceStatusResponse == null) {
            log.error("Invalid device status response from collector.");
            throw new ValidationException("statistics.device.status.response.invalid");
        }
        log.trace("SLX Device {} status updated as {}.", deviceStatusResponse.getDeviceIPAddress(), deviceStatusResponse.getState());

        String ipAddress = deviceStatusResponse.getDeviceIPAddress();
        if (!Strings.isNullOrEmpty(ipAddress)) {
            Device device = deviceRepository.findByIpAddress(ipAddress);
            if (device != null) {
                Integer status = deviceStatusResponse.getState();
                if (status != device.getStatus()) {
                    device.setStatus(status);
                    deviceRepository.save(device);
                    if (device.getStatus() == Device.STATUS_DOWN) {
                        sendDeviceStatusNotification(device, "DEVICE_DOWN", Job.Status.SUCCESS, Event.Severity.INFO, "Device is down!");
                    } else if (device.getStatus() == Device.STATUS_DISCONNECTED) {
                        sendDeviceStatusNotification(device, "DEVICE_DISCONNECTED", Job.Status.SUCCESS, Event.Severity.INFO,
                                "Connection between collector and device is down!");
                    } else if (device.getStatus() == Device.STATUS_UP) {
                        sendDeviceStatusNotification(device, "DEVICE_UP", Job.Status.SUCCESS, Event.Severity.INFO,
                                "Connection between collector and device is up!");
                    }
                }
            } else {
                log.info("DeviceStatus: device is not part of EVM inventory. {}", ipAddress);
            }
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * This method constructs the collector device mapping object. device
     *
     * @param device
     * @return
     */
    private synchronized CollectorDeviceMapping constructCollectorDevcieMapping(
            Device device, CollectorDeviceMapping.TYPE type) {
        CollectorDeviceMapping collectorDeviceMapping =
                collectorDeviceMappingRepository.findByDeviceIdAndProfileType(device.getId(), type);
        if (collectorDeviceMapping == null) {
            collectorDeviceMapping = new CollectorDeviceMapping();
            collectorDeviceMapping.setProfileType(type);
            collectorDeviceMapping.setDevice(device);
            collectorDeviceMappingRepository.save(collectorDeviceMapping);
        }
        return collectorDeviceMapping;
    }

    /**
     * This method to updates the port_id in the interface statistics object. device
     *
     * @param interfaceStatisticsSet
     * @param portIds
     * @return
     */
    private void constructInterfaceStatistics(
            Set<InterfaceStatistics> interfaceStatisticsSet, List<Object[]> portIds) {
        if (portIds != null && !portIds.isEmpty()) {
            for (Object[] port : portIds) {
                if (portIds.size() >= 1 && port[0] != null && port[1] != null) {
                    Long portId = (Long) port[0];
                    Long portIndex = (Long) port[1];
                    Optional<InterfaceStatistics> optional =
                            interfaceStatisticsSet.stream()
                                    .filter(
                                            interfaceStatistics ->
                                                    portIndex != null && portIndex.equals(interfaceStatistics.getIfIndex()))
                                    .findAny();
                    if (optional.isPresent()) {
                        optional.get().setPortId(portId);
                    }
                }
            }
        }
    }

    @Scheduled(fixedRateString = "${statistics.scheduler.timer.interval.milliseconds}")
    public void clearStatistics() {
        log.trace("Clearing interface and system utilization statistics.");
        clearInterfaceStatistics();
        clearSystemUtilizationStatistics();
        clearPBRStatistics();
        switchCache.deleteDeviceUtilization(STATISTICS_DATA_TIMER_INTERVAL_IN_SECONDS);
    }

    private void clearInterfaceStatistics() {
        Integer deleteCount = 0;
        try {
            deleteCount =
                    interfaceStatisticsRepository.deleteInterfaceStatistics(
                            STATISTICS_DATA_TIMER_INTERVAL_IN_SECONDS);
        } catch (Exception e) {
            log.error("Error while deleting interface statistics {}", e.getMessage());
        }
        log.trace("Interface statistics records deleted {}.", deleteCount);
    }

    private void clearSystemUtilizationStatistics() {
        Integer deleteCount = 0;
        try {
            deleteCount =
                    systemUtilizationStatisticsRepository.deleteSystemUtilizationStatistics(
                            STATISTICS_DATA_TIMER_INTERVAL_IN_SECONDS);
        } catch (Exception e) {
            log.error("Error while deleting system utilization statistics {}", e.getMessage());
        }
        log.trace("System utilization statistics records deleted {}.", deleteCount);
    }

    private void deleteSystemUtilizationStatistics(Long collectorId) {
        Integer deleteCount = 0;
        try {
            deleteCount =
                    systemUtilizationStatisticsRepository.deleteSystemUtilizationStatisticsByCollectorId(
                            collectorId);
        } catch (Exception e) {
            log.error("Error while deleting system utilization statistics {}", e.getMessage());
        }
        log.trace("System utilization statistics records deleted {}.", deleteCount);
    }

    private void clearPBRStatistics() {
        Integer deleteCount = 0;
        try {
            deleteCount =
                    pbrStatisticsRepository.deletePBRStatistics(STATISTICS_DATA_TIMER_INTERVAL_IN_SECONDS);
        } catch (Exception e) {
            log.error("Error while deleting PBR statistics {}", e.getMessage());
        }
        log.trace("PBR Statistics records deleted {}.", deleteCount);
    }

    private void deletePBRStatistics(Long collectorId) {
        Integer deleteCount = 0;
        try {
            deleteCount = pbrStatisticsRepository.deletePBRStatisticsByCollectorId(collectorId);
        } catch (Exception e) {
            log.error("Error while deleting PBR statistics {}", e.getMessage());
        }
        log.trace("PBR Statistics records deleted {}.", deleteCount);
    }

    private void sendDeviceStatusNotification(Device device, String type, Job.Status status, Event.Severity severity, String result) {
        Event event = new Event();
        event.setParentObjectId(device.getId());
        event.setType(type);
        event.setJobStatus(status.toString());
        event.setSeverity(severity);
        event.setCreatedByUser(
                configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
        event.setCreatedTime(Instant.now());
        event.setTargetHost(device.getName());
        event.setLastUpdatedTime(Instant.now());
        event.setResult(result);
        eventRepository.save(event);
    }
}
