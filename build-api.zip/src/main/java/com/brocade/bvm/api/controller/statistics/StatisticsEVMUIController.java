package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.manager.statistics.SwitchOverviewManager;
import com.brocade.bvm.api.model.statistics.EVMOverView;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.EVMPlatform;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.statistics.StatisticsGridRepository;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsSwitchRepository;
import com.brocade.bvm.model.db.statistics.EVMOverview;
import com.brocade.bvm.model.db.statistics.EVMStatisticsOverview;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RequestMapping(produces = "application/json", value = "/statistics")
@RestController
@Slf4j
public class StatisticsEVMUIController {

  @Inject private ManagedObjectAuthorityProvider authorityProvider;

  @Inject private DeviceRepository deviceRepository;

  @Inject private StatisticsPortRepository statisticsPortRepository;

  @Inject private SwitchOverviewManager switchOverviewManager;

  @Inject private StatisticsSwitchRepository statisticsSwitchRepository;

  @Inject private StatisticsGridRepository statisticsGridRepository;
  @Inject private StatisticsPolicyRepository statisticsPolicyRepository;

  /**
   * This endpoint returns evm overview.
   *
   * @return EVMOverview
   */
  @RequestMapping(method = RequestMethod.GET, value = "/evm-overview")
  public ResponseEntity<EVMOverView> evmOverView() throws Exception {
    log.debug("Start: evm overview");
    List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
    EVMOverView evmOverview = new EVMOverView();
    if (stablenetDeviceIds.isEmpty()) {
      log.debug("No device available");
      evmOverview.setTotalNoOfSwitches(0L);
    } else {
      evmOverview.setTotalNoOfSwitches(deviceRepository.count());
    }

    evmOverview.setMemoryUtilization(EVMPlatform.memoryUtilization());
    evmOverview.setCpuUtilization(Double.parseDouble(EVMPlatform.getProcessCpuLoad()));
    EVMOverview evmOverview1 = statisticsPortRepository.evmOverview();
    evmOverview.setTotalNoOfGrids(evmOverview1.getTotalNoOfGrids());
    evmOverview.setTotalSLX(statisticsSwitchRepository.findCountOfAllSLXDevices());
    evmOverview.setTotalMLX(statisticsSwitchRepository.findCountOfAllMLXEDevices());
    evmOverview.setTotalPolices(statisticsPolicyRepository.operationalSwitchesPoliciesCount());
    evmOverview.setTotalSoftwareServers(statisticsSwitchRepository.findAllSDDevicesCount());
    evmOverview.setTotalTapPorts(
        statisticsPortRepository.getALLTapPortsCount());
    evmOverview.setTotalToolPorts(
        statisticsPortRepository.getAllToolPortsCount());
    evmOverview.setTotalMemory(EVMPlatform.totalMemory());
    evmOverview.setCpuCores(EVMPlatform.getNumberOfCPUCores());

    log.debug("End: evm overview");
    return new ResponseEntity<>(evmOverview, HttpStatus.OK);
  }

  /** This endpoints return EVM statistics overview */
  @RequestMapping(method = RequestMethod.GET, value = "/evm-statistics-overview")
  public ResponseEntity<EVMStatisticsOverview> evmStatisticsOverview()
      throws ExecutionException, InterruptedException {
    log.debug("Start: evm statistics overview");
    EVMStatisticsOverview evmStatisticsOverview = new EVMStatisticsOverview();

    CompletableFuture topFiveSwitches = switchOverviewManager.findTopFiveSwitches();
    CompletableFuture bottomFiveSwitches = switchOverviewManager.findBottomFiveSwitches();
    CompletableFuture<List<String>> topFiveGrids = statisticsGridRepository.findTopFiveGrids();
    CompletableFuture<List<String>> bottomFiveGrids =
        statisticsGridRepository.findBottomFiveGrids();

    CompletableFuture.allOf(topFiveSwitches, bottomFiveSwitches, topFiveGrids, bottomFiveGrids)
        .join();

    evmStatisticsOverview.setTopFiveDevices((List) topFiveSwitches.get());
    evmStatisticsOverview.setBottomFiveDevices((List) bottomFiveSwitches.get());
    evmStatisticsOverview.setTopFiveTapPorts(switchOverviewManager.findTopFiveTapPorts());
    evmStatisticsOverview.setBottomFiveTapPorts(switchOverviewManager.findBottomFiveTapPorts());
    evmStatisticsOverview.setTopFiveToolPorts(switchOverviewManager.findTopFiveToolPorts());
    evmStatisticsOverview.setBottomFiveToolPorts(switchOverviewManager.findBottomFiveToolPorts());
    evmStatisticsOverview.setTopFiveGrids(topFiveGrids.get());
    evmStatisticsOverview.setBottomFiveGrids(bottomFiveGrids.get());

    log.debug("End: evm statistics overview");

    return new ResponseEntity<>(evmStatisticsOverview, HttpStatus.OK);
  }

  /**
   * This method is used for get audit Details.
   *
   * @return
   */
  @RequestMapping(method = RequestMethod.GET, value = "/audit")
  public ResponseEntity<Object> getAuditDetails() {
    log.debug("Enter: Audit Details ");
    return new ResponseEntity<>(switchOverviewManager.getAuditDetails(), HttpStatus.OK);
  }
}
