package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractPortGroupManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.sessiondirector.IngressPortRepository;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The PortGroupManagerNonOpenFlow class implements methods related to port group for NonOpenFlow
 */
@Named
@Slf4j
public class PortGroupManagerNonOpenFlow extends AbstractPortGroupManager {

    @Inject
    private IngressPortRepository ingressPortRepository;

    /**
     * This method validates if the portGroup is part of any Packet Slicing policy
     *
     * @param portGroup
     * @throws ValidationException
     */
    @Override
    protected void validateAllPortsInPacketSlicing(PortGroup portGroup) throws ValidationException {
        if (portGroup != null && !portGroup.getPorts().isEmpty()) {
            List<Long> portIds = packetSlicingModulePolicyRepository.findPortsByEgressPorts(portGroup.getPorts().stream().map(Port::getId).collect(Collectors.toList()));
            if (!portIds.isEmpty() && (portIds.size() != portGroup.getPorts().size())) {
                throw new ValidationException("portGroup.ports.existsInPacketSlicing");
            }
        }
    }

    /**
     * This method does validates if the portGroup is used in Non Open Flow policy as ingress or egress
     *
     * @param portGroupId
     * @throws ValidationException
     */
    @Override
    protected void validatePortGroupIfUsedInPolicy(Long portGroupId, boolean isPortChannel) throws ValidationException {
        if (portGroupId != null && (!portGroupRepository.findServicePortGroupIsUseInPolicy(portGroupId).isEmpty() || !portGroupRepository.findEgressPortGroupIsUseInPolicy(portGroupId).isEmpty())) {
            if (isPortChannel) {
                throw new ValidationException("portChannel.operation.notallowed");
            } else {
                throw new ValidationException("portGroup.operation.notallowed");
            }
        }
    }

    protected void validatePortsIfUsedInPolicy(List<Long> portIds, boolean isPortChannel) {
        if (portIds != null && !portIds.isEmpty() && !portGroupRepository.findIngressOrEgressPortIdsByPortIds(portIds).isEmpty()) {
            log.error("Participating ports are in use by policies as Service Port or EGRESS. Aborting!");
            if (isPortChannel) {
                throw new ValidationException("port.exists.policy.portChannel.error");
            } else {
                throw new ValidationException("port.exists.policy");
            }
        }
    }

    @Override
    protected void validatePortsIfUsedInSDPorts(List<Long> portIds) throws ValidationException {
        if (portIds != null && !portIds.isEmpty()) {
            List<Long> sdIngressPortIds = ingressPortRepository.findByServicePortIds(portIds);
            if (!sdIngressPortIds.isEmpty()) {
                log.error("Participating ports are in use by SD Ingress Port(s) as Servie Port(s). Aborting!");
                throw new ValidationException("portGroup.port.exists.sdIngress");
            }
        }
    }

}
