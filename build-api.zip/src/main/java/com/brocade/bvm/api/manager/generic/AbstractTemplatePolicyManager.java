package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.TemplatePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.FlexMatchProfile;
import com.brocade.bvm.model.db.TemplatePolicy;

import java.util.*;

public abstract class AbstractTemplatePolicyManager implements TemplatePolicyManager {

    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";
    public static final String CLEANUP = "cleanup";

    @Override
    public List<Long> saveOrCommitPolicies(Set<? extends TemplatePolicy> templatePolicies, String action) {
        List<Long> jobIds = new ArrayList<>();
        if (!templatePolicies.isEmpty()) {
            validateTemplatePolicies(templatePolicies);
            TemplatePolicy templatePolicy = templatePolicies.stream().findFirst().get();
            if (SAVE.equals(action)) {
                jobIds.add(savePolicy(templatePolicy));
            } else if (COMMIT.equals(action)) {
                jobIds.add(commitPolicy(templatePolicy));
            } else if (UPDATE.equals(action)) {
                jobIds.add(updatePolicy(templatePolicy));
            }
        }
        return jobIds;
    }

    @Override
    public Map<String, Set<TemplatePolicy>> getTemplatePolicies(Set<? extends TemplatePolicy> templatePolicies) {
        Map<String, Set<TemplatePolicy>> policyMap = new HashMap<>();
        if (templatePolicies != null) {
            Set<TemplatePolicy> slxFlexMatchProfiles = new HashSet<>();
            templatePolicies.stream().forEach(devicePolicy -> {
                if (devicePolicy instanceof FlexMatchProfile) {
                    slxFlexMatchProfiles.add(devicePolicy);
                }
            });
            policyMap.put("slxFlexMatchProfiles", slxFlexMatchProfiles);
        }
        return policyMap;
    }

    /**
     * This method validates if TemplatePolicy data is valid to commit
     *
     * @param templatePolicies
     * @throws ValidationException
     */
    @Override
    public void validateTemplatePolicies(Set<? extends TemplatePolicy> templatePolicies) {
        if (!templatePolicies.isEmpty()) {
            TemplatePolicy devicePolicy = templatePolicies.stream().findFirst().get();
            if (!isValidPolicy(devicePolicy)) {
                throw new ValidationException("");
            }
        }
    }

    @Override
    public Long deletePolicy(Long policyId) {
        return null;
    }

    @Override
    public Long recoverPolicy(Long policyId) {
        return null;
    }

    protected abstract boolean isValidPolicy(TemplatePolicy policy);

    protected abstract Long savePolicy(TemplatePolicy policy);

    protected abstract Long commitPolicy(TemplatePolicy policy);

    protected abstract Long updatePolicy(TemplatePolicy policy);
}
