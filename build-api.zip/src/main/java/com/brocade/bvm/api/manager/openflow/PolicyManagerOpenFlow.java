package com.brocade.bvm.api.manager.openflow;

import com.brocade.bvm.api.manager.generic.AbstractPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.utility.MACAddressValidator;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Named;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The PolicyManagerOpenFlow class implements methods related to policy for OpenFlow
 */
@Slf4j
@Named
public class PolicyManagerOpenFlow extends AbstractPolicyManager {

	public static final String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/(([0-9])|([1-2][0-9])|(3[0-2]))$";
	private static final String PROTOCOL_SCTP = "sctp";
	private static final String IPV4_BROADCAST_ADDRESS = "255.255.255.255";
	private static final String IPV6_BROADCAST_ADDRESS = "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff";

	@Value("${bsc.resource-url.icx.max.flows}")
	private Long maxICXFlows;
    @Value("${bsc.resource-url.mlxe.max.flows}")
	private Long maxMlxeFlows;
	@Value("${bsc.resource-url.slx.max.flows}")
	private Long maxSlxFlows;

	/**
	 * This method validates if the policy data is valid to save in BVM
	 *
	 * @param policy
	 * @return boolean
	 * @throws ValidationException
	 */
	@Override
	public boolean isValidPolicyToSave(Policy policy, boolean isStandalone) throws ValidationException {
		if(policy.getGridPolicySetId() != null && isStandalone) {
			log.error("Cannot save policy as it is associated with a grid policy.");
			throw new ValidationException("Cannot save policy as it is associated with a grid policy.");
		}

		validateIfIngressAndEgressPortsAndPortGroupAreValid(policy);
		isValidPorts(policy);
		isTagAndDeviceIdUnique(policy);
		isFlowCountExceeded(policy, WorkflowParticipant.WorkflowStatus.ACTIVE);
		isPolicyCandidateToSave(policy);// 10106
		//TODO: dependent on CommandBuilder to construct the rulestring
		//isRuleStringUnique(policy);
		isRuleContainsValidIp(policy);
		isValidSLXPolicy(policy);
		return true;
	}

	/**
	 * This method validates if the policy data is valid to update in bvm
	 *
	 * @param policy
	 * @return boolean
	 */
	@Override
	protected boolean isValidPolicyToUpdate(Policy policy, boolean isStandalone) throws ValidationException {
		if(policy.getGridPolicySetId() != null && isStandalone) {
			log.error("Cannot update policy as it is associated with a grid policy.");
			throw new ValidationException("Cannot update policy as it is associated with a grid policy.");
		}
        isTagAndDeviceIdUniqueForUpdate(policy);
		validateIfIngressAndEgressPortsAndPortGroupAreValid(policy);
		isValidPorts(policy);
        isPolicyCandidateToSave(policy);
		isRuleContainsValidIp(policy);
        isFlowCountExceeded(policy, WorkflowParticipant.WorkflowStatus.ACTIVE);
		isValidSLXPolicy(policy);
		return true;
	}

	/**
	 * This method validates if the policy data is valid to commit on the device
	 *
	 * @param policy
	 * @return boolean
	 */
	@Override
	public boolean isValidPolicyToCommit(Policy policy, boolean isStandalone) {
		if(policy.getGridPolicySetId() != null && isStandalone) {
			log.error("Cannot commit policy as it is associated with a grid policy.");
			throw new ValidationException("Cannot commit policy as it is associated with a grid policy.");
		}
		isValidPorts(policy);
		isAnyPolicyInProgessOrError(policy);
        isFlowCountExceeded(policy, WorkflowParticipant.WorkflowStatus.ACTIVE);
		return true;
	}

	/**
	 * This method validates if rules in the policy contains valid IPV4 or IPV6
	 *
	 * @param policy
	 * @return boolean
	 */
	private boolean isRuleContainsValidIp(Policy policy) {
		for (Flow eachFlow : policy.getFlows()) {
			for (Rule rule : getFlatRules(eachFlow.getRuleSets())) {
				String etherType = rule.getEthType();
				String srcIp = rule.getSourceIp();
				String destIP = rule.getDestinationIp();

				if (etherType != null && !(etherType.equalsIgnoreCase("any"))) {
					if (etherType.equalsIgnoreCase("ipv4")) {
						if (!validateIp(srcIp, IPV4_PATTERN) || !validateIp(destIP, IPV4_PATTERN)) {
							throw new ValidationException("policy.save.invalidipv4");
						}
						if (srcIp != null && !srcIp.trim().isEmpty() && !"any".equalsIgnoreCase(srcIp)) {
							String sourceIp = srcIp;
							if (srcIp.contains("/")) {
								sourceIp = srcIp.substring(0, srcIp.indexOf("/"));
							}
							try {
								Inet4Address inet4Address = (Inet4Address) Inet4Address.getByName(sourceIp);
								if (inet4Address.isMulticastAddress()) {
									throw new ValidationException("rule.sourceIp.notSupported");
								} else if (IPV4_BROADCAST_ADDRESS.equals(sourceIp)) {
									throw new ValidationException("rule.sourceIp.notSupported");
								}
							} catch (UnknownHostException e) {
								throw new ValidationException("policy.save.invalidipv4");
							}
						}
					} else if (etherType.equalsIgnoreCase("ipv6")) {
						if (!validateIpv6(srcIp) || !validateIpv6(destIP)) {
							throw new ValidationException("policy.save.invalidipv6");
						}
						if (srcIp != null && !srcIp.trim().isEmpty() && !"any".equalsIgnoreCase(srcIp)) {
							try {
								String sourceIp = srcIp;
								if (srcIp.contains("/")) {
									sourceIp = srcIp.substring(0, srcIp.indexOf("/"));
								}
								Inet6Address inet6Address = (Inet6Address) Inet6Address.getByName(sourceIp);
								if (inet6Address.isMulticastAddress()) {
									throw new ValidationException("rule.sourceIp.notSupported");
								} else if (IPV6_BROADCAST_ADDRESS.equals(sourceIp)) {
									throw new ValidationException("rule.sourceIp.notSupported");
								}
							} catch (UnknownHostException e) {
								throw new ValidationException("policy.save.invalidipv6");
							}
						}
					} else if (etherType.equalsIgnoreCase("arp")) {
						if (!validateIp(srcIp, IPV4_PATTERN) || !validateIp(destIP, IPV4_PATTERN)) {
							throw new ValidationException("policy.save.invalidipv4");
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * This method validates if the given ip is a valid
	 *
	 * @param ip
	 * @return boolean
	 */
	private boolean validateIp(String ip, String regex) {
		if(ip != null) {
			if ("any".equalsIgnoreCase(ip)) {
				return true;
			}
            else {
				Pattern pattern = Pattern.compile(regex);
				return pattern.matcher(ip).matches();
			}
		}
		return true;
	}

	/**
	 * This method collects all the rule objects from all the RuleSet objects
	 *
	 * @param ruleSetList
	 * @return List<Rule>
	 */
	private List<Rule> getFlatRules(Set<RuleSet> ruleSetList) {
		// Creating duplicate list of Rule from Ruleset and updating the
		// ethernet type for any and null cases.
		List<Rule> rules = new ArrayList<>();
		for (RuleSet ruleSet : ruleSetList) {
			Set<Rule> ruleList = ruleSet.getRules();
			for (Rule rule : ruleList) {
				Rule ruleNew = new Rule();
				ruleNew.setSourceIp(rule.getSourceIp());
				ruleNew.setDestinationIp(rule.getDestinationIp());
                ruleNew.setSequence(rule.getSequence());
                ruleNew.setVlanId(rule.getVlanId());
				// L2 case - any, ip4, ip6, arp
				// L3/L4 case - ip4 ip6
				// L23 case - ip4, ip6
				ruleNew.setEthType(rule.getEthType());
				rules.add(ruleNew);
			}
		}
		return rules;
	}

	private boolean isRuleStringUnique(Policy policy) {

		// get all policies for a device
		List<String> existingRulesString = new ArrayList<String>();
		List<String> currentPolicyRulesString = new ArrayList<String>();
		List<Rule> existingRulesForDevice = ruleRepository.findAllRulesByDevice(policy.getDevice().getId());
		existingRulesString = constructRuleStringForPolicies(existingRulesForDevice);
		// collect all rules in the current policy
		List<Rule> curentRules = new ArrayList<>();
		for (Flow eachFlow : policy.getFlows()) {
			for (RuleSet eachRuleSet : eachFlow.getRuleSets()) {
				curentRules.addAll(eachRuleSet.getRules());
			}
		}
		currentPolicyRulesString = constructRuleStringForPolicies(curentRules);

		for (String ruleString : currentPolicyRulesString) {
			if (existingRulesString.contains(ruleString)) {
				throw new ValidationException("policy.save.rulenotunique");
			}
		}
		return true;
	}

	private List<String> constructRuleStringForPolicies(List<Rule> rules) {
		List<String> commandRuleList = new ArrayList<String>();


		// TODO: dependency on CommandBuilder ?
		// PolicyCommandBuilder policyCommandBuilder = new
		// PolicyCommandBuilder();
		//
		// for (RuleSet ruleSet : policyWrapper.getPolicy().getRuleSetList()) {
		//
		// if (ruleSet.getType().equalsIgnoreCase("l2") ||
		// ruleSet.getType().equalsIgnoreCase("mac")) {
		// commandRuleList.addAll(policyCommandBuilder.buildMacRuleCommands(ruleSet.getRuleList()));
		//
		// } else if (ruleSet.getType().equalsIgnoreCase("l23") ||
		// ruleSet.getOrder() == 3) {
		// commandRuleList.addAll(policyCommandBuilder.buildL23MacRuleCommands(ruleSet.getRuleList()));
		// } else {
		// commandRuleList.addAll(policyCommandBuilder.buildRuleCommands(ruleSet.getRuleList()));
		// }
		//
		// }

		return commandRuleList;
	}

	/**
	 * This method checks if no. of flows created, exceed the maximum allowed
	 *
	 * @param policy
	 * @param status
	 * @return boolean
	 * @throws ValidationException if the maximum flow count is reached
	 */
	private boolean isFlowCountExceeded(Policy policy, WorkflowParticipant.WorkflowStatus status) {
		Integer currentPolicyRuleCount = 0;
		for (Flow eachFlow : policy.getFlows()) {
			for (RuleSet eachRuleSet : eachFlow.getRuleSets()) {
				currentPolicyRuleCount += eachRuleSet.getRules().size();
			}
		}
		Integer totalRulesOnDeviceCount = ruleRepository.findAllRulesByDeviceAndStatusAndNotInPolicy(policy.getDevice().getId(),
				status, policy.getId());

		if (policy.getDevice().getType() == Device.Type.ICX) {
			if (totalRulesOnDeviceCount + currentPolicyRuleCount <= maxICXFlows) {
				return true;
			}
		} else if (policy.getDevice().getType() == Device.Type.MLXE) {
			if (totalRulesOnDeviceCount + currentPolicyRuleCount <= maxMlxeFlows) {
				return true;
			}
		} else if (policy.getDevice().getType() == Device.Type.SLX) {
			if (totalRulesOnDeviceCount + currentPolicyRuleCount <= maxSlxFlows) {
				return true;
			}
		}
		throw new ValidationException("policy.save.maxflowcount");
	}

	/**
	 * This method checks if the flow priority is between 0 and 65535
	 *
	 * @param policy
	 * @return boolean
	 * @throws ValidationException if the flow priority is not with in the range
	 */
	public boolean isFlowPriorityValid(Policy policy) throws ValidationException {
        for (Flow eachFlow : policy.getFlows()) {
            int flowPriority = eachFlow.getSequence();
            Set<RuleSet> ruleSet = eachFlow.getRuleSets();
            List<Rule> flatRules = getFlatRules(ruleSet);
            for (Rule rule : flatRules) {
                long priority = rule.getSequence() + flowPriority;
                if(priority<0 || priority>65535){
                    throw new ValidationException("policy.priority.notvalid");
                }
            }
        }
        return true;
	}

	/**
	 * This method checks if the flow VLAN is with in the valid range
	 *
	 * @param policy
	 * @return boolean
	 * @throws ValidationException if the flow VLAN is not with in the range
	 */
	public boolean isVLanValid(Policy policy) throws ValidationException {
        for (Flow eachFlow : policy.getFlows()) {
            String vLan = eachFlow.getVlans().size()>0?eachFlow.getVlans().stream().findFirst().get():null;
            if(vLan !=null) {
                int flowVLanId = Integer.parseInt(vLan);
                if (flowVLanId < 1 || flowVLanId > 4094) {
                    throw new ValidationException("flow.vlan.notvalid");
                }
            }
            Set<RuleSet> ruleSet = eachFlow.getRuleSets();
            List<Rule> flatRules = getFlatRules(ruleSet);
            Device device = deviceRepository.findById(policy.getDevice().getId());
			for (Rule rule : flatRules) {
				int ruleVLanId = rule.getVlanId();
				if (ruleVLanId > 0) {
					if (device.getMode() == Device.Mode.OPENFLOW && (device.getType() == Device.Type.ICX || device.getType() == Device.Type.SLX)) { // TODO To be changed, after confirmation for SLX
						if (ruleVLanId > 4095) {
							throw new ValidationException("rule.icx.vlan.notvalid");
						}
					} else if (device.getMode() == Device.Mode.OPENFLOW && device.getType() == Device.Type.MLXE) {
						if (ruleVLanId >= 4095) {
							throw new ValidationException("rule.mlxe.vlan.notvalid");
						}
					}
				}
			}

			ruleSet.forEach(ruleSet1 -> {
				ruleSet1.getRules().forEach(rule -> {
					String sourceMac = rule.getSourceMac();
					if (sourceMac != null && !sourceMac.trim().isEmpty() && !"any".equals(sourceMac)) {
						MACAddressValidator macAddressValidator = MACAddressValidator.valueOf(sourceMac);
						if (macAddressValidator.isMulticast()) {
							throw new ValidationException("rule.sourceMac.notSupported");
						} else if (macAddressValidator.isBroadcast()) {
							throw new ValidationException("rule.sourceMac.notSupported");
						}
					}
					String etherType = rule.getEthType();
					if (policy.getDevice().getType() == Device.Type.SLX && policy.getDevice().getMode() == Device.Mode.OPENFLOW) {
						String srcMac = rule.getSourceMac();
						String destMac = rule.getDestinationMac();
						if ((srcMac != null && !srcMac.trim().isEmpty() && !"any".equalsIgnoreCase(srcMac)) || (destMac != null && !destMac.trim().isEmpty() && !"any".equalsIgnoreCase(destMac))) {
							if (etherType != null && !"any".equalsIgnoreCase(etherType) && "ipv6".equalsIgnoreCase(etherType)) {
								throw new ValidationException("policy.save.bothMacAndIp.notAllowed");
							}
						}
					}
				});
			});
		}
        return true;
    }

	/**
	 * This method checks if the selected ingress/egress port(s)/portGroup(s) are valid
	 *
	 * @param policy
	 * @return boolean
	 * @throws ValidationException if the flow VLAN is not with in the range
	 */
	private boolean isValidPorts(Policy policy) throws ValidationException {
		policy.getFlows().forEach(flow -> {
			Set<Port.Mode> ingressPortModes = flow.getIngressPorts().stream().map(Port::getMode).collect(Collectors.toSet());

			if (flow.getIngressPortGroups().isEmpty() && flow.getIngressPorts().isEmpty()) {
                throw new ValidationException("policy.sourcePort.isEmpty");
            }

			if (ingressPortModes.size() > 1) {
				throw new ValidationException("policy.sourcePort.modeInvalid");
			}

			if (!flow.getEgressPorts().isEmpty() && !flow.getEgressPortGroups().isEmpty()) {
				throw new ValidationException("policy.destinationPort.portAndPortGroupNotAllowed");
			} else if (flow.getEgressPortGroups().size() > 1) {
				throw new ValidationException("policy.destinationPort.portGroupSizeNotAllowed");
			}
		});
		return true;
	}

	private void isValidSLXPolicy(Policy policy) {
		Long policyId = policy.getId() != null ? policy.getId() : 0L;
		if (policy.getDevice().getType() == Device.Type.SLX && policy.getDevice().getMode() == Device.Mode.OPENFLOW) {
			policy.getFlows().forEach(flow -> {
				PortGroup portGroup = flow.getEgressPortGroups().stream().findAny().orElse(null);
				if (portGroup != null) {
					List<Policy> policies = policyRepository.findPoliciesByEgressPortGroupIdAndNotInCurrentPolicy(portGroup.getId(), policyId);
					if (policies != null && !policies.isEmpty()) {
						policies.forEach(policy1 -> {
							policy1.getFlows().forEach(flow1 -> {
								if (flow1.getVlanStripping()) {
									throw new ValidationException("policy.egressPortGroup.stripping.usedInAnotherPolicy");
								}
								if (flow.getVlanStripping()) {
									throw new ValidationException("policy.egressPortGroup.stripping.usedInCurrentPolicy");
								}
								if (flow1.getVlans() != null && !flow1.getVlans().isEmpty()) {
									throw new ValidationException("policy.egressPortGroup.tagging.usedInAnotherPolicy");
								}
								if (flow.getVlans() != null && !flow.getVlans().isEmpty()) {
									throw new ValidationException("policy.egressPortGroup.tagging.usedInCurrentPolicy");
								}
							});
						});
					}

					policies = getActivePoliciesFromHistoryForDraftPolicies(policy.getDevice().getId(), policyId);
					if (policies != null && !policies.isEmpty()) {
						policies.forEach(policy1 -> {
							policy1.getFlows().forEach(flow1 -> {
								if (flow.getVlanStripping()) {
									throw new ValidationException("policy.egressPortGroup.stripping.usedInAnotherPolicy");
								}
								if (flow1.getVlanStripping()) {
									throw new ValidationException("policy.egressPortGroup.stripping.usedInCurrentPolicy");
								}
								if (flow.getVlans() != null && !flow.getVlans().isEmpty()) {
									throw new ValidationException("policy.egressPortGroup.tagging.usedInAnotherPolicy");
								}
								if (flow1.getVlans() != null && !flow1.getVlans().isEmpty()) {
									throw new ValidationException("policy.egressPortGroup.tagging.usedInCurrentPolicy");
								}
							});
						});
					}
				}

				String vlanId = policy.getFlows().stream().findAny().get().getVlans().stream().findAny().orElse(null);
				if (vlanId != null && vlanId.trim().length() > 0) {
					if (flow.getVlanStripping()) {
						throw new ValidationException("policy.vlan.tagging.stripping.invalid");
					}

					Set<Port> ingressPorts = flow.getIngressPorts();
					Set<Port> egressPorts = flow.getEgressPorts();
					if (ingressPorts.size() == 1 && egressPorts.size() == 1) {
						throw new ValidationException("policy.vlan.tagging.invalid");
					}
				}

				if (flow.getVlanStripping()) {
					Set<Port> ingressPorts = flow.getIngressPorts();
					Set<Port> egressPorts = flow.getEgressPorts();
					if (ingressPorts.size() == 1 && egressPorts.size() == 1) {
						throw new ValidationException("policy.vlan.stripping.invalid");
					}
				}

				flow.getRuleSets().forEach(ruleSet -> {
					ruleSet.getRules().forEach(rule -> {
						int sourcePort = rule.getSourcePort();
						int destinationPort = rule.getDestinationPort();
						String protocol = rule.getProtocol();
						if (PROTOCOL_SCTP == protocol) {
							if (sourcePort > 0) {
								throw new ValidationException("policy.rule.sourcePort.invalid");
							} else if (destinationPort > 0) {
								throw new ValidationException("policy.rule.destinationPort.invalid");
							}
						}
					});
				});
			});
		}
	}
}
