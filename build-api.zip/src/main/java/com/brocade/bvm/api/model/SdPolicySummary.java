package com.brocade.bvm.api.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@NoArgsConstructor
@Getter
public class SdPolicySummary {
    private long id;
    private String name;
    private boolean preserveCplane;
    private String trafficType;
    private int rules;
    private String workflowStatus;
    private String workflowType;
}
