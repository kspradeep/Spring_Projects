package com.brocade.bvm.api.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DeviceFirmwareSummary {

    private Long id;
    private String name;
    private String ipAddress;
    private String softwareVersion;
    private String username;
    private String password;
    private String lastUpdatedTime;
    private Long firmwareJobId;
    private String workflowStatus;
    private boolean rebootRequired;
}
