package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.GridManager;
import com.brocade.bvm.api.manager.GridPolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.utility.GridPolicySetComparator;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.dao.grid.GridPolicySetRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.dao.statistics.cache.GridCache;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.grid.GridTopologyPath;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The DeviceGridController class implements methods to perform CRUD operations related to device grid
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/grid")
public class DeviceGridController {

    public static final String CLEANUP = "cleanup";
    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";
    public static final String ROLLBACK = "rollback";

    @Inject
    private GridManager deviceGridManager;

    @Inject
    private GridPolicyManager deviceGridPolicyManager;

    @Inject
    private GridRepository gridRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridPolicySetRepository gridPolicySetRepository;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private GridPolicySetComparator gridPolicySetComparator;

    @Inject
    private GridCache gridCache;

    /**
     * This method saves the device grid in bvm db
     *
     * @param deviceGrid
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitDeviceGrid(@RequestBody DeviceGrid deviceGrid) throws JsonProcessingException {
        log.debug("Save grid,  name: {}", deviceGrid.getName());

        ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
        if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
            log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
            throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
        }

        deviceGridManager.commitGrid(deviceGrid);
        return new ResponseEntity<>(deviceGrid.getId(), HttpStatus.OK);
    }

    /**
     * This method updates the device grid as DRAFT in bvm db
     *
     * @param gridId
     * @param deviceGrid
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{gridId}", consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitDeviceGrid(@PathVariable(value = "gridId") Long gridId, @RequestBody DeviceGrid deviceGrid) {
        log.debug("Update grid,  name: {}", deviceGrid.getName());
        if (gridId != null && deviceGrid != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            DeviceGrid deviceGridInDb = gridRepository.findOne(gridId);
            if (deviceGrid.getId() != null && deviceGrid.getId().longValue() != gridId.longValue()) {
                throw new ValidationException("Invalid grid Id.");
            }
            if (deviceGridInDb != null) {
                deviceGridManager.commitGrid(deviceGrid);
                return new ResponseEntity<>(gridId, HttpStatus.OK);
            }
        }
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method is used to delete device grid for the given gridId
     *
     * @param gridId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{gridId}")
    public ResponseEntity<Object> deleteDeviceGrid(@PathVariable("gridId") Long gridId) {
        if (gridId != null) {
            DeviceGrid deviceGridInDb = gridRepository.findOne(gridId);
            if (deviceGridInDb != null) {
                ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
                if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                    log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                    throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
                }
                if (WorkflowParticipant.WorkflowStatus.ERROR == deviceGridInDb.getWorkflowStatus()) {
                    log.debug("Recovery of grid,  gridId: {}", gridId);
                    deviceGridManager.rollbackGrid(deviceGridInDb);
                } else {
                    log.debug("Delete grid,  gridId: {}", gridId);
                    deviceGridManager.deleteGrid(deviceGridInDb);
                }

                gridCache.getTopFiveGrids().clear();
                gridCache.getBottomFiveGrids().clear();
                return new ResponseEntity<>(gridId, HttpStatus.OK);
            }
        }
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method is used to abort device grid operation for the given gridId
     *
     * @param gridId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{gridId}/abort")
    public ResponseEntity<Object> abortDeviceGrid(@PathVariable("gridId") Long gridId) {
        log.debug("Aborting grid execution for {}", gridId);
        if (gridId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            DeviceGrid deviceGridInDb = gridRepository.findOne(gridId);
            if (deviceGridInDb != null) {
                if (WorkflowParticipant.WorkflowStatus.SUBMITTED == deviceGridInDb.getWorkflowStatus()) {
                    log.debug("Aborting the grid action,  gridId: {}", gridId);
                    deviceGridInDb.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                    gridRepository.save(deviceGridInDb);
                }
                return new ResponseEntity<>(gridId, HttpStatus.OK);
            }
        }
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method fetches the device grid for the given gridId
     *
     * @param gridId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{gridId}")
    public ResponseEntity<Object> getDeviceGrid(@PathVariable("gridId") Long gridId) {
        log.debug("getDeviceGrid for {}", gridId);
        if (gridId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            DeviceGrid deviceGrid = gridRepository.findOne(gridId);
            deviceGrid.getSourceNodes().forEach(networkNode -> {
                networkNode.getDevice().setModules(Sets.newHashSet());
            });
            deviceGrid.getDestinationNodes().forEach(networkNode -> {
                networkNode.getDevice().setModules(Sets.newHashSet());
            });
            return new ResponseEntity<>(deviceGrid, HttpStatus.OK);
        }
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method fetches all device grids
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Object> getAllDeviceGrids() {
        ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
        if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
            log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
            throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
        }
        Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
        deviceGrids.forEach(deviceGrid -> {
            deviceGrid.getSourceNodes().forEach(networkNode -> {
                networkNode.getDevice().setModules(Sets.newHashSet());
            });
            deviceGrid.getDestinationNodes().forEach(networkNode -> {
                networkNode.getDevice().setModules(Sets.newHashSet());
            });
        });
        return new ResponseEntity<>(deviceGrids, HttpStatus.OK);
    }

    /**
     * This method saves or commits device grid policies
     *
     * @param action
     * @param gridPolicySet
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.POST, value = "/policy", consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitDeviceGridPolicy(@RequestParam(value = "action", required = false) String action,
                                                               @RequestBody GridPolicySet gridPolicySet) throws JsonProcessingException {
        log.debug("New Grid policy, name: {}, action {}", gridPolicySet.getName(), action);
        ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
        if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
            log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
            throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
        }
        if (action == null || action.equalsIgnoreCase(SAVE)) {
            Long policyId = deviceGridPolicyManager.saveGridPolicy(gridPolicySet);
            return new ResponseEntity<>(policyId, HttpStatus.OK);
        } else if (action.equalsIgnoreCase(COMMIT)) {
            Long jobId = deviceGridPolicyManager.commitGridPolicy(gridPolicySet);
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        }
        throw new ValidationException("policy.action.invalid");
    }

    /**
     * This method updates device grid policies
     *
     * @param action
     * @param policySetId
     * @param gridPolicySet
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/policy/{policySetId}", consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitDeviceGridPolicy(@RequestParam(value = "action", required = false) String action,
                                                                 @PathVariable(value = "policySetId") Long policySetId, @RequestBody GridPolicySet gridPolicySet) {
        log.debug("Update Grid policy set, name: {}, action {}", gridPolicySet.getName(), action);
        ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
        if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
            log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
            throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
        }
        if (policySetId == null || (!CLEANUP.equalsIgnoreCase(action) && (gridPolicySet.getId() == null || policySetId.longValue() != gridPolicySet.getId().longValue()))) {
            throw new ValidationException("Invalid policy id!.");
        }
        GridPolicySet gridPolicySetInDb = gridPolicySetRepository.findOne(policySetId);
        if (gridPolicySetInDb == null) {
            throw new ValidationException("Invalid policy id!.");
        }
        if (!CLEANUP.equalsIgnoreCase(action)) {
            if (gridPolicySet.getDeviceGrid() == null) {
                throw new ValidationException("Invalid grid id!.");
            }

        }
        if (action == null || action.equalsIgnoreCase(UPDATE)) {
            if (WorkflowParticipant.WorkflowStatus.DRAFT != gridPolicySetInDb.getWorkflowStatus() && gridPolicySetComparator.compare(gridPolicySetInDb, gridPolicySet) == 0) {
                log.debug("Policy data unchanged, skipping the execution. id {}", gridPolicySet.getId());
                throw new ValidationException("Policy data unchanged.");
            }
            Long policyId = deviceGridPolicyManager.saveGridPolicy(gridPolicySet);
            return new ResponseEntity<>(policyId, HttpStatus.OK);
        } else if (action.equalsIgnoreCase(COMMIT)) {
            if (WorkflowParticipant.WorkflowStatus.DRAFT != gridPolicySetInDb.getWorkflowStatus() && gridPolicySetComparator.compare(gridPolicySetInDb, gridPolicySet) == 0) {
                log.debug("Policy data unchanged, skipping the execution. id {}", gridPolicySet.getId());
                throw new ValidationException("Policy data unchanged.");
            }
            Long jobId = deviceGridPolicyManager.commitGridPolicy(gridPolicySet);
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        } else if (CLEANUP.equalsIgnoreCase(action)) {
            if (WorkflowParticipant.WorkflowStatus.ERROR != gridPolicySetInDb.getWorkflowStatus()) {
                throw new ValidationException("policy.action.invalid");
            }
            deviceGridPolicyManager.rollbackGridPolicy(policySetId);
            return new ResponseEntity<>(policySetId, HttpStatus.OK);
        }
        throw new ValidationException("policy.action.invalid");
    }

    /**
     * This method commits the grid policies which are in draft state.
     *
     * @param action
     * @param policySetId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/policy/{policySetId}/ui", consumes = "application/json")
    public ResponseEntity<Object> commitDeviceGridPolicyUI(@RequestParam(value = "action") String action,
                                                           @PathVariable(value = "policySetId") Long policySetId) {
        log.debug("Update Grid policy ui, id: {}, action {}", policySetId, action);
        ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
        if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
            log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
            throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
        }
        if (policySetId == null) {
            throw new ValidationException("Invalid policy id!.");
        }
        GridPolicySet gridPolicySetInDb = gridPolicySetRepository.findOne(policySetId);
        if (gridPolicySetInDb == null) {
            throw new ValidationException("Invalid policy id!.");
        }
        if (action.equalsIgnoreCase(COMMIT)) {
            if (WorkflowParticipant.WorkflowStatus.DRAFT != gridPolicySetInDb.getWorkflowStatus()) {
                log.debug("Policy data is not in saved state, skipping the execution. id {}", policySetId);
                throw new ValidationException("Policy data not in saved state.");
            }
            Long jobId = -1L;
            try {
                jobId = deviceGridPolicyManager.commitGridPolicy(gridPolicySetInDb);
            } catch (Exception e) {
                log.error("Grid policy commit UI API failed, {}", e.getMessage());
            }
            return new ResponseEntity<>(jobId, HttpStatus.OK);
        }
        throw new ValidationException("policy.action.invalid");
    }

    /**
     * This method deletes device grid policies for a given gridId
     *
     * @param policySetId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/policy/{policySetId}")
    public ResponseEntity<Object> deleteDeviceGridPolicy(@PathVariable("policySetId") Long policySetId) {
        log.debug("Delete Grid policy by id: {}", policySetId);
        if (policySetId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            deviceGridPolicyManager.deleteGridPolicy(policySetId);
            return new ResponseEntity<>(policySetId, HttpStatus.OK);
        }
        log.error("deleteDeviceGridPolicy: Invalid policy id! {}.", policySetId);
        throw new ValidationException("Invalid policy id!.");
    }

    /**
     * This method is used to abort device grid operation for the given gridId
     *
     * @param policySetId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/policy/{policySetId}/abort")
    public ResponseEntity<Object> abortGridPolicySet(@PathVariable("policySetId") Long policySetId) {
        if (policySetId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            GridPolicySet gridPolicySetInDb = gridPolicySetRepository.findOne(policySetId);
            if (gridPolicySetInDb != null) {
                if (WorkflowParticipant.WorkflowStatus.SUBMITTED == gridPolicySetInDb.getWorkflowStatus()) {
                    log.debug("Aborting the grid policy action,  policySetId: {}", policySetId);
                    deviceGridPolicyManager.abortGridPolicy(gridPolicySetInDb);
                }
                return new ResponseEntity<>(policySetId, HttpStatus.OK);
            }
        }
        log.error("abortGridPolicySet: Invalid policy id! {}.", policySetId);
        throw new ValidationException("Invalid policy id!.");
    }

    /**
     * This method fetches the device grid policies for a given gridId
     *
     * @param policySetId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/policy/{policySetId}")
    public ResponseEntity<Object> getDeviceGridPolicy(@PathVariable("policySetId") Long policySetId) {
        log.debug("Get Grid policy by id: {}", policySetId);
        if (policySetId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            GridPolicySet gridPolicySet = gridPolicySetRepository.findOne(policySetId);
            return new ResponseEntity<>(gridPolicySet, HttpStatus.OK);
        }
        log.error("getDeviceGridPolicy: Invalid policy id! {}.", policySetId);
        throw new ValidationException("Invalid policy id!.");
    }


    /**
     * This method fetches all device grid policies
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "{gridId}/policy")
    public ResponseEntity<Object> getAllGridPoliciesByGrid(@PathVariable("gridId") Long gridId) {
        log.debug("Get all Grid policies by grid id: {}", gridId);
        if (gridId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            List<GridPolicySet> gridPolicySets = gridPolicySetRepository.findByGridId(gridId);
            gridPolicySets.forEach(gridPolicySet -> {
                if (WorkflowParticipant.WorkflowStatus.ACTIVE == gridPolicySet.getWorkflowStatus()) {
                    Set<Long> gridTopologyPathIds = gridTopologyPathRepository.findByPolicySetIdAndIsActive(gridPolicySet.getId(), false);
                    if (!gridTopologyPathIds.isEmpty()) {
                        gridPolicySet.setIsManualReloadRequired(true);
                    }
                }
            });
            return new ResponseEntity<>(gridPolicySets, HttpStatus.OK);
        }
        log.error("getAllGridPoliciesByGrid: Invalid grid id! {}.", gridId);
        throw new ValidationException("Invalid grid id!.");
    }

    /**
     * This method saves or commits device grid policies
     *
     * @param pathId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.POST, value = "/pathdown/{pathId}", consumes = "application/json")
    public void notifyPathFailure(@PathVariable("pathId") Long pathId) {
        log.debug("Path failure notification: {}", pathId);
        if (pathId != null) {
            Set<GridTopologyPath> gridTopologyPathsFailedDb = gridTopologyPathRepository.findAllByPathIdAndIsActive(pathId, true);
            if (gridTopologyPathsFailedDb != null) {
                gridTopologyPathsFailedDb.forEach(gridTopologyPath -> {
                    gridTopologyPath.setIsActive(false);
                    gridTopologyPathRepository.save(gridTopologyPath);
                });
                deviceGridPolicyManager.updatePath(pathId);
            } else {
                log.error("Topology auto path switch : path id {} not found in db.", pathId);
            }
        } else {
            log.error("notifyPathFailure: Invalid path id! {}.", pathId);
        }
    }

    /**
     * This method updates the policies for those paths requires manual intervention.
     *
     * @param policySetId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/policy/{policySetId}/update", consumes = "application/json")
    public ResponseEntity<Object> updatePathFailedPolicies(@PathVariable("policySetId") Long policySetId) {
        log.debug("Updating policy manually where paths are down: {}", policySetId);
        if (policySetId != null) {
            ApplicationConstant gridFeatureStatus = featureConstantsRepository.findByName(ApplicationConstant.GRID_FEATURE_STATUS_KEY);
            if (gridFeatureStatus != null && !ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(gridFeatureStatus.getValue())) {
                log.error("Fetching grid information. This may take a few minutes. Please try after sometime.");
                throw new ValidationException("Fetching grid information. This may take a few minutes. Please try after sometime.");
            }
            deviceGridPolicyManager.updateFailedPoliciesManually(policySetId);
            return new ResponseEntity<>(policySetId, HttpStatus.OK);
        } else {
            log.error("updatePathFailedPolicies : Invalid policy id! {}.", policySetId);
            throw new ValidationException("Invalid policy id!.");
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{gridId}/viewtopology", produces = "application/json")
    public ResponseEntity<Object> viewTopology(@PathVariable("gridId") Long gridId) {
        if (gridId != null) {
            Map topology = deviceGridManager.getGridTopology(gridId);
            return new ResponseEntity<>(topology, HttpStatus.OK);
        }
        log.error("viewTopology : Invalid grid id! {}.", gridId);
        throw new ValidationException("Invalid grid id!.");

    }
}
