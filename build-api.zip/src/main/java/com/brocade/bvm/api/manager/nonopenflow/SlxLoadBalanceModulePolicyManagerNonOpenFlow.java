package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The LoadBalanceModulePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover LoadBalanceModulePolicy for NonOpenFlow
 */
@Named("slxLoadBalanceModulePolicyManagerNonOpenFlow")
public class SlxLoadBalanceModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {
    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private JobQueue jobQueue;

    /**
     * This method is used to delete SlxLoadBalanceModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId,
                                   Long modulePolicyId) {

        ModulePolicy modulePolicy = modulePolicyRepository
                .findOne(modulePolicyId);
        // Validate
        // 1. ModulePolicy present in DB
        if (modulePolicy == null) {
            throw new ValidationException("loadBalancePolicy.id.invalid");
        }
        // 2. ModulePolicy not in active state.
        if (modulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            throw new ValidationException("loadBalancePolicy.delete.policyApplied");
        }
        Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_DELETE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to create LoadBalanceModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy) {

        // Validate
        // 1. Check if modulePolicy already present on same device and module.
        SlxLoadBalanceModulePolicy loadBalanceModulePolicy = modulePolicy.getSlxLoadBalanceModulePolicy();
        List<Long> moduleIds = loadBalanceModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("loadBalancePolicy.edit.failed");
        }
        loadBalanceModulePolicy.setModules(Sets.newHashSet(modules));
        loadBalanceModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        loadBalanceModulePolicy = modulePolicyRepository.save(loadBalanceModulePolicy);
        Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_CREATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(loadBalanceModulePolicy.getId()).build());

        return jobId;

    }

    /**
     * This method is used to update LoadBalanceModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicyFromRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    public Long updateModulePolicy(Long deviceId,
                                   Long modulePolicyId, ModulePolicyRequest modulePolicyFromRequest) {

        SlxLoadBalanceModulePolicy modulePolicy = modulePolicyFromRequest.getSlxLoadBalanceModulePolicy();
        SlxLoadBalanceModulePolicy oldModulePolicy = (SlxLoadBalanceModulePolicy) modulePolicyRepository
                .findById(modulePolicyId);

        // If id not found
        if (oldModulePolicy == null) {
            throw new ValidationException("loadBalancePolicy.id.invalid");
        }
        validateRequest(modulePolicy, oldModulePolicy);
        // If Lag is not in committed status or in error state, do not allow
        // modify
        if (oldModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ACTIVE
                || oldModulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("loadBalancePolicy.edit.failed");
        }

        // Merging oldModulePolicy with updated ModulePolicy data
        oldModulePolicy.setSelectedLoadBalancePolicy(modulePolicy.getSelectedLoadBalancePolicy());
        //merge modules
        List<Long> moduleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("loadBalancePolicy.edit.failed");
        }
        oldModulePolicy.setModules(new HashSet<>(modules));
        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(oldModulePolicy);

        Job.Type jobType = Job.Type.LOAD_BALANCE_MODULE_POLICY_UPDATE;
        //TODO: Add only the new updated module ids in impacted list
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());

        return jobId;
    }

    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        throw new ValidationException("loadBalancePolicy.recovery.invalid");
    }

    /**
     * This checks if the LoadBalanceModulePolicy is data is valid
     *
     * @param modulePolicy
     */
    private void validateRequest(SlxLoadBalanceModulePolicy modulePolicy, SlxLoadBalanceModulePolicy oldModulePolicy) {
        if(modulePolicy.getSelectedLoadBalancePolicy().equals(oldModulePolicy.getSelectedLoadBalancePolicy())){
            throw new ValidationException("loadBalancePolicy.data.unChanged");
        }
    }
}
