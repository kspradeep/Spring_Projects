package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.ModulePolicyManager;
import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.db.*;

import java.util.*;

/**
 * The AbstractModulePolicyManager class implements methods to fetch all module policies based on type
 */
public abstract class AbstractModulePolicyManager implements ModulePolicyManager {

    /**
     * This method is used fetch map of module policies based type of module policy
     *
     * @param modulePolicies
     * @return Map<String, Set<? extends ModulePolicy>>
     */
    public Map<String, Set<? extends ModulePolicy>> getModulePolicies(List<? extends ModulePolicy> modulePolicies) {
        Map<String, Set<? extends ModulePolicy>> policyMap = new HashMap<>();
        Set<ModulePolicy> packetSlicingModulePolicies = new HashSet<>();
        Set<ModulePolicy> loadBalanceModulePolicies = new HashSet<>();
        Set<ModulePolicy> headerStrippingModulePolicies = new HashSet<>();
        Set<ModulePolicy> packetStampingModulePolicies = new HashSet<>();
        Set<ModulePolicy> packetLabelingModulePolicies = new HashSet<>();
        Set<ModulePolicy> slxLoadBalanceModulePolicies = new HashSet<>();
        Set<ModulePolicy> gtpDeEncapsulationModulePolicies = new HashSet<>();
        Set<ModulePolicy> ipPayloadLengthPolicies = new HashSet<>();
        if (modulePolicies != null) {
            modulePolicies.stream().forEach(modulePolicy -> {
                if (modulePolicy instanceof PacketSlicingModulePolicy) {
                    packetSlicingModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof PacketStampingModulePolicy) {
                    packetStampingModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof PacketLabelingModulePolicy) {
                    packetLabelingModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof HeaderStrippingModulePolicy) {
                    headerStrippingModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof LoadBalanceModulePolicy) {
                    loadBalanceModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof SlxLoadBalanceModulePolicy) {
                    slxLoadBalanceModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof GtpDeEncapsulationModulePolicy) {
                    gtpDeEncapsulationModulePolicies.add(modulePolicy);
                } else if (modulePolicy instanceof IpPayloadLengthPolicy) {
                    ipPayloadLengthPolicies.add(modulePolicy);
                }
            });
        }
        policyMap.put("packetSlicingModulePolicies", packetSlicingModulePolicies);
        policyMap.put("loadBalanceModulePolicies", loadBalanceModulePolicies);
        policyMap.put("headerStrippingModulePolicies", headerStrippingModulePolicies);
        policyMap.put("packetStampingModulePolicies", packetStampingModulePolicies);
        policyMap.put("packetLabelingModulePolicies", packetLabelingModulePolicies);
        policyMap.put("slxLoadBalanceModulePolicies", slxLoadBalanceModulePolicies);
        policyMap.put("gtpDeEncapsulationModulePolicies", gtpDeEncapsulationModulePolicies);
        policyMap.put("ipPayloadLengthPolicies", ipPayloadLengthPolicies);
        return policyMap;
    }
}
