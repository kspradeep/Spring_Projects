package com.brocade.bvm.api.manager;

import java.util.List;

public interface GlobalManager {

    String refreshDeviceConfiguration();

    List commit(Object request);

    List update(Long id, Object request);

    List delete(Long id);

    String getProfiles();

    String getProfile(Long id);

    Long rollBack(Long id);
}
