package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.grid.ClusterNodeInterfaceRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridCluster;
import com.brocade.bvm.model.db.statistics.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import java.util.*;

@RequestMapping(produces = "application/json", value = "/statistics")
@RestController
@Slf4j
public class StatisticsPortUIController {

  @Inject StatisticsPortRepository statisticsPortRepository;
  @Inject GridRepository gridRepository;
  @Inject PortRepository portRepository;
  @Inject PortGroupRepository portGroupRepository;

  /** Find packet information of individual port. */
  @RequestMapping(method = RequestMethod.GET, value = "/{portId}/{samples}/port-packets")
  public List<PortPackets> portPackets(
      @PathVariable("portId") Long portId, @PathVariable("samples") int samples) {
    log.debug("Start: port packets for port id {}", portId);
    validatePortAndSamples(portId, samples);

    List<PortPackets> result = null;

    List<Long> portIds = statisticsPortRepository.findPortsByTapId(portId);
    if (portIds != null && !portIds.isEmpty()) {
        result = statisticsPortRepository.findGridPackets(portIds, samples);
    }else {
      result = statisticsPortRepository.findPortPacketInformation(portId, samples);
    }

    if(result != null && result.size() > 0) {
      try{
        result.sort(Comparator.comparing(PortPackets::getLastUpdatedTime));
      }catch (Exception e) {
        log.error("Last updated time is null for port: {}", portId);
      }
    }

    log.debug("End: port packets for port id {}", portId);
    return result;
  }

  /** This end point returns packets type of individual port */
  @RequestMapping(method = RequestMethod.GET, value = "/{portId}/{samples}/port-type-packets")
  public List<PortPacketType> portPacketTypes(
      @PathVariable("portId") Long portId, @PathVariable("samples") int samples) {
    log.debug("Start: port type packets for port id {}", portId);

    validatePortAndSamples(portId, samples);

    List<PortPacketType> result = null;

    List<Long> portIds = statisticsPortRepository.findPortsByTapId(portId);
    if (portIds != null && !portIds.isEmpty()) {
        result = statisticsPortRepository.findGridPacketsType(portIds, samples);
    }else {
      result = statisticsPortRepository.portTypePackets(portId, samples);
    }

    if(result != null && result.size() > 0) {
      try{
        result.sort(Comparator.comparing(PortPacketType::getLastUpdatedTime));
      }catch (Exception e) {
        log.error("Last update time is null for port :{}", portId);
      }
    }

    log.debug("End: port type packets for port id {}", portId);
    return result;
  }

  /** This endpoint returns drop packets for individual port */
  @RequestMapping(method = RequestMethod.GET, value = "/{portId}/{samples}/port-drop-packets")
  public List<PortPacketsDrop> portDropPackets(
      @PathVariable("portId") Long portId, @PathVariable("samples") int samples) {
    log.debug("Start: port drop packets for port id {}", portId);
    validatePortAndSamples(portId, samples);

    List<PortPacketsDrop> result = null;

    List<Long> portIds = statisticsPortRepository.findPortsByTapId(portId);
    if (portIds != null && !portIds.isEmpty()) {
        result =  statisticsPortRepository.findGridDropPackets(portIds, samples);
    } else {
      result = statisticsPortRepository.portDropPackets(portId, samples);
    }

    if(result != null && result.size() > 0){
      try{
        result.sort(Comparator.comparing(PortPacketsDrop::getLastUpdatedTime));
      }catch (Exception e) {
        log.error("Last update time is null for port :{}", portId);
      }
    }

    log.debug("End: port drop packets for port id {}", portId);
    return result;
  }

  /** This endpoint returns error packets for individual port. */
  @RequestMapping(method = RequestMethod.GET, value = "/{portId}/{samples}/port-error-packets")
  public List<PortPacketsError> portErrorPackets(
      @PathVariable("portId") Long portId, @PathVariable("samples") int samples) {
    log.debug("Start: port error packets for port id {}", portId);
    validatePortAndSamples(portId, samples);

    List<PortPacketsError> result = null;

    List<Long> portIds = statisticsPortRepository.findPortsByTapId(portId);
    if (portIds != null && !portIds.isEmpty()) {
      result = statisticsPortRepository.findGridErrorPackets(portIds, samples);
    }else{
      result = statisticsPortRepository.portErrorPackets(portId, samples);
    }

    if(result != null && result.size() > 0) {
      try{
        result.sort(Comparator.comparing(PortPacketsError::getLastUpdatedTime));
      }catch (Exception e) {
        log.error("Last update time is null for port :{}", portId);
      }
    }

    log.debug("End: port error packets for port id {}", portId);
    return result;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/{policyId}/{samples}/policy")
  public List<OnePolicyStatistics> policyStatistics(
      @PathVariable("policyId") String policyName, @PathVariable("samples") int samples) {
    log.debug("Start: policy packets for policy name", policyName);
    if (Objects.equals(policyName, "") || samples == 0 || samples < 0) {
      throw new ValidationException("Invalid request params");
    }
    List<OnePolicyStatistics> result =
        statisticsPortRepository.findPolicyStatistics(policyName, samples);
    log.debug("End: policy packets for policy name", policyName);
    return result;
  }

  private void validatePortAndSamples(Long portId, int samples) {
    if (portId == null || samples == 0 || samples < 0) {
      throw new ValidationException("port.ids.invalid");
    }
  }

  @RequestMapping(value = "/{deviceId}/ports")
  public List<Port> devicePorts(@PathVariable("deviceId") Long deviceId) {
    List ports = portRepository.findPortsByDeviceId(deviceId);
    List<PortGroup> portGroups = portGroupRepository.findByDeviceId(deviceId);
    portGroups.forEach(
        portGroup -> {
          PortReplica portReplica = new PortReplica();
          portReplica.setId(portGroup.getId());
          portReplica.setName(portGroup.getName());
          portReplica.setType("Port Channel");
          ports.add(portReplica);
        });
    return ports;
  }

  @RequestMapping(
      value = "/{gridId}/grid-ports",
      method = RequestMethod.GET,
      produces = "application/json")
  public ResponseEntity<Object> gridPorts(@PathVariable("gridId") Long gridId) {
    List ports = new ArrayList<>();
    if (!StringUtils.isEmpty(gridId)) {
      DeviceGrid grid = gridRepository.findOne(gridId);
      if (!StringUtils.isEmpty(grid)) {
        grid.getSourceNodes()
            .forEach(
                networkNode ->
                    networkNode
                        .getClusterNodeInterfaces()
                        .forEach(
                            clusterNodeInterface -> {
                              ports.add(clusterNodeInterface);
                            }));
        grid.getDestinationNodes()
            .forEach(
                networkNode ->
                    networkNode
                        .getClusterNodeInterfaces()
                        .forEach(
                            clusterNodeInterface -> {
                              ports.add(clusterNodeInterface);
                            }));
      }
    }

    return new ResponseEntity<>(ports, HttpStatus.ACCEPTED);
  }

  @RequestMapping(value = "/{portId}/utilization")
  public List<PortBandwidth> portUtilization(@PathVariable("portId") Long portId) {
    log.debug("Start: port utilization for port id {}", portId);
    validatePortAndSamples(portId, 20);

    List<PortBandwidth> result = null;

    List<Long> portIds = statisticsPortRepository.findPortsByTapId(portId);

    if (portIds != null && !portIds.isEmpty()) {
        result =  statisticsPortRepository.findGridPortsUtilization(portIds);
    }else {
      result =  statisticsPortRepository.getPortUtilization(portId);
    }

    if(result != null && result.size() > 0) {
      try {
        result.sort(Comparator.comparing(PortBandwidth::getLastUpdatedTime));
      }catch (Exception e) {
        log.error("Last updated time is null for port :{}", portId);
      }
    }

    log.debug("End: port utilization for port id {}", portId);
    return result;
  }
}
