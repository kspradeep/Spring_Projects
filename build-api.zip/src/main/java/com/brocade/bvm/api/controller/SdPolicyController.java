package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.factory.SDFlowFactory;
import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.SdPolicyRequest;
import com.brocade.bvm.api.model.SdPolicySummary;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.*;

/**
 * The SdPolicyController class implements methods to perform CRUD operations of policies for SD version 3.5 and above
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/sd")
public class SdPolicyController {

    public static final String CLEANUP = "cleanup";
    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String SAVE = "save";

    public static final String SAMPLING = "sampling";
    public static final String DEDUPE = "dedupe";
    public static final String FILTER = "filter";

    public static final String DROP = "drop";
    public static final String FORWARD = "forward";

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private SdPolicyRepository policyRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private FilterPolicyRepository filterPolicyRepository;

    @Inject
    private DedupePolicyRepository dedupePolicyRepository;

    @Inject
    private SamplingPolicyRepository samplingPolicyRepository;

    @Inject
    private ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    ProfileInterfaceMappingRepository profileInterfaceMappingRepository;

    @Inject
    EgressPortGroupRepository egressPortGroupRepository;

    /**
     * This method is used to save device policy(DRAFT) in bvm db or create device policy on device based action param
     *
     * @param action
     * @param sdPolicyRequest
     * @return ResponseEntity<Object>
     * @throws JsonProcessingException
     */
    @RequestMapping(method = RequestMethod.POST, value = "/policy", consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitPolicies(@RequestParam(value = "action", required = false) String action,
                                                       @RequestBody SdPolicyRequest sdPolicyRequest) throws JsonProcessingException {
        log.info("Action on SD Policy to " + action);
        if (sdPolicyRequest == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (sdPolicyRequest.getDevice() == null) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = validateAndReturnDevice(sdPolicyRequest.getDevice().getId());
        isAuthorizedDeviceForOperation(device);
        if (device != null) {
            Long jobPolicyId;
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            jobPolicyId = sdFlowFactory.saveOrCommit(sdPolicyRequest, device, action);
            return new ResponseEntity<>(jobPolicyId, HttpStatus.OK);
        }
        return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
    }


    /**
     * This method is used to update device policy as DRAFT in bvm db or update device policy on device based action param
     *
     * @param action
     * @param sdPolicyRequest
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/policy", consumes = "application/json")
    public ResponseEntity<Object> updateOrCommitPolicies(@RequestParam(value = "action", required = false) String action,
                                                         @RequestBody SdPolicyRequest sdPolicyRequest) {
        log.debug("********** Start: Update SD Policy **********");
        if (sdPolicyRequest == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (sdPolicyRequest.getDevice() == null) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = validateAndReturnDevice(sdPolicyRequest.getDevice().getId());
        isAuthorizedDeviceForOperation(device);
        Long jobId = 0l;
        if (action == null || UPDATE.equalsIgnoreCase(action) || COMMIT.equalsIgnoreCase(action)) {
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            jobId = sdFlowFactory.saveOrCommit(sdPolicyRequest, device, action);
        } else if (action.equalsIgnoreCase(CLEANUP)) {

        } else {
            throw new ValidationException("policy.action.invalid");
        }
        return new ResponseEntity<>(jobId, HttpStatus.OK);
    }

    /**
     * This method is used to delete SD policy for the given policyId
     *
     * @param action
     * @param ids
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/policy/delete")
    public ResponseEntity<Object> deletePolicy(@RequestParam(value = "action", required = false) String action, @RequestBody List<Long> ids) {
        log.debug("********** Start: Delete SD Policy **********");
        if (ids != null && !ids.isEmpty()) {
            List<SdPolicy> policies = (List<SdPolicy>) policyRepository.findAll(ids);
            if (!policies.isEmpty()) {
                long deviceId = policies.get(0).getDevice().getId();
                Device device = validateAndReturnDevice(deviceId);
                isAuthorizedDeviceForOperation(device);
                SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
                Long jobId = sdFlowFactory.deletePolicy(policies, action);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to update policy as DRAFT in bvm db or update device policy on device based action param
     *
     * @param policyId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/policy/{policyId}")
    public ResponseEntity<Object> getPolicy(@PathVariable("policyId") Long policyId) {
        log.debug("********** Start: Update SD Device Policy **********");
        if (policyId != null) {
            SdPolicy policy = policyRepository.findOne(policyId);
            Device device = validateAndReturnDevice(policy.getDevice().getId());
            isAuthorizedDeviceForOperation(device);
            if (policy instanceof FilterPolicy) {
                SortedSet<FilterRule> filterRules = ((FilterPolicy) policy).getRules();
                for (FilterRule filterRule : filterRules) {
                    if (filterRule.getPortGroup() == null) {
                        filterRule.setAction(DROP);
                    } else {
                        filterRule.getPortGroup().setEgressPorts(Sets.newHashSet());
                        filterRule.setAction(FORWARD);
                    }
                }
                ((FilterPolicy) policy).setRules(filterRules);
            }
            return new ResponseEntity<>(policy, HttpStatus.OK);
        }
        throw new ValidationException("policy.id.invalid");
    }

    /**
     * This method is used to get all policies from bvm db based on device ID
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{deviceid}/policy")
    public ResponseEntity<Object> getPolicies(@RequestParam(value = "type", required = false) String type, @PathVariable("deviceid") Long deviceId) {
        log.debug("********** Start: get Policies **********");
        Device device = validateAndReturnDevice(deviceId);
        isAuthorizedDeviceForOperation(device);
        if (FILTER.equalsIgnoreCase(type)) {
            List<FilterPolicy> filterPolicies = filterPolicyRepository.findAllByDeviceId(deviceId);
            return new ResponseEntity<>(getSdFilterPolicySummary(filterPolicies), HttpStatus.OK);
        } else if (DEDUPE.equalsIgnoreCase(type)) {
            List<DeDupePolicy> deDupePolicies = dedupePolicyRepository.findAllByDeviceId(deviceId);
            List<DeDupePolicy> tempDedupePolicies = new ArrayList<>();
            for (DeDupePolicy deDupePolicy : deDupePolicies) {
                deDupePolicy.setDevice(null);
                tempDedupePolicies.add(deDupePolicy);
            }
            return new ResponseEntity<>(tempDedupePolicies, HttpStatus.OK);
        } else if (SAMPLING.equalsIgnoreCase(type)) {
            List<SamplingPolicy> samplingPolicies = samplingPolicyRepository.findAllByDeviceId(deviceId);
            List<SamplingPolicy> tempSamplingPolicies = new ArrayList<>();
            for (SamplingPolicy samplingPolicy : samplingPolicies) {
                samplingPolicy.setDevice(null);
                tempSamplingPolicies.add(samplingPolicy);
            }
            return new ResponseEntity<>(tempSamplingPolicies, HttpStatus.OK);
        }
        return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
    }

    /**
     * This method is used to save device policy(DRAFT) in bvm db or create device policy on device based action param
     *
     * @param action
     * @param activeInterface
     * @return ResponseEntity<Object>
     * @throws JsonProcessingException
     */
    @RequestMapping(method = RequestMethod.POST, value = "/interface", consumes = "application/json")
    public ResponseEntity<Object> saveOrCommitInterface(@RequestParam(value = "action", required = false) String action,
                                                        @RequestBody ActiveInterface activeInterface) throws JsonProcessingException {
        log.info("Action on SD Policy to " + action);
        if (activeInterface == null) {
            throw new ValidationException("policy.data.invalid");
        }
        ProfileInterfaceMapping profileInterfaceMapping = profileInterfaceMappingRepository.findOne(activeInterface.getProfileInterfaceMapping().getId());
        long deviceId = profileInterfaceMapping.getProfile().getDevice().getId();
        Device device = validateAndReturnDevice(deviceId);
        isAuthorizedDeviceForOperation(device);
        activeInterface.setProfileInterfaceMapping(profileInterfaceMapping);
        if (device != null) {
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            Long jobId = sdFlowFactory.saveOrCommitInterface(activeInterface, device, action);
            return new ResponseEntity<>(jobId, HttpStatus.OK);

        }
        throw new ValidationException("device.get.notfound");
    }

    /**
     * This method is used to get Active interface based on requested ID
     *
     * @param interfaceId
     * @return ResponseEntity<Object>
     * @throws JsonProcessingException
     */
    @RequestMapping(method = RequestMethod.GET, value = "/interface/{interfaceId}")
    public ResponseEntity<Object> getInterface(@PathVariable("interfaceId") Long interfaceId) throws JsonProcessingException {
        log.debug("********** Start: get SD interface **********");
        if (interfaceId != null) {
            ActiveInterface activeInterface = activeInterfaceRepository.findOne(interfaceId);
            if (activeInterface != null)
                return new ResponseEntity<>(getActiveInterfaceSummary(Lists.newArrayList(activeInterface)).get(0), HttpStatus.OK);
        }
        throw new ValidationException("interface.not.found");
    }

    /**
     * This method is used to get all Interfaces mapped with Policy
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{deviceid}/interfaces")
    public ResponseEntity<Object> getMappedInterfacesWithPolicy(@RequestParam(value = "type", required = false) String type, @PathVariable("deviceid") Long deviceId) {
        log.debug("********** Start: get all SD interfaces **********");
        Device device = validateAndReturnDevice(deviceId);
        isAuthorizedDeviceForOperation(device);
        List<ActiveInterface> activeInterfaces = (List<ActiveInterface>) activeInterfaceRepository.findAllActiveInterfaceByDeviceId(deviceId);
        if (!activeInterfaces.isEmpty())
            return new ResponseEntity<>(getActiveInterfaceSummary(activeInterfaces), HttpStatus.OK);
        else
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
    }

    /**
     * This method is used to delete SD Interface for the given interface
     *
     * @param interfaceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/interface/delete")
    public ResponseEntity<Object> deleteInterface(@RequestBody List<Long> interfaceId) {
        log.debug("********** Start: Delete SD Interface**********");
        if (interfaceId != null && !interfaceId.isEmpty()) {
            List<ActiveInterface> activeInterfaces = (List<ActiveInterface>) activeInterfaceRepository.findAll(interfaceId);
            if (!activeInterfaces.isEmpty()) {
                long deviceId = activeInterfaces.get(0).getProfileInterfaceMapping().getProfile().getDevice().getId();
                Device device = validateAndReturnDevice(deviceId);
                isAuthorizedDeviceForOperation(device);
                SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
                Long jobId = sdFlowFactory.deleteInterface(activeInterfaces, device);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("interface.not.found");

    }

    /**
     * This method is to return all sampling policy and port-group configured on requested device
     *
     * @param deviceId
     * @return Map having all Portgroups and All sampling policy
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{deviceId}/portGroupSampling")
    public ResponseEntity<Object> getPortGroupAndSamplePolicy(@PathVariable("deviceId") Long deviceId) {
        Device device = validateAndReturnDevice(deviceId);
        isAuthorizedDeviceForOperation(device);
        Map<String, Object> pgSamplingMap = new HashMap<>();
        List<SdPortGroup> egressPortGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        List<SamplingPolicy> samplingPolicies = samplingPolicyRepository.findByDeviceAndInWorkflowStatus(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        List list = new ArrayList();
        Map<String, Object> map;
        for (SdPortGroup portGroup : egressPortGroups) {
            map = new HashMap<>();
            map.put("id", portGroup.getId());
            map.put("name", portGroup.getName());
            list.add(map);
        }
        pgSamplingMap.put("portGroups", list);
        list = new ArrayList();
        for (SamplingPolicy samplingPolicy : samplingPolicies) {
            map = new HashMap<>();
            map.put("id", samplingPolicy.getId());
            map.put("name", samplingPolicy.getName());
            list.add(map);
        }
        pgSamplingMap.put("samplingPolicies", list);
        return new ResponseEntity<>(pgSamplingMap, HttpStatus.OK);
    }

    /**
     * This method is used to cut unnecessary information and provide actual data to display on UI
     *
     * @param filterPolicies
     * @return
     */
    private List<SdPolicySummary> getSdFilterPolicySummary(List<FilterPolicy> filterPolicies) {
        List<SdPolicySummary> tempFilterPolicies = new ArrayList<>();
        SdPolicySummary sdPolicySummary;
        for (FilterPolicy filterPolicy : filterPolicies) {
            sdPolicySummary = new SdPolicySummary();
            sdPolicySummary.setId(filterPolicy.getId());
            sdPolicySummary.setTrafficType(filterPolicy.getTrafficType());
            sdPolicySummary.setPreserveCplane(filterPolicy.isPreserveCplane());
            sdPolicySummary.setName(filterPolicy.getName());
            sdPolicySummary.setWorkflowStatus(filterPolicy.getWorkflowStatus() != null ? filterPolicy.getWorkflowStatus().name() : null);
            sdPolicySummary.setWorkflowType(filterPolicy.getWorkflowType() != null ? filterPolicy.getWorkflowType().name() : null);
            sdPolicySummary.setRules(filterPolicy.getRules().size());
            tempFilterPolicies.add(sdPolicySummary);
        }
        return tempFilterPolicies;
    }

    /**
     * This method is used to cut unnecessary information and provide actual data to display on UI
     *
     * @param activeInterfaces
     * @return
     */
    private List<ActiveInterface> getActiveInterfaceSummary(List<ActiveInterface> activeInterfaces) {

        activeInterfaces.forEach(intrfc -> {
            if (intrfc.getPortGroup() != null) {
                intrfc.getPortGroup().setEgressPorts(new HashSet<>());
            }
            if (intrfc.getReplicatePortGroup() != null) {
                intrfc.getReplicatePortGroup().setEgressPorts(new HashSet<>());
            }
            if (intrfc.getDeDupePolicy() != null) {
                intrfc.getDeDupePolicy().setDevice(null);
            }
            if (intrfc.getSamplingPolicy() != null) {
                intrfc.getSamplingPolicy().setDevice(null);
            }
            if (intrfc.getFilterPolicy() != null) {
                intrfc.getFilterPolicy().setDevice(null);
                intrfc.getFilterPolicy().setRules(new TreeSet<>());
            }
        });
        return activeInterfaces;
    }

    /**
     * This method is used to validate whether requested operation having valid device ID or not
     *
     * @param device
     */
    private void isAuthorizedDeviceForOperation(Device device) {
        if (!authorityProvider.getAuthorizedDeviceIds().contains(device.getId()) || !Device.Type.SD.equals(device.getType())) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        return device;
    }
}
