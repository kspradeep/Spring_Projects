package com.brocade.bvm.api.manager;

import com.brocade.bvm.api.model.DeviceAdditionResponse;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceDiscoveryJob;

import java.util.List;
import java.util.Set;

public interface SettingManager {

    Set<Long> deleteDevice(List<Device> devices);

    List<DeviceAdditionResponse> addDevice(DeviceDiscoveryJob deviceDiscoveryJob);

    void deleteDiscoveryJob(List<Long> ids);

    void startJob(DeviceDiscoveryJob deviceDiscoveryJob);
}
