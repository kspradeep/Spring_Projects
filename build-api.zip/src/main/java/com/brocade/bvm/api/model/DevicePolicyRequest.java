package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collections;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class DevicePolicyRequest {

    private String name;

    private Device device;

    private MPLSDevicePolicy mplsDevicePolicy;

    private GTPDevicePolicy gtpDevicePolicy;

    private TunnelDevicePolicy tunnelDevicePolicy;

    private SlxPtpPolicy slxPtpPolicy;

    private ReservedVlanDevicePolicy reservedVlanDevicePolicy;
}
