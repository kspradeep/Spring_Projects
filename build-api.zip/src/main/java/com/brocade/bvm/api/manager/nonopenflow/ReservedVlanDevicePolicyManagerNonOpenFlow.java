package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractDevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.ReservedVlanDevicePolicy;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The ReservedVlanDevicePolicyManagerNonOpenFlow class implements methods to create/update/delete Reserved VLAN for NonOpenFlow device
 */
@Named
public class ReservedVlanDevicePolicyManagerNonOpenFlow extends AbstractDevicePolicyManager {

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private ReservedVlanDevicePolicyRepository reservedVlanDevicePolicyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    @Inject
    private FlowRepository flowRepository;

    /**
     * This method checks if ReservedVlanDevicePolicy data is valid to commit on the given device
     *
     * @param policy
     * @return boolean
     */
    @Override
    protected boolean isValidPolicy(DevicePolicy policy) {
        if (policy != null) {
            ReservedVlanDevicePolicy reservedVlanDevicePolicy = (ReservedVlanDevicePolicy) policy;
            if (reservedVlanDevicePolicy.getDevice().getId() == null) {
                return false;
            }
            if (reservedVlanDevicePolicy.getReservedVlan() == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * This method is used to create ReservedVlanDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns devicePolicyId
     * @throws ValidationException
     */
    @Override
    protected Long commitPolicy(DevicePolicy policy) {
        ReservedVlanDevicePolicy reservedVlanDevicePolicy = (ReservedVlanDevicePolicy) policy;
        isValidPolicyToCommit(reservedVlanDevicePolicy);
        reservedVlanDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        reservedVlanDevicePolicy = devicePolicyRepository.save(reservedVlanDevicePolicy);
        return reservedVlanDevicePolicy.getId();
    }

    /**
     * This method checks if ReservedVlanDevicePolicy data is valid to commit on the given device
     *
     * @param reservedVlanDevicePolicy
     * @throws ValidationException
     */
    private void isValidPolicyToCommit(ReservedVlanDevicePolicy reservedVlanDevicePolicy) {
        Integer reservedVlan = reservedVlanDevicePolicy.getReservedVlan();
        Long deviceId = reservedVlanDevicePolicy.getDevice().getId();
        Long devicePolicyId = reservedVlanDevicePolicy.getId();

        //#1 Validating if the ReservedVlanDevicePolicy is already present for the selected device
        ReservedVlanDevicePolicy devicePolicy = reservedVlanDevicePolicyRepository.findByDeviceIdAndNotInPolicy(deviceId, devicePolicyId != null ? devicePolicyId : 0L);
        if (devicePolicy != null) {
            throw new ValidationException("reservedVlanDevicePolicy.policy.exists");
        }

        //#2 Validating if the given reserved VLAN is with in the allowed range
        if (reservedVlan < 1 || reservedVlan > 4090) {
            throw new ValidationException("reserved.vlan.notvalid");
        }

        //#3 Validating if the selected reserved VLAN is already used in any other flow
        List<Long> flowIds = reservedVlanDevicePolicyRepository.findFlowIdsByVlanId(reservedVlan);
        if (!flowIds.isEmpty()) {
            throw new ValidationException("reservedVlanDevicePolicy.vlan.exists");
        }
    }

    private void isValidPolicyToUpdateOrDelete(Long deviceId, Integer reservedVlan) {
        //#4 Validating if the preserve Header is enabled in any of the policy on the device
        List<Long> policiesWithPreserveHeader = policyRepository.findPoliciesByDeviceIdAndPreserveHeader(deviceId, true);
        if (!policiesWithPreserveHeader.isEmpty()) {
            throw new ValidationException("reservedVlanDevicePolicy.used.inPolicy");
        }

        //#5 Validating if the selected reserved VLAN is already used in any other flow from ACTIVE policies (SAVED over COMMIT)
        List<Policy> activePolicies = getActivePoliciesFromHistoryForDraftPolicies(deviceId, 0L);
        if (!activePolicies.isEmpty()) {
            validateIfReservedVlanUsedInActivePolicies(activePolicies, reservedVlan);
        }
    }

    /**
     * This method fetches ACTIVE policies from history for DRAFT policies
     *
     * @param deviceId
     * @return List<Policy> returns list of ACTIVE policies
     */
    private List<Policy> getActivePoliciesFromHistoryForDraftPolicies(Long deviceId, Long policyId) {
        List<Policy> activePolicies = Lists.newArrayList();
        //
        if (policyId == null) {
            policyId = 0L;
        }

		/* Finding the draft policies for the given device*/
        List<Long> draftPolicyIds = policyRepository.findDraftPoliciesByDeviceId(deviceId, policyId);
        if (!draftPolicyIds.isEmpty()) {
            draftPolicyIds.forEach(draftPolicyId -> {
                /* Finding the ACTIVE policies for the draft policies from history for the given device*/
                PolicyHistory activePolicyFromHistroy = policyHistoryRepository.findCurrentActivePolicy(deviceId, draftPolicyId);
                if (activePolicyFromHistroy != null) {
                    Policy activePolicy = activePolicyFromHistroy.buildParent();
                    activePolicies.add(activePolicy);
                }
            });
        }
        return activePolicies;
    }

    /**
     * This method validates if the reserved VLAN is used in ACTIVE policies
     *
     * @param activePolicies
     * @param reservedVlan
     * @throws ValidationException
     */
    private void validateIfReservedVlanUsedInActivePolicies(List<Policy> activePolicies, Integer reservedVlan) {
        activePolicies.forEach(activePolicy -> {
            final Set<String> activeVlans = Sets.newHashSet();
            activePolicy.getFlows().forEach(flow -> {
                // Checking if PreserveHeader is enabled on any policy (If preserve header is enabled, reserved VLAN will be used to build command in route-map on device)
                if (activePolicy.isPreserveHeader()) {
                    throw new ValidationException("reservedVlanDevicePolicy.used.inPolicy");
                } else {
                    activeVlans.addAll(flow.getVlans().stream().collect(Collectors.toSet()));
                }
            });

            // Finding if the reserved VLAN is used in ACTIVE policies, which are currently in DRAFT state
            if (activeVlans.contains(String.valueOf(reservedVlan))) {
                throw new ValidationException("reservedVlanDevicePolicy.used.inPolicy");
            }
        });
    }

    /**
     * This method is used to update ReservedVlanDevicePolicy, on the given device
     *
     * @param policy
     * @return Long This returns devicePolicyId
     * @throws ValidationException
     */
    @Override
    protected Long updatePolicy(DevicePolicy policy) {
        ReservedVlanDevicePolicy reservedVlanDevicePolicy = (ReservedVlanDevicePolicy) policy;
        Long devicePolicyId;
        if (reservedVlanDevicePolicy.getId() == null) {
            devicePolicyId = commitPolicy(reservedVlanDevicePolicy);
        } else {
            ReservedVlanDevicePolicy oldReservedVlanDevicePolicy = (ReservedVlanDevicePolicy) devicePolicyRepository.findOne(reservedVlanDevicePolicy.getId());
            if (oldReservedVlanDevicePolicy == null) {
                throw new ValidationException("reservedVlanDevicePolicy.id.invalid");
            }
            if (isPolicyUnChanged(oldReservedVlanDevicePolicy, reservedVlanDevicePolicy)) {
                throw new ValidationException("reservedVlanDevicePolicy.data.unChanged");
            }
            isValidPolicyToCommit(reservedVlanDevicePolicy);
            // Validating if Preserve Header is enabled in any policy on the device
            isValidPolicyToUpdateOrDelete(reservedVlanDevicePolicy.getDevice().getId(), reservedVlanDevicePolicy.getReservedVlan());
            // Merging updated data
            oldReservedVlanDevicePolicy.setReservedVlan(reservedVlanDevicePolicy.getReservedVlan());
            oldReservedVlanDevicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
            oldReservedVlanDevicePolicy = devicePolicyRepository.save(oldReservedVlanDevicePolicy);
            devicePolicyId = oldReservedVlanDevicePolicy.getId();
        }
        return devicePolicyId;
    }

    /**
     * This method checks if ReservedVlanDevicePolicy data is updated
     *
     * @param oldDevicePolicy
     * @param newDevicePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(ReservedVlanDevicePolicy oldDevicePolicy, ReservedVlanDevicePolicy newDevicePolicy) {
        if (oldDevicePolicy.getReservedVlan() != newDevicePolicy.getReservedVlan()) {
            return false;
        }
        return true;
    }

    /**
     * This method is used to delete ReservedVlanDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(Long policyId) {
        ReservedVlanDevicePolicy devicePolicy = (ReservedVlanDevicePolicy) devicePolicyRepository.findOne(policyId);
        // Validate
        // 1. DevicePolicy present in DB
        if (devicePolicy == null) {
            throw new ValidationException("reservedVlanDevicePolicy.id.invalid");
        }
        isValidPolicyToUpdateOrDelete(devicePolicy.getDevice().getId(), devicePolicy.getReservedVlan());

        devicePolicyRepository.delete(devicePolicy);
        return -1L;
    }

    /**
     * This method is used to recover ReservedVlanDevicePolicy, on the given device
     *
     * @param policyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        return deletePolicy(policyId);
    }
}
