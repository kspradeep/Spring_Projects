package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.IpPayloadLengthPolicyRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.IpPayloadLengthPolicy;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.ModulePolicy;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Manager class for IP Payload Length policy
 */
@Slf4j
@Named
public class IpPayloadLengthPolicyManager extends AbstractModulePolicyManager {

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private IpPayloadLengthPolicyRepository payloadLengthPolicyRepository;

    /**
     * This method is used to create PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicyRequest) {
        IpPayloadLengthPolicy payloadLengthPolicy = modulePolicyRequest.getIpPayloadLengthPolicy();
        isValidPolicy(payloadLengthPolicy, deviceId);
        List<Long> moduleIds = payloadLengthPolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        Device device = deviceRepository.findOne(payloadLengthPolicy.getDevice().getId());
        if (device != null && device.getType() != Device.Type.MLXE) {
            throw new ValidationException("policy.action.invalid");
        }

        // 1. Check if modulePolicy already present on same device and module.
        List<Long> ipPayloadLengthPolicyIds = payloadLengthPolicyRepository.findIpPayloadLengthPolicyByModuleIds(moduleIds, payloadLengthPolicy.getIpType().name());
        if (!ipPayloadLengthPolicyIds.isEmpty()) {
            log.error("Already a IpPayloadLength Policy applied for the selected Module(s).");
            throw new ValidationException("payloadlengthpolicy.edit.exists");
        }

        isValidPolicyToCommit(payloadLengthPolicy, moduleIds, modules);
        payloadLengthPolicy.setModules(Sets.newHashSet(modules));
        payloadLengthPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        payloadLengthPolicy = modulePolicyRepository.save(payloadLengthPolicy);
        Job.Type jobType = Job.Type.IP_PAYLOAD_LENGTH_POLICY_CREATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(device.getId()).impactedObjectIds(moduleIds)
                .parentObjectId(payloadLengthPolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to delete IpPayloadLengthPolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        IpPayloadLengthPolicy payloadLengthPolicy = (IpPayloadLengthPolicy) modulePolicyRepository.findOne(modulePolicyId);
        // Validate
        // 1. IpPayloadLengthPolicy present in DB
        if (payloadLengthPolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(payloadLengthPolicy, deviceId);
        // 2. IpPayloadLengthPolicy not in active state.
        if (WorkflowParticipant.WorkflowStatus.SUBMITTED == payloadLengthPolicy.getWorkflowStatus()) {
            throw new ValidationException("ip.payload.length.delete.policy.in.progress");
        }
        Job.Type jobType = Job.Type.IP_PAYLOAD_LENGTH_POLICY_DELETE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(payloadLengthPolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to update PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicyFromRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicyFromRequest) {

        IpPayloadLengthPolicy modulePolicy = modulePolicyFromRequest.getIpPayloadLengthPolicy();
        isValidPolicy(modulePolicy, deviceId);
        IpPayloadLengthPolicy oldModulePolicy = (IpPayloadLengthPolicy) modulePolicyRepository
                .findById(modulePolicyId);

        Device device = deviceRepository.findOne(modulePolicy.getDevice().getId());
        if (device != null && device.getType() != Device.Type.MLXE) {
            throw new ValidationException("policy.action.invalid");
        }

        // If no PacketLabelingModulePolicy is available with id
        if (oldModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        // If PacketLabelingModulePolicy is not in committed status or in error state, do not allow
        // modify
        if (WorkflowParticipant.WorkflowStatus.ACTIVE != oldModulePolicy.getWorkflowStatus()
                || WorkflowParticipant.WorkflowStatus.ERROR == oldModulePolicy.getWorkflowStatus()) {
            throw new ValidationException("ip.payload.length.edit.failed");
        }
        List<Long> moduleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        isValidPolicyToCommit(modulePolicy, moduleIds, modules);
        isPolicyUnChanged(oldModulePolicy, modulePolicy);

        // merging data
        oldModulePolicy.setProcessor(modulePolicy.getProcessor());
        oldModulePolicy.setModules(Sets.newHashSet(modules));
        oldModulePolicy.setIpType(modulePolicy.getIpType());
        oldModulePolicy.setMinRange(modulePolicy.getMinRange());
        oldModulePolicy.setMaxRange(modulePolicy.getMaxRange());
        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(oldModulePolicy);

        Job.Type jobType = Job.Type.IP_PAYLOAD_LENGTH_POLICY_UPDATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        IpPayloadLengthPolicy payloadLengthPolicy = (IpPayloadLengthPolicy) modulePolicyRepository.findOne(modulePolicyId);
        if (payloadLengthPolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(payloadLengthPolicy, deviceId);
        if (WorkflowParticipant.WorkflowStatus.ERROR != payloadLengthPolicy.getWorkflowStatus()) {
            throw new ValidationException("policy.recovery.not.in.error");
        }
        List<Long> moduleIds = payloadLengthPolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        payloadLengthPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(payloadLengthPolicy);

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.IP_PAYLOAD_LENGTH_POLICY_ROLLBACK)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * Validating the IP Payload Length policy
     *
     * @param policy
     * @param deviceId
     * @return
     */
    protected boolean isValidPolicy(IpPayloadLengthPolicy policy, Long deviceId) {
        if (policy != null) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("ip.payload.length.not.supported.device");
            }
            if (policy.getModules() == null || policy.getModules().isEmpty()) {
                throw new ValidationException("empty.module.not.allowed");
            }
            if (policy.getProcessor() == null) {
                throw new ValidationException("empty.processor.not.allowed");
            }
            if (policy.getIpType() == null) {
                throw new ValidationException("ip.payload.length.protocol.empty");
            }
            if (policy.getMinRange() == null || policy.getMaxRange() == null) {
                throw new ValidationException("ip.payload.length.payload.range.empty");
            }
        }
        return true;
    }

    /**
     * This method checks if PacketLabelingModulePolicy data is valid to commit on the given device
     *
     * @param payloadLengthPolicy
     * @param moduleIds
     * @param modules
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(IpPayloadLengthPolicy payloadLengthPolicy, List<Long> moduleIds, List<Module> modules) {

        // #1 Check if the modules selected are valid modules
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("invalid.module.selected");
        }
        // #2 Check if the process number is valid
        IpPayloadLengthPolicy.ProcessorNumber processorNumber = payloadLengthPolicy.getProcessor();
        List<IpPayloadLengthPolicy.ProcessorNumber> processorNumberList = Arrays.asList(IpPayloadLengthPolicy.ProcessorNumber.ONE, IpPayloadLengthPolicy.ProcessorNumber.TWO, IpPayloadLengthPolicy.ProcessorNumber.ALL);
        if (!processorNumberList.contains(processorNumber)) {
            log.error("Invalid Process Number. Device {}", payloadLengthPolicy.getDevice().getId());
            throw new ValidationException("processNumber.invalid");
        }
        if ((payloadLengthPolicy.getMinRange() < IpPayloadLengthPolicy.PAYLOAD_LENGTH_MIN || payloadLengthPolicy.getMaxRange() > IpPayloadLengthPolicy.PAYLOAD_LENGTH_MAX)
                || (payloadLengthPolicy.getMinRange() > payloadLengthPolicy.getMaxRange())) {
            log.error("Invalid IP payload length range. Device {}", payloadLengthPolicy.getDevice().getId());
            throw new ValidationException("ip.payload.length.payload.range.invalid");
        }
        return true;
    }

    /**
     * This method checks if IpPayloadLengthPolicy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(IpPayloadLengthPolicy oldModulePolicy, IpPayloadLengthPolicy newModulePolicy) {
        if ((oldModulePolicy.getProcessor() != null ? !oldModulePolicy.getProcessor().equals(newModulePolicy.getProcessor()) : newModulePolicy.getProcessor() != null) && !oldModulePolicy.getIpType().name().equals(newModulePolicy.getIpType().name()) && !oldModulePolicy.getMinRange().equals(newModulePolicy.getMinRange()) && !oldModulePolicy.getMaxRange().equals(newModulePolicy.getMaxRange()))
            return false;
        Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        Set<Long> newModuleIds = newModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        if (!oldModuleIds.containsAll(newModuleIds)) {
            return false;
        }
        return true;
    }
}
