package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.outbound.stablenet.StablenetAdminConnection;
import com.brocade.bvm.outbound.stablenet.model.UserVO;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXB;
import java.io.StringReader;

/**
 * The UserManagementController class implements methods to perform operations related to user and role management
 */
@Slf4j
@RequestMapping(value = "/users")
@RestController
public class UserManagementController {

    @Value("${stablenet.resource-url.users.remove}")
    private String userRemoveUrl;

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String getUserUrl;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private StablenetAdminConnection stablenetConnection;

    @RequestMapping(method = RequestMethod.DELETE, value = "/remove/{username}")
    public ResponseEntity<Object> deleteUser(@PathVariable(value = "username") String username) {
        log.debug("Deleting user {} from StableNet.", username);
        if (!Strings.isNullOrEmpty(username)) {
            String adminUser = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue();
            if (username.equals(adminUser)) {
                throw new ValidationException(adminUser + " is an administrator user and cannot be deleted.");
            }
            UserVO user = null;
            try {
                user = JAXB.unmarshal(
                        new StringReader(stablenetConnection.get(getUserUrl, username).readEntity(String.class)),
                        UserVO.class);
            } catch (Exception e) {
                log.error("Failed to get the user information from StableNet. {}", e.getMessage());
            }

            if (user != null && user.getObid() != null) {
                Response response = stablenetConnection.delete(userRemoveUrl, "/" + user.getObid());
                if (response == null || response.getStatus() != HttpStatus.OK.value()) {
                    throw new ValidationException("User does not exist.");
                }
                return new ResponseEntity<>(HttpStatus.OK);
            }
        }
        throw new ValidationException("User does not exist.");
    }
}
