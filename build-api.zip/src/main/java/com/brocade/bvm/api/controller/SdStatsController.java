package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.factory.SDFlowFactory;
import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.model.db.Device;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/sd/{deviceId}/stats")
public class SdStatsController {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    /**
     * This method is used to get all kind of Stats data based on their name
     *
     * @param name
     * @param deviceId
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Object> getSdStats(@RequestParam(value = "name", required = true) String name, @PathVariable("deviceId") Long deviceId) {
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId) || (device != null && !Device.Type.SD.equals(device.getType()))) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (device != null) {
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            return new ResponseEntity<>(sdFlowFactory.getStats(name, device), HttpStatus.OK);

        }
        throw new ValidationException("device.get.notfound");

    }

    /**
     * This method is used to start/stop stats timer task
     *
     * @param action
     * @param deviceId
     * @return
     */
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Object> startStopStatsTimerTask(@RequestParam(value = "action", required = true) String action, @PathVariable("deviceId") Long deviceId) {
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId) || !Device.Type.SD.equals(device.getType())) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if(action == null) {
            throw new ValidationException("policy.action.invalid");
        }
        if (device != null) {
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            return new ResponseEntity<>(sdFlowFactory.startStopStatsTimeTask(action, device), HttpStatus.OK);

        }
        throw new ValidationException("device.get.notfound");

    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        return device;
    }
}
