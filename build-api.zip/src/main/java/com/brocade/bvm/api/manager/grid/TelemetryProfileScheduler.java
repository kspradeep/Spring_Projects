package com.brocade.bvm.api.manager.grid;

import com.brocade.bvm.api.manager.generic.GenericJobManager;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.collector.CollectorScheduler;
import com.brocade.bvm.dao.ConfigRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.FeatureConstantsRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.dao.statistics.StatisticsTruncateTables;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Event;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.rest.RestHelperWithoutProxy;
import com.brocade.bvm.outbound.stablenet.StablenetInitializerManager;
import com.brocade.bvm.outbound.stablenet.service.InitialDeviceConfiguration;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * This class checks and configure the telemetry profiles (LLDP and System) at scheduled interval
 */
@Named
@Slf4j
public class TelemetryProfileScheduler {

    @Value("${stablenet.resource-url.users.getuserbyname}")
    private String resourceUrl;

    @Value("${telemetry.collector.ip.address}")
    private String telemetryCollectorIpAddress;

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    @Value("${slx.tacacs.authorization.supported.os.version:18.1.03}")
    private String slxTacacsAuthorizationSupportedVersion;

    @Value("${telemetry.collector.default.port:54322}")
    private Integer telemetryCollectorPort;

    @Value("${tme.path.sync.timeout.minutes:2}")
    private int timeoutMinutes;

    @Value("${tme.path.sync.timeout.seconds:10}")
    private int sleepIntervalSeconds;

    @Value("${tme.path.sync.delay.minutes:3}")
    private int delayBeforeTmeSyncMinutes;

    @Value("${tacacs.server.ip.address}")
    private String tacacsServerIp;

    @Value("${tacacs.server.auto.configuration}")
    private boolean tacacsServerAutoConfig = false;

    //default value is sharedsecret
    @Value("${tacacs.server.shared.key}")
    private String tacacsServerSharedKey;

    @Value("${tacacs.server.service.attribute}")
    private String tacacsServerServiceAttribute;

    //default value is 49, range : 1 - 65535
    @Value("${tacacs.authentication.port:49}")
    private Integer tacacsAuthenticationPort;

    //default value is 5, range : 1 - 60
    @Value("${tacacs.server.timeout.seconds:5}")
    private Integer tacacsServerTimeoutSeconds;

    //default value is 5, range : 0 - 100
    @Value("${tacacs.server.connection.retries:5}")
    private Integer tacacsServerConnectionRetries;

    //CHAP or PAP
    @Value("${tacacs.authentication.protocol:chap}")
    private String tacacsAuthenticationProtocol;

    //default value is 10
    @Value("${evm.init.connection.retry.count:10}")
    private int evmInitConnectionRetryCount;

    //default value is 125
    @Value("${evm.init.connection.wait.seconds:125}")
    private int evmInitConnectionWaitSeconds;

    //default value is 120
    //Delay for establishing StableNet connection with devices before executing CLIs
    @Value("${stablenet.connection.device.wait.seconds:120}")
    private int stablenetDeviceConnectivityWaitSeconds;

    private static final String TELEMETRY_COLLECTOR_IPV4_PORT = "ip %s port %d;";

    private static final String TELEMETRY_COLLECTOR_IPV6_PORT = "ipv6 %s port %d;";

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private GridPolicySetHelper gridPolicySetHelper;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private ApplicationContext applicationContext;

    @Inject
    private InitialDeviceConfiguration configureTelemetryProfile;

    @Inject
    private GenericHelper genericHelper;

    @Inject
    private RestHelperWithoutProxy restHelperWithoutProxy;

    @Inject
    private StatisticsTruncateTables statisticsTruncateTables;

    @Inject
    private StablenetInitializerManager stablenetInitializerManager;

    private AtomicBoolean isRunning = new AtomicBoolean(false);

    @PostConstruct
    void init() {
        saveApplicationConstant(ApplicationConstant.GRID_FEATURE_STATUS_KEY, ApplicationConstant.GRID_FEATURE_STATUS.DOWN.toString());
        //Clearing the all stats after starting evm service.
        statisticsTruncateTables.deleteAllProfilesStats();
    }

    @EventListener
    void runCollectorTACACSAndTopologyPathSync(ApplicationReadyEvent applicationReadyEvent) {
        String initMessage = "Extreme Visibility Manager service is initializing. This may take a few minutes.";
        saveApplicationConstant(ApplicationConstant.EVM_INIT_STATUS_KEY, ApplicationConstant.GRID_FEATURE_STATUS.DOWN.toString());
        genericHelper.sendNotification(null, null, null, Event.Severity.INFO, Job.Type.INITIALIZING_VISIBILITY_MANAGER, Job.Status.SUCCESS, initMessage);
        Set<Long> telemetryConfiguredDeviceIds = Sets.newHashSet();
        try {
            List<Object[]> deviceList = deviceRepository.findAllByTypeAndIsReconciledAndIsProfileConfigured(Lists.newArrayList(Device.Type.SLX), true);
            deviceList.stream().forEach(deviceObj -> {
                if (deviceObj.length > 2 && deviceObj[0] != null && deviceObj[1] != null && deviceObj[2] != null && !String.valueOf(deviceObj[2]).contains(Device.SLX_9850)) {
                    Long id = (Long) deviceObj[0];
                    Device device = deviceRepository.findOne(id);
                    if (device != null) {
                        if (device.getStatus() != Device.STATUS_DOWN) {
                            device.setStatus(Device.STATUS_DOWN);
                        }
                        if (device.isProfileConfigured()) {
                            telemetryConfiguredDeviceIds.add(device.getId());
                            device.setProfileConfigured(false);
                        }
                        deviceRepository.save(device);
                    }
                }
            });
            //On start up the main thread triggers the runCollector method,
            // on failure because of any misconfiguration or services down brings down the server
            ApplicationConfig stablenetRestUrlConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetRestUrl);
            ApplicationConfig stablenetUsernameConfig = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername);
            if (stablenetRestUrlConfig != null && stablenetUsernameConfig != null) {
                String baseUrl = stablenetRestUrlConfig.getValue();
                String username = stablenetUsernameConfig.getValue();
                StringBuilder uri = new StringBuilder(baseUrl);
                if (!baseUrl.endsWith("/") && !resourceUrl.startsWith("/"))
                    uri.append("/");
                uri.append(resourceUrl).append("/").append(username);

                int counter = 0;
                while (true) {
                    try {
                        Response response = restHelperWithoutProxy.get(MediaType.APPLICATION_JSON_TYPE, uri.toString());
                        if (response != null) {
                            if (response.getStatus() == HttpStatus.OK.value()) {
                                break;
                            }
                        }
                    } catch (Exception e) {
                        log.error("Failed to establish the connection with StableNet, going to retry, count={}. {}", counter, e.getMessage());
                    }
                    if (evmInitConnectionRetryCount <= counter++) {
                        break;
                    }
                    try {
                        TimeUnit.SECONDS.sleep(evmInitConnectionWaitSeconds);
                    } catch (InterruptedException e1) {
                        log.debug(e1.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error while connecting to Stablenet, {}", e.getMessage());
        }

        try {
            CollectorScheduler collectorScheduler = applicationContext.getBean(CollectorScheduler.class);
            collectorScheduler.runCollectors();
            stablenetInitializerManager.syncSnmwAgent();
        } catch (Exception e) {
            log.error("Error while collecting the data from Stablenet, {}", e.getMessage());
        }
        try {
            TimeUnit.SECONDS.sleep(stablenetDeviceConnectivityWaitSeconds);
        } catch (InterruptedException e1) {
            log.debug(e1.getMessage());
        }
        try {
            initMessage = "Extreme Visibility Manager service initialized successfully.";
            if (!Strings.isNullOrEmpty(telemetryCollectorIpAddress) && telemetryCollectorPort != null) {
                List<Device> slxDeviceList = deviceRepository.getDevicesByType(Lists.newArrayList(Device.Type.SLX));
                try {
                    configureTelemetryProfile.postDeviceInfo(slxDeviceList, Lists.newArrayList());
                } catch (Exception e) {
                    log.error("Failed to update the device info to collector. {}", e.getMessage());
                }
                ApplicationConstant propertyKeyAppConstant = featureConstantsRepository.findByName(ApplicationConstant.TELEMETRY_COLLECTOR_CONFIG_OLD);
                String telemetryConfigValue = String.format(telemetryCollectorIpAddress.contains(":") ? TELEMETRY_COLLECTOR_IPV6_PORT : TELEMETRY_COLLECTOR_IPV4_PORT, telemetryCollectorIpAddress, telemetryCollectorPort);
                if (propertyKeyAppConstant != null && !Strings.isNullOrEmpty(propertyKeyAppConstant.getValue())) {
                    boolean isTelemetryServerIpUpdated = isPropertyToBeUpdated(ApplicationConstant.TELEMETRY_COLLECTOR_CONFIG_OLD, telemetryConfigValue, false);
                    if (!isTelemetryServerIpUpdated) {
                        configureTelemetryProfile(telemetryConfiguredDeviceIds, false);
                    } else {
                        if (!slxDeviceList.isEmpty()) {
                            Set<Long> telemetryEligibleDeviceIds = Sets.newHashSet();
                            slxDeviceList.stream().forEach(device -> {
                                if (device.getModel() != null && !device.getModel().contains(Device.SLX_9850) && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                                    telemetryEligibleDeviceIds.add(device.getId());
                                }
                            });
                            configureTelemetryProfile(telemetryEligibleDeviceIds, true);
                        }
                    }
                }
                saveApplicationConstant(ApplicationConstant.TELEMETRY_COLLECTOR_CONFIG_OLD, telemetryConfigValue);
            } else {
                log.warn("Telemetry Manager Server IP Address is not configured. Please set the telemetry.collector.ip.address property in application.properties and restart Visibility Manager service.");
            }
        } catch (Exception e) {
            log.error("Error occurred! failed to configure telemetry profile.", e.getMessage());
        }
        try {
            reconfigureTacacsServer();
        } catch (Exception e) {
            log.error("Error occurred! failed to configure TACACS.", e.getMessage());
        }
        saveApplicationConstant(ApplicationConstant.EVM_INIT_STATUS_KEY, ApplicationConstant.GRID_FEATURE_STATUS.UP.toString());
        genericHelper.sendNotification(null, null, null, Event.Severity.INFO, Job.Type.COMPLETED_INITIALIZING_VISIBILITY_MANAGER, Job.Status.SUCCESS, initMessage);
        try {
            TelemetryProfileScheduler telemetryProfileScheduler = applicationContext.getBean(TelemetryProfileScheduler.class);
            telemetryProfileScheduler.syncTopologyPath();
        } catch (Exception e) {
            log.error("Error occurred! failed to sync network path with TME.", e.getMessage());
        }
        saveApplicationConstant(ApplicationConstant.GRID_FEATURE_STATUS_KEY, ApplicationConstant.GRID_FEATURE_STATUS.UP.toString());
    }

    /**
     * Saves the application constants
     *
     * @param key
     * @param value
     */
    private void saveApplicationConstant(String key, String value) {
        ApplicationConstant applicationConstant = featureConstantsRepository.findByName(key);
        if (applicationConstant == null) {
            applicationConstant = new ApplicationConstant();
            applicationConstant.setName(key);
        }
        applicationConstant.setValue(value);
        featureConstantsRepository.save(applicationConstant);
    }

    /**
     * This method sync topology paths saved with TME.
     */
    private void syncTopologyPath() {
        Integer gridTopologyPathCount = gridTopologyPathRepository.getAllPathCount(true);
        if (gridTopologyPathCount > 0) {
            long startTime = System.currentTimeMillis();
            while (true) {
                Integer deviceCountInDownStats = deviceRepository.getCountByTypeAndIsReconciledAndIsProfileConfiguredAndStatus(Lists.newArrayList(Device.Type.SLX), true, Device.STATUS_DOWN);
                if (deviceCountInDownStats == 0) {
                    break;
                }
                try {
                    TimeUnit.SECONDS.sleep(sleepIntervalSeconds);
                } catch (InterruptedException e1) {
                    throw new ServerException(e1);
                }

                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime >= timeoutMinutes * 60 * 1000) {
                    log.warn("Telemetry profile configuration is not completed for {} devices. Going ahead with topology path sync with TME.", deviceCountInDownStats);
                    break;
                }
            }
            try {
                TimeUnit.MINUTES.sleep(delayBeforeTmeSyncMinutes);
            } catch (InterruptedException e1) {
                throw new ServerException(e1);
            }
            gridPolicySetHelper.syncTopologyPath();
        } else {
            log.debug("There is no active network paths to sync.");
        }
    }

    /**
     * Reconfigure/update the telemetry profile on devices which are are eligible.
     * Posting telemetry device info to Collector for filtering the valid neighbors
     *
     * @param deviceIds
     * @param isUpdateCollector
     */
    private void configureTelemetryProfile(Set<Long> deviceIds, boolean isUpdateCollector) {
        String action = isUpdateCollector ? "update" : "reconfigure";
        try {
            log.debug("Starting telemetry profile {} for {} devices", action, deviceIds.size());
            List<Long> jobIds = Lists.newArrayList();
            if (!deviceIds.isEmpty()) {
                Job.Type type = isUpdateCollector ? Job.Type.UPDATE_TELEMETRY_PROFILE : Job.Type.RECONFIG_TELEMETRY_PROFILE;
                deviceIds.stream().forEach(deviceId -> {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(deviceId)
                            .impactedObjectIds(Collections.emptyList()).build());
                    jobIds.add(jobId);
                });
                jobIds.forEach(aLong -> {
                    Job job = genericJobManager.getJobStatus(aLong);
                    if (job != null) {
                        Device device = job.getDevice();
                        if (job.getStatus() == Job.Status.SUCCESS) {
                            if (device != null) {
                                device.setProfileConfigured(true);
                                deviceRepository.save(device);
                            }
                        } else if (job.getStatus() == Job.Status.FAILED) {
                            String userName = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue();
                            String errorMessage = job.getJobResult();
                            if (errorMessage == null || Strings.isNullOrEmpty(errorMessage.trim())) {
                                if (isUpdateCollector) {
                                    errorMessage = "Failed to configure the telemetry profile! Try to manually sync the telemetry from Administration page.";
                                } else {
                                    errorMessage = "Failed to reconfigure the telemetry profile! Try to manually sync the telemetry from Administration page.";
                                }
                            }
                            log.error("Failed to " + action + " telemetry profile on device {} due to {}", device != null ? device.getId() : null, errorMessage);
                            genericHelper.sendNotification(device.getId(), device.getName(), userName, Event.Severity.CRITICAL, type, Job.Status.FAILED, errorMessage);
                            if (device != null) {
                                device.setProfileConfigured(false);
                                deviceRepository.save(device);
                            }
                        }
                    }
                });
            }
            log.info("Telemetry profile " + action + " completed.");
        } catch (Exception e) {
            log.error("Telemetry profile " + action + " failed with exception: {}", e.getMessage());
        }
    }

    /**
     * Reconfigure the TACACS on devices which are are eligible.
     */
    private void reconfigureTacacsServer() {
        ApplicationConstant tacAcsServerIpAppConstant = featureConstantsRepository.findByName(ApplicationConstant.TACACS_SERVER_IP);
        String tacacsServerIpExisting = tacAcsServerIpAppConstant != null ? tacAcsServerIpAppConstant.getValue() : null;

        if (tacacsServerTimeoutSeconds == null || tacacsServerTimeoutSeconds < 1 || tacacsServerTimeoutSeconds > 60) {
            tacacsServerTimeoutSeconds = 5;
        }
        if (tacacsServerConnectionRetries == null || tacacsServerConnectionRetries < 0 || tacacsServerConnectionRetries > 100) {
            tacacsServerConnectionRetries = 5;
        }
        if (tacacsAuthenticationPort == null || tacacsAuthenticationPort < 1 || tacacsAuthenticationPort > 65535) {
            tacacsAuthenticationPort = 49;
        }
        if (Strings.isNullOrEmpty(tacacsServerSharedKey)) {
            tacacsServerSharedKey = ApplicationConstant.TACACS_SHARED_KEY_DEFAULT;
        }
        if (Strings.isNullOrEmpty(tacacsAuthenticationProtocol) || (!ApplicationConstant.TACACS_PROTOCOL.CHAP.getConstant().equals(tacacsAuthenticationProtocol) && !ApplicationConstant.TACACS_PROTOCOL.PAP.getConstant().equals(tacacsAuthenticationProtocol))) {
            tacacsAuthenticationProtocol = ApplicationConstant.TACACS_PROTOCOL.CHAP.getConstant();
        }

        boolean isServerKeyUpdated = false;
        boolean isServerTimeoutUpdated = false;
        boolean isServerConnectionRetriesUpdated = false;
        boolean isAuthenticationPortUpdated = false;
        boolean isAuthenticationProtocolUpdated = false;
        boolean isServiceAttributeUpdated = false;
        boolean isAutoConfigurationStatusUpdated = false;
        boolean isServerIPUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_SERVER_IP, tacacsServerIp, true);
        if (!Strings.isNullOrEmpty(tacacsServerIp)) {
            isServerKeyUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_SERVER_SHARED_KEY, tacacsServerSharedKey, true);
            isServiceAttributeUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_SERVICE_ATTRIBUTE, tacacsServerServiceAttribute, true);
            isServerTimeoutUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_SERVER_TIMEOUT_SECONDS, String.valueOf(tacacsServerTimeoutSeconds), true);
            isServerConnectionRetriesUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_SERVER_CONNECTION_RETRIES, String.valueOf(tacacsServerConnectionRetries), true);
            isAuthenticationPortUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_AUTHENTICATION_PORT, String.valueOf(tacacsAuthenticationPort), true);
            isAuthenticationProtocolUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_AUTHENTICATION_PROTOCOL, tacacsAuthenticationProtocol, true);
            isAutoConfigurationStatusUpdated = isPropertyToBeUpdated(ApplicationConstant.TACACS_AUTO_CONFIGURATION_STATUS, String.valueOf(tacacsServerAutoConfig), true);
        }
        if (tacacsServerAutoConfig && (isServerIPUpdated || isServerKeyUpdated || isAuthenticationProtocolUpdated || isServerTimeoutUpdated
                || isServerConnectionRetriesUpdated || isAuthenticationPortUpdated || isServiceAttributeUpdated || isAutoConfigurationStatusUpdated)) {
            List<Device> devices = deviceRepository.getDevicesByType(Lists.newArrayList(Device.Type.SLX));
            if (!devices.isEmpty()) {
                devices.forEach(device -> {
                    if (device.getModel() != null && !device.getModel().contains(Device.SLX_9850) && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                        configureTelemetryProfile.configureTACACSProfile(device, tacacsServerIp, tacacsServerIpExisting);
                        deviceRepository.save(device);
                    }
                });
            }
        }
    }

    /**
     * Property comparator and update the value in application constant.
     *
     * @param propertyName
     * @param propertyValue
     * @return
     */
    private boolean isPropertyToBeUpdated(String propertyName, String propertyValue, boolean isSave) {
        ApplicationConstant propertyKeyAppConstant = featureConstantsRepository.findByName(propertyName);
        String propertyValueExisting = propertyKeyAppConstant != null ? propertyKeyAppConstant.getValue() : null;
        if ((propertyKeyAppConstant == null && !Strings.isNullOrEmpty(propertyValue)) || (Strings.isNullOrEmpty(propertyValue) && !Strings.isNullOrEmpty(propertyValueExisting))
                || (!Strings.isNullOrEmpty(propertyValue) && !propertyValue.equals(propertyValueExisting))) {
            if (isSave) {
                if (propertyKeyAppConstant == null) {
                    propertyKeyAppConstant = new ApplicationConstant();
                }
                propertyKeyAppConstant.setName(propertyName);
                if (propertyValue != null) {
                    propertyKeyAppConstant.setConstantValue(propertyValue.trim());
                }
                featureConstantsRepository.save(propertyKeyAppConstant);
            }
            log.debug("{} config is different; existing:{}  new:{}", propertyName, propertyValueExisting, propertyValue);
            return true;
        }
        return false;
    }
}

