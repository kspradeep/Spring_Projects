package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.FilterPolicyHistory;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The SdFilterPolicyManager class implements methods to perform SdFilterPolicy create/update/delete/recover on the selected SD device
 */
@Slf4j
@Named(value = "SdFilterPolicyManager")
public class SdFilterPolicyManager extends AbstractSDPolicyManager {

    private static final String FORWARD = "forward";

    @Inject
    protected FilterPolicyRepository sdFilterPolicyRepository;

    @Inject
    protected ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected FilterPolicyHistoryRepository sdFilterPolicyHistoryRepository;

    @Inject
    private PersistFilterPolicyInBatch persistFilterPolicyInBatch;

    @Inject
    private SamplingPolicyRepository samplingPolicyRepository;

    @Inject
    protected EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    protected JobQueue jobQueue;

    /**
     * This method is used to validate if the given SdFilterPolicy is valid to commit on the device
     *
     * @param policyToSave
     * @return
     * @throws ValidationException
     */
    protected boolean isValidFilterPolicyToCommit(FilterPolicy policyToSave) {
        isInProgress(policyToSave, "policy.commit.inprogress");
        List<FilterPolicy> filterPolicies = sdFilterPolicyRepository.findAllByDeviceId(policyToSave.getDevice().getId());

        if (filterPolicies != null && filterPolicies.size() >= FilterRule.FILTER_POLICY_MAX && policyToSave.getId() == null) {
            throw new ValidationException("filterPolicy.max5.allowed");
        }

        if (policyToSave.getId() != null && !WorkflowParticipant.WorkflowStatus.DRAFT.equals(policyToSave.getWorkflowStatus())) {
            List<FilterPolicyHistory> filterPolicyHistories = sdFilterPolicyHistoryRepository.findByIdAndWorkflowStatus(policyToSave.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
            if (!filterPolicyHistories.isEmpty()) {
                comparePolicy(policyToSave, filterPolicyHistories.get(0).buildParent());
            }
        }
        return true;
    }

    /**
     * This method checks if the SdFilterPolicy name is already used by other SD policies for SAVE
     *
     * @param policyToUpdate
     * @throws ValidationException
     */
    protected void isValidFilterPolicyToSave(FilterPolicy policyToUpdate) {

        if (policyToUpdate != null && policyToUpdate.getName().equalsIgnoreCase(FilterPolicy.RESERVE_NAME_FILTER)) {
            throw new ValidationException("policy.save.reserve.name.filter");
        } else if (policyToUpdate.getName() == null) {
            throw new ValidationException("policy.save.invalidname");
        } else if (policyToUpdate.getName().length() > FilterRule.FILTER_POLICY_NAME_MAX) {
            throw new ValidationException("policy.save.invalidname.max16char");
        }
        List<FilterPolicy> filterPolicies = sdFilterPolicyRepository.findByNameAndDevice(policyToUpdate.getName(), policyToUpdate.getDevice().getId());
        if (policyToUpdate.getId() == null && !filterPolicies.isEmpty()) {
            throw new ValidationException("policy.save.tagnotunique");
        }
        List<SamplingPolicy> samplingPolicies = samplingPolicyRepository.findByNameAndDevice(policyToUpdate.getName(), policyToUpdate.getDevice().getId());
        if (!samplingPolicies.isEmpty()) {
            throw new ValidationException("same.name.exists.in.policy");
        }
        isValidFilterRule(policyToUpdate);
    }

    /**
     * This method is used to validate FilterPolicy Rules
     *
     * @param policyToSave
     */
    protected void isValidFilterRule(FilterPolicy policyToSave) {
        policyToSave.getRules().forEach(rule -> {
            if (rule.getPriority() == null) {
                throw new ValidationException("empty.priority.not.allowed");
            } else if (rule.getPriority() < FilterRule.PRIORITY_MIN || rule.getPriority() > FilterRule.PRIORITY_MAX) {
                throw new ValidationException("invalid.priority.range");
            }
            String fileName = null;
            if (rule.getImsiFileName() != null) {
                fileName = rule.getImsiFileName();
                rule.setImsiFileName(rule.getImsiFileName().trim());
            } else if (rule.getImeiFileName() != null) {
                fileName = rule.getImeiFileName();
                rule.setImeiFileName(rule.getImeiFileName().trim());
            } else if (rule.getApnFileName() != null) {
                fileName = rule.getApnFileName();
                rule.setApnFileName(rule.getApnFileName().trim());
            } else if (rule.getSipCallingPartyFileName() != null) {
                fileName = rule.getSipCallingPartyFileName();
                rule.setSipCallingPartyFileName(rule.getSipCallingPartyFileName().trim());
            } else if (rule.getSipCalledPartyFileName() != null) {
                fileName = rule.getSipCalledPartyFileName();
                rule.setSipCalledPartyFileName(rule.getSipCalledPartyFileName().trim());
            }

            if (policyToSave.getTrafficType().equalsIgnoreCase("volte")) {
                if (fileName == null && rule.getSipCallingParty() == null && rule.getSipCalledParty() == null && rule.getImsi() == null)
                    throw new ValidationException("one.filter.param.mandatory");
                if (rule.getApn() != null)
                    throw new ValidationException("volte.parameter.invalid");

                if (rule.getSipCallingParty() != null) {
                    if (rule.getSipCallingParty().trim().length() < FilterRule.SIP_CALL_PARTY_MIN || rule.getSipCallingParty().trim().length() > FilterRule.SIP_CALL_PARTY_MAX)
                        throw new ValidationException("invalid.range.sipPartyValue");
                    rule.setSipCallingParty(rule.getSipCallingParty().trim());
                }
                if (rule.getSipCalledParty() != null) {
                    if (rule.getSipCalledParty().trim().length() < FilterRule.SIP_CALL_PARTY_MIN || rule.getSipCalledParty().trim().length() > FilterRule.SIP_CALL_PARTY_MAX)
                        throw new ValidationException("invalid.range.sipPartyValue");
                    rule.setSipCalledParty(rule.getSipCalledParty().trim());
                }
                if (rule.getImsi() != null) {
                    if (rule.getImsi().trim().length() < FilterRule.IMSI_MIN || rule.getImsi().trim().length() > FilterRule.IMSI_MAX)
                        throw new ValidationException("invalid.imsi.value");
                    rule.setImsi(rule.getImsi().trim());
                }
            } else if (fileName == null && rule.getQci() == null && rule.getImei() == null && rule.getImsi() == null && rule.getApn() == null)
                throw new ValidationException("one.filter.param.mandatory");

            if (rule.getApn() != null) {
                if (rule.getApn().trim().length() == 0)
                    throw new ValidationException("empty.apn.value.invalid");
                rule.setApn(rule.getApn().trim());
            }
            if (rule.getQci() != null) {
                if (rule.getQci() < FilterRule.QCI_MIN || rule.getQci() > FilterRule.QCI_MAX)
                    throw new ValidationException("invalid.qci.value");
            }

            if (FORWARD.equals(rule.getAction()) && rule.getPortGroup() == null)
                throw new ValidationException("empty.portgroup.not.allowed");

            if (rule.getSamplingPolicy() == null) {
                if (FilterRule.APPLY_DEFERRED.equals(rule.getApply()) && rule.getQci() != null) {
                    throw new ValidationException("invalid.combination.deferred.qci");
                }

                if (rule.getImsi() != null) {
                    /*if (!rule.getImsi().endsWith("*") && (rule.getImei().trim().length() < FilterRule.IMSI_SAMPLING_MIN) || rule.getImsi().trim().length() >= FilterRule.IMSI_MAX)
                        throw new ValidationException("wildcard.imsi.value.invalid");*/
                    if (rule.getImsi().trim().length() < FilterRule.IMSI_MIN || rule.getImsi().trim().length() > FilterRule.IMSI_MAX)
                        throw new ValidationException("invalid.imsi.value");
                    rule.setImsi(rule.getImsi().trim());
                }
                if (rule.getImei() != null) {
                    /*if (!rule.getImei().endsWith("*") && (rule.getImei().trim().length() < FilterRule.IMEI_SAMPLING_MIN) || rule.getImei().trim().length() >= FilterRule.IMEI_MAX)
                        throw new ValidationException("wildcard.imei.value.invalid");*/
                    if (rule.getImei().trim().length() < FilterRule.IMEI_MIN || rule.getImei().trim().length() > FilterRule.IMEI_MAX)
                        throw new ValidationException("invalid.imei.value");
                    rule.setImei(rule.getImei().trim());
                }
            } else {
                if (fileName != null && rule.getApnFileName() == null) {
                    throw new ValidationException("invalid.rule.combination");
                }
                if (rule.getImsi() != null) {
                    if (rule.getImsi().trim().length() < FilterRule.IMSI_SAMPLING_MIN || rule.getImsi().trim().length() >= FilterRule.IMSI_MAX)
                        throw new ValidationException("invalid.wildcard.imsi.value");
                    rule.setImsi(rule.getImsi().trim());
                }
                if (rule.getImei() != null) {
                    if (rule.getImei().trim().length() < FilterRule.IMEI_SAMPLING_MIN || rule.getImei().trim().length() >= FilterRule.IMEI_MAX)
                        throw new ValidationException("invalid.wildcard.imei.value");
                    rule.setImei(rule.getImei().trim());
                }
                if (rule.getQci() != null) {
                    throw new ValidationException("sampling.with.qci.notallowed");
                }

            }
        });
    }

    /**
     * This method checks if the SdFilterPolicy input data is valid
     *
     * @param policyToValidate
     * @param isUpdate
     * @throws ValidationException
     */
    public void isPolicyInputValid(SdPolicy policyToValidate, boolean isUpdate) {
        FilterPolicy policy = (FilterPolicy) policyToValidate;
        if (Strings.isNullOrEmpty(policy.getName())) {
            throw new ValidationException("policy.save.invalidname");
        } else {
            if (policyToValidate.getName().length() > FilterRule.FILTER_POLICY_NAME_MAX) {
                throw new ValidationException("policy.save.invalidname.max16char");
            }
        }
    }

    /**
     * This method is used to SAVE SdFilterPolicy in BVM db as DRAFT
     *
     * @param policy
     * @return
     */
    @Override
    public Long savePolicy(SdPolicy policy) {
        FilterPolicy policyToSave = (FilterPolicy) policy;
        //reloading the device object to make it an attached entity.
        Device device = deviceRepository.findById(policyToSave.getDevice().getId());

        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(device.getId());
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(device.getId());
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", device.getId());
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", device.getId());
            throw new ValidationException("sd.profile.not.configured");
        }
        policyToSave.getRules().forEach(rule -> {
            if (rule.getPortGroup() != null || rule.getReplicationPortGroup() != null) {
                Set<EgressPort> ports = new HashSet<>();
                Long portGroupId = rule.getPortGroup() != null ? rule.getPortGroup().getId() : rule.getReplicationPortGroup().getId();
                SdPortGroup sdPortGroup = egressPortGroupRepository.findOne(portGroupId);
                rule.setPortGroup(sdPortGroup);
            }
        });
        isValidFilterPolicyToSave(policyToSave);

        policyToSave.setDevice(device);
        policyToSave.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        // save policy in DB
        policyToSave = persistFilterPolicyInBatch.saveFilterPolicyInBatch(policyToSave);
        return policyToSave.getId();
    }


    /**
     * This method is used to COMMIT SdFilterPolicy in the given SD device
     *
     * @param policyToCommit
     * @return
     * @throws ValidationException
     */
    @Override
    public Long commitPolicy(SdPolicy policyToCommit) {
        FilterPolicy policy = (FilterPolicy) policyToCommit;
        isValidFilterPolicyToCommit(policy);

        Device device = deviceRepository.findById(policy.getDevice().getId());
        policy.setDevice(device);
        boolean isNew = false;
        long jobId = -1;
        long policyId = -1;
        // check if policy exists
        if (policy.getId() == null) {
            policyId = savePolicy(policy);
            isNew = true;
        } else {
            policyId = policy.getId();
        }
        FilterPolicy policyInDb = sdFilterPolicyRepository.findOne(policyId);
        if (policyInDb != null) {
            Job.Type type = Job.Type.SD_FILTER_POLICY_CREATE;
            if (!isNew) {
                if (getPolicyFromHistory(policyInDb, Arrays.asList(WorkflowParticipant.WorkflowStatus.ACTIVE)) != null && !WorkflowParticipant.WorkflowStatus.DRAFT.equals(policyInDb.getWorkflowStatus())) {
                    type = Job.Type.SD_FILTER_POLICY_UPDATE;
                }
                savePolicy(policy);
            }
            List<Long> impactedObjectIds = new ArrayList<>();
            impactedObjectIds.add(policyId);

            jobId = jobQueue.submit(JobTemplate.builder().type(type).deviceId(policy.getDevice().getId())
                    .parentObjectId(policyId).impactedObjectIds(impactedObjectIds).build());
            return jobId;
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to DELETE SdFilterPolicy in the given SD device
     *
     * @param policies
     * @return
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(List<? extends SdPolicy> policies) {
        if (!policies.isEmpty()) {
            List<Long> impactedObjectIds = new ArrayList<>();
            List<FilterPolicy> filterPolicies = new ArrayList<>();
            boolean isActivePolicy = false;
            for (SdPolicy sdPolicy : policies) {
                FilterPolicy policy = sdFilterPolicyRepository.findOne(sdPolicy.getId());
                if (policy != null) {
                    isInProgress(policy, "policy.delete.inprogress");
                    if (!activeInterfaceRepository.findActiveInterfaceBasedOnFilterPolicyId(policy.getId()).isEmpty()) {
                        throw new ValidationException("policy.used.in.interface");
                    }
                    if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                        log.error("Policy {} in error state. Aborting operation", policy.getId());
                        throw new ValidationException("invalid.combination.mix.policy.status");
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                        sdFilterPolicyRepository.delete(policy);
                        log.info("Policy {} in draft state nothing on device so deleting it from BVM", policy.getName());
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                        // should not delete a policy if in Submitted state
                        log.error("Cannot delete a filterPolicy id {} which is in progress.", policy.getId());
                        throw new ValidationException("policy.delete.inprogress");
                    } else if (policy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ACTIVE) {
                        //new request , so setting it to DRAFT
                        policy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        filterPolicies.add(policy);
                        impactedObjectIds.add(policy.getId());
                        isActivePolicy = true;
                    }
                }
            }
            if (!isActivePolicy) {
                return -1l;
            }
            sdFilterPolicyRepository.save(filterPolicies);
            Job.Type jobType = Job.Type.SD_FILTER_POLICY_DELETE;
            long jobId = jobQueue.submit(JobTemplate
                    .builder()
                    .type(jobType)
                    .deviceId(policies.get(0).getDevice().getId())
                    .impactedObjectIds(impactedObjectIds).build());

            return jobId;
        }
        throw new ValidationException("policy.get.notfound");
    }

    /**
     * This method is used to recover SdFilterPolicy which is in ERROR state
     *
     * @param policyId
     * @return
     * @throws ValidationException
     */
    @Override
    public Long recoverPolicy(Long policyId) {
        FilterPolicy filterPolicy = sdFilterPolicyRepository.findOne(policyId);
        if (filterPolicy == null) {
            throw new ValidationException("policy.get.notfound");
        }
        isInProgress(filterPolicy, "policy.recovery.inprogress");
        filterPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        sdFilterPolicyRepository.save(filterPolicy);

        List<Long> impactedObjectIds = new ArrayList<>();
        impactedObjectIds.add(filterPolicy.getId());
        Job.Type jobType = Job.Type.SD_FILTER_POLICY_RECOVER;
        long jobId = jobQueue.submit(JobTemplate
                .builder()
                .type(jobType)
                .deviceId(filterPolicy.getDevice().getId())
                .impactedObjectIds(impactedObjectIds)
                .parentObjectId(policyId).build());

        return jobId;
    }

    /**
     * This method is used to compare Old Policy with New Policy and throw error message if there is no change made
     *
     * @param newPolicy
     * @param oldPolicy
     */
    protected void comparePolicy(FilterPolicy newPolicy, FilterPolicy oldPolicy) {
        if (!newPolicy.getName().equals(oldPolicy.getName())) {
            throw new ValidationException("name.change.not.allowed");
        }
        //Update of Traffic type not allowed if associated with Interface
        if (!activeInterfaceRepository.findActiveInterfaceBasedOnFilterPolicyId(newPolicy.getId()).isEmpty() && !newPolicy.getTrafficType().equalsIgnoreCase(oldPolicy.getTrafficType())) {
            throw new ValidationException("trafficType.change.not.allowed.policy.used.in.interface");
        }

        Map<Long, Integer> newFilterRuleMap = new ConcurrentHashMap<>();
        Map<Long, Integer> oldFilterRuleMap = new ConcurrentHashMap<>();
        oldPolicy.getRules().parallelStream().forEach(rule -> {
            oldFilterRuleMap.put(rule.getId(), rule.hash());
        });
        newPolicy.getRules().parallelStream().forEach(rule -> {
            Long ruleId = rule.getId() != null ? rule.getId() : rule.hash();
            newFilterRuleMap.put(ruleId, rule.hash());
        });
        MapDifference<Long, Integer> ruleMapDifference = Maps.difference(oldFilterRuleMap, newFilterRuleMap);
        if (ruleMapDifference.areEqual() && newPolicy.getTrafficType().equalsIgnoreCase(oldPolicy.getTrafficType()) && newPolicy.isPreserveCplane() == oldPolicy.isPreserveCplane()) {
            throw new ValidationException("same.configuration");
        }


    }

    /**
     * This method fetches the latest ACTIVE policy from history for the current policy
     *
     * @param policy
     * @param workflowStatus
     * @return
     */
    protected FilterPolicy getPolicyFromHistory(FilterPolicy policy, List<WorkflowParticipant.WorkflowStatus> workflowStatus) {
        FilterPolicy policyFromHistory = null;
        // get the previous policy name from the history.
        List<FilterPolicyHistory> policyHistoryList = sdFilterPolicyHistoryRepository.findByIdAndWorkflowStatus(policy.getId(),
                workflowStatus);
        if (!policyHistoryList.isEmpty()) {
            FilterPolicyHistory oldPolicy = policyHistoryList.get(0);
            log.debug("Found a FilterPolicyHistory entity with oldName {} and lasted SdFilterPolicyName {}", oldPolicy.getName(), policy.getName());
            policyFromHistory = oldPolicy.buildParent();
        }
        return policyFromHistory;
    }

    /**
     * This method is use to validate if some operation is in progress it will not allow to proceed further
     *
     * @param filterPolicy
     * @param operation
     */
    protected void isInProgress(FilterPolicy filterPolicy, String operation) {
        List<FilterPolicy> inProgressOrErrorPoliciesOnDevice = sdFilterPolicyRepository
                .findByDeviceAndInWorkflowStatus(filterPolicy.getDevice().getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
        if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
            throw new ValidationException(operation);
        }
    }
}