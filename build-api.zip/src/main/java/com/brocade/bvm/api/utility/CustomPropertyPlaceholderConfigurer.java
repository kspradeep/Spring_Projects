package com.brocade.bvm.api.utility;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.context.support.StandardServletEnvironment;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Class to trim white spaces from properties files
 */
@Configuration
@Slf4j
public class CustomPropertyPlaceholderConfigurer extends PropertySourcesPlaceholderConfigurer {

    private static final String ENVIRONMENT_PROPERTIES = "environmentProperties";

    @Override
    public void postProcessBeanFactory(
            final ConfigurableListableBeanFactory beanFactory)
            throws BeansException {

        super.postProcessBeanFactory(beanFactory);

        final StandardServletEnvironment propertySources =
                (StandardServletEnvironment) super.getAppliedPropertySources().get(ENVIRONMENT_PROPERTIES).getSource();

        propertySources.getPropertySources().forEach(propertySource -> {
            if (propertySource.getSource() instanceof Map) {
//                log.debug("property name : {}", propertySource.getName());
                if (propertySource.getName() != null && !propertySource.getName().contains("systemEnvironment")) {
                    Map<String, String> properties = mapValueAsString((Map<String, Object>) propertySource.getSource());
//                    log.debug("properties {}", properties);
                    properties.forEach((s, s2) -> {
                        if (s != null && s2 != null && propertySource.getSource() != null) {
                            ((Map) propertySource.getSource()).replace(s, s2.trim());
                        }
                    });
                }
            }
        });
    }

    private Map<String, String> mapValueAsString(
            final Map<String, Object> map) {
        return map.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> toString(entry.getValue())));
    }

    private String toString(
            final Object object) {
        return Optional.ofNullable(object).map(value -> value.toString()).orElse(null);
    }
}