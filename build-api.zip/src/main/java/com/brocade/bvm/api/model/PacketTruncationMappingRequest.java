package com.brocade.bvm.api.model;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PacketTruncationMappingRequest {

    private Long id;

    private Long deviceId;

    private String portId;

    private INTERFACE_TYPE type;

    public enum INTERFACE_TYPE {
        PORT,
        PORT_CHANNEL
    }
}
