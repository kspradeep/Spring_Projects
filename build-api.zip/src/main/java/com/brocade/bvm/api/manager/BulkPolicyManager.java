package com.brocade.bvm.api.manager;

import com.brocade.bvm.api.model.DevicePolicyRequest;
import com.brocade.bvm.api.model.SdPolicyRequest;
import com.brocade.bvm.model.db.DevicePolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;

public interface BulkPolicyManager {

    public FilterPolicy saveAndCommitPolcies(SdPolicyRequest sdPolicyRequest, Long deviceId);

    public void isPolicyInputValid(SdPolicyRequest SdPolicyRequest);
}
