package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.GlobalManager;
import com.brocade.bvm.api.model.PacketTruncationMappingRequest;
import com.brocade.bvm.api.model.PacketTruncationRequest;
import com.brocade.bvm.api.model.PacketTruncationResponse;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridClusterRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.db.history.PacketTruncationMappingHistory;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.stablenet.service.InitialDeviceConfiguration;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * GlobalManagerImpl class performs the global configuration changes on devices.
 */
@Named
@Slf4j
public class GlobalManagerImpl implements GlobalManager {

    private static final String CREATE_PROFILE = "createProfile";
    private static final String UPDATE_PROFILE = "updateProfile";
    private static final String DELETE_PROFILE = "deleteProfile";

    private static final String SPACE_REGEX = "\\s+";
    private static final String ANY_CHAR_REGEX = "(.*)";
    private static final String TACACS_SERVER = "tacacs-server host";
    private static final String VRF = "use-vrf mgmt-vrf";

    @Inject
    protected PortRepository portRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    protected PacketTruncationRepository packetTruncationRepository;

    @Inject
    protected PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    protected JobRepository jobRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    protected PolicyRepository policyRepository;

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    @Value("${slx.tacacs.authorization.supported.os.version:18.1.03}")
    private String slxTacacsAuthorizationSupportedVersion;

    @Value("${telemetry.collector.ip.address}")
    private String telemetryCollectorIpAddress;

    @Value("${telemetry.collector.default.port:54322}")
    private Integer telemetryCollectorPort;

    @Value("${tacacs.server.ip.address}")
    private String tacacsServerIp;

    @Value("${tacacs.server.auto.configuration}")
    private boolean tacacsServerAutoConfig = false;

    @Value("${slx.tacacs.authorization.supported.os.version:18.1.03}")
    private String slxPacketTrincationTacacsAuthorizationSupportedVersion;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private EventRepository eventRepository;

    @Inject
    private ConfigRepository configRepository;

    @Inject
    private PacketTruncationMappingHistoryRepository packetTruncationMappingHistoryRepository;

    @Inject
    private ManagedObjectRepository managedObjectRepository;

    @Inject
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Inject
    private GridClusterRepository gridClusterRepository;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    private GenericHelper genericHelper;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private GenericJobManager genericJobManager;

    @Inject
    private InitialDeviceConfiguration initialDeviceConfiguration;

    private AtomicBoolean isTacacsConfigRunning = new AtomicBoolean(false);

    private AtomicBoolean isTelemetryConfigRunning = new AtomicBoolean(false);

    /**
     * Reconfigure the telemetry and tacacs configurations
     */
    @Override
    public String refreshDeviceConfiguration() {
        ApplicationConstant evmInitStatus = featureConstantsRepository.findByName(ApplicationConstant.EVM_INIT_STATUS_KEY);
        if (evmInitStatus != null && ApplicationConstant.GRID_FEATURE_STATUS.UP.toString().equals(evmInitStatus.getValue())) {
            JSONArray responseArray = new JSONArray();
            configureTelemetryProfile(responseArray);
            configureTacacs(responseArray);
            return (responseArray.toString());
        } else {
            throw new ValidationException("Extreme Visibility Manager service is initializing. This may take a few minutes.");
        }
    }

    /**
     * Configure the Telemetry profile for non-configured devices
     */
    public JSONArray configureTelemetryProfile(JSONArray deviceArray) {
        if (Strings.isNullOrEmpty(telemetryCollectorIpAddress)) {
            log.error("Telemetry Manager Server IP Address is not configured. Please set the telemetry.collector.ip.address property in application.properties and restart Visibility Manager service.");
            return null;
        }
        if (isTelemetryConfigRunning.get()) {
            while (isTelemetryConfigRunning.get()) {
                try {
                    TimeUnit.SECONDS.sleep(10);
                } catch (InterruptedException e) {
                    throw new ServerException(e);
                }
            }
            return null;
        }

        synchronized (this) {
            isTelemetryConfigRunning.set(true);
            try {
                List<Long> jobIds = Lists.newArrayList();
                List<Object[]> deviceList = deviceRepository.findAllByTypeAndIsReconciledAndIsProfileConfigured(Lists.newArrayList(Device.Type.SLX), false);
                if (!deviceList.isEmpty()) {
                    log.info("Starting telemetry profile configuration.");
                    deviceList.stream().forEach(deviceObj -> {
                        if (deviceObj.length > 2 && deviceObj[0] != null && deviceObj[1] != null && deviceObj[2] != null && !String.valueOf(deviceObj[2]).contains(Device.SLX_9850)) {
                            Long id = (Long) deviceObj[0];
                            if (genericHelper.isSLXVersionValid(String.valueOf(deviceObj[1]), slxTelemetrySupportedVersion) >= 0) {
                                Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.CONFIG_TELEMETRY_PROFILE).deviceId(id)
                                        .impactedObjectIds(Collections.emptyList()).build());
                                jobIds.add(jobId);
                            }
                        }
                    });
                    jobIds.forEach(aLong -> {
                        Job job = genericJobManager.getJobStatus(aLong);
                        if (job != null) {
                            Device device = job.getDevice();
                            try {
                                JSONObject deviceObject = new JSONObject();
                                deviceObject.put("deviceName", device.getName());
                                deviceObject.put("type", "TELEMETRY_PROFILE");
                                if (job.getStatus() == Job.Status.SUCCESS) {
                                    if (device != null) {
                                        log.debug("Telemetry profile configuration is successful on device {}.", device.getId());
                                        device.setProfileConfigured(true);
                                        deviceObject.put("status", Job.Status.SUCCESS);
                                        deviceRepository.save(device);
                                    }
                                } else if (job.getStatus() == Job.Status.FAILED) {
                                    log.debug("Telemetry profile configuration is failed on device id {}.", device.getId());
                                    String userName = configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue();
                                    genericHelper.sendNotification(device.getId(), device.getName(), userName, Event.Severity.CRITICAL, Job.Type.CONFIG_TELEMETRY_PROFILE, Job.Status.FAILED, job.getJobResult());
                                    deviceObject.put("status", Job.Status.FAILED);
                                }
                                deviceArray.put(deviceObject);
                            } catch (JSONException e) {
                                log.error("Telemetry profile configuration failed. {}", e.getMessage());
                            }
                        }
                    });
                    log.info("Telemetry profile configuration completed.");
                }
            } catch (Exception e) {
                log.error("Telemetry profile configuration failed with exception: {}", e.getMessage());
                //TODO create event
            } finally {
                try {
                    isTelemetryConfigRunning.set(false);
                } catch (Exception e) {
                    log.error("Failed to update the telemetry profile configuration status : {}", e.getMessage());
                }
            }
        }
        return deviceArray;
    }

    /**
     * Configure the TACACS authentication and authorization for non-configured devices
     */
    private JSONArray configureTacacs(JSONArray deviceArray) {
        if (Strings.isNullOrEmpty(tacacsServerIp)) {
            //TACACS configuration
            log.warn("TACACS server IP address is not configured. Please set the tacacs.server.ip.address property in application.properties and restart Visibility Manager service.");
            return null;
        }
        if (isTacacsConfigRunning.get()) {
            while (isTacacsConfigRunning.get()) {
                try {
                    TimeUnit.SECONDS.sleep(10);
                } catch (InterruptedException e) {
                    throw new ServerException(e);
                }
            }
            return null;
        }

        synchronized (this) {
            isTacacsConfigRunning.set(true);
            try {
                List<Device> deviceList = deviceRepository.findByTypeAndIsReconciledAndIsAuthenticated(Lists.newArrayList(Device.Type.SLX), false);
                if (!deviceList.isEmpty()) {
                    log.info("Starting TACACS server configuration.");
                    deviceList.stream().forEach(device -> {
                        try {
                            if (device.getOs() != null && device.getModel() != null && !device.getModel().contains(Device.SLX_9850) && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                                JSONObject deviceObject = new JSONObject();
                                deviceObject.put("deviceName", device.getName());
                                if (tacacsServerAutoConfig) {
                                    boolean isSuccessful = initialDeviceConfiguration.configureTACACSProfile(device, tacacsServerIp, null);
                                    if (isSuccessful) {
                                        if (device.isAuthenticationConfigured() && !device.isAuthorizationConfigured()) {
                                            deviceObject.put("type", "TACACS_AUTHENTICATION");
                                        } else if (!device.isAuthenticationConfigured() && device.isAuthorizationConfigured()) {
                                            deviceObject.put("type", "TACACS_AUTHORIZATION");
                                        } else {
                                            deviceObject.put("type", "TACACS_AUTHENTICATION_AUTHORIZATION");
                                        }
                                        deviceObject.put("status", Job.Status.SUCCESS);
                                        deviceRepository.save(device);
                                    } else {
                                        if (!device.isAuthenticationConfigured() && device.isAuthorizationConfigured()) {
                                            deviceObject.put("type", "TACACS_AUTHENTICATION");
                                        } else if (device.isAuthenticationConfigured() && !device.isAuthorizationConfigured()) {
                                            deviceObject.put("type", "TACACS_AUTHORIZATION");
                                        } else {
                                            deviceObject.put("type", "TACACS_AUTHENTICATION_AUTHORIZATION");
                                        }
                                        deviceObject.put("status", Job.Status.FAILED);
                                    }
                                } else {
                                    String tacacsResponse = initialDeviceConfiguration.getTACACSConfiguration(device);
                                    boolean isTacConfigured = false;
                                    if (!Strings.isNullOrEmpty(tacacsResponse)) {
                                        StringBuffer strbuf = new StringBuffer(ANY_CHAR_REGEX);
                                        strbuf.append(TACACS_SERVER).append(SPACE_REGEX).append(ANY_CHAR_REGEX).append(SPACE_REGEX).append(VRF).append(ANY_CHAR_REGEX);

                                        Matcher matcher = Pattern.compile(strbuf.toString()).matcher(tacacsResponse.trim());
                                        Set<String> tacServerIpSet = Sets.newHashSet();
                                        while (matcher.find() && matcher.groupCount() == 3) {
                                            String tacServerIp = matcher.group(2);
                                            if (!Strings.isNullOrEmpty(tacServerIp)) {
                                                tacServerIpSet.add(tacServerIp);
                                            }
                                        }
                                        if (!tacServerIpSet.isEmpty()) {
                                            if (tacServerIpSet.contains(tacacsServerIp)) {
                                                if (tacacsResponse.contains("aaa authentication login tacacs+")
                                                        && tacacsResponse.contains("aaa accounting exec default start-stop tacacs+")
                                                        && tacacsResponse.contains("aaa accounting commands default start-stop tacacs+")) {
                                                    device.setAuthenticationConfigured(true);
                                                    deviceObject.put("type", "TACACS_AUTHENTICATION");
                                                    if (tacacsResponse.contains("aaa authorization command tacacs+")) {
                                                        device.setAuthorizationConfigured(true);
                                                        deviceObject.put("type", "TACACS_AUTHENTICATION_AUTHORIZATION");
                                                    }
                                                    deviceObject.put("status", Job.Status.SUCCESS);
                                                    isTacConfigured = true;
                                                    deviceRepository.save(device);
                                                }
                                            } else {
                                                log.error("TACACS host IP address {} on device is not matching with TACACS host IP address configured on EVM.", tacServerIpSet);
                                            }
                                        }
                                    }
                                    if (!isTacConfigured) {
                                        deviceObject.put("type", "TACACS_AUTHENTICATION_AUTHORIZATION");
                                        deviceObject.put("status", "NOT ENABLED");
                                        log.error("TACACS configuration is either missing or incorrect on device {}.", device.getId());
                                    }
                                }
                                deviceArray.put(deviceObject);
                            }
                        } catch (JSONException e) {
                            log.error("TACACS server configuration failed. {}", e.getMessage());
                        }
                    });
                    log.info("TACACS server configuration completed.");
                }
                List<Device> deviceListAuthorization = deviceRepository.findByTypeAndIsReconciledAndAuthenticatedAndIsAuthorized(Lists.newArrayList(Device.Type.SLX), false);
                deviceListAuthorization = deviceListAuthorization.stream().filter(device -> device.getOs() != null && device.getModel() != null && !device.getModel().contains(Device.SLX_9850)
                        && initialDeviceConfiguration.isSLXSupportsTelemetry(device.getOs(), slxPacketTrincationTacacsAuthorizationSupportedVersion) >= 0).collect(Collectors.toList());
                if (!deviceListAuthorization.isEmpty()) {
                    log.info("Starting TACACS authorization configuration.");
                    deviceListAuthorization.stream().forEach(device -> {
                        try {
                            JSONObject deviceObject = new JSONObject();
                            deviceObject.put("deviceName", device.getName());
                            deviceObject.put("type", "TACACS_AUTHORIZATION");
                            boolean isSuccessful = initialDeviceConfiguration.configureTACACSAuthorization(device);
                            if (isSuccessful) {
                                deviceObject.put("status", Job.Status.SUCCESS);
                                deviceRepository.save(device);
                            } else {
                                deviceObject.put("status", Job.Status.FAILED);
                            }
                            deviceArray.put(deviceObject);
                        } catch (JSONException e) {
                            log.error("TACACS server authorization configuration failed. {}", e.getMessage());
                        }
                    });
                    log.info("TACACS authorization configuration completed.");
                }
            } catch (Exception e) {
                log.error("TACACS server configuration failed with exception: {}", e.getMessage());
            } finally {
                try {
                    isTacacsConfigRunning.set(false);
                } catch (Exception e) {
                    log.error("Failed to update the TACACS server configuration status : {}", e.getMessage());
                }
            }
        }
        return deviceArray;
    }

    /**
     * Commit the packet truncation profile to devices
     *
     * @param request
     * @return
     * @throws ValidationException
     */
    @Override
    public List commit(Object request) throws ValidationException {
        PacketTruncationRequest packetTruncationRequest = (PacketTruncationRequest) request;
        validatePacketTruncationProfile(packetTruncationRequest, false);

        //save the truncation profile to evm database
        PacketTruncation packetTruncation = saveTruncationProfile(packetTruncationRequest);
        List<Long> jobList = Lists.newArrayList();
        List<PacketTruncationResponse> packetTruncationResponses = Lists.newArrayList();
        if (packetTruncation != null) {
            //commit the truncation profile to the devices as per the request
            packetTruncation.getPacketTruncationMappings().forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_PROFILE_CREATE).deviceId(device.getId())
                            .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
                    if (jobId != -1) {
                        jobList.add(jobId);
                    }
                }
            });
            if (packetTruncationRequest.isGlobal() && packetTruncationRequest.getPolicyName() != null && packetTruncationRequest.getSequenceNumbers() != null) {
                updateJobResult(jobList, packetTruncationResponses, true);
                updatePacketTruncationOnDevices(packetTruncationResponses, packetTruncation, packetTruncationRequest.getPolicyName(), packetTruncationRequest.getSequenceNumbers(), true);
                return packetTruncationResponses;
            }
        }
        return jobList;
    }

    /**
     * Update the  packet truncation profile in devices
     *
     * @param request
     * @return
     * @throws ValidationException
     */
    @Override
    public List update(Long id, Object request) throws ValidationException {
        List<Long> jobList = Lists.newArrayList();
        PacketTruncationRequest packetTruncationRequest = (PacketTruncationRequest) request;
        validatePacketTruncationProfile(packetTruncationRequest, true);
        if (id != null) {
            List<PacketTruncationResponse> packetTruncationResponses = Lists.newArrayList();
            PacketTruncation packetTruncation = packetTruncationRepository.findOne(id);
            //cascade update for the existing, new  and deleted entities
            Set<PacketTruncationMapping> packetTruncationMappings = updatePacketTruncationProfile(packetTruncation, packetTruncationRequest, packetTruncationResponses);
            Set<PacketTruncationMapping> packetTruncationMappingsAdd = Sets.newHashSet();
            Set<PacketTruncationMapping> packetTruncationMappingsUpdate = Sets.newHashSet();
            Set<PacketTruncationMapping> packetTruncationMappingsDelete = Sets.newHashSet();
            packetTruncationMappings.stream().forEach(packetTruncationMapping -> {
                String jobType = findTheJobType(packetTruncationMapping, packetTruncationRequest);
                if (jobType != null) {
                    if (jobType.equals(CREATE_PROFILE)) {
                        packetTruncationMappingsAdd.add(packetTruncationMapping);
                    } else if (jobType.equals(UPDATE_PROFILE) && isUpdatePacketTruncationProfileInDevice(packetTruncationMapping)) {
                        packetTruncationMappingsUpdate.add(packetTruncationMapping);
                    } else if (jobType.equals(DELETE_PROFILE)) {
                        packetTruncationMappingsDelete.add(packetTruncationMapping);
                    }
                }
            });
            List<Long> jobListAdd = Lists.newArrayList();
            List<Long> jobListUpdate = Lists.newArrayList();
            List<Long> jobListDelete = Lists.newArrayList();
            packetTruncationMappingsUpdate.forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_PROFILE_UPDATE).deviceId(device.getId())
                        .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
                if (jobId != -1) {
                    jobListUpdate.add(jobId);
                }
            });
            packetTruncationMappingsAdd.forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_PROFILE_CREATE).deviceId(device.getId())
                            .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
                    if (jobId != -1) {
                        jobListAdd.add(jobId);
                    }
                }
            });
            if (packetTruncation.isGlobal()) {
                updateJobResult(jobListAdd, packetTruncationResponses, true);
                List<Long> jobListPolicyAdd = Lists.newArrayList();
                packetTruncationMappingsAdd.forEach(packetTruncationMapping -> {
                    Device device = packetTruncationMapping.getDevice();
                    if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                        jobListPolicyAdd.addAll(updatePacketTruncationOnDevicePolicy(packetTruncationResponses, packetTruncationMapping, packetTruncation.getGlobalPolicyName(), packetTruncation.getGlobalPolicySequenceNumbers(), true));
                    }
                });
                updateJobResult(jobListPolicyAdd, packetTruncationResponses, false);

                List<Long> jobListPolicyDelete = Lists.newArrayList();
                packetTruncationMappingsDelete.forEach(packetTruncationMapping -> {
                    Device device = packetTruncationMapping.getDevice();
                    if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                        jobListPolicyDelete.addAll(updatePacketTruncationOnDevicePolicy(packetTruncationResponses, packetTruncationMapping, packetTruncation.getGlobalPolicyName(), packetTruncation.getGlobalPolicySequenceNumbers(), false));
                    }
                });
                updateJobResult(jobListPolicyDelete, packetTruncationResponses, false);
            }
            packetTruncationMappingsDelete.forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                    Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_PROFILE_DELETE).deviceId(device.getId())
                            .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
                    if (jobId != -1) {
                        jobListDelete.add(jobId);
                    }
                }
            });

            if (packetTruncation.isGlobal()) {
                updateJobResult(jobListDelete, packetTruncationResponses, true);
                if (packetTruncationResponses.isEmpty()) {
                    throw new ValidationException("no.change.in.config");
                } else {
                    return packetTruncationResponses;
                }
            } else {
                jobList.addAll(jobListAdd);
                jobList.addAll(jobListUpdate);
                jobList.addAll(jobListDelete);
                return jobList;
            }
        }
        throw new ValidationException("packetTruncationProfile.data.invalid");
    }

    /**
     * Get or create PacketTruncationResponse object from existing list.
     *
     * @param packetTruncationResponses
     * @param deviceId
     * @return
     */
    private PacketTruncationResponse getProfileResponse(List<PacketTruncationResponse> packetTruncationResponses, Long deviceId, String deviceName) {
        Optional<PacketTruncationResponse> packetTruncationResponseOptional = packetTruncationResponses.stream().filter(packetTruncationResponse -> packetTruncationResponse.getDeviceId().equals(deviceId)).findAny();
        if (packetTruncationResponseOptional.isPresent()) {
            return packetTruncationResponseOptional.get();
        } else {
            PacketTruncationResponse packetTruncationResponse = new PacketTruncationResponse();
            packetTruncationResponse.setDeviceId(deviceId);
            packetTruncationResponse.setDeviceName(deviceName);
            packetTruncationResponses.add(packetTruncationResponse);
            return packetTruncationResponse;
        }
    }

    /**
     * Update the PacketTruncationResponse object based on job result and type
     *
     * @param jobIdList
     * @param packetTruncationResponses
     */
    private void updateJobResult(List<Long> jobIdList, List<PacketTruncationResponse> packetTruncationResponses, boolean isPtType) {
        if (jobIdList != null && packetTruncationResponses != null) {
            jobIdList.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    PacketTruncationResponse packetTruncationResponse = getProfileResponse(packetTruncationResponses, device.getId(), device.getName());
                    if (job.getStatus() == Job.Status.FAILED) {
                        if (isPtType) {
                            packetTruncationResponse.setPtErrorResult(job.getJobResult());
                        } else {
                            packetTruncationResponse.setPolicyErrorResult(job.getJobResult());
                        }
                    } else {
                        if (isPtType) {
                            packetTruncationResponse.setPtSuccessful(true);
                        } else {
                            packetTruncationResponse.setPolicySuccessful(true);
                        }
                    }
                }
            });
        }
    }

    /**
     * Delete the packet truncation profiles in devices
     *
     * @param id
     * @return
     * @throws ValidationException
     */
    @Override
    public List delete(Long id) throws ValidationException {
        List<Long> jobList = new ArrayList<>();
        List<PacketTruncationResponse> packetTruncationResponses = Lists.newArrayList();
        Set<PacketTruncationMapping> packetTruncationMappings = new HashSet<>();
        PacketTruncation packetTruncation = packetTruncationRepository.findOne(id);
        if (packetTruncation != null) {
            for (PacketTruncationMapping packetTruncationMapping : packetTruncation.getPacketTruncationMappings()) {
                if (packetTruncationMapping.getWorkflowStatus() != null && WorkflowParticipant.WorkflowStatus.ACTIVE == packetTruncationMapping.getWorkflowStatus()) {
                    if (isPolicyAssociated(packetTruncationMapping.getId())) {
                        throw new ValidationException(String.format("Cannot update profile on %s as the Packet Truncation Profile is either applied on a policy or is in error state.", packetTruncationMapping.getDevice() != null ? packetTruncationMapping.getDevice().getName() : null));
                    }
                    packetTruncationMappings.add(packetTruncationMapping);
                } else if (packetTruncationMapping.getWorkflowStatus() != null && WorkflowParticipant.WorkflowStatus.ERROR == packetTruncationMapping.getWorkflowStatus()) {
                    throw new ValidationException(String.format("Cannot update profile on %s as the Packet Truncation Profile is either applied on a policy or is in error state.", packetTruncationMapping.getDevice() != null ? packetTruncationMapping.getDevice().getName() : null));
                }
            }
        } else {
            throw new ValidationException("Invalid Packet Truncation Profile Id!");
        }
        packetTruncation.setPacketTruncationMappings(packetTruncationMappings);
        packetTruncationRepository.save(packetTruncation);
        List<Long> jobListPolicyDelete = Lists.newArrayList();
        if (packetTruncation.isGlobal()) {
            packetTruncationMappings.forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                    jobListPolicyDelete.addAll(updatePacketTruncationOnDevicePolicy(packetTruncationResponses, packetTruncationMapping, packetTruncation.getGlobalPolicyName(), packetTruncation.getGlobalPolicySequenceNumbers(), false));
                }
            });
            jobListPolicyDelete.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    PacketTruncationResponse packetTruncationResponse = getProfileResponse(packetTruncationResponses, device.getId(), device.getName());
                    if (job.getStatus() == Job.Status.FAILED) {
                        packetTruncationResponse.setPolicyErrorResult(job.getJobResult());
                    } else {
                        packetTruncationResponse.setPolicySuccessful(true);
                    }
                }
            });
        }
        packetTruncationMappings.forEach(packetTruncationMapping -> {
            Device device = packetTruncationMapping.getDevice();
            if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                long jobId = -1;
                jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_PROFILE_DELETE).deviceId(device.getId())
                        .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
                if (jobId != -1) {
                    jobList.add(jobId);
                }
            }
        });
        if (packetTruncation.isGlobal() && !jobListPolicyDelete.isEmpty()) {
            jobList.forEach(aLong -> {
                Job job = genericJobManager.getJobStatus(aLong);
                if (job != null) {
                    Device device = job.getDevice();
                    PacketTruncationResponse packetTruncationResponse = getProfileResponse(packetTruncationResponses, device.getId(), device.getName());
                    if (job.getStatus() == Job.Status.FAILED) {
                        packetTruncationResponse.setPtErrorResult(job.getJobResult());
                    } else {
                        packetTruncationResponse.setPtSuccessful(true);
                    }
                }
            });
        }
        List<PacketTruncation> truncationProfileList = Lists.newArrayList(packetTruncationRepository.findAll());
        truncationProfileList.stream().forEach(packetTruncationObj -> {
            if (packetTruncationObj != null && packetTruncationObj.getPacketTruncationMappings().isEmpty()) {
                packetTruncationRepository.delete(packetTruncationObj.getId());
            }
        });
        if (packetTruncation.isGlobal() && !jobListPolicyDelete.isEmpty()) {
            return packetTruncationResponses;
        } else {
            return jobList;
        }
    }

    /**
     * Display the packet truncation profile summaries
     *
     * @return
     */
    @Override
    public String getProfiles() {
        List<PacketTruncation> truncationProfileList = Lists.newArrayList(packetTruncationRepository.findAll());
        JSONArray packetTruncationArrray = new JSONArray();
        if (!truncationProfileList.isEmpty()) {
            truncationProfileList.stream().forEach(packetTruncationObj -> {
                if (!packetTruncationObj.getPacketTruncationMappings().isEmpty()) {
                    JSONObject packetTruncationJsonObject = new JSONObject();
                    JSONArray packetTruncationMappingSummaryArray = new JSONArray();
                    AtomicBoolean isTypePortChannel = new AtomicBoolean(false);
                    AtomicReference<String> interfaceName = new AtomicReference();
                    packetTruncationObj.getPacketTruncationMappings().stream().forEach(packetTruncationMapping -> {
                        JSONObject packetTruncationMappingSummaryJsonObject = new JSONObject();
                        try {
                            Device device = packetTruncationMapping.getDevice();
                            if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                                packetTruncationMappingSummaryJsonObject.put("id", packetTruncationMapping.getId());
                                packetTruncationMappingSummaryJsonObject.put("deviceId", device.getId());
                                packetTruncationMappingSummaryJsonObject.put("deviceName", device.getName());
                                Port port = packetTruncationMapping.getPort();
                                PortGroup portGroup = packetTruncationMapping.getPortGroup();
                                if (port != null) {
                                    isTypePortChannel.set(false);
                                    interfaceName.set(port.getName());
                                    packetTruncationMappingSummaryJsonObject.put("portId", port.getId() != null ? port.getId() : JSONObject.NULL);
                                    packetTruncationMappingSummaryJsonObject.put("portNumber", port.getName());
                                    packetTruncationMappingSummaryJsonObject.put("type", PacketTruncationMappingRequest.INTERFACE_TYPE.PORT);
                                } else if (portGroup != null) {
                                    isTypePortChannel.set(true);
                                    interfaceName.set(portGroup.getName());
                                    packetTruncationMappingSummaryJsonObject.put("portId", portGroup.getId() != null ? portGroup.getId() : JSONObject.NULL);
                                    packetTruncationMappingSummaryJsonObject.put("portChannel", portGroup.getName());
                                    packetTruncationMappingSummaryJsonObject.put("type", PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL);
                                }
                                Set<BigInteger> policyIds = flowRepository.findByPacketTruncationMappingId(packetTruncationMapping.getId());
                                String policyNames = null;
                                if (!policyIds.isEmpty()) {
                                    policyNames = policyIds.stream().map(policyId -> {
                                        String policy = policyRepository.findNameById(policyId.longValue());
                                        return policy;
                                    }).collect(Collectors.joining(","));
                                }
                                packetTruncationMappingSummaryJsonObject.put("policyName", !Strings.isNullOrEmpty(policyNames) ? policyNames : JSONObject.NULL);
                                packetTruncationMappingSummaryJsonObject.put("workflowStatus", packetTruncationMapping.getWorkflowStatus() != null ? packetTruncationMapping.getWorkflowStatus().name() : JSONObject.NULL);
                                if (packetTruncationMapping.getWorkflowStatus() != null && packetTruncationMapping.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                                    String jobResult = null;
                                    Object[] jobResultAndStatus = (Object[]) jobRepository.getJobStatusByObjectId(packetTruncationMapping.getId());
                                    if (jobResultAndStatus != null && jobResultAndStatus.length == 2) {
                                        if (Job.Status.FAILED.toString().equals(jobResultAndStatus[1])) {
                                            jobResult = String.valueOf(jobResultAndStatus[0]);
                                        }
                                    }
                                    if (jobResult == null) {
                                        jobResult = eventRepository.getEventByObjectId(packetTruncationMapping.getId());
                                    }
                                    packetTruncationMappingSummaryJsonObject.put("result", jobResult);
                                }
                                packetTruncationMappingSummaryArray.put(packetTruncationMappingSummaryJsonObject);
                            }
                        } catch (JSONException e) {
                            log.error("Failed to generate the packet truncation map summary JSON. {}", e.getMessage());
                        }
                    });
                    try {
                        if (packetTruncationMappingSummaryArray.length() != 0) {
                            packetTruncationJsonObject.put("id", packetTruncationObj.getId());
                            packetTruncationJsonObject.put("profileName", packetTruncationObj.getName());
                            packetTruncationJsonObject.put("frameSize", packetTruncationObj.getFrameSize());
                            if (packetTruncationObj.isGlobal()) {
                                packetTruncationJsonObject.put("isGlobal", true);
                                packetTruncationJsonObject.put("policyName", packetTruncationObj.getGlobalPolicyName());
                                packetTruncationJsonObject.put("policySequenceNumber", packetTruncationObj.getGlobalPolicySequenceNumbers());
                                if (isTypePortChannel.get()) {
                                    packetTruncationJsonObject.put("globalPortId", interfaceName);
                                } else {
                                    String portName = interfaceName.get();
                                    if (portName != null && portName.matches("Ethernet \\d/\\d+")) {
                                        packetTruncationJsonObject.put("globalPortId", portName.substring(portName.indexOf("/") + 1).trim());
                                    } else {
                                        packetTruncationJsonObject.put("globalPortId", portName);
                                    }
                                }
                                packetTruncationJsonObject.put("globalPortType", isTypePortChannel.get() ? PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL : PacketTruncationMappingRequest.INTERFACE_TYPE.PORT);
                            } else {
                                packetTruncationJsonObject.put("isGlobal", false);
                            }
                            packetTruncationJsonObject.put("truncationProfileMapSummaries", packetTruncationMappingSummaryArray);
                            packetTruncationJsonObject.put("workflowStatus", packetTruncationObj.getWorkflowStatus() != null ? packetTruncationObj.getWorkflowStatus().name() : JSONObject.NULL);
                            packetTruncationArrray.put(packetTruncationJsonObject);
                        }
                    } catch (JSONException e) {
                        log.error("Failed to generate the packet truncation profile JSON. {}", e.getMessage());
                    }
                }
            });
        }
        return packetTruncationArrray.toString();
    }

    /**
     * Display the device packet truncation profiles
     *
     * @param id
     * @return
     */
    @Override
    public String getProfile(Long id) {
        List<PacketTruncationMapping> packetTruncationMappings = packetTruncationMappingRepository.findByDeviceId(id);
        JSONArray packetTruncationMappingArray = new JSONArray();
        if (!packetTruncationMappings.isEmpty()) {
            packetTruncationMappings.stream().forEach(packetTruncationObj -> {
                if (WorkflowParticipant.WorkflowStatus.ACTIVE == packetTruncationObj.getWorkflowStatus()) {
                    JSONObject packetTruncationMappingJsonObject = new JSONObject();
                    try {
                        PacketTruncation packetTruncation = packetTruncationObj.getPacketTruncation();
                        packetTruncationMappingJsonObject.put("id", packetTruncationObj.getId());
                        packetTruncationMappingJsonObject.put("profileName", packetTruncation != null ? packetTruncation.getName() : null);
                        packetTruncationMappingJsonObject.put("frameSize", packetTruncation != null ? packetTruncation.getFrameSize() : null);
                        Port port = packetTruncationObj.getPort();
                        PortGroup portGroup = packetTruncationObj.getPortGroup();
                        if (port != null) {
                            packetTruncationMappingJsonObject.put("interface", port.getName());
                        } else if (portGroup != null) {
                            packetTruncationMappingJsonObject.put("interface", portGroup.getName());
                        }
                        if (packetTruncationObj.getWorkflowStatus() != null) {
                            packetTruncationMappingJsonObject.put("workflowStatus", packetTruncationObj.getWorkflowStatus() != null ? packetTruncationObj.getWorkflowStatus().name() : JSONObject.NULL);
                        }
                        if (packetTruncation != null && packetTruncation.isGlobal()) {
                            packetTruncationMappingJsonObject.put("isGlobal", true);
                            packetTruncationMappingJsonObject.put("policyName", packetTruncation.getGlobalPolicyName());
                            packetTruncationMappingJsonObject.put("policySequenceNumber", packetTruncation.getGlobalPolicySequenceNumbers());
                            if (portGroup != null) {
                                packetTruncationMappingJsonObject.put("globalPortId", portGroup.getName());
                                packetTruncationMappingJsonObject.put("globalPortType", PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL);
                            } else if (port != null) {
                                String portName = port.getName();
                                if (portName != null && portName.matches("Ethernet \\d/\\d+")) {
                                    packetTruncationMappingJsonObject.put("globalPortId", portName.substring(portName.indexOf("/") + 1).trim());
                                } else {
                                    packetTruncationMappingJsonObject.put("globalPortId", portName);
                                }
                                packetTruncationMappingJsonObject.put("globalPortType", PacketTruncationMappingRequest.INTERFACE_TYPE.PORT);
                            }
                        } else {
                            packetTruncationMappingJsonObject.put("isGlobal", false);
                        }
                        packetTruncationMappingArray.put(packetTruncationMappingJsonObject);
                    } catch (JSONException e) {
                        log.error("Failed to generate the packet truncation map summary JSON. {}", e.getMessage());
                    }
                }
            });
        }
        return packetTruncationMappingArray.toString();
    }

    /**
     * Clean up the packet truncation profile and internal roolback ports
     *
     * @param id
     * @return
     */
    @Override
    public Long rollBack(Long id) {
        Long jobId = -1L;
        PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findOne(id);
        if (packetTruncationMapping != null) {
            if (packetTruncationMapping.getDevice() != null && !packetTruncationMapping.getDevice().isDeleted()) {
                jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_TRUNCATION_ROLLBACK).deviceId(packetTruncationMapping.getDevice().getId())
                        .parentObjectId(packetTruncationMapping.getId()).impactedObjectIds(Collections.emptyList()).build());
            }
        }
        return jobId;
    }

    /**
     * Add/remove the packet truncation profile on selected devices.
     *
     * @param packetTruncationResponses
     * @param packetTruncation
     * @param policyName
     * @param flowSequenceNumbers
     * @param isAdd
     * @return
     */
    private List updatePacketTruncationOnDevices(List<PacketTruncationResponse> packetTruncationResponses, PacketTruncation packetTruncation, String policyName, String flowSequenceNumbers, boolean isAdd) {
        List<Long> jobList = Lists.newArrayList();
        if (packetTruncation != null && !Strings.isNullOrEmpty(policyName) && flowSequenceNumbers != null) {
            packetTruncation.getPacketTruncationMappings().forEach(packetTruncationMapping -> {
                Device device = packetTruncationMapping.getDevice();
                if (device != null && !device.isDeleted() && device.isReconciled() && device.isProfileConfigured()) {
                    jobList.addAll(updatePacketTruncationOnDevicePolicy(packetTruncationResponses, packetTruncationMapping, policyName, flowSequenceNumbers, isAdd));
                }
            });
            if (!jobList.isEmpty()) {
                updateJobResult(jobList, packetTruncationResponses, false);
            }
        }
        return jobList;
    }

    /**
     * Add/remove the packet truncation profile on selected device.
     *
     * @param packetTruncationResponses
     * @param packetTruncationMapping
     * @param policyName
     * @param flowSequenceNumbers
     * @param isAdd
     * @return
     */
    private List updatePacketTruncationOnDevicePolicy(List<PacketTruncationResponse> packetTruncationResponses, PacketTruncationMapping packetTruncationMapping, String policyName, String flowSequenceNumbers, boolean isAdd) {
        List<Long> jobList = Lists.newArrayList();
        if (packetTruncationMapping != null && !Strings.isNullOrEmpty(policyName) && flowSequenceNumbers != null) {
            Device device = packetTruncationMapping.getDevice();
            List<Long> flowSequenceList = getIdListFromString(flowSequenceNumbers);
            Optional<PacketTruncationResponse> packetTruncationResponseOptional = packetTruncationResponses.stream().filter(packetTruncationResponse -> packetTruncationResponse.getDeviceId().equals(device.getId())).findAny();
            if (!isAdd || (packetTruncationResponseOptional.isPresent() && packetTruncationResponseOptional.get().isPtSuccessful())) {
                List<Policy> policies = policyRepository.findByNameAndDevice(policyName, device.getId());
                if (!policies.isEmpty() && !flowSequenceList.isEmpty()) {
                    policies.forEach(policy -> {
                        AtomicBoolean isUpdated = new AtomicBoolean(false);
                        policy.getFlows().forEach(flow -> {
                            if (flow.getSequence() != null && flowSequenceList.contains(flow.getSequence().longValue())) {
                                if (isAdd && packetTruncationMapping != null) {
                                    flow.setPacketTruncationMapping(packetTruncationMapping);
                                    isUpdated.set(true);
                                } else if (!isAdd && flow.getPacketTruncationMapping() != null) {
                                    flow.setPacketTruncationMapping(null);
                                    isUpdated.set(true);
                                }
                            }
                        });
                        if (isUpdated.get()) {
                            policyRepository.save(policy);
                            Long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.POLICY_UPDATE).deviceId(policy.getDevice().getId())
                                    .parentObjectId(policy.getId()).impactedObjectIds(Collections.emptyList()).build());
                            if (jobId != -1) {
                                jobList.add(jobId);
                            }
                        }
                    });
                }
            }
        }
        return jobList;
    }

    /**
     * Validate the packet truncation name
     *
     * @param name
     * @return
     */
    private boolean isValidPacketTruncationProfileName(String name) {
        if (name == null) {
            throw new ValidationException("packetTruncation.data.invalidName");
        }
        boolean isValidName = false;
        if (name != null && name.length() > 0 && name.matches("^[a-zA-Z0-9[_][-]]{1,32}$")) {
            isValidName = true;
            char first = name.charAt(0);
            if (Character.toString(first).equals("_") || Character.toString(first).equals("-")) {
                isValidName = false;
            }
        } else {
            isValidName = false;
        }
        return isValidName;
    }

    /**
     * Validate the Packet Truncation Profile request
     *
     * @param packetTruncationRequest
     */
    private void validatePacketTruncationProfile(PacketTruncationRequest packetTruncationRequest, boolean isUpdate) {
        if (!isValidPacketTruncationProfileName(packetTruncationRequest.getProfileName())) {
            throw new ValidationException("packetTruncation.data.invalidName");
        }
        if (!isValidPacketTruncationProfileFrameSize(packetTruncationRequest.getFrameSize())) {
            throw new ValidationException("packetTruncation.data.invalidFrameSize");
        }
        List<Long> packetTruncationInterfaceIds = Lists.newArrayList();
        Set<PacketTruncationMappingRequest> packetTruncationMappingRequests = packetTruncationRequest.getPacketTruncationMappingRequest();
        if (packetTruncationMappingRequests == null || packetTruncationMappingRequests.isEmpty()) {
            if (!isUpdate || (isUpdate && !packetTruncationRequest.isGlobal())) {
                throw new ValidationException("packetTruncationProfile.data.invalid");
            }
        }
        if (packetTruncationMappingRequests != null && !packetTruncationMappingRequests.isEmpty()) {
            String policyName = packetTruncationRequest.getPolicyName();
            String flowSequenceNumbers = packetTruncationRequest.getSequenceNumbers();
            List<Long> flowSequenceList = Lists.newArrayList();
            if (packetTruncationRequest.isGlobal()) {
                if (policyName == null || Strings.isNullOrEmpty(policyName.trim())) {
                    throw new ValidationException("Invalid policy name!");
                }
                if (flowSequenceNumbers == null || Strings.isNullOrEmpty(flowSequenceNumbers.trim())) {
                    throw new ValidationException("Invalid policy sequence number!");
                }
                flowSequenceList.addAll(getIdListFromString(flowSequenceNumbers));
                if (isUpdate) {
                    if (packetTruncationRequest.getId() == null) {
                        throw new ValidationException("Invalid Packet Truncation profile id!");
                    }
                    PacketTruncation packetTruncation = packetTruncationRepository.findOne(packetTruncationRequest.getId());
                    if (packetTruncation != null) {
                        if (!policyName.equals(packetTruncation.getGlobalPolicyName())) {
                            throw new ValidationException("Cannot change the name of the policy, as it is associated with an existing Packet Truncation profile.");
                        }
                        if (!flowSequenceNumbers.equals(packetTruncation.getGlobalPolicySequenceNumbers())) {
                            throw new ValidationException("Cannot change the sequence number of the policy, as it is associated with an existing Packet Truncation profile.");
                        }
                    }
                }
            }
            packetTruncationMappingRequests.forEach(packetTruncationMappingRequest -> {
                Long deviceId = packetTruncationMappingRequest.getDeviceId();
                if (deviceId == null || packetTruncationMappingRequest.getPortId() == null || packetTruncationMappingRequest.getType() == null) {
                    throw new ValidationException("Invalid port/port channel.");
                }
                Device device = deviceRepository.findById(deviceId);
                if (device == null || Device.Type.SLX != device.getType() || device.getOs() == null || device.isDeleted() || !device.isReconciled() || genericHelper.isSLXVersionValid(device.getOs(), slxPacketTrincationTacacsAuthorizationSupportedVersion) < 0) {
                    if (device == null) {
                        throw new ValidationException("Invalid device.");
                    } else {
                        throw new ValidationException(String.format("Invalid device %s.", device.getName()));
                    }
                }
                Port port = null;
                PortGroup portGroup = null;
                if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT == packetTruncationMappingRequest.getType()) {
                    if (packetTruncationRequest.isGlobal()) {
                        String portFormat = "Ethernet 0/%s";
                        port = portRepository.findPortByNameAndDeviceId(String.format(portFormat, packetTruncationMappingRequest.getPortId()), device.getId());
                    } else if (packetTruncationMappingRequest.getPortId().matches("\\d+")) {
                        port = portRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                    }
                    if (port == null || port.getType() == null || Port.Type.SERVICE_PORT != port.getType()) {
                        if (port == null) {
                            throw new ValidationException(String.format("Invalid port on %s.", device.getName()));
                        } else {
                            throw new ValidationException(String.format("Invalid port %s on %s.", port.getName(), device.getName()));
                        }
                    } else if (!portGroupRepository.findPortIdsByPortIds(Lists.newArrayList(port.getId())).isEmpty()) {
                        log.error("Participating port {} is in use by other port channel.", port.getId());
                        throw new ValidationException(String.format("Cannot perform this action as the port %s is used in a port channel on %s.", port.getName(), device.getName()));
                    }
                } else if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL == packetTruncationMappingRequest.getType()) {
                    if (packetTruncationRequest.isGlobal()) {
                        portGroup = portGroupRepository.findByNameAndDeviceId(String.valueOf(packetTruncationMappingRequest.getPortId()), deviceId);
                    } else if (packetTruncationMappingRequest.getPortId().matches("\\d+")) {
                        portGroup = portGroupRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                    }
                    if (portGroup == null || portGroup.getType() != Port.Type.SERVICE_PORT) {
                        if (portGroup == null) {
                            throw new ValidationException(String.format("Invalid port channel on %s.", device.getName()));
                        } else {
                            throw new ValidationException(String.format("Invalid port channel %s on %s.", portGroup.getName(), device.getName()));
                        }
                    }
                }
                if (port == null && portGroup == null) {
                    throw new ValidationException(String.format("Invalid port/port channel on %s.", device.getName()));
                } else {
                    Long interfaceId = port != null ? port.getId() : portGroup.getId();
                    String interfaceName = port != null ? port.getName() : portGroup.getName();
                    if (!isUpdate || packetTruncationMappingRequest.getId() == null) {
                        isInterfaceAssociated(device, interfaceId, interfaceName, port != null ? true : false);
                    } else if (isUpdate) {
                        PacketTruncationMapping oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMappingRequest.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
                        if (oldPacketTruncationMapping != null) {
                            Long oldInterfaceId = null;
                            if (oldPacketTruncationMapping.getPort() != null && oldPacketTruncationMapping.getPort().getId() != null) {
                                oldInterfaceId = oldPacketTruncationMapping.getPort().getId();
                            } else if (oldPacketTruncationMapping.getPortGroup() != null && oldPacketTruncationMapping.getPortGroup().getId() != null) {
                                oldInterfaceId = oldPacketTruncationMapping.getPortGroup().getId();
                            }
                            if ((oldInterfaceId != null && interfaceId != null) && !interfaceId.equals(oldInterfaceId) && !isPolicyAssociated(packetTruncationMappingRequest.getId())) {
                                isInterfaceAssociated(device, interfaceId, interfaceName, port != null ? true : false);
                            }
                        }
                    }
                    packetTruncationInterfaceIds.add(interfaceId);
                }
                if (packetTruncationRequest.isGlobal()) {
                    List<Policy> policies = policyRepository.findByNameAndDevice(policyName, device.getId());
                    if (!policies.isEmpty() && !flowSequenceList.isEmpty()) {
                        policies.forEach(policy -> {
                            if (WorkflowParticipant.WorkflowStatus.ACTIVE != policy.getWorkflowStatus()) {
                                throw new ValidationException(String.format("Cannot perform this action as the policy is not in active state on %s.", device.getName()));
                            }
                            flowSequenceList.forEach(sequence -> {
                                List<Flow> flows = flowRepository.findByPolicyIdAndFlowSequenceId(policy.getId(), sequence.intValue());
                                if (flows.isEmpty()) {
                                    throw new ValidationException(String.format("Invalid policy sequence number %s on %s.", sequence, device.getName()));
                                } else {
                                    if (!isUpdate && flows.stream().anyMatch(flow -> flow.getPacketTruncationMapping() != null)) {
                                        throw new ValidationException(String.format("Policy on %s is already associated with a Packet Truncation profile.", device.getName()));
                                    }
                                }
                            });
                        });
                    } else {
                        throw new ValidationException(String.format("Policy does not exist on %s.", device.getName()));
                    }
                }
                if (!isUpdate) {
                    //Check the truncation profile name found in evm database
                    List<PacketTruncationMapping> packetTruncationMapping = packetTruncationMappingRepository.findByProfileNameAndDeviceId(packetTruncationRequest.getProfileName(), deviceId);
                    if (packetTruncationMapping != null && !packetTruncationMapping.isEmpty()) {
                        throw new ValidationException("packetTruncation.data.found");
                    }
                }
            });
            if (!packetTruncationInterfaceIds.isEmpty()) {
                validateInterfacesWithGrid(packetTruncationInterfaceIds);
                validateInterfacesWithGridPolicySet(packetTruncationInterfaceIds);
            }
            //Max four profiles validation
            if (!isUpdate) {
                packetTruncationRequest.getPacketTruncationMappingRequest()
                        .stream().forEach(packetTruncationRequestObj -> {
                    isMaxFourProfiles(packetTruncationRequestObj);
                });
            }
        }
    }

    /**
     * Convert the string of numbers into list
     *
     * @param idString
     * @return
     */
    private List<Long> getIdListFromString(String idString) {
        List<Long> flowIds = Lists.newArrayList();
        if (!Strings.isNullOrEmpty(idString)) {
            idString.trim().split(",");
            flowIds = Arrays.stream(idString.trim().split(",")).filter(id -> id != null && !Strings.isNullOrEmpty(id.trim())).map(id -> Long.parseLong(id)).collect(Collectors.toList());
        }
        return flowIds;
    }

    /**
     * Validates the interfaces, is it used in grid policy set or not
     *
     * @param managedObjectIds
     */
    private void validateInterfacesWithGridPolicySet(List<Long> managedObjectIds) {
        if (!managedObjectIds.isEmpty() && (!gridTopologyPathRepository.findIntermediateIngressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findIntermediateEgressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findSourceIngressByManagedObjectId(managedObjectIds).isEmpty() ||
                !gridTopologyPathRepository.findDestinationEgressByManagedObjectId(managedObjectIds).isEmpty())) {
            throw new ValidationException("Cannot create/update Packet Truncation profile as the port(s)/port group(s) is used in a grid policy.");
        }

    }

    /**
     * Validates the interfaces, is it used in device grid or not
     *
     * @param managedObjectIds
     */
    private void validateInterfacesWithGrid(List<Long> managedObjectIds) {
        if (!managedObjectIds.isEmpty() && !gridClusterRepository.findInterfaceByManagedObjectId(managedObjectIds).isEmpty()) {
            throw new ValidationException("Cannot create/update Packet Truncation profile as the port(s)/port group(s) is used in a grid.");
        }
    }

    /**
     * Validate the packet truncation frame size
     *
     * @param frameSize
     * @return
     */
    private boolean isValidPacketTruncationProfileFrameSize(Long frameSize) {
        if (frameSize == null) {
            throw new ValidationException("packetTruncation.data.invalidFrameSize");
        }
        if ((frameSize >= PacketTruncationMapping.FRAME_SIZE_MIN && frameSize <= PacketTruncationMapping.FRAME_SIZE_MAX) && frameSize % PacketTruncationMapping.FRAME_SIZE_MULTIPLE == 0) {
            return true;
        }
        return false;
    }

    /**
     * validate the max four profile validation on the device.
     *
     * @param packetTruncationMappingRequest
     * @return
     */
    private boolean isMaxFourProfiles(PacketTruncationMappingRequest packetTruncationMappingRequest) {
        boolean isTruncationPrifileNameFound = false;
        if (packetTruncationMappingRequest != null) {
            List<PacketTruncationMapping> packetTruncationMappings = packetTruncationMappingRepository.findByDeviceId(packetTruncationMappingRequest.getDeviceId()).stream().filter(packetTruncationMapping -> WorkflowParticipant.WorkflowStatus.ACTIVE == packetTruncationMapping.getWorkflowStatus()).collect(Collectors.toList());
            Device device = deviceRepository.findById(packetTruncationMappingRequest.getDeviceId());
            if (device != null && packetTruncationMappings.size() == PacketTruncationMapping.MAX_FOUR) {
                throw new ValidationException(String.format("The maximum allowed number of truncation profiles has been exceeded for the %s", device.getName()));
            }
        }
        return isTruncationPrifileNameFound;
    }

    /**
     * Save the packet truncation profiles to evm database.
     *
     * @param packetTruncationRequest
     * @return
     */
    private PacketTruncation saveTruncationProfile(PacketTruncationRequest packetTruncationRequest) {
        Set<PacketTruncationMapping> packetTruncationMappings = new HashSet<>();
        packetTruncationRequest.getPacketTruncationMappingRequest().stream().forEach(truncationProfileMapObj -> {
            PacketTruncationMapping packetTruncationMapping = new PacketTruncationMapping();
            Device device = deviceRepository.findById(truncationProfileMapObj.getDeviceId());
            if (device != null) {
                packetTruncationMapping.setDevice(device);
            }
            if (truncationProfileMapObj.getPortId() != null) {
                Port port = null;
                PortGroup portGroup = null;
                if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT == truncationProfileMapObj.getType()) {
                    if (packetTruncationRequest.isGlobal()) {
                        String portFormat = "Ethernet 0/%s";
                        port = portRepository.findPortByNameAndDeviceId(String.format(portFormat, truncationProfileMapObj.getPortId()), device.getId());
                    } else {
                        port = portRepository.findOne(Long.parseLong(truncationProfileMapObj.getPortId()));
                    }
                    if (port != null) {
                        packetTruncationMapping.setPort(port);
                    }
                } else if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL == truncationProfileMapObj.getType()) {
                    if (packetTruncationRequest.isGlobal()) {
                        portGroup = portGroupRepository.findByNameAndDeviceId(String.valueOf(truncationProfileMapObj.getPortId()), device.getId());
                    } else {
                        portGroup = portGroupRepository.findOne(Long.parseLong(truncationProfileMapObj.getPortId()));
                    }
                    if (portGroup != null) {
                        packetTruncationMapping.setPortGroup(portGroup);
                    }
                }
                if (port != null || portGroup != null) {
                    packetTruncationMapping.setName(packetTruncationRequest.getProfileName());
                    packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    packetTruncationMappings.add(packetTruncationMapping);
                }
            }
        });
        PacketTruncation packetTruncation = new PacketTruncation();
        if (packetTruncationRequest.isGlobal() && packetTruncationRequest.getPolicyName() != null && packetTruncationRequest.getSequenceNumbers() != null) {
            packetTruncation.setGlobal(true);
            packetTruncation.setGlobalPolicyName(packetTruncationRequest.getPolicyName());
            packetTruncation.setGlobalPolicySequenceNumbers(packetTruncationRequest.getSequenceNumbers());
        }
        packetTruncation.setName(packetTruncationRequest.getProfileName());
        packetTruncation.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetTruncation.setFrameSize(packetTruncationRequest.getFrameSize());
        packetTruncation.setPacketTruncationMappings(packetTruncationMappings);
        packetTruncation = packetTruncationRepository.save(packetTruncation);
        return packetTruncation;
    }

    /**
     * update and create the packet truncation profiles in evm database
     *
     * @param packetTruncationRequest
     * @return
     */
    private Set<PacketTruncationMapping> updatePacketTruncationProfile(PacketTruncation packetTruncation, PacketTruncationRequest packetTruncationRequest, List<PacketTruncationResponse> packetTruncationResponses) {
        if (packetTruncation != null) {
            String profileName = packetTruncation.getName();
            if (profileName != null && !profileName.equals(packetTruncationRequest.getProfileName())) {
                throw new ValidationException("Packet truncation profile name cannot be changed.");
            }
            /*Add the deleted objects to collection by using request then save to evm data base.*/
            Set<PacketTruncationMapping> packetTruncationMappingToDelete = packetTruncation.getPacketTruncationMappings().stream().
                    filter(packetTruncationMapping -> packetTruncationRequest.getPacketTruncationMappingRequest().stream().noneMatch(packetTruncationMappingRequest -> packetTruncationMappingRequest.getId() != null && packetTruncationMappingRequest.getId().equals(packetTruncationMapping.getId())))
                    .collect(Collectors.toSet());
            Set<PacketTruncationMapping> packetTruncationMappings = new HashSet<>();
            packetTruncationRequest.getPacketTruncationMappingRequest().stream().forEach(packetTruncationMappingRequest -> {
                PacketTruncationMapping packetTruncationMapping = null;
                Device device = deviceRepository.findById(packetTruncationMappingRequest.getDeviceId());
                if (packetTruncationMappingRequest.getId() != null) {
                    /*Retrieve the existing entities from evm database and assign to packetTruncationMapping entity then add to collection*/
                    packetTruncationMapping = packetTruncationMappingRepository.findOne(packetTruncationMappingRequest.getId());
                    if (packetTruncationMapping != null) {
                        Long interfaceId = null;
                        if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT == packetTruncationMappingRequest.getType() && packetTruncationMappingRequest.getPortId() != null) {
                            Port port;
                            if (packetTruncationRequest.isGlobal()) {
                                String portFormat = "Ethernet 0/%s";
                                port = portRepository.findPortByNameAndDeviceId(String.format(portFormat, packetTruncationMappingRequest.getPortId()), device.getId());
                            } else {
                                port = portRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                            }
                            if (port != null) {
                                packetTruncationMapping.setPort(port);
                                packetTruncationMapping.setPortGroup(null);
                                interfaceId = port.getId();
                            }
                        } else if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL == packetTruncationMappingRequest.getType() && packetTruncationMappingRequest.getPortId() != null) {
                            PortGroup portGroup;
                            if (packetTruncationRequest.isGlobal()) {
                                portGroup = portGroupRepository.findByNameAndDeviceId(String.valueOf(packetTruncationMappingRequest.getPortId()), device.getId());
                            } else {
                                portGroup = portGroupRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                            }
                            if (portGroup != null) {
                                packetTruncationMapping.setPortGroup(portGroup);
                                packetTruncationMapping.setPort(null);
                                interfaceId = portGroup.getId();
                            }
                        }
                        if (interfaceId != null && isSetPacketTruncationMappingEntity(packetTruncationMappingRequest, packetTruncationRequest.getFrameSize(), interfaceId)) {
                            packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                        }
                    }
                } else if (packetTruncationMappingRequest.getPortId() != null) {
                    //Max four profiles validation
                    isMaxFourProfiles(packetTruncationMappingRequest);
                    /*Add the new entities from the request to collection*/
                    packetTruncationMapping = new PacketTruncationMapping();
                    packetTruncationMapping.setName(profileName);
                    packetTruncationMapping.setDevice(device);
                    if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT == packetTruncationMappingRequest.getType()) {
                        Port port;
                        if (packetTruncationRequest.isGlobal()) {
                            String portFormat = "Ethernet 0/%s";
                            port = portRepository.findPortByNameAndDeviceId(String.format(portFormat, packetTruncationMappingRequest.getPortId()), device.getId());
                        } else {
                            port = portRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                        }
                        if (port != null) {
                            packetTruncationMapping.setPort(port);
                            packetTruncationMapping.setPortGroup(null);
                        }
                    } else if (PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL == packetTruncationMappingRequest.getType()) {
                        PortGroup portGroup;
                        if (packetTruncationRequest.isGlobal()) {
                            portGroup = portGroupRepository.findByNameAndDeviceId(String.valueOf(packetTruncationMappingRequest.getPortId()), device.getId());
                        } else {
                            portGroup = portGroupRepository.findOne(Long.parseLong(packetTruncationMappingRequest.getPortId()));
                        }
                        if (portGroup != null) {
                            packetTruncationMapping.setPortGroup(portGroup);
                            packetTruncationMapping.setPort(null);
                        }
                    }
                    packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                }
                /* packetTruncationMappings contains create and update entities*/
                if (packetTruncationMapping != null) {
                    packetTruncationMappings.add(packetTruncationMapping);
                }
            });
            /*Save the deleted objects if WorkflowStatus is ACTIVE or ERROR to db once job is success then delete these objects from DB, If WorkflowStatus is DRAFT then delete from db,  */
            packetTruncationMappingToDelete.stream().forEach(packetTruncationMapping -> {
                if (packetTruncationMapping.getId() != null) {
                    if (packetTruncationMapping.getWorkflowStatus() != null && packetTruncationMapping.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.DRAFT) {
                        Device device = packetTruncationMapping.getDevice();
                        PacketTruncationResponse packetTruncationResponse = getProfileResponse(packetTruncationResponses, device.getId(), device.getName());
                        packetTruncationResponse.setPtSuccessful(true);
                        managedObjectRepository.delete(packetTruncationMapping);
                    } else {
                        packetTruncationMapping = packetTruncationMappingRepository.findOne(packetTruncationMapping.getId());
                        /* Add deleted(WorkflowStatus is ACTIVE or ERROR)  entities to collection*/
                        packetTruncationMappings.add(packetTruncationMapping);
                    }
                }
            });
            /*Save the frame size*/
            if (packetTruncationRequest.getFrameSize() != null) {
                packetTruncation.setFrameSize(packetTruncationRequest.getFrameSize());
            }
            /*save the create and update entities from collection*/
            packetTruncation.setPacketTruncationMappings(packetTruncationMappings);
            packetTruncation = packetTruncationRepository.save(packetTruncation);
        } else {
            throw new ValidationException("Packet truncation profile does not exists.");
        }
        return packetTruncation.getPacketTruncationMappings();
    }

    private String findTheJobType(PacketTruncationMapping packetTruncationMapping, PacketTruncationRequest packetTruncationRequest) {
        //Assign the type of job and send to executor service.
        String type = null;
        PacketTruncationMapping oldPacketTruncationMapping = null;
        boolean isUpdate = packetTruncationRequest.getPacketTruncationMappingRequest().stream().map(PacketTruncationMappingRequest::getId).anyMatch(packetTruncationMapping.getId()::equals);
        if (isUpdate) {
            //After clean up fresh commit to job executor
            oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMapping.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            if (oldPacketTruncationMapping != null && WorkflowParticipant.WorkflowStatus.ACTIVE == oldPacketTruncationMapping.getWorkflowStatus()) {
                type = UPDATE_PROFILE;
            } else if (WorkflowParticipant.WorkflowStatus.ERROR == oldPacketTruncationMapping.getWorkflowStatus()) {
                oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMapping.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.DRAFT));
                if (oldPacketTruncationMapping != null && WorkflowParticipant.WorkflowStatus.DRAFT == packetTruncationMapping.getWorkflowStatus())
                    type = CREATE_PROFILE;
            }
        } else {
            oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMapping.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
            if (oldPacketTruncationMapping != null && WorkflowParticipant.WorkflowStatus.ACTIVE == oldPacketTruncationMapping.getWorkflowStatus()) {
                type = DELETE_PROFILE;
            } else {
                type = CREATE_PROFILE;
            }
        }
        return type;
    }

    /**
     * This method validate the framesize and interface is editable or not, If it is editable then send to job executor else not
     *
     * @param packetTruncationMapping
     * @return
     */
    private boolean isUpdatePacketTruncationProfileInDevice(PacketTruncationMapping packetTruncationMapping) {
        boolean isUpdatePacketTruncationProfileInDevice = false;
        PacketTruncationMapping oldPacketTruncationMapping = null;
        oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMapping.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
        if (oldPacketTruncationMapping != null) {
            Long oldInterfaceChannel = null;
            Long interfaceChannel = null;
            if (packetTruncationMapping.getPacketTruncation() != null && oldPacketTruncationMapping.getPacketTruncation() != null && !packetTruncationMapping.getPacketTruncation().getFrameSize().equals(oldPacketTruncationMapping.getPacketTruncation().getFrameSize())) {
                isUpdatePacketTruncationProfileInDevice = true;
            }
            if (oldPacketTruncationMapping.getPort() != null && oldPacketTruncationMapping.getPort().getId() != null) {
                oldInterfaceChannel = oldPacketTruncationMapping.getPort().getId();
            } else if (oldPacketTruncationMapping.getPortGroup() != null && oldPacketTruncationMapping.getPortGroup().getId() != null) {
                oldInterfaceChannel = oldPacketTruncationMapping.getPortGroup().getId();
            }
            if (packetTruncationMapping.getPort() != null && packetTruncationMapping.getPort().getId() != null) {
                interfaceChannel = packetTruncationMapping.getPort().getId();
            } else if (packetTruncationMapping.getPortGroup() != null && packetTruncationMapping.getPortGroup().getId() != null) {
                interfaceChannel = packetTruncationMapping.getPortGroup().getId();
            }
            if (oldInterfaceChannel != null && interfaceChannel != null && !interfaceChannel.equals(oldInterfaceChannel)) {
                isUpdatePacketTruncationProfileInDevice = true;
            }
        }
        return isUpdatePacketTruncationProfileInDevice;
    }

    private boolean isSetPacketTruncationMappingEntity(PacketTruncationMappingRequest packetTruncationMappingRequest, Long frameSize, Long interfaceChannel) {
        boolean isSetPacketTruncationMappingEntity = false;
        PacketTruncationMapping oldPacketTruncationMapping = null;
        oldPacketTruncationMapping = getOldPacketTruncationMapping(packetTruncationMappingRequest.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE, WorkflowParticipant.WorkflowStatus.ERROR));
        if (oldPacketTruncationMapping != null) {
            Long oldInterfaceChannel = null;
            if (oldPacketTruncationMapping.getPacketTruncation() != null && !frameSize.equals(oldPacketTruncationMapping.getPacketTruncation().getFrameSize())) {
                isSetPacketTruncationMappingEntity = true;
            }
            if (oldPacketTruncationMapping.getPort() != null && oldPacketTruncationMapping.getPort().getId() != null) {
                oldInterfaceChannel = oldPacketTruncationMapping.getPort().getId();
            } else if (oldPacketTruncationMapping.getPortGroup() != null && oldPacketTruncationMapping.getPortGroup().getId() != null) {
                oldInterfaceChannel = oldPacketTruncationMapping.getPortGroup().getId();
            }
            if ((oldInterfaceChannel != null && interfaceChannel != null) && !interfaceChannel.equals(oldInterfaceChannel) && !isPolicyAssociated(packetTruncationMappingRequest.getId())) {
                isSetPacketTruncationMappingEntity = true;
            }
        }
        log.debug("isSetPacketTruncationMappingEntity :" + isSetPacketTruncationMappingEntity);
        return isSetPacketTruncationMappingEntity;
    }

    /**
     * Check  the PacketTruncation is asscociated to  Policy
     *
     * @param id
     * @return
     */
    private Boolean isPolicyAssociated(Long id) {
        Boolean isPolicyAssociated = false;
        Set<BigInteger> policyIds = flowRepository.findByPacketTruncationMappingId(id);
        if (!policyIds.isEmpty()) {
            isPolicyAssociated = true;
        }
        return isPolicyAssociated;
    }

    /**
     * Check the port or port group is already associated to any truncation profile or policy.
     *
     * @param device
     * @param interfaceId
     * @param interfaceName
     * @param isTypePort
     * @return
     */
    private void isInterfaceAssociated(Device device, Long interfaceId, String interfaceName, boolean isTypePort) {
        if (device != null && interfaceId != null) {
            if (!flowRepository.findPolicyIdsInIngressPortMapping(Lists.newArrayList(interfaceId)).isEmpty()
                    || !flowRepository.findPolicyIdsInEgressPortMapping(Lists.newArrayList(interfaceId)).isEmpty()) {
                if (isTypePort) {
                    throw new ValidationException(String.format("Cannot commit Packet Truncation profile as the port %s is used in a policy on %s.", interfaceName, device.getName()));
                } else {
                    throw new ValidationException(String.format("Cannot commit Packet Truncation profile as the port channel %s is used in a policy on %s.", interfaceName, device.getName()));
                }
            }
            PacketTruncationMapping packetTruncationMapping = packetTruncationMappingRepository.findByDeviceIdAndInterface(device.getId(), interfaceId);
            if (packetTruncationMapping != null) {
                if (packetTruncationMapping.getName() != null && packetTruncationMapping.getDevice() != null) {
                    throw new ValidationException(String.format("Port/Port Channel is already configured on another truncation profile %s on %s.", packetTruncationMapping.getName(), packetTruncationMapping.getDevice().getName()));
                } else {
                    throw new ValidationException("Port/Port Channel is already configured on another truncation profile.");
                }
            }
        }
    }

    /**
     * Retrive the old active PacketTruncationMapping entity  from history.
     *
     * @param id
     * @return
     */
    protected PacketTruncationMapping getOldPacketTruncationMapping(Long id, List statusses) {
        PacketTruncationMapping oldPacketTruncationMapping = null;
        List<PacketTruncationMappingHistory> packetTruncationMappingHistories = packetTruncationMappingHistoryRepository.findByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(id, statusses);
        if (!packetTruncationMappingHistories.isEmpty()) {
            PacketTruncationMappingHistory packetTruncationMappingHistory = packetTruncationMappingHistories.get(0);
            oldPacketTruncationMapping = packetTruncationMappingHistory.buildParent();
        }
        return oldPacketTruncationMapping;
    }
}
