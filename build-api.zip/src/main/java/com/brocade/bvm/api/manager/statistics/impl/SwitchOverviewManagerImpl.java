package com.brocade.bvm.api.manager.statistics.impl;

import com.brocade.bvm.api.manager.statistics.SwitchOverviewManager;
import com.brocade.bvm.dao.EventRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsSwitchRepository;
import com.brocade.bvm.dao.statistics.cache.TapPortCache;
import com.brocade.bvm.dao.statistics.cache.ToolPortCache;
import com.brocade.bvm.model.db.Event;
import com.brocade.bvm.model.db.statistics.EVMOverview;
import com.brocade.bvm.model.db.statistics.PortBandwidth;
import com.brocade.bvm.model.db.statistics.PortPackets;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CompletableFuture;

@Named
@Slf4j
public class SwitchOverviewManagerImpl implements SwitchOverviewManager {

    @Inject private StatisticsSwitchRepository statisticsSwitchViewRepository;
    @Inject private StatisticsPortRepository statisticsPortRepository;
    @Inject private TapPortCache tapPortCache;
    @Inject private ToolPortCache toolPortCache;
    @Inject private PortRepository portRepository;
    @Inject private StatisticsPolicyRepository statisticsPolicyRepository;
    @Inject private EventRepository eventRepository;

    @Value("${evm.app.version}")
    private String evmApiVersion;

    @Value("${tacacs.server.ip.address}")
    private String tacacsServerIp;

  @Override
  public CompletableFuture<List<String>> findTopFiveSwitches() {
    List<String> devices = new ArrayList<>();
    statisticsSwitchViewRepository.getTopFiveSwitches().stream()
        .forEach(switchUtilization -> devices.add(switchUtilization.getDevice().getName()));
    return CompletableFuture.completedFuture(devices);
  }

  @Override
  public CompletableFuture<List<String>> findBottomFiveSwitches() {
    List<String> devices = new ArrayList<>();
    statisticsSwitchViewRepository.getBottomFiveSwitches().stream()
        .forEach(switchUtilization -> devices.add(switchUtilization.getDevice().getName()));
    return CompletableFuture.completedFuture(devices);
  }

  @Override
  public Set<String> findTopFiveTapPorts() {
    Set<String> ports = new TreeSet<>();
    tapPortCache
        .getTopFiveTapPorts()
        .forEach(portUtilization -> ports.add(portUtilization.getPort()));
    return ports;
  }

  @Override
  public Set<String> findBottomFiveTapPorts() {
    Set<String> ports = new TreeSet<>();
    tapPortCache.getBottomFiveTapPorts().stream()
        .forEach(portUtilization -> ports.add(portUtilization.getPort()));
    return ports;
  }

  @Override
  public Set<String> findTopFiveToolPorts() {
    Set<String> ports = new TreeSet<>();
    toolPortCache.getTopFiveToolPorts().stream()
        .forEach(portUtilization -> ports.add(portUtilization.getPort()));
    return ports;
  }

  @Override
  public Set<String> findBottomFiveToolPorts() {
    Set<String> ports = new TreeSet<>();
    toolPortCache.getBottomFiveToolPorts().stream()
        .forEach(portUtilization -> ports.add(portUtilization.getPort()));
    return ports;
  }

  @Override
  public List<PortPackets> findSwitchPackets(Long switchId, int samples) {
    return statisticsSwitchViewRepository.findDevicePortPacketsInformation(switchId, samples);
  }

  @Override
  public List<PortBandwidth> findDeviceUtilization(Long deviceId, int samples) {
    return statisticsSwitchViewRepository.findDeviceUtilization(deviceId, samples);
  }

  /**
   * Display the device packet truncation profiles
   *
   * @return
   */
  @Override
  public String getAuditDetails() {
      JSONArray auditJsonArray = new JSONArray();
      try {
          EVMOverview evmOverview1 = statisticsPortRepository.evmOverview();
          JSONObject devicesMonitored = new JSONObject();
          devicesMonitored.put("label", "Number of Devices monitored");
          devicesMonitored.put("value", String.valueOf(statisticsSwitchViewRepository.findCountOfAllSLXDevices() + statisticsSwitchViewRepository.findCountOfAllMLXEDevices()));
          JSONObject gridsMonitored = new JSONObject();
          gridsMonitored.put("label", "Number of Grids monitored");
          gridsMonitored.put("value", String.valueOf(evmOverview1.getTotalNoOfGrids()));
          JSONObject slxDevices = new JSONObject();
          slxDevices.put("label", "Number of SLX devices");
          slxDevices.put("value", String.valueOf(statisticsSwitchViewRepository.findCountOfAllSLXDevices()));
          JSONObject mlxDevices = new JSONObject();
          mlxDevices.put("label", "Number of MLX devices");
          mlxDevices.put("value", String.valueOf(statisticsSwitchViewRepository.findCountOfAllMLXEDevices()));
          JSONObject policiesMonitored = new JSONObject();
          policiesMonitored.put("label", "Number of policies monitored");
          policiesMonitored.put("value", String.valueOf(statisticsPolicyRepository.operationalSwitchesPoliciesCount()));
          JSONObject alerts = new JSONObject();
          alerts.put("label", "Number of Alerts(unread)");
          alerts.put("value", String.valueOf(eventRepository.findTop500ByStatusInOrderByLastUpdatedTimeDesc(Lists.newArrayList(Event.Status.NEW)).size()));
          if(!Strings.isNullOrEmpty(tacacsServerIp)){
              JSONObject tacacsIp = new JSONObject();
              tacacsIp.put("label", "TACACS server configured(IP add)");
              tacacsIp.put("value",  tacacsServerIp);
              auditJsonArray.put(tacacsIp);
          }
          auditJsonArray.put(devicesMonitored);
          auditJsonArray.put(gridsMonitored);
          auditJsonArray.put(slxDevices);
          auditJsonArray.put(mlxDevices);
          auditJsonArray.put(policiesMonitored);
          auditJsonArray.put(alerts);
      } catch (JSONException e) {
          log.error("Failed to generate the get audit details JSON. {}", e.getMessage());
      }
      return auditJsonArray.toString();
  }

}
