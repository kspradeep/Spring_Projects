package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class PacketTruncationRequest {

    private Long id;

    private String profileName;

    private Long frameSize;

    private String policyName;

    @JsonProperty("sequenceNo")
    private String sequenceNumbers;

    @JsonProperty("isGlobal")
    private boolean isGlobal;

    private Set<PacketTruncationMappingRequest> packetTruncationMappingRequest;

}
