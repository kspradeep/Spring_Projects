package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class ACLResponse {

    @JsonProperty
    private String seqNum;

    @JsonProperty
    private String hitCount;

    @JsonProperty
    private String byteCount;
}
