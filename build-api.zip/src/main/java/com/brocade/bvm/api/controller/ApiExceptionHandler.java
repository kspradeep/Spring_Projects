package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.job.JobSubmissionException;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.exception.OutboundConnectionException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.orm.hibernate4.HibernateJdbcException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({ValidationException.class, javax.validation.ValidationException.class, ConstraintViolationException.class})
    public ResponseEntity<Map<String, String>> handleValidationFailures(RuntimeException e, HttpServletRequest request) {
        Map<String, String> map = new HashMap<>();
        if (e instanceof ValidationException) {
            map.put("messageId", ((ValidationException) e).getMessageId());
        } else {
            map.put("messageId", "validation.error");
        }
        return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Object> handleAuthorityFailures(RuntimeException e, HttpServletRequest request) {
        Map<String, String> map = new HashMap<>();
        if (e instanceof ForbiddenException) {
            map.put("messageId", ((ForbiddenException) e).getMessageId());
        } else {
            map.put("messageId", "validation.error");
        }
        return new ResponseEntity<>(map, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(JobSubmissionException.class)
    public ResponseEntity<Object> handleJobSubmissionFailures(RuntimeException e, HttpServletRequest request) {
        Map<String, String> map = new HashMap<>();
        if (e instanceof JobSubmissionException) {
            map.put("messageId", ((JobSubmissionException) e).getMessageId());
        } else {
            map.put("messageId", "validation.error");
        }
        return new ResponseEntity<>(map, HttpStatus.TOO_MANY_REQUESTS);
    }

    @ExceptionHandler({OutboundConnectionException.class, HibernateJdbcException.class})
    public ResponseEntity<Object> handleConnectionFailures(RuntimeException e, HttpServletRequest request) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(ServerException.class)
    public ResponseEntity<Object> handleServerFailures(RuntimeException e, HttpServletRequest request) {
        return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Object> handleAbortedConnection(final IOException e)
    {
        // avoids compile/runtime dependency by using class name
        if (e.getClass().getName().equals("org.apache.catalina.connector.ClientAbortException"))
        {
            return new ResponseEntity<>("Extreme Visibility Manager is unable to authenticate " +
                    "as StableNet service is not up/running." +
                    " Please check the status of StableNet service.", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}