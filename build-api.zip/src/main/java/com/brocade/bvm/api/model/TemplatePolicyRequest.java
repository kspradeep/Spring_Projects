package com.brocade.bvm.api.model;

import com.brocade.bvm.model.db.FlexMatchProfile;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TemplatePolicyRequest {

    private String deviceType;

    private String deviceMode;

    private String deviceModel;

    private FlexMatchProfile slxFlexMatchProfile;
}
