package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.dao.PacketStampingModulePolicyRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.PacketStampingModulePolicy.ProcessorNumber;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * The PacketStampingModulePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover PacketStampingModulePolicy for NonOpenFlow
 */
@Named
@Slf4j
public class PacketStampingModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PacketStampingModulePolicyRepository packetStampingModulePolicyRepository;

    /**
     * This method is used to create PacketStampingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicyRequest) {
        PacketStampingModulePolicy packetStampingModulePolicy = modulePolicyRequest.getPacketStampingModulePolicy();
        isValidPolicy(packetStampingModulePolicy, deviceId);

        List<Long> moduleIds = packetStampingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        Device device = deviceRepository.findOne(packetStampingModulePolicy.getDevice().getId());
        if (device != null && device.getType() != Device.Type.MLXE) {
            throw new ValidationException("policy.action.invalid");
        }

        // 1. Check if modulePolicy already present on same module and processor.
        if (!moduleIds.isEmpty()) {
            ProcessorNumber processorNumber = packetStampingModulePolicy.getProcessor();
            moduleIds.forEach(moduleId -> {
                List<String> processors = Lists.newArrayList();
                if (ProcessorNumber.ALL == processorNumber) {
                    processors.add(ProcessorNumber.ONE.name());
                    processors.add(ProcessorNumber.TWO.name());
                } else {
                    processors.add(processorNumber.name());
                }
                List<Long> dbModuleIds = packetStampingModulePolicyRepository.findModulesPolicyByModuleIdAndProcessorNumber(moduleId, processors);
                if (!dbModuleIds.isEmpty()) {
                    log.error("Already a Packet Stamping Module Policy applied for the selected processor(s).");
                    throw new ValidationException("policy.exists.with.same.processor");
                }
            });
        }

        isValidPolicyToCommit(packetStampingModulePolicy, moduleIds, modules);
        packetStampingModulePolicy.setModules(Sets.newHashSet(modules));
        packetStampingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetStampingModulePolicy = modulePolicyRepository.save(packetStampingModulePolicy);
        Job.Type jobType = Job.Type.PACKET_STAMPING_MODULE_POLICY_CREATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(packetStampingModulePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to delete PacketStampingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        ModulePolicy modulePolicy = modulePolicyRepository.findOne(modulePolicyId);
        // Validate
        // 1. ModulePolicy present in DB
        if (modulePolicy == null) {
            throw new ValidationException("packetstamping.id.invalid");
        }
        isValidPolicy(modulePolicy, deviceId);
        // 2. ModulePolicy not in active state.
        if (modulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            throw new ValidationException("packetstamping.delete.policyApplied");
        }
        Job.Type jobType = Job.Type.PACKET_STAMPING_MODULE_POLICY_DELETE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to update PacketStampingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicyFromRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicyFromRequest) {

        PacketStampingModulePolicy modulePolicy = modulePolicyFromRequest.getPacketStampingModulePolicy();
        isValidPolicy(modulePolicy, deviceId);
        PacketStampingModulePolicy oldModulePolicy = (PacketStampingModulePolicy) modulePolicyRepository
                .findById(modulePolicyId);

        Device device = deviceRepository.findOne(modulePolicy.getDevice().getId());
        if (device != null && device.getType() != Device.Type.MLXE) {
            throw new ValidationException("policy.action.invalid");
        }

        // If no PacketStampingModulePolicy is available with id
        if (oldModulePolicy == null) {
            throw new ValidationException("packetstamping.id.invalid");
        }
        // If PacketStampingModulePolicy is not in committed status or in error state, do not allow
        // modify
        if (oldModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ACTIVE
                || oldModulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("packetstamping.edit.failed");
        }
        List<Long> moduleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        isValidPolicyToCommit(modulePolicy, moduleIds, modules);
        isPolicyUnChanged(oldModulePolicy, modulePolicy);

        // merging data
        oldModulePolicy.setProcessor(modulePolicy.getProcessor());
        oldModulePolicy.setModules(Sets.newHashSet(modules));
        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(oldModulePolicy);

        Job.Type jobType = Job.Type.PACKET_STAMPING_MODULE_POLICY_UPDATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover PacketStampingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        PacketStampingModulePolicy packetStampingModulePolicy = (PacketStampingModulePolicy) modulePolicyRepository.findOne(modulePolicyId);
        if (packetStampingModulePolicy == null) {
            throw new ValidationException("packetstamping.id.invalid");
        }
        isValidPolicy(packetStampingModulePolicy, deviceId);
        if (packetStampingModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("packetstamping.recovery.notInError");
        }
        List<Long> moduleIds = packetStampingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        packetStampingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(packetStampingModulePolicy);

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_STAMPING_MODULE_POLICY_ROLLBACK)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * Validating the Packet Stamping Policy
     *
     * @param policy
     * @param deviceId
     * @return
     */
    protected boolean isValidPolicy(ModulePolicy policy, Long deviceId) {
        if (policy != null) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("packetSlicingPolicy.not.supported.device");
            }
        }
        return true;
    }

    /**
     * This method checks if PacketStampingModulePolicy data is valid to commit on the given device
     *
     * @param packetStampingModulePolicy
     * @param moduleIds
     * @param modules
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(PacketStampingModulePolicy packetStampingModulePolicy, List<Long> moduleIds, List<Module> modules) {

        // #1 Check if the modules selected are valid modules
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("packetstamping.edit.failed");
        }

        // #2 Check if the process number is valid
        ProcessorNumber processorNumber = packetStampingModulePolicy.getProcessor();
        List<ProcessorNumber> processorNumberList = Arrays.asList(ProcessorNumber.ONE, ProcessorNumber.TWO, ProcessorNumber.ALL);
        if (!processorNumberList.contains(processorNumber)) {
            log.error("Invalid Process Number. Aborting!");
            throw new ValidationException("packetstamping.processNumber.invalid");
        }
        return true;
    }

    /**
     * This method checks if PacketStampingModulePolicy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(PacketStampingModulePolicy oldModulePolicy, PacketStampingModulePolicy newModulePolicy) {
        if (oldModulePolicy.getProcessor() != null ? !oldModulePolicy.getProcessor().equals(newModulePolicy.getProcessor()) : newModulePolicy.getProcessor() != null)
            return false;
        Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        Set<Long> newModuleIds = newModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        if (!oldModuleIds.containsAll(newModuleIds)) {
            return false;
        }
        return true;
    }

}
