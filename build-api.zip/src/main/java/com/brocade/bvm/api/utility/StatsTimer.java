package com.brocade.bvm.api.utility;

import com.brocade.bvm.api.manager.sessiondirector.SdRestManager;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.sessiondirector.SdStatsRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.SdStats;
import com.brocade.bvm.model.db.sessiondirector.Stats;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.time.Instant;
import java.util.*;

@Named
@Slf4j
public class StatsTimer {

    @Inject
    private SdStatsRepository sdStatsRepository;
    private Timer timer;
    private Device device;

    @Value("${stats.timer.interval.minute:5}")
    private long TIMER_INTERVAL_IN_MINUTES;

    @Value(("${stats.timer.clearInterval.hour:1}"))
    private long CLEAR_INTERVAL_IN_HOUR;

    private static final String TOTAL_NO_OF_PKTS = "Total No Of Packets";

    @Inject
    private SdRestManager sdRestManager;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * This class is used to perform stats collection action
     */
    class StatsTask extends TimerTask {
        @Override
        public void run() {
            log.info("Timer task trigerred");
            List<SdStats> packetStats = new ArrayList<>();
            Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.PKT_STATS_ALL.getValue());
            Long reportTime = System.currentTimeMillis();
            if (res != null && res.getStatus() == HttpStatus.SC_OK) {
                try {
                    JSONObject responseJson = sdRestManager.getJsonFromResponse(res);
                    JSONArray jsonArray = (JSONArray) (responseJson.has(Stats.Response.PKT_STATS_ALL.getValue()) ? responseJson.get(Stats.Response.PKT_STATS_ALL.getValue()) : new JSONArray());
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject statsObj = jsonArray.getJSONObject(i);
                        Iterator<String> keysItr = statsObj.keys();
                        while (keysItr.hasNext()) {
                            String key = keysItr.next();
                            if (statsObj.has(key)) {
                                JSONArray statsDataArray = (JSONArray) statsObj.get(key);
                                for (int j = 0; j < statsDataArray.length(); j++) {
                                    JSONObject obj = statsDataArray.getJSONObject(j);
                                    if (obj.has(TOTAL_NO_OF_PKTS)) {
                                        SdStats stats = new SdStats();
                                        stats.setDevice(device);
                                        stats.setName(key);
                                        stats.setReportTime(Instant.ofEpochMilli(reportTime));
                                        stats.setStatsData(obj.toString());
                                        packetStats.add(stats);
                                    }
                                }
                            }
                        }
                    }

                } catch (JSONException e) {
                    log.error("Exception while fetching PACKET_STATS_ALL {}", e.getMessage());
                }
            }
            sdStatsRepository.save(packetStats);
            updateUserCountStats(reportTime);

            clearLastOneHourStatsData();

            log.info("End of Timer task");
        }

    }

    /**
     * This method is used to get USER_COUNT_STATS and update the DB on defined interval
     *
     * @param reportTime
     */
    public void updateUserCountStats(Long reportTime) {
        List<SdStats> packetStats = new ArrayList<>();
        Response res = sdRestManager.getResponse(device.getIpAddress(), "/" + Stats.Request.USER_COUNT_STATS.getValue());
        Long currentTime = System.currentTimeMillis();
        if (res != null && res.getStatus() == HttpStatus.SC_OK) {
            try {
                JSONObject responseJson = sdRestManager.getJsonFromResponse(res);
                JSONArray jsonArray = (JSONArray) (responseJson.has(Stats.Response.USER_COUNT_STATS.getValue()) ? responseJson.get(Stats.Response.USER_COUNT_STATS.getValue()) : new JSONArray());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject statsObj = jsonArray.getJSONObject(i);
                    SdStats stats = new SdStats();
                    stats.setDevice(device);
                    stats.setName(Stats.Response.USER_COUNT_STATS.getValue());
                    stats.setReportTime(Instant.ofEpochMilli(currentTime));
                    stats.setStatsData(statsObj.toString());
                    packetStats.add(stats);
                }

            } catch (JSONException e) {
                log.error("Exception while fetching USER_COUNT_STATS {}", e.getMessage());
            }
        }
        sdStatsRepository.save(packetStats);
    }

    /**
     * This is to clear last 1hr stats data
     */
    public void clearLastOneHourStatsData() {
        List<SdStats> sdStats = sdStatsRepository.findAllByDeviceId(device.getId());
        if (!sdStats.isEmpty()) {
            Long fromTime = System.currentTimeMillis() - 2 * CLEAR_INTERVAL_IN_HOUR * 60 * 60 * 1000;
            Long toTime = System.currentTimeMillis() - CLEAR_INTERVAL_IN_HOUR * 60 * 60 * 1000;
            List<SdStats> sdStatsList = sdStatsRepository.findLastOneHourData(device.getId(), Instant.ofEpochMilli(fromTime), Instant.ofEpochMilli(toTime));
            sdStatsRepository.delete(sdStatsList);
        }
    }

    /**
     * This method is used to start StatsTimerTask
     *
     * @param device
     * @return
     */
    public String startStatsTimerTask(Device device) {
        this.device = device;
        timer = new Timer();
        timer.scheduleAtFixedRate(new StatsTask(), 0, TIMER_INTERVAL_IN_MINUTES * 60 * 1000);
        return "stats collector task started";
    }

    /**
     * This method is used to stop StatsTimerTask
     *
     * @return
     */
    public String stopStatsTimerTask() {
        timer.cancel();
        return "stats collector task stopped";
    }
}
