package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.grid.DeviceGrid;

import java.util.Map;

public interface GridManager {

    Long saveGrid(DeviceGrid deviceGrid);

    Long commitGrid(DeviceGrid deviceGrid);

    Long deleteGrid(DeviceGrid deviceGrid);

    Long rollbackGrid(DeviceGrid deviceGrid);

    Map getGridTopology(Long gridId);
}
