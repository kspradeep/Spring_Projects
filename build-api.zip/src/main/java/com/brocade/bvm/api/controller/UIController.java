package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.BulkPolicyManager;
import com.brocade.bvm.api.model.*;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.collector.CollectorScheduler;
import com.brocade.bvm.collector.synctool.ReconciliationHelper;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.ClusterNodeInterfaceRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.model.SessionTimeout;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.db.admin.CollectorRunningStatus;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.brocade.bvm.model.db.statistics.DeviceSnapshot;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.model.flexmatch.FlexMatchHeaderJson;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.inject.Inject;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * The UIController class implements methods to fetch BVM data to display in UI
 */
@Slf4j
@RequestMapping(method = RequestMethod.GET, produces = "application/json", value = "/ui")
@RestController
public class UIController {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    @Value("${slx.packet.truncation.supported.os.version:18.1.03}")
    private String slxPacketTruncationSupportedVersion;

    @Value("${slx.packet.truncation.supported.os.version:18.1.01}")
    private String slxBreakoutWithoutReloadSupportedVersion;

    @Value("${evm.flex-match.template.server.path}")
    private String evmFlexMatchTemplateServerPath;

    @Value("${sd.valid.profile.ids}")
    private String validProfileIds;

    @Value("${sd.evm.server.file.path}")
    private String evmServerFilePath;

    @Value("${tacacs.server.ip.address}")
    private String tacacsServerIp;

    @Value("${evm.server.session.timeout:30}")
    private int defaultSessionTimeout;

    private AtomicInteger reconciledDeviceCount = new AtomicInteger(0);

    private static final String HEADERS_KEY = "headers";
    private static final String IS_SUPPORTED_KEY = "isSupported";
    private static final String SUB_HEADERS_KEY = "subHeaders";
    private static final String FIELDS_KEY = "fields";

    private static final String PORT_CHANNEL = "PORT_CHANNEL";
    private static final String PORT = "PORT";

    private static final Integer TELEMETRY_VERSION_CHECK = 1;
    private static final Integer PACKET_TRUNCATION_VERSION_CHECK = 2;
    private static final Integer SLX_GITTO_VERSION_CHECK = 3;

    private static final String EVENT_IMPACTED_OBJECTS_DELIMITTER = ", ";

    @Inject
    private ApplicationContext applicationContext;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private CollectorScheduler collectorScheduler;

    @Inject
    private BulkPolicyManager bulkPolicyManager;

    @Inject
    private ReconciliationHelper reconciliationHelper;

    @Inject
    private GenericHelper genericHelper;

    @Inject
    private ModulePolicyRepository modulepolicyRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private DevicePolicyRepository devicePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    private ProfileRepository profileRepository;

    @Inject
    private ProfileMappingRepository profileMappingRepository;

    @Inject
    private ProfileInterfaceMappingRepository profileInterfaceMappingRepository;

    @Inject
    private TargetHostRepository targetHostRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private JobRepository jobRepository;

    @Inject
    private EventRepository eventRepository;

    @Inject
    private PhysicalInterfaceRepository physicalInterfaceRepository;

    @Inject
    private IngressPortRepository ingressPortRepository;

    @Inject
    private DedupePolicyRepository dedupePolicyRepository;

    @Inject
    private EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    private SamplingPolicyRepository samplingPolicyRepository;

    @Inject
    private FilterPolicyRepository filterPolicyRepository;

    @Inject
    private FeatureConstantsRepository featureConstantsRepository;

    @Inject
    protected FlowExporterRepository flowExporterRepository;

    @Inject
    protected TemplatePolicyRepository templatePolicyRepository;

    @Inject
    private CollectorRunningStatusRepository collectorRunningStatusRepository;

    @Inject
    private HeaderStrippingModulePolicyRepository headerStrippingModulePolicyRepository;

    @Inject
    private GtpDeEncapsulationModulePolicyRepository gtpDeEncapsulationModulePolicyRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Inject
    private ClusterNodeInterfaceRepository clusterNodeInterfaceRepository;

    @Inject
    private SessionTimeoutRespository sessionTimeoutRespository;

    @EventListener
    void runImportFiles(ApplicationReadyEvent applicationReadyEvent) {
        //On start up the main thread triggers the importTemplatePolicies method,
        try {
            importTemplatePolicies();

            //resetting the flags if the collector and reconcile feature are in running state.
            List<CollectorRunningStatus> collectorRunningStatuses = Lists.newArrayList(collectorRunningStatusRepository.findAll());
            if (collectorRunningStatuses != null && !collectorRunningStatuses.isEmpty()) {
                CollectorRunningStatus collectorRunningStatus = collectorRunningStatuses.get(collectorRunningStatuses.size() - 1);
                if (collectorRunningStatus != null) {
                    collectorRunningStatus.setCollectorRunning(false);
                    collectorRunningStatus.setReconciliationRunning(false);
                    collectorRunningStatusRepository.save(collectorRunningStatus);
                }
            }
        } catch (Exception e) {
            log.error("Error while importing Template files from file system", e.getMessage());
        }
    }

    /**
     * This method fetches the global policies for the given policy type
     *
     * @param type
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/globalpolicy")
    public ResponseEntity<Object> getGlobalPoliciesByType(@RequestParam(value = "type", required = true) String type) {
        Set<ManagedObject> globalPolicies = new HashSet<>();
        if (type != null) {
            //device Policies
            Arrays.stream(DevicePolicy.Type.values()).forEach(policyType -> {
                if (policyType != null && policyType.name().equals(type)) {
                    Set<DevicePolicy> devicePolicies = devicePolicyRepository.findByType(type);
                    devicePolicies.stream().forEach(devicePolicy -> {
                        Device device = devicePolicy.getDevice();
                        if (device != null && !device.isDeleted() && device.isReconciled() && authorityProvider.getAuthorizedDeviceIds().contains(device.getId())) {
                            globalPolicies.add(devicePolicy);
                        }
                    });
                }
            });
            //module policies
            Arrays.stream(ModulePolicy.Type.values()).forEach(policyType -> {
                if (policyType != null && policyType.name().equals(type)) {
                    Set<ModulePolicy> modulePolicies = modulepolicyRepository.findByType(type);
                    modulePolicies.stream().forEach(modulePolicy -> {
                        if (ModulePolicy.Type.header_stripping_module_policy.name().equals(type) && modulePolicy instanceof HeaderStrippingModulePolicy && ((HeaderStrippingModulePolicy) modulePolicy).isPreserve()) {
                            HeaderStrippingModulePolicy headerStrippingModulePolicy = (HeaderStrippingModulePolicy) modulePolicy;
                            if (headerStrippingModulePolicy.getIntermediatePortId() != null) {
                                ((HeaderStrippingModulePolicy) modulePolicy).setIntermediatePort(portRepository.findOne(headerStrippingModulePolicy.getIntermediatePortId()));
                            }
                        }
                        if (modulePolicy.getModules() != null) {
                            Optional<Module> optionalModule = modulePolicy.getModules().stream().findAny();
                            if (optionalModule.isPresent()) {
                                //added device to module policy as part of global policy refactoring.
                                Device device = optionalModule.get().getDevice();
                                if (device != null && !device.isDeleted() && device.isReconciled()) {
                                    device.setModules(Sets.newHashSet());
                                    modulePolicy.setDevice(device);
                                    if (authorityProvider.getAuthorizedDeviceIds().contains(device.getId())) {
                                        globalPolicies.add(modulePolicy);
                                    }
                                }
                            } else {
                                Device device = modulePolicy.getDevice();
                                if (device != null && !device.isDeleted() && device.isReconciled()) {
                                    globalPolicies.add(modulePolicy);
                                } else if (device == null) {
                                    globalPolicies.add(modulePolicy);
                                }
                            }
                        }
                    });
                }
            });
        }
        return new ResponseEntity<>(globalPolicies, HttpStatus.OK);
    }


    /**
     * This method fetches all types of policies in BVM for the given device id
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/device/{deviceid}/policy")
    public ResponseEntity<Object> getAllTypesOfPoliciesByDeviceId(@PathVariable("deviceid") Long deviceId, @RequestParam(value = "createdFromSd", required = false) String createdFromSd) {
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        Map<String, Object> map = new HashMap<>();
        boolean isCreatedFromSd = false;
        if (!StringUtils.isEmpty(createdFromSd) && "true".equals(createdFromSd)) {
            isCreatedFromSd = true;
        }
        //policies
        Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(deviceId, isCreatedFromSd));
        policies = authorityProvider.applyRBACOnPolicies(policies, deviceId);
        UIPolicySummary policySummaryOnDevice = new UIPolicySummary(policies);
        map.put("policySummaries", policySummaryOnDevice.getPolicySets());

        //device Policies
        Set<DevicePolicy> devicePolicies = devicePolicyRepository.findByDeviceId(deviceId);
        Map<String, Set<DevicePolicy>> devicePolicyMap = new HashMap<>();
        if (devicePolicies != null && devicePolicies.size() > 0) {
            devicePolicyMap.putAll(managerBuilder.getOperationsFactory(device)
                    .getDevicePolicyManager(devicePolicies)
                    .getDevicePolicies(devicePolicies));
        }
        map.put("devicePolicies", devicePolicyMap);
        //module policies
        if (TargetHost.Mode.PLAIN.equals(device.getMode())) {
            List<ModulePolicy> modulePolicies = modulepolicyRepository.findByDeviceId(deviceId);
            if (modulePolicies != null && modulePolicies.size() > 0) {
                map.putAll(managerBuilder.getOperationsFactory(device)
                        .getModulePolicyManager(modulePolicies.stream().findAny().get())
                        .getModulePolicies(modulePolicies));
            }
        }
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * This method fetches the ports and portGroups for the given device id
     *
     * @param deviceId
     * @return
     */
    @RequestMapping(value = "/device/{deviceid}/port")
    public ResponseEntity<Object> getPortsAndPortGroupsOfDevice(@PathVariable("deviceid") Long deviceId, @RequestParam(value = "fromSd", required = false) String fromSd) {
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        boolean isFromSd = false;
        if (!StringUtils.isEmpty(fromSd) && "true".equals(fromSd)) {
            isFromSd = true;
        }
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(Device.class, isFromSd ? new SDPortsJsonSerializer() : new PortsJsonSerializer());
        mapper.registerModule(simpleModule);
        String customJson;
        try {
            customJson = mapper.writeValueAsString(device);
        } catch (JsonProcessingException e) {
            throw new ServerException(e);
        }

        return new ResponseEntity<>(customJson, HttpStatus.OK);
    }

    /**
     * This method check if the device os version is valid for enabling a feature
     *
     * @param deviceId
     * @return json
     */
    @RequestMapping(value = "/device/{deviceid}/versioncheck")
    public ResponseEntity<Object> getSLXDeviceOsVersionCheck(@PathVariable("deviceid") Long deviceId, @RequestParam(value = "type") Integer type) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && (!device.isReconciled() || !device.isProfileConfigured())) {
            throw new ValidationException("device.not.authorized");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        JSONObject jsonObject = new JSONObject();
        boolean isValidVersion = false;
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850) && !Strings.isNullOrEmpty(device.getOs())) {
            if (TELEMETRY_VERSION_CHECK == type) {
                isValidVersion = genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0;
            } else if (PACKET_TRUNCATION_VERSION_CHECK == type) {
                isValidVersion = genericHelper.isSLXVersionValid(device.getOs(), slxPacketTruncationSupportedVersion) >= 0;
            } else if (SLX_GITTO_VERSION_CHECK == type) {
                isValidVersion = genericHelper.isSLXVersionValid(device.getOs(), slxBreakoutWithoutReloadSupportedVersion) >= 0;
            }
        }
        try {
            jsonObject.put("isValid", isValidVersion);
        } catch (JSONException e) {
            throw new ServerException(e);
        }
        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to trigger collectors from UI
     *
     * @return
     */
    @RequestMapping(value = "/collect")
    public ResponseEntity<Object> runCollector() {
        collectorScheduler.runCollectors();
        Map<String, Instant> mapDevice = new HashMap<>();
        mapDevice.put("lastUpdatedTime", deviceRepository.getLastUpdatedTime());
        Map<String, Instant> mapCloud = new HashMap<>();
        mapCloud.put("lastUpdatedTime", targetHostRepository.getLastUpdatedTime());
        Map<String, Map> finalMap = new HashMap<>();
        finalMap.put("device", mapDevice);
        finalMap.put("cloud", mapCloud);
        return new ResponseEntity<>(finalMap, HttpStatus.OK);
    }

    /**
     * This method is used to trigger reconciliation of devices from UI
     *
     * @return
     */
    @RequestMapping(value = "/reconcile")
    public ResponseEntity<Object> reconcileDevices() {
        CollectorRunningStatus reconcileRunningStatus = null;
        List<CollectorRunningStatus> collectorRunningStatuses = Lists.newArrayList(collectorRunningStatusRepository.findAll());
        if (collectorRunningStatuses != null && !collectorRunningStatuses.isEmpty()) {
            reconcileRunningStatus = collectorRunningStatuses.get(collectorRunningStatuses.size() - 1);
            AtomicBoolean isRunning = new AtomicBoolean(reconcileRunningStatus.isReconciliationRunning());
            if (isRunning.get()) {
                while (isRunning.get()) {
                    try {
                        TimeUnit.SECONDS.sleep(10);
                        collectorRunningStatuses = Lists.newArrayList(collectorRunningStatusRepository.findAll());
                        if (collectorRunningStatuses != null && !collectorRunningStatuses.isEmpty()) {
                            reconcileRunningStatus = collectorRunningStatuses.get(collectorRunningStatuses.size() - 1);
                            isRunning = new AtomicBoolean(reconcileRunningStatus.isReconciliationRunning());
                        } else {
                            isRunning.set(false);
                        }
                    } catch (InterruptedException e) {
                        isRunning.set(false);
                        reconcileRunningStatus.setReconciliationRunning(false);
                        collectorRunningStatusRepository.save(reconcileRunningStatus);
                        throw new ServerException(e);
                    }
                }
                return new ResponseEntity<>(HttpStatus.OK);
            }
        }

        if (reconcileRunningStatus == null) {
            reconcileRunningStatus = new CollectorRunningStatus();
        }
        synchronized (this) {
            log.debug("Reconciliation process started.");
            reconcileRunningStatus.setReconciliationRunning(true);
            collectorRunningStatusRepository.save(reconcileRunningStatus);
            JSONArray responseArray = new JSONArray();
            try {
                List<Long> mlxeDevices = deviceRepository.findAllMlxeDevicesNotReconciled();
                mlxeDevices.forEach(deviceId -> {
                    reconciliationHelper.reconcileMLXe(deviceId, responseArray);
                });

                List<Long> slxDevices = deviceRepository.findAllSLXDevicesNotReconciled();
                slxDevices.forEach(deviceId -> {
                    reconciliationHelper.reconcileSLX(deviceId, responseArray);
                });
            } catch (ServerException e) {
                log.error("Reconciliation failed with exception: ", e.getMessage());
            } finally {
                reconcileRunningStatus.setReconciliationRunning(false);
                collectorRunningStatusRepository.save(reconcileRunningStatus);
                log.debug("Reconciliation process ended.");
            }
            return new ResponseEntity<>(responseArray.toString(), HttpStatus.OK);
        }
    }

    /**
     * This method is used to get reconciliation status
     *
     * @return
     */
    @RequestMapping(value = "/reconciliationstatus")
    public ResponseEntity<Object> reconciliationStatus() {
        Map<String, Object> reconcileResult = Maps.newHashMap();
        CollectorRunningStatus reconcileRunningStatus;
        log.debug("Reconciliation status api invoked.");
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
        }
        List<CollectorRunningStatus> reconcileRunningStatuses = Lists.newArrayList(collectorRunningStatusRepository.findAll());
        if (reconcileRunningStatuses != null && !reconcileRunningStatuses.isEmpty()) {
            reconcileRunningStatus = reconcileRunningStatuses.get(reconcileRunningStatuses.size() - 1);
            AtomicLong reconciledDeviceCount = new AtomicLong();
            reconciledDeviceCount.set(deviceRepository.getReconciledDeviceCountByType(Lists.newArrayList(Device.Type.SD, Device.Type.MLXE)));

            List<Object[]> deviceListWithProfileConfigured = deviceRepository.findAllByTypeAndIsReconciledAndIsProfileConfigured(Lists.newArrayList(Device.Type.SLX), true);
            reconciledDeviceCount.addAndGet(deviceListWithProfileConfigured.size());

            List<Object[]> deviceListWithoutProfileConfigured = deviceRepository.findAllByTypeAndIsReconciledAndIsProfileConfigured(Lists.newArrayList(Device.Type.SLX), false);
            deviceListWithoutProfileConfigured.stream().forEach(deviceObj -> {
                if (deviceObj.length > 2 && deviceObj[0] != null && deviceObj[1] != null && deviceObj[2] != null) {
                    if (String.valueOf(deviceObj[2]).contains(Device.SLX_9850)) {
                        reconciledDeviceCount.incrementAndGet();
                    } else if (genericHelper.isSLXVersionValid(String.valueOf(deviceObj[1]), slxTelemetrySupportedVersion) < 0) {
                        reconciledDeviceCount.incrementAndGet();
                    }
                }
            });
            reconcileResult.put("isReconciliationRunning", reconcileRunningStatus.isReconciliationRunning());
            reconcileResult.put("reconciledDeviceCount", reconciledDeviceCount.get());
        }
        return new ResponseEntity<>(reconcileResult, HttpStatus.OK);
    }

    /**
     * This method is used to fetch error status for the given objectId
     *
     * @param objectId
     * @return
     */
    @RequestMapping(value = "/error/{objectid}")
    public ResponseEntity<Object> getObjectStatus(@PathVariable("objectid") Long objectId) {
        JSONObject jsonObject = new JSONObject();
        if (objectId != null) {
            String jobResult = null;
            Object[] jobResultAndStatus = (Object[]) jobRepository.getJobStatusByObjectId(objectId);
            if (jobResultAndStatus != null && jobResultAndStatus.length == 2) {
                if ((jobResultAndStatus[1] != null && Job.Status.FAILED.toString().equals(jobResultAndStatus[1])) || (jobResultAndStatus[0] != null && String.valueOf(jobResultAndStatus[0]).contains("WARNING"))) {
                    jobResult = String.valueOf(jobResultAndStatus[0]);
                }
            }
            if (jobResult == null) {
                jobResult = eventRepository.getEventByObjectId(objectId);
            }
            try {
                jsonObject.put("jobresult", jobResult);
            } catch (JSONException e) {
                throw new ServerException(e);
            }
        }
        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to fetch error job result given jobId
     *
     * @param jobId
     * @return
     */
    @RequestMapping(value = "/error/jobresult/{jobid}")
    public ResponseEntity<Object> getJobResult(@PathVariable("jobid") Long jobId) {
        JSONObject jsonObject = new JSONObject();
        if (jobId != null) {
            String jobResult = jobRepository.getJobResultByJobId(jobId);
            try {
                jsonObject.put("jobresult", jobResult);
            } catch (JSONException e) {
                throw new ServerException(e);
            }
        }
        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to fetch all NEW EVENTS and display in UI
     *
     * @return
     */
    @RequestMapping(value = "/events")
    public ResponseEntity<Object> getEvents() {
        List<Event> events = eventRepository.findTop500ByStatusInOrderByLastUpdatedTimeDesc(Lists.newArrayList(Event.Status.NEW));
        List<Long> managedObjectIds = new ArrayList<>();
        events.stream().forEach(event -> {
            Job job = event.getJob();
            if (job != null && job.getParentObjectId() != null) {
                managedObjectIds.add(job.getParentObjectId());
            }
            if (job != null && !job.getImpactedObjectsIds().isEmpty()) {
                managedObjectIds.addAll(job.getImpactedObjectsIds());
            }
        });

        Map<Long, String> managedObjectMap = new HashMap<>();
        if (!managedObjectIds.isEmpty()) {
            List<String> managedObjectNames = eventRepository.findManagedObjectNames(managedObjectIds);
            managedObjectNames.stream().forEach(nameId -> {
                if (nameId != null) {
                    Long id = Long.parseLong(nameId.substring(0, nameId.indexOf(':')));
                    String name = nameId.substring(nameId.indexOf(':') + 1);
                    managedObjectMap.put(id, name);
                }
            });
        }

        // serializing events data
        List<JSONObject> eventsResponse = new ArrayList<>();
        events.stream().forEach(eachEvent -> {
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", eachEvent.getId());
                jsonObject.put("eventStatus", eachEvent.getStatus());
                Date myDate = Date.from(eachEvent.getLastUpdatedTime());
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String formattedDate = formatter.format(myDate);
                jsonObject.put("eventLastUpdatedTime", formattedDate);

                Job eventJob = eachEvent.getJob();
                if (eventJob != null) {
                    if (eventJob.getTargetHost() != null) {
                        jsonObject.put("deviceId", eventJob.getTargetHost().getId());
                        jsonObject.put("deviceName", eventJob.getTargetHost().getName());
                    }
                    jsonObject.put("jobId", eventJob.getId());
                    jsonObject.put("workflowStatus", eventJob.getStatus());
                    jsonObject.put("jobType", eventJob.getType());
                    if (eachEvent.getSeverity() != null) {
                        jsonObject.put("jobStatus", eachEvent.getSeverity());
                    } else {
                        jsonObject.put("jobStatus", Event.Severity.CRITICAL);
                    }
                    jsonObject.put("createdBy", eventJob.getCreatedByUser());
                    StringBuilder impactedObjectNames = new StringBuilder();
                    if (eventJob.getParentObjectId() != null && (managedObjectMap.get(eventJob.getParentObjectId())) != null && !"null".equalsIgnoreCase(managedObjectMap.get(eventJob.getParentObjectId()))) {
                        impactedObjectNames.append(managedObjectMap.get(eventJob.getParentObjectId())).append(EVENT_IMPACTED_OBJECTS_DELIMITTER);
                    }
                    eventJob.getImpactedObjectIds().forEach(eachId -> {
                        if (managedObjectMap.get(eachId) != null && !(managedObjectMap.get(eachId)).equalsIgnoreCase("null")) {
                            impactedObjectNames.append(managedObjectMap.get(eachId)).append(EVENT_IMPACTED_OBJECTS_DELIMITTER);
                        }
                    });
                    //added in case of deleted objects in events
                    if (impactedObjectNames.length() > 0) {
                        jsonObject.put("impactedObjects", impactedObjectNames.substring(0, impactedObjectNames.length() - EVENT_IMPACTED_OBJECTS_DELIMITTER.length()));
                    }
                } else {
                    if (eachEvent.getTargetHost() != null) {
                        jsonObject.put("deviceName", eachEvent.getTargetHost());
                    }
                    jsonObject.put("workflowStatus", eachEvent.getJobStatus());
                    jsonObject.put("jobType", eachEvent.getType());
                    if (eachEvent.getSeverity() != null) {
                        jsonObject.put("jobStatus", eachEvent.getSeverity());
                    } else {
                        jsonObject.put("jobStatus", Event.Severity.CRITICAL);
                    }
                    jsonObject.put("createdBy", eachEvent.getCreatedByUser());
                    jsonObject.put("result", eachEvent.getResult());
                }
                eventsResponse.add(jsonObject);
            } catch (JSONException e) {
                log.error("Failed to get events", e);
            }
        });
        return new ResponseEntity<>(eventsResponse.toString(), HttpStatus.OK);
    }

    /**
     * This method converts device object into JSON string
     *
     * @param device
     * @return
     * @throws JsonProcessingException
     */
    @VisibleForTesting
    String getJson(Device device) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(Device.class, new PortsJsonSerializer());
        mapper.registerModule(simpleModule);
        return mapper.writeValueAsString(device);
    }

    /**
     * This class serializes ports and port groups from object to JSON
     */
    private class PortsJsonSerializer extends JsonSerializer<Device> {

        /**
         * This method is used to serialize ports and port groups
         *
         * @param device
         * @param jsonGenerator
         * @param serializers
         * @throws IOException
         */
        @Override
        public void serialize(Device device, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                device = authorityProvider.applyRBACOnDevice(device);

                Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(device.getId(), false));

                Map<Long, Policy> portGroupMap = new HashMap<>();
                Set<Long> servicePortGroupIdUsedAsIngress = new HashSet<>();
                Set<Long> servicePortIdUsedAsIngress = new HashSet<>();
                policies.forEach(policy -> {
                    Set<PortGroup> portGroups = new HashSet<>();
                    policy.getFlows().forEach(flow -> {
                        portGroups.addAll(flow.getEgressPortGroups().stream().filter(obj -> obj.getObjectType().equals("port_group")).collect(Collectors.toSet()));
                        portGroups.addAll(flow.getIngressPortGroups().stream().filter(obj -> obj.getObjectType().equals("port_group")).collect(Collectors.toSet()));
                        flow.getIngressPortGroups().stream().forEach(obj -> {
                            if (obj != null && obj.getId() != null && obj.getObjectType().equals("port_group") && Port.Type.SERVICE_PORT == obj.getType()) {
                                servicePortGroupIdUsedAsIngress.add(obj.getId());
                            }
                        });
                        flow.getIngressPorts().stream().forEach(obj -> {
                            if (obj != null && obj.getId() != null && Port.Type.SERVICE_PORT == obj.getType())
                                servicePortIdUsedAsIngress.add(obj.getId());
                        });
                    });
                    for (PortGroup portGroup : portGroups) {
                        portGroupMap.put(portGroup.getId(), policy);
                    }
                });

                List<Long> authorizedPortsOnDevice = new ArrayList<>();
                device.getModules().stream().forEach(module -> module.getPorts().stream().forEach(port -> authorizedPortsOnDevice.add(port.getId())));
                List<Long> portGroupIds = device.getPortGroups().stream().map(ManagedObject::getId).collect(Collectors.toList());
                List<Long> packetTruncationPortGroupIds = Lists.newArrayList();
                if (!portGroupIds.isEmpty()) {
                    packetTruncationPortGroupIds.addAll(packetTruncationMappingRepository.findPortGroupsByDeviceIdAndPortGroupIds(device.getId(), portGroupIds));
                }
                Set<ManagedObject> managedObjects = clusterNodeInterfaceRepository.findManagedObjectsByDeviceId(device.getId());
                List<Long> interfaceIdsInGrid = managedObjects.stream().map(ManagedObject::getId).collect(Collectors.toList());
                jsonGenerator.writeStartObject();
                jsonGenerator.writeArrayFieldStart("portGroups");
                device.getPortGroups().forEach(portGroup -> {
                    try {
                        if (portGroup.getPorts().stream().allMatch(port -> authorizedPortsOnDevice.contains(port.getId()))) {
                            portGroup.setGtpProfileId(portGroup.getGtpProfile() != null ? portGroup.getGtpProfile().getId() : null);
                            jsonGenerator.writeStartObject();
                            JsonSerializer<Object> portGroupJsonSerializer = serializers.findValueSerializer(PortGroup.class);
                            portGroupJsonSerializer.unwrappingSerializer(null).serialize(portGroup, jsonGenerator, serializers);
                            jsonGenerator.writeStringField("associatedPolicy", portGroupMap.containsKey(portGroup.getId()) ? portGroupMap.get(portGroup.getId()).getName() : null);
                            jsonGenerator.writeBooleanField("isUsedAsIngress", servicePortGroupIdUsedAsIngress.contains(portGroup.getId()) ? true : false);
                            if (packetTruncationPortGroupIds.contains(portGroup.getId())) {
                                jsonGenerator.writeBooleanField("isUsedInPacketTruncation", true);
                            } else {
                                jsonGenerator.writeBooleanField("isUsedInPacketTruncation", false);
                            }
                            if (interfaceIdsInGrid.contains(portGroup.getId())) {
                                jsonGenerator.writeBooleanField("isUsedInGrid", true);
                            } else {
                                jsonGenerator.writeBooleanField("isUsedInGrid", false);
                            }
                            jsonGenerator.writeEndObject();
                        }
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeArrayFieldStart("ports");

                List<Port> ports = device.getModules().stream().map(module -> module.getPorts()).flatMap(c -> c.stream()).collect(Collectors.toList());
                Collections.sort(ports);
                List<Long> portIds = ports.stream().map(ManagedObject::getId).collect(Collectors.toList());
                List<Long> packetTruncationPortIds = Lists.newArrayList();
                if (!portIds.isEmpty()) {
                    packetTruncationPortIds.addAll(packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(device.getId(), portIds));
                }
                ports.forEach(port -> {
                    try {
                        jsonGenerator.writeStartObject();
                        JsonSerializer<Object> portJsonSerializer = serializers.findValueSerializer(Port.class);
                        portJsonSerializer.unwrappingSerializer(null).serialize(port, jsonGenerator, serializers);
                        jsonGenerator.writeStringField("moduleName", port.getModule().getName());
                        jsonGenerator.writeNumberField("moduleId", port.getModule().getId());
                        if (port.getModule().getType() != null) {
                            jsonGenerator.writeStringField("moduleCapacity", port.getModule().getType().name());
                        } else {
                            jsonGenerator.writeStringField("moduleCapacity", null);
                        }
                        Long portGroupId = portGroupRepository.findByPortId(port.getId());
                        PortGroup portGroup = null;
                        if (portGroupId != null) {
                            portGroup = portGroupRepository.findOne(portGroupId);
                        }
                        jsonGenerator.writeStringField("portGroupName", portGroup != null ? portGroup.getName() : null);

                        if (packetTruncationPortIds.contains(port.getId())) {
                            jsonGenerator.writeBooleanField("isUsedInPacketTruncation", true);
                        } else {
                            jsonGenerator.writeBooleanField("isUsedInPacketTruncation", false);
                        }
                        jsonGenerator.writeBooleanField("isUsedAsIngress", servicePortIdUsedAsIngress.contains(port.getId()) ? true : false);
                        if (interfaceIdsInGrid.contains(port.getId())) {
                            jsonGenerator.writeBooleanField("isUsedInGrid", true);
                        } else {
                            jsonGenerator.writeBooleanField("isUsedInGrid", false);
                        }
                        jsonGenerator.writeEndObject();
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
            } catch (IOException e) {
                throw new ServerException(e);
            }
            jsonGenerator.writeEndObject();
        }
    }


    /**
     * This class serializes ports and port groups from object to JSON
     */
    private class SDPortsJsonSerializer extends JsonSerializer<Device> {

        /**
         * This method is used to serialize ports and port groups
         *
         * @param device
         * @param jsonGenerator
         * @param serializers
         * @throws IOException
         */
        @Override
        public void serialize(Device device, JsonGenerator jsonGenerator, SerializerProvider serializers) throws IOException {
            try {
                device = authorityProvider.applyRBACOnDevice(device);
                Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(device.getId(), false));
                Map<Long, Policy> portGroupMap = new HashMap<>();
                Set<Port> portsFromPolicies = Sets.newHashSet();
                policies.forEach(policy -> {
                    Set<PortGroup> portGroups = new HashSet<>();
                    policy.getFlows().forEach(flow -> {
                        portGroups.addAll(flow.getEgressPortGroups().stream().filter(obj -> obj.getObjectType().equals("port_group")).collect(Collectors.toSet()));
                        portGroups.addAll(flow.getIngressPortGroups().stream().filter(obj -> obj.getObjectType().equals("port_group")).collect(Collectors.toSet()));
                        portsFromPolicies.addAll(flow.getIngressPorts());
                        portsFromPolicies.addAll(flow.getEgressPorts());
                    });
                    for (PortGroup portGroup : portGroups) {
                        portGroupMap.put(portGroup.getId(), policy);
                    }
                });

                List<Long> authorizedPortsOnDevice = new ArrayList<>();
                device.getModules().stream().forEach(module -> module.getPorts().stream().forEach(port -> authorizedPortsOnDevice.add(port.getId())));
                jsonGenerator.writeStartObject();
                jsonGenerator.writeArrayFieldStart("ports");

                List<Port> ports = device.getModules().stream().map(module -> module.getPorts()).flatMap(c -> c.stream()).collect(Collectors.toList());
                Collections.sort(ports);
                ports.forEach(port -> {
                    try {
                        if (!portsFromPolicies.contains(port)) {
                            jsonGenerator.writeStartObject();
                            JsonSerializer<Object> portJsonSerializer = serializers.findValueSerializer(Port.class);
                            portJsonSerializer.unwrappingSerializer(null).serialize(port, jsonGenerator, serializers);
                            jsonGenerator.writeStringField("moduleName", port.getModule().getName());
                            jsonGenerator.writeNumberField("moduleId", port.getModule().getId());
                            if (port.getModule().getType() != null) {
                                jsonGenerator.writeStringField("moduleCapacity", port.getModule().getType().name());
                            } else {
                                jsonGenerator.writeStringField("moduleCapacity", null);
                            }
                            Long portGroupId = portGroupRepository.findByPortId(port.getId());
                            PortGroup portGroup = null;
                            if (portGroupId != null) {
                                portGroup = portGroupRepository.findOne(portGroupId);
                            }
                            jsonGenerator.writeStringField("portGroupName", portGroup != null ? portGroup.getName() : null);
                            jsonGenerator.writeEndObject();
                        }
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
                jsonGenerator.writeArrayFieldStart("portGroups");
                device.getPortGroups().forEach(portGroup -> {
                    try {
                        if (portGroup.getPorts().stream().allMatch(port -> authorizedPortsOnDevice.contains(port.getId()))) {
                            portGroup.setGtpProfileId(portGroup.getGtpProfile() != null ? portGroup.getGtpProfile().getId() : null);
                            jsonGenerator.writeStartObject();
                            JsonSerializer<Object> portGroupJsonSerializer = serializers.findValueSerializer(PortGroup.class);
                            portGroupJsonSerializer.unwrappingSerializer(null).serialize(portGroup, jsonGenerator, serializers);
                            jsonGenerator.writeStringField("associatedPolicy", portGroupMap.containsKey(portGroup.getId()) ? portGroupMap.get(portGroup.getId()).getName() : null);
                            jsonGenerator.writeEndObject();
                        }
                    } catch (IOException e) {
                        throw new ServerException(e);
                    }
                });
                jsonGenerator.writeEndArray();
            } catch (IOException e) {
                throw new ServerException(e);
            }
            jsonGenerator.writeEndObject();
        }
    }

    /**
     * This method is used to fetch all SLX and MLXe devices for pairing with SD
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/device/{deviceid}/pair/profile", method = RequestMethod.GET)
    public ResponseEntity<Object> getDevicesForPairingProfiling(@PathVariable("deviceid") Long deviceId) throws JSONException {
        validateAndReturnDevice(deviceId);
        //Setting Paired Device data into response JSON
        List<Device.Type> types = new ArrayList<>();
        types.add(Device.Type.MLXE);
        List<Device.Mode> modes = new ArrayList<>();
        modes.add(Device.Mode.PLAIN);
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        List<Device> availableDevicesForPairing = Lists.newArrayList();
        if (!stablenetDeviceIds.isEmpty()) {
            availableDevicesForPairing = deviceRepository.findByReconciledAndIsDeletedFalseAndTypeInAndModeIn(stablenetDeviceIds, types, modes);
        }

        JSONObject response = new JSONObject();
        // serializing device data
        List<JSONObject> devices = new ArrayList<>();
        availableDevicesForPairing.stream().forEach(eachDevice -> {
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", eachDevice.getId());
                jsonObject.put("name", eachDevice.getName());
                jsonObject.put("mode", eachDevice.getMode());
                jsonObject.put("type", eachDevice.getType());
                devices.add(jsonObject);
            } catch (JSONException e) {
                log.error("Failed to get devices", e);
            }
        });
        response.put("deviceList", devices);
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        if (pairedDevice != null) {
            JSONObject targetDevicejsonObject = new JSONObject();
            Device targetDevice = pairedDevice.getTargetDevice();
            targetDevicejsonObject.put("id", targetDevice.getId());
            targetDevicejsonObject.put("name", targetDevice.getName());
            targetDevicejsonObject.put("mode", targetDevice.getMode());
            targetDevicejsonObject.put("type", targetDevice.getType());
            response.put("selectedDevice", targetDevicejsonObject);
        } else {
            response.put("selectedDevice", "");
        }

        //Setting Profile data into response JSON
        ProfileMapping profileOnSD = profileMappingRepository.findByDeviceId(deviceId);
        List<Profile> profiles = null;
        //Getting only profiles used for Verizon and the default profile with which Sd comes up
        if (validProfileIds != null && !validProfileIds.isEmpty()) {
            List<Integer> validProfiles = new ArrayList<>();
            for (String profileId : validProfileIds.split(",")) {
                validProfiles.add(new Integer(profileId));
            }
            profiles = profileRepository.findByDeviceIdAndProfileIdIn(deviceId, validProfiles);
        } else {
            profiles = profileRepository.findByDevice(deviceRepository.findOne(deviceId));
        }
        List<JSONObject> profilesJson = new ArrayList<>();
        for (Profile profile : profiles) {
            JSONObject profileJson = new JSONObject();
            profileJson.put("id", profile.getId());
            profileJson.put("name", profile.getName());
            profilesJson.add(profileJson);
        }
        JSONObject selectedProfileJson = new JSONObject();
        if (profileOnSD != null) {
            selectedProfileJson.put("id", profileOnSD.getProfile().getId());
            selectedProfileJson.put("name", profileOnSD.getProfile().getName());
        }
        response.put("profiles", profilesJson);
        response.put("selectedProfile", selectedProfileJson);
        return new ResponseEntity<>(response.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to fetch all interface names and ingress types based on profile selected
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/device/{deviceid}/profile/{profileid}/ingressports", method = RequestMethod.GET)
    public ResponseEntity<Object> getIngressPorts(@PathVariable("deviceid") Long deviceId, @PathVariable("profileid") Long profileId) throws JSONException {
        validateAndReturnDevice(deviceId);
        List<PhysicalInterface> physicalInterfaceList = (List<PhysicalInterface>) physicalInterfaceRepository.findByDeviceId(deviceId);
        List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(deviceId, profileId);

        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        List<Port> ports = new ArrayList<>();
        if (pairedDevice != null && pairedDevice.getTargetDevice() != null) {
            Device targetDevice = pairedDevice.getTargetDevice();
            Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(targetDevice.getId(), false));
            Set<Port> portsFromPolicies = Sets.newHashSet();
            policies.forEach(policy -> {
                policy.getFlows().forEach(flow -> {
                    portsFromPolicies.addAll(flow.getIngressPorts());
                    portsFromPolicies.addAll(flow.getEgressPorts());
                });
            });

            targetDevice.getModules().forEach(module -> module.getPorts().stream().forEach(port -> {
                ports.add(port);
            }));

            ports.removeAll(portsFromPolicies);
        }

        Collections.sort(ports);
        Map<String, Object> map = new HashMap<>();
        map.put("ingressPorts", ingressPorts);
        map.put("physicalInterfaces", physicalInterfaceList);
        map.put("ports", ports);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * This method is used to club Sampling/Filter/Dedupe/Port-Group configured on particular SD device.
     *
     * @param deviceId
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/sd/{deviceId}/policies")
    public ResponseEntity<Object> getSdPolicies(@PathVariable("deviceId") Long deviceId) {
        validateAndReturnDevice(deviceId);
        List<SdPortGroup> portGroups = egressPortGroupRepository.findByDeviceAndInWorkflowStatus(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        List<Long> usedPortGroupsInFilterPolicy = filterPolicyRepository.findPortGroupUsedInFilter();
        List<Long> usedSamplingPolicyInFilterPolicy = filterPolicyRepository.findSamplingPolicyUsedInFilter();
        List<SamplingPolicy> samplingPolicies = samplingPolicyRepository.findByDeviceAndInWorkflowStatus(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        List<DeDupePolicy> deDupePolicies = dedupePolicyRepository.findAllByDeviceId(deviceId);
        List<FilterPolicy> filterPolicies = filterPolicyRepository.findByDeviceAndInWorkflowStatus(deviceId, Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));

        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
        List<ProfileInterfaceMapping> interfaces = profileInterfaceMappingRepository.findByProfile(profileMapping.getProfile());

        interfaces.forEach(intrfc -> {
            intrfc.setProfile(null);
        });

        portGroups.forEach(portGroup -> {
            portGroup.setDevice(null);
            portGroup.setEgressPorts(Sets.newHashSet());
        });

        samplingPolicies.forEach(samplingPolicy -> {
            samplingPolicy.setDevice(null);
        });

        deDupePolicies.forEach(deDupePolicy -> {
            deDupePolicy.setDevice(null);
        });

        filterPolicies.forEach(filterPolicy -> {
            filterPolicy.setDevice(null);
            filterPolicy.setRules(Sets.newTreeSet());
        });

        Map<String, Object> policyMap = new HashMap<>();
        policyMap.put("portGroups", portGroups);
        policyMap.put("samplingPolicies", samplingPolicies);
        policyMap.put("dedupePolicies", deDupePolicies);
        policyMap.put("filterPolicies", filterPolicies);
        policyMap.put("usedPortGroupsInFilterPolicy", usedPortGroupsInFilterPolicy);
        policyMap.put("usedSamplingPolicyInFilterPolicy", usedSamplingPolicyInFilterPolicy);
        policyMap.put("interfaces", interfaces);

        return new ResponseEntity<>(policyMap, HttpStatus.OK);
    }

    /**
     * This is used to upload bulk data into BVM
     *
     * @param deviceId
     * @param sdPolicyRequest
     * @return
     */
    @RequestMapping(value = "/sd/{deviceid}/upload", method = RequestMethod.POST)
    public ResponseEntity<Object> upload(@PathVariable("deviceid") Long deviceId,
                                         @RequestBody SdPolicyRequest sdPolicyRequest) {
        Device device = validateAndReturnDevice(deviceId);
        if (sdPolicyRequest == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (sdPolicyRequest.getFilterPolicies() != null && !sdPolicyRequest.getFilterPolicies().isEmpty()) {
            bulkPolicyManager.isPolicyInputValid(sdPolicyRequest);
        }
        if (device.getType() == Device.Type.SD) {
            FilterPolicy filterPolicy = bulkPolicyManager.saveAndCommitPolcies(sdPolicyRequest, deviceId);
            return new ResponseEntity<>(filterPolicy, HttpStatus.OK);
        } else {
            throw new ValidationException("policy.action.invalid");
        }
    }

    /**
     * This method is used to upload sd-files into BVM server
     *
     * @return
     */
    @RequestMapping(value = "/sd/upload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) {
        if (file == null) {
            throw new ValidationException("file.not.found");
        }
        Map<String, String> fileNameMap = new HashMap<>();
        try {
            String fileName = file.getOriginalFilename().replace(".csv", "_" + System.currentTimeMillis() + ".csv");
            fileNameMap.put("fileName", fileName);
            if (fileName != null) {
                List<Long> ruleIds = filterPolicyRepository.findImsiFileUsedInFilterRule(fileName);
                if (!ruleIds.isEmpty()) {
                    throw new ValidationException("file.already.used");
                }
            }
            byte[] fileBytes = file.getBytes();
            Path path = Paths.get(evmServerFilePath + fileName);
            Files.write(path, fileBytes);
            convertFileDosToUnix(evmServerFilePath + fileName);
        } catch (Exception e) {
            log.error("Error while saving file ", e.getLocalizedMessage());
            throw new ServerException(e.getMessage());
        }
        return new ResponseEntity(fileNameMap, HttpStatus.OK);
    }

    /**
     * This method is used to convert DOS file into UNIX file
     *
     * @param filePath
     */
    public void convertFileDosToUnix(String filePath) {
        try {
            log.debug("Filename to convert is " + filePath);
            Runtime.getRuntime().exec("dos2unix " + filePath);
            log.debug("Conversion done....");
        } catch (Exception e) {
            log.error("Error while converting file Dos2Unix " + e.getLocalizedMessage());
        }
    }

    /**
     * This method is used for deleting file from BVM server created during File Upload
     *
     * @param fileName
     * @return
     */
    @RequestMapping(value = "/sd/{fileName}/delete", method = RequestMethod.DELETE)
    public ResponseEntity<Object> deleteFile(@PathVariable("fileName") String fileName) {
        if (fileName == null) {
            throw new ValidationException("file.not.found");
        }
        try {
            File file = new File(evmServerFilePath + fileName);
            if (file.exists())
                file.delete();
        } catch (Exception e) {
            log.error("Error while deleting file ", e.getLocalizedMessage());
            throw new ServerException(e.getMessage());
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * This method is used for deleting file from BVM server created during File Upload
     *
     * @param fileName
     * @return
     */
    @RequestMapping(value = "/sd/{fileName}/download", method = RequestMethod.GET)
    public ResponseEntity<Object> downloadFile(@PathVariable("fileName") String fileName) {
        if (fileName == null) {
            throw new ValidationException("file.not.found");
        }
        try {
            File file = new File(evmServerFilePath + fileName);
            if (file.exists()) {
                byte[] document = FileCopyUtils.copyToByteArray(file);
                return ResponseEntity
                        .ok()
                        .contentLength(document.length)
                        .contentType(
                                MediaType.parseMediaType("application/octet-stream"))
                        .body(new InputStreamResource(new ByteArrayInputStream(document)));
            }
        } catch (Exception e) {
            log.error("Error while downloading file ", e.getLocalizedMessage());
            throw new ServerException(e.getMessage());
        }
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/device/{deviceid}/flowExporter")
    public ResponseEntity<Object> getFlowExporter(@PathVariable("deviceid") Long deviceId) {
        validateAndReturnDevice(deviceId);
        JSONObject response = new JSONObject();
        FlowExporter flowExporterDB = flowExporterRepository.findByDeviceId(deviceId);
        JSONObject flowExporterjsonObject = new JSONObject();
        try {
            if (flowExporterDB != null) {
                flowExporterjsonObject.put("id", flowExporterDB.getId());
                flowExporterjsonObject.put("name", flowExporterDB.getName());
                flowExporterjsonObject.put("transportType", flowExporterDB.getTransportType());
                JSONObject sdManagementPortjsonObject = new JSONObject();
                sdManagementPortjsonObject.put("id", flowExporterDB.getSdManagementPort().getId());
                sdManagementPortjsonObject.put("name", flowExporterDB.getSdManagementPort().getName());
                sdManagementPortjsonObject.put("speed", flowExporterDB.getSdManagementPort().getSpeed());
                flowExporterjsonObject.put("sdManagementPort", sdManagementPortjsonObject);
                flowExporterjsonObject.put("sdTransportPort", flowExporterDB.getSdTransportPort());
                flowExporterjsonObject.put("ipAdress", flowExporterDB.getIpAdress());
                flowExporterjsonObject.put("cPlaneIdleTimer", flowExporterDB.getCPlaneIdleTimer());
                flowExporterjsonObject.put("pen", flowExporterDB.getPen());
            }
            response.put("flowExporter", flowExporterjsonObject);
            List<PhysicalInterface> physicalInterfaceList = physicalInterfaceRepository.findByDeviceId(deviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
            List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(deviceId, profileMapping.getProfile().getId());
            ingressPorts.forEach(port -> {
                if (physicalInterfaceList.contains(port.getPhysicalInterface())) {
                    physicalInterfaceList.remove(port.getPhysicalInterface());
                }
            });
            JSONArray sdMngPortsArray = new JSONArray();
            physicalInterfaceList.forEach(physicalInterface -> {
                JSONObject sdPortJsonObject = new JSONObject();
                try {
                    sdPortJsonObject.put("id", physicalInterface.getId());
                    sdPortJsonObject.put("name", physicalInterface.getName());
                    sdPortJsonObject.put("speed", physicalInterface.getSpeed());
                    sdMngPortsArray.put(sdPortJsonObject);
                } catch (JSONException e) {
                    log.error(e.getMessage());
                }
            });
            response.put("availableManagementPorts", sdMngPortsArray);
        } catch (JSONException e) {
            log.error(e.getMessage());
        }
        return new ResponseEntity<>(response.toString(), HttpStatus.OK);
    }

    /**
     * This method fetches flex match packet header structure
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/flexMatchjson")
    public ResponseEntity<Object> getFlexMatchHeaderStructure() {
        JSONObject jsonHeaderObject = new JSONObject();
        try {
            ApplicationConstant applicationConstantFlexMatch = featureConstantsRepository.findByName(FlexMatchHeaderJson.FLEX_MATCH_HEADER_KEY);
            String fmHeaderStackJsonForUi;
            if (applicationConstantFlexMatch != null && applicationConstantFlexMatch.getConstantValue() != null) {
                fmHeaderStackJsonForUi = applicationConstantFlexMatch.getConstantValue();
            } else {
                fmHeaderStackJsonForUi = FlexMatchHeaderJson.FLEX_MATCH_HEADER_INITIAL_JSON;
            }
            if (fmHeaderStackJsonForUi != null) {
                JSONObject jObject = new JSONObject(fmHeaderStackJsonForUi);
                if (jObject != null && jObject.has(HEADERS_KEY) && jObject.get(HEADERS_KEY) instanceof JSONArray) {
                    JSONArray headerArray = new JSONArray();
                    JSONArray jsonArray = (JSONArray) jObject.get(HEADERS_KEY);
                    if (jsonArray != null) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = new JSONObject();
                            JSONObject headerObj = jsonArray.getJSONObject(i);
                            Iterator<String> keysItr = headerObj.keys();
                            if (headerObj.has(IS_SUPPORTED_KEY)) {
                                boolean isSupported = (Boolean) headerObj.get(IS_SUPPORTED_KEY);
                                if (!isSupported) {
                                    continue;
                                }
                            }
                            while (keysItr.hasNext()) {
                                String key = keysItr.next();
                                if (key.equals(SUB_HEADERS_KEY)) {
                                    JSONArray subHeaderArrayUpdated = new JSONArray();
                                    JSONArray subHeaderArrayOriginal = (JSONArray) headerObj.get(SUB_HEADERS_KEY);
                                    if (subHeaderArrayOriginal != null) {
                                        for (int j = 0; j < subHeaderArrayOriginal.length(); j++) {
                                            JSONObject subHeaderObj = subHeaderArrayOriginal.getJSONObject(j);
                                            if (subHeaderObj.has(IS_SUPPORTED_KEY)) {
                                                boolean isSupported = (Boolean) subHeaderObj.get(IS_SUPPORTED_KEY);
                                                if (isSupported) {
                                                    subHeaderArrayUpdated.put(subHeaderObj);
                                                }
                                            } else {
                                                subHeaderArrayUpdated.put(subHeaderObj);
                                            }
                                        }
                                    }
                                    jsonObject.put(SUB_HEADERS_KEY, subHeaderArrayUpdated);
                                } else if (key.equals(FIELDS_KEY)) {
                                    JSONArray fieldArrayUpdated = new JSONArray();
                                    JSONArray fieldArrayOriginal = (JSONArray) headerObj.get(FIELDS_KEY);
                                    if (fieldArrayOriginal != null) {
                                        for (int j = 0; j < fieldArrayOriginal.length(); j++) {
                                            JSONObject fieldObj = fieldArrayOriginal.getJSONObject(j);
                                            if (fieldObj.has(IS_SUPPORTED_KEY)) {
                                                boolean isSupported = (Boolean) fieldObj.get(IS_SUPPORTED_KEY);
                                                if (isSupported) {
                                                    fieldArrayUpdated.put(fieldObj);
                                                }
                                            } else {
                                                fieldArrayUpdated.put(fieldObj);
                                            }
                                        }
                                    }
                                    jsonObject.put(FIELDS_KEY, fieldArrayUpdated);
                                } else {
                                    jsonObject.put(key, headerObj.get(key));
                                }
                            }
                            headerArray.put(jsonObject);
                        }
                    }
                    jsonHeaderObject.put(HEADERS_KEY, headerArray);
                }
            }
        } catch (JSONException e) {
            log.error("Error while parsing FlexMatchHeaderJson, {} ", e.getMessage());
        }
        return new ResponseEntity<>(jsonHeaderObject.toString(), HttpStatus.OK);
    }


    /**
     * This method is used to import and save the template policies from the file system
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(value = "/import", method = RequestMethod.GET, produces = "application/json")
    private ResponseEntity<Object> importTemplatePolicies() {
        List<String> list = Lists.newArrayList();
        try {
            File directory = new File(evmFlexMatchTemplateServerPath);
            if (directory != null && directory.isDirectory() && directory.exists()) {
                log.debug("Importing Template Policies.");
                String[] myFiles = directory.list((directoryObj, fileName) -> (fileName.toLowerCase()).endsWith(".json"));
                if (myFiles != null) {
                    log.debug("Number of template files found {}", myFiles.length);
                    list.addAll(Arrays.asList(myFiles));
                }
            } else {
                log.debug("Template directory does not exist.");
            }
        } catch (Exception e) {
            log.error("Failed to get Firmware version due to {}", e.getMessage());
        }

        if (list != null && !list.isEmpty()) {
            List<Long> policyIds = Lists.newArrayList();
            ObjectMapper mapper = new ObjectMapper();
            for (String fileName : list) {
                try {
                    File jsonInputFile = new File(evmFlexMatchTemplateServerPath + File.separator + fileName);
                    TemplatePolicyRequest templatePolicyRequest = mapper.readValue(jsonInputFile, TemplatePolicyRequest.class);
                    TemplatePolicy templatePolicy = null;
                    if (templatePolicyRequest.getSlxFlexMatchProfile() != null) {
                        templatePolicyRequest = flushIdsForPolicy(templatePolicyRequest);
                        templatePolicy = templatePolicyRequest.getSlxFlexMatchProfile();

                        List<TemplatePolicy> templatePoliciesInDb = templatePolicyRepository.findByName(templatePolicy.getName());
                        if (!templatePoliciesInDb.isEmpty()) {
                            log.trace("Template policy already configured with name {}, skipping.", templatePolicy.getName());
                            continue;
                        }
                        ((FlexMatchProfile) templatePolicy).setIsDefault(true);
                        templatePolicy.setDeviceModel(templatePolicyRequest.getDeviceModel() != null ? templatePolicyRequest.getDeviceModel() : null);
                        isValidHeaderField(templatePolicyRequest);
                    }
                    policyIds.addAll(managerBuilder.getOperationsFactory(new Device()).getTemplatePolicyManager(templatePolicy).saveOrCommitPolicies(Sets.newHashSet(templatePolicy), TemplatePolicyController.COMMIT));
                } catch (Exception e) {
                    log.error("Failed to save the template, {}", e.getMessage());
                }
            }
            return new ResponseEntity<>(policyIds, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * This method is used to validate the valid header field for SLX 9850 device
     *
     * @param templatePolicyRequest
     * @return
     */
    protected boolean isValidHeaderField(TemplatePolicyRequest templatePolicyRequest) {
        if (templatePolicyRequest.getDeviceModel() != null && templatePolicyRequest.getDeviceModel().equalsIgnoreCase(FlexMatchProfile.SLX_9850)) {
            (templatePolicyRequest.getSlxFlexMatchProfile()).getFlexHeaders().forEach(flexHeader -> {
                flexHeader.getFlexHeaderFields().forEach(flexHeaderField -> {
                    Integer validOffset = (flexHeaderField.getCustomOffset() != null && flexHeaderField.getOffset() != null && flexHeaderField.getCustomOffset() > -1) ? flexHeaderField.getCustomOffset() + flexHeaderField.getOffset() : flexHeaderField.getOffset();
                    if ((validOffset < TemplatePolicyController.MIN_SLX_9850_OFFSET || validOffset > TemplatePolicyController.MAX_SLX_9850_OFFSET)) {
                        log.error("FlexMatch profile field Offset range is invalid.");
                        throw new ValidationException("policy.save.fieldOffsetRangeInvalid");
                    }
                });
            });
        }
        return true;
    }

    /**
     * This method is used to clear ids of template policy
     *
     * @param templatePolicyRequest
     * @return
     */
    private TemplatePolicyRequest flushIdsForPolicy(TemplatePolicyRequest templatePolicyRequest) {
        FlexMatchProfile slxFlexMatchProfile = templatePolicyRequest.getSlxFlexMatchProfile();
        if (slxFlexMatchProfile != null) {
            slxFlexMatchProfile.clearId();
            slxFlexMatchProfile.getFlexHeaders().stream().forEach(flexHeader -> {
                flexHeader.clearId();
                flexHeader.getFlexHeaderFields().stream().forEach(flexHeaderField -> {
                    flexHeaderField.clearId();
                });
            });
        }
        return templatePolicyRequest;
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }

    /**
     * Displays the TACACS server configuration.
     *
     * @return
     */
    @RequestMapping(value = "/tacacs/serverinfo")
    public ResponseEntity<Object> getTacacsServerInfo() {
        if (Strings.isNullOrEmpty(tacacsServerIp)) {
            throw new ValidationException("TACACS server is not configured.");
        }
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("IP", tacacsServerIp);
        } catch (JSONException e) {
            log.error("Failed to generate TACACS server info JSON. {}", e.getMessage());
        }
        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    /**
     * Method fetches the devices by type and reconciled and perform RBAC.
     *
     * @return ResponseEntity<Object> This returns list of devices
     */
    @RequestMapping(value = "/packettruncation/devices")
    public ResponseEntity<Object> getPacketTruncationDevices() {
        JSONArray devicesResponseArray = new JSONArray();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            List<Device> devices = deviceRepository.findAllByIdsAndTypeAndReconciledAndProfileSet(stablenetDeviceIds, Lists.newArrayList(Device.Type.SLX));
            List<Long> portsInGlobalPolicies = headerStrippingModulePolicyRepository.findPortIdsByPortType(Port.Type.SERVICE_PORT);
            portsInGlobalPolicies.addAll(gtpDeEncapsulationModulePolicyRepository.findPortIdsByPortType(Port.Type.SERVICE_PORT));
            List<Object[]> portIdAndPtIdMappings = packetTruncationMappingRepository.findPortIds();
            List<Object[]> portGroupIdAndPtIdMappings = packetTruncationMappingRepository.findPortGroupIds();
            devices.stream().forEach(device -> {
                if (!Strings.isNullOrEmpty(device.getOs()) && genericHelper.isSLXVersionValid(device.getOs(), slxPacketTruncationSupportedVersion) >= 0) {
                    try {
                        JSONArray interfaceArray = new JSONArray();
                        Set<PortGroup> portGroups = new HashSet<>(portGroupRepository.findByDeviceIdAndWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE)));
                        List<Long> portGroupMemberIds = Lists.newArrayList();
                        portGroups.stream().forEach(portGroup -> {
                            portGroupMemberIds.addAll(portGroup.getPorts().stream().map(ManagedObject::getId).collect(Collectors.toSet()));
                        });
                        device.getModules().forEach(module -> {
                            List<Long> portIds = module.getPorts().stream().filter(port -> Port.Type.SERVICE_PORT == port.getType() && WorkflowParticipant.WorkflowStatus.ERROR != port.getWorkflowStatus() && !portGroupMemberIds.contains(port.getId())).map(ManagedObject::getId).collect(Collectors.toList());
                            if (!portIds.isEmpty()) {
                                List<BigInteger> portIdsInPolicy = flowRepository.findManagedObjectIdsInIngressPortMapping(portIds);
                                portIds.removeAll(portIdsInPolicy.stream().map(id -> id.longValue()).collect(Collectors.toList()));
                                if (!portsInGlobalPolicies.isEmpty()) {
                                    portIds.removeAll(portsInGlobalPolicies);
                                }
                                if (!portIds.isEmpty()) {
                                    List<Port> ports = Lists.newArrayList(portRepository.findAll(portIds));
                                    Collections.sort(ports);
                                    ports.forEach(port -> {
                                        try {
                                            JSONObject interfaceJsonObject = new JSONObject();
                                            interfaceJsonObject.put("id", port.getId());
                                            interfaceJsonObject.put("name", port.getName());
                                            portIdAndPtIdMappings.stream().forEach(objects -> {
                                                Object[] array = objects;
                                                if (array != null && array[0] != null && port.getId().longValue() == Long.parseLong(array[0].toString())) {
                                                    try {
                                                        interfaceJsonObject.put("ptProfileId", array[1]);
                                                    } catch (JSONException e) {
                                                        log.error("Failed to generate the packet truncation device JSON for port. {}", e.getMessage());
                                                    }
                                                }
                                            });
                                            interfaceJsonObject.put("type", PORT);
                                            interfaceArray.put(interfaceJsonObject);
                                        } catch (JSONException e) {
                                            log.error("Failed to generate the packet truncation device JSON for port. {}", e.getMessage());
                                        }
                                    });
                                }
                            }
                        });
                        List<Long> portGroupIds = portGroups.stream().filter(portGroup -> WorkflowParticipant.WorkflowStatus.ERROR != portGroup.getWorkflowStatus() && Port.Type.SERVICE_PORT == portGroup.getType()).map(ManagedObject::getId).collect(Collectors.toList());
                        if (!portGroupIds.isEmpty()) {
                            List<BigInteger> portGroupIdsInPolicy = flowRepository.findManagedObjectIdsInIngressPortMapping(portGroupIds);
                            portGroupIds.removeAll(portGroupIdsInPolicy.stream().map(id -> id.longValue()).collect(Collectors.toList()));
                            if (!portGroupIds.isEmpty()) {
                                List<PortGroup> portGroupsFiltered = Lists.newArrayList(portGroupRepository.findAll(portGroupIds));
                                portGroupsFiltered.stream().filter(portGroup -> WorkflowParticipant.WorkflowStatus.ERROR != portGroup.getWorkflowStatus() && Port.Type.SERVICE_PORT == portGroup.getType()).collect(Collectors.toList()).forEach(portGroup -> {
                                    try {
                                        JSONObject interfaceJsonObject = new JSONObject();
                                        interfaceJsonObject.put("id", portGroup.getId());
                                        interfaceJsonObject.put("name", portGroup.getName());
                                        portGroupIdAndPtIdMappings.stream().forEach(objects -> {
                                            Object[] array = objects;
                                            if (array != null && array[0] != null && portGroup.getId().longValue() == Long.parseLong(array[0].toString())) {
                                                try {
                                                    interfaceJsonObject.put("ptProfileId", array[1]);
                                                } catch (JSONException e) {
                                                    log.error("Failed to generate the packet truncation device JSON for port. {}", e.getMessage());
                                                }
                                            }
                                        });
                                        interfaceJsonObject.put("type", PORT_CHANNEL);
                                        interfaceArray.put(interfaceJsonObject);
                                    } catch (JSONException e) {
                                        log.error("Failed to generate the packet truncation device JSON for port channel. {}", e.getMessage());
                                    }
                                });
                            }
                        }
                        if (interfaceArray.length() > 0) {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("id", device.getId());
                            jsonObject.put("name", device.getName());
                            jsonObject.put("interfaces", interfaceArray);
                            devicesResponseArray.put(jsonObject);
                        }
                    } catch (JSONException e) {
                        log.error("Failed to generate the device JSON for packet truncation. {}", e.getMessage());
                    }
                }
            });
        }
        return new ResponseEntity<>(devicesResponseArray.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/{user}/sessionTimeout", method = RequestMethod.GET)
    public ResponseEntity<SessionTimeout> getSessionTimeout(@PathVariable("user") String userName) {
        SessionTimeout sessionTimeout = sessionTimeoutRespository.findByUserName(userName);
        if (sessionTimeout == null) {
            sessionTimeout = new SessionTimeout();
            sessionTimeout.setUserName(userName);
            sessionTimeout.setTimeOut(defaultSessionTimeout);
        }
        return new ResponseEntity<>(sessionTimeout, HttpStatus.OK);
    }

    @RequestMapping(value = "/sessionTimeout", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<SessionTimeout> setSessionTimeout(@RequestBody SessionTimeout sessionTimeout) {
        if (!sessionTimeout.isValid()) {
            throw new ValidationException("User name and timeout cannot be empty. Timeout cannot be 0");
        }
        SessionTimeout exitingSessionTimeout = sessionTimeoutRespository.findByUserName(sessionTimeout.getUserName());
        if (exitingSessionTimeout != null) {
            exitingSessionTimeout.setTimeOut(sessionTimeout.getTimeOut());
            sessionTimeoutRespository.save(exitingSessionTimeout);
            return new ResponseEntity<>(exitingSessionTimeout, HttpStatus.OK);
        } else {
            sessionTimeoutRespository.save(sessionTimeout);
            return new ResponseEntity<>(sessionTimeout, HttpStatus.OK);
        }
    }

    @Inject
    private DeviceCustomRepository deviceCustomRepository;

    @RequestMapping(value = "/deviceversioninfo")
    public ResponseEntity<Object> getDeviceVersionInfo() {
        JSONArray devicesResponseArrayInfo = new JSONArray();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            List<DeviceSnapshot> deviceSnapshots = deviceCustomRepository.findDeviceInfo(stablenetDeviceIds, Lists.newArrayList(Device.Type.MLXE.toString()));
            JSONObject jsonObjectDeviceMlxe = createDeviceInfoJson(deviceSnapshots, Device.Type.MLXE.toString());
            if (jsonObjectDeviceMlxe != null) {
                devicesResponseArrayInfo.put(jsonObjectDeviceMlxe);
            }
            List<DeviceSnapshot> deviceSnapshotsSlx = deviceCustomRepository.findDeviceInfo(stablenetDeviceIds, Lists.newArrayList(Device.Type.SLX.toString()));
            List<DeviceSnapshot> validSlxDevices = Lists.newArrayList();
            deviceSnapshotsSlx.forEach(deviceSnapshot -> {
                if (genericHelper.isSLXVersionValid(deviceSnapshot.getOs(), slxTelemetrySupportedVersion) >= 0) {
                    if (deviceSnapshot.isProfileConfigured()) {
                        validSlxDevices.add(deviceSnapshot);
                    }
                } else if (!Strings.isNullOrEmpty(deviceSnapshot.getOs())) {
                    validSlxDevices.add(deviceSnapshot);
                }
            });
            JSONObject jsonObjectDeviceSlx = createDeviceInfoJson(validSlxDevices, Device.Type.SLX.toString());
            if (jsonObjectDeviceSlx != null) {
                devicesResponseArrayInfo.put(jsonObjectDeviceSlx);
            }
        }
        return new ResponseEntity<>(devicesResponseArrayInfo.toString(), HttpStatus.OK);
    }

    private JSONObject createDeviceInfoJson(List<DeviceSnapshot> deviceSnapshots, String deviceType) {
        if (!deviceSnapshots.isEmpty()) {
            Iterator<DeviceSnapshot> deviceIterator = deviceSnapshots.iterator();
            Map<String, Set<DeviceSnapshot>> deviceVersionSetMap = Maps.newHashMap();
            while (deviceIterator.hasNext()) {
                DeviceSnapshot deviceSnapshot = deviceIterator.next();
                Set<DeviceSnapshot> deviceSnapshotSet = deviceVersionSetMap.get(deviceSnapshot.getOs());
                if (deviceSnapshotSet == null) {
                    deviceSnapshotSet = Sets.newHashSet();
                }
                deviceSnapshotSet.add(deviceSnapshot);
                deviceVersionSetMap.put(deviceSnapshot.getOs(), deviceSnapshotSet);
            }
            try {
                if (!deviceVersionSetMap.isEmpty()) {
                    JSONObject jsonObjectDevice = new JSONObject();
                    JSONArray devicesResponseArray = new JSONArray();
                    deviceVersionSetMap.forEach((version, deviceSnapshotsSet) -> {
                        try {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("version", version);
                            jsonObject.put("count", deviceSnapshotsSet.size());
                            jsonObject.put("devices", deviceSnapshotsSet);
                            devicesResponseArray.put(jsonObject);
                        } catch (JSONException e) {
                        }
                    });
                    jsonObjectDevice.put("type", deviceType);
                    jsonObjectDevice.put("versionInfo", devicesResponseArray);
                    return jsonObjectDevice;
                }
            } catch (JSONException e) {
            }
        }
        return null;
    }
}