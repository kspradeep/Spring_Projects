package com.brocade.bvm.api.manager;

import com.brocade.bvm.api.model.HostInfoRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.model.firmware.FirmwareHistoryObject;

import java.util.List;

public interface FirmwareManager {
    Long upgradeFirmware(List<DeviceFirmwareInfo> deviceFirmwareInfos) throws ValidationException;
    Long saveHostInfo(HostInfoRequest hostInfoRequest);
    Long rebootUpgradedDevice(List<Long> ids) throws ValidationException;
    List<FirmwareHistoryObject> getFirmwareHistory(Device device);
}
