package com.brocade.bvm.api.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PacketTruncationResponse {

    private Long deviceId;

    private String deviceName;

    private boolean ptSuccessful;

    private boolean policySuccessful;

    private String ptErrorResult;

    private String policyErrorResult;
}
