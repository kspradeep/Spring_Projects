package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.factory.SDFlowFactory;
import com.brocade.bvm.api.manager.sessiondirector.SdConfigurationManager;
import com.brocade.bvm.api.model.*;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.brocade.bvm.model.exception.ServerException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The SdDeviceController class implements methods to perform CRUD operations of ports, device configuration for SD version 3.5 and above
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/device/sd/{deviceid}/")
public class SdDeviceController {

    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String CLEANUP = "cleanup";
    public static final String ROLLBACK = "rollback";
    public static final String DEFAULT_PORT_GROUP = "default-port-group";
    public static final String INGRESS = "ingress";
    public static final String EGRESS = "egress";

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PhysicalInterfaceRepository physicalInterfaceRepository;

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    protected EgressPortGroupRepository egressPortGroupRepository;

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    protected ProfileMappingRepository profileMappingRepository;

    @Inject
    private ProfileInterfaceMappingRepository profileInterfaceMappingRepository;

    @Inject
    private SdConfigurationManager sdConfigurationManager;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private GlobalConfigRepository globalConfigRepository;

    @Inject
    private IngressPortRepository ingressPortRepository;

    @Inject
    protected PortRepository portRepository;

    @Inject
    private ProfileRepository profileRepository;

    @Inject
    private ActiveInterfaceRepository activeInterfaceRepository;

    @Inject
    private FilterPolicyRepository filterPolicyRepository;

    @Inject
    private SamplingPolicyRepository samplingPolicyRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    protected FlowExporterRepository flowExporterRepository;

    /**
     * This method is used to pair and unpair the MLXe/SLX with SD
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.POST, value = "/pair/profile", consumes = "application/json")
    public ResponseEntity<Object> pairDevice(@RequestParam(value = "action", required = false) String action, @PathVariable("deviceid") Long deviceId,
                                             @RequestBody SdPairProfileRequest pairProfileRequest) throws JSONException {
        log.debug("********** Start: pair & Profile device **********");
        ResponseEntity responseEntity = null;
        validateAndReturnDevice(deviceId);
        if (pairProfileRequest == null) {
            throw new ValidationException("sd.invalid.pair.device");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action == null) {
            Profile validProfile = profileRepository.findByDeviceProfileId(deviceId, pairProfileRequest.getProfileId());
            //Validating configuration before updating profile.
            if (validProfile != null) {
                List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findAllActiveInterfaceByDeviceId(deviceId);
                if (!activeInterfaces.isEmpty())
                    throw new ValidationException("delete.interface.policy");

                List<FilterPolicy> filterPolicies = filterPolicyRepository.findAllByDeviceId(deviceId);
                if (!filterPolicies.isEmpty())
                    throw new ValidationException("delete.filter.policy");

                List<SamplingPolicy> samplingPolicies = samplingPolicyRepository.findAllByDeviceId(deviceId);
                if (!samplingPolicies.isEmpty())
                    throw new ValidationException("delete.sampling.policy");

                List<SdPortGroup> sdPortGroups = egressPortGroupRepository.findAllByDeviceId(deviceId);
                if (!sdPortGroups.isEmpty())
                    if (!(sdPortGroups.size() == 1 && DEFAULT_PORT_GROUP.equalsIgnoreCase(sdPortGroups.get(0).getName())))
                        throw new ValidationException("delete.portgroup");

            }
            PairedDevice oldPairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);

            boolean isPairedDeviceSame = oldPairedDevice != null && (pairProfileRequest.getTargetDeviceId() == oldPairedDevice.getTargetDevice().getId());
            boolean isProfileSame = profileMapping != null && (pairProfileRequest.getProfileId().longValue() == profileMapping.getProfile().getId());

            if (validProfile == null) {
                log.debug("Invalid Profile selected for the SD {}", deviceId);
                throw new ValidationException("sd.profile.invalid");
            }
            if (isPairedDeviceSame && isProfileSame) {
                log.debug("No parameters changed to apply on SD {}", deviceId);
                throw new ValidationException("sd.paired.profile.same");
            }
            if (!isPairedDeviceSame) {
                PairedDevice pairedDeviceTarget = sdPairedDeviceRepository.findByTargetDeviceId(pairProfileRequest.getTargetDeviceId());
                if (pairedDeviceTarget != null && pairedDeviceTarget.getDevice().getId().longValue() != deviceId.longValue()) {
                    if (!pairedDeviceTarget.getDevice().isDeleted()) {
                        log.error("Selected target device id {} is already paired with SD device id {}.", pairProfileRequest.getTargetDeviceId(), pairedDeviceTarget.getDevice().getId());
                        throw new ValidationException("device.already.paired");
                    } else {
                        log.debug("SD device id {} is paired with a deleted target device id {}.", pairedDeviceTarget.getDevice().getId(), pairProfileRequest.getTargetDeviceId());
                    }
                }
                PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
                if (pairedDevice != null) {
                    sdConfigurationManager.deletePairedDevice(pairedDevice);
                }
                Long jobId = sdConfigurationManager.savePairedDevice(pairProfileRequest.getTargetDeviceId(), deviceId);
                log.debug("Device is paired successfully, device Id {}", deviceId);
                responseEntity = new ResponseEntity<>(jobId, HttpStatus.OK);
            }
            if (!isProfileSame) {
                sdConfigurationManager.deletePairedProfile(deviceId);
                Job jobResult = sdConfigurationManager.saveProfile(deviceId, pairProfileRequest.getProfileId());

                if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
                    log.debug("Profile set successfully for SD {}", deviceId);
                    responseEntity = new ResponseEntity<>(jobResult.getId(), HttpStatus.OK);
                } else {
                    log.debug("Profile set failed for SD {}", deviceId);
                    throw new ValidationException(jobResult.getJobResult());
                }
            }
        } else {
            Long jobId = sdConfigurationManager.unPairDevice(deviceId);
            log.debug("Successfully Unpaired the selected device with SD {}", deviceId);
            responseEntity = new ResponseEntity<>(jobId, HttpStatus.OK);
        }
        log.debug("********** End: pair & Profile device for SD {} **********", deviceId);
        return responseEntity;
    }

    /**
     * This method is used to save the global configuration of Session Director
     *
     * @param deviceId
     * @param globalConfig
     * @return
     * @throws JSONException
     */
    @RequestMapping(method = RequestMethod.POST, value = "/global", consumes = "application/json")
    public ResponseEntity<Object> setGlobalConfig(@PathVariable("deviceid") Long deviceId,
                                                  @RequestBody GlobalConfig globalConfig) throws JSONException {
        log.debug("********** Start: set global configuration **********");
        Device device = validateAndReturnDevice(deviceId);
        if (device != null && !device.getType().equals(Device.Type.SD)) {
            throw new ValidationException("sd.invalid.device.id");
        } else if (globalConfig == null) {
            throw new ValidationException("sd.invalid.global");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (globalConfig.getRxTxSplitStatus() || globalConfig.getMode().equals(GlobalConfig.Mode.MULTINODE)) {
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
            //TODO instead of checking the profile Id's need to check current profile and if it's interface contains s11-s1u-gngp
            if (globalConfig.getRxTxSplitStatus() && (profileMapping.getProfile().getProfileId() != 13 && profileMapping.getProfile().getProfileId() != 14)) {
                throw new ValidationException("sd.rx.tx.invalid");
            } else {
                if (profileMapping.getProfile().getName().contains("MASK_DEDUPE")) {
                    throw new ValidationException("sd.set.mode.invalid");
                }
            }
        }
        GlobalConfig globalConfigDb = globalConfigRepository.findByDeviceId(deviceId);
        Job jobResult = null;
        if (globalConfigDb != null) {
            boolean isModeSame = globalConfig.getMode() != null && globalConfigDb != null && globalConfigDb.getMode().equals(globalConfig.getMode());
            boolean isFcrSame = globalConfig.getFcrStatus() != null && globalConfigDb != null && globalConfig.getFcrStatus() == globalConfigDb.getFcrStatus();
            boolean isS11DropSame = globalConfig.getS11DropStatus() != null && globalConfigDb != null && globalConfigDb.getS11DropStatus().equals(globalConfig.getS11DropStatus());
            boolean isRxTxSplitSame = globalConfig.getRxTxSplitStatus() != null && globalConfigDb != null && globalConfig.getRxTxSplitStatus() == globalConfigDb.getRxTxSplitStatus();
            boolean isFcrFileTimeSame = globalConfig.getFcrFileTime() != null && globalConfigDb != null && globalConfig.getFcrFileTime() == globalConfigDb.getFcrFileTime();
            boolean isSgiCorrelationSame = globalConfig.getSgiCorrelationStatus() != null && globalConfigDb != null && globalConfigDb.getSgiCorrelationStatus() == globalConfig.getSgiCorrelationStatus();
            boolean isSipPortSame = globalConfig.getSipPorts() != null && globalConfigDb != null && globalConfigDb.getSipPorts().containsAll(globalConfig.getSipPorts()) && globalConfig.getSipPorts().containsAll(globalConfigDb.getSipPorts());
            boolean isIpFragmentationSame = globalConfig.getIpFragmentationStatus() != null && globalConfigDb != null && globalConfig.getIpFragmentationStatus() == globalConfigDb.getIpFragmentationStatus();
            if (!isSipPortSame) {
                globalConfig.getSipPorts().forEach(port -> {
                    if (port < GlobalConfig.SIP_PORT_MIN_RANGE || port > GlobalConfig.SIP_PORT_MAX_RANGE) {
                        throw new ValidationException("sd.sip.port.valid.range");
                    }
                });
                if (globalConfig.getSipPorts().contains(GlobalConfig.SIP_PORT_DEFAULT)) {
                    throw new ValidationException("sd.global.config.sip.port.default");
                }
                if (globalConfig.getSipPorts().size() > GlobalConfig.SIP_PORTS_MAX_SIZE) {
                    throw new ValidationException("sd.max.sip.port");
                }
            }
            if (isModeSame && isFcrSame && isS11DropSame && isRxTxSplitSame && isFcrFileTimeSame && isSgiCorrelationSame && isSipPortSame && isIpFragmentationSame) {
                throw new ValidationException("sd.global.config.same");
            } else {
                jobResult = sdConfigurationManager.saveGlobalConfig(deviceId, globalConfig, isFcrSame, isSipPortSame);
                if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
                    return new ResponseEntity<>(jobResult.getId(), HttpStatus.OK);
                } else {
                    throw new ServerException(jobResult.getJobResult());
                }
            }
        }
        log.debug("********** End: set global configuration **********");
        return new ResponseEntity<>(jobResult.getId(), HttpStatus.OK);
    }

    /**
     * This method is used to save the SD running configuration.
     *
     * @param deviceId
     * @return
     * @throws JSONException
     */
    @RequestMapping(method = RequestMethod.GET, value = "/saveconfig")
    public ResponseEntity<Object> saveRunningConfig(@PathVariable("deviceid") Long deviceId) throws JSONException {
        log.debug("********** Start: save running config, id:{} **********", deviceId);
        Device device = validateAndReturnDevice(deviceId);
        if (device != null && !Device.Type.SD.equals(device.getType())) {
            throw new ValidationException("sd.invalid.device.id");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        Job jobResult = sdConfigurationManager.saveRunningConfig(deviceId);
        log.debug("********** End: save running config, id:{} **********", deviceId);
        if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(jobResult.getJobResult(), HttpStatus.EXPECTATION_FAILED);
        }

    }

    /**
     * This method gets called to fetch the global configuration
     *
     * @param deviceId
     * @return
     * @throws JSONException
     */
    @RequestMapping(method = RequestMethod.GET, value = "/global")
    public ResponseEntity<Object> getGlobalConfig(@PathVariable("deviceid") Long deviceId) throws JSONException {
        log.debug("********** Start: get global configuration, id:{}  **********", deviceId);
        Device device = validateAndReturnDevice(deviceId);
        //RBAC
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (!Device.Type.SD.equals(device.getType())) {
            throw new ValidationException("sd.config.invalid.device.id");
        }
        GlobalConfig globalConfig = sdConfigurationManager.getGlobalConfig(device);
        log.debug("********** End: get global configuration, id:{} **********", deviceId);
        return new ResponseEntity<>(globalConfig, HttpStatus.OK);
    }


    /**
     * This method is used to commit the port and policy configuration
     *
     * @param sdDeviceId
     * @param ports
     * @return ResponseEntity<Object> This returns the list of jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/port")
    public ResponseEntity<Object> commitPortsMarking(@RequestParam(value = "action", required = false) String action,
                                                     @PathVariable("deviceid") Long sdDeviceId, @RequestBody Set<Port> ports) {
        log.info("********** Start Ports marking: **********");
        validateAndReturnDevice(sdDeviceId);
        if (ports == null || ports.isEmpty()) {
            throw new ValidationException("port.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action != null) {
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            if (pairedDevice != null && pairedDevice.getTargetDevice() != null) {
                Policy policyOne = null;
                Policy policyTwo = null;
                Set<Policy> sdPolicies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(pairedDevice.getTargetDevice().getId(), true));

                if (!sdPolicies.isEmpty()) {
                    for (Policy policy : sdPolicies) {
                        if (policy.getName().contains("_one_")) {
                            policyOne = policy;
                        } else if (policy.getName().contains("_two_")) {
                            policyTwo = policy;
                        }
                    }
                }
                SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(pairedDevice.getDevice());
                Set<Port> egressPorts = Sets.newHashSet();
                if (EGRESS.equals(action)) {
                    List<Long> egressPortIds = ports.stream().filter(port -> port != null && port.getId() != null && port.getType() != null && port.getWorkflowStatus() != Port.WorkflowStatus.ERROR && port.getType() == Port.Type.EGRESS).map(Port::getId).collect(Collectors.toList());
                    egressPorts = Sets.newHashSet(portRepository.findAll(egressPortIds));
                }
                sdFlowFactory.validateUnMarkPorts(ports, policyTwo, egressPorts, action);

                Job job = sdFlowFactory.markPorts(ports, pairedDevice.getTargetDevice(), action);
                if (job != null) {
                    if (job.getStatus() == Job.Status.FAILED) {
                        return new ResponseEntity<>(job.getJobResult(), HttpStatus.EXPECTATION_FAILED);
                    } else {
                        //mark new ports
                        //add new ports, remove old ports and update policy
                        //unmarked old ports
                        //updating policyOne if the ingress ports are updated.
                        if (INGRESS.equals(action) && policyOne != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
                            List<Long> ingressPortIds = ports.stream().filter(port -> port != null && port.getId() != null && port.getType() != null && port.getWorkflowStatus() != Port.WorkflowStatus.ERROR && port.getType() == Port.Type.INGRESS).map(Port::getId).collect(Collectors.toList());
                            Set<Port> ingressPorts = Sets.newHashSet(portRepository.findAll(ingressPortIds));
                            job = sdFlowFactory.commitTargetPolicyOne(policyOne, pairedDevice.getTargetDevice(), null, null, ingressPorts, null, null);
                        }
                        if (EGRESS.equals(action) && policyTwo != null && (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS)) {
                            job = sdFlowFactory.removePortsFromPolicyTwoAndSd(policyTwo, pairedDevice.getDevice(), pairedDevice.getTargetDevice(), egressPorts);
                        }
                        if (job.getStatus() == Job.Status.CREATED || job.getStatus() == Job.Status.SUCCESS) {
                            job = sdFlowFactory.unMarkPorts(ports, pairedDevice.getTargetDevice());
                        }
                        if (job.getStatus() == Job.Status.FAILED) {
                            return new ResponseEntity<>(job.getJobResult(), HttpStatus.EXPECTATION_FAILED);
                        }
                        return new ResponseEntity<>(job.getId(), HttpStatus.OK);
                    }
                }
                return new ResponseEntity<>(HttpStatus.OK);
            }
        }
        throw new ValidationException("invalid.action");
    }

    /**
     * This method is used to recover the ports (MLXe/SLX)
     *
     * @param sdDeviceId
     * @param ports
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/port")
    public ResponseEntity<Object> recoverPorts(@RequestParam(value = "action", required = false) String action,
                                               @PathVariable("deviceid") Long sdDeviceId, @RequestBody List<Port> ports) {
        log.info("********** Start Ports marking: {} **********", action);
        validateAndReturnDevice(sdDeviceId);
        if (ports == null || ports.isEmpty()) {
            throw new ValidationException("port.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action != null) {
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            if (pairedDevice != null && pairedDevice.getTargetDevice() != null) {
                SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(pairedDevice.getDevice());
                if (ROLLBACK.equalsIgnoreCase(action)) {
                    List<Long> portIds = ports.stream().filter(port -> port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR).map(Port::getId).collect(Collectors.toList());
                    if (!portIds.isEmpty()) {
                        Job job = sdFlowFactory.recoverPorts(portIds, pairedDevice.getTargetDevice());
                        if (job != null && job.getStatus() == Job.Status.SUCCESS) {
                            return new ResponseEntity<>(job.getId(), HttpStatus.OK);
                        } else if (job != null) {
                            throw new ServerException(job.getJobResult());
                        }
                    }
                    return new ResponseEntity<>(HttpStatus.OK);
                }
            }
        }
        throw new ValidationException("invalid.action");
    }


    /**
     * This method is used to get the port and mlxe/slx policy configuration
     *
     * @param sdDeviceId
     * @return ResponseEntity<Object> This returns ports
     */
    @RequestMapping(method = RequestMethod.GET, value = "/port")
    public ResponseEntity<Object> getPorts(@PathVariable("deviceid") Long sdDeviceId) {
        log.info("********** get Ports and Policies **********");
        validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        List<Port> ports = new ArrayList<>();
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
        if (pairedDevice != null && pairedDevice.getTargetDevice() != null) {
            Device targetDevice = deviceRepository.findOne(pairedDevice.getTargetDevice().getId());
            if (targetDevice != null) {
                Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(targetDevice.getId(), false));

                // Collect ports used in MLXe policies created from MLXe tab
                Set<Port> portsFromPolicies = Sets.newHashSet();
                policies.forEach(policy -> {
                    policy.getFlows().forEach(flow -> {
                        portsFromPolicies.addAll(flow.getIngressPorts());
                        portsFromPolicies.addAll(flow.getEgressPorts());
                    });
                });

                // Collect all ports from paired MLXe
                targetDevice.getModules().forEach(module -> module.getPorts().stream().forEach(port -> {
                    ports.add(port);
                }));

                ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
                if (profileMapping != null) {
                    List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(sdDeviceId, profileMapping.getProfile().getId());
                    portsFromPolicies.addAll(ingressPorts.stream().map(IngressPort::getServicePort).collect(Collectors.toSet()));
                }

                // Remove the ports used in MLXe policies created from MLXe tab and used as servce port in SD ingress port from all ports of paired MLXe
                ports.removeAll(portsFromPolicies);
            }
        }
        Collections.sort(ports);
        return new ResponseEntity<>(ports, HttpStatus.OK);
    }

    /**
     * This method is used to commit the port and policy configuration
     *
     * @param action
     * @param sdDeviceId
     * @param sdPortPolicyParameter
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/portpolicy")
    public ResponseEntity<Object> commitPortsAndPolicies(@RequestParam(value = "action", required = false) String action,
                                                         @PathVariable("deviceid") Long sdDeviceId, @RequestBody SdPortPolicyParameter sdPortPolicyParameter) {
        log.info("********** Start PortsAndPolicies: {} **********", action);
        Device device = validateAndReturnDevice(sdDeviceId);
        if (sdPortPolicyParameter == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action != null) {
            if (device.getType() != Device.Type.SD) {
                throw new ValidationException("device.type.invalid");
            }
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);

            if (action.equalsIgnoreCase(COMMIT)) {
                Long jobId = sdFlowFactory.commitPortsAndPolicies(sdPortPolicyParameter, device);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("invalid.action");
    }

    /**
     * This method is used to delete/recover the port and policy configuration
     *
     * @param action
     * @param sdDeviceId
     * @param sdPortPolicyParameter
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/portpolicy")
    public ResponseEntity<Object> deletePortsAndPolicies(@RequestParam(value = "action", required = false) String action,
                                                         @PathVariable("deviceid") Long sdDeviceId, @RequestBody SdPortPolicyParameter sdPortPolicyParameter) {
        log.info("********** Start PortsAndPolicies: {} **********", action);
        Device device = validateAndReturnDevice(sdDeviceId);
        if (sdPortPolicyParameter == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action != null) {
            if (device.getType() != Device.Type.SD) {
                throw new ValidationException("device.type.invalid");
            }
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            if (action.equalsIgnoreCase(ROLLBACK)) {
                Long jobId = sdFlowFactory.recoverPortsAndPolicies(sdPortPolicyParameter, device);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            } else if (action.equalsIgnoreCase(CLEANUP)) {
                Long jobId = sdFlowFactory.deletePortsAndPolicies(sdPortPolicyParameter, device);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("invalid.action");
    }

    /**
     * This method is used to recover target policies
     *
     * @param action
     * @param sdDeviceId
     * @param sdPortPolicyParameter
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/policy")
    public ResponseEntity<Object> recoverTargetDevicePolicies(@RequestParam(value = "action", required = false) String action,
                                                              @PathVariable("deviceid") Long sdDeviceId, @RequestBody SdPortPolicyParameter sdPortPolicyParameter) {
        log.info("********** Start recoverTargetDevicePolicies: {} **********", action);
        Device device = validateAndReturnDevice(sdDeviceId);
        if (sdPortPolicyParameter == null) {
            throw new ValidationException("policy.data.invalid");
        }
        if (sdDeviceId < 1 || sdPortPolicyParameter.getTargetDevice() == null || sdPortPolicyParameter.getTargetDevice().getId() == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (action != null) {
            if (device.getType() != Device.Type.SD) {
                throw new ValidationException("device.type.invalid");
            }
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            if (action.equalsIgnoreCase(ROLLBACK)) {
                Long jobId = sdFlowFactory.recoverPolicies(sdPortPolicyParameter);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("invalid.action");
    }


    /**
     * This method is used to recover target policies
     *
     * @param action
     * @param sdDeviceId
     * @param port
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/sdport")
    public ResponseEntity<Object> recoverSdEgressPorts(@RequestParam(value = "action", required = false) String action,
                                                       @PathVariable("deviceid") Long sdDeviceId, @RequestBody EgressPort port) {
        log.info("********** Start recoverSdEgressPorts: {} **********", action);
        Device device = validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (port == null) {
            throw new ValidationException("port.data.invalid");
        }
        if (action != null) {
            if (device.getType() != Device.Type.SD) {
                throw new ValidationException("device.type.invalid");
            }
            PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
            if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
                log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
                throw new ValidationException("sd.invalid.unpair");
            } else if (profileMapping == null) {
                log.error("Session Director {}, profile is not configured.", sdDeviceId);
                throw new ValidationException("sd.profile.not.configured");
            }
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
            if (action.equalsIgnoreCase(ROLLBACK)) {
                Long jobId = sdFlowFactory.recoverSdEgressPorts(Lists.newArrayList(port), device);
                return new ResponseEntity<>(jobId, HttpStatus.OK);
            }
        }
        throw new ValidationException("invalid.action");
    }

    /**
     * This method is used to get the port and mlxe/slx policy configuration
     *
     * @param sdDeviceId
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.GET, value = "/portpolicy")
    public ResponseEntity<Object> getPortsAndPolicies(
            @PathVariable("deviceid") Long sdDeviceId) {
        log.info("********** get Ports and Policies **********");
        validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        SdPortPolicyParameter sdPortPolicyParameter = new SdPortPolicyParameter();
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
        if (pairedDevice != null && pairedDevice.getTargetDevice() != null && profileMapping != null) {
            List<SdPortParameter> sdPortParameters = new ArrayList<>();
            List<EgressPort> egressPorts = egressPortRepository.findByDeviceId(sdDeviceId);
            // Get ports of MLXe, which are not used by policies created from MLXe tab
            Device targetDevice = pairedDevice.getTargetDevice();
            Set<Policy> policies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(targetDevice.getId(), false));

            // Collect ports used in MLXe policies created from MLXe tab
            Set<Port> portsUsedInTargetDevice = Sets.newHashSet();
            policies.forEach(policy -> {
                policy.getFlows().forEach(flow -> {
                    portsUsedInTargetDevice.addAll(flow.getIngressPorts());
                    portsUsedInTargetDevice.addAll(flow.getEgressPorts());
                });
            });

            // Collect ports used in MLXe portGroups created from MLXe tab
            // TODO filter by createdFromSd in future, if portGroups are created in MLXe from SD context
            Set<PortGroup> portGroups = new HashSet<>(portGroupRepository.findByDeviceId(targetDevice.getId()));
            portGroups.forEach(portGroup -> {
                portGroup.getPorts().forEach(port -> {
                    portsUsedInTargetDevice.add(port);
                });
            });

            // Collect all ports from paired MLXe
            List<Port> ports = new ArrayList<>();
            targetDevice.getModules().forEach(module -> module.getPorts().stream().forEach(port -> {
                ports.add(port);
            }));

            // Remove the ports used in MLXe policies created from MLXe tab
            ports.removeAll(portsUsedInTargetDevice);

            ports.forEach(port -> {
                SdPortParameter sdPortParameter = new SdPortParameter();
                sdPortParameter.setId(port.getId());
                sdPortParameter.setName(port.getName());
                sdPortParameter.setType(port.getType());
                sdPortParameter.setPortNumber(port.getPortNumber());
                sdPortParameter.setWorkflowStatus(port.getWorkflowStatus());
                sdPortParameter.setWorkflowType(port.getWorkflowType());
                if (egressPorts != null) {
                    EgressPort egress = egressPorts.stream().filter(portObj -> (portObj.getSourcePort() != null && portObj.getSourcePort().getId() == port.getId())).findFirst().orElse(null);
                    if (egress != null) {
                        //Separating the tagged and untagged vlan id's for the UI
                        Set<Long> taggedVlanIds = new HashSet<Long>();
                        Set<Long> untaggedVlanIds = new HashSet<Long>();
                        egress.getVlanMappings().forEach(vlanMapping -> {
                            if (vlanMapping.isTagged()) {
                                taggedVlanIds.add(vlanMapping.getVlanId());
                            } else {
                                untaggedVlanIds.add(vlanMapping.getVlanId());
                            }
                        });
                        egress.setTaggedVlanIds(taggedVlanIds);
                        egress.setUntaggedVlanIds(untaggedVlanIds);
                        sdPortParameter.setEgressPort(egress);
                    }

                }
                sdPortParameters.add(sdPortParameter);
            });

            Collections.sort(sdPortParameters);

            Set<EgressPort> defaultPorts = egressPorts.stream().filter(portObj -> portObj.isDefault()).collect(Collectors.toSet());
            if (!defaultPorts.isEmpty()) {
                defaultPorts.forEach(egressPort -> {
                    SdPortParameter sdPortParameter = new SdPortParameter();
                    sdPortParameter.setName(egressPort.getName());
                    sdPortParameter.setType(Port.Type.EGRESS);
                    sdPortParameter.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                    //Separating the tagged and untagged vlan id's for the UI
                    Set<Long> taggedVlanIds = new HashSet<Long>();
                    Set<Long> untaggedVlanIds = new HashSet<Long>();
                    egressPort.getVlanMappings().forEach(vlanMapping -> {
                        if (vlanMapping.isTagged()) {
                            taggedVlanIds.add(vlanMapping.getVlanId());
                        } else {
                            untaggedVlanIds.add(vlanMapping.getVlanId());
                        }
                    });
                    egressPort.setTaggedVlanIds(taggedVlanIds);
                    egressPort.setUntaggedVlanIds(untaggedVlanIds);
                    sdPortParameter.setEgressPort(egressPort);
                    sdPortParameter.setWorkflowType(Job.Type.SD_PORT_GROUP_CREATE);
                    sdPortParameters.add(0, sdPortParameter);
                });
            }

            targetDevice.setModules(Sets.newHashSet());
            Set<Policy> sdPolicies = new HashSet<>(policyRepository.findByDeviceIdAndCreatedFromSd(targetDevice.getId(), true));

            if (!sdPolicies.isEmpty()) {
                sdPolicies.stream().forEach(policy -> {
                    if (policy.getName().contains("_one_")) {
                        sdPortPolicyParameter.setPolicyOne(policy);
                    } else if (policy.getName().contains("_two_")) {
                        sdPortPolicyParameter.setPolicyTwo(policy);
                    }
                });
            }

            List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(sdDeviceId, profileMapping.getProfile().getId());

            sdPortPolicyParameter.setIngressPorts(ingressPorts);
            sdPortPolicyParameter.setPhysicalInterfaceList(physicalInterfaceRepository.findByDeviceId(sdDeviceId));
            sdPortPolicyParameter.setSdPortParameters(sdPortParameters);
            sdPortPolicyParameter.setTargetDevice(targetDevice);
        }

        return new ResponseEntity<>(sdPortPolicyParameter, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to update the Egress ports for a SD device
     *
     * @param sdDeviceId
     * @param ports
     * @return ResponseEntity<Object> This returns job id
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/egressport")
    public ResponseEntity<Object> updateEgressPorts(@PathVariable("deviceid") Long sdDeviceId, @RequestBody List<EgressPort> ports) {
        log.info("********** update Egress Ports **********");
        Device device = validateAndReturnDevice(sdDeviceId);
        if (ports == null || ports.isEmpty()) {
            throw new ValidationException("port.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
        Long sdPortJobId = sdFlowFactory.updateEgressPort(device, ports);
        return new ResponseEntity<>(sdPortJobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to get the Egress port for a device
     *
     * @param sdDeviceId
     * @return ResponseEntity<Object> This returns SD Egress Ports
     */
    @RequestMapping(method = RequestMethod.GET, value = "/egressport")
    public ResponseEntity<Object> getEgressPorts(
            @PathVariable("deviceid") Long sdDeviceId) {
        log.info("********** get Egress Ports **********");
        validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        List<EgressPort> egressPorts = egressPortRepository.findByDeviceId(sdDeviceId);
        Collections.sort(egressPorts);
        return new ResponseEntity<>(egressPorts, HttpStatus.OK);
    }

    /**
     * This method is used to create port group, on the given SD device
     *
     * @param sdDeviceId
     * @param sdPortGroupRequest
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.POST, value = "/portgroup", consumes = "application/json")
    public ResponseEntity<Object> createPortGroup(@PathVariable("deviceid") Long sdDeviceId, @RequestBody SdPortGroupRequest sdPortGroupRequest) {
        log.debug("********** Start: SD create port group **********");
        Device device = validateAndReturnDevice(sdDeviceId);
        if (sdPortGroupRequest == null || sdPortGroupRequest.getSdPortGroup() == null) {
            throw new ValidationException("portGroup.data.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (device.getType() != Device.Type.SD) {
            throw new ValidationException("device.type.invalid");
        }
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", sdDeviceId);
            throw new ValidationException("sd.profile.not.configured");
        }
        SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
        SdPortGroup portGroup = sdPortGroupRequest.getSdPortGroup();
        portGroup.setDevice(device);
        List<ProfileInterfaceMapping> profileInterfaceMappings = sdPortGroupRequest.getProfileInterfaceMapping();
        if (profileInterfaceMappings != null) {
            List<ActiveInterface> inProgressOrErrorPoliciesOnDevice = activeInterfaceRepository
                    .findByDeviceAndInWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
            if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
                log.error("Cannot commit Port Group as an interface operation is in progress. pg id {}", portGroup.getId());
                throw new ValidationException("interface.operation.inprogress");
            }
            profileInterfaceMappings.forEach(interfaceMapping -> {
                List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findAllActiveInterfaceByDeviceIdAndInterfaceId(device.getId(), interfaceMapping.getId());
                if (!activeInterfaces.isEmpty()) {
                    log.error("Cannot commit Port Group as the selected interface is being used in another Port Group.");
                    throw new ValidationException("portGroup.interface.in.use");
                }
            });
        }
        Long jobId = managerBuilder.getOperationsFactory(device).getSdPortGroupManager().commitPortGroup(portGroup);
        if (profileInterfaceMappings != null) {
            for (ProfileInterfaceMapping interfaceMapping : profileInterfaceMappings) {
                ProfileInterfaceMapping profileInterfaceMapping = profileInterfaceMappingRepository.findOne(interfaceMapping.getId());
                ActiveInterface activeInterface = new ActiveInterface();
                activeInterface.setName(profileInterfaceMapping.getName());
                activeInterface.setPortGroup(portGroup);
                activeInterface.setProfileInterfaceMapping(profileInterfaceMapping);
                jobId = sdFlowFactory.commitInterfaceWithStatusPolling(activeInterface, device, COMMIT);
            }
        }
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to update existing port group on the selected SD device using id
     *
     * @param sdDeviceId
     * @param portGroupId
     * @param sdPortGroupRequest
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/portgroup/{portgroupid}")
    public ResponseEntity<Object> editPortGroup(
            @PathVariable(value = "deviceid") Long sdDeviceId,
            @PathVariable(value = "portgroupid") Long portGroupId,
            @RequestBody SdPortGroupRequest sdPortGroupRequest) {
        log.info("********** Start: SD edit port group **********");
        Device device = validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        if (device.getType() != Device.Type.SD) {
            throw new ValidationException("device.type.invalid");
        }
        if (sdPortGroupRequest == null) {
            throw new ValidationException("portGroup.data.invalid");
        }
        if (portGroupId == null || portGroupId < 1) {
            throw new ValidationException("portGroup.id.invalid");
        }
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(sdDeviceId);
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", sdDeviceId);
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", sdDeviceId);
            throw new ValidationException("sd.profile.not.configured");
        }
        SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(device);
        SdPortGroup sdPortGroup = sdPortGroupRequest.getSdPortGroup();
        sdPortGroup.setDevice(device);
        List<ProfileInterfaceMapping> profileInterfaceMappings = sdPortGroupRequest.getProfileInterfaceMapping();
        if (profileInterfaceMappings != null) {
            List<ActiveInterface> inProgressOrErrorPoliciesOnDevice = activeInterfaceRepository
                    .findByDeviceAndInWorkflowStatus(device.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.SUBMITTED));
            if (!inProgressOrErrorPoliciesOnDevice.isEmpty()) {
                log.error("Cannot commit Port Group as an interface operation is in progress. pg id {}", sdPortGroup.getId());
                throw new ValidationException("interface.operation.inprogress");
            }
            profileInterfaceMappings.forEach(interfaceMapping -> {
                List<Long> activeInterfaceIds = activeInterfaceRepository.findAllActiveInterfaceIdsByDeviceIdInterfaceIdAndPortGroupId(device.getId(), interfaceMapping.getId(), sdPortGroup.getId());
                if (!activeInterfaceIds.isEmpty()) {
                    log.error("Cannot commit Port Group as the selected interface is being used in another Port Group.");
                    throw new ValidationException("portGroup.interface.in.use");
                }
            });
        }
        Long jobId = 0L;
        SdPortGroup oldPortGroup = egressPortGroupRepository.findById(sdPortGroup.getId());
        if (oldPortGroup != null) {
            if (!(sdPortGroup.getLoadBalance() == oldPortGroup.getLoadBalance() &&
                    sdPortGroup.getWorkflowStatus() == oldPortGroup.getWorkflowStatus() &&
                    compareIdSets(sdPortGroup.getEgressPorts().stream().map(EgressPort::getId).collect(Collectors.toSet()),
                            oldPortGroup.getEgressPorts().stream().map(EgressPort::getId).collect(Collectors.toSet())))) {
                jobId = managerBuilder.getOperationsFactory(device).getSdPortGroupManager().commitPortGroup(sdPortGroup);
            }
        }
        if (profileInterfaceMappings != null) {
            List<ActiveInterface> activeInterfacesInDb = activeInterfaceRepository.findActiveInterfacesByPortGroupId(sdPortGroupRequest.getSdPortGroup().getId());
            for (ProfileInterfaceMapping interfaceMapping : profileInterfaceMappings) {
                ProfileInterfaceMapping profileInterfaceMapping = profileInterfaceMappingRepository.findOne(interfaceMapping.getId());
                long matchCount = -1;
                if (activeInterfacesInDb != null && !activeInterfacesInDb.isEmpty()) {
                    matchCount = activeInterfacesInDb.stream().filter(activeInterface -> activeInterface.getProfileInterfaceMapping().getId().longValue() == profileInterfaceMapping.getId().longValue()).count();
                }
                if (matchCount == 0 || activeInterfacesInDb.isEmpty()) {
                    ActiveInterface activeInterface = new ActiveInterface();
                    activeInterface.setName(profileInterfaceMapping.getName());
                    activeInterface.setPortGroup(sdPortGroup);
                    activeInterface.setProfileInterfaceMapping(profileInterfaceMapping);
                    jobId = sdFlowFactory.commitInterfaceWithStatusPolling(activeInterface, device, COMMIT);
                }
            }
            for (ActiveInterface activeInterfaceDb : activeInterfacesInDb) {
                long matchCount = profileInterfaceMappings.stream().filter(interfaceMapping -> interfaceMapping.getId().longValue() == activeInterfaceDb.getProfileInterfaceMapping().getId().longValue()).count();
                if (matchCount == 0) {
                    jobId = sdFlowFactory.deleteInterfaceWithStatusPolling(activeInterfaceDb, device);
                }
            }
        }
        return new ResponseEntity<>(jobId, HttpStatus.OK);
    }

    /**
     * This method is used to compare two sets of type Long
     *
     * @param firstIdSets
     * @param secondIdSets
     * @return
     */
    private boolean compareIdSets(Set<Long> firstIdSets, Set<Long> secondIdSets) {
        if (firstIdSets != null && secondIdSets != null) {
            if (!firstIdSets.isEmpty() && !secondIdSets.isEmpty() && firstIdSets.size() == secondIdSets.size()) {
                for (Long aLong : firstIdSets) {
                    if (!secondIdSets.contains(aLong)) {
                        return false;
                    }
                }
                for (Long aLong : secondIdSets) {
                    if (!firstIdSets.contains(aLong)) {
                        return false;
                    }
                }
                return true;
            } else if (firstIdSets.isEmpty() && secondIdSets.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * This method is used to fetch port group, based on the given portGroupId
     *
     * @param portGroupId
     * @param sdDeviceId
     * @return ResponseEntity<Object> This returns portGroup
     */
    @RequestMapping(method = RequestMethod.GET, value = "/portgroup/{portgroupid}")
    public ResponseEntity<Object> getPortGroup(@PathVariable("deviceid") Long sdDeviceId,
                                               @PathVariable(value = "portgroupid") Long portGroupId) {
        log.debug("********** Start: SD get Port Group **********");
        validateAndReturnDevice(sdDeviceId);
        if (portGroupId == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        SdPortGroup portGroup = egressPortGroupRepository.findById(portGroupId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        SdPortGroupRequest sdPortGroupRequest = new SdPortGroupRequest();
        sdPortGroupRequest.setSdPortGroup(portGroup);
        List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findActiveInterfacesByPortGroupId(portGroup.getId());
        if (activeInterfaces != null) {
            List<ProfileInterfaceMapping> profileInterfaceMapping = Lists.newArrayList();
            activeInterfaces.forEach(activeInterface ->
                    profileInterfaceMapping.add(activeInterface.getProfileInterfaceMapping())
            );
            sdPortGroupRequest.setProfileInterfaceMapping(profileInterfaceMapping);
        }
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
        List<ProfileInterfaceMapping> profileInterfaces = profileInterfaceMappingRepository.findByProfile(profileMapping.getProfile());
        profileInterfaces.forEach(intrfc ->
                intrfc.setProfile(null)
        );
        sdPortGroupRequest.setProfileInterfaces(profileInterfaces);
        return new ResponseEntity<>(sdPortGroupRequest, HttpStatus.OK);
    }

    /**
     * This method is used to fetch all port group for a selected sd device
     *
     * @param sdDeviceId
     * @return ResponseEntity<Object> This returns portGroup
     */
    @RequestMapping(method = RequestMethod.GET, value = "/portgroup")
    public ResponseEntity<Object> getAllPortGroups(@PathVariable("deviceid") Long sdDeviceId) {
        log.debug("********** Start: get all SD Port Groups **********");
        validateAndReturnDevice(sdDeviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(sdDeviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        List<SdPortGroup> portGroups = egressPortGroupRepository.findAllByDeviceId(sdDeviceId);
        List<SdPortGroupRequest> sdPortGroupRequests = Lists.newArrayList();
        portGroups.forEach(sdPortGroup -> {
            SdPortGroupRequest sdPortGroupRequest = new SdPortGroupRequest();
            sdPortGroupRequest.setSdPortGroup(sdPortGroup);
            List<ActiveInterface> activeInterfaces = activeInterfaceRepository.findActiveInterfacesByPortGroupId(sdPortGroup.getId());
            if (activeInterfaces != null) {
                List<ProfileInterfaceMapping> profileInterfaceMapping = Lists.newArrayList();
                activeInterfaces.forEach(activeInterface ->
                        profileInterfaceMapping.add(activeInterface.getProfileInterfaceMapping())
                );
                sdPortGroupRequest.setProfileInterfaceMapping(profileInterfaceMapping);
            }
            sdPortGroupRequests.add(sdPortGroupRequest);
        });

        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(sdDeviceId);
        List<ProfileInterfaceMapping> profileInterfaces = profileInterfaceMappingRepository.findByProfile(profileMapping.getProfile());
        profileInterfaces.forEach(intrfc ->
                intrfc.setProfile(null)
        );
        Map<String, Object> portGroupInterfaceMap = new HashMap<>();
        portGroupInterfaceMap.put("sdPortGroupRequests", sdPortGroupRequests);
        portGroupInterfaceMap.put("profileInterfaces", profileInterfaces);
        return new ResponseEntity<>(portGroupInterfaceMap, HttpStatus.OK);
    }

    /**
     * This method is used to delete port group on the given SD device using id
     *
     * @param portGroupId
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/portgroup/{portgroupid}")
    public ResponseEntity<Object> deletePortGroup(@RequestParam(value = "action", required = false) String action, @PathVariable(value = "portgroupid") Long portGroupId) {
        log.info("********** Start: SD delete Port Group **********");
        if (portGroupId == null || portGroupId < 1) {
            throw new ValidationException("portGroup.id.invalid");
        }
        SdPortGroup portGroup = egressPortGroupRepository.findOne(portGroupId);
        if (portGroup == null) {
            throw new ValidationException("portGroup.id.invalid");
        }
        if(portGroup.getDevice() == null) {
            throw new ValidationException("device.id.invalid");
        }
        validateAndReturnDevice(portGroup.getDevice().getId());
        if (portGroup.getDevice().getType() != Device.Type.SD) {
            throw new ValidationException("device.type.invalid");
        }
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(portGroup.getDevice().getId());
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(portGroup.getDevice().getId());
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", portGroup.getDevice().getId());
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", portGroup.getDevice().getId());
            throw new ValidationException("sd.profile.not.configured");
        }
        Long jobId;
        if (ROLLBACK.equalsIgnoreCase(action)) {
            jobId = managerBuilder.getOperationsFactory(portGroup.getDevice()).getSdPortGroupManager()
                    .rollbackPortGroup(portGroup.getId());
            return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
        } else if (CLEANUP.equalsIgnoreCase(action)) {
            jobId = managerBuilder.getOperationsFactory(portGroup.getDevice()).getSdPortGroupManager()
                    .deletePortGroup(portGroup.getId());
        } else {
            throw new ValidationException("invalid.action");
        }
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to update the port configuration
     *
     * @param deviceId
     * @param sdConfigRequest
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/ingressport")
    public ResponseEntity<Object> updateIngressPorts(@PathVariable("deviceid") Long deviceId, @RequestBody SdConfigRequest sdConfigRequest) {
        log.info("********** Start: updateIngressPorts **********");
        validateAndReturnDevice(deviceId);

        if (sdConfigRequest == null || sdConfigRequest.getSdIngressPorts() == null || sdConfigRequest.getSdIngressPorts().isEmpty()) {
            throw new ValidationException("sd.ingress.ports.empty");
        }
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", deviceId);
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", deviceId);
            throw new ValidationException("sd.profile.not.configured");
        }
        Job jobResult = sdConfigurationManager.updateIngressPorts(sdConfigRequest.getSdIngressPorts(), deviceId);
        log.info("********** End: updateIngressPorts ********** {}", jobResult.getStatus());
        if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
            return new ResponseEntity<>(jobResult.getStatus(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(jobResult.getJobResult(), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/flowExporter")
    public ResponseEntity<Object> updateFlowExporter(@PathVariable("deviceid") Long deviceId, @RequestBody FlowExporter flowExporter) {
        log.info("********** Start: updateFlowExporter **********");
        validateAndReturnDevice(deviceId);
        FlowExporter flowExporterDB = flowExporterRepository.findByDeviceId(deviceId);
        if (flowExporterDB != null && flowExporter.getName().equals(flowExporterDB.getName()) &&
                flowExporter.getTransportType().equals(flowExporterDB.getTransportType()) && flowExporter.getSdTransportPort() == flowExporterDB.getSdTransportPort()
                && flowExporter.getSdManagementPort().getId() == flowExporterDB.getSdManagementPort().getId()
                ) {
            throw new ValidationException("sd.flow.exporter.config.same");
        }
        Job jobResult = sdConfigurationManager.updateFlowExporter(flowExporter, deviceId);
        if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
            return new ResponseEntity<>(jobResult.getStatus(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(jobResult.getJobResult(), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/flowExporter")
    public ResponseEntity<Object> deleteFlowExporter(@PathVariable("deviceid") Long deviceId, @RequestBody FlowExporter flowExporter) {
        log.info("********** Start: deleteFlowExporter **********");
        validateAndReturnDevice(deviceId);
        FlowExporter flowExporterDB = flowExporterRepository.findByDeviceId(deviceId);
        if (flowExporter.getId() == null || (flowExporterDB != null && flowExporter.getId() != flowExporterDB.getId())) {
            throw new ValidationException("flow.exporter.id.invalid");
        }
        Job jobResult = sdConfigurationManager.deleteFlowExporter(flowExporter, deviceId);
        if (jobResult.getStatus().equals(Job.Status.SUCCESS)) {
            return new ResponseEntity<>(jobResult.getStatus(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(jobResult.getJobResult(), HttpStatus.EXPECTATION_FAILED);
        }
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("sd.invalid.device.id");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        return device;
    }
}
