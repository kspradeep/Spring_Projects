package com.brocade.bvm.api.manager.sessiondirector;

import com.brocade.bvm.api.controller.ManagerFactoryBuilder;
import com.brocade.bvm.api.factory.SDFlowFactory;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.sessiondirector.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.GlobalConfigHistory;
import com.brocade.bvm.model.db.sessiondirector.*;
import com.brocade.bvm.model.exception.ServerException;
import com.brocade.bvm.outbound.sessiondirector.service.SdDiscoveryService;
import com.google.common.collect.ImmutableSortedSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.common.IOUtils;
import net.schmizz.sshj.connection.ConnectionException;
import net.schmizz.sshj.connection.channel.direct.Session;
import net.schmizz.sshj.transport.TransportException;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * The SDConfiguration class implements methods to perform CRUD operations, Validations of ports, device configuration for SD version 3.5 and above
 */
@Named
@Slf4j
public class SdConfigurationManager {

    private static final String SD_STATUS_ACTIVE = "Session Director is active";
    private final static String CONTROL_PORT = "CONTROL-PORT";
    private final static String GTPU_PORT = "GTPU-PORT";
    private final static String RTP_PORT = "RTP-PORT";
    private final static String SIP_PORT = "SIP-PORT";
    private static final String ANY = "any";
    private static final String EQ = "eq";
    private static final String UDP = "udp";
    private static final String TCP = "tcp";
    private final static String ARCH1_DEF_S11_S1U_VoLTE = "ARCH1_DEF_S11_S1U_VoLTE";
    private final static String ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI = "ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI";

    @Inject
    private SdPairedDeviceRepository sdPairedDeviceRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private GlobalConfigRepository globalConfigRepository;

    @Inject
    private ProfileMappingRepository profileMappingRepository;

    @Inject
    private ProfileRepository profileRepository;

    @Inject
    protected JobRepository jobRepository;

    @Inject
    protected FlowExporterRepository flowExporterRepository;

    @Inject
    private SdDiscoveryService sdDiscoveryService;

    @Value("${stablenet-response.timeout.minutes}")
    private int stablenetTimeoutMinutes;

    @Value("${sd.status.wait.timeout.minutes}")
    private int sdStatusTimeoutMinutes;

    @Value("${sd.status.poll.interval.seconds:30}")
    private int waitIntervalInSeconds;

    @Value("${job.poll.interval.seconds:3}")
    private int jobPollIntervalSeconds;

    @Inject
    private EntityManager entityManager;

    @Inject
    private PortRepository portRepository;

    @Inject
    private IngressPortRepository ingressPortRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    protected EgressPortRepository egressPortRepository;

    @Inject
    private SdEgressPortManager sdEgressPortManager;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private GlobalConfigHistoryRepository globalConfigHistoryRepository;

    @Inject
    protected PhysicalInterfaceRepository physicalInterfaceRepository;

    /**
     * This method is used to save the SD paired device info
     *
     * @param targetDeviceId
     * @param deviceId
     * @return PairedDevice
     */
    public Long savePairedDevice(Long targetDeviceId, Long deviceId) {
        PairedDevice pairedDeviceDb = sdPairedDeviceRepository.findByDeviceId(deviceId);
        //TODO Need to clean the Egress and Egress Port Group and policies associated with earlier associated device
        pairedDeviceDb = (pairedDeviceDb == null) ? new PairedDevice() : pairedDeviceDb;
        Device newDeviceToPair = deviceRepository.findById(targetDeviceId);
        pairedDeviceDb.setDevice(deviceRepository.findById(deviceId));
        pairedDeviceDb.setTargetDevice(newDeviceToPair);
        sdPairedDeviceRepository.save(pairedDeviceDb);

        Job.Type jobType = Job.Type.ENABLE_ACL_FRAG_CONSERVATIVE;
        Long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(targetDeviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());

        jobType = Job.Type.SD_CLEAR_CONFIG;
        Long clearConfigJobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());
        Job job = getJobStatus(jobId);
        if (job != null) {
            log.debug("Enable ACL Frag conservative job is completed on device {}, status {}", targetDeviceId, job.getStatus());
        }
        if (clearConfigJobId != -1) {
            job = getJobStatus(clearConfigJobId);
        }
        log.debug("SD Device id {} is paired Successfully with target device id{}", deviceId, targetDeviceId);
        return jobId;
    }

    /**
     * This method is used to delete device paired with the SD
     *
     * @param deviceId
     */
    public Long unPairDevice(Long deviceId) {
        PairedDevice pairedDevice = sdPairedDeviceRepository.findOne(deviceId);
        deletePairedDevice(pairedDevice);
        if (pairedDevice != null) {
            Job.Type jobType = Job.Type.ENABLE_ACL_FRAG_CONSERVATIVE;
            Long jobId = jobQueue.submit(JobTemplate.builder()
                    .type(jobType)
                    .deviceId(pairedDevice.getTargetDevice().getId())
                    .impactedObjectIds(Lists.newArrayList())
                    .build());

            sdPairedDeviceRepository.delete(pairedDevice);
            return jobId;
        } else {
            throw new ValidationException("sd.invalid.unpair");
        }
    }

    /**
     * This method is used to delete device paired with the SD
     *
     * @param pairedDevice
     */
    public void deletePairedDevice(PairedDevice pairedDevice) {
        Long deviceId = pairedDevice.getDevice().getId();

        /* if MLXe is unpaired*/
        // DELETE SD EGRESS ports from SD
        List<EgressPort> egressPorts = egressPortRepository.findEgressPortsByIsDefaultFalseAndDeviceId(deviceId);
        Long egressDeleteJobId = 0l;
        if (!egressPorts.isEmpty()) {
            egressDeleteJobId = sdEgressPortManager.deletePort(pairedDevice.getDevice(), egressPorts);
        }

        Job job = egressDeleteJobId > 0 ? getJobStatus(egressDeleteJobId) : null;
        if (job == null || job.getStatus() == Job.Status.SUCCESS) {
            // Remove Service ports from SD ingress ports in BVM db
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
            List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(deviceId, profileMapping.getProfile().getId());
            ingressPorts.forEach(ingressPort -> {
                ingressPort.setServicePort(null);
            });
            ingressPortRepository.save(ingressPorts);

            // DELETE MLXe policies
            Set<Long> policyIds = new HashSet<>(policyRepository.findIdsByDeviceIdAndCreatedFromSd(pairedDevice.getTargetDevice().getId(), true));
            policyIds.forEach(policyId -> {
                Long policyDeleteJobId = managerBuilder.getOperationsFactory(pairedDevice.getTargetDevice()).getPolicyManager().deletePolicy(policyId, false, false);
                Job policyJob = getJobStatus(policyDeleteJobId);
                if (policyJob.getStatus() == Job.Status.FAILED) {
                    throw new ServerException(policyJob.getJobResult());
                }
            });
        } else if (job != null && job.getStatus() == Job.Status.FAILED) {
            throw new ServerException(job.getJobResult());
        }
    }

    public void deletePairedProfile(Long deviceId) {
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        /* if SD profile is changed*/
        // DELETE SD EGRESS ports from SD
        List<EgressPort> egressPorts = egressPortRepository.findEgressPortsByIsDefaultFalseAndDeviceId(deviceId);
        Long egressDeleteJobId = 0l;
        if (!egressPorts.isEmpty()) {
            egressDeleteJobId = sdEgressPortManager.deletePort(pairedDevice.getDevice(), egressPorts);
        }

        Job job = egressDeleteJobId > 0 ? getJobStatus(egressDeleteJobId) : null;
        if (job == null || job.getStatus() == Job.Status.SUCCESS) {
            // Remove SD INGRESS ports from BVM db
            ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
            List<IngressPort> ingressPorts = ingressPortRepository.findByDeviceIdAndProfileId(deviceId, profileMapping.getProfile().getId());
            ingressPortRepository.delete(ingressPorts);

            // DELETE MLXe policies
            Set<Long> policyIds = new HashSet<>(policyRepository.findIdsByDeviceIdAndCreatedFromSd(pairedDevice.getTargetDevice().getId(), true));
            policyIds.forEach(policyId -> {
                Long policyDeleteJobId = managerBuilder.getOperationsFactory(pairedDevice.getTargetDevice()).getPolicyManager().deletePolicy(policyId, false, false);
                Job policyJob = getJobStatus(policyDeleteJobId);
                if (policyJob.getStatus() == Job.Status.FAILED) {
                    return;
                }
            });
        }
    }

    /**
     * This method is used to save the SD ingress ports
     *
     * @param ingressPortSet
     * @param deviceId
     * @return Long
     */
    public Job updateIngressPorts(Set<IngressPort> ingressPortSet, Long deviceId) {
        Set<IngressPort> ingressPortsToSave = Sets.newHashSet();
        Set<Boolean> sdRebootRequired = Sets.newHashSet();
        Set<Long> servicePortIds = Sets.newHashSet();

        Map<Long, Port> oldServicePortToNewMap = Maps.newHashMap();

        List<Long> servicePorts = ingressPortSet.stream().map(IngressPort::getServicePort).collect(Collectors.toList()).stream().map(Port::getId).collect(Collectors.toList());
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        Device targetDevice = pairedDevice.getTargetDevice();
        Device sdDevice = pairedDevice.getDevice();
        log.debug("Updating SD Devide :{} ingress port(s)", sdDevice.getName());

        // Recovering the ports which are in ERROR state
        List<Port> dbPorts = (List<Port>) portRepository.findAll(servicePorts);
        List<Long> errorPorts = Lists.newArrayList();
        List<Long> portsToMark = Lists.newArrayList();
        if (dbPorts.isEmpty()) {
            dbPorts.forEach(port -> {
                if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    errorPorts.add(port.getId());
                }
                if (Port.Type.SERVICE_PORT != port.getType()) {
                    portsToMark.add(port.getId());
                }
            });
        }

        long portJobId = 0;
        if (!errorPorts.isEmpty()) {
            log.debug("Recovering ERROR port(s) on Target Device :{}", targetDevice.getName());
            portJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .recoverPort(targetDevice.getId(), errorPorts);
        }

        Job job = null;
        if (portJobId > 0) {
            job = getJobStatus(portJobId);
        }
        if (job != null && job.getStatus() == Job.Status.FAILED) {
            return job;
        }

        // Marking ports as SERVICE_PORT
        if (!portsToMark.isEmpty()) {
            Job jobMarking = null;
            long portMarkJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .changeType(targetDevice.getId(), portsToMark, Port.Type.SERVICE_PORT, false);
            if (portMarkJobId > 0) {
                jobMarking = getJobStatus(portMarkJobId);
            }
            if (jobMarking != null && jobMarking.getStatus() == Job.Status.FAILED) {
                return jobMarking;
            }
        }

        List<Long> servicePortToUnMark = Lists.newArrayList();
        ingressPortSet.forEach(ingressPort -> {
            if (ingressPort != null) {
                if (ingressPort.getId() != null) {
                    IngressPort ingressPortInDb = ingressPortRepository.findOne(ingressPort.getId());
                    if (ingressPortInDb != null) {
                        Boolean isSdRebootRequired = isIngressPortChanged(ingressPortInDb, ingressPort) || ingressPortInDb.getServicePort() == null || (ingressPortInDb.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR);
                        sdRebootRequired.add(isSdRebootRequired);

                        if (ingressPort.getServicePort() != null) {
                            if (servicePortIds.contains(ingressPort.getServicePort().getId())) {
                                log.debug("Same service port {} can not be selected for multiple ingress ports", ingressPort.getServicePort().getId());
                                throw new ValidationException("sd.service.port.same");
                            } else {
                                servicePortIds.add(ingressPort.getServicePort().getId());
                            }
                        }

                        boolean isServicePortChanged = isServicePortChanged(ingressPortInDb, ingressPort);
                        if (isServicePortChanged && ingressPortInDb.getServicePort() != null) {
                            servicePortToUnMark.add(ingressPortInDb.getServicePort().getId());
                            oldServicePortToNewMap.put(ingressPortInDb.getServicePort().getId(), ingressPort.getServicePort());
                        }

                        if (isSdRebootRequired || isServicePortChanged) {
                            ingressPortInDb.setPhysicalInterface(ingressPort.getPhysicalInterface());
                            ingressPortInDb.setJumboFrame(ingressPort.isJumboFrame());
                            ingressPortInDb.setServicePort(ingressPort.getServicePort());
                            ingressPortsToSave.add(ingressPortInDb);
                        }
                    }
                }
            }
        });

        if (!oldServicePortToNewMap.isEmpty()) {
            SDFlowFactory sdFlowFactory = (SDFlowFactory) managerBuilder.getOperationsFactory(sdDevice);
            Job jobUpdatePort = sdFlowFactory.updateTargetPoliciesForServicePorts(targetDevice, oldServicePortToNewMap);
            if (jobUpdatePort != null && jobUpdatePort.getStatus() == Job.Status.FAILED) {
                return jobUpdatePort;
            }
        }

        // Marking ports as NONE
        if (!servicePortToUnMark.isEmpty()) {
            Job jobUnMarking = null;
            long portUnMarkJobId = managerBuilder.getOperationsFactory(targetDevice)
                    .getPortManager()
                    .changeType(targetDevice.getId(), servicePortToUnMark, Port.Type.NONE, false);
            if (portUnMarkJobId > 0) {
                jobUnMarking = getJobStatus(portUnMarkJobId);
            }
            if (jobUnMarking != null && jobUnMarking.getStatus() == Job.Status.FAILED) {
                return jobUnMarking;
            }
        }

        Job jobObject = new Job();
        jobObject.setStatus(Job.Status.SUCCESS);

        if (!ingressPortsToSave.isEmpty()) {
            ingressPortsToSave.forEach(ingressPort -> {
                if (ingressPort.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
                    throw new ValidationException("sd.ingress.commit.inprogress");
                }
            });

            if (sdRebootRequired.contains(Boolean.TRUE)) {
                ingressPortsToSave.stream().forEach(ingressPort -> {
                    ingressPort.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                });
            }

            ingressPortRepository.save(ingressPortsToSave);
            if (sdRebootRequired.contains(Boolean.TRUE)) {
                long jobId = jobQueue.submit(JobTemplate.builder()
                        .type(Job.Type.SD_SET_INGRESS_PORT)
                        .deviceId(deviceId)
                        .impactedObjectIds(ingressPortsToSave.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                        .build());
                jobObject = getJobStatus(jobId);
                if (jobObject.getStatus() == Job.Status.SUCCESS) {
                    Device device = deviceRepository.findById(deviceId);
                    try {
                        int exitStatus = restartSD(device.getIpAddress());
                        if (exitStatus != 0) {
                            jobObject.setStatus(Job.Status.FAILED);
                            jobObject.setJobResult("Session Director services not running. Please check the configuration and try again.");
                        } else {
                            TimeUnit.SECONDS.sleep(3);
                            jobObject = getSdStatus(device);
                        }
                    } catch (ServerException e) {
                        throw new ServerException(e);
                    } catch (InterruptedException | IOException e) {
                        throw new ServerException("Session Director services not running. Please check the configuration and try again.", e);
                    }
                }
                log.debug("SD Ingress Job with id {} status is {}", jobObject.getId(), jobObject.getStatus());
            }
        } else {
            log.debug("SD Ingress configuration is unchanged");
            throw new ValidationException("sd.ingress.config.same");
        }
        return jobObject;
    }

    private int restartSD(String ipAddress) throws IOException {
        final SSHClient client = new SSHClient();
        client.addHostKeyVerifier(new PromiscuousVerifier());
        client.connect(ipAddress);
        int exitStatus = -1;
        try {
            client.authPassword("root", "password");
            final Session session = client.startSession();
            try {
                final Session.Command cmd = session.exec("systemctl restart sd; systemctl restart sd_cli;"); //systemctl restart sd; systemctl restart sd_cli;
                log.debug("Command output: {}", IOUtils.readFully(cmd.getInputStream()).toString());
                cmd.join(5, TimeUnit.SECONDS);
                exitStatus = cmd.getExitStatus();
                log.debug("Exit status: {}", exitStatus);
            } finally {
                if (session != null) {
                    try {
                        session.close();
                    } catch (TransportException | ConnectionException e) {
                        log.error("Error while closing session " + e.getMessage());
                    }
                }
            }
        } finally {
            try {
                client.disconnect();
                client.close();
            } catch (IOException e) {
                log.error("Error while closing connection " + e.getMessage());
            }
        }
        return exitStatus;
    }

    /**
     * This method validates if the ingress port data is changed
     *
     * @param ingressPortInDb
     * @param ingressPort
     * @return boolean
     */
    private boolean isIngressPortChanged(IngressPort ingressPortInDb, IngressPort ingressPort) {
        PhysicalInterface ingressPhysicalInterfaceDB = ingressPortInDb.getPhysicalInterface();
        PhysicalInterface ingressPhysicalInterfaceReq = physicalInterfaceRepository.findByIdAndDeviceId(ingressPort.getPhysicalInterface().getId(), ingressPort.getDevice().getId());
        if (ingressPhysicalInterfaceReq == null) {
            throw new ValidationException("sd.port.name.null");
        }
        if (ingressPhysicalInterfaceReq == null) {
            throw new ValidationException("sd.port.selected.invalid");
        }
        if (ingressPhysicalInterfaceDB == null) {
            return true;
        }
        if (!ingressPhysicalInterfaceReq.getName().equals(ingressPhysicalInterfaceDB.getName())) {
            return true;
        }
        if (ingressPortInDb.isJumboFrame() != ingressPort.isJumboFrame()) {
            return true;
        }
        return false;
    }

    private boolean isServicePortChanged(IngressPort ingressPortInDb, IngressPort ingressPort) {
        if (ingressPortInDb.getServicePort() == null || (ingressPort.getServicePort() != null && !ingressPort.getServicePort().getId().equals(ingressPortInDb.getServicePort().getId()))) {
            return true;
        }
        return false;
    }

    public GlobalConfig getGlobalConfig(Device device) {
        GlobalConfig globalConfig = globalConfigRepository.findByDeviceId(device.getId());
        //First time we get the GET request for the Global configuration we set the default values in the DB
        if (globalConfig == null) {
            globalConfig = new GlobalConfig();
            globalConfig.setMode(GlobalConfig.Mode.SINGLE);
            globalConfig.setFcrStatus(true);
            globalConfig.setFcrFileTime(10);
            globalConfig.setS11DropStatus(false);
            globalConfig.setRxTxSplitStatus(false);
            globalConfig.setSipPorts(Sets.newHashSet());
            globalConfig.setSgiCorrelationStatus(false);
            globalConfig.setIpFragmentationStatus(false);
            globalConfig.setDevice(device);
            globalConfig.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
            globalConfigRepository.save(globalConfig);
        }
        return globalConfig;
    }

    public Job saveGlobalConfig(Long deviceId, GlobalConfig globalConfigReq, Boolean isFcrSame, Boolean isSipCustomPortsSame) {
        long jobId = 0;
        Job jobObject = null;
        Device device = deviceRepository.findOne(deviceId);
        globalConfigReq.setDevice(device);
        globalConfigReq.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        //----Check if the profile contains SIP port and Target Device Policy 1 is not in error state
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
        PairedDevice pairedDevice = sdPairedDeviceRepository.findByDeviceId(deviceId);
        if (pairedDevice == null || pairedDevice.getTargetDevice() == null || pairedDevice.getTargetDevice().isDeleted()) {
            log.error("Session Director {} is currently not paired with any device.", device.getId());
            throw new ValidationException("sd.invalid.unpair");
        } else if (profileMapping == null) {
            log.error("Session Director {}, profile is not configured.", device.getId());
            throw new ValidationException("sd.profile.not.configured");
        }
        Profile profile = profileMapping.getProfile();
        Device targetDevice = pairedDevice.getTargetDevice();
        List<Policy> policys = policyRepository.findByNameAndDevice("policy_one_" + targetDevice.getType().toString() + "_" + targetDevice.getId(), targetDevice.getId());
        Policy policy1 = null;
        if (policys != null && !policys.isEmpty()) {
            policy1 = policys.get(0);
        }
        if (!isSipCustomPortsSame) {
            if (!profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE) && !profile.getName().equals(ARCH1_DEF_S11_S1U_VoLTE_S5S8_SGI)) {
                throw new ValidationException("sd.sip.port.invalid.profile");
            }
            if (policy1 != null && policy1.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                throw new ValidationException("sd.policy.in.error.state");
            }
        }
        //-----
        globalConfigRepository.save(globalConfigReq);
        // Return 0 if no job is created
        Job.Type jobType = Job.Type.SD_GLOBAL_CONFIG_UPDATE;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .parentObjectId(globalConfigReq.getId())
                .build());
        jobObject = getJobStatus(jobId);
        //Reverting the Configuration if the JOB fails as there is no recovery mechanism
        if (jobObject.getStatus().equals(Job.Status.FAILED)) {
            GlobalConfig oldGlobalConfig = getGlobalConfigFromHistory(globalConfigReq, 0);
            globalConfigRepository.save(oldGlobalConfig);
        } else {
            if (!isFcrSame) {
                getSdStatus(device);
            }
            if (!isSipCustomPortsSame) {
                //If there is difference in SIP Port configured need to trigger MLXE Policy 1 update job

                if (policy1 != null) {
                    updateSdPolicyWithChangedSipPorts(policy1, globalConfigReq, profile);
                    Long policyUpdateJobId = managerBuilder.getOperationsFactory(targetDevice).getPolicyManager().commitPolicy(policy1, false);
                    Job policyJob = getJobStatus(policyUpdateJobId);
                    if (policyJob.getStatus() == Job.Status.FAILED) {
                        throw new ServerException(policyJob.getJobResult());
                    }
                }
            }
        }
        return jobObject;
    }

    private Policy updateSdPolicyWithChangedSipPorts(Policy policy, GlobalConfig globalConfig, Profile profile) {
        Policy changedPolicy = policy;
        List<Integer> sipCustomPorts = new ArrayList<>();
        sipCustomPorts.addAll(globalConfig.getSipPorts());
        Map<String, List> portNumberTypeMap = Maps.newLinkedHashMap();
        portNumberTypeMap.put(CONTROL_PORT, Lists.newArrayList(2123));
        sipCustomPorts.add(5060);
        portNumberTypeMap.put(SIP_PORT, sipCustomPorts);
        portNumberTypeMap.put(GTPU_PORT, Lists.newArrayList(2152));
        portNumberTypeMap.put(RTP_PORT, Lists.newArrayList());
        SortedSet<Flow> flows = policy.getFlows();
        Long currentProfileId = profile.getId();
        Set<Integer> addedPorts = new HashSet<>(globalConfig.getSipPorts());
        addedPorts.removeAll(getGlobalConfigFromHistory(globalConfig, 1) != null ? getGlobalConfigFromHistory(globalConfig, 1).getSipPorts() : Sets.newHashSet());
        //Get the Ingress Id associated with SD SIP PORT
        Long sipMappedServicePortId = ingressPortRepository.findByNameAndProfileIdAndDeviceId(SIP_PORT, currentProfileId, globalConfig.getDevice().getId()).getServicePort().getId();
        SortedSet<RuleSet> newRulesets = new TreeSet();
        flows.forEach(flow -> {
            Optional portOptional = flow.getEgressPorts().stream().filter(egress -> egress.getId().longValue() == sipMappedServicePortId.longValue()).findFirst();
            if (portOptional.isPresent()) {
                flow.getRuleSets().forEach(ruleSet -> {
                    RuleSet newRuleSet = ruleSet;
                    SortedSet<Rule> newRules = Sets.newTreeSet(ruleSet.getRules());
                    ruleSet.getRules().forEach(rule -> {
                        if (!(sipCustomPorts.contains(rule.getSourcePort()) || sipCustomPorts.contains(rule.getDestinationPort()))) {
                            newRules.remove(rule);
                        }
                    });
                    addedPorts.forEach(portNo -> {
                        Long maxSeq = newRules.stream().map(rule -> rule.getSequence()).mapToLong(Seq -> Seq).max().orElseThrow(NoSuchElementException::new);
                        SortedSet<Rule> rules = ImmutableSortedSet.copyOf(createRuleWithPort(portNo, maxSeq));
                        newRules.addAll(rules);
                    });
                    newRuleSet.setRules(newRules);
                    newRulesets.add(newRuleSet);
                });
            }
        });
        return policy;
    }

    private Set<Rule> createRuleWithPort(Integer portNo, Long prevMaxSeq) {
        Long sequence = prevMaxSeq + 1;
        SortedSet<Rule> rules = new TreeSet<>();
        rules.add(addRule(TCP, sequence++, portNo, -1));
        rules.add(addRule(TCP, sequence++, -1, portNo));
        rules.add(addRule(UDP, sequence++, portNo, -1));
        rules.add(addRule(UDP, sequence++, -1, portNo));
        return rules;
    }

    /**
     * Method build and return the rule
     *
     * @param protocol
     * @param sequence
     * @param sourcePortNo
     * @param destinationPortNo
     * @return
     */
    private Rule addRule(String protocol, long sequence, int sourcePortNo, int destinationPortNo) {
        Rule rule = new Rule();
        rule.setSequence(sequence);
        rule.setProtocol(protocol);
        rule.setProtocolType(protocol);
        rule.setSourceIp(ANY);
        rule.setDestinationIp(ANY);
        if (sourcePortNo != -1)
            rule.setSourcePort(sourcePortNo);
        if (destinationPortNo != -1)
            rule.setDestinationPort(destinationPortNo);
        rule.setIsPermit(true);
        rule.setSourcePortOperator(EQ);
        rule.setDestinationPortOperator(EQ);
        rule.setSourceMac(ANY);
        rule.setDestinationMac(ANY);
        rule.setEthType(ANY);
        return rule;
    }

    /**
     * This method is used to save profile selected and it's ingress Ports
     *
     * @param deviceId
     * @param profileId
     * @return
     */
    public Job saveProfile(Long deviceId, Long profileId) {
        ProfileMapping profileMapping = profileMappingRepository.findByDeviceId(deviceId);
        Long oldProfileId = profileMapping.getProfile().getId();
        Device device = deviceRepository.findOne(deviceId);
        Long jobId = 0l;
        Job jobObject = new Job();
        jobObject.setStatus(Job.Status.SUCCESS);
        profileMapping = profileMapping == null ? new ProfileMapping() : profileMapping;
        profileMapping.setDevice(device);
        profileMapping.setProfile(profileRepository.findByDeviceProfileId(deviceId, profileId));
        profileMappingRepository.save(profileMapping);
        // Return 0 if no job is created
        Job.Type jobType = Job.Type.SD_CLEAR_CONFIG;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());

        jobType = Job.Type.SD_PROFILE_UPDATE;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());
        jobObject = getJobStatus(jobId);
        if (jobObject.getStatus().equals(Job.Status.SUCCESS)) {
            sdDiscoveryService.saveIngressPorts(device);
        } else if (jobObject.getStatus().equals(Job.Status.FAILED)) {
            log.debug("Reverting the Profile back as the Job failed.");
            Profile oldProfile = profileRepository.findByDeviceProfileId(deviceId, oldProfileId);
            profileMapping.setProfile(oldProfile);
            profileMappingRepository.save(profileMapping);
        }
        return jobObject;
    }

    /**
     * This method initiates the save running config on the SD device
     *
     * @param deviceId
     * @return
     */
    public Job saveRunningConfig(Long deviceId) {
        Job.Type jobType = Job.Type.SD_SAVE_RUNNING_CONFIG;
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());
        return getJobStatus(jobId);
    }

    public Job deleteFlowExporter(FlowExporter flowExporter, Long deviceId) {
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(Job.Type.SD_DELETE_FLOW_CONFIG)
                .deviceId(deviceId)
                .parentObjectId(flowExporter.getId())
                .impactedObjectIds(Lists.newArrayList())
                .build());
        return getJobStatus(jobId);
    }

    public Job updateFlowExporter(FlowExporter flowExporter, Long deviceId) {
        Job.Type jobType = Job.Type.SD_UPDATE_FLOW_CONFIG;
        FlowExporter flowExporterDB = flowExporterRepository.findByDeviceId(deviceId);
        if (flowExporterDB == null) {
            jobType = Job.Type.SD_CREATE_FLOW_EXPORTER;
        } else {
            if (flowExporterDB.getId() != flowExporter.getId()) {
                throw new ValidationException("sd.flow.exporter.invalid.id");
            }
        }
        PhysicalInterface physicalInterface = physicalInterfaceRepository.findOne(flowExporter.getSdManagementPort().getId());
        if (physicalInterface == null) {
            throw new ValidationException("Invalid SD Management Port");
        }
        flowExporter.setSdManagementPort(physicalInterface);
        flowExporter.setDevice(deviceRepository.findOne(deviceId));
        flowExporter.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        flowExporterRepository.save(flowExporter);
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(Lists.newArrayList())
                .build());
        return getJobStatus(jobId);
    }

    /**
     * This method  polls for job status
     *
     * @param jobId
     * @return
     */
    private Job getJobStatus(Long jobId) {
        log.debug("********** Job Status polling **********");
        long startTime = System.currentTimeMillis();
        while (true) {
            Job job = jobRepository.findOne(jobId);
            entityManager.clear();
            if (job == null) {
                break;
            }
            if (job.getStatus() == Job.Status.FAILED || job.getStatus() == Job.Status.SUCCESS) {
                return job;
            }
            try {
                TimeUnit.SECONDS.sleep(jobPollIntervalSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((stablenetTimeoutMinutes + 1) * 1000 * 60)) {
                log.warn("Job status polling timeout!");
                break;
            }
        }
        throw new ValidationException("job.get.notfound");
    }

    /**
     * This method fetches the latest ACTIVE globalConfig from history for the current policy
     *
     * @param globalConfig
     * @return Policy returns latest ACTIVE policy
     */
    protected GlobalConfig getGlobalConfigFromHistory(GlobalConfig globalConfig, Integer index) {
        // get the previous policy name from the history.
        GlobalConfig globalConfigFromHistory = null;
        List<GlobalConfigHistory> globalConfigFromHistoryList = globalConfigHistoryRepository.findByIdAndWorkflowStatus(globalConfig.getId(), Lists.newArrayList(WorkflowParticipant.WorkflowStatus.ACTIVE));
        if (!globalConfigFromHistoryList.isEmpty()) {
            GlobalConfigHistory oldConfig = globalConfigFromHistoryList.get(index);
            globalConfigFromHistory = oldConfig.buildParent();
        }
        return globalConfigFromHistory;
    }

    /*
     *  This method is used to look for SD status until it's Active or it gets timeout
     *  @param deviceId
     */
    private Job getSdStatus(Device device) {
        log.debug("********** Start of get SD Status **********");
        long startTime = System.currentTimeMillis();
        Job jobObject;
        while (true) {
            Long jobId = jobQueue.submit(JobTemplate.builder()
                    .type(Job.Type.SD_STATUS)
                    .deviceId(device.getId())
                    .impactedObjectIds(Lists.newArrayList())
                    .build());
            jobObject = getJobStatus(jobId);
            if (jobObject.getStatus().equals(Job.Status.FAILED)) {
                log.debug("SD status job failed for SD with device Id {} and IP {}", device.getId(), device.getIpAddress());
                break;
            }
            if (jobObject.getStatus().equals(Job.Status.SUCCESS)) {
                String response = jobObject.getJobResult();
                if (response != null) {
                    Pattern patternSdStatus = Pattern.compile(SD_STATUS_ACTIVE, Pattern.CASE_INSENSITIVE);
                    Matcher matcherSdStatus = patternSdStatus.matcher(response);
                    if (matcherSdStatus.find()) {
                        log.debug("Session Director with device Id {} and IP {} is active now !", device.getId(), device.getIpAddress());
                        break;
                    }
                }
            }
            long elapsedTime = System.currentTimeMillis() - startTime;
            if (elapsedTime >= ((sdStatusTimeoutMinutes + 1) * 1000 * 60)) {
                log.error("Session Director status polling timeout for device Id {} and IP {}!", device.getId(), device.getIpAddress());
                throw new ValidationException("sd.service.not.running");
            }
            try {
                log.debug("Waiting for SD service, device Id {} and IP {} to come up...", device.getId(), device.getIpAddress());
                TimeUnit.SECONDS.sleep(waitIntervalInSeconds);
            } catch (InterruptedException e1) {
                log.debug(e1.getMessage());
            }
        }
        return jobObject;
    }
}
