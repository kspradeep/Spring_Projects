package com.brocade.bvm.api.utility;

import com.brocade.bvm.api.controller.PolicyController;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.RuleRepository;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The PolicyControllerHelper class implements for performing smart update on policy.
 * Only fields which are required to be updated/added/deleted and it's values are to be send this API.
 * API will construct the complete policy object and push to the CRUD operation.
 */
@Named
@Slf4j
public class PolicyControllerHelper {

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private RuleRepository ruleRepository;

    /**
     * Method construct and return the complete policy object
     *
     * @param policyUi
     * @param policyDb
     * @param action
     * @return
     */
    public Policy updatePortPortGroupRuleInPolicy(Policy policyUi, Policy policyDb, String action) {
        policyDb = updatePortPortGroupInPolicy(policyUi, policyDb, action);
        policyDb = updateRulesInPolicy(policyUi, policyDb, action);
        return policyDb;
    }

    /**
     * This method add/remove port and port-group from policy.
     *
     * @param policyUi
     * @param policyDb
     * @param action
     * @return
     */
    public Policy updatePortPortGroupInPolicy(Policy policyUi, Policy policyDb, String action) {
        if (policyUi != null && policyDb != null && action != null) {
            SortedSet<Flow> flows = new TreeSet<>();
            policyDb.getFlows().forEach(flow -> {
                        Optional<Flow> flowMatchedOptional = policyUi.getFlows().stream().filter(flowUi -> flowUi.getId() != null && flowUi.getId().longValue() == flow.getId().longValue()).findAny();
                        if (flowMatchedOptional != null && flowMatchedOptional.isPresent()) {
                            Flow flowMatched = flowMatchedOptional.get();
                            if (PolicyController.ADD.equalsIgnoreCase(action)) {
                                flow.addIngressPorts(Sets.newHashSet(portRepository.findAll(flowMatched.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()))));
                                Set<Port> egressPorts = Sets.newHashSet(portRepository.findAll(flowMatched.getEgressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet())));
                                flow.addEgressPorts(egressPorts);
                                flow.addFlowEgressManagedObjects(egressPorts);

                                flow.addIngressPortGroups(Sets.newHashSet(portGroupRepository.findAll(flowMatched.getIngressPortGroups().stream().map(port -> port.getId()).collect(Collectors.toSet()))));
                                Set<PortGroup> egressPortsGroups = Sets.newHashSet(portGroupRepository.findAll(flowMatched.getEgressPortGroups().stream().map(port -> port.getId()).collect(Collectors.toSet())));
                                flow.addEgressPortGroups(egressPortsGroups);
                                flow.addFlowEgressManagedObjects(egressPortsGroups);
                            } else if (PolicyController.DELETE.equalsIgnoreCase(action)) {
                                validatePortPortGroup(flow.getIngressPorts().stream().map(Port::getId).collect(Collectors.toList()), flowMatched.getIngressPorts().stream().map(Port::getId).collect(Collectors.toList()), false);
                                validatePortPortGroup(flow.getEgressPorts().stream().map(Port::getId).collect(Collectors.toList()), flowMatched.getEgressPorts().stream().map(Port::getId).collect(Collectors.toList()), false);
                                validatePortPortGroup(flow.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList()), flowMatched.getIngressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList()), true);
                                validatePortPortGroup(flow.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList()), flowMatched.getEgressPortGroups().stream().map(PortGroup::getId).collect(Collectors.toList()), true);

                                flow.removeIngressPorts(Sets.newHashSet(portRepository.findAll(flowMatched.getIngressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet()))));
                                Set<Port> egressPorts = Sets.newHashSet(portRepository.findAll(flowMatched.getEgressPorts().stream().map(port -> port.getId()).collect(Collectors.toSet())));
                                flow.removeEgressPorts(egressPorts);
                                flow.removeFlowEgressManagedObjects(egressPorts);

                                flow.removeIngressPortGroups(Sets.newHashSet(portGroupRepository.findAll(flowMatched.getIngressPortGroups().stream().map(port -> port.getId()).collect(Collectors.toSet()))));
                                Set<PortGroup> egressPortsGroups = Sets.newHashSet(portGroupRepository.findAll(flowMatched.getEgressPortGroups().stream().map(port -> port.getId()).collect(Collectors.toSet())));
                                flow.removeEgressPortGroups(egressPortsGroups);
                                flow.removeFlowEgressManagedObjects(egressPortsGroups);
                            }
                            flows.add(flow);
                        }
                    }
            );
            policyDb.setFlows(flows);
        }
        return policyDb;
    }

    private void validatePortPortGroup(List<Long> managedObjectIdsInDb, List<Long> managedObjectIdsInUi, boolean isPortGroup) {
        if (managedObjectIdsInDb != null && managedObjectIdsInUi != null) {
            managedObjectIdsInUi.forEach(aLong -> {
                if (!managedObjectIdsInDb.contains(aLong)) {
                    if (isPortGroup) {
                        throw new ValidationException("portGroup.id.invalid");
                    } else {
                        throw new ValidationException("port.ids.invalid");
                    }
                }
            });
        }
    }

    /**
     * this method add/remove VLAN ids, add/update/remove fields in policy rule.
     *
     * @param policyUi
     * @param policyDb
     * @param action
     * @return
     */
    public Policy updateRulesInPolicy(Policy policyUi, Policy policyDb, String action) {
        if (policyUi != null && policyDb != null && action != null) {
            policyDb.getFlows().forEach(flow -> {
                Optional<Flow> flowMatchedUiOptional = policyUi.getFlows().stream().filter(flowUi -> flowUi.getId() != null && flowUi.getId().longValue() == flow.getId().longValue()).findAny();
                if (flowMatchedUiOptional != null && flowMatchedUiOptional.isPresent()) {
                    Flow flowMatchedUi = flowMatchedUiOptional.get();
                    if (PolicyController.ADD.equalsIgnoreCase(action)) {
                        flow.addVlan(flowMatchedUi.getVlans());
                    } else if (PolicyController.DELETE.equalsIgnoreCase(action)) {
                        flow.removeVlan(flowMatchedUi.getVlans());
                    }
                    flow.getRuleSets().forEach(ruleSet -> {
                        Optional<RuleSet> ruleSetMatchedUiOptional = flowMatchedUi.getRuleSets().stream().filter(ruleSetUi -> ruleSetUi.getId() != null && ruleSetUi.getId().longValue() == ruleSet.getId().longValue()).findAny();
                        if (ruleSetMatchedUiOptional != null && ruleSetMatchedUiOptional.isPresent()) {
                            RuleSet ruleSetUi = ruleSetMatchedUiOptional.get();
                            ruleSet.getRules().forEach(rule -> {
                                Optional<Rule> ruleMatchedUiOptional = ruleSetUi.getRules().stream().filter(ruleUi -> ruleUi.getId() != null && ruleUi.getId().longValue() == rule.getId().longValue()).findAny();
                                if (ruleMatchedUiOptional != null && ruleMatchedUiOptional.isPresent()) {
                                    Rule rule1Ui = ruleMatchedUiOptional.get();
                                    if (rule1Ui != null && rule1Ui.getId() == rule.getId()) {
                                        if (rule1Ui.getIsPermit() != null && rule.getIsPermit() != rule1Ui.getIsPermit())
                                            rule.setIsPermit(rule1Ui.getIsPermit());
                                        if (rule1Ui.getVlanId() != null && rule.getVlanId() != rule1Ui.getVlanId())
                                            rule.setVlanId(rule1Ui.getVlanId());
                                        if (rule1Ui.getSourceIp() != null && !rule1Ui.getSourceIp().equals(rule.getSourceIp()))
                                            rule.setSourceIp(rule1Ui.getSourceIp());
                                        if (rule1Ui.getDestinationIp() != null && !rule1Ui.getDestinationIp().equals(rule.getDestinationIp()))
                                            rule.setDestinationIp(rule1Ui.getDestinationIp());
                                        if (rule1Ui.getSourceMac() != null && !rule1Ui.getSourceMac().equals(rule.getSourceMac()))
                                            rule.setSourceMac(rule1Ui.getSourceMac());
                                        if (rule1Ui.getDestinationMac() != null && !rule1Ui.getDestinationMac().equals(rule.getDestinationMac()))
                                            rule.setDestinationMac(rule1Ui.getDestinationMac());
                                        if (rule1Ui.getSourcePort() != null && !rule1Ui.getSourcePort().equals(rule.getSourcePort()))
                                            rule.setSourcePort(rule1Ui.getSourcePort());
                                        if (rule1Ui.getDestinationPort() != null && !rule1Ui.getDestinationPort().equals(rule.getDestinationPort()))
                                            rule.setDestinationPort(rule1Ui.getDestinationPort());
                                    }
                                }
                            });

                            if (PolicyController.ADD.equalsIgnoreCase(action)) {
                                Long ruleSequnceMax = ruleRepository.getMaxSequenceByRuleSetId(ruleSet.getId());
                                SortedSet<Rule> rules = ruleSetUi.getRules().stream().filter(ruleUi -> ruleUi.getId() == null).collect(Collectors.toCollection(TreeSet::new));
                                for (Rule rule : rules) {
                                    if (rule.getEthType() == null)
                                        rule.setEthType("any");
                                    if (rule.getDestinationMac() == null)
                                        rule.setDestinationMac("any");
                                    if (rule.getSourceMac() == null)
                                        rule.setSourceMac("any");
                                    if (rule.getDestinationIp() == null)
                                        rule.setDestinationIp("any");
                                    if (rule.getSourceIp() == null)
                                        rule.setSourceIp("any");
                                    if (rule.getVlanId() == null)
                                        rule.setVlanId(-1);
                                    if (rule.getIsPermit() == null)
                                        rule.setIsPermit(false);
                                    if (rule.getSequence() == null)
                                        rule.setSequence(ruleSequnceMax += 5);
                                }
                                ruleSet.addRules(rules);
                            } else if (PolicyController.DELETE.equalsIgnoreCase(action)) {
                                ruleSet.removeRules(Sets.newTreeSet(ruleRepository.findAll(ruleSetUi.getRules().stream().filter(ruleUi -> ruleUi.getId() != null).map(ruleUi -> ruleUi.getId()).collect(Collectors.toCollection(TreeSet::new)))));
                            }
                        }
                    });
                }
            });
        }
        return policyDb;
    }
}
