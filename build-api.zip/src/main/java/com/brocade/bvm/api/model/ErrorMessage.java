package com.brocade.bvm.api.model;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Error Message Data Model
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement
public class ErrorMessage {
    private int errorCode;
    private String errorMessage;
    private String documentation;
}
