package com.brocade.bvm.api.model.grid;

import com.brocade.bvm.model.WorkflowParticipant;
import com.google.common.collect.Sets;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class GridSummary {

    private Long id;

    private String name;

    private String description;

    private WorkflowParticipant.WorkflowStatus workflowStatus;

    private Set<GridSummaryDeviceInfo> dataSet = Sets.newHashSet();

    public void addData(GridSummaryDeviceInfo gridSummaryDeviceInfo) {
        dataSet.add(gridSummaryDeviceInfo);
    }
}

