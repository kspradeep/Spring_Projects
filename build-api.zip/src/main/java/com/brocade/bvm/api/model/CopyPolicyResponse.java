<<<<<<< .mine
package com.brocade.bvm.api.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CopyPolicyResponse {

    private Long deviceId;

    private String deviceName;

    private boolean policySuccessful;

    private String policyErrorResult;
}
||||||| .r0
=======
package com.brocade.bvm.api.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CopyPolicyResponse {

    private Long deviceId;

    private String deviceName;

    private boolean policySuccessful;

    private String policyErrorResult;
}
>>>>>>> .r14165
