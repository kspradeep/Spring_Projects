package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;

public interface SdPortGroupManager {
    /**
     * return saved/updated SD port group
     */
    Long savePortGroup(SdPortGroup port);

    Long commitPortGroup(SdPortGroup port);

    Long deletePortGroup(Long portGroupId);

    Long rollbackPortGroup(Long portGroupId);
}
