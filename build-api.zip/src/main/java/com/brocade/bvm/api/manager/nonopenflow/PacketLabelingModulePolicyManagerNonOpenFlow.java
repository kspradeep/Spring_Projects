package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.ModuleRepository;
import com.brocade.bvm.dao.PacketLabelingModulePolicyRepository;
import com.brocade.bvm.model.db.PacketLabelingModulePolicy.ProcessorNumber;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Manager class for the Source Port Labeling
 */
@Slf4j
@Named
public class PacketLabelingModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private PacketLabelingModulePolicyRepository packetLabelingModulePolicyRepository;

    /**
     * This method is used to create PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicyRequest) {
        PacketLabelingModulePolicy packetLabelingModulePolicy = modulePolicyRequest.getPacketLabelingModulePolicy();
        isValidPolicy(packetLabelingModulePolicy, deviceId);

        List<Long> moduleIds = packetLabelingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        // 1. Check if modulePolicy already present on same module and processor.
        if (!moduleIds.isEmpty()) {
            ProcessorNumber processorNumber = packetLabelingModulePolicy.getProcessor();
            moduleIds.forEach(moduleId -> {
                List<String> processors = Lists.newArrayList();
                if (ProcessorNumber.ALL == processorNumber) {
                    processors.add(ProcessorNumber.ONE.name());
                    processors.add(ProcessorNumber.TWO.name());
                } else {
                    processors.add(processorNumber.name());
                }
                List<Long> dbModulePolicyIds = packetLabelingModulePolicyRepository.findModulesPolicyByModuleIdAndProcessorNumber(moduleId, processors);
                if (!dbModulePolicyIds.isEmpty()) {
                    log.error("Already a Packet Labeling Module Policy applied for the selected processor(s).");
                    throw new ValidationException("policy.exists.with.same.processor");
                }
            });
        }

        isValidPolicyToCommit(packetLabelingModulePolicy, moduleIds, modules);
        packetLabelingModulePolicy.setModules(Sets.newHashSet(modules));
        packetLabelingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetLabelingModulePolicy = modulePolicyRepository.save(packetLabelingModulePolicy);
        Job.Type jobType = Job.Type.PACKET_LABELING_MODULE_POLICY_CREATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(packetLabelingModulePolicy.getId()).build());
        return jobId;
    }

    /**
     * This method is used to delete PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        PacketLabelingModulePolicy packetLabelingModulePolicy = (PacketLabelingModulePolicy) modulePolicyRepository.findOne(modulePolicyId);
        // Validate
        // 1. ModulePolicy present in DB
        if (packetLabelingModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(packetLabelingModulePolicy, deviceId);
        // 2. ModulePolicy not in active state.
        if (WorkflowParticipant.WorkflowStatus.SUBMITTED == packetLabelingModulePolicy.getWorkflowStatus()) {
            throw new ValidationException("source.port.labeling.delete.policy.in.progress");
        }
        Job.Type jobType = Job.Type.PACKET_LABELING_MODULE_POLICY_DELETE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(packetLabelingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to update PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicyFromRequest
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicyFromRequest) {
        PacketLabelingModulePolicy modulePolicy = modulePolicyFromRequest.getPacketLabelingModulePolicy();
        isValidPolicy(modulePolicy, deviceId);

        PacketLabelingModulePolicy oldModulePolicy = (PacketLabelingModulePolicy) modulePolicyRepository.findById(modulePolicyId);

        // If no PacketLabelingModulePolicy is available with id
        if (oldModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        // If PacketLabelingModulePolicy is not in committed status or in error state, do not allow
        // modify
        if (WorkflowParticipant.WorkflowStatus.ACTIVE != oldModulePolicy.getWorkflowStatus()
                || WorkflowParticipant.WorkflowStatus.ERROR == oldModulePolicy.getWorkflowStatus()) {
            throw new ValidationException("source.port.labeling.edit.failed");
        }
        List<Long> moduleIds = modulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);

        isValidPolicyToCommit(modulePolicy, moduleIds, modules);
        isPolicyUnChanged(oldModulePolicy, modulePolicy);

        // merging data
        oldModulePolicy.setProcessor(modulePolicy.getProcessor());
        oldModulePolicy.setModules(Sets.newHashSet(modules));
        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(oldModulePolicy);

        Job.Type jobType = Job.Type.PACKET_LABELING_MODULE_POLICY_UPDATE;
        long jobId = jobQueue.submit(JobTemplate.builder().type(jobType)
                .deviceId(deviceId).impactedObjectIds(modules.stream().map(Module::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover PacketLabelingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        PacketLabelingModulePolicy packetLabelingModulePolicy = (PacketLabelingModulePolicy) modulePolicyRepository.findOne(modulePolicyId);
        if (packetLabelingModulePolicy == null) {
            throw new ValidationException("policy.id.invalid");
        }
        isValidPolicy(packetLabelingModulePolicy, deviceId);
        if (WorkflowParticipant.WorkflowStatus.ERROR != packetLabelingModulePolicy.getWorkflowStatus()) {
            throw new ValidationException("policy.recovery.not.in.error");
        }
        List<Long> moduleIds = packetLabelingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        packetLabelingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        modulePolicyRepository.save(packetLabelingModulePolicy);

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_LABELING_MODULE_POLICY_ROLLBACK)
                .deviceId(deviceId).impactedObjectIds(moduleIds)
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * Validating the Port Labeling Policy
     *
     * @param policy
     * @param deviceId
     * @return
     */
    protected boolean isValidPolicy(PacketLabelingModulePolicy policy, Long deviceId) {
        if (policy != null) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("source.port.labeling.not.supported.device");
            }
            if (policy.getModules() == null || policy.getModules().isEmpty()) {
                throw new ValidationException("empty.module.not.allowed");
            }
            if (policy.getProcessor() == null) {
                throw new ValidationException("empty.processor.not.allowed");
            }
        }
        return true;
    }

    /**
     * This method checks if PacketLabelingModulePolicy data is valid to commit on the given device
     *
     * @param packetLabelingModulePolicy
     * @param moduleIds
     * @param modules
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(PacketLabelingModulePolicy packetLabelingModulePolicy, List<Long> moduleIds, List<Module> modules) {
        // #1 Check if the modules selected are valid modules
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("invalid.module.selected");
        }

        // #2 Check if the process number is valid
        PacketLabelingModulePolicy.ProcessorNumber processorNumber = packetLabelingModulePolicy.getProcessor();
        List<PacketLabelingModulePolicy.ProcessorNumber> processorNumberList = Arrays.asList(PacketLabelingModulePolicy.ProcessorNumber.ONE, PacketLabelingModulePolicy.ProcessorNumber.TWO, PacketLabelingModulePolicy.ProcessorNumber.ALL);
        if (!processorNumberList.contains(processorNumber)) {
            log.error("Invalid Process Number. Aborting!");
            throw new ValidationException("processNumber.invalid");
        }
        return true;
    }

    /**
     * This method checks if PacketLabelingModulePolicy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    private boolean isPolicyUnChanged(PacketLabelingModulePolicy oldModulePolicy, PacketLabelingModulePolicy newModulePolicy) {
        if (oldModulePolicy.getProcessor() != null ? !oldModulePolicy.getProcessor().equals(newModulePolicy.getProcessor()) : newModulePolicy.getProcessor() != null)
            return false;
        Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        Set<Long> newModuleIds = newModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        if (!oldModuleIds.containsAll(newModuleIds)) {
            return false;
        }
        return true;
    }
}
