package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ForbiddenException;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ModulePolicy;
import com.brocade.bvm.model.db.TargetHost;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The ModulePolicyController class implements methods to perform CRUD operations related to module policy
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/device/{deviceId}/modulepolicy")
public class ModulePolicyController {

    @Value("${slx.telemetry.supported.os.version}")
    private String slxTelemetrySupportedVersion;

    public static final String CLEANUP = "cleanup";
    public static final String UPDATE = "update";

    @Inject
    private ManagerFactoryBuilder managerBuilder;

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private GenericHelper genericHelper;

    /**
     * This method is used to create ModulePolicy on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Object> createModulePolicy(@PathVariable("deviceId") Long deviceId, @RequestBody ModulePolicyRequest modulePolicy) {
        log.debug("********** Start: Commit Module Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (modulePolicy == null) {
            throw new ValidationException("policy.data.invalid");
        }
        //RBAC
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        try {
            Long jobId = managerBuilder.getOperationsFactory(device)
                    .getModulePolicyManager(modulePolicy)
                    .commitModulePolicy(deviceId, modulePolicy);
            return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
        } catch (UnsupportedOperationException e) {
            log.error("Policy action is failed on device {} : {}", deviceId, e.getLocalizedMessage());
            throw new ValidationException(e.getLocalizedMessage());
        }
    }

    /**
     * This method is used to fetch ModulePolicy for the given modulePolicyId
     *
     * @param deviceId
     * @param modulePolicyId
     * @return ResponseEntity<Object> This returns ModulePolicy
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{modulepolicyid}")
    public ResponseEntity<Object> getModulePolicyById(@PathVariable("deviceId") Long deviceId, @PathVariable("modulepolicyid") Long modulePolicyId) {
        log.info("********** Start: get module policy **********");
        validateAndReturnDevice(deviceId);
        if (modulePolicyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        //RBAC
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        ModulePolicy modulePolicy = modulePolicyRepository.findById(modulePolicyId);
        if (modulePolicy == null) {
            throw new ValidationException("loadBalancePolicy.id.invalid");
        }
        return new ResponseEntity<>(modulePolicy, HttpStatus.OK);
    }

    /**
     * This method is used to delete ModulePolicy by given modulePolicyId
     *
     * @param action
     * @param deviceId
     * @param modulePolicyId
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{modulepolicyid}")
    public ResponseEntity<Object> deleteModulePolicyById(@RequestParam(value = "action", required = false) String action,
                                                         @PathVariable("deviceId") Long deviceId, @PathVariable("modulepolicyid") Long modulePolicyId) {
        log.info("********** Start: Delete module policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (modulePolicyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        //RBAC
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        Long jobId;
        ModulePolicy modulePolicy = modulePolicyRepository.findOne(modulePolicyId);
        if (modulePolicy == null) {
            throw new ValidationException("loadBalancePolicy.id.invalid");
        }
        try {
            //Recovery
            if (CLEANUP.equalsIgnoreCase(action)) {
                if (modulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR) {
                    jobId = managerBuilder.getOperationsFactory(device)
                            .getModulePolicyManager(modulePolicy)
                            .recoverModulePolicy(deviceId, modulePolicyId);
                } else {
                    throw new ValidationException("policy.action.invalid");
                }
            } else { // Delete
                jobId = managerBuilder.getOperationsFactory(device)
                        .getModulePolicyManager(modulePolicy)
                        .deleteModulePolicy(deviceId, modulePolicyId);
            }
        } catch (UnsupportedOperationException e) {
            log.error("Policy action {} is failed on device {} : {}", action, deviceId, e.getLocalizedMessage());
            throw new ValidationException(e.getLocalizedMessage());
        }
        return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
    }

    /**
     * This method is used to update ModulePolicy on device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicy
     * @return ResponseEntity<Object> This returns jobId
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/{modulepolicyid}", consumes = "application/json")
    public ResponseEntity<Object> updateModulePolicy(@PathVariable("deviceId") Long deviceId,
                                                     @PathVariable("modulepolicyid") Long modulePolicyId,
                                                     @RequestBody ModulePolicyRequest modulePolicy) {
        log.info("********** Start: update Module Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (modulePolicyId == null) {
            throw new ValidationException("policy.id.invalid");
        }
        if (modulePolicy == null) {
            throw new ValidationException("policy.data.invalid");
        }
        //RBAC
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }
        try {
            Long jobId = managerBuilder.getOperationsFactory(device)
                    .getModulePolicyManager(modulePolicy)
                    .updateModulePolicy(deviceId, modulePolicyId, modulePolicy);
            return new ResponseEntity<>(jobId, HttpStatus.ACCEPTED);
        } catch (UnsupportedOperationException e) {
            log.error("Policy action is failed on device {} : {}", deviceId, e.getLocalizedMessage());
            throw new ValidationException(e.getLocalizedMessage());
        }
    }

    /**
     * This method is used to fetch all module policies for the given deviceId
     *
     * @param deviceId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Object> getModulePoliciesByDeviceId(@PathVariable("deviceid") Long deviceId) {
        log.debug("********** Start: Get Module Policy **********");
        Device device = validateAndReturnDevice(deviceId);
        if (!authorityProvider.getAuthorizedDeviceIds().contains(deviceId)) {
            throw new ForbiddenException("rbac.device.notAuthorized");
        }

        List<ModulePolicy> modulePolicies = modulePolicyRepository.findByDeviceId(deviceId);
        Map<String, Set<? extends ModulePolicy>> policyMap = new HashMap<>();
        if (TargetHost.Mode.PLAIN.equals(device.getMode())) {
            if (modulePolicies != null && modulePolicies.size() > 0) {
                policyMap.putAll(managerBuilder.getOperationsFactory(device)
                        .getModulePolicyManager(modulePolicies.stream().findAny().get())
                        .getModulePolicies(modulePolicies));
            }
        }

        if (policyMap != null && policyMap.size() > 0) {
            return new ResponseEntity<>(policyMap, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(policyMap, HttpStatus.OK);
        }
    }

    /**
     * Method validates the device
     *
     * @param deviceId
     * @return
     */
    private Device validateAndReturnDevice(Long deviceId) {
        if (deviceId == null || deviceId < 0) {
            throw new ValidationException("device.id.invalid");
        }
        Device device = deviceRepository.findByIdsAndIsReconciled(deviceId);
        if (device == null) {
            throw new ValidationException("device.id.invalid");
        }
        if (device != null && !device.isReconciled()) {
            throw new ValidationException("device.not.authorized");
        }
        if (Device.Type.SLX == device.getType() && device.getModel() != null && !String.valueOf(device.getModel()).contains(Device.SLX_9850)) {
            if (!Strings.isNullOrEmpty(device.getOs()) && !device.isProfileConfigured() && genericHelper.isSLXVersionValid(device.getOs(), slxTelemetrySupportedVersion) >= 0) {
                throw new ValidationException("device.not.authorized");
            }
        }
        return device;
    }
}
