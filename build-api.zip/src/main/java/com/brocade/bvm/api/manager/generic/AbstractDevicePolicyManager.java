package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.DevicePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.*;

import java.util.*;

/**
 * The AbstractDevicePolicyManager class implements methods to SAVE/COMMIT and fetch all device policies
 */
public abstract class AbstractDevicePolicyManager implements DevicePolicyManager {

    public static final String COMMIT = "commit";
    public static final String UPDATE = "update";
    public static final String CLEANUP = "cleanup";

    /**
     * This method is used to invoke COMMIT/UPDATE device policy based on action
     *
     * @param devicePolicies
     * @param device
     * @param action
     * @param policyName
     * @return
     */
    @Override
    public List<Long> saveOrCommitDevicePolicies(Set<? extends DevicePolicy> devicePolicies, Device device, String action, String policyName) {
        List<Long> jobIds = new ArrayList<>();
        if (!devicePolicies.isEmpty()) {
            validateDevicePolicies(devicePolicies, device, action, false);
            DevicePolicy devicePolicy = devicePolicies.stream().findFirst().get();
            devicePolicy.setDevice(device);
            if (COMMIT.equals(action)) {
                jobIds.add(commitPolicy(devicePolicy));
            } else if (UPDATE.equals(action)) {
                jobIds.add(updatePolicy(devicePolicy));
            }
        }
        return jobIds;
    }

    /**
     * This method is used fetch the map of device policies based type of device policy
     *
     * @param devicePolicies
     * @return Map<String, Set<DevicePolicy>>
     */
    @Override
    public Map<String, Set<DevicePolicy>> getDevicePolicies(Set<? extends DevicePolicy> devicePolicies) {
        Map<String, Set<DevicePolicy>> policyMap = new HashMap<>();
        if (devicePolicies != null) {
            Set<DevicePolicy> mplsPolicies = new HashSet<>();
            Set<DevicePolicy> gtpPolicies = new HashSet<>();
            Set<DevicePolicy> tunnelPolicies = new HashSet<>();
            Set<DevicePolicy> reservedVlanPolicies = new HashSet<>();
            Set<DevicePolicy> slxPtpPolicies = new HashSet<>();
            devicePolicies.stream().forEach(devicePolicy -> {
                if (devicePolicy instanceof MPLSDevicePolicy) {
                    mplsPolicies.add(devicePolicy);
                } else if (devicePolicy instanceof GTPDevicePolicy) {
                    gtpPolicies.add(devicePolicy);
                } else if (devicePolicy instanceof TunnelDevicePolicy) {
                    tunnelPolicies.add(devicePolicy);
                } else if (devicePolicy instanceof ReservedVlanDevicePolicy) {
                    reservedVlanPolicies.add(devicePolicy);
                } else if (devicePolicy instanceof SlxPtpPolicy) {
                    slxPtpPolicies.add(devicePolicy);
                }
            });
            policyMap.put("mplsDevicePolicies", mplsPolicies);
            policyMap.put("gtpDevicePolicies", gtpPolicies);
            policyMap.put("tunnelDevicePolicies", tunnelPolicies);
            policyMap.put("reservedVlanDevicePolicies", reservedVlanPolicies);
            policyMap.put("slxPtpPolicies",slxPtpPolicies);
        }
        return policyMap;
    }

    /**
     * This method validates if DevicePolicy data is valid to commit on the given device
     *
     * @param devicePolicies
     * @param device
     * @param policyName
     * @param isUpdate
     * @throws ValidationException
     */
    @Override
    public void validateDevicePolicies(Set<? extends DevicePolicy> devicePolicies, Device device, String policyName, boolean isUpdate) {
        if (!devicePolicies.isEmpty()) {
            DevicePolicy devicePolicy = devicePolicies.stream().findFirst().get();
            if (!isValidPolicy(devicePolicy)) {
                throw new ValidationException("devicePolicy.data.invalid");
            }
        }
    }

    protected abstract boolean isValidPolicy(DevicePolicy policy);

    protected abstract Long commitPolicy(DevicePolicy policy);

    protected abstract Long updatePolicy(DevicePolicy policy);

    public abstract Long deletePolicy(Long policyId);

    public abstract Long recoverPolicy(Long policyId);
}
