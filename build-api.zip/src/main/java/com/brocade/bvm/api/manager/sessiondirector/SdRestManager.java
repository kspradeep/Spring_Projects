package com.brocade.bvm.api.manager.sessiondirector;


import com.brocade.bvm.outbound.sessiondirector.SessionDirectorConnection;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Named
public class SdRestManager {
    @Inject
    protected SessionDirectorConnection sessionDirectorConnection;

    /**
     * This method initiates SD Rest Call and returns the Response
     *
     * @param ipAddress
     * @param url
     * @return
     */
    public Response getResponse(String ipAddress, String url) {
        sessionDirectorConnection.setBaseUrl(ipAddress);
        log.debug("Requested rest URL is " + url + " & SD device IP is " + ipAddress);
        return sessionDirectorConnection.get(url);
    }

    /**
     * This method extracts the response and sends the JSON Object of it
     *
     * @param res
     * @return
     * @throws JSONException
     */
    public JSONObject getJsonFromResponse(Response res) throws JSONException {
        String responseString = res.readEntity(String.class);
        return new JSONObject(responseString);
    }

    /**
     * This method is used to extract data from response in same order
     *
     * @param res
     * @return
     */
    public Map<String, Object> getJsonResponseInMap(Response res) {
        String responseString = res.readEntity(String.class);
        ObjectMapper mapper = new ObjectMapper();
        HashMap<String, Object> map = null;
        try {
            map = mapper.readValue(responseString, new TypeReference<Map<String, Object>>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }
}
