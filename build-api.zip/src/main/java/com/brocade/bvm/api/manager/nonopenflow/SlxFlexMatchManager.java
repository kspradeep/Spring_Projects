package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractTemplatePolicyManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.FlexMatchProfileRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.FlexHeader;
import com.brocade.bvm.model.db.FlexMatchProfile;
import com.brocade.bvm.model.db.TemplatePolicy;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The SlxFlexMatchManager class implements methods to create Flex Match profiles for SLX Classic device
 */
@Named
@Slf4j
public class SlxFlexMatchManager extends AbstractTemplatePolicyManager {

    @Inject
    private FlexMatchProfileRepository flexMatchProfileRepository;

    private static final String PROFILE_NAME_PATTERN = "^[A-Za-z][A-Za-z0-9_\\-]*$";

    @Inject
    private PolicyRepository policyRepository;

    private static final long MIN_SLX_9850_OFFSET = 0;

    private static final long MAX_SLX_9850_OFFSET = 63;

    @Override
    protected boolean isValidPolicy(TemplatePolicy policy) {
        return true;
    }

    /**
     * This method is used to save Flex Match Profile
     *
     * @param policy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    protected Long savePolicy(TemplatePolicy policy) {
        FlexMatchProfile flexMatchProfile = (FlexMatchProfile) policy;
        if (flexMatchProfile.getName() != null) {
            FlexMatchProfile flexMatchProfileDb = flexMatchProfileRepository.findByName(flexMatchProfile.getName());
            if(flexMatchProfileDb != null) {
                flexMatchProfile.setIsDefault(flexMatchProfileDb.getIsDefault());
            }
        }
        isFlexMatchProfileValid(flexMatchProfile);
        flexMatchProfile.setName(flexMatchProfile.getName().trim());
        flexMatchProfile.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        flexMatchProfileRepository.save(flexMatchProfile);
        log.debug("Flex Match Profile saved. id:{} name:{}", flexMatchProfile.getId(), flexMatchProfile.getName());
        return flexMatchProfile.getId();
    }

    @Override
    protected Long commitPolicy(TemplatePolicy policy) {
        Long profileId = -1L;
        if (policy != null) {
            if (policy.getId() != null) {
                //TODO update scenario, need to validate the usage of profile in other policies.
            }
            profileId = savePolicy(policy);
        }
        return profileId;
    }

    @Override
    protected Long updatePolicy(TemplatePolicy policy) {
        return commitPolicy(policy);
    }


    /**
     * This method is used to delete flex Match Profile
     *
     * @param profileId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deletePolicy(Long profileId) {
        FlexMatchProfile flexMatchProfile = flexMatchProfileRepository.findOne(profileId);
        if (flexMatchProfile == null) {
            log.error("Flex Match Profile doesn't exists. id {}", profileId);
            throw new ValidationException("profile.id.invalid");
        }
        List<Long> policyIds = policyRepository.findIdsByFlexMatchProfileId(profileId);
        if (policyIds != null && !policyIds.isEmpty()) {
            throw new ValidationException("profile.delete.used.in.policy");
        }
        flexMatchProfileRepository.delete(flexMatchProfile);
        return flexMatchProfile.getId();
    }

    @Override
    public Long recoverPolicy(Long policyId) {
        return null;
    }

    /*
    This method is used to validate the Flex Match Profile
    @param flexMatchProfile
     */
    public void isFlexMatchProfileValid(FlexMatchProfile flexMatchProfile) {
        if (flexMatchProfile.getName() == null) {
            log.error("Profile name cannot not be empty");
            throw new ValidationException("uda.profile.name.empty");
        } else if (flexMatchProfile.getName().length() > FlexMatchProfile.PROFILE_NAME_MAX_LENGTH) {
            log.error("Profile name should not exceed 63 characters");
            throw new ValidationException("uda.profile.name.max.length");
        }
        Pattern pattern = Pattern.compile(PROFILE_NAME_PATTERN);
        Matcher matcher = pattern.matcher(flexMatchProfile.getName());
        if (!matcher.matches()) {
            log.error("Profile name should start with a letter, and can contain letters, numbers, hyphen and underscores.");
            throw new ValidationException("uda.profile.name.invalid.pattern");
        }
        if (flexMatchProfile.getId() == null) {
            FlexMatchProfile flexMatchProfileDb = flexMatchProfileRepository.findByName(flexMatchProfile.getName());
            if (flexMatchProfileDb != null) {
                log.error("Flex Match Profile with the same name already exists.");
                throw new ValidationException("profile.name.already.exists");
            }
        } else {
            FlexMatchProfile flexMatchProfileDb = flexMatchProfileRepository.findOne(flexMatchProfile.getId());
            if (flexMatchProfileDb != null && !flexMatchProfileDb.getName().equals(flexMatchProfile.getName())) {
                log.error("Profile name of an existing Flex Match cannot be modified. id {}", flexMatchProfile.getId());
                throw new ValidationException("profile.name.change.not.allowed");
            }
            List<Long> policyIds = policyRepository.findIdsByFlexMatchProfileId(flexMatchProfile.getId());
            if (policyIds != null && !policyIds.isEmpty()) {
                throw new ValidationException("profile.update.used.in.policy");
            }
        }
        //Check if at least 1 field is selected
        FlexHeader flexMatchHeader = flexMatchProfile.getFlexHeaders().stream().filter(flexHeader -> {
            return flexHeader.getFlexHeaderFields().size() > 0;
        }).findAny().orElse(null);
        if (flexMatchHeader == null) {
            log.error("At least one field to be selected to save the profile.");
            throw new ValidationException("profile.min.field.selection.invalid");
        }
        boolean isSLX9850 = Device.Type.SLX.name().equals(flexMatchProfile.getDeviceType()) && flexMatchProfile.getDeviceModel().contains(FlexMatchProfile.SLX_9850);
        AtomicInteger atomicInteger = new AtomicInteger(0);
        if (flexMatchProfile.getFlexHeaders() != null) {
            Set<Integer> headerStackLevels = Sets.newHashSet();
            int headerByteLength = 0;
            for (FlexHeader flexHeader : flexMatchProfile.getFlexHeaders()) {
                headerStackLevels.add(flexHeader.getHeaderLevel());
                FlexHeader.HEADER_BYTE_LENGTH header_byte_length = FlexHeader.HEADER_BYTE_LENGTH.valueOf(flexHeader.getHeaderName().value());
                if (header_byte_length != null) {
                    headerByteLength += header_byte_length.getByteLength();
                }
                flexHeader.getFlexHeaderFields().forEach(flexHeaderField -> {
                    atomicInteger.getAndAdd(1);
                    if (isSLX9850) {
                        Integer validOffset = flexHeaderField.getCustomOffset() > -1 ? flexHeaderField.getCustomOffset() + flexHeaderField.getOffset() : flexHeaderField.getOffset();
                        if (validOffset < MIN_SLX_9850_OFFSET || validOffset > MAX_SLX_9850_OFFSET) {
                            log.error("Cannot save FlexMatch profile as Field Offset range is invalid.");
                            throw new ValidationException("policy.save.fieldOffsetRangeInvalid");
                        }
                    }
                });
            }
            if (headerByteLength > FlexHeader.HEADER_BYTE_LENGTH_MAX) {
                log.error("FlexMatch Profile cannot be saved as the byte length of the Header Stack exceeds " + FlexHeader.HEADER_BYTE_LENGTH_MAX + " bytes.");
                throw new ValidationException("uda.profile.field.byteLength.exceeded");
            }
            if (!isHeaderStackConsecutive(headerStackLevels)) {
                log.error("Header stack should be indexed continuously.");
                throw new ValidationException("uda.header.stack.index.not.continuous");
            }
        }
        if (atomicInteger.get() > 4) {
            log.error("Maximum 4 fields are allowed to be configured.");
            throw new ValidationException("uda.profile.field.max.allowed");
        }
    }

    private boolean isHeaderStackConsecutive(Set<Integer> headerStackLevels) {
        if (headerStackLevels != null && !headerStackLevels.isEmpty()) {
            for (int i = 0; i < headerStackLevels.size(); i++) {
                if (!headerStackLevels.contains(i)) {
                    return false;
                }
            }
        }
        return true;
    }
}
