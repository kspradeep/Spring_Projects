package com.brocade.bvm.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeviceAdditionResponse {

    @JsonProperty
    private String deviceIp;

    @JsonProperty
    private String status;

    @JsonProperty
    private String errorMessage;

}
