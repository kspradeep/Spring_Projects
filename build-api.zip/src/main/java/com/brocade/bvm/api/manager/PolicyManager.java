package com.brocade.bvm.api.manager;

import com.brocade.bvm.model.db.Policy;

public interface PolicyManager {
    /**
     * return saved/updated policyid
     */
    Long savePolicy(Policy policy, boolean isStandalone);

    Long commitPolicy(Policy policy, boolean isStandalone);

    Long deletePolicy(Long policyId, boolean isRetainAsDraft, boolean isStandalone);

    Long rollbackPolicy(Long policyId, boolean isStandalone);

    void validateCopyPolicy(Policy policy);

    Long copyPolicy(Policy policy, boolean isStandalone);

    Policy getCopyPolicy(Policy existingPolicy, Long deviceId);

}
