package com.brocade.bvm.api.manager.generic;

import com.brocade.bvm.api.manager.PortManager;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.utility.GenericHelper;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.sessiondirector.IngressPortRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.math.BigInteger;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The AbstractPortManager class implements methods to perform port operations like enable/disable, mark as ingress/egress/service port/none and recovery
 */
@Slf4j
public abstract class AbstractPortManager implements PortManager {
    @Inject
    protected PortRepository portRepository;

    @Inject
    protected PolicyRepository policyRepository;

    @Inject
    protected DeviceRepository deviceRepository;

    @Inject
    protected PortGroupRepository portGroupRepository;

    @Inject
    protected FlowRepository flowRepository;

    @Inject
    protected JobQueue jobQueue;

    @Inject
    private JobRepository jobRepository;

    @Inject
    private GenericHelper genericHelper;

    @Value("${stablenet-response.timeout.minutes}")
    private int stablenetTimeoutMinutes;

    @Value("${job.poll.interval.seconds:3}")
    private int jobPollIntervalSeconds;

    @Value("${slx.internal.loopback.supported.os.version:18.1.01}")
    private String slxLoopBackSupportedVersion;

    @Inject
    protected EntityManager entityManager;

    @Inject
    private IngressPortRepository ingressPortRepository;

    @Inject
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    /**
     * This method is used to enable or disable the selected port(s) on the given device
     *
     * @param deviceId
     * @param portIds
     * @param status
     * @param mode
     * @return Long This returns jobId
     */
    @Override
    public long changeAdminStatus(Long deviceId, List<Long> portIds, Port.AdminStatus status, Port.Mode mode) {
        //Get only those ports from passed list whose status is not same as passed status
        List<Port> applicablePorts = filterAdminPorts(portIds, status, mode);
        isValidForAdminStatus(portIds);
        //Validate
        //1. Fail if any port or it's portGroup has a submitted job
        //2. Fail if any port is a participant in PortGroup.
        if (applicablePorts.stream().anyMatch(port -> port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)) {
            throw new ValidationException("port.config.inprogress");
        }

        if (applicablePorts.isEmpty()) {
            log.error("Selected Port(s) are already marked as " + status.name());
            throw new ValidationException("Selected Port(s) are already marked as " + status.name());
        }

        for (Port port : applicablePorts) {
            Long portGroupId = portGroupRepository.findByPortId(port.getId());
            PortGroup portGroup = null;
            if (portGroupId != null) {
                portGroup = portGroupRepository.findOne(portGroupId);
                if (port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED
                        || (portGroup != null && portGroup.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)) {
                    log.error("Port configuration is in progress. Please try after sometime.");
                    throw new ValidationException("port.config.inprogress");
                } else if (port.getModule().getDevice().getMode() == Device.Mode.OPENFLOW) {
                    log.error("Port is part of Port Group. Aborting!");
                    throw new ValidationException("port.used.portGroup");
                }
            }
        }

        Job.Type jobType;
        switch (status) {
            case ENABLED:
                jobType = Job.Type.PORT_ENABLE;
                break;
            case DISABLED:
                jobType = Job.Type.PORT_DISABLE;
                break;
            default:
                throw new ValidationException("Invalid port status!");
        }

        applicablePorts.stream().forEach(port -> {
            port.setAdminStatus(status);
            port.setMode(mode);
            port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            port.setBvmDefinedLastUpdatedTime(Instant.now());
        });

        portRepository.save(applicablePorts);

        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
        }
        return getAdminStatus(deviceId, applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()));
    }

    /**
     * Get the admin status of the ports
     *
     * @param deviceId
     * @param portIds
     * @return
     */
    @Override
    public long getAdminStatus(Long deviceId, List<Long> portIds) {
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(Job.Type.PORT_LINK_STATUS)
                .deviceId(deviceId)
                .impactedObjectIds(portIds)
                .build());
        return jobId;
    }

    protected abstract void isValidForAdminStatus(List<Long> portIds);

    protected abstract void isValidForTypeChange(Long deviceId, List<Long> portIds);

    protected abstract boolean isPortTypeJobRequired();

    protected abstract List<Port> filterAdminPorts(List<Long> portIds, Port.AdminStatus status, Port.Mode mode);


    /**
     * This method is used to mark selected port(s) as ingress/egress/service port/none on the given device
     *
     * @param deviceId
     * @param portIds
     * @param type
     * @return Long This returns jobId
     */
    @Override
    public long changeType(Long deviceId, List<Long> portIds, Port.Type type, boolean isLoopbackEnable) {
        long jobId = 0; // Return 0 if no job is created
        validatePortsWithPacketTruncation(portIds, deviceId);
        List<Port> applicablePorts = null;
        //Get only those ports from passed list whose type is not same as passed type
        if (isLoopbackEnable && Port.Type.SERVICE_PORT == type) {
            applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                    .filter(port -> !port.isLoopbackEnabled())
                    .collect(Collectors.toList());
        } else {
            applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                    .filter(port -> port.getType() != type)
                    .collect(Collectors.toList());
            List<Port> portsWithSameType = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                    .filter(port -> port.getType() == type)
                    .collect(Collectors.toList());

            if (!portsWithSameType.isEmpty() && portIds.size() == portsWithSameType.size()) {
                log.error("Selected Port(s) are already marked as " + type);
                throw new ValidationException("Selected Port(s) are already marked as " + type);
            }
        }

        List<Long> applicablePortIds = applicablePorts.stream().map(Port::getId).collect(Collectors.toList());
        if (!applicablePortIds.isEmpty()) {
            //Validate
            //1. WorkflowStatus
            if (applicablePorts.stream().anyMatch(port -> port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)) {
                throw new ValidationException("port.config.inprogress");
            }

            //2. isPortInPolicy
            List<BigInteger> policyIds = flowRepository.findPolicyIdsInIngressPortMapping(applicablePortIds);
            policyIds.addAll(flowRepository.findPolicyIdsInEgressPortMapping(applicablePortIds));
            if (policyIds != null && policyIds.size() > 0) {
                policyIds.stream().forEach(policyId -> {
                    Policy policy = policyRepository.findOne(policyId.longValue());
                    if (policy != null) {
                        log.error("Port already in use in Policy {}", policy.getId());
                        throw new ValidationException("port.operation.usedinpolicy");
                    }
                });
            }

            Device device = deviceRepository.findOne(deviceId);
            if (!applicablePortIds.isEmpty()) {
                //3. isPortInPortGroup
                if (!portGroupRepository.findPortGroupIdsByPortIds(applicablePortIds).isEmpty()) {
                    if (device != null && (Device.Type.SLX == device.getType() && TargetHost.Mode.PLAIN == device.getMode())) {
                        throw new ValidationException("port.used.portChannel");
                    } else {
                        throw new ValidationException("port.used.portGroup");
                    }
                }

                //4. Check if any participating ports are either part of packet slicing policy or not.
                List<Long> truncateEnabledPorts = portGroupRepository.findTruncateEnabledEgressPorts(applicablePortIds);
                if (!truncateEnabledPorts.isEmpty()) {
                    log.error("Participating port(s) are part of packet slicing policy. Aborting!");
                    throw new ValidationException("port.egressTruncate.enabled.packetSlicing");
                }

                //5. Check if participating ports are in use by SD Ingress Ports as Service Ports
                if (!ingressPortRepository.findByServicePortIds(applicablePortIds).isEmpty()) {
                    log.error("Participating ports are in use by SD Ingress Port(s) as Servie Port(s). Aborting!");
                    throw new ValidationException("port.exists.sdIngress");
                }
            }

            isValidForTypeChange(deviceId, applicablePortIds);
            Boolean isSlx = Device.Type.SLX.equals(device.getType());

            Job.Type jobType;
            switch (type) {
                case INGRESS:
                    jobType = Job.Type.PORT_MARK_INGRESS;
                    break;
                case EGRESS:
                    jobType = Job.Type.PORT_MARK_EGRESS;
                    break;
                case SERVICE_PORT:
                    if (isSlx) {
                        jobType = Job.Type.PORT_MARK_SERVICE;
                    } else {
                        jobType = Job.Type.PORT_MARK_NONE;
                    }
                    break;
                default:
                    jobType = Job.Type.PORT_MARK_NONE;
            }

            AtomicBoolean filterPortsForLLDPAndLoopBack = new AtomicBoolean(false);
            if (isSlx) {
                filterPortsForLLDPAndLoopBack.set(filterPortsForLLDPAndLoopBack(device, applicablePorts, jobType, isLoopbackEnable));
            }

            applicablePorts.stream().forEach(port -> {
                port.setType(type);
                if (isSlx) {
                    if (!filterPortsForLLDPAndLoopBack.get()) {
                        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
                    } else {
                        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
                    }
                    port.setWorkflowType(jobType);
                } else {
                    port.setLoopbackEnabled(false);
                }
            });
            portRepository.save(applicablePorts);

            if (isPortTypeJobRequired()) {
                if (isSlx) {
                    if (filterPortsForLLDPAndLoopBack.get()) {
                        jobId = jobQueue.submit(JobTemplate.builder()
                                .type(jobType)
                                .deviceId(deviceId)
                                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                                .build());
                    } else {
                        log.info("Saved in database no commands to execute on the device {}", deviceId);
                    }
                } else {
                    jobId = jobQueue.submit(JobTemplate.builder()
                            .type(jobType)
                            .deviceId(deviceId)
                            .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                            .build());
                }
            }
        }
        return jobId;
    }

    /**
     * Check whether to enable/disable LLDP on the interface
     *
     * @param applicablePorts
     * @param jobType
     * @return
     */
    private boolean filterPortsForLLDPAndLoopBack(Device device, List<Port> applicablePorts, Job.Type jobType, boolean isLoopbackEnable) {
        boolean isSlxLoopbackSupported = genericHelper.isSLXVersionValid(device.getOs(), slxLoopBackSupportedVersion) >= 0;
        AtomicBoolean isExecuteCommand = new AtomicBoolean(false);
        if (Job.Type.PORT_MARK_SERVICE == jobType || Job.Type.PORT_MARK_NONE == jobType) {
            applicablePorts.stream().forEach(port -> {
                if (Job.Type.PORT_MARK_SERVICE == jobType && isSlxLoopbackSupported) {
                    port.setLoopbackEnabled(isLoopbackEnable);
                    if (isLoopbackEnable) {
                        isExecuteCommand.set(true);
                    }
                } else if (Job.Type.PORT_MARK_NONE == jobType) {
                    port.setLoopbackEnabled(false);
                    isExecuteCommand.set(true);
                }
            });
        } else if (applicablePorts.stream().anyMatch(port -> (Port.Type.SERVICE_PORT == port.getType()))) {
            applicablePorts.stream().forEach(port -> {
                if (port.isLoopbackEnabled()) {
                    port.setLoopbackEnabled(false);
                    isExecuteCommand.set(true);
                }
            });
        }
        return isExecuteCommand.get();
    }

    /**
     * This method is used to recover selected port(s) which are in error state on the given device
     *
     * @param deviceId
     * @param portIds
     * @return Long This returns jobId
     */
    @Override
    public long recoverPort(Long deviceId, List<Long> portIds) {

        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .collect(Collectors.toList());
        List<Long> applicablePortIds = applicablePorts.stream().map(Port::getId).collect(Collectors.toList());
        //Validate
        //1. WorkflowStatus
        if (applicablePorts.stream().anyMatch(port -> port.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR)) {
            throw new ValidationException("port.recovery.notallowed");
        }
        if (!applicablePortIds.isEmpty()) {
            Device device = deviceRepository.findOne(deviceId);
            //3. isPortInPortGroup
            if (!portGroupRepository.findPortGroupIdsByPortIds(applicablePortIds).isEmpty()) {
                if (device != null && (Device.Type.SLX == device.getType() && TargetHost.Mode.PLAIN == device.getMode())) {
                    throw new ValidationException("port.used.portChannel");
                } else {
                    throw new ValidationException("port.used.portGroup");
                }
            }
        }
        applicablePorts.stream().forEach(port -> {
            port.setType(Port.Type.NONE);
            port.setAdminStatus(Port.AdminStatus.DISABLED);
            //	port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
            port.setCustomDescription("");
            port.setMode(null);
        });

        portRepository.save(applicablePorts);

        Job.Type jobType = Job.Type.PORT_MARK_RECOVER;
        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());

        return jobId;
    }

    /**
     * This method is used to create/update/delete port description for the given port, on the selected device
     *
     * @param deviceId
     * @param portIds
     * @return Long This returns jobId
     */
    @Override
    public long updateDescription(Long deviceId, List<Long> portIds, String description) {
        if (description != null && description.contains("?")) {
            throw new ValidationException("Port description cannot contain question mark.");
        }
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toList());

        applicablePorts.stream().forEach(port -> {
            port.setCustomDescription(description);
            port.setBvmDefinedLastUpdatedTime(Instant.now());
            port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        });

        portRepository.save(applicablePorts);

        long jobId = jobQueue.submit(JobTemplate.builder()
                .type(Job.Type.PORT_DESCRIPTION)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());

        return jobId;
    }

    /**
     * @param deviceId
     * @param portIds
     * @param breakout
     * @return
     */
    public long applyOrRemoveBreakout(Long deviceId, List<Long> portIds, boolean breakout, Long breakoutSpeed) {
        List<Port> applicablePorts = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false)
                .collect(Collectors.toList());
        //Validate
        isValidForBreakout(deviceId, applicablePorts, breakout, breakoutSpeed);
        portRepository.save(applicablePorts);
        long jobId = 0; // Return 0 if no job is created
        Job.Type jobType = breakout ? Job.Type.PORT_BREAKOUT_ENABLE : Job.Type.PORT_BREAKOUT_DISABLE;
        jobId = jobQueue.submit(JobTemplate.builder()
                .type(jobType)
                .deviceId(deviceId)
                .impactedObjectIds(applicablePorts.stream().map(ManagedObject::getId).collect(Collectors.toList()))
                .build());

        return jobId;
    }

    /**
     * This method validates if all the selected ports are qualified for type change
     *
     * @param deviceId
     * @param applicablePorts
     * @throws ValidationException
     */
    protected void isValidForBreakout(Long deviceId, List<Port> applicablePorts, boolean breakout, Long breakoutSpeed) {
        //Validate
        //1. WorkflowStatus
        if (applicablePorts.stream().anyMatch(port -> {
            return (breakout && ((port.getWorkflowStatus() != null && port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.ERROR && port.getLineSpeed() != 40000) || port.getName().contains(":")));
        })) {
            throw new ValidationException("port.breakout.notallowed");
        }

        if (applicablePorts.stream().anyMatch(port -> port.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED)) {
            throw new ValidationException("port.config.inprogress");
        }
        List<Long> allPorts = new ArrayList<>();
        for (Port port : applicablePorts) {
            if (breakoutSpeed != null) {
                //valid breakout speed and max speed combination to be allowed
                if (port.getLineSpeed() == null || (port.getLineSpeed() != null && port.getLineSpeed().longValue() == Port.SPEED_0)) {
                    throw new ValidationException("Set the Port Line Speed before enabling breakout.");
                } else if (breakoutSpeed.longValue() == Port.SPEED_25G && port.getLineSpeed().longValue() == Port.SPEED_100G || breakoutSpeed.longValue() == Port.SPEED_10G && port.getLineSpeed().longValue() == Port.SPEED_40G) {
                    //valid breakout speed and max speed combination to be allowed
                    port.setLineSpeed(breakoutSpeed);
                } else {
                    throw new ValidationException("4*25G breakout is supported on 100G ports only, and 4*10G breakout is supported on 40G ports only.");
                }
            }
            if (!breakout) {
                String portName = port.getName().split(":")[0];
                List<Long> allBreakOutPorts = StreamSupport.stream(portRepository.getPortsByNameAndDeviceId(portName + ":", deviceId).spliterator(), false).map(Port::getId).collect(Collectors.toList());
                allPorts.addAll(allBreakOutPorts);
            } else {
                allPorts.add(port.getId());
            }
        }
        // #1 Check if participating port is associated with Port-Group
        if (!portGroupRepository.findPortIdsByPortIds(allPorts).isEmpty()) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (Device.Type.SLX == device.getType() && TargetHost.Mode.PLAIN == device.getMode())) {
                log.error("Cannot perform this action as the port(s) are used in a port-channel.");
                throw new ValidationException("port.breakout.exists.portChannel");
            } else {
                log.error("Cannot perform this action as the port(s) are used in a port-group.");
                throw new ValidationException("port.breakout.exists.portgroup");
            }
        }

        // #2 Check if participating ports are in use by policies(flows) as EGREES or SERVICE_PORT
        if (!portGroupRepository.findIngressOrEgressPortIdsByPortIdsInPolicy(allPorts).isEmpty()) {
            log.error("Participating ports are in use by policies as EGRESS. Aborting!");
            throw new ValidationException("port.breakout.exists.policy");
        }
    }

    /**
     * Validates the ports, is it used in packet truncation or not
     *
     * @param managedObjectIds
     */
    private void validatePortsWithPacketTruncation(List<Long> managedObjectIds, Long deviceId) {
        if (!managedObjectIds.isEmpty() && !packetTruncationMappingRepository.findPortsByDeviceIdAndPortIds(deviceId, managedObjectIds).isEmpty()) {
            throw new ValidationException("Cannot create/update the port(s) as it is used in a Packet Truncation profile.");
        }
    }
}
