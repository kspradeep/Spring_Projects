package com.brocade.bvm.api.utility;

import com.brocade.bvm.model.db.grid.*;

import javax.inject.Named;
import java.util.Comparator;
import java.util.List;

@Named
public class GridPolicySetComparator implements Comparator<GridPolicySet> {
    /**
     * This method compares oldPolicy with updated policy
     *
     * @param oldPolicy
     * @param newPolicy
     * @return int returns 0 if equal and -1 if not equal
     */
    @Override
    public int compare(GridPolicySet oldPolicy, GridPolicySet newPolicy) {
        if (oldPolicy.getName() != null ? !oldPolicy.getName().equals(newPolicy.getName()) : newPolicy.getName() != null)
            return -1;
        if (oldPolicy.getFieldOffset1() != null ? !oldPolicy.getFieldOffset1().equals(newPolicy.getFieldOffset1()) : newPolicy.getFieldOffset1() != null)
            return -1;
        if (oldPolicy.getFieldOffset2() != null ? !oldPolicy.getFieldOffset2().equals(newPolicy.getFieldOffset2()) : newPolicy.getFieldOffset2() != null)
            return -1;
        if (oldPolicy.getFieldOffset3() != null ? !oldPolicy.getFieldOffset3().equals(newPolicy.getFieldOffset3()) : newPolicy.getFieldOffset3() != null)
            return -1;
        if (oldPolicy.getFieldOffset4() != null ? !oldPolicy.getFieldOffset4().equals(newPolicy.getFieldOffset4()) : newPolicy.getFieldOffset4() != null)
            return -1;
        if (oldPolicy.isLoopbackEnabled() != newPolicy.isLoopbackEnabled())
            return -1;
        if (oldPolicy.isPreserveHeader() != newPolicy.isPreserveHeader())
            return -1;
        if (oldPolicy.isTimestamp() != newPolicy.isTimestamp())
            return -1;
        if (oldPolicy.getIsOverSubscriptionAllowed() != newPolicy.getIsOverSubscriptionAllowed())
            return -1;
        if (oldPolicy.getIsCspfEnabled() != newPolicy.getIsCspfEnabled())
            return -1;
        if (oldPolicy.isGtpHttpFiltered() != newPolicy.isGtpHttpFiltered())
            return -1;
        if (oldPolicy.isIngressValid() != newPolicy.isIngressValid())
            return -1;
        if (oldPolicy.getEgressAction() != null ? !oldPolicy.getEgressAction().equals(newPolicy.getEgressAction()) : newPolicy.getEgressAction() != null)
            return -1;
        if (oldPolicy.getFlexMatchProfiles() != null && newPolicy.getFlexMatchProfiles() != null) {
            if (oldPolicy.getFlexMatchProfiles().size() != newPolicy.getFlexMatchProfiles().size()) {
                return -1;
            } else if (oldPolicy.getFlexMatchProfiles().size() > 0 && newPolicy.getFlexMatchProfiles().size() > 0 &&
                    oldPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue() != newPolicy.getFlexMatchProfiles().stream().findFirst().get().getId().longValue()) {
                return -1;
            }
        }

        //Creating new rules even when sequence is spoiled
        List<GridPolicy> oldFlowList = oldPolicy.getGridPolicies().asList();
        List<GridPolicy> newFlowList = newPolicy.getGridPolicies().asList();
        int result = -1;
        if (oldFlowList.size() == newFlowList.size()) {
            for (int i = 0; i < newFlowList.size(); i++) {
                GridPolicy newFlow = newFlowList.get(i);
                GridPolicy oldFlow = oldFlowList.stream().filter(flow -> flow.getId().equals(newFlow.getId())).findFirst().orElse(null);
                if (oldFlow != null && newFlow != null) {
                    if (compare(newFlow, oldFlow)) {
                        result = 0;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            }
        }
        return result;
    }

    /**
     * This method compares newFlow with old flow
     *
     * @param newFlow
     * @param oldFlow
     * @return boolean
     */
    private boolean compare(GridPolicy newFlow, GridPolicy oldFlow) {
        if (newFlow.getTvfDomain() != oldFlow.getTvfDomain())
            return false;
        if (newFlow.getIsDefaultRouteMapDrop() != oldFlow.getIsDefaultRouteMapDrop())
            return false;
        if (newFlow.getIsTagged() != oldFlow.getIsTagged())
            return false;
        if (newFlow.getVlanStripping() != oldFlow.getVlanStripping())
            return false;
        if (newFlow.getTaggedVlanId() != oldFlow.getTaggedVlanId())
            return false;
        if (newFlow.getSequence() != null ? !newFlow.getSequence().equals(oldFlow.getSequence()) : oldFlow.getSequence() != null)
            return false;
        if (newFlow.getSourceMacTag() != null ? !newFlow.getSourceMacTag().equals(oldFlow.getSourceMacTag()) : oldFlow.getSourceMacTag() != null)
            return false;
        if (newFlow.getDestinationMacTag() != null ? !newFlow.getDestinationMacTag().equals(oldFlow.getDestinationMacTag()) : oldFlow.getDestinationMacTag() != null)
            return false;
        if (newFlow.getVlans() != null ? !newFlow.getVlans().equals(oldFlow.getVlans()) : oldFlow.getVlans() != null)
            return false;
        if (newFlow.getRuleSets() != null && oldFlow.getRuleSets() != null && !compareRuleSets(newFlow.getRuleSets().asList(), oldFlow.getRuleSets().asList()))
            return false;
        if (newFlow.getIngressClusterNodeInterfaces() != null && oldFlow.getIngressClusterNodeInterfaces() != null && !comparePorts(newFlow.getIngressClusterNodeInterfaces().asList(), oldFlow.getIngressClusterNodeInterfaces().asList()))
            return false;
        return (newFlow.getEgressClusterNodeInterfaces() != null && oldFlow.getEgressClusterNodeInterfaces() != null && comparePorts(newFlow.getEgressClusterNodeInterfaces().asList(), oldFlow.getEgressClusterNodeInterfaces().asList()));
    }

    /**
     * This method compares newPorts with oldPorts
     *
     * @param nPortList
     * @param oPortList
     * @return boolean
     */
    private boolean comparePorts(List<ClusterNodeInterface> nPortList, List<ClusterNodeInterface> oPortList) {
        boolean isEqual = true;
        if (nPortList.size() == oPortList.size()) {
            for (int ctr = 0; ctr < nPortList.size(); ctr++) {
                ClusterNodeInterface newPort = nPortList.get(ctr);
                ClusterNodeInterface oldPort = oPortList.stream().filter(port -> port.getId().equals(newPort.getId())).findFirst().orElse(null);
                if (oldPort != null) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        } else if (nPortList.size() != oPortList.size()) {
            isEqual = false;
        }
        return isEqual;
    }

    /**
     * This method compares newRuleSets with oldRuleSets
     *
     * @param nRuleSetList
     * @param oRuleSetList
     * @return boolean
     */
    private boolean compareRuleSets(List<GridRuleSet> nRuleSetList, List<GridRuleSet> oRuleSetList) {
        boolean isEqual = false;
        if (nRuleSetList.size() == oRuleSetList.size()) {
            for (int ctr = 0; ctr < nRuleSetList.size(); ctr++) {
                if (compare(nRuleSetList.get(ctr), oRuleSetList.get(ctr))) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        }
        return isEqual;
    }

    /**
     * This method compares newRuleSet with oldRuleSet
     *
     * @param nRuleSet
     * @param oRuleSet
     * @return boolean
     */
    private boolean compare(GridRuleSet nRuleSet, GridRuleSet oRuleSet) {
        boolean isEqual = false;
        //Even change in name can spoil validation of object
        if ((nRuleSet.getType() == oRuleSet.getType()) && (nRuleSet.getIpVersion() == oRuleSet.getIpVersion())) {
            isEqual = compareRule(nRuleSet.getRules().asList(), oRuleSet.getRules().asList());
        }
        return isEqual;
    }


    /**
     * This method compares newRules with oldRules
     *
     * @param nRuleList
     * @param oRuleList
     * @return boolean
     */
    private boolean compareRule(List<GridRule> nRuleList, List<GridRule> oRuleList) {
        boolean isEqual = false;
        if (nRuleList.size() == oRuleList.size()) {
            for (int ctr = 0; ctr < nRuleList.size(); ctr++) {
                if (compare(nRuleList.get(ctr), oRuleList.get(ctr))) {
                    isEqual = true;
                } else {
                    return false;
                }
            }
        }
        return isEqual;
    }

    /**
     * This method compares newRule with oldRule
     *
     * @param rule
     * @param nRule
     * @return boolean
     */
    private boolean compare(GridRule rule, GridRule nRule) {
        if (rule.getSourcePort() != null ? !rule.getSourcePort().equals(nRule.getSourcePort()) : nRule.getSourcePort() != null) return false;
        if (rule.getDestinationPort() != null ? !rule.getDestinationPort().equals(nRule.getDestinationPort()) : nRule.getDestinationPort() != null) return false;
        if (rule.getVlanId() != null ? !rule.getVlanId().equals(nRule.getVlanId()) : nRule.getVlanId() != null) return false;
        if (rule.getIsPermit() != nRule.getIsPermit()) return false;
        if (rule.getIsCountEnabled() != nRule.getIsCountEnabled()) return false;
        if (rule.getSourceIp() != null ? !rule.getSourceIp().equals(nRule.getSourceIp()) : nRule.getSourceIp() != null)
            return false;
        if (rule.getSourcePortOperator() != null ? !rule.getSourcePortOperator().equals(nRule.getSourcePortOperator()) : nRule.getSourcePortOperator() != null)
            return false;
        if (rule.getDestinationIp() != null ? !rule.getDestinationIp().equals(nRule.getDestinationIp()) : nRule.getDestinationIp() != null)
            return false;
        if (rule.getDestinationPortOperator() != null ? !rule.getDestinationPortOperator().equals(nRule.getDestinationPortOperator()) : nRule.getDestinationPortOperator() != null)
            return false;
        if (rule.getProtocol() != null ? !rule.getProtocol().equals(nRule.getProtocol()) : nRule.getProtocol() != null)
            return false;
        if (rule.getProtocolType() != null ? !rule.getProtocolType().equals(nRule.getProtocolType()) : nRule.getProtocolType() != null)
            return false;
        if (rule.getCustomAcl() != null ? !rule.getCustomAcl().equals(nRule.getCustomAcl()) : nRule.getCustomAcl() != null)
            return false;
        if (rule.getSourceMac() != null ? !rule.getSourceMac().equals(nRule.getSourceMac()) : nRule.getSourceMac() != null)
            return false;
        if (rule.getSourceMacMask() != null ? !rule.getSourceMacMask().equals(nRule.getSourceMacMask()) : nRule.getSourceMacMask() != null)
            return false;
        if (rule.getDestinationMac() != null ? !rule.getDestinationMac().equals(nRule.getDestinationMac()) : nRule.getDestinationMac() != null)
            return false;
        if (rule.getDestinationMacMask() != null ? !rule.getDestinationMacMask().equals(nRule.getDestinationMacMask()) : nRule.getDestinationMacMask() != null)
            return false;
        if (rule.getEthType() != null ? !rule.getEthType().equals(nRule.getEthType()) : nRule.getEthType() != null)
            return false;
        if (rule.getSequence() != null ? !rule.getSequence().equals(nRule.getSequence()) : nRule.getSequence() != null)
            return false;
        if (rule.getFieldmask1() != null ? !rule.getFieldmask1().equals(nRule.getFieldmask1()) : nRule.getFieldmask1() != null)
            return false;
        if (rule.getFieldmask2() != null ? !rule.getFieldmask2().equals(nRule.getFieldmask2()) : nRule.getFieldmask2() != null)
            return false;
        if (rule.getFieldmask3() != null ? !rule.getFieldmask3().equals(nRule.getFieldmask3()) : nRule.getFieldmask3() != null)
            return false;
        if (rule.getFieldmask4() != null ? !rule.getFieldmask4().equals(nRule.getFieldmask4()) : nRule.getFieldmask4() != null)
            return false;
        if (rule.getFieldValue1() != null ? !rule.getFieldValue1().equals(nRule.getFieldValue1()) : nRule.getFieldValue1() != null)
            return false;
        if (rule.getFieldValue2() != null ? !rule.getFieldValue2().equals(nRule.getFieldValue2()) : nRule.getFieldValue2() != null)
            return false;
        if (rule.getFieldValue3() != null ? !rule.getFieldValue3().equals(nRule.getFieldValue3()) : nRule.getFieldValue3() != null)
            return false;
        if (rule.getMatchPayloadLength() != nRule.getMatchPayloadLength())
            return false;
        if (rule.getIsHexadecimalType1() != nRule.getIsHexadecimalType1())
            return false;
        if (rule.getIsHexadecimalType2() != nRule.getIsHexadecimalType2())
            return false;
        if (rule.getIsHexadecimalType3() != nRule.getIsHexadecimalType3())
            return false;
        if (rule.getIsHexadecimalType4() != nRule.getIsHexadecimalType4())
            return false;
        return rule.getFieldValue4() != null ? rule.getFieldValue4().equals(nRule.getFieldValue4()) : nRule.getFieldValue4() == null;
    }
}
