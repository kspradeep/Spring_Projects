package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.generic.AbstractModulePolicyManager;
import com.brocade.bvm.api.model.ModulePolicyRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.job.JobTemplate;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * The PacketSlicingModulePolicyManagerNonOpenFlow class implements methods to create/update/delete/recover PacketSlicingModulePolicy for NonOpenFlow
 */
@Named("packetSlicingModulePolicyManagerNonOpenFlow")
@Slf4j
public class PacketSlicingModulePolicyManagerNonOpenFlow extends AbstractModulePolicyManager {

    @Inject
    private PacketSlicingModulePolicyRepository packetSlicingModulePolicyRepository;

    @Inject
    private ModuleRepository moduleRepository;

    @Inject
    private PortRepository portRepository;

    @Inject
    private PortGroupRepository portGroupRepository;

    @Inject
    private JobQueue jobQueue;

    @Inject
    private DeviceRepository deviceRepository;

    /**
     * This method is used to create PacketSlicingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long commitModulePolicy(Long deviceId, ModulePolicyRequest modulePolicy) {

        PacketSlicingModulePolicy packetSlicingModulePolicy = modulePolicy.getPacketSlicingModulePolicy();
        isValidPolicy(packetSlicingModulePolicy, deviceId);

        List<Long> moduleIds = packetSlicingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        List<Long> dbModuleIds = packetSlicingModulePolicyRepository.findModulesByModuleIds(moduleIds);

        // #1 Check if the selected module doesn't have another packet slicing policy
        if (!dbModuleIds.isEmpty()) {
            log.error("Already a Packet Slicing Module Policy applied for the selected Module(s).");
            throw new ValidationException("packetSlicingPolicy.exists");
        }

        List<Module> modules = (List<Module>) moduleRepository.findAll(moduleIds);
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("packetSlicingPolicy.edit.failed");
        }

        List<Long> portIds = packetSlicingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Set<Port> ports = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());

        isValidPolicyToCommit(moduleIds, portIds, ports);

        packetSlicingModulePolicy.setModules(Sets.newHashSet(modules));
        packetSlicingModulePolicy.setPorts(Sets.newHashSet(ports));
        packetSlicingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetSlicingModulePolicy = packetSlicingModulePolicyRepository.save(packetSlicingModulePolicy);

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_SLICING_MODULE_POLICY_CREATE)
                .deviceId(deviceId).impactedObjectIds(portIds)
                .parentObjectId(packetSlicingModulePolicy.getId()).build());

        return jobId;
    }

    /**
     * Validating the Packet Slicing Policy
     *
     * @param policy
     * @param deviceId
     * @return
     */
    protected boolean isValidPolicy(PacketSlicingModulePolicy policy, Long deviceId) {
        if (policy != null) {
            Device device = deviceRepository.findOne(deviceId);
            if (device != null && (device.getType() != Device.Type.MLXE || device.getMode() != Device.Mode.PLAIN)) {
                throw new ValidationException("packetSlicingPolicy.not.supported.device");
            }
            if (policy.getPorts() == null || policy.getPorts().isEmpty()) {
                throw new ValidationException("empty.port.notallowed");
            }
            if (policy.getModules() == null || policy.getModules().isEmpty()) {
                throw new ValidationException("empty.module.not.allowed");
            }
            if (policy.getNumberOfBytes() == null || policy.getNumberOfBytes() < PacketSlicingModulePolicy.TRUNCATION_SIZE_MIN || policy.getNumberOfBytes() > PacketSlicingModulePolicy.TRUNCATION_SIZE_MAX) {
                throw new ValidationException("packet.slicing.policy.truncate.size.invalid");
            }
        }
        return true;
    }

    /**
     * This method checks if PacketSlicingModulePolicy data is valid to commit on the given device
     *
     * @param moduleIds
     * @param portIds
     * @param ports
     * @throws ValidationException
     */
    private boolean isValidPolicyToCommit(List<Long> moduleIds, List<Long> portIds, Set<Port> ports) {

        // #1 Check if all participating ports are of either EGRESS type or SERVICE_PORT type
        Set<Port> portsInDb = ports.stream().filter(port -> (port.getType() == Port.Type.EGRESS) || (port.getType() == Port.Type.SERVICE_PORT)).collect(Collectors.toSet());
        List<Long> portIdsInDb = portsInDb.stream().map(Port::getId).collect(Collectors.toList());
        if (!portIdsInDb.containsAll(portIds)) {
            log.error("All participating ports should be of type Service Port or EGRESS.");
            throw new ValidationException("port.type.egressOrService");
        }

        // #2 Check if all participating ports belongs to selected modules
        portsInDb.forEach(port -> {
            if (!moduleIds.contains(port.getModule().getId())) {
                log.error("Some of the participating ports doesn't belong to selected modules.");
                throw new ValidationException("port.ids.invalid");
            }
        });
        return true;
    }

    /**
     * This method checks if PacketSlicingModulePolicy data is updated
     *
     * @param oldModulePolicy
     * @param newModulePolicy
     * @return boolean
     */
    public boolean isPolicyUnChanged(PacketSlicingModulePolicy oldModulePolicy, PacketSlicingModulePolicy newModulePolicy) {
        if (oldModulePolicy.getNumberOfBytes() != null ? !oldModulePolicy.getNumberOfBytes().equals(newModulePolicy.getNumberOfBytes()) : newModulePolicy.getNumberOfBytes() != null)
            return false;

        Set<Long> oldModuleIds = oldModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        Set<Long> newModuleIds = newModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toSet());
        if (oldModuleIds.size() != newModuleIds.size() || !newModuleIds.containsAll(oldModuleIds)) {
            return false;
        }

        if (oldModulePolicy.getPorts() != null && newModulePolicy.getPorts() != null) {
            Set<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            Set<Long> newPortIds = newModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toSet());
            if (oldPortIds.size() != newPortIds.size() || !newPortIds.containsAll(oldPortIds)) {
                return false;
            }
        } else {
            throw new ValidationException("policy.ports.invalid");
        }
        return true;
    }

    /**
     * This method is used to delete PacketSlicingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long deleteModulePolicy(Long deviceId, Long modulePolicyId) {
        PacketSlicingModulePolicy packetSlicingModulePolicy = packetSlicingModulePolicyRepository.findOne(modulePolicyId);
        if (packetSlicingModulePolicy == null) {
            throw new ValidationException("packetSlicingPolicy.id.invalid");
        }
        isValidPolicy(packetSlicingModulePolicy, deviceId);
        if (packetSlicingModulePolicy.getWorkflowStatus() == WorkflowParticipant.WorkflowStatus.SUBMITTED) {
            throw new ValidationException("packetSlicingPolicy.delete.policyApplied");
        }
        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_SLICING_MODULE_POLICY_DELETE)
                .deviceId(deviceId).impactedObjectIds(packetSlicingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to update PacketSlicingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @param modulePolicy
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long updateModulePolicy(Long deviceId, Long modulePolicyId, ModulePolicyRequest modulePolicy) {
        if (modulePolicyId == null) {
            throw new ValidationException("packetSlicingPolicy.id.invalid");
        }
        PacketSlicingModulePolicy packetSlicingModulePolicy = modulePolicy.getPacketSlicingModulePolicy();
        isValidPolicy(packetSlicingModulePolicy, deviceId);

        PacketSlicingModulePolicy oldModulePolicy = packetSlicingModulePolicyRepository.findOne(modulePolicyId);
        if (isPolicyUnChanged(oldModulePolicy, packetSlicingModulePolicy)) {
            log.error("PacketSlicingPolicy data is unchanged, id {}.", packetSlicingModulePolicy.getId());
            throw new ValidationException("packetSlicingPolicy.data.unchanged");
        }
        List<Long> moduleIds = packetSlicingModulePolicy.getModules().stream().map(Module::getId).collect(Collectors.toList());
        Set<Module> modules = StreamSupport.stream(moduleRepository.findAll(moduleIds).spliterator(), false).collect(Collectors.toSet());
        if (modules.size() != moduleIds.size()) {
            throw new ValidationException("packetSlicingPolicy.edit.failed");
        }

        // Adding newly selected ports as impacted objects
        List<Long> oldPortIds = oldModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        List<Long> impactedObjects = Lists.newArrayList();
        packetSlicingModulePolicy.getPorts().forEach(newPort -> {
            if (!oldPortIds.contains(newPort.getId())) {
                impactedObjects.add(newPort.getId());
            }
        });

        List<Long> portIds = packetSlicingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList());
        Set<Port> ports = StreamSupport.stream(portRepository.findAll(portIds).spliterator(), false).collect(Collectors.toSet());
        isValidPolicyToCommit(moduleIds, portIds, ports);
        // merging updated data
        oldModulePolicy.setNumberOfBytes(packetSlicingModulePolicy.getNumberOfBytes());
        oldModulePolicy.setModules(modules);
        oldModulePolicy.setPorts(ports);

        oldModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetSlicingModulePolicyRepository.save(oldModulePolicy);
        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_SLICING_MODULE_POLICY_UPDATE)
                .deviceId(deviceId).impactedObjectIds(impactedObjects)
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }

    /**
     * This method is used to recover PacketSlicingModulePolicy, on the given device
     *
     * @param deviceId
     * @param modulePolicyId
     * @return Long This returns jobId
     * @throws ValidationException
     */
    @Override
    public Long recoverModulePolicy(Long deviceId, Long modulePolicyId) {
        PacketSlicingModulePolicy packetSlicingModulePolicy = packetSlicingModulePolicyRepository.findOne(modulePolicyId);
        if (packetSlicingModulePolicy == null) {
            throw new ValidationException("packetSlicingPolicy.id.invalid");
        }
        if (packetSlicingModulePolicy.getWorkflowStatus() != WorkflowParticipant.WorkflowStatus.ERROR) {
            throw new ValidationException("packetSlicingPolicy.recovery.notInError");
        }
        isValidPolicy(packetSlicingModulePolicy, deviceId);
        packetSlicingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        packetSlicingModulePolicyRepository.save(packetSlicingModulePolicy);

        long jobId = jobQueue.submit(JobTemplate.builder().type(Job.Type.PACKET_SLICING_MODULE_POLICY_ROLLBACK)
                .deviceId(deviceId).impactedObjectIds(packetSlicingModulePolicy.getPorts().stream().map(Port::getId).collect(Collectors.toList()))
                .parentObjectId(modulePolicyId).build());
        return jobId;
    }
}
