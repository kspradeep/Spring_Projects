package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.outbound.stablenet.StablenetInitializerManager;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;


@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/stablenet")
public class StablenetInitializerController {

    @Inject
    StablenetInitializerManager stablenetInitializerManager;

    /*@RequestMapping(method = RequestMethod.PUT, value = "/initialize")
    public ResponseEntity<Object> initializeStablenet(@RequestParam(value = "ipaddress", required = true) String stablenetIp) {
        if (Strings.isNullOrEmpty(stablenetIp)) {
            throw new ValidationException("Invalid StableNet IP address.");
        }
        stablenetInitializerManager.initialize(stablenetIp);
        return new ResponseEntity<>(HttpStatus.OK);
    }*/
}
