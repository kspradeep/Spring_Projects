package com.brocade.bvm.api.model.statistics;

import lombok.*;

import java.util.*;

@Data
public class GridOverview {
    private int noDevices;
    private int noAggregator;
    private int noDistributor;
    private long tapBandwidth;
    private long toolBandwidth;
    private List<String> devices = new ArrayList<>();
    private List<Map<String,List<String>>> tapPorts = new ArrayList<>();
    private List<Map<String,List<String>>> toolPorts = new ArrayList<>();
    private int configuredPolices;
}
