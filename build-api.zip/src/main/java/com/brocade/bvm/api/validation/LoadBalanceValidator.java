//package com.brocade.bvm.api.validation;
//
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.validation.Errors;
//import org.springframework.validation.Validator;
//
//import com.brocade.bvm.api.db.beans.LoadBalance;
//
//@Slf4j
//public class LoadBalanceValidator implements Validator{
//
//    private Operations operationtype;
//    private LoadBalance loadBalance;
//
//    @Override
//    public boolean supports(Class<?> clazz) {
//        // TODO Auto-generated method stub
//        return false;
//    }
//
//    @Override
//    public void validate(Object target, Errors errors) {
//        if (!(target != null && target instanceof LoadBalance)){
//            log.error("Invalid LoadBalance instance Passed");
//            errors.reject("10007", "Invalid LoadBalance Instance. ");
//            return;
//        }
//        this.loadBalance = (LoadBalance)target;
//        switch (operationtype) {
//        case Create:
//            ValidatorUtility.isNull(loadBalance.getId(), errors, "Load Balance Id");
//            ValidatorUtility.notNull(loadBalance.getSlotNo(), errors, "Slot No");
//            ValidatorUtility.notNull(loadBalance.getSlotName(), errors, "Slot Name");
//            ValidatorUtility.notNull(loadBalance.getIsInnerIp(), errors, "isInnerIp");
//            ValidatorUtility.notNull(loadBalance.getSourceIpMarked(), errors, "sourceIpMarked");
//            ValidatorUtility.notNull(loadBalance.getDestIpMarked(), errors, "destIpMarked");
//            ValidatorUtility.notNull(loadBalance.getSourcePortMarked(), errors, "sourcePortMarked");
//            ValidatorUtility.notNull(loadBalance.getDestPortMarked(), errors, "destPortMarked");
//            ValidatorUtility.notNull(loadBalance.getProtocolMarked(), errors, "protocolMarked");
//            ValidatorUtility.notNull(loadBalance.getTeidMarked(), errors, "teidMarked");
//            ValidatorUtility.notNull(loadBalance.getIsBiDirectional(), errors, "isBiDirectional");
//            ValidatorUtility.notNull(loadBalance.getJobId(), errors, "jobId");
//            ValidatorUtility.notNull(loadBalance.getDeviceId(), errors, "deviceId");
//            ValidatorUtility.notNull(loadBalance.getDeviceType(), errors, "deviceType");
//            break;
//        case Update:
//            ValidatorUtility.notNull(loadBalance.getId(), errors, "Load Balance Id");
//            ValidatorUtility.notNull(loadBalance.getSlotNo(), errors, "Slot No");
//            ValidatorUtility.notNull(loadBalance.getSlotName(), errors, "Slot Name");
//            ValidatorUtility.notNull(loadBalance.getIsInnerIp(), errors, "isInnerIp");
//            ValidatorUtility.notNull(loadBalance.getSourceIpMarked(), errors, "sourceIpMarked");
//            ValidatorUtility.notNull(loadBalance.getDestIpMarked(), errors, "destIpMarked");
//            ValidatorUtility.notNull(loadBalance.getSourcePortMarked(), errors, "sourcePortMarked");
//            ValidatorUtility.notNull(loadBalance.getDestPortMarked(), errors, "destPortMarked");
//            ValidatorUtility.notNull(loadBalance.getProtocolMarked(), errors, "protocolMarked");
//            ValidatorUtility.notNull(loadBalance.getTeidMarked(), errors, "teidMarked");
//            ValidatorUtility.notNull(loadBalance.getIsBiDirectional(), errors, "isBiDirectional");
//            ValidatorUtility.notNull(loadBalance.getJobId(), errors, "jobId");
//            ValidatorUtility.notNull(loadBalance.getDeviceId(), errors, "deviceId");
//            ValidatorUtility.notNull(loadBalance.getDeviceType(), errors, "deviceType");
//            break;
//        case Delete:
//            break;
//        default:
//
//            break;
//
//        }
//
//    }
//
//}
