package com.brocade.bvm.api.manager.statistics;

import com.brocade.bvm.api.model.grid.GridDeviceInfoRequest;

public interface StatisticsSettingsManager {

    boolean clearCounters(GridDeviceInfoRequest gridDeviceInfoRequest);
}
