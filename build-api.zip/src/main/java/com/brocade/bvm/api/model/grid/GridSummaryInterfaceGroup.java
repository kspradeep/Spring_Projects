package com.brocade.bvm.api.model.grid;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class GridSummaryInterfaceGroup {

    private String name;

    private Set<String> interfaces;
}