package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.manager.GlobalManager;
import com.brocade.bvm.api.manager.SettingManager;
import com.brocade.bvm.api.manager.packetcapture.PacketCaptureManager;
import com.brocade.bvm.api.model.DeviceAdditionResponse;
import com.brocade.bvm.api.model.PacketTruncationRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.DeviceDiscoveryJobRepository;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ManagedObjectRepository;
import com.brocade.bvm.dao.SetupHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.DeviceDiscoveryJob;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.PacketCapture;
import com.brocade.bvm.outbound.exception.CliConnectorException;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.*;
import java.util.stream.Collectors;

/**
 * The GlobalController class implements methods to perform CRUD operations related to all global configurations
 */
@Slf4j
@RestController
@RequestMapping(produces = "application/json", value = "/global")
public class GlobalController {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private GlobalManager globalManager;

    @Inject
    private SettingManager settingManager;

    @Inject
    private EntityManager entityManager;

    @Inject
    private ManagedObjectRepository managedObjectRepository;

    @Inject
    private DeviceDiscoveryJobRepository deviceDiscoveryJobRepository;

    @Value("${add.device.max.count:5}")
    private Integer maxDeviceCount;

    private static final String ROLLBACK = "rollback";

    @Inject
    private ManagedObjectAuthorityProvider authorityProvider;

    @Inject
    private PacketCaptureManager packetCaptureManager;

    @Inject
    private ApplicationContext applicationContext;

    @Inject
    private SetupHistoryRepository setupHistoryRepository;
    /**
     * This method refreshes the device configuration
     *
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.POST, value = "/device/refresh")
    public ResponseEntity<Object> refreshDevices() {
        log.debug("Refreshing the device configuration.");
        String response = globalManager.refreshDeviceConfiguration();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Deletes the devices from Stablenet Measurements and marks as deleted against corresponding device entry in EVM.
     * Send the EVM device id as comma separated value.
     *
     * @param deviceIds
     * @return
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/device/remove/{deviceids}")
    public ResponseEntity<Object> removeDevicesFromMeasurements(@PathVariable(value = "deviceids") String deviceIds) {
        if (!Strings.isNullOrEmpty(deviceIds)) {
            log.debug("Removing device Ids {} from StableNet.", deviceIds);
            List<String> deviceIdStringList = Arrays.asList(deviceIds.split(","));
            List<Long> deviceIdList = new ArrayList<>();
            deviceIdStringList.stream().forEach(deviceIdLong -> {
                if (deviceIdLong.matches("\\d+")) {
                    deviceIdList.add(Long.parseLong(deviceIdLong.trim()));
                } else {
                    log.error("Requested Device Id(s) is not valid {}.", deviceIdLong);
                    throw new ValidationException("Invalid device Ids.");
                }
            });
            List<Device> devices = deviceRepository.getdevicesNotDeletedByDeviceId(deviceIdList);
            if (devices.isEmpty() || devices.size() != deviceIdList.size()) {
                throw new ValidationException("Selected device(s) does not exist.");
            } else {
                Set<Long> deviceIdSet = settingManager.deleteDevice(devices);
                return new ResponseEntity<>(deviceIdSet, HttpStatus.OK);
            }
        }
        throw new ValidationException("Select the device to delete.");
    }

    /**
     * Deletes the discovery job from StableNet and EVM.
     * Send the EVM discovery job ids as comma separated value.
     *
     * @param ids
     * @return
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/discoveryjob/remove/{objids}")
    public ResponseEntity<Object> removeDiscoveryJob(@PathVariable(value = "objids") String ids) {
        if (Strings.isNullOrEmpty(ids)) {
            throw new ValidationException("Invalid job id.");
        }
        List<String> idList = Arrays.asList(ids.split(","));
        List<Long> discoveryJobIds = idList.stream().map(id -> Long.parseLong(id)).collect(Collectors.toList());
        List<DeviceDiscoveryJob> deviceDiscoveryJobs = deviceDiscoveryJobRepository.findByInIds(discoveryJobIds);
        List<DeviceDiscoveryJob> discoveryJobRunning = deviceDiscoveryJobs.stream().filter(job -> {
            return job.isRunning();
        }).collect(Collectors.toList());
        if (discoveryJobRunning != null && !discoveryJobRunning.isEmpty()) {
            throw new ValidationException("Selected discovery job(s) are already running.");
        }
        settingManager.deleteDiscoveryJob(discoveryJobIds);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Gets the list of discovery job in EVM.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/discoveryjob/all")
    public ResponseEntity<Object> getDiscoveryJob() {
        Iterable<DeviceDiscoveryJob> deviceDiscoveryJobRepositoryAll = deviceDiscoveryJobRepository.findAll();
        if (deviceDiscoveryJobRepositoryAll == null) {
            deviceDiscoveryJobRepositoryAll = new ArrayList<>();
        }
        return new ResponseEntity<>(deviceDiscoveryJobRepositoryAll, HttpStatus.OK);
    }

    /**
     * Starts the StableNet discovery job using the EVM discovery job id passed
     */
    @RequestMapping(method = RequestMethod.GET, value = "/discoveryjob/start/{id}")
    public ResponseEntity<Object> startDiscoveryJob(@PathVariable(value = "id") Long id) {
        if (id == null || id <= 0) {
            throw new ValidationException("Invalid job id.");
        }
        DeviceDiscoveryJob deviceDiscoveryJob = deviceDiscoveryJobRepository.findOne(id);
        if (deviceDiscoveryJob == null) {
            throw new ValidationException("Invalid job id.");
        }
        if (deviceDiscoveryJob != null && deviceDiscoveryJob.isRunning()) {
            throw new ValidationException("The selected job is already running!.");
        }
        settingManager.startJob(deviceDiscoveryJob);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Adds the discovery job and starts the created discovery job in StableNet
     */
    @RequestMapping(method = RequestMethod.POST, value = "/device/add", consumes = "application/json")
    public ResponseEntity<Object> addDevices(@RequestBody DeviceDiscoveryJob deviceDiscoveryJob) {
        log.debug("Create device discovery job in stablenet.");
        if (deviceDiscoveryJob == null) {
            throw new ValidationException("Empty request.");
        }
        if (deviceDiscoveryJob.getIps() == null || deviceDiscoveryJob.getIps().isEmpty()) {
            throw new ValidationException("Device IP address(es) not found.");
        }
        //TODO Uncomment when UI supports update case
        /*else {
            Set<DeviceDiscoveryJob> duplicateDeviceDiscoveryJobs = deviceDiscoveryJobRepository.findByInIpAddress(deviceDiscoveryJob.getIps());
            if (duplicateDeviceDiscoveryJobs != null && !duplicateDeviceDiscoveryJobs.isEmpty()) {
                String ips = duplicateDeviceDiscoveryJobs.stream().map(duplicateJob -> {
                    return duplicateJob.getIpAddress();
                }).collect(Collectors.joining(","));
                throw new ValidationException("Try updating discovery job for already existing jobs with IP address : " + ips);
            }
        }*/

        if (deviceDiscoveryJob.getIps().size() > maxDeviceCount) {
            throw new ValidationException("Only " + maxDeviceCount + " devices can be added at one time.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getCliUserName())) {
            throw new ValidationException("Invalid CLI username.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getCliPassword())) {
            throw new ValidationException("Invalid CLI password.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getSnmpCommunity())) {
            throw new ValidationException("Invalid SNMP community string.");
        }
        if (DeviceDiscoveryJob.TriggerType.INTERVAL.equals(deviceDiscoveryJob.getTriggerType()) && (deviceDiscoveryJob.getIntervalValue() == null || deviceDiscoveryJob.getIntervalValue() <= 0)) {
            throw new ValidationException("Invalid Interval value.");
        }
        List<DeviceAdditionResponse> deviceAdditionResponseList = settingManager.addDevice(deviceDiscoveryJob);

        return new ResponseEntity<>(deviceAdditionResponseList, HttpStatus.OK);
    }

    /**
     * Updates the discovery job and starts the updated discovery job in StableNet
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/device/add", consumes = "application/json")
    public ResponseEntity<Object> updateDevices(@RequestBody DeviceDiscoveryJob deviceDiscoveryJob) {
        log.debug("Create device discovery job in stableNet.");
        DeviceDiscoveryJob deviceDiscoveryJobById = deviceDiscoveryJobRepository.findOne(deviceDiscoveryJob.getId());
        if (deviceDiscoveryJob == null) {
            throw new ValidationException("Empty request.");
        }
        if (deviceDiscoveryJob.getId() == null || deviceDiscoveryJobById == null) {
            throw new ValidationException("Invalid Discovery job.");
        }
        if (deviceDiscoveryJobById != null && deviceDiscoveryJob.isRunning()) {
            throw new ValidationException("The selected job is already running!.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getIpAddress())) {
            throw new ValidationException("Invalid IP address.");
        }

        List<DeviceDiscoveryJob> deviceDiscoveryJobByIp = deviceDiscoveryJobRepository.findByIpAddress(deviceDiscoveryJob.getIpAddress());
        if (deviceDiscoveryJobByIp != null || !deviceDiscoveryJobByIp.isEmpty()) {
            throw new ValidationException("Discovery Job with IP address " + deviceDiscoveryJob.getIpAddress() + " already exists. Please try updating the same.");
        }

        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getCliUserName())) {
            throw new ValidationException("Invalid CLI username.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getCliPassword())) {
            throw new ValidationException("Invalid CLI password.");
        }
        if (Strings.isNullOrEmpty(deviceDiscoveryJob.getSnmpCommunity())) {
            throw new ValidationException("Invalid SNMP community string.");
        }
        if (DeviceDiscoveryJob.TriggerType.INTERVAL.equals(deviceDiscoveryJob.getTriggerType()) && (deviceDiscoveryJob.getIntervalValue() == null || deviceDiscoveryJob.getIntervalValue() <= 0)) {
            throw new ValidationException("Invalid Interval value.");
        }
        Set<String> ips = new HashSet<>();
        ips.add(deviceDiscoveryJob.getIpAddress());
        deviceDiscoveryJob.setIps(ips);
        List<DeviceAdditionResponse> deviceAdditionResponseList = settingManager.addDevice(deviceDiscoveryJob);

        return new ResponseEntity<>(deviceAdditionResponseList, HttpStatus.OK);
    }


    /**
     * This method is used to get all devices from EVM which are not deleted i.e. whatever is seen in StableNet measurements.
     *
     * @return : device list json array with just id and name parameter
     */
    @RequestMapping(method = RequestMethod.GET, value = "/devices")
    public ResponseEntity<Object> getAllDevicesInMeasurements() {
        JSONArray jsonArray = new JSONArray();
        List<Long> stablenetDeviceIds = authorityProvider.getAuthorizedDeviceIds();
        if (stablenetDeviceIds != null && !stablenetDeviceIds.isEmpty()) {
            List<Device> devices = deviceRepository.getdevicesNotDeletedByDeviceId(stablenetDeviceIds);
            if (devices != null && !devices.isEmpty()) {
                devices.forEach(device -> {
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", device.getId());
                        jsonObject.put("name", device.getName());
                        jsonArray.put(jsonObject);
                    } catch (JSONException e) {
                        log.error("Error while creating device json");
                    }
                });
            }
        }
        return new ResponseEntity<>(jsonArray.toString(), HttpStatus.OK);
    }

    /**
     * This method is used to save packet truncation profiles in bvm db and create packet truncation profile on devices.
     *
     * @param packetTruncationRequest
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/packettruncation", consumes = "application/json")
    public ResponseEntity<Object> commitTruncationProfile(@RequestBody PacketTruncationRequest packetTruncationRequest) {
        log.debug("Enter: commit Packet Truncation Profile ");
        return new ResponseEntity<>(globalManager.commit(packetTruncationRequest), HttpStatus.OK);
    }

    /**
     * This method is used to update packet truncation profiles in bvm db and update packet truncation profile on devices.
     *
     * @param packetTruncationRequest
     * @return
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/packettruncation/{id}")
    public ResponseEntity<Object> updateTruncationProfile(@RequestParam(value = "action", required = false) String action, @PathVariable("id") Long id, @RequestBody PacketTruncationRequest packetTruncationRequest) {
        log.debug("Enter: update Packet Truncation Profile");
        List jobList = new ArrayList<>();
        if (ROLLBACK.equalsIgnoreCase(action)) {
            Long jobId = globalManager.rollBack(id);
            jobList.add(jobId);
        } else {
            jobList = globalManager.update(id, packetTruncationRequest);
        }
        return new ResponseEntity<>(jobList, HttpStatus.OK);
    }

    /**
     * This method is used to delete packet truncation profiles in bvm db and delete packet truncation profile on devices.
     *
     * @param id
     * @return
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/packettruncation/{id}")
    public ResponseEntity<Object> deletePacketTruncationProfile(@PathVariable("id") Long id) {
        log.debug("Start: delete Packet Truncation Profile");
        return new ResponseEntity<>(globalManager.delete(id), HttpStatus.OK);
    }

    /**
     * This method is used to abort execution of the given managed object
     *
     * @param managedObjectId
     * @return ResponseEntity<Object>
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/{managedObjectId}/abort")
    public ResponseEntity<Object> abortExecution(@PathVariable("managedObjectId") Long managedObjectId) {
        if (managedObjectId != null) {
            try {
                Query query = entityManager.createNamedQuery("ManagedObject.findByIds");
                List<Long> ids = new ArrayList<>();
                ids.add(managedObjectId);
                query.setParameter("ids", ids);
                ManagedObject managedObject = (ManagedObject) query.getSingleResult();
                if (managedObject != null) {
                    if (WorkflowParticipant.WorkflowStatus.SUBMITTED == managedObject.getWorkflowStatus()) {
                        log.debug("Aborting the execution of managed object {}", managedObjectId);
                        managedObject.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
                        managedObjectRepository.save(managedObject);
                    } else {
                        log.error("Managed object {} is not in submitted state.", managedObjectId);
                        throw new ValidationException("Managed object not in submitted state.");
                    }
                    return new ResponseEntity<>(managedObjectId, HttpStatus.OK);
                }
            } catch (Exception e) {
                throw new ValidationException("Failed to update the state of the managed object. " + e.getMessage());
            }
        }
        throw new ValidationException("Invalid managed object id!.");
    }

    /**
     * This method is used to display the packet truncation profiles is create on devices.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/packettruncation")
    public ResponseEntity<Object> viewTruncationProfiles() {
        return new ResponseEntity<>(globalManager.getProfiles(), HttpStatus.OK);
    }

    /**
     * This method is used to display the packet truncation profiles is create on device.
     *
     * @param id
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/packettruncation/{id}")
    public ResponseEntity<Object> viewTruncationProfilesForDevice(@PathVariable("id") Long id) {
        log.debug("Enter: view Truncation Profiles For Device");
        if (id == null) {
            throw new ValidationException("Invalid Packet Truncation Profile Id!");
        }
        return new ResponseEntity<>(globalManager.getProfile(id), HttpStatus.OK);
    }

    /**
     * This method is used for  packetCapture for the port.
     *
     * @param packetCapture
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/packetcapture", consumes = "application/json")
    public ResponseEntity<Object> createPacketCapture(@RequestBody PacketCapture packetCapture) {
        log.debug("Enter: Create Packet Capture ");
        return new ResponseEntity<>(packetCaptureManager.createPacketCapture(packetCapture), HttpStatus.OK);
    }

    /**
     * This method is used for get packetCapture.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/packetcapture/{deviceId}")
    public ResponseEntity<Object> getPacketCapture(@PathVariable("deviceId") Long deviceId) {
        log.debug("Enter: Get Packet Capture ");
        return new ResponseEntity<>(packetCaptureManager.getPacketCapture(deviceId), HttpStatus.OK);
    }

    /**
     * APi is used to copy the pcap file from device to any servers
     *
     * @param copyPcapFileReq
     * @return
     * @throws CliConnectorException
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/copypcapfile")
    public ResponseEntity<Object> copyPcapFile(@RequestBody Map<String, String> copyPcapFileReq) throws CliConnectorException {
        Map<String, Object> map = new HashMap<>();
        packetCaptureManager.copyPcapFile(copyPcapFileReq);
        map.put("Success", "Pcap file is copied");
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * This method is used for get packetCapture.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/setup/history")
    public ResponseEntity<Object> getSetupHistory() {
        log.debug("Enter: Get Setup History ");
        Pageable pageable = new PageRequest(0, 10);
        return new ResponseEntity<>(setupHistoryRepository.findAllByOrderByIdDesc(pageable), HttpStatus.OK);
    }
}
