package com.brocade.bvm;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.cache.CacheBuilderSpec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.Ssl;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.WebApplicationInitializer;

import java.time.ZoneOffset;
import java.util.TimeZone;
import java.util.concurrent.Executor;

@SpringBootApplication
@EnableScheduling
@EnableTransactionManagement
@EnableJpaRepositories
@EnableCaching
@EnableAsync
public class Application {

    @Value("${https.enabled:true}")
    private boolean isHttpsEnabled;

    @Value("${rest.api.port:9285}")
    private Integer restApiPort;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public EmbeddedServletContainerCustomizer customizeContainer() {
        return container -> {
            container.setContextPath("/evm/api");
            //TODO make port configurable after making rest-url configurable in UI
            container.setPort(restApiPort);

            if (isHttpsEnabled) {
                Ssl ssl = new Ssl();
                ssl.setKeyStore("classpath:bvm-keystore.jks");
                ssl.setKeyStorePassword("Brocade@123");
                ssl.setKeyPassword("Brocade@123");
                container.setSsl(ssl);
            }
        };
    }

    @Bean
    public WebApplicationInitializer webApplicationInitializer() {
        return servletContext -> {
            TimeZone.setDefault(TimeZone.getTimeZone(ZoneOffset.UTC));
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
        };
    }

    @Bean
    public CacheBuilderSpec cacheBuilderSpec() {
        return CacheBuilderSpec.parse("expireAfterWrite=15m");
    }

    @Bean(name = "asyncExecutor")
    public Executor asyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(20);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("EVMAsynchThread-");
        executor.initialize();
        return executor;
    }
}
