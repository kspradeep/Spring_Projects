package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.model.db.statistics.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class StatsPortUIControllerTest {

  @Mock private StatisticsPortRepository statisticsPortRepository;

  @InjectMocks private StatisticsPortUIController statisticsPortUIController;

  private MockMvc mockMvc;

  @Before
  public void setup() {

    // Setup Spring test in standalone mode
    this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsPortUIController).build();
  }

  @Test
  public void itShouldReturnPortPacketsForPort() throws Exception {
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(null);
    PortPackets portPackets = new PortPackets();
    List<PortPackets> portPackets1 = new ArrayList<>();
    portPackets1.add(portPackets);
    when(statisticsPortRepository.findPortPacketInformation(1L, 20)).thenReturn(portPackets1);

    this.mockMvc
        .perform(get("/statistics/1/20/port-packets").accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
        .andExpect(content().json("[{'sequence':0, 'receivedTime':1, 'inPackets':0}]"))
        .andExpect(jsonPath("$", hasSize(1)))
        .andExpect(jsonPath("$[0].sequence", is(0)));


    //Test for grid
    List<Long> portIds = new ArrayList<>();
    portIds.add(10L);
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(portIds);
    PortPackets portPackets2 = new PortPackets();
    portPackets2.setThroughput(100);
    portPackets1.add(portPackets2);
    when(statisticsPortRepository.findGridPackets(portIds, 20)).thenReturn(portPackets1);

    this.mockMvc
            .perform(get("/statistics/1/20/port-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$", hasSize(2)))
            .andExpect(jsonPath("$[1].throughput", is(100)));
  }

  @Test
  public void itShouldReturnPacketsTypeForPort() throws Exception {
    List<PortPacketType> portPacketTypes = new ArrayList<>();
    PortPacketType portPacketType = new PortPacketType();
    portPacketTypes.add(portPacketType);
    when(statisticsPortRepository.portTypePackets(1L, 20)).thenReturn(portPacketTypes);

    this.mockMvc.perform(get("/statistics/1/20/port-type-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(1)));

    //Test for grid
    List<Long> portIds = new ArrayList<>();
    portIds.add(10L);
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(portIds);
    PortPacketType portPacketType1 = new PortPacketType();
    portPacketType1.setInBroadcastPackets(100);
    portPacketTypes.add(portPacketType1);
    when(statisticsPortRepository.findGridPacketsType(portIds, 20)).thenReturn(portPacketTypes);

    this.mockMvc.perform(get("/statistics/1/20/port-type-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(2)));

  }


  @Test
  public void isShouldReturnPortDropPackets() throws Exception {
    List<PortPacketsDrop> portPacketsDrops = new ArrayList<>();
    PortPacketsDrop portPacketsDrop = new PortPacketsDrop();
    portPacketsDrops.add(portPacketsDrop);
    when(statisticsPortRepository.portDropPackets(1L, 20)).thenReturn(portPacketsDrops);

    this.mockMvc.perform(get("/statistics/1/20/port-drop-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(1)));


    //Test for grid
    List<Long> portIds = new ArrayList<>();
    portIds.add(10L);
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(portIds);
    PortPacketsDrop portPacketsDrop1 = new PortPacketsDrop();
    portPacketsDrop1.setInDropPackets(100);
    portPacketsDrops.add(portPacketsDrop1);
    when(statisticsPortRepository.findGridDropPackets(portIds, 20)).thenReturn(portPacketsDrops);
    this.mockMvc.perform(get("/statistics/1/20/port-drop-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(2)))
            .andExpect(jsonPath("$[1].inDropPackets", is(100)));

  }

  @Test
  public void itShouldReturnPortErrorPackets() throws Exception {
    List<PortPacketsError> portPacketsErrors = new ArrayList<>();
    PortPacketsError portPacketsError = new PortPacketsError();
    portPacketsErrors.add(portPacketsError);
    when(statisticsPortRepository.portErrorPackets(1L, 20)).thenReturn(portPacketsErrors);

    this.mockMvc.perform(get("/statistics/1/20/port-error-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(1)));

    //Test for grid
    List<Long> portIds = new ArrayList<>();
    portIds.add(10L);
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(portIds);
    PortPacketsError portPacketsError1 = new PortPacketsError();
    portPacketsError1.setInPacketsError(100);
    portPacketsErrors.add(portPacketsError1);
    when(statisticsPortRepository.findGridErrorPackets(portIds, 20)).thenReturn(portPacketsErrors);

    this.mockMvc.perform(get("/statistics/1/20/port-error-packets").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(2)))
            .andExpect(jsonPath("$[1].inPacketsError", is(100)));
  }

  @Test
  public void itShouldReturnPortUtilizationAndThroughput() throws Exception {
    List<PortBandwidth> portBandwidths = new ArrayList<>();
    PortBandwidth portBandwidth = new PortBandwidth();
    portBandwidths.add(portBandwidth);
    when(statisticsPortRepository.getPortUtilization(1L)).thenReturn(portBandwidths);

    this.mockMvc.perform(get("/statistics/1/utilization").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(1)));

    //Test for grid
    List<Long> portIds = new ArrayList<>();
    portIds.add(10L);
    when(statisticsPortRepository.findPortsByTapId(1L)).thenReturn(portIds);
    PortBandwidth portBandwidth1 = new PortBandwidth();
    portBandwidth1.setInUtilization(100.00);
    portBandwidths.add(portBandwidth1);
    when(statisticsPortRepository.findGridPortsUtilization(portIds)).thenReturn(portBandwidths);

    this.mockMvc.perform(get("/statistics/1/utilization").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(2)))
            .andExpect(jsonPath("$[1].inUtilization", is(100.00)));
  }
}
