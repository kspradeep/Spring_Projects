package com.brocade.bvm.api.manager.openflow;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.FlowRepository;
import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.PortGroup;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.StrictAssertions.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PortManagerOpenFlowTest {

    @InjectMocks
    private PortManagerOpenFlow portManagerOpenFlow;

    @Mock
    private PortRepository portRepository;

    @Mock
    private FlowRepository flowRepository;

    @Mock
    private PortGroupRepository portGroupRepository;

    @Mock
    private JobQueue jobQueue;

    private static final Long deviceId = 1001L;

    @Before
    public void setUp() throws Exception {
        List<Port> ports = new ArrayList<Port>();
        Port port = new Port();
        port.setName("ethernetport1");
        port.setAdminStatus(Port.AdminStatus.ENABLED);
        port.setType(Port.Type.INGRESS);
        port.setMode(Port.Mode.LAYER3);
        port.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        ports.add(port);
        PortGroup portGroup = new PortGroup();

        Module module = new Module();
        Device device = new Device();
        device.setMode(Device.Mode.OPENFLOW);
        device.setLastCollectedTime(Instant.now());

        ReflectionTestUtils.setField(port, "module", module);
        ReflectionTestUtils.setField(module, "device", device);

        when(portRepository.findAll(any())).thenReturn(ports);
        when(portGroupRepository.findByPortId(anyLong())).thenReturn(null);
        when(portGroupRepository.findOne(10L)).thenReturn(portGroup);
        when(jobQueue.submit(any())).thenReturn(10L);
    }

    @Test
    public void testChangeAdminStatuswithNullPortIdList() {
        assertThat(portManagerOpenFlow.changeAdminStatus(deviceId, null, Port.AdminStatus.ENABLED, Port.Mode.LAYER2))
                .isEqualTo(10L);
        Mockito.verify(portRepository, Mockito.times(1)).findAll(any());
        Mockito.verify(portGroupRepository, Mockito.times(1)).findByPortId(anyLong());
        Mockito.verify(portGroupRepository, Mockito.times(0)).findOne(anyLong());
        Mockito.verify(jobQueue, Mockito.times(2)).submit(any());
    }

    @Test
    public void testChangeAdminStatusWithEmptyPortIdList() {
        assertThat(portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2)).isEqualTo(10L);
    }

    @Test(expected = ValidationException.class)
    public void testChangeAdminStatusWithPortInPortGroup() {
        List<Port> ports = new ArrayList<Port>();
        Port port = new Port();
        port.setWorkflowStatus(null);
        ports.add(port);

        Module module = new Module();
        Device device = new Device();
        device.setMode(Device.Mode.OPENFLOW);
        device.setLastCollectedTime(Instant.now());

        ReflectionTestUtils.setField(port, "module", module);
        ReflectionTestUtils.setField(module, "device", device);

        when(portGroupRepository.findByPortId(anyLong())).thenReturn(10L);
        when(portRepository.findAll(any())).thenReturn(ports);

        try {
            portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                    Port.Mode.LAYER2);
        } catch (ValidationException e) {
            Mockito.verify(portGroupRepository, Mockito.times(1)).findOne(anyLong());
            throw e;
        }
    }

    @Test
    public void testChangeAdminStatusWithPortInFlowPortMapping() {
        List<Long> flowIds = new ArrayList<Long>();
        flowIds.add(71L);
        portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2);
    }

    @Test(expected = ValidationException.class)
    public void testChangeAdminStatusWithValidPortGroupId() {
        when(portGroupRepository.findByPortId(anyLong())).thenReturn(10L);
        portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2);
    }

    @Test(expected = ValidationException.class)
    public void testChangeAdminStatusWithNullPortGroup() {
        when(portGroupRepository.findByPortId(anyLong())).thenReturn(10L);
        when(portGroupRepository.findOne(10L)).thenReturn(null);
        portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2);
    }

    @Test(expected = ValidationException.class)
    public void testChangeAdminStatusWithPortGroupWorkFlowSubmitted() {
        PortGroup portGroup1 = new PortGroup();
        portGroup1.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.SUBMITTED);
        when(portGroupRepository.findByPortId(anyLong())).thenReturn(10L);
        when(portGroupRepository.findOne(10L)).thenReturn(portGroup1);
        portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2);
    }

    @Test(expected = ValidationException.class)
    public void testChangeAdminStatusWithPortGroupWorkFlowError() {
        PortGroup portGroup1 = new PortGroup();
        portGroup1.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
        when(portGroupRepository.findByPortId(anyLong())).thenReturn(10L);
        when(portGroupRepository.findOne(10L)).thenReturn(portGroup1);
        portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.ENABLED,
                Port.Mode.LAYER2);
    }

    @Test
    public void testChangeAdminStatusWithPortModeNull() {
        assertThat(portManagerOpenFlow.changeAdminStatus(deviceId, Collections.emptyList(), Port.AdminStatus.DISABLED,
                null)).isEqualTo(10L);
    }
}
