package com.brocade.bvm.api.security;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.model.LoggedInUser;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.outbound.stablenet.service.StablenetMeasurementService;
import com.brocade.bvm.outbound.stablenet.service.StablenetUserGroupService;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ManagedObjectAuthorityProviderTest {

    @InjectMocks
    private ManagedObjectAuthorityProvider managedObjectAuthorityProvider;

    @Mock
    private StablenetUserGroupService groupService;

    @Mock
    private LoggedInUser loggedInUser;

    @Mock
    private StablenetMeasurementService measurementService;

    @Mock
    private PortRepository portRepository;

    @Mock
    private DeviceRepository deviceRepository;

    @Mock
    private Device device;

    @Before
    public void setup(){
        List<String> vlanIds = new ArrayList<>();
        vlanIds.add("100");
        vlanIds.add("200");
        Map<String,List<String>> accessMap = new HashMap<>();
        accessMap.put("VLAN",vlanIds);
        List<Long> portIds = new ArrayList<>();
        portIds.add(12L);
        portIds.add(13L);
        portIds.add(14L);
        List<Long> portIndices = new ArrayList<>();
        portIndices.add(3L);
        portIndices.add(2L);
        portIndices.add(4L);
        ReflectionTestUtils.setField(managedObjectAuthorityProvider, "isVlanFloodValidation", true);
        ReflectionTestUtils.setField(managedObjectAuthorityProvider, "isVlanFilterValidation", true);
        ReflectionTestUtils.setField(managedObjectAuthorityProvider, "loggedInUser", loggedInUser);
        when(device.getId()).thenReturn(1L);
        when(device.getStablenetId()).thenReturn(123L);
        when(groupService.getVlanSmacAndDmacForUser(any())).thenReturn(accessMap);
        when(loggedInUser.getUsername()).thenReturn("infosim");
        when(measurementService.getPortIndices(any())).thenReturn(portIndices);
        when(portRepository.findIdsByDeviceIdAndPortIndex(any(),any())).thenReturn(portIds);
        when(deviceRepository.findById(any())).thenReturn(device);
    }

    public static Policy getPolicy(Set<String> vlanIds,String ingressPortName, String egressPortName,Long ingressPortIndex, Long egressPortIndex,Long ingressId, Long egressId,int ruleVlanId){
        Policy policyToSave = new Policy();
        Device device = new Device();
        device.setStablenetId(123L);
        policyToSave.setDevice(device);
        policyToSave.setName("New Policy");
        Flow flow = new Flow();
        Set<Port> ingressPorts = new HashSet<>();
        Port ingressport = new Port();
        ReflectionTestUtils.setField(ingressport,"id",ingressId);
        ingressport.setStablenetIndex(ingressPortIndex);
        ingressport.setName(ingressPortName);
        ingressport.setType(Port.Type.INGRESS);
        ingressPorts.add(ingressport);
        Port egressPort = new Port();
        ReflectionTestUtils.setField(egressPort,"id",egressId);
        egressPort.setType(Port.Type.EGRESS);
        egressPort.setStablenetIndex(egressPortIndex);
        egressPort.setName(egressPortName);
        Set<Port> egressPorts = new HashSet<>();
        egressPorts.add(egressPort);
        flow.addIngressPorts(ingressPorts);
        flow.addEgressPorts(egressPorts);
        flow.setSequence(1);
        flow.setVlans(vlanIds);
        RuleSet ruleSet = new RuleSet();
        ruleSet.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet.setType(RuleSet.Type.L2);
        ruleSet.setSequence(0);
        SortedSet<Rule> rules = new TreeSet<>();
        Rule rule1 = new Rule();
        rule1.setVlanId(ruleVlanId);
        rule1.setSequence(1l);
        rules.add(rule1);
        ruleSet.addRules(rules);
        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        ruleSets.add(ruleSet);
        flow.setRuleSets(ruleSets);
        SortedSet<Flow> flows = new TreeSet<>();
        flows.add(flow);
        policyToSave.setFlows(flows);
        return policyToSave;
    }

    @Test
    public void isVlansInPolicyAuthorizedFor100And200(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("100");
        vlanIds.add("200");
        Policy policy = getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,100);
        Assertions.assertThat(managedObjectAuthorityProvider.isVlansInPolicyAuthorized(policy)).isTrue();
    }

    @Test
    public void isVlansInPolicyAuthorizedForFilterVlan(){
        ReflectionTestUtils.setField(managedObjectAuthorityProvider, "isVlanFilterValidation", false);
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("100");
        vlanIds.add("200");
        Policy policy = getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,400);
        Assertions.assertThat(managedObjectAuthorityProvider.isVlansInPolicyAuthorized(policy)).isTrue();
    }

    @Test
    public void isVlansInPolicyNotAuthorizedForFilterVlan(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("100");
        vlanIds.add("200");
        Policy policy = getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,400);
        Assertions.assertThat(managedObjectAuthorityProvider.isVlansInPolicyAuthorized(policy)).isFalse();
    }

    @Test
    public void isVlansInPolicyAuthorizedFor200And300(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("200");
        vlanIds.add("300");
        Policy policy = getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,-1);
        Assertions.assertThat(managedObjectAuthorityProvider.isVlansInPolicyAuthorized(policy)).isFalse();
    }

    @Test
    public void isVlansInPolicyAuthorizedFor300(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("300");
        Policy policy = getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,100);
        Assertions.assertThat(managedObjectAuthorityProvider.isVlansInPolicyAuthorized(policy)).isFalse();
    }

    @Test
    public void testApplyRBACOnPolicyReturnOne(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("100");
        Set<Policy> policies = new HashSet<>();
        policies.add(getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,100));
        policies.add(getPolicy(vlanIds,"1/4","1/5",4L,5L,14L,15L,100));
        Set<Policy> rbacPolicies = managedObjectAuthorityProvider.applyRBACOnPolicies(policies,1L);
        Assertions.assertThat(rbacPolicies.size()).isEqualTo(1);
    }

    @Test
    public void testApplyRBACOnPolicyReturnNonZero(){
        Set<String> vlanIds = new HashSet<>();
        vlanIds.add("100");
        Set<Policy> policies = new HashSet<>();
        policies.add(getPolicy(vlanIds,"1/3","1/2",3L,2L,13L,12L,100));
        policies.add(getPolicy(vlanIds,"1/3","1/4",3L,4L,13L,14L,100));
        Set<Policy> rbacPolicies = managedObjectAuthorityProvider.applyRBACOnPolicies(policies,1L);
        Assertions.assertThat(rbacPolicies.size()).isEqualTo(2);
    }
}
