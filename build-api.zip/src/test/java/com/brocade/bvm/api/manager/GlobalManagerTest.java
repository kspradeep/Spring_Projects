package com.brocade.bvm.api.manager;

import com.brocade.bvm.api.manager.generic.GlobalManagerImpl;
import com.brocade.bvm.api.model.PacketTruncationMappingRequest;
import com.brocade.bvm.api.model.PacketTruncationRequest;
import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridClusterRepository;
import com.brocade.bvm.dao.grid.GridTopologyPathRepository;
import com.brocade.bvm.job.JobQueue;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PacketTruncation;
import com.brocade.bvm.model.db.PacketTruncationMapping;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class GlobalManagerTest {

    @InjectMocks
    private GlobalManagerImpl globalManagerImpl;
    @Mock
    private DeviceRepository deviceRepository;

    @Mock
    private PacketTruncationMappingRepository packetTruncationMappingRepository;

    @Mock
    private PortRepository portRepository;

    @Mock
    private PortGroupRepository portGroupRepository;

    @Mock
    private PacketTruncationRepository packetTruncationRepository;

    @Mock
    private FlowRepository flowRepository;

    @Mock
    private PolicyRepository policyRepository;

    @Mock
    private GridClusterRepository gridClusterRepository;

    @Mock
    private GridTopologyPathRepository gridTopologyPathRepository;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private JobQueue jobQueue;

    @Before
    public void init() {

    }

    @Test(expected = ValidationException.class)
    public void testIsProfileNameNullInCommitTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setProfileName(null);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsFrameSizeNullInCommitTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setFrameSize(null);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsDeviceIdNullInCommitTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setDeviceId(null);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsPortIdNullInCommitTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setPortId(null);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testCommitTruncationProfileValidationDeviceEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(getPacketTruncationMappingRequest()));
        when(deviceRepository.findById(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testCommitTruncationProfileValidationPortEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(getPacketTruncationMappingRequest()));
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        device.setDeleted(false);
        when(deviceRepository.findById(anyLong())).thenReturn(device);
        when(portRepository.findOne(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testCommitTruncationProfileValidationPortChannelEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setType(PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        device.setDeleted(false);
        when(deviceRepository.findById(anyLong())).thenReturn(device);
        when(portGroupRepository.findOne(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "commit", packetTruncationRequest);
    }

    @Test
    public void testPacketTruncationProfileNameValidationSuccess() {
        boolean result = true;
        List<String> profileNames = new ArrayList<>();
        profileNames.add("TEST_PROFILE-23456789");
        profileNames.add("TEST-PROFILE_23456789");
        profileNames.add("TEST_PROFILE-23456789123456789");
        profileNames.forEach(profileName -> {
            boolean resultName = ReflectionTestUtils.invokeMethod(globalManagerImpl, "isValidPacketTruncationProfileName", profileName);
            assertEquals(result, resultName);
        });
    }

    @Test
    public void testPacketTruncationProfileNameValidationFailures() {
        boolean result = false;
        List<String> profileNames = new ArrayList<>();
        profileNames.add("_TEST_PROFILE-23456789");
        profileNames.add("-TEST-PROFILE_23456789");
        profileNames.add("TEST-PROFILE_23456789TEST-PROFILE_23456789");
        profileNames.add("@#$%^&*()!");
        profileNames.forEach(profileName -> {
            boolean resultName = ReflectionTestUtils.invokeMethod(globalManagerImpl, "isValidPacketTruncationProfileName", profileName);
            assertEquals(result, resultName);
        });
    }

    @Test
    public void testPacketTruncationFrameSizeValidationSuccess() {
        boolean result = true;
        List<Long> frameSizeList = new ArrayList<>();
        frameSizeList.add(64L);
        frameSizeList.add(256L);
        frameSizeList.add(9216L);
        frameSizeList.forEach(frameSize -> {
            boolean resultName = ReflectionTestUtils.invokeMethod(globalManagerImpl, "isValidPacketTruncationProfileFrameSize", frameSize);
            assertEquals(result, resultName);
        });
    }

    @Test
    public void testPacketTruncationFrameSizeValidationFailures() {
        boolean result = false;
        List<Long> frameSizeList = new ArrayList<>();
        frameSizeList.add(33L);
        frameSizeList.add(202L);
        frameSizeList.add(3242423L);
        frameSizeList.forEach(frameSize -> {
            boolean resultName = ReflectionTestUtils.invokeMethod(globalManagerImpl, "isValidPacketTruncationProfileFrameSize", frameSize);
            assertEquals(result, resultName);
        });
    }

    @Test(expected = ValidationException.class)
    public void testIsTruncationPrifileNameFound() {
        List<PacketTruncationMapping> packetTruncationMappings = new ArrayList<>();
        packetTruncationMappings.add(getPacketTruncationMapping());
        when(packetTruncationMappingRepository.findByProfileNameAndDeviceId(anyString(), anyLong())).thenReturn(packetTruncationMappings);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "validatePacketTruncationProfile", getPacketTruncationRequest(),false);
    }

    @Test(expected = ValidationException.class)
    public void testIsMaxFourProfiles() {
        List<PacketTruncationMapping> packetTruncationMappings = new ArrayList<>();
        packetTruncationMappings.add(getPacketTruncationMapping());
        packetTruncationMappings.add(getPacketTruncationMapping());
        packetTruncationMappings.add(getPacketTruncationMapping());
        packetTruncationMappings.add(getPacketTruncationMapping());
        when(packetTruncationMappingRepository.findByDeviceId(anyLong())).thenReturn(packetTruncationMappings);
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        device.setDeleted(false);
        when(deviceRepository.findById(anyLong())).thenReturn(device);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "isMaxFourProfiles", getPacketTruncationRequest());
    }

    @Test(expected = ValidationException.class)
    public void testIsInterfaceAssociated() {
        when(packetTruncationMappingRepository.findByDeviceIdAndInterface(anyLong(), anyLong())).thenReturn(getPacketTruncationMapping());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "isInterfaceAssociated", getPacketTruncationMappingRequest());
    }

    //update packet truncation profile
    @Test(expected = ValidationException.class)
    public void testIsProfileNameNullInUpdateTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setProfileName(null);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsFrameSizeNullInUpdateTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setFrameSize(null);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsDeviceIdNullInUpdateTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setDeviceId(null);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testIsPortIdNullInUpdateTruncationProfile() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setPortId(null);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);

    }

    @Test(expected = ValidationException.class)
    public void testUpdateTruncationProfileWithDifferentProfileName() {
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        when(gridClusterRepository.findInterfaceByManagedObjectId(anyList())).thenReturn(Sets.newHashSet());
        when(gridTopologyPathRepository.findIntermediateIngressByManagedObjectId(anyList())).thenReturn(Sets.newHashSet());
        when(gridTopologyPathRepository.findIntermediateEgressByManagedObjectId(anyList())).thenReturn(Sets.newHashSet());
        when(gridTopologyPathRepository.findSourceIngressByManagedObjectId(anyList())).thenReturn(Sets.newHashSet());
        when(gridTopologyPathRepository.findDestinationEgressByManagedObjectId(anyList())).thenReturn(Sets.newHashSet());
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setProfileName("Different_Name");
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(getPacketTruncationMappingRequest()));
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testUpdateTruncationProfileValidationDeviceEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(getPacketTruncationMappingRequest()));
        when(deviceRepository.findById(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testUpdateTruncationProfileValidationPortEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(getPacketTruncationMappingRequest()));
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        device.setDeleted(false);
        when(deviceRepository.findById(anyLong())).thenReturn(device);
        when(portRepository.findOne(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    @Test(expected = ValidationException.class)
    public void testUpdateTruncationProfileValidationPortChannelEntityNotFound() {
        PacketTruncationRequest packetTruncationRequest = getPacketTruncationRequest();
        PacketTruncationMappingRequest packetTruncationMappingRequest = getPacketTruncationMappingRequest();
        packetTruncationMappingRequest.setType(PacketTruncationMappingRequest.INTERFACE_TYPE.PORT_CHANNEL);
        packetTruncationRequest.setPacketTruncationMappingRequest(Sets.newHashSet(packetTruncationMappingRequest));
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        device.setDeleted(false);
        when(deviceRepository.findById(anyLong())).thenReturn(device);
        when(portGroupRepository.findOne(anyLong())).thenReturn(null);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "update", 1l, packetTruncationRequest);
    }

    //Delete packet truncation profile
    @Test(expected = ValidationException.class)
    public void testDeleteForInvalidId() {
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(null);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "delete", 1l);
    }

    @Test(expected = ValidationException.class)
    public void testDeleteIsProfileAsscoistedToPolicy() {
        Set<BigInteger> policyIds = new HashSet<>();
        policyIds.add(new BigInteger("1"));
        when(flowRepository.findByPacketTruncationMappingId(anyLong())).thenReturn(policyIds);
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(getPacketTruncation());
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "delete", 1l);
    }

    @Test(expected = ValidationException.class)
    public void testDeleteIsProfileAsscoistedToError() {
        PacketTruncation packetTruncation = getPacketTruncation();
        packetTruncation.getPacketTruncationMappings().forEach(packetTruncationMapping -> packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR));
        when(packetTruncationRepository.findOne(anyLong())).thenReturn(packetTruncation);
        ReflectionTestUtils.invokeMethod(globalManagerImpl, "delete", 1l);
    }

    //View packet truncation profile summaries
    @Test
    public void testGetProfiles() {
        String sampleGetProfilesOutput = "[{\"profileName\":\"Test_Profile\",\"frameSize\":64,\"truncationProfileMapSummaries\":[{\"policyName\":null,\"workflowStatus\":\"ACTIVE\",\"portId\":null,\"type\":\"PORT\",\"deviceName\":\"Slx-71\",\"portNumber\":\"Ethernet 0/1\"}],\"workflowStatus\":null}]";
        when(packetTruncationRepository.findAll()).thenReturn(Lists.newArrayList(getPacketTruncation()));
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfiles");
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    @Test
    public void testGetProfilesForEmpty() {
        String sampleGetProfilesOutput = "[]";
        when(packetTruncationRepository.findAll()).thenReturn(Lists.newArrayList());
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfiles");
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    @Test
    public void testGetProfilesContainsPolicy() {
        String sampleGetProfilesOutput = "[{\"profileName\":\"Test_Profile\",\"frameSize\":64,\"truncationProfileMapSummaries\":[{\"policyName\":\"RM_PolicyTest\",\"workflowStatus\":\"ACTIVE\",\"portId\":null,\"type\":\"PORT\",\"deviceName\":\"Slx-71\",\"portNumber\":\"Ethernet 0/1\"}],\"workflowStatus\":null}]";
        when(packetTruncationRepository.findAll()).thenReturn(Lists.newArrayList(getPacketTruncation()));
        Set<BigInteger> policyIds = new HashSet<>();
        policyIds.add(new BigInteger("1"));
        when(flowRepository.findByPacketTruncationMappingId(anyLong())).thenReturn(policyIds);
        when(policyRepository.findNameById(anyLong())).thenReturn("RM_PolicyTest");
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfiles");
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    //View packet truncation profile summaries by device
    @Test
    public void testGetActiveProfilesByDeviceId() {
        String sampleGetProfilesOutput = "[{\"profileName\":\"Test_Profile\",\"frameSize\":64,\"workflowStatus\":\"ACTIVE\",\"interface\":\"Ethernet 0/1\"}]";
        when(packetTruncationMappingRepository.findByDeviceId(anyLong())).thenReturn(Lists.newArrayList(getPacketTruncation().getPacketTruncationMappings()));
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfile", anyLong());
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    @Test
    public void testGetProfilesByDeviceIdForEmpty() {
        String sampleGetProfilesOutput = "[]";
        when(packetTruncationMappingRepository.findByDeviceId(anyLong())).thenReturn(Lists.newArrayList());
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfile", anyLong());
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    @Test
    public void testGetErrorProfilesByDeviceId() {
        String sampleGetProfilesOutput = "[]";
        PacketTruncationMapping packetTruncationMapping = getPacketTruncationMapping();
        packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ERROR);
        when(packetTruncationMappingRepository.findByDeviceId(anyLong())).thenReturn(Lists.newArrayList(packetTruncationMapping));
        String result = ReflectionTestUtils.invokeMethod(globalManagerImpl, "getProfile", anyLong());
        Assertions.assertThat(result).isEqualTo(sampleGetProfilesOutput);
    }

    private PacketTruncationRequest getPacketTruncationRequest() {
        PacketTruncationRequest packetTruncationRequest = new PacketTruncationRequest();
        packetTruncationRequest.setProfileName("Test_Profile");
        packetTruncationRequest.setFrameSize(64L);
        Set<PacketTruncationMappingRequest> packetTruncationMappingRequestSet = new HashSet<>();
        PacketTruncationMappingRequest packetTruncationMappingRequest = new PacketTruncationMappingRequest();
        packetTruncationMappingRequest.setDeviceId(null);
        packetTruncationMappingRequest.setPortId(null);
        packetTruncationMappingRequest.setType(PacketTruncationMappingRequest.INTERFACE_TYPE.PORT);
        packetTruncationMappingRequestSet.add(packetTruncationMappingRequest);
        packetTruncationRequest.setPacketTruncationMappingRequest(packetTruncationMappingRequestSet);
        return packetTruncationRequest;
    }

    private PacketTruncationMappingRequest getPacketTruncationMappingRequest() {
        PacketTruncationMappingRequest packetTruncationMappingRequest = new PacketTruncationMappingRequest();
        packetTruncationMappingRequest.setDeviceId(1L);
        packetTruncationMappingRequest.setPortId("1");
        packetTruncationMappingRequest.setType(PacketTruncationMappingRequest.INTERFACE_TYPE.PORT);
        return packetTruncationMappingRequest;
    }

    private PacketTruncationMapping getPacketTruncationMapping() {
        PacketTruncationMapping packetTruncationMapping = new PacketTruncationMapping();
        Port port = new Port();
        port.setName("Ethernet 0/1");
        packetTruncationMapping.setPort(port);
        Device device = new Device();
        device.setName("Slx-71");
        device.setType(Device.Type.SLX);
        packetTruncationMapping.setDevice(device);
        packetTruncationMapping.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        return packetTruncationMapping;
    }

    private PacketTruncation getPacketTruncation() {
        PacketTruncation packetTruncation = new PacketTruncation();
        packetTruncation.setName("Test_Profile");
        packetTruncation.setFrameSize(64L);
        Set<PacketTruncationMapping> packetTruncationMappings = new HashSet<>();
        packetTruncationMappings.add(getPacketTruncationMapping());
        packetTruncation.setPacketTruncationMappings(packetTruncationMappings);
        return packetTruncation;
    }

}
