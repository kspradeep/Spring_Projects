package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.model.db.statistics.Policy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class StatisticsPolicyControllerTest {

    @InjectMocks
    StatisticsPolicyController statisticsPolicyController;
    private MockMvc mockMvc;

    @Mock
    private StatisticsPolicyRepository policyRepository;
    @Before
    public void before() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsPolicyController).build();
    }

    @Test
    public void itShouldReturnAllPolicies() throws Exception {

        List<Policy> policies = new ArrayList<>();
        Policy policy = new Policy();
        policy.setName("policy1");
        policies.add(policy);

        given(policyRepository.getPolicies())
                .willReturn(policies);

        this.mockMvc.perform(get("/statistics/policies"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].name", is("policy1")));
    }

    @Test
    public void itShouldReturnPolicyStatistics() throws Exception {

        this.mockMvc.perform(get("/statistics/1/policy"))
                .andExpect(status().isOk());
    }
}
