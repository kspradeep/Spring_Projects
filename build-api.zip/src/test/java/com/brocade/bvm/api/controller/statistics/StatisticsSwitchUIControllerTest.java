package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.manager.statistics.SwitchOverviewManager;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsSwitchRepository;
import com.brocade.bvm.dao.statistics.cache.PortCache;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.statistics.PortBandwidth;
import com.brocade.bvm.model.db.statistics.PortPackets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class StatisticsSwitchUIControllerTest {
    @Mock
    private SwitchOverviewManager switchOverviewManager;

    @InjectMocks
    private StatisticsSwitchUIController statisticsSwitchUIController;
    @Mock
    private DeviceRepository deviceRepository;
    @Mock
    private PolicyRepository policyRepository;
    @Mock
    private StatisticsSwitchRepository statisticsSwitchRepository;
    @Mock
    private StatisticsPortRepository statisticsPortRepository;
    @Mock
    private StatisticsPolicyRepository statisticsPolicyRepository;
    private MockMvc mockMvc;

    @Before
    public void setup() {
        // Setup Spring test in standalone mode
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsSwitchUIController).build();
    }

    @Test
    public void itShouldReturnSwitchPackets() throws Exception {
        List<PortPackets> result = new ArrayList<>();
        PortPackets packets = new PortPackets();
        packets.setThroughput(100);
        packets.setLastUpdatedTime("");
        result.add(packets);

        when(switchOverviewManager.findSwitchPackets(1L, 20)).thenReturn(result);

        this.mockMvc.perform(get("/statistics/1/20/device-packets"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].throughput", is(100)));
    }

    @Test
    public void itShouldReturnSwitchUtilization() throws Exception {
        List<PortBandwidth> utilization = new ArrayList<>();
        PortBandwidth portBandwidth = new PortBandwidth();
        portBandwidth.setInUtilization(100.00);
        utilization.add(portBandwidth);


        when(switchOverviewManager.findDeviceUtilization(1L, 20))
                .thenReturn(utilization);

        this.mockMvc.perform(get("/statistics/1/20/system-utilization"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].inUtilization", is(100.00)));
    }

    @Test
    public void itShouldReturnSwitchThroughput() throws Exception {
        List<PortBandwidth> utilization = new ArrayList<>();
        PortBandwidth portBandwidth = new PortBandwidth();
        portBandwidth.setInUtilization(100.00);
        utilization.add(portBandwidth);


        when(switchOverviewManager.findDeviceUtilization(1L, 20))
                .thenReturn(utilization);

        this.mockMvc.perform(get("/statistics/1/20/system-throughput"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].inUtilization", is(100.00)));
    }

    @Test
    public void itShouldReturnSwitchOverview() throws Exception {
        Device device = new Device();
        device.setOs("Windows");
        device.setSystemDescription("description");
        device.setIpAddress("10.10.134.34");

        List<Policy> policies = new ArrayList<>();

        given(deviceRepository.findByIdAndTypeAndIsReconciled(1L, Device.Type.SLX)).willReturn(device);
        given(policyRepository.findActivePoliciesByDeviceId(1L)).willReturn(policies);

        this.mockMvc.perform(get("/statistics/1/switch-overview"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.os", is("description")))
                .andExpect(jsonPath("$.ipAddress", is("10.10.134.34")));
    }

    @Test
    public void itShouldReturnAllSwitchesOverview() throws Exception {
        Map<String, Long> map = new HashMap<>();
        map.put("ingress", 1L);
        map.put("egress", 1L);
        given(statisticsPortRepository.getAllIngressAndEgressTapPorts())
                .willReturn(map);

        this.mockMvc.perform(get("/statistics/switch-overview"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalTapPorts", is(1)))
                .andExpect(jsonPath("$.totalToolPorts", is(1)));
    }

    @Mock
    private PortCache portCache;
    @Test
    public void itShouldReturnAllSwitchesStatistics() throws Exception {

        List<String> devices = new ArrayList<>();
        devices.add("device1");
        CompletableFuture<List<String>> fiveSwitches = CompletableFuture.completedFuture(devices);
        given(switchOverviewManager.findTopFiveSwitches()).willReturn(fiveSwitches);
        given(switchOverviewManager.findBottomFiveSwitches()).willReturn(fiveSwitches);
        this.mockMvc.perform(get("/statistics/switch-statistics-overview"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.topFiveDevices[0]", is("device1")))
                .andExpect(jsonPath("$.bottomFiveDevices", is(new ArrayList())));
    }
}
