package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.model.ValidationException;
import com.brocade.bvm.model.db.DeviceDiscoveryJob;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class DeviceManagementControllerTest {

    @InjectMocks
    private GlobalController globalController;

    private DeviceDiscoveryJob deviceDiscoveryJob;

    @Before
    public void setup() {
        deviceDiscoveryJob = new DeviceDiscoveryJob();
        Set<String> ipSet = new HashSet<>();
        ((HashSet) ipSet).add("10.37.128.90");
        deviceDiscoveryJob.setIps(ipSet);
        deviceDiscoveryJob.setCliPassword("password");
        deviceDiscoveryJob.setCliUserName("admin");
        deviceDiscoveryJob.setSnmpCommunity("comm1");
    }

    @Test(expected = ValidationException.class)
    public void deleteDevicesWhenDeviceIdIncorrect() {
        String deviceIds = "78@09";
        globalController.removeDevicesFromMeasurements(deviceIds);
    }

    @Test(expected = ValidationException.class)
    public void deleteDevicesWhenDeviceIdNotGiven() {
        String deviceIds = "";
        globalController.removeDevicesFromMeasurements(deviceIds);
    }

    @Test(expected = ValidationException.class)
    public void testAddDevicesWhenIpNotGiven() {
        DeviceDiscoveryJob deviceDiscoveryJob = this.deviceDiscoveryJob;
        deviceDiscoveryJob.setIps(null);
        globalController.addDevices(deviceDiscoveryJob);
    }

    @Test(expected = ValidationException.class)
    public void testAddDevicesWhenUserNameNotGiven() {
        DeviceDiscoveryJob deviceDiscoveryJob = this.deviceDiscoveryJob;
        deviceDiscoveryJob.setCliUserName(null);
        globalController.addDevices(deviceDiscoveryJob);
    }

    @Test(expected = ValidationException.class)
    public void testAddDevicesWhenPasswordNotGiven() {
        DeviceDiscoveryJob deviceDiscoveryJob = this.deviceDiscoveryJob;
        deviceDiscoveryJob.setCliPassword(null);
        globalController.addDevices(deviceDiscoveryJob);
    }

    @Test(expected = ValidationException.class)
    public void testAddDevicesWhenSnmpPasswordNotGiven() {
        DeviceDiscoveryJob deviceDiscoveryJob = this.deviceDiscoveryJob;
        deviceDiscoveryJob.setSnmpCommunity(null);
        globalController.addDevices(deviceDiscoveryJob);
    }
}