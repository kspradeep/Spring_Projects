package com.brocade.bvm.api.controller;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Event;
import com.brocade.bvm.model.db.Job;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collections;
import java.util.HashSet;

@RunWith(MockitoJUnitRunner.class)
public class EventControllerTest {

    @InjectMocks
    EventController eventController;

    Event event;

    @Before
    public void setup() throws NoSuchFieldException {

        Device d = new Device();
        ReflectionTestUtils.setField(d, "id", 1L);
        d.setName("MLXE_4_SLOT_10.37.136.11_59ab");
        Job job = new Job();
        ReflectionTestUtils.setField(job, "id", 10L);
        job.setStatus(Job.Status.SUCCESS);
        job.setType(Job.Type.POLICY_CREATE);
        job.setTargetHost(d);
        job.setParentObjectId(12L);
        job.setImpactedObjectsIds(new HashSet<>(Collections.singletonList(new Long(13L))));
        event = new Event();
        event.setJob(job);
        event.setStatus(Event.Status.NEW);
        event.setId(11L);
    }

    @Test
    public void testEventJsonResponse() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        String jsonRequest = mapper.writeValueAsString(event);
        System.out.println(jsonRequest);
    }


}
