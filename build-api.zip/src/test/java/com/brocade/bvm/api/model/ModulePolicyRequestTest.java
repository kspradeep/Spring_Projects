package com.brocade.bvm.api.model;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class ModulePolicyRequestTest {

    private static final String expectedRequestLoadBalance = "{\"loadBalanceModulePolicy\":{\"id\":null,\"name\":\"Load Balance Policy for 1\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":null,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":null,\"ports\":[{\"id\":null,\"name\":\"Ethernet 0/1\",\"workflowStatus\":null,\"workflowType\":null,\"portDescription\":null,\"portNumber\":\" 0/1\",\"openFlowPortNumber\":\"eth 0/1\",\"physicalAddress\":null,\"linkStatus\":\"UP\",\"ppcr\":null,\"type\":\"INGRESS\",\"mode\":null,\"lineSpeed\":null,\"maxSpeed\":null,\"adminStatus\":\"ENABLED\",\"precedence\":0}]}],\"device\":null,\"isSourceIpIncluded\":false,\"isSourcePortIncluded\":false,\"isDestinationIpIncluded\":false,\"isDestinationPortIncluded\":false,\"isTeIdIncluded\":false,\"isInnerIpIncluded\":false,\"isProtocolMaskIncluded\":false,\"isBiDirectional\":true,\"tunnelingProtocol\":\"tcp\",\"biDirectional\":true,\"sourceIpIncluded\":false,\"sourcePortIncluded\":false,\"destinationIpIncluded\":false,\"destinationPortIncluded\":false,\"protocolMaskIncluded\":false,\"innerIpIncluded\":false,\"teIdIncluded\":false},\"slxLoadBalanceModulePolicy\":null,\"packetSlicingModulePolicy\":null,\"packetStampingModulePolicy\":null,\"headerStrippingModulePolicy\":null,\"packetLabelingModulePolicy\":null,\"gtpDeEncapsulationModulePolicy\":null,\"ipPayloadLengthPolicy\":null}";
    private static final String expectedRequestPacketStamping = "{\"loadBalanceModulePolicy\":null,\"slxLoadBalanceModulePolicy\":null,\"packetSlicingModulePolicy\":null,\"packetStampingModulePolicy\":{\"id\":null,\"name\":\"Packet Timestampping for Processor 1\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":null,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":null,\"ports\":[{\"id\":null,\"name\":\"Ethernet 0/1\",\"workflowStatus\":null,\"workflowType\":null,\"portDescription\":null,\"portNumber\":\" 0/1\",\"openFlowPortNumber\":\"eth 0/1\",\"physicalAddress\":null,\"linkStatus\":\"UP\",\"ppcr\":null,\"type\":\"INGRESS\",\"mode\":null,\"lineSpeed\":null,\"maxSpeed\":null,\"adminStatus\":\"ENABLED\",\"precedence\":0}]}],\"device\":null,\"processor\":\"ONE\"},\"headerStrippingModulePolicy\":null,\"packetLabelingModulePolicy\":null,\"gtpDeEncapsulationModulePolicy\":null,\"ipPayloadLengthPolicy\":null}";
    private static final String expectedRequestHeaderStripping = "{\"loadBalanceModulePolicy\":null,\"slxLoadBalanceModulePolicy\":null,\"packetSlicingModulePolicy\":null,\"packetStampingModulePolicy\":null,\"headerStrippingModulePolicy\":{\"id\":null,\"name\":\"BR802 Header stripping\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":null,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":null,\"ports\":[{\"id\":null,\"name\":\"Ethernet 0/1\",\"workflowStatus\":null,\"workflowType\":null,\"portDescription\":null,\"portNumber\":\" 0/1\",\"openFlowPortNumber\":\"eth 0/1\",\"physicalAddress\":null,\"linkStatus\":\"UP\",\"ppcr\":null,\"type\":\"INGRESS\",\"mode\":null,\"lineSpeed\":null,\"maxSpeed\":null,\"adminStatus\":\"ENABLED\",\"precedence\":0}]}],\"device\":null,\"stripHeaders\":[\"BR802\"],\"ports\":[],\"processor\":\"ONE\",\"intermediateVlan\":0,\"intermediatePort\":null,\"intermediatePortId\":null,\"replaceVlan\":0,\"preserve\":false},\"packetLabelingModulePolicy\":null,\"gtpDeEncapsulationModulePolicy\":null,\"ipPayloadLengthPolicy\":null}";
    private static final String expectedRequestPacketSlicing = "{\"loadBalanceModulePolicy\":null,\"slxLoadBalanceModulePolicy\":null,\"packetSlicingModulePolicy\":{\"id\":null,\"name\":\"Packet Slicing\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":null,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":null,\"ports\":[{\"id\":null,\"name\":\"Ethernet 0/1\",\"workflowStatus\":null,\"workflowType\":null,\"portDescription\":null,\"portNumber\":\" 0/1\",\"openFlowPortNumber\":\"eth 0/1\",\"physicalAddress\":null,\"linkStatus\":\"UP\",\"ppcr\":null,\"type\":\"INGRESS\",\"mode\":null,\"lineSpeed\":null,\"maxSpeed\":null,\"adminStatus\":\"ENABLED\",\"precedence\":0}]}],\"device\":null,\"numberOfBytes\":null,\"ports\":[{\"id\":null,\"name\":\"Ethernet 0/1\",\"workflowStatus\":null,\"workflowType\":null,\"portDescription\":null,\"portNumber\":\" 0/1\",\"openFlowPortNumber\":\"eth 0/1\",\"physicalAddress\":null,\"linkStatus\":\"UP\",\"ppcr\":null,\"type\":\"INGRESS\",\"mode\":null,\"lineSpeed\":null,\"maxSpeed\":null,\"adminStatus\":\"ENABLED\",\"precedence\":0}]},\"packetStampingModulePolicy\":null,\"headerStrippingModulePolicy\":null,\"packetLabelingModulePolicy\":null,\"gtpDeEncapsulationModulePolicy\":null,\"ipPayloadLengthPolicy\":null}";

    private Set<Module> modules = new HashSet<>();

    @Before
    public void setup() {
        Device device = saveDevice();
        Module module = device.getModules().stream().findFirst().get();
        modules.add(module);
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device.setLastUpdatedTime(Instant.now());

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("Ethernet 0/1");
        port1.setStablenetId(1L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);
        port1.setStablenetIndex(103L);

        module.addPorts(Sets.newHashSet(port1));
        device.addModules(Sets.newHashSet(module));
        return device;
    }

    @Test
    public void testLoadBalanceJsonRequest() throws JsonProcessingException {

        LoadBalanceModulePolicy lpPolicy = new LoadBalanceModulePolicy();
        lpPolicy.setBiDirectional(true);
        lpPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        lpPolicy.setTunnelingProtocol("tcp");
        lpPolicy.setName("Load Balance Policy for 1");
        lpPolicy.setModules(modules);
        ModulePolicyRequest request = new ModulePolicyRequest();
        request.setLoadBalanceModulePolicy(lpPolicy);
        ObjectMapper mapper = new ObjectMapper();
        String jsonRequest = mapper.writeValueAsString(request);
        System.out.println(jsonRequest);
        Assertions.assertThat(jsonRequest).isNotEmpty();
        //TODO: Order of the inner fields is getting lost
        Assertions.assertThat(jsonRequest).isEqualTo(expectedRequestLoadBalance);
    }


    @Test
    public void testPacketStampingJsonRequest() throws JsonProcessingException {

        PacketStampingModulePolicy packetStampingModulePolicy = new PacketStampingModulePolicy();
        packetStampingModulePolicy.setName("Packet Timestampping for Processor 1");
        packetStampingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        packetStampingModulePolicy.setModules(modules);
        packetStampingModulePolicy.setProcessor(PacketStampingModulePolicy.ProcessorNumber.ONE);
        ModulePolicyRequest request = new ModulePolicyRequest();
        request.setPacketStampingModulePolicy(packetStampingModulePolicy);
        ObjectMapper mapper = new ObjectMapper();
        String jsonRequest = mapper.writeValueAsString(request);
        System.out.println(jsonRequest);
        Assertions.assertThat(jsonRequest).isNotEmpty();
        Assertions.assertThat(jsonRequest).isEqualTo(expectedRequestPacketStamping);
    }

    @Test
    public void testHeaderStrippingJsonRequest() throws JsonProcessingException {

        HeaderStrippingModulePolicy headerStrippingModulePolicy = new HeaderStrippingModulePolicy();
        headerStrippingModulePolicy.setName("BR802 Header stripping");
        headerStrippingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        headerStrippingModulePolicy.setModules(modules);
        headerStrippingModulePolicy.setProcessor(HeaderStrippingModulePolicy.ProcessorNumber.ONE);
        headerStrippingModulePolicy.setStripHeaders(new HashSet<>(Arrays.asList(HeaderStrippingModulePolicy.Headers.BR802)));
        ModulePolicyRequest request = new ModulePolicyRequest();
        request.setHeaderStrippingModulePolicy(headerStrippingModulePolicy);
        ObjectMapper mapper = new ObjectMapper();
        String jsonRequest = mapper.writeValueAsString(request);
        System.out.println(jsonRequest);
        Assertions.assertThat(jsonRequest).isNotEmpty();
        Assertions.assertThat(jsonRequest).isEqualTo(expectedRequestHeaderStripping);
    }

    @Test
    public void testPacketSlicingJsonRequest() throws JsonProcessingException {

        PacketSlicingModulePolicy packetSlicingModulePolicy = new PacketSlicingModulePolicy();
        packetSlicingModulePolicy.setName("Packet Slicing");
        packetSlicingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        packetSlicingModulePolicy.setModules(modules);

        Port port = modules.stream().findFirst().get().getPorts().stream().findFirst().get();
        packetSlicingModulePolicy.setPorts(Sets.newHashSet(port));

        ModulePolicyRequest request = new ModulePolicyRequest();
        request.setPacketSlicingModulePolicy(packetSlicingModulePolicy);
        ObjectMapper mapper = new ObjectMapper();
        String jsonRequest = mapper.writeValueAsString(request);
        Assertions.assertThat(jsonRequest).isNotEmpty();
        Assertions.assertThat(jsonRequest).isEqualTo(expectedRequestPacketSlicing);
    }
}
