package com.brocade.bvm.api.controller;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@RunWith(MockitoJUnitRunner.class)
public class PolicyControllerTest {


    @InjectMocks
    PolicyController policyController;

    Policy policy;

    @Before
    public void setup() throws NoSuchFieldException {
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        ReflectionTestUtils.setField(device,"id",1L);

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);

        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        device.addModules(Sets.newHashSet(module));


        return device;
    }

    private Policy getPolicy(String policyName, WorkflowParticipant.WorkflowStatus workflowStatus) {
        Device device = saveDevice();
        Policy policyToSave = new Policy();
        policyToSave.setName(policyName);
        policyToSave.setFlows(getFlows(device));
        policyToSave.setWorkflowStatus(workflowStatus);
        ReflectionTestUtils.setField(policyToSave,"id",10L);
        return policyToSave;
    }

    private static SortedSet<Flow> getFlows(Device device) {
        Flow flow = new Flow();
        ReflectionTestUtils.setField(flow,"id",11L);
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> egressPorts = new HashSet<>();

        List<Port> ingressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType()==Port.Type.INGRESS).collect(Collectors.toList());
        List<Port> egressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType()==Port.Type.EGRESS).collect(Collectors.toList());

        ingressPorts.add(ingressList.get(0));
        egressPorts.add(egressList.get(0));

        flow.addIngressPorts(ingressPorts);
        flow.addEgressPorts(egressPorts);
        flow.setSequence(1);
        flow.setRuleSets(getRuleSets());

        Flow flow1 = new Flow();
        ReflectionTestUtils.setField(flow1,"id",31L);
        Set<Port> ingressPorts1 = new HashSet<>();
        Set<Port> egressPorts1 = new HashSet<>();

        ingressPorts1.add(ingressList.get(1));
        egressPorts1.add(egressList.get(1));

        flow1.addIngressPorts(ingressPorts1);
        flow1.addEgressPorts(egressPorts1);
        flow1.setSequence(2);

        SortedSet<Flow> flows = new TreeSet<>();
        flows.add(flow);
        flows.add(flow1);
        return flows;
    }

    private static SortedSet<RuleSet> getRuleSets() {
        RuleSet ruleSet = new RuleSet();
        ruleSet.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet.setType(RuleSet.Type.L2);
        ruleSet.setSequence(0);
        ruleSet.addRules(getRules());
        ReflectionTestUtils.setField(ruleSet,"id",11L);
        RuleSet ruleSet1 = new RuleSet();
        ruleSet1.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet1.setType(RuleSet.Type.L2);
        ruleSet1.setSequence(1);
        ruleSet1.addRules(getRules());

        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        ruleSets.add(ruleSet);
        ruleSets.add(ruleSet1);
        return ruleSets;
    }

    private static SortedSet<Rule> getRules() {
        Rule rule = new Rule();
        rule.setSequence(10l);
        Rule rule1 = new Rule();
        rule1.setSequence(6l);
        ReflectionTestUtils.setField(rule1,"id",21L);
        Rule rule2 = new Rule();
        rule2.setSequence(27l);
        ReflectionTestUtils.setField(rule2,"id",22L);
        Rule rule3 = new Rule();
        rule3.setSequence(99l);
        ReflectionTestUtils.setField(rule2,"id",23L);
        // wiring rules
        SortedSet<Rule> ruleSet = new TreeSet<>();
        ruleSet.add(rule);
        ruleSet.add(rule1);
        ruleSet.add(rule2);
        ruleSet.add(rule3);

        return ruleSet;
    }


    @Test
    public void testFlushIdsForPolicy(){
        Policy forCopy = getPolicy("TestPolicy", WorkflowParticipant.WorkflowStatus.ACTIVE);
        Policy policy = ReflectionTestUtils.invokeMethod(policyController,"flushIdsForPolicy",forCopy);
        Assertions.assertThat(policy.getId()).isNull();
        Assertions.assertThat(policy.getFlows().stream().allMatch(flow -> flow.getId() == null)).isTrue();
        policy.getFlows().stream().forEach(flow -> {
            if(flow.getId()!=null){
                Assertions.fail("Flow id is not set to null");
            }
            flow.getRuleSets().forEach(ruleSet -> {
                if(ruleSet.getId()!=null){
                    Assertions.fail("Flow id is not set to null");
                }
                ruleSet.getRules().stream().forEach(rule -> {
                    if(rule.getId()!=null){
                        Assertions.fail("Flow id is not set to null");
                    }
                });
            });
        });

    }




}
