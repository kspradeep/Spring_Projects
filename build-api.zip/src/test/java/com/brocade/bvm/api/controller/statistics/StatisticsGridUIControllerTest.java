package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsGridRepository;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class StatisticsGridUIControllerTest {

    @InjectMocks
    StatisticsGridUIController statisticsGridUIController;
    @Mock
    private GridRepository gridRepository;
    @Mock
    private StatisticsGridRepository statisticsGridRepository;


    private MockMvc mockMvc;


    @Before
    public void before() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsGridUIController).build();
    }

    @Test
    public void itShouldReturnGridStatistics() throws Exception {
        given(statisticsGridRepository.getPortOverThresholdCount(1L))
                .willReturn(1);
        DeviceGrid deviceGrid = new DeviceGrid();
        given(gridRepository.findOne(null)).willReturn(deviceGrid);
        this.mockMvc.perform(get("/statistics/1/grid-statistics"))
                .andExpect(status().isOk());
    }
}
