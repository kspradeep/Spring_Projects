package com.brocade.bvm.api.manager.settings;

import com.brocade.bvm.api.manager.generic.DeviceSettingManager;
import com.brocade.bvm.model.db.Device;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import java.util.List;

public class DeviceSettingManagerTest {

    @InjectMocks
    DeviceSettingManager deviceSettingManager;

    Device device;

    @Before
    public void setUp() throws Exception {
        device = new Device();
        device.setStablenetId(1l);
    }

    @Test
    public void deleteDevice() {
        List<Device> devices = Lists.newArrayList(device);
        //deviceSettingManager.deleteDevice(devices);
    }

    @Test
    public void addDevice() {
    }
}