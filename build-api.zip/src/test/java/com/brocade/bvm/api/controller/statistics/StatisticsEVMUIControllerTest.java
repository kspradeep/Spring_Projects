package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.statistics.StatisticsPolicyRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsSwitchRepository;
import com.brocade.bvm.model.db.statistics.EVMOverview;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class StatisticsEVMUIControllerTest {

    @InjectMocks
    StatisticsEVMUIController statisticsEVMUIController;

    private MockMvc mockMvc;

    @Mock
    private ManagedObjectAuthorityProvider authorityProvider;
    @Mock
    private StatisticsPortRepository statisticsPortRepository;
    @Mock
    private StatisticsSwitchRepository statisticsSwitchRepository;
    @Mock
    private StatisticsPolicyRepository statisticsPolicyRepository;

    @Before
    public void before() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsEVMUIController).build();
    }

    @Test
    public void itShouldReturnEVMOverview() throws Exception {
        EVMOverview evmOverview = new EVMOverview();
        given(statisticsSwitchRepository.findCountOfAllSLXDevices()).willReturn(1);
        given(statisticsSwitchRepository.findCountOfAllMLXEDevices()).willReturn(1);
        given(statisticsPortRepository.evmOverview()).willReturn(evmOverview);
        this.mockMvc.perform(get("/statistics/evm-overview"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalSLX", is(1)));
    }

}
