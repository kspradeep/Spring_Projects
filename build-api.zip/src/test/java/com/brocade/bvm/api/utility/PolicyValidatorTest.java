package com.brocade.bvm.api.utility;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PolicyValidatorTest {
//https://en.wikipedia.org/wiki/Multicast_address
    PolicyValidator policyValidator;

    @Before
    public void setup() {
        policyValidator = new PolicyValidator();
    }

    @Test
    public void testMultiCastMacAddress(){
        String[] multiCastMacAddress = {"01:00:0C:CC:CC:CC",
                "01:00:0C:CC:CC:CD",
                "01:80:C2:00:00:00",
                "01:80:C2:00:00:00",
                "01:80:C2:00:00:03",
                "01:80:C2:00:00:0E",
                "01:80:C2:00:00:08",
                "01:80:C2:00:00:01",
                "01:80:C2:00:00:02",
                "01:80:C2:00:00:30",
                "01:80:C2:00:00:3F",
                "01:00:5E:00:00:00",
                "01:00:5E:7F:FF:FF",
                "01:0C:CD:01:00:00",
                "01:0C:CD:01:01:FF",
                "01:0C:CD:02:00:00",
                "01:0C:CD:02:01:FF",
                "01:0C:CD:04:00:00",
                "01:0C:CD:04:01:FF",
                "01:1B:19:00:00:00",
                "33:33:19:22:22:33"};
        for(int i=0; i<multiCastMacAddress.length;i++){
            Assertions.assertThat(policyValidator.isMultiCastAddress(multiCastMacAddress[i])).isTrue();
        }
    }

    @Test
    public void testNotMultiCastMacAddress(){
        String[] notMultiCastAddress = {"EC:F4:BB:38:04:83","A0:A8:CD:7C:2E:05"};
        for(int i=0; i<notMultiCastAddress.length;i++){
            Assertions.assertThat(policyValidator.isMultiCastAddress(notMultiCastAddress[i])).isFalse();
        }
    }

}
