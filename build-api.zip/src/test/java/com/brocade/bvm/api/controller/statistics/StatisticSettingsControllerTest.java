package com.brocade.bvm.api.controller.statistics;

import com.brocade.bvm.dao.FeatureConstantsRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class StatisticSettingsControllerTest {
    @InjectMocks
    StatisticSettingsController statisticSettingsController;
    @Mock
    private FeatureConstantsRepository featureConstantsRepository;
    private MockMvc mockMvc;

    @Before
    public void before() {
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticSettingsController).build();
    }

    @Test
    public void itShouldSetThreshold() throws Exception {

        this.mockMvc.perform(post("/1/threshold"))
                .andExpect(status().isOk());
    }

    @Test(expected = NestedServletException.class)
    public void itShouldThrowExceptionIfthresholdIsLessThanZero() throws Exception {
        this.mockMvc.perform(post("/0.1/threshold"))
                .andExpect(status().isOk());
    }
}
