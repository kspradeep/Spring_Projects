package com.brocade.bvm.api.controller;

import com.brocade.bvm.api.factory.NonOpenFlowFactory;
import com.brocade.bvm.api.manager.ModulePolicyManager;
import com.brocade.bvm.api.manager.nonopenflow.LoadBalanceModulePolicyManagerNonOpenFlow;
import com.brocade.bvm.api.security.ManagedObjectAuthorityProvider;
import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UIControllerTest {

    @InjectMocks
    private UIController uiController;

    @Mock
    private PortGroupRepository portGroupRepository;

    @Mock
    private ManagedObjectAuthorityProvider managedObjectAuthorityProvider;

    @Mock
    private ModulePolicyRepository modulePolicyRepository;

    @Mock
    private PolicyRepository policyRepository;

    @Mock
    private DevicePolicyRepository devicePolicyRepository;

    @Mock
    private ManagerFactoryBuilder managerBuilder;

    @Mock
    private NonOpenFlowFactory nonOpenFlowOperationsFactory;

    @Mock
    private DeviceRepository deviceRepository;

    private Device device;

    @Mock
    private EventRepository eventRepository;

    @Before
    public void setup() throws NoSuchFieldException {

        ModulePolicyManager modulePolicyManager = new LoadBalanceModulePolicyManagerNonOpenFlow();

        device = new Device();
        device.setName("device1");
        Field idField = ManagedObject.class.getDeclaredField("id");
        ReflectionUtils.makeAccessible(idField);
        Field idFieldDevice = TargetHost.class.getDeclaredField("id");
        ReflectionUtils.makeAccessible(idFieldDevice);
        ReflectionUtils.setField(idFieldDevice, device, 1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setModel("model1");
        device.setStablenetId(1L);
        Module module = new Module();
        device.addModules(Sets.newHashSet(module));
        ReflectionUtils.setField(idField, module, 2L);
        module.setStablenetId(2L);
        module.setName("module1");
        Port port1 = new Port();
        ReflectionUtils.setField(idField, port1, 3L);
        port1.setName("ethernetport1");
        port1.setType(Port.Type.INGRESS);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setMode(Port.Mode.LAYER2);
        module.addPorts(Sets.newHashSet(port1));

        PortGroup portGroup1 = new PortGroup();
        ReflectionUtils.setField(idField, portGroup1, 5L);
        portGroup1.setPrimaryPort(port1);
        portGroup1.setPorts(Sets.newHashSet(port1));
        Field portGroupsField = Device.class.getDeclaredField("portGroups");
        ReflectionUtils.makeAccessible(portGroupsField);
        ReflectionUtils.setField(portGroupsField, device, Sets.newHashSet(portGroup1));

        List<Long> authorizedDevices = new ArrayList<>();
        authorizedDevices.add(device.getId());

        Job job = saveJob(device);
        Event event = saveEvent(job);

        when(eventRepository.findByStatusIn(Lists.newArrayList(Event.Status.NEW))).thenReturn(Lists.newArrayList(event));
        when(eventRepository.findManagedObjectNames(anyList())).thenReturn(Lists.newArrayList("112:TestPolicy", "113:10GigbitEthernet1/1"));

        when(portGroupRepository.findByPortId(anyLong())).thenReturn(5L);
        when(portGroupRepository.findOne(anyLong())).thenReturn(portGroup1);
        when(managedObjectAuthorityProvider.applyRBACOnDevice(any())).thenReturn(device);
        when(modulePolicyRepository.findByDeviceId(Matchers.anyLong())).thenReturn(prepareModulePolicyObject());
        when(policyRepository.findByDeviceIdAndCreatedFromSd(anyLong(), anyBoolean())).thenReturn(Collections.emptyList());
        when(managedObjectAuthorityProvider.applyRBACOnPolicies(anyObject(), anyLong())).thenReturn(Collections.emptySet());
        when(managedObjectAuthorityProvider.getAuthorizedDeviceIds()).thenReturn(authorizedDevices);
        when(managerBuilder.getOperationsFactory(device)).thenReturn(nonOpenFlowOperationsFactory);
        when(nonOpenFlowOperationsFactory.getModulePolicyManager(Matchers.any(ModulePolicy.class))).thenReturn(modulePolicyManager);
        when(deviceRepository.findOne(anyLong())).thenReturn(device);
    }

    private Event saveEvent(Job job) {
        Event event = new Event();
        event.setJob(job);
        event.setStatus(Event.Status.NEW);
        event.setId(100L);
        event.setLastUpdatedTime(Instant.now());
        return event;
    }

    private Job saveJob(Device device) {
        Job job = new Job();
        ReflectionTestUtils.setField(job, "id", 111L);
        job.setStatus(Job.Status.SUCCESS);
        job.setType(Job.Type.POLICY_CREATE);
        job.setParentObjectId(112L);
        job.setTargetHost(device);
        job.setImpactedObjectsIds(new HashSet<>(Collections.singletonList(113L)));
        return job;
    }

    private List<ModulePolicy> prepareModulePolicyObject() throws NoSuchFieldException {
        List<ModulePolicy> modulePolicies = new ArrayList<>();
        Set<Module> modules = device.getModules();
        //packet slicing
        PacketSlicingModulePolicy packetSlicingModulePolicy = new PacketSlicingModulePolicy();
        packetSlicingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        packetSlicingModulePolicy.setNumberOfBytes(1024);
        packetSlicingModulePolicy.setModules(modules);
        ReflectionTestUtils.setField(packetSlicingModulePolicy, "objectType", "packet_slicing_module_policy");
        //loadbalance policy
        LoadBalanceModulePolicy lpPolicy = new LoadBalanceModulePolicy();
        lpPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        lpPolicy.setTunnelingProtocol("tcp");
        lpPolicy.addModules(modules);
        ReflectionTestUtils.setField(lpPolicy, "objectType", "load_balance_module_policy");
        //header stripping
        HeaderStrippingModulePolicy headerStrippingModulePolicy = new HeaderStrippingModulePolicy();
        headerStrippingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        headerStrippingModulePolicy.setStripHeaders(new HashSet<>(Arrays.asList(HeaderStrippingModulePolicy.Headers.BR802)));
        headerStrippingModulePolicy.addModules(modules);
        ReflectionTestUtils.setField(headerStrippingModulePolicy, "objectType", "header_stripping_module_policy");
        //packet stamping
        PacketStampingModulePolicy packetStampingModulePolicy = new PacketStampingModulePolicy();
        packetStampingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        packetStampingModulePolicy.setProcessor(PacketStampingModulePolicy.ProcessorNumber.ONE);
        packetStampingModulePolicy.addModules(modules);
        ReflectionTestUtils.setField(packetStampingModulePolicy, "objectType", "packet_stamping_module_policy");
        modulePolicies.add(packetSlicingModulePolicy);
        modulePolicies.add(lpPolicy);
        modulePolicies.add(headerStrippingModulePolicy);
        modulePolicies.add(packetStampingModulePolicy);
        return modulePolicies;
    }

    @Test
    @Ignore
    public void getJson() throws JsonProcessingException {
        String portsJson = uiController.getJson(device);
        String expectedJson = "{\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null,\"moduleName\":\"module1\",\"moduleId\":2,\"portGroupName\":null}],\"portGroups\":[{\"id\":5,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"primaryPort\":{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null},\"gtpProfile\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}],\"type\":\"INGRESS\"}]}";
        String expectedJson1 = "{\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portDescription\":null,\"portNumber\":\"port1\",\"moduleName\":\"module1\",\"moduleId\":2,\"portGroupName\":null}],\"portGroups\":[{\"id\":5,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"primaryPort\":{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portDescription\":null,\"portNumber\":\"port1\"},\"gtpProfile\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portDescription\":null,\"portNumber\":\"port1\"}],\"type\":\"INGRESS\"}]}";
        assertThat(portsJson).isIn(expectedJson, expectedJson1);
    }

    @Ignore
    @Test
    public void testGetAllTypesOfPoliciesByDeviceId() throws JsonProcessingException {
        ResponseEntity<Object> response = uiController.getAllTypesOfPoliciesByDeviceId(device.getId(), "false");
        assertThat(response.getBody()).isNotNull();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        String jsonRequest = mapper.writeValueAsString(response);
        String expectedJson = "{\"headers\":{},\"body\":{\"packetStampingModulePolicies\":[{\"id\":null,\"name\":null,\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"processor\":\"ONE\"}],\"loadBalanceModulePolicies\":[{\"id\":null,\"name\":null,\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"isSourceIpIncluded\":false,\"isSourcePortIncluded\":false,\"isDestinationIpIncluded\":false,\"isDestinationPortIncluded\":false,\"isTeIdIncluded\":false,\"isInnerIpIncluded\":false,\"isProtocolMaskIncluded\":false,\"isBiDirectional\":false,\"tunnelingProtocol\":\"tcp\",\"teIdIncluded\":false,\"biDirectional\":false,\"destinationIpIncluded\":false,\"destinationPortIncluded\":false,\"innerIpIncluded\":false,\"protocolMaskIncluded\":false,\"sourceIpIncluded\":false,\"sourcePortIncluded\":false}],\"sdDevicePolicies\":{\"sdImsiPolicies\":[{\"id\":null,\"name\":\"sdImsiPolicy\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"device\":{\"id\":1,\"name\":\"device1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":\"MLXE\",\"mode\":\"PLAIN\",\"model\":\"model1\",\"os\":null,\"ipAddress\":null,\"description\":null,\"lastCollectedTime\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"portGroups\":[{\"id\":5,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"primaryPort\":{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null},\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}],\"type\":\"INGRESS\"}],\"deleted\":false},\"dropRate\":10,\"sampling\":true}],\"sdFilterPolicies\":[{\"id\":null,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"device\":null,\"sdRuleSets\":[{\"id\":null,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"sequence\":1,\"sdRules\":[{\"id\":null,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"sequence\":1,\"priority\":3,\"apn\":\"abcd.com\",\"apnIncludeAll\":false,\"imsi\":\"123434456778896\",\"imsiRange\":4,\"qci\":3,\"permit\":false,\"vlanId\":200}]}],\"sequence\":null}],\"sdDedupePolicies\":[{\"id\":null,\"name\":\"sdDedupePolicy\",\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"device\":{\"id\":1,\"name\":\"device1\",\"workflowStatus\":null,\"workflowType\":null,\"type\":\"MLXE\",\"mode\":\"PLAIN\",\"model\":\"model1\",\"os\":null,\"ipAddress\":null,\"description\":null,\"lastCollectedTime\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"portGroups\":[{\"id\":5,\"name\":null,\"workflowStatus\":null,\"workflowType\":null,\"primaryPort\":{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null},\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}],\"type\":\"INGRESS\"}],\"deleted\":false},\"timeout\":100,\"dedupe\":false}]},\"policies\":[],\"headerStrippingModulePolicies\":[{\"id\":null,\"name\":null,\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"headers\":[\"BR802\",\"VNTAG\"]}],\"packetSlicingModulePolicies\":[{\"id\":null,\"name\":null,\"workflowStatus\":\"ACTIVE\",\"workflowType\":null,\"modules\":[{\"id\":2,\"name\":\"module1\",\"workflowStatus\":null,\"workflowType\":null,\"ports\":[{\"id\":3,\"name\":\"ethernetport1\",\"workflowStatus\":null,\"workflowType\":null,\"physicalAddress\":null,\"linkStatus\":null,\"type\":\"INGRESS\",\"mode\":\"LAYER2\",\"adminStatus\":\"ENABLED\",\"portNumber\":\"port1\",\"portDescription\":null}]}],\"numberOfBytes\":1024,\"ports\":[]}]},\"statusCode\":\"OK\"}";
        assertThat(jsonRequest).isNotNull();
    }


    @Test
    public void testGetEvents() throws JsonProcessingException {
        ResponseEntity<Object> response = uiController.getEvents();
        assertThat(response.getBody()).isNotNull();
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule simpleModule = new SimpleModule();
        String jsonRequest = mapper.writeValueAsString(response);
        assertThat(jsonRequest).isNotNull();
        System.out.println(jsonRequest);
    }

}