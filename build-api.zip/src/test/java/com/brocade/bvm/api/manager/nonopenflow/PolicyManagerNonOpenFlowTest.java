package com.brocade.bvm.api.manager.nonopenflow;

import com.brocade.bvm.api.manager.openflow.PolicyManagerOpenFlow;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

/**
 * Created by dneelapa on 6/23/2016.
 */
@RunWith(MockitoJUnitRunner.class)
public class PolicyManagerNonOpenFlowTest {
    @InjectMocks
    private PolicyManagerNonOpenFlow policyManagerNonOpenFlow;

    @InjectMocks
    private PolicyManagerOpenFlow policyManagerOpenFlow;

    private Policy newPolicy;

    @Mock
    protected PolicyRepository policyRepository;

    @Mock
    private DeviceRepository deviceRepository;

    private static final String INVALID_IPV6 = "1111:2222:3333:4444:5555:6666:7777:8888:9999,1111:2222:3333:4444:5555:6666:7777:8888::,::2222:3333:4444:5555:6666:7777:8888:9999,1111:2222:3333:4444:5555:6666:7777,1111:2222:3333:4444:5555:6666,1111:2222:3333:4444:5555,1111:2222:3333:4444,1111:2222:3333,1111:2222,1111,11112222:3333:4444:5555:6666:7777:8888,1111:22223333:4444:5555:6666:7777:8888,1111:2222:33334444:5555:6666:7777:8888,1111:2222:3333:44445555:6666:7777:8888,1111:2222:3333:4444:55556666:7777:8888,1111:2222:3333:4444:5555:66667777:8888,1111:2222:3333:4444:5555:6666:77778888,1111:2222:3333:4444:5555:6666:7777:8888:,1111:2222:3333:4444:5555:6666:7777:,1111:2222:3333:4444:5555:6666:,1111:2222:3333:4444:5555:,1111:2222:3333:4444:,1111:2222:3333:,1111:2222:,1111:,:,:8888,:7777:8888,:6666:7777:8888,:5555:6666:7777:8888,:4444:5555:6666:7777:8888,:3333:4444:5555:6666:7777:8888,:2222:3333:4444:5555:6666:7777:8888,:1111:2222:3333:4444:5555:6666:7777:8888," +
            ":::2222:3333:4444:5555:6666:7777:8888,1111:::3333:4444:5555:6666:7777:8888,1111:2222:::4444:5555:6666:7777:8888,1111:2222:3333:::5555:6666:7777:8888,1111:2222:3333:4444:::6666:7777:8888,1111:2222:3333:4444:5555:::7777:8888,1111:2222:3333:4444:5555:6666:::8888,1111:2222:3333:4444:5555:6666:7777:::,::2222::4444:5555:6666:7777:8888,::2222:3333::5555:6666:7777:8888,::2222:3333:4444::6666:7777:8888,::2222:3333:4444:5555::7777:8888,::2222:3333:4444:5555:7777::8888,::2222:3333:4444:5555:7777:8888::,1111::3333::5555:6666:7777:8888,1111::3333:4444::6666:7777:8888,1111::3333:4444:5555::7777:8888,1111::3333:4444:5555:6666::8888,1111::3333:4444:5555:6666:7777::,1111:2222::4444::6666:7777:8888," +
            "1111:2222::4444:5555::7777:8888,1111:2222::4444:5555:6666::8888,1111:2222::4444:5555:6666:7777::,1111:2222:3333::5555::7777:8888,1111:2222:3333::5555:6666::8888,1111:2222:3333::5555:6666:7777::,1111:2222:3333:4444::6666::8888,1111:2222:3333:4444::6666:7777::,1111:2222:3333:4444:5555::7777::,1111:2222:3333:4444:5555:6666:7777:8888:1.2.3.4,1111:2222:3333:4444:5555:6666:7777:1.2.3.4,1111:2222:3333:4444:5555:6666::1.2.3.4,::2222:3333:4444:5555:6666:7777:1.2.3.4,1111:2222:3333:4444:5555:6666:1.2.3.4.5,1111:2222:3333:4444:5555:1.2.3.4,1111:2222:3333:4444:1.2.3.4,1111:2222:3333:1.2.3.4,1111:2222:1.2.3.4,1111:1.2.3.4,1.2.3.4,11112222:3333:4444:5555:6666:1.2.3.4,1111:22223333:4444:5555:6666:1.2.3.4,1111:2222:33334444:5555:6666:1.2.3.4,1111:2222:3333:44445555:6666:1.2.3.4,1111:2222:3333:4444:55556666:1.2.3.4,1111:2222:3333:4444:5555:66661.2.3.4,1111:2222:3333:4444:5555:6666:255255.255.255,1111:2222:3333:4444:5555:6666:255.255255.255,1111:2222:3333:4444:5555:6666:255.255.255255,:1.2.3.4,:6666:1.2.3.4,:5555:6666:1.2.3.4,:4444:5555:6666:1.2.3.4,:3333:4444:5555:6666:1.2.3.4,:2222:3333:4444:5555:6666:1.2.3.4,:1111:2222:3333:4444:5555:6666:1.2.3.4," +
            ":::2222:3333:4444:5555:6666:1.2.3.4,1111:::3333:4444:5555:6666:1.2.3.4,1111:2222:::4444:5555:6666:1.2.3.4,1111:2222:3333:::5555:6666:1.2.3.4,1111:2222:3333:4444:::6666:1.2.3.4,1111:2222:3333:4444:5555:::1.2.3.4,::2222::4444:5555:6666:1.2.3.4,::2222:3333::5555:6666:1.2.3.4,::2222:3333:4444::6666:1.2.3.4,::2222:3333:4444:5555::1.2.3.4,1111::3333::5555:6666:1.2.3.4,1111::3333:4444::6666:1.2.3.4,1111::3333:4444:5555::1.2.3.4,1111:2222::4444::6666:1.2.3.4,1111:2222::4444:5555::1.2.3.4,1111:2222:3333::5555::1.2.3.4,::.,::..,::...,::1...,::1.2..,::1.2.3.,::.2..,::.2.3.,::.2.3.4,::..3.,::..3.4,::...4,:1111:2222:3333:4444:5555:6666:7777::,:1111:2222:3333:4444:5555:6666::,:1111:2222:3333:4444:5555::,:1111:2222:3333:4444::,:1111:2222:3333::,:1111:2222::,:1111::,:::,:1111:2222:3333:4444:5555:6666::8888,:1111:2222:3333:4444:5555::8888,:1111:2222:3333:4444::8888,:1111:2222:3333::8888,:1111:2222::8888,:1111::8888,:::8888,:1111:2222:3333:4444:5555::7777:8888,:1111:2222:3333:4444::7777:8888,:1111:2222:3333::7777:8888,:1111:2222::7777:8888,:1111::7777:8888,:::7777:8888,:1111:2222:3333:4444::6666:7777:8888,:1111:2222:3333::6666:7777:8888,:1111:2222::6666:7777:8888,:1111::6666:7777:8888,:::6666:7777:8888,:1111:2222:3333::5555:6666:7777:8888,:1111:2222::5555:6666:7777:8888,:1111::5555:6666:7777:8888,:::5555:6666:7777:8888,:1111:2222::4444:5555:6666:7777:8888,:1111::4444:5555:6666:7777:8888,:::4444:5555:6666:7777:8888,:1111::3333:4444:5555:6666:7777:8888,:::3333:4444:5555:6666:7777:8888,:::2222:3333:4444:5555:6666:7777:8888,:1111:2222:3333:4444:5555:6666:1.2.3.4,:1111:2222:3333:4444:5555::1.2.3.4,:1111:2222:3333:4444::1.2.3.4,:1111:2222:3333::1.2.3.4,:1111:2222::1.2.3.4,:1111::1.2.3.4,:::1.2.3.4,:1111:2222:3333:4444::6666:1.2.3.4,:1111:2222:3333::6666:1.2.3.4,:1111:2222::6666:1.2.3.4,:1111::6666:1.2.3.4,:::6666:1.2.3.4,:1111:2222:3333::5555:6666:1.2.3.4,:1111:2222::5555:6666:1.2.3.4,:1111::5555:6666:1.2.3.4,:::5555:6666:1.2.3.4,:1111:2222::4444:5555:6666:1.2.3.4,:1111::4444:5555:6666:1.2.3.4,:::4444:5555:6666:1.2.3.4,:1111::3333:4444:5555:6666:1.2.3.4,:::2222:3333:4444:5555:6666:1.2.3.4,1111:2222:3333:4444:5555:6666:7777:::,1111:2222:3333:4444:5555:6666:::,1111:2222:3333:4444:5555:::,1111:2222:3333:4444:::,1111:2222:3333:::,1111:2222:::,1111:::,:::,1111:2222:3333:4444:5555:6666::8888:,1111:2222:3333:4444:5555::8888:,1111:2222:3333:4444::8888:,1111:2222:3333::8888:,1111:2222::8888:,1111::8888:,::8888:,1111:2222:3333:4444:5555::7777:8888:,1111:2222:3333:4444::7777:8888:,1111:2222:3333::7777:8888:,1111:2222::7777:8888:,1111::7777:8888:,::7777:8888:,1111:2222:3333:4444::6666:7777:8888:,1111:2222:3333::6666:7777:8888:,1111:2222::6666:7777:8888:,1111::6666:7777:8888:,::6666:7777:8888:,1111:2222:3333::5555:6666:7777:8888:,1111:2222::5555:6666:7777:8888:,1111::5555:6666:7777:8888:,::5555:6666:7777:8888:,1111:2222::4444:5555:6666:7777:8888:,1111::4444:5555:6666:7777:8888:,::4444:5555:6666:7777:8888:,1111::3333:4444:5555:6666:7777:8888:,::3333:4444:5555:6666:7777:8888:,::2222:3333:4444:5555:6666:7777:8888:,02001:0000:1234:0000:0000:C1C0:ABCD:0876,2001:0000:1234:0000:00001:C1C0:ABCD:0876,2001:0000:1234: 0000:0000:C1C0:ABCD:0876,3ffe:0b00:0000:0001:0000:0000:000a,FF02:0000:0000:0000:0000:0000:0000:0000:0001,3ffe:b00::1::a,::1111:2222:3333:4444:5555:6666::,1::5:400.2.3.4,1::5:260.2.3.4,1::5:256.2.3.4,1::5:1.256.3.4,1::5:1.2.256.4,1::5:1.2.3.256,1::5:300.2.3.4,1::5:1.300.3.4,1::5:1.2.300.4,1::5:1.2.3.300,1::5:900.2.3.4,1::5:1.900.3.4,1::5:1.2.900.4,1::5:1.2.3.900,1::5:300.300.300.300,1::5:3000.30.30.30,1::400.2.3.4,1::260.2.3.4,1::256.2.3.4,1::1.256.3.4,1::.2.256.4,1::1.2.3.256,1::300.2.3.4,1::1.300.3.4,1::1.2.300.4,1::1.2.3.300,1::900.2.3.4,1::1.900.3.4,1::1.2.900.4,1::1.2.3.900,1::300.300.300.300,1::3000.30.30.30,::400.2.3.4,::260.2.3.4,::256.2.3.4,::1.256.3.4,::1.2.256.4,::1.2.3.256,::00.2.3.4,::1.300.3.4,::1.2.300.4,::1.2.3.300,::900.2.3.4,::1.900.3.4,::1.2.900.4,::1.2.3.900,::300.300.300.300,::3000.30.30.30,2001:1:1:1:1:1:255Z255X255Y255,::ffff:192x168.1.26,::ffff:2.3.4,::ffff:257.1.2.3,1.2.3.4,1.2.3.4:1111:222:3333:4444::5555,1.2.3.4:1111:2222:3333::5555,1.2.3.4:1111:2222::5555,1.2.3.4:1111::5555,1.2.3.4::5555,1.2.3.4::,fe80:0000:0000:0000:0204:61ff:254.157.241.086,XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:1.2.3.4,1111:2222:3333:444:5555:6666:00.00.00.00,1111:2222:3333:4444:5555:6666:000.000.000.000,1111:2222:3333:4444:5555:6666:256.256.256.256,1111:2222:3333:4444::5555:,1111:2222:3333::5555:,1111:2222::5555:,1111::5555:,::5555:,:::,1111:,:,:1111:2222:3333:444::5555,:1111:2222:3333::5555,:1111:2222::5555,:1111::5555,:::5555,:::,123,ldkfj,2001::FFD3::57ab,2001:db8:85a3::8a2e:37023:7334,2001:db8:85a3::8a2e:370k:7334,1:2:3:4:5:6:7:8:9,1::2::3,1:::3:4:5,1:2:3::4:5:6:7:8:9,2001:0000:1234:0000:0000:C1C0:ABCD:0876  0";

    private static final String VALID_IPV6 = "::1,::,0:0:0:0:0:0:0:1,0:0:0:0:0:0:0:0,2001:DB8:0:0:8:800:200C:417A,FF01:0:0:0:0:0:0:101,2001:DB8::8:800:200C:417A,FF01::101,fe80::217:f2ff:fe07:ed62,2001:0000:1234:0000:0000:C1C0:ABCD:0876,3ffe:0b00:0000:0000:0001:0000:0000:000a,FF02:0000:0000:0000:0000:0000:0000:0001,0000:0000:0000:0000:0000:0000:0000:0001,0000:0000:0000:0000:0000:0000:0000:0000,2::10,ff02::1,fe80::,2002::,2001:db8::,2001:0db8:1234::,::ffff:0:0,::1,1:2:3:4:5:6:7:8,1:2:3:4:5:6::8,1:2:3:4:5::8,1:2:3:4::8,1:2:3::8,1:2::8,1::8,1::2:3:4:5:6:7,1::2:3:4:5:6,1::2:3:4:5,1::2:3:4,1::2:3,1::8,::2:3:4:5:6:7:8,::2:3:4:5:6:7,::2:3:4:5:6,::2:3:4:5,::2:3:4,::2:3,::8,1:2:3:4:5:6::,1:2:3:4:5::,1:2:3:4::,1:2:3::,1:2::,1::,1:2:3:4:5::7:8,1:2:3:4::7:8,1:2:3::7:8,1:2::7:8,1::7:8,1:2:3:4:5:6:1.2.3.4,1:2:3:4:5::1.2.3.4,1:2:3:4::1.2.3.4,1:2:3::1.2.3.4,1:2::1.2.3.4,1::1.2.3.4,1:2:3:4::5:1.2.3.4,1:2:3::5:1.2.3.4,1:2::5:1.2.3.4,1::5:1.2.3.4,1::5:11.22.33.44,fe80::217:f2ff:254.7.237.98,::ffff:192.168.1.26,::ffff:192.168.1.1,0:0:0:0:0:0:13.1.68.3,0:0:0:0:0:FFFF:129.144.52.38,::13.1.68.3,::FFFF:129.144.52.38,fe80:0:0:0:204:61ff:254.157.241.86,fe80::204:61ff:254.157.241.86,::ffff:12.34.56.78,::ffff:192.0.2.128,fe80:0000:0000:0000:0204:61ff:fe9d:f156,fe80:0:0:0:204:61ff:fe9d:f156,fe80::204:61ff:fe9d:f156,::1,fe80::,fe80::1,::ffff:c000:280,2001:0db8:85a3:0000:0000:8a2e:0370:7334,2001:db8:85a3:0:0:8a2e:370:7334,2001:db8:85a3::8a2e:370:7334,2001:0db8:0000:0000:0000:0000:1428:57ab,2001:0db8:0000:0000:0000::1428:57ab,2001:0db8:0:0:0:0:1428:57ab,2001:0db8:0:0::1428:57ab,2001:0db8::1428:57ab,2001:db8::1428:57ab,0000:0000:0000:0000:0000:0000:0000:0001,::1,::ffff:0c22:384e,2001:0db8:1234:0000:0000:0000:0000:0000,2001:0db8:1234:ffff:ffff:ffff:ffff:ffff,2001:db8:a::123,fe80::,1111:2222:3333:4444:5555:6666:7777:8888,1111:2222:3333:4444:5555:6666:7777::,1111:2222:3333:4444:5555:6666::,1111:2222:3333:4444:5555::,1111:2222:3333:4444::,1111:2222:3333::,1111:2222::,1111::,::,1111:2222:3333:4444:5555:6666::8888,1111:2222:3333:4444:5555::8888," +
            "1111:2222:3333:4444::8888,1111:2222:3333::8888,1111:2222::8888,1111::8888,::8888,1111:2222:3333:4444:5555::7777:8888,1111:2222:3333:4444::7777:8888,1111:2222:3333::7777:8888,1111:2222::7777:8888,1111::7777:8888,::7777:8888,1111:2222:3333:4444::6666:7777:8888,1111:2222:3333::6666:7777:8888,1111:2222::6666:7777:8888,1111::6666:7777:8888,::6666:7777:8888,1111:2222:3333::5555:6666:7777:8888,1111:2222::5555:6666:7777:8888,1111::5555:6666:7777:8888,::5555:6666:7777:8888,1111:2222::4444:5555:6666:7777:8888,1111::4444:5555:6666:7777:8888,::4444:5555:6666:7777:8888,1111::3333:4444:5555:6666:7777:8888,::3333:4444:5555:6666:7777:8888,::2222:3333:4444:5555:6666:7777:8888,1111:2222:3333:4444:5555:6666:123.123.123.123,1111:2222:3333:4444:5555::123.123.123.123,1111:2222:3333:4444::123.123.123.123,1111:2222:3333::123.123.123.123,1111:2222::123.123.123.123,1111::123.123.123.123,::123.123.123.123,1111:2222:3333:4444::6666:123.123.123.123,1111:2222:3333::6666:123.123.123.123,1111:2222::6666:123.123.123.123,1111::6666:123.123.123.123,::6666:123.123.123.123,1111:2222:3333::5555:6666:123.123.123.123,1111:2222::5555:6666:123.123.123.123,1111::5555:6666:123.123.123.123,::5555:6666:123.123.123.123,1111:2222::4444:5555:6666:123.123.123.123,1111::4444:5555:6666:123.123.123.123,::4444:5555:6666:123.123.123.123,1111::3333:4444:5555:6666:123.123.123.123,::2222:3333:4444:5555:6666:123.123.123.123,::0:0:0:0:0:0:0,::0:0:0:0:0:0,::0:0:0:0:0,::0:0:0:0,::0:0:0,::0:0,::0,0:0:0:0:0:0:0::,0:0:0:0:0:0::,0:0:0:0:0::,0:0:0:0::,0:0:0::,0:0::,0::,::ffff:192.0.2.128";

    @Before
    public void setUp() throws Exception {
        newPolicy = new Policy();
        newPolicy.setName("Test_Policy");
        // Should get computed from policy set parameter
        Device device = new Device();
        device.setName("NetIron");
        device.setType(Device.Type.MLXE);
        newPolicy.setDevice(device);

        newPolicy.setFieldOffset1(0L);
        newPolicy.setFieldOffset2(4L);
        newPolicy.setFieldOffset3(8L);
        newPolicy.setFieldOffset4(12L);

        Port ingress = new Port();
        ingress.setName("10GigabitEthernet1/1");
        ingress.setType(Port.Type.INGRESS);

        Set<Port> ingresses = new LinkedHashSet<>();
        ingresses.add(ingress);

        Flow flow = new Flow();
        ReflectionTestUtils.setField(flow, "id", 1L);
        flow.setIngressPorts(ingresses);
        flow.setSequence(1);

        Set<Port> egressPorts = new LinkedHashSet<>();

        Port egress1 = new Port();
        egress1.setName("10GigabitEthernet2/1");
        egress1.setType(Port.Type.EGRESS);

        egressPorts.add(egress1);

        Module module = new Module();
        device.addModules(Sets.newHashSet(module));
        module.addPorts(Sets.newHashSet(ingress));

        flow.addEgressPorts(egressPorts);

        SortedSet<Flow> flows = new TreeSet<>();
        flows.add(flow);

        newPolicy.addFlows(flows);

        RuleSet ruleSet = new RuleSet();
        ruleSet.setType(RuleSet.Type.UDA);
        ruleSet.setSequence(1);
        ruleSet.setName("acl_uda_for_" + newPolicy.getComputedName() + "_" + flow.getSequence());

        Rule rule = new Rule();
        rule.setIsPermit(true);

        rule.setFieldValue1("aabbccdd");
        rule.setFieldValue2("eeff0000");
        rule.setFieldValue3("08000000");
        rule.setFieldValue4("0a0a");

        rule.setFieldmask1("ffffffff");
        rule.setFieldmask2("ffff0000");
        rule.setFieldmask3("ffff0000");
        rule.setFieldmask4("ffff");

        rule.setVlanId(-1);
        rule.setSequence(1l);

        SortedSet<Rule> rules = new TreeSet<>();
        rules.add(rule);
        ruleSet.setRules(rules);

        // wiring ruleset
        SortedSet<RuleSet> ruleSetList = new TreeSet<>();
        ruleSetList.add(ruleSet);

        // wiring policy
        flow.setRuleSets(ruleSetList);

        Set<String> vlans = new HashSet<>();
        vlans.add("400");
        flow.addVlan(vlans);
        flow.setIsTagged(true);

        when(policyRepository.findOne(anyLong())).thenReturn(newPolicy);
        when(deviceRepository.findOne(anyLong())).thenReturn(device);
    }

    @Test
    public void testIsValidRuleSetTypes() {
        boolean flag = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "isValidForUda", newPolicy);
        Assertions.assertThat(flag).isEqualTo(true);
    }

    @Test
    public void testIsOffsetValuesValid() {
        boolean flag = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "isOffsetValuesValid", newPolicy);
        Assertions.assertThat(flag).isEqualTo(true);
    }

    @Test
    public void testIsValidRulesForUda() {
        boolean flag = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "isValidRulesForUda", newPolicy);
        Assertions.assertThat(flag).isEqualTo(true);
    }

    @Test
    public void testIsValidMac() {
        boolean flag = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateMacAddress", "609C.9F58.7909");
        Assertions.assertThat(flag).isEqualTo(true);
    }

    @Test
    public void testIpv4WithSubnetMaskPositiveCase() {
        String ip = "10.254.20.0/24";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv4", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv4WithSubnetMaskNegativeCase1() {
        String ip = "10.254.20.0/-1";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv4", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv4WithSubnetMaskNegativeCase2() {
        String ip = "10.254.20.0/33";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv4", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv4WithoutSubnetMaskPositiveCase() {
        String ip = "10.254.20.10";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv4", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv4WithoutSubnetMaskNegativeCase1() {
        String ip = "10.254.20.256";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv4", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6ShortPositiveCase() {
        String ip = "::/128";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv6ShortNegativeCase() {
        String ip = "1200::AB00:1234::2552:7777:1313";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6LongPositiveCase() {
        String ip = "21DA:D3:0:2F3B:2AA:FF:FE28:9C5A";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv6LongNegativeCase() {
        String ip = "1200:0000:AB00:1234:O000:2552:7777:1313";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6LongNegativeCase1() {
        String ip = "1111:2222:3333:4444:5555:6666:7777:8888:9999";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6LongNegativeCase2() {
        String ip = "02001:0000:1234:0000:0000:C1C0:ABCD:0876";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6LongPositiveCase1() {
        String ip = "2001:4888:2012:3000::/52";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv6LongPositiveCase2() {
        String ip = "2001:0000:6dcd:8c74:76cc:63bf:ac32:6a1/64";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv6LongPositiveCase3() {
        String ip = "2001:0db8:85a3:0000:0000:8a2e:0370:7334";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(true);
    }

    @Test
    public void testIpv6LongNegativeCase3() {
        String ip = "02001:0000:6dcd:8c74:76cc:63bf:ac32:6a1/64";
        boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
        Assertions.assertThat(result).isEqualTo(false);
    }

    @Test
    public void testIpv6Valid() {
        String ipV6[] = VALID_IPV6.split(",");
        for (String ip : ipV6) {
            boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
            Assertions.assertThat(result).isEqualTo(true);
        }
    }

    @Test
    public void testIpv6InValid() {
        String ipV6[] = INVALID_IPV6.split(",");
        for (String ip : ipV6) {
            boolean result = ReflectionTestUtils.invokeMethod(policyManagerNonOpenFlow, "validateIpv6", ip);
            Assertions.assertThat(result).isEqualTo(false);
        }
    }
}
