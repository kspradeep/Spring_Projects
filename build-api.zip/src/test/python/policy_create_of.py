import json, urllib2, base64

ps = {"device":{"id":58},"name":"testl23", "flows":[{"sequence": 1000, "ingressPorts": [{"id": 84}], "ingressPortGroups": [], "egressPortGroups": [], "egressPorts": [{"id": 93}], "vlans": [], "tagged": "false", "ruleSets":[{"ipVersion":"V4","type":"L23","sequence":1}]}]}

rules = []
for i in range(1025, 3025):
    rule = {"sourceIp":"any","destinationIp":"any", "protocolType":"tcp","sourcePortOperator":"eq","destinationPort":"" + str(i),"destinationPortOperator":"eq","protocol":"tcp","permit":"true","ethType":"ipv4","vlanId":"1","sequence":str(i)}
    rules.append(rule)

ruleSet0 = ps["flows"][0]["ruleSets"][0]
ruleSet0.update({"rules": rules})
ps_json = json.dumps(ps, indent=4, separators=(',', ': '))
print(ps_json)

#curl -uinfosim:stablenet --insecure --header "Content-Type: application/json" -X POST --data ps_json https://10.37.130.22:9285/bvm/api/policy?action=commit
url = 'https://10.37.130.22:9285/bvm/api/policy?action=commit'
req = urllib2.Request(url, json.dumps(ps), {'Content-Type': 'application/json'})
base64string = base64.b64encode('%s:%s' % ('infosim', 'stablenet'))
req.add_header("Authorization", "Basic %s" % base64string)
f = urllib2.urlopen(req)
for x in f:
    print(x)
f.close()