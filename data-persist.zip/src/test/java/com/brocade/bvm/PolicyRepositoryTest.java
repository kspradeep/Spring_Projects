package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PolicyHistoryRepository;
import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static org.assertj.core.api.StrictAssertions.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class PolicyRepositoryTest {

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHisotryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    private static boolean isSetupDone;

    private static Long deviceId;

    @Before
    public void setup() {
        if (!isSetupDone) {
            Device device = saveDevice();
            Policy policy1 = savePolicy(device, "Policy1", WorkflowParticipant.WorkflowStatus.DRAFT);
            isSetupDone = true;
            deviceId = device.getId();
        }

    }

    private Policy savePolicy(Device device, String policyName, WorkflowParticipant.WorkflowStatus workflowStatus) {
        Policy policyToSave = new Policy();
        policyToSave.setName(policyName);

        policyToSave.setFlows(getFlows(device));

        policyToSave.setWorkflowStatus(workflowStatus);
        policyToSave.setFieldOffset1(0L);
        policyToSave.setFieldOffset2(4L);
        policyToSave.setFieldOffset3(8L);
        policyToSave.setFieldOffset4(12L);
        policyToSave = policyRepository.save(policyToSave);

        Policy policy = policyRepository.findOne(policyToSave.getId());
        policy.setDevice(deviceRepository.findById(1L));
        policy.setFieldOffset1(0L);
        policy.setFieldOffset2(4L);
        policy.setFieldOffset3(8L);
        policy.setFieldOffset4(12L);
        policy = policyRepository.save(policy);
        return policy;
    }

    private static SortedSet<Flow> getFlows(Device device) {
        Flow flow = new Flow();
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> egressPorts = new HashSet<>();

        List<Port> ingressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType()==Port.Type.INGRESS).collect(Collectors.toList());
        List<Port> egressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType()==Port.Type.EGRESS).collect(Collectors.toList());

        ingressPorts.add(ingressList.get(0));
        egressPorts.add(egressList.get(0));

        flow.addIngressPorts(ingressPorts);
        flow.addEgressPorts(egressPorts);
        flow.setSequence(1);
        flow.setRuleSets(getRuleSets());

        Flow flow1 = new Flow();
        Set<Port> ingressPorts1 = new HashSet<>();
        Set<Port> egressPorts1 = new HashSet<>();

        ingressPorts1.add(ingressList.get(1));
        egressPorts1.add(egressList.get(1));

        flow1.addIngressPorts(ingressPorts1);
        flow1.addEgressPorts(egressPorts1);
        flow1.setSequence(2);

        SortedSet<Flow> flows = new TreeSet<>();
        flows.add(flow);
        flows.add(flow1);
        return flows;
    }

    private static SortedSet<RuleSet> getRuleSets() {
        RuleSet ruleSet = new RuleSet();
        ruleSet.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet.setType(RuleSet.Type.L2);
        ruleSet.setSequence(0);
        ruleSet.addRules(getRules());

        RuleSet ruleSet1 = new RuleSet();
        ruleSet1.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet1.setType(RuleSet.Type.L2);
        ruleSet1.setSequence(1);
        ruleSet1.addRules(getRules());

        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        ruleSets.add(ruleSet);
        ruleSets.add(ruleSet1);
        return ruleSets;
    }

    private static SortedSet<Rule> getRules() {
        Rule rule = new Rule();
        rule.setSequence(10l);

        Rule rule1 = new Rule();
        rule1.setSequence(6l);

        Rule rule2 = new Rule();
        rule2.setSequence(27l);

        Rule rule3 = new Rule();
        rule3.setSequence(99l);

        // wiring rules
        SortedSet<Rule> ruleSet = new TreeSet<>();
        ruleSet.add(rule);
        ruleSet.add(rule1);
        ruleSet.add(rule2);
        ruleSet.add(rule3);

        return ruleSet;
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        port4.setStablenetIndex(100L);
        port3.setStablenetIndex(101L);
        port2.setStablenetIndex(102L);
        port1.setStablenetIndex(103L);
        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        device.addModules(Sets.newHashSet(module));
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    public void testPolicyGetWithSingleIngressAndSingleEgresss() {
        List<Policy> policies = (List<Policy>) policyRepository.findAll();
        Policy policy = policies.get(0);
        assertThat(policy).isNotNull();
        assertThat(policy.getDevice()).isNotNull();
        assertThat(policy.getName()).isNotEmpty();
        assertThat(policy.getFlows().size()).isEqualTo(2);
        assertThat(policy.getFlows().stream().findFirst().get().getSequence()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getEgressPorts().size()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getIngressPorts().size()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getRuleSets().size()).isEqualTo(2);
        assertThat(policy.getFlows().stream().findFirst().get().getRuleSets().stream().findFirst().get().getRules().size()).isEqualTo(4);
    }

    @Test
    public void testFindByDeviceId() {
        List<Policy> policies = (List<Policy>) policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policy = policies.get(0);
        assertThat(policy).isNotNull();
        assertThat(policy.getDevice()).isNotNull();
        assertThat(policy.getName()).isNotEmpty();
        assertThat(policy.getFlows().size()).isEqualTo(2);
        assertThat(policy.getFlows().stream().findFirst().get().getSequence()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getEgressPorts().size()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getIngressPorts().size()).isEqualTo(1);
        assertThat(policy.getFlows().stream().findFirst().get().getRuleSets().size()).isEqualTo(2);
        assertThat(policy.getFlows().stream().findFirst().get().getRuleSets().stream().findFirst().get().getRules().size()).isEqualTo(4);
    }

    @Test
    public void testSortFlows() {
        List<Policy> policies = (List<Policy>) policyRepository.findAll();
        Policy policy = policies.get(0);
        List<Integer> actSeqOrder = policy.getFlows().stream().map(Flow::getSequence).collect(Collectors.toList());
        Assertions.assertThat(actSeqOrder).isSorted();
    }

    @Test
    public void testSortRuleSets() {
        List<Policy> policies = (List<Policy>) policyRepository.findAll();
        Policy policy = policies.get(0);
        List<Integer> actSeqOrder = policy.getFlows().stream().findFirst().get().getRuleSets().stream().map(RuleSet::getSequence).collect(Collectors.toList());
        Assertions.assertThat(actSeqOrder).isSorted();
    }

    @Test
    public void testSortRules() {
        List<Policy> policies = (List<Policy>) policyRepository.findAll();
        Policy policy = policies.get(0);
        List<Long> actSeqOrder = policy.getFlows().stream().findFirst().get().getRuleSets().stream().findFirst().get().getRules().stream().map(Rule::getSequence).collect(Collectors.toList());
        Assertions.assertThat(actSeqOrder).isSorted();
    }

    @Test
    public void testfindByDeviceIdAndStatusInAndFlowIdNot() {
        List<Policy> policiesBefore = policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policyToGetFlow = policiesBefore.get(0);
        Flow flow = policyToGetFlow.getFlows().stream().findFirst().get();
        List<Policy> policies = policyRepository.findByDeviceIdAndStatusInAndFlowIdNot(deviceId, Arrays.asList(WorkflowParticipant.WorkflowStatus.DRAFT, WorkflowParticipant.WorkflowStatus.ACTIVE), flow);
        assertThat(policies.size()).isEqualTo(0);
    }

    @Test
    public void testFindByDeviceIdAndIngressPorts() {
        List<Policy> policiesBefore = policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policyToGetFlow = policiesBefore.get(0);
        Set<Long> portIds = policyToGetFlow.getFlows().stream().flatMap(flow -> flow.getIngressPorts().stream()).map(Port::getId).collect(Collectors.toSet());
        List<Policy> policies = policyRepository.findByDeviceIdAndIngressPorts(1L, portIds);
        assertThat(policies.size()).isEqualTo(2);
    }

    @Test
    public void testFindByDeviceIdAndIngressPortsForActivePolicy() {
        List<Policy> policiesBefore =  policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policyToGetFlow = policiesBefore.get(0);
        policyToGetFlow.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        policyToGetFlow.setFieldOffset1(0L);
        policyToGetFlow.setFieldOffset2(4L);
        policyToGetFlow.setFieldOffset3(8L);
        policyToGetFlow.setFieldOffset4(12L);
        policyRepository.save(policyToGetFlow);
        Set<Long> portIds = policyToGetFlow.getFlows().stream().flatMap(flow -> flow.getIngressPorts().stream()).map(Port::getId).collect(Collectors.toSet());
        List<Policy> policies =  policyRepository.findByDeviceIdAndIngressPorts(1L, portIds);
        assertThat(policies.size()).isEqualTo(2);
    }

    @Test
    public void testPolicyHistory() throws JsonProcessingException {
        List<Policy> policiesBefore = policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policyToGetFlow = policiesBefore.get(0);
        policyToGetFlow.setFieldOffset1(0L);
        policyToGetFlow.setFieldOffset2(4L);
        policyToGetFlow.setFieldOffset3(8L);
        policyToGetFlow.setFieldOffset4(12L);
        policyToGetFlow.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        policyRepository.save(policyToGetFlow);
        List<PolicyHistory> policyHistory = policyHisotryRepository.findByIdAndWorkflowStatus(policyToGetFlow.getId(),WorkflowParticipant.WorkflowStatus.ACTIVE);
        Policy policy = policyHistory.get(0).buildParent();
        assertThat(policy).isEqualToComparingOnlyGivenFields(policyToGetFlow,"id","name");
        assertThat(policy.getFlows().size()).isEqualTo(policyToGetFlow.getFlows().size());
    }

    @Test
    public void testPolicyHistoryForOpenFlow() throws JsonProcessingException {
        List<Policy> policiesBefore =policyRepository.findByDeviceIdAndCreatedFromSd(1L, false);
        Policy policyToGetFlow = policiesBefore.get(0);
        policyToGetFlow.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        policyToGetFlow.setFieldOffset1(null);
        policyToGetFlow.setFieldOffset2(null);
        policyToGetFlow.setFieldOffset3(null);
        policyToGetFlow.setFieldOffset4(null);
        policyRepository.save(policyToGetFlow);
        List<PolicyHistory> policyHistory = policyHisotryRepository.findByIdAndWorkflowStatus(policyToGetFlow.getId(),WorkflowParticipant.WorkflowStatus.ACTIVE);
        Policy policy = policyHistory.get(0).buildParent();
        assertThat(policy).isEqualToComparingOnlyGivenFields(policyToGetFlow, "id", "name");
        assertThat(policy.getFlows().size()).isEqualTo(policyToGetFlow.getFlows().size());
    }
}
