package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ManagedObjectRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Sets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class DatabaseSanityTest {

    @Inject
    private ManagedObjectRepository managedObjectRepository;

    @Inject
    private DeviceRepository deviceRepository;

    private static boolean isSetupDone;

    @Before
    public void setup() {
        if (!isSetupDone) {
            Device device = new Device();
            device.setName("device1");
            device.setStablenetId(1L);
            device.setMode(Device.Mode.PLAIN);
            device.setType(Device.Type.MLXE);
            device.setIpAddress("1.2.3.4");
            device.setLastCollectedTime(Instant.now());
            deviceRepository.save(device);
            isSetupDone = true;
        }
    }

    @Test
    public void testDeviceGet() {
        Device device = deviceRepository.findOne(1L);
        Device expectedDevice = new Device();
        expectedDevice.setName("device1");
        expectedDevice.setStablenetId(1L);
        expectedDevice.setMode(Device.Mode.PLAIN);
        expectedDevice.setType(Device.Type.MLXE);
        expectedDevice.setIpAddress("1.2.3.4");
        assertThat(device).isEqualToComparingOnlyGivenFields(expectedDevice, "name", "stablenetId", "mode", "type", "ipAddress");
    }

    @Test
    public void testManagedObject() {
        ManagedObject managedObject = managedObjectRepository.findOne(1L);
        assertThat(managedObject.getName()).isEqualTo("device1");
        managedObject.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.DRAFT);
        managedObjectRepository.save(managedObject);

        ManagedObject managedObject1 = managedObjectRepository.findOne(1L);
        assertThat(managedObject1.getWorkflowStatus()).isEqualTo(WorkflowParticipant.WorkflowStatus.DRAFT);
    }

    @Test
    public void testInventoryRelations() {
        Device device = deviceRepository.findOne(1L);
        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setLinkStatus(Port.LinkStatus.UP);
        port1.setStablenetIndex(100l);

        module.addPorts(Sets.newHashSet(port1));
        device.addModules(Sets.newHashSet(module));
        deviceRepository.save(device);

        Device device1 = deviceRepository.findOne(1L);
        assertThat(device1.getModules()).extracting("name").containsOnly("module1");
        assertThat(device1.getModules().stream().findFirst().get().getPorts()).extracting("name").containsOnly("port1");
    }
}
