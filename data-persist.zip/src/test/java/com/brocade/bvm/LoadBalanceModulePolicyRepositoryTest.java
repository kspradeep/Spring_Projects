package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.LoadBalanceModulePolicyHistoryRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class LoadBalanceModulePolicyRepositoryTest {


    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private LoadBalanceModulePolicyHistoryRepository loadBalanceModulePolicyHistoryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    private static boolean isSetupDone;

    private Long deviceId;

    @Before
    public void setup() {
        Device device = saveDevice();
        isSetupDone = true;
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        deviceId = device.getId();

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);


        Module module2 = new Module();
        module2.setName("module2");
        module2.setModuleNumber(2);
        module2.setStablenetId(21L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);
        port1.setStablenetIndex(101L);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);
        port2.setStablenetIndex(102L);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);
        port3.setStablenetIndex(103L);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        port4.setStablenetIndex(104L);

        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        Set<Module> modules = new HashSet<>();
        modules.add(module);
        modules.add(module2);
        device.addModules(modules);
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    public void testSaveLoadBalancePolicy(){
        Device device =deviceRepository.findOne(deviceId);
        LoadBalanceModulePolicy lpPolicy = new LoadBalanceModulePolicy();
        lpPolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        lpPolicy.setTunnelingProtocol("tcp");
        Set<Module> modules = device.getModules();
        lpPolicy.addModules(modules);
        lpPolicy = modulePolicyRepository.save(lpPolicy);

        Assertions.assertThat(lpPolicy.getId()).isNotNull();
        ModulePolicy mp = modulePolicyRepository.findOne(lpPolicy.getId());
        Assertions.assertThat(mp).isNotNull();
        //Assertions.assertThat(mp.getModules().size()).isEqualTo(2);

        List<ModulePolicy> modulePolicyListByDevice = modulePolicyRepository.findByDeviceId(1L);
        //Assertions.assertThat(modulePolicyListByDevice.size()).isEqualTo(2);

        List<ModulePolicy> modulePolicyListByModule = modulePolicyRepository.findByModuleId(device.getModules().stream().findFirst().get().getId());
        Assertions.assertThat(modulePolicyListByModule.size()).isEqualTo(1);

        LoadBalanceModulePolicyHistory historyModulePolicy = loadBalanceModulePolicyHistoryRepository.findByParentId(lpPolicy.getId());
        Assertions.assertThat(historyModulePolicy).isNotNull();
        LoadBalanceModulePolicy modulePolicyFromHistory = historyModulePolicy.buildParent();
        Assertions.assertThat(modulePolicyFromHistory).isNotNull();
    }

}
