package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Port;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.time.Instant;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class DeviceRepositoryTest {

    @Inject
    private DeviceRepository deviceRepository;

    private static boolean isSetupDone;

    private static Long deviceId;

    @Before
    public void setup() {
        if (!isSetupDone) {
            Device d = saveDevice();
            deviceId = d.getId();
            isSetupDone = true;
        }
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        port4.setStablenetIndex(100L);
        port3.setStablenetIndex(101L);
        port2.setStablenetIndex(102L);
        port1.setStablenetIndex(103L);
        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        device.addModules(Sets.newHashSet(module));
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    public void testFindByModuleId(){
        Device d1 = deviceRepository.findById(deviceId);
        Long moduleId = d1.getModules().stream().findAny().get().getId();
        Device d2 = deviceRepository.findByModuleId(moduleId);
        Assertions.assertThat(d1.getId()).isEqualTo(d2.getId());

    }
}
