package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.EventRepository;
import com.brocade.bvm.dao.JobRepository;
import com.brocade.bvm.model.db.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import javax.inject.Inject;
import java.time.Instant;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class EventRepositoryTest {

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private JobRepository jobRepository;

    @Inject
    private EventRepository eventRepository;

    private static boolean isSetupDone;

    private Event event;

    private Device device;


    @Before
    public void setup() {
        if (!isSetupDone) {
            this.device = saveDevice();
            Job job = saveJob(device);
            this.event = saveEvent(job);
            isSetupDone = true;
        }
    }

    private Event saveEvent(Job job){
        Event event = new Event();
        event.setJob(job);
        event.setStatus(Event.Status.NEW);
        event = eventRepository.save(event);
        return event;
    }

    private Job saveJob(Device device){
        Job job = new Job();
        ReflectionTestUtils.setField(job, "id", 10L);
        job.setStatus(Job.Status.SUCCESS);
        job.setType(Job.Type.POLICY_CREATE);
        job.setParentObjectId(12L);
        job.setTargetHost(device);
        job.setImpactedObjectsIds(new HashSet<>(Collections.singletonList(13L)));
        job = jobRepository.save(job);
        return job;
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);
        port1.setStablenetIndex(100l);
        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);
        port2.setStablenetIndex(102l);
        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);
        port3.setStablenetIndex(101l);
        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        port4.setStablenetIndex(100l);
        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        device.addModules(Sets.newHashSet(module));
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    @Ignore
    public void testFindByDeviceId(){
        List<Event> eventsFromDb = eventRepository.findByTargetHostId(deviceRepository.findById(1L).getId());
        Assertions.assertThat(eventsFromDb.size()).isGreaterThan(0);
    }

    @Test
    @Ignore
    public void testFindByDeviceAndStatus(){
        List<Event> eventsFromDb = eventRepository.findByTargetHostIdAndStatusIn(deviceRepository.findById(1L).getId(),Sets.newHashSet(Event.Status.NEW));
        Assertions.assertThat(eventsFromDb.size()).isGreaterThan(0);
    }

    @Test
    public void testFindByStatus(){
        List<Event> eventsFromDb = eventRepository.findByStatusIn(Collections.singletonList(Event.Status.NEW));
        Assertions.assertThat(eventsFromDb.size()).isGreaterThan(0);
    }

    @Test
    public void testFindManagedObjectNames() {
        List<String> managedObjectIdNames = eventRepository.findManagedObjectNames(Lists.newArrayList(1L, 2L));
        Assertions.assertThat(managedObjectIdNames).contains("1:device1", "2:module1");
    }
}
