package com.brocade.bvm.statistics;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.statistics.InterfaceStatisticsRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import com.google.common.collect.Sets;

import java.time.Instant;
import java.util.Date;
import java.util.Set;

class TestDataBuilder {

  private TestDataBuilder() {}

  static TestDataBuilder getBuilder() {
    return new TestDataBuilder();
  }

  void buildDevice(DeviceRepository deviceRepository) {
    Device device = new Device();
    device.setName("device1");
    device.setType(Device.Type.SLX);
    device.setStablenetId(1L);
    device.setMode(Device.Mode.PLAIN);
    device.setIpAddress("1.2.3.4");
    device.setDeleted(false);
    device.setProfileConfigured(true);
    device.setReconciled(true);
    device.setLastCollectedTime(Instant.now());
    device = deviceRepository.save(device);

    Module module = new Module();
    module.setName("module1");
    module.setModuleNumber(1);
    module.setStablenetId(2L);

    Port port1 = new Port();
    port1.setName("port1");
    port1.setMaxSpeed(40000L);
    port1.setStablenetId(3L);
    port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
    port1.setType(Port.Type.INGRESS);
    port1.setLinkStatus(Port.LinkStatus.UP);
    port1.setStablenetIndex(103L);
    module.addPorts(Sets.newHashSet(port1));
    device.addModules(Sets.newHashSet(module));
    deviceRepository.save(device);
  }

  InterfaceStatistics buildInterfaceStatistics(
          InterfaceStatisticsRepository repository, PortRepository portRepository) {
    InterfaceStatistics interfaceStatistics = new InterfaceStatistics();
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    Port port = null;
    if(ports.stream().findFirst().isPresent()) port = ports.stream().findFirst().get();

    if (port == null) throw new AssertionError();
    interfaceStatistics.setPortId(port.getId());
    interfaceStatistics.setIfName("Eithernet 0/1");
    interfaceStatistics.setIfIndex(port.getStablenetIndex());
    interfaceStatistics.setInBandwidth(100000L);
    interfaceStatistics.setInBroadcastPkts(100000L);
    interfaceStatistics.setInErrors(10000L);
    interfaceStatistics.setInLinkUtilization(100.00);
    interfaceStatistics.setInPackets(1000L);
    interfaceStatistics.setInMulticastPkts(1000L);
    interfaceStatistics.setInUnicastPkts(1000L);
    interfaceStatistics.setInPktsPerSecond(100L);
    interfaceStatistics.setOutBandwidth(100000L);
    interfaceStatistics.setOutBroadcastPkts(100000L);
    interfaceStatistics.setOutErrors(10000L);
    interfaceStatistics.setOutLinkUtilization(100.00);
    interfaceStatistics.setOutPackets(1000L);
    interfaceStatistics.setOutMulticastPkts(1000L);
    interfaceStatistics.setOutUnicastPkts(1000L);
    interfaceStatistics.setOutPktsPerSecond(100L);
    interfaceStatistics.setInOctets(1000L);
    interfaceStatistics.setOutOctets(1000L);
    interfaceStatistics.setLastUpdatedTime(Instant.now());
    interfaceStatistics.setReceivedTime(new Date());
    repository.save(interfaceStatistics);
    return interfaceStatistics;
  }
}
