package com.brocade.bvm.statistics;

import com.brocade.bvm.EmbeddedDbTestConfiguration;
import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.statistics.InterfaceStatisticsRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.statistics.*;
import com.google.common.collect.Sets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.util.*;

import static org.assertj.core.api.StrictAssertions.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class StatisticsPortRepositoryTest {

  @Inject private PortRepository portRepository;
  @Inject private StatisticsPortRepository statisticsPortRepository;
  @Inject private DeviceRepository deviceRepository;
  @Inject private InterfaceStatisticsRepository interfaceStatisticsRepository;
  private InterfaceStatistics interfaceStatistics;

  @Before
  public void setup() {
      TestDataBuilder.getBuilder().buildDevice(deviceRepository);
      interfaceStatistics =
          TestDataBuilder.getBuilder()
              .buildInterfaceStatistics(interfaceStatisticsRepository, portRepository);
  }

  @Test
  public void itShouldReturnPortUtilizationForGivenPort() {
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    List<PortBandwidth> portBandwidths = new ArrayList<>();
    ports.forEach(
        port -> portBandwidths.addAll(statisticsPortRepository.getPortUtilization(port.getId())));

    assertThat(portBandwidths.size() > 1);
    PortBandwidth portBandwidth = portBandwidths.stream().findFirst().get();
    assertThat(portBandwidth.getInUtilization())
        .isEqualTo(interfaceStatistics.getInLinkUtilization());
    assertThat(portBandwidth.getLineSpeed()).isEqualTo(40000L);
    assertThat(portBandwidth.getOutUtilization())
        .isEqualTo(interfaceStatistics.getOutLinkUtilization());
    assertThat(portBandwidth.getInBandwidth()).isEqualTo(interfaceStatistics.getInBandwidth());
    assertThat(portBandwidth.getOutBandwidth()).isEqualTo(interfaceStatistics.getOutBandwidth());
    assertThat(portBandwidth.getThroughput()).isEqualTo(interfaceStatistics.getInBandwidth());
  }

  @Test
  public void itShouldReturnPacketsForGivenPort() {
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    List<PortPackets> portPackets = new ArrayList<>();
    ports.forEach(
            port -> portPackets.addAll(statisticsPortRepository.findPortPacketInformation(port.getId(), 20)));

    assertThat(portPackets.size() > 1);
    Optional<PortPackets> found = portPackets.stream().findFirst();
    PortPackets portPacket = found.get();
    assertThat(portPacket.getInPackets()).isEqualTo(interfaceStatistics.getInPackets());
    assertThat(portPacket.getOutPackets()).isEqualTo(interfaceStatistics.getOutPackets());
    assertThat(portPacket.getInPPS()).isEqualTo(interfaceStatistics.getInPktsPerSecond());
    assertThat(portPacket.getOutPPS()).isEqualTo(interfaceStatistics.getOutPktsPerSecond());
    assertThat(portPacket.getInBytes()).isEqualTo(interfaceStatistics.getInOctets());
    assertThat(portPacket.getOutBytes()).isEqualTo(interfaceStatistics.getOutOctets());
  }

  @Test
  public void itShouldReturnPacketTypesForGivenPort() {
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    List<PortPacketType> portPacketTypes = new ArrayList<>();
    ports.forEach(
            port -> portPacketTypes.addAll(statisticsPortRepository.portTypePackets(port.getId(), 20)));

    assertThat(portPacketTypes.size() > 1);
    Optional<PortPacketType> found = portPacketTypes.stream().findFirst();
    PortPacketType portPacketType = found.get();
    assertThat(portPacketType.getInUniCastPackets()).isEqualTo(interfaceStatistics.getInUnicastPkts());
    assertThat(portPacketType.getOutUniCastPackets()).isEqualTo(interfaceStatistics.getOutUnicastPkts());
    assertThat(portPacketType.getInMultiCastPackets()).isEqualTo(interfaceStatistics.getInMulticastPkts());
    assertThat(portPacketType.getOutMultiCastPackets()).isEqualTo(interfaceStatistics.getOutMulticastPkts());
    assertThat(portPacketType.getInBroadcastPackets()).isEqualTo(interfaceStatistics.getInBroadcastPkts());
    assertThat(portPacketType.getOutBroadcastPackets()).isEqualTo(interfaceStatistics.getOutBroadcastPkts());
  }

  @Test
  public void itShouldReturnPacketsDropForGivenPort() {
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    List<PortPacketsDrop> portPacketsDrops = new ArrayList<>();
    ports.forEach(
            port -> portPacketsDrops.addAll(statisticsPortRepository.portDropPackets(port.getId(), 20)));

    assertThat(portPacketsDrops.size() > 1);
    Optional<PortPacketsDrop> found = portPacketsDrops.stream().findFirst();
    PortPacketsDrop portPacketsDrop = found.get();
    assertThat(portPacketsDrop.getInDropPackets()).isEqualTo(interfaceStatistics.getInDiscards());
    assertThat(portPacketsDrop.getOutDropPackets()).isEqualTo(interfaceStatistics.getOutDiscards());
  }

  @Test
  public void itShouldReturnErrorPacketForGivenPort() {
    Set<Port> ports = Sets.newHashSet(portRepository.findAll());
    List<PortPacketsError> portPacketsErrors = new ArrayList<>();
    ports.forEach(
            port -> portPacketsErrors.addAll(statisticsPortRepository.portErrorPackets(port.getId(), 20)));

    assertThat(portPacketsErrors.size() > 1);
    Optional<PortPacketsError> found = portPacketsErrors.stream().findFirst();
    PortPacketsError portPacketsError = found.get();
    assertThat(portPacketsError.getInPacketsError()).isEqualTo(interfaceStatistics.getInErrors());
    assertThat(portPacketsError.getOutPacketsError()).isEqualTo(interfaceStatistics.getOutErrors());
  }

  @Test
  public void itShouldReturnAllIngressAndEgressPorts() {
    Map<String, Long> all =  statisticsPortRepository.getAllIngressAndEgressTapPorts();
    assertThat(all.get("ingress").longValue()).isEqualTo(1);
    assertThat(all.get("egress").longValue()).isEqualTo(0);
  }
}
