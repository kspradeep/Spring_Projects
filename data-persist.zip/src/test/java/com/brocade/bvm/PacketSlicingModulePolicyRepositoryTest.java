package com.brocade.bvm;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.ModulePolicyRepository;
import com.brocade.bvm.dao.PacketSlicingModulePolicyHistoryRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.brocade.bvm.model.db.history.PacketSlicingModulePolicyHistory;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import javax.inject.Inject;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by dneelapa on 6/27/2016.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class PacketSlicingModulePolicyRepositoryTest {

    @Inject
    private ModulePolicyRepository modulePolicyRepository;

    @Inject
    private PacketSlicingModulePolicyHistoryRepository packetSlicingModulePolicyHistoryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    private static boolean isSetupDone;

    private Long deviceId;

    @Before
    public void setup() {
        if (!isSetupDone) {
            Device device = saveDevice();
            isSetupDone = true;
        }
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device2");
        device.setStablenetId(2L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.5");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        deviceId = device.getId();

        Module module = new Module();
        module.setName("module3");
        module.setModuleNumber(3);
        module.setStablenetId(22L);
        ReflectionTestUtils.setField(module, "id", 10L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(23L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);
        ReflectionTestUtils.setField(port1, "id", 101L);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(23L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);
        ReflectionTestUtils.setField(port2, "id", 102L);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(23L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);
        ReflectionTestUtils.setField(port3, "id", 103L);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(23L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        ReflectionTestUtils.setField(port4, "id", 104L);

        port4.setStablenetIndex(100l);
        port3.setStablenetIndex(101l);
        port2.setStablenetIndex(102l);
        port1.setStablenetIndex(103l);

        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        Set<Module> modules = new HashSet<>();
        modules.add(module);

        device.addModules(modules);
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    public void testSavePacketSlicingPolicy() {
        Device device = deviceRepository.findOne(deviceId);
        PacketSlicingModulePolicy packetSlicingModulePolicy = new PacketSlicingModulePolicy();
        packetSlicingModulePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        packetSlicingModulePolicy.setNumberOfBytes(1024);
        Set<Module> modules = device.getModules();
        packetSlicingModulePolicy.setModules(modules);
        packetSlicingModulePolicy.setPorts(packetSlicingModulePolicy.getModules().stream().findFirst().get().getPorts());
        packetSlicingModulePolicy = modulePolicyRepository.save(packetSlicingModulePolicy);
        Assertions.assertThat(packetSlicingModulePolicy.getId()).isNotNull();

        ModulePolicy modulePolicy = modulePolicyRepository.findOne(packetSlicingModulePolicy.getId());
        Assertions.assertThat(modulePolicy).isNotNull();

        PacketSlicingModulePolicyHistory historyModulePolicy = packetSlicingModulePolicyHistoryRepository.findByParentId(packetSlicingModulePolicy.getId());
        Assertions.assertThat(historyModulePolicy).isNotNull();
        PacketSlicingModulePolicy modulePolicyFromHistory = historyModulePolicy.buildParent();
        Assertions.assertThat(modulePolicyFromHistory).isNotNull();
    }
}
