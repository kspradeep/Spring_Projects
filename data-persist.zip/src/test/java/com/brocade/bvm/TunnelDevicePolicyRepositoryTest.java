package com.brocade.bvm;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.*;
import com.brocade.bvm.model.db.history.PolicyHistory;
import com.brocade.bvm.model.db.history.TunnelDevicePolicyHistory;
import com.google.common.collect.Sets;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(EmbeddedDbTestConfiguration.class)
public class TunnelDevicePolicyRepositoryTest {

    @Inject
    private TunnelDevicePolicyRepository tunnelDevicePolicyRepository;

    @Inject
    private TunnelDevicePolicyHistoryRepository tunnelDevicePolicyHistoryRepository;

    @Inject
    private DeviceRepository deviceRepository;

    @Inject
    private PolicyRepository policyRepository;

    @Inject
    private PolicyHistoryRepository policyHistoryRepository;

    private static boolean isSetupDone;

    private static Long deviceId;

    @Before
    public void setup() {
        Device device = saveDevice();
        deviceId = device.getId();
        isSetupDone = true;
    }

    private Policy savePolicy(Device device, String policyName, WorkflowParticipant.WorkflowStatus workflowStatus, TunnelDevicePolicy devicePolicy) {
        Policy policyToSave = new Policy();


        policyToSave.setName(policyName);

        policyToSave.setFlows(getFlows(device,devicePolicy));

        policyToSave.setWorkflowStatus(workflowStatus);
        policyToSave.setFieldOffset1(0L);
        policyToSave.setFieldOffset2(4L);
        policyToSave.setFieldOffset3(8L);
        policyToSave.setFieldOffset4(12L);
        policyToSave = policyRepository.save(policyToSave);

        Policy policy = policyRepository.findOne(policyToSave.getId());
        policy.setDevice(deviceRepository.findById(1L));
        policy.setFieldOffset1(0L);
        policy.setFieldOffset2(4L);
        policy.setFieldOffset3(8L);
        policy.setFieldOffset4(12L);
        policy = policyRepository.save(policy);
        return policy;
    }

    private static SortedSet<Flow> getFlows(Device device, TunnelDevicePolicy devicePolicy) {
        Flow flow = new Flow();
        Set<Port> ingressPorts = new HashSet<>();
        Set<Port> egressPorts = new HashSet<>();

        List<Port> ingressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType() == Port.Type.INGRESS).collect(Collectors.toList());
        List<Port> egressList = device.getModules().stream().findAny().get().getPorts().stream().filter(port -> port.getType() == Port.Type.EGRESS).collect(Collectors.toList());

        ingressPorts.add(ingressList.get(0));
        egressPorts.add(egressList.get(0));

        flow.addIngressPorts(ingressPorts);
        flow.addEgressPorts(egressPorts);
        flow.setSequence(1);
        flow.setRuleSets(getRuleSets());

        Flow flow1 = new Flow();
        List<TunnelDevicePolicy> tunnelDevicePolicies = new ArrayList<>();
        tunnelDevicePolicies.add(devicePolicy);
        flow1.setTunnelPolicies(tunnelDevicePolicies);
        Set<Port> ingressPorts1 = new HashSet<>();
        Set<Port> egressPorts1 = new HashSet<>();

        ingressPorts1.add(ingressList.get(1));
        egressPorts1.add(egressList.get(1));

        flow1.addIngressPorts(ingressPorts1);
        flow1.addEgressPorts(egressPorts1);
        flow1.setSequence(2);

        SortedSet<Flow> flows = new TreeSet<>();
        flows.add(flow);
        flows.add(flow1);
        return flows;
    }

    private static SortedSet<RuleSet> getRuleSets() {
        RuleSet ruleSet = new RuleSet();
        ruleSet.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet.setType(RuleSet.Type.L2);
        ruleSet.setSequence(0);
        ruleSet.addRules(getRules());

        RuleSet ruleSet1 = new RuleSet();
        ruleSet1.setIpVersion(RuleSet.IpVersion.V4);
        ruleSet1.setType(RuleSet.Type.L2);
        ruleSet1.setSequence(1);
        ruleSet1.addRules(getRules());

        SortedSet<RuleSet> ruleSets = new TreeSet<>();
        ruleSets.add(ruleSet);
        ruleSets.add(ruleSet1);
        return ruleSets;
    }

    private static SortedSet<Rule> getRules() {
        Rule rule = new Rule();
        rule.setSequence(10l);

        Rule rule1 = new Rule();
        rule1.setSequence(6l);

        Rule rule2 = new Rule();
        rule2.setSequence(27l);

        Rule rule3 = new Rule();
        rule3.setSequence(99l);

        // wiring rules
        SortedSet<Rule> ruleSet = new TreeSet<>();
        ruleSet.add(rule);
        ruleSet.add(rule1);
        ruleSet.add(rule2);
        ruleSet.add(rule3);

        return ruleSet;
    }

    private Device saveDevice() {
        Device device = new Device();
        device.setName("device1");
        device.setStablenetId(1L);
        device.setMode(Device.Mode.PLAIN);
        device.setType(Device.Type.MLXE);
        device.setIpAddress("1.2.3.4");
        device.setLastCollectedTime(Instant.now());
        device = deviceRepository.save(device);

        Module module = new Module();
        module.setName("module1");
        module.setModuleNumber(1);
        module.setStablenetId(2L);

        Port port1 = new Port();
        port1.setName("port1");
        port1.setStablenetId(3L);
        port1.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port1.setType(Port.Type.INGRESS);
        port1.setLinkStatus(Port.LinkStatus.UP);

        Port port2 = new Port();
        port2.setName("port2");
        port2.setStablenetId(3L);
        port2.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port2.setType(Port.Type.EGRESS);
        port2.setLinkStatus(Port.LinkStatus.UP);

        Port port3 = new Port();
        port3.setName("port3");
        port3.setStablenetId(3L);
        port3.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port3.setType(Port.Type.INGRESS);
        port3.setLinkStatus(Port.LinkStatus.UP);

        Port port4 = new Port();
        port4.setName("port4");
        port4.setStablenetId(3L);
        port4.setDiscoveredAdminStatus(Port.AdminStatus.ENABLED);
        port4.setType(Port.Type.EGRESS);
        port4.setLinkStatus(Port.LinkStatus.UP);
        port4.setStablenetIndex(100L);
        port3.setStablenetIndex(101L);
        port2.setStablenetIndex(102L);
        port1.setStablenetIndex(103L);
        module.addPorts(Sets.newHashSet(port1));
        module.addPorts(Sets.newHashSet(port2));
        module.addPorts(Sets.newHashSet(port3));
        module.addPorts(Sets.newHashSet(port4));
        device.addModules(Sets.newHashSet(module));
        device = deviceRepository.save(device);
        return device;
    }

    @Test
    @Ignore
    public void testTunnelDevicePolicy() {
        Device device = deviceRepository.findById(deviceId);
        TunnelDevicePolicy devicePolicy = new TunnelDevicePolicy();
        devicePolicy.setDevice(device);
        devicePolicy.setWorkflowStatus(WorkflowParticipant.WorkflowStatus.ACTIVE);
        devicePolicy.setName("Profile 1");
        devicePolicy.setType(TunnelDevicePolicy.Type.MPLS);
        devicePolicy = tunnelDevicePolicyRepository.save(devicePolicy);
        //history
        List<TunnelDevicePolicyHistory> tunnelDevicePolicyHistories = tunnelDevicePolicyHistoryRepository.findByIdAndWorkflowStatus(devicePolicy.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        System.out.println(tunnelDevicePolicyHistories.get(0).getDevicePolicyJson());
        TunnelDevicePolicy devicePolicyFromHistory = tunnelDevicePolicyHistories.get(0).buildParent();
        Assertions.assertThat(devicePolicyFromHistory).isNotNull();
        //policy association
        devicePolicy = tunnelDevicePolicyRepository.findOne(devicePolicy.getId());
        Policy policy1 = savePolicy(deviceRepository.findById(deviceId), "Policy1", WorkflowParticipant.WorkflowStatus.ACTIVE, devicePolicy);
        Assertions.assertThat(policy1.getFlows().stream().anyMatch(flow -> flow.getTunnelPolicies().size()>0)).isTrue();
        //policy history
        List<PolicyHistory> policyHistories = policyHistoryRepository.findByIdAndWorkflowStatus(policy1.getId(), WorkflowParticipant.WorkflowStatus.ACTIVE);
        policyHistories.stream().forEach(policyHistory -> {
            System.out.println(policyHistory.getPolicyJson());
        });

    }
}