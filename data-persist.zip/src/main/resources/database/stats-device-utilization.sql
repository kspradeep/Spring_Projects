select
    sum (i.in_band_width) as in_band_width,
    sum (i.out_band_width) as out_band_width,
    sum (i.in_link_utilization) as in_link_utilization,
    sum (i.out_link_utilization) as out_link_utilization,
    i.last_updated_time
from bvm.interface_statistics i
where i.collector_device_id = ?
GROUP BY UNIX_TIMESTAMP (i.received_time) DIV 30 order by i.last_updated_time desc limit ?