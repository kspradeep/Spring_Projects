select
    sum (i.in_unicast_pkts) as in_unicast_pkts,
    sum (i.out_unicast_pkts) as out_unicast_pkts,
    sum (i.in_multicast_pkts) as in_multicast_pkts,
    sum (i.out_multicast_pkts) as out_multicast_pkts,
    sum (i.in_broadcast_pkts) as in_broadcast_pkts,
    sum (i.out_broadcast_pkts) as out_broadcast_pkts,
    i.last_updated_time
from bvm.interface_statistics i
where i.port_id IN (:ids)
GROUP BY UNIX_TIMESTAMP (i.received_time) DIV 30 order by i.last_updated_time desc limit :limit