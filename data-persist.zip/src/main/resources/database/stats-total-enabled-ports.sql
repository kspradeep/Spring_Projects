select count (distinct p.id)
from
    bvm.port p,
    bvm.module m,
    bvm.device d
where
    m.device_id = d.id and
    d.type = ? and
    p.admin_status = ?;