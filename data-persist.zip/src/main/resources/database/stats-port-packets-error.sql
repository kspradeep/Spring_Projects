select
    o.in_errors,
    o.out_errors,
    o.last_updated_time
from interface_statistics o
where o.port_id = ?
order by o.last_updated_time desc limit ?