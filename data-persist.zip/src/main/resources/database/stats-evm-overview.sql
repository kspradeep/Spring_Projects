select
    (
    select count (*)
    from bvm.device_grid) as totalGrids,
    (
    select count (*)
    from bvm.network_node_interface_mapping_ingress) as totalTapPorts,
    (
    select count (*)
    from bvm.network_node_interface_mapping_egress) as totalToolPorts,
    (
    select count (*)
    from bvm.policy) as totalPolicies