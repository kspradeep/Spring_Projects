select
    i.in_unicast_pkts,
    i.out_unicast_pkts,
    i.in_multicast_pkts,
    i.out_multicast_pkts,
    i.in_broadcast_pkts,
    i.out_broadcast_pkts,
    i.last_updated_time
from interface_statistics i
where i.port_id = ?
order by i.last_updated_time desc limit ?