select
    sum (i.in_packets) as in_packets,
    sum (i.out_packets) as out_packets,
    sum (i.in_octets) as in_octets,
    sum (i.out_octets) as out_octets,
    sum (i.in_pkts_per_second) as in_pkts_per_second,
    sum (i.out_pkts_per_second) as out_pkts_per_second,
    sum (i.in_band_width) as in_band_width,
    i.last_updated_time
from bvm.interface_statistics i
where i.port_id IN (:ids)
GROUP BY UNIX_TIMESTAMP (i.received_time) DIV 30 order by i.last_updated_time desc limit :limit