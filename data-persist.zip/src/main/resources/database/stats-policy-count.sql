select
    ac.hit_count,
    acl.acl_name as acls,
    acl.interface_name as port
from
    bvm.acl ac,
    bvm.acl_statistics acl
where
    ac.acl_statistics_id IN (select acll.id
                             from bvm.acl_statistics acll
                             where acll.policy_id = ?) and
    ac.acl_statistics_id = acl.id group by acl.interface_name