select
    sum (i.in_errors) as in_errors,
    sum (i.out_errors) as out_errors,
    i.last_updated_time
from bvm.interface_statistics i
where i.port_id IN (:ids)
GROUP BY UNIX_TIMESTAMP (i.received_time) DIV 30 order by i.last_updated_time desc limit :limit