select
    i.in_packets,
    i.out_packets,
    i.in_octets,
    i.out_octets,
    i.in_pkts_per_second,
    i.out_pkts_per_second,
    i.in_band_width,
    i.in_broadcast_pkts,
    i.out_band_width,
    i.out_broadcast_pkts,
    i.last_updated_time,
    i.received_time
from
    interface_statistics i
where i.port_id = ?
order by i.last_updated_time desc limit ?