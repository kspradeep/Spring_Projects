select
    o.in_discards,
    o.out_discards,
    o.last_updated_time
from interface_statistics o
where o.port_id = ?
order by o.last_updated_time desc limit ?