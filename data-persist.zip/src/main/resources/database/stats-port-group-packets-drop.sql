select
    sum (i.in_discards) as in_discards,
    sum (i.out_discards) as out_discards,
    i.last_updated_time
from bvm.interface_statistics i
where i.port_id IN (:ids)
GROUP BY UNIX_TIMESTAMP (i.last_updated_time) DIV 30 order by i.received_time desc limit :limit