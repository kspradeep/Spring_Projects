ALTER TABLE setup_history DROP COLUMN vm_ip_address;
ALTER TABLE setup_history DROP COLUMN username;
ALTER TABLE setup_history DROP COLUMN installdate;
ALTER TABLE setup_history DROP COLUMN upgradedate;
ALTER TABLE setup_history DROP COLUMN checksum;
ALTER TABLE setup_history  ADD column set_up_date_time  VARCHAR(50);
ALTER TABLE setup_history  ADD column action  VARCHAR(50);