ALTER TABLE policy ADD column is_ingress_valid BIT(1) NOT NULL DEFAULT 0;
ALTER TABLE policy ADD column egress_action VARCHAR(10);