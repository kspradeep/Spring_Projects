DROP TABLE IF EXISTS discovery_job;
CREATE TABLE IF NOT EXISTS discovery_job (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(100),
	obj_id VARCHAR(50),
	is_running BIT,
	ip_address VARCHAR(50) NOT NULL,
	cli_username VARCHAR(100),
    snmp_community VARCHAR(100),
    snmp_write_community VARCHAR(100),
    trigger_type VARCHAR(100),
    interval_value BIGINT(20),
	is_active BIT,
	job_status VARCHAR(100),
	response LONGTEXT,
	PRIMARY KEY (id)
);

ALTER TABLE port ADD column is_loop_back_enabled BIT NOT NULL DEFAULT 0;
ALTER TABLE port_history ADD column is_loop_back_enabled BIT NOT NULL DEFAULT 0;
ALTER TABLE port_group ADD column is_loop_back_enabled BIT NOT NULL DEFAULT 0;


