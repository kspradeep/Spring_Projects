DROP TABLE sd_filter_policy_history;
DROP TABLE sd_rule;
DROP TABLE sd_ruleset;
DROP TABLE sd_filter_policy;
DROP TABLE sd_imsi_policy_history;
DROP TABLE sd_imsi_policy;
DROP TABLE sd_dedupe_policy_history;
DROP TABLE sd_dedupe_policy;
DROP TABLE sd_load_balance_policy_history;
DROP TABLE sd_load_balance_policy;
DROP TABLE sd_port_group_history;
DROP TABLE sd_pb_port;
DROP TABLE sd_port_group;

DROP TABLE IF EXISTS sd_global_config;
CREATE TABLE IF NOT EXISTS sd_global_config (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    mode VARCHAR(45) NOT NULL,
    fcr_status BIT NOT NULL,
    fcr_mtime INT,
    s11_drop_status BIT NOT NULL,
    rx_tx_split_status BIT NOT NULL,
    sgi_correlation_status BIT NOT NULL,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sip_port_mapping;
CREATE TABLE IF NOT EXISTS sip_port_mapping (
    global_config_id BIGINT(20) NOT NULL,
    sip_port_no INTEGER(20) NOT NULL,
    FOREIGN KEY (global_config_id)
        REFERENCES sd_global_config (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_global_config_history;
CREATE TABLE IF NOT EXISTS sd_global_config_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    global_config_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_paired_device;
CREATE TABLE IF NOT EXISTS sd_paired_device (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(45),
    device_id BIGINT(20) NOT NULL,
    target_device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (target_device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_profile;
CREATE TABLE IF NOT EXISTS sd_profile (
    id BIGINT(20) AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    profile_id INT NOT NULL,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS device_profile_mapping;
CREATE TABLE IF NOT EXISTS device_profile_mapping (
    id BIGINT(20) AUTO_INCREMENT,
    name VARCHAR(45),
    device_id BIGINT(20) NOT NULL,
    profile_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (profile_id)
        REFERENCES sd_profile (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_physical_interface;
CREATE TABLE IF NOT EXISTS sd_physical_interface (
    id BIGINT(20) AUTO_INCREMENT,
    name VARCHAR(45),
    speed VARCHAR(45),
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS profile_interface_mapping;
CREATE TABLE IF NOT EXISTS profile_interface_mapping (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    profile_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
            REFERENCES managed_object (id)
            ON DELETE CASCADE,
    FOREIGN KEY (profile_id)
        REFERENCES sd_profile (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_ingress_port;
CREATE TABLE IF NOT EXISTS sd_ingress_port (
    id BIGINT(20) NOT NULL,
    jumbo_frame BIT,
    ptp_timestamp BIT,
    vlan_id INT,
    device_id BIGINT(20) NOT NULL,
    profile_id BIGINT(20) NOT NULL,
    physical_interface_id BIGINT(20),
    service_port_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (profile_id)
        REFERENCES sd_profile (id)
        ON DELETE CASCADE,
    FOREIGN KEY (physical_interface_id)
        REFERENCES sd_physical_interface (id),
    FOREIGN KEY (service_port_id)
        REFERENCES port (id)
);

DROP TABLE IF EXISTS sd_ingress_port_history;
CREATE TABLE IF NOT EXISTS sd_ingress_port_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    port_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_egress_port_group;
CREATE TABLE IF NOT EXISTS sd_egress_port_group (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    state VARCHAR(45),
    load_balance VARCHAR(45),
    is_default BIT,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_egress_port;
CREATE TABLE IF NOT EXISTS sd_egress_port (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    load_balance VARCHAR(45),
    imsi_limit VARCHAR(45),
    is_default BIT,
    device_id BIGINT(20) NOT NULL,
    egress_port_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (egress_port_id)
        REFERENCES port (id)
);

DROP TABLE IF EXISTS sd_egress_port_history;
CREATE TABLE IF NOT EXISTS sd_egress_port_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    port_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS port_vlan_mapping;
CREATE TABLE IF NOT EXISTS port_vlan_mapping (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(100),
    vlan_id BIGINT(20) NOT NULL,
    sd_port_id BIGINT(20) NOT NULL,
    is_tagged BIT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (sd_port_id)
        REFERENCES sd_egress_port (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS port_port_group;
CREATE TABLE IF NOT EXISTS port_port_group (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    sd_port_id BIGINT(20) NOT NULL,
    sd_egress_port_group_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (sd_port_id)
        REFERENCES sd_egress_port (id)
        ON DELETE CASCADE,
    FOREIGN KEY (sd_egress_port_group_id)
        REFERENCES sd_egress_port_group (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_egress_port_group_history;
CREATE TABLE IF NOT EXISTS sd_egress_port_group_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    port_group_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_policy;
CREATE TABLE IF NOT EXISTS sd_policy (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sampling_policy;
CREATE TABLE IF NOT EXISTS sampling_policy (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    is_preserve_cplane BIT,
    action VARCHAR(45),
    rate INT,
    load_balance_algo VARCHAR(45),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (id)
        REFERENCES sd_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sampling_policy_history;
CREATE TABLE IF NOT EXISTS sampling_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
    workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
    revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS dedupe_policy;
CREATE TABLE IF NOT EXISTS dedupe_policy (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    timeout INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (id)
        REFERENCES sd_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS dedupe_policy_history;
CREATE TABLE IF NOT EXISTS dedupe_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(45),
    timeout INT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) DEFAULT NULL,
    policy_json LONGTEXT,
    workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
    revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS filter_policy;
CREATE TABLE IF NOT EXISTS filter_policy (
    id BIGINT(20) NOT NULL,
    name VARCHAR(45),
    is_preserve_cplane BIT,
    sequence INT,
    traffic_type VARCHAR(45),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (id)
        REFERENCES sd_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS filter_policy_history;
CREATE TABLE IF NOT EXISTS filter_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    traffic_type VARCHAR(45),
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS filter_rule;
CREATE TABLE IF NOT EXISTS filter_rule (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(45),
    subscriber_traffic VARCHAR(45),
    charging_char VARCHAR(45),
    imsi_range INT,
    priority INT,
    apply VARCHAR(45),
    imsi VARCHAR(45),
    apn VARCHAR(45),
    imei VARCHAR(45),
    qci INT,
    mcc INT,
    mnc VARCHAR(45),
    sip_calling_party VARCHAR(45),
    sip_called_party VARCHAR(45),
    sampling_policy_id BIGINT(20),
    smatch_policy_id BIGINT(20),
    port_group_id BIGINT(20),
    replication_port_group_id BIGINT(20),
    filter_policy_id BIGINT(20) NOT NULL,
    imsi_file_name VARCHAR(45),
    imei_file_name VARCHAR(45),
    apn_file_name VARCHAR(45),
    sip_calling_party_file_name VARCHAR(45),
    sip_called_party_file_name VARCHAR(45),
    is_bulk_delete BIT,
    PRIMARY KEY (id),
    FOREIGN KEY (filter_policy_id)
        REFERENCES filter_policy (id)
        ON DELETE CASCADE,
    FOREIGN KEY (sampling_policy_id)
        REFERENCES sampling_policy (id),
    FOREIGN KEY (port_group_id)
        REFERENCES sd_egress_port_group (id),
    FOREIGN KEY (replication_port_group_id)
        REFERENCES sd_egress_port_group (id)
);

DROP TABLE IF EXISTS sd_active_interface;
CREATE TABLE IF NOT EXISTS sd_active_interface (
    id BIGINT(20) NOT NULL,
    replication_port_group_id BIGINT(20),
    sampling_policy_id BIGINT(20),
    filter_policy_id BIGINT(20),
    dedupe_policy_id BIGINT(20),
    port_group_id BIGINT(20),
    interface_mapping_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
            REFERENCES managed_object (id)
            ON DELETE CASCADE,
    FOREIGN KEY (sampling_policy_id)
        REFERENCES sampling_policy (id),
    FOREIGN KEY (filter_policy_id)
        REFERENCES filter_policy (id),
    FOREIGN KEY (dedupe_policy_id)
        REFERENCES dedupe_policy (id),
    FOREIGN KEY (port_group_id)
        REFERENCES sd_egress_port_group (id),
    FOREIGN KEY (interface_mapping_id)
        REFERENCES profile_interface_mapping (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_active_interface_history;
CREATE TABLE IF NOT EXISTS sd_active_interface_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20),
    interface_json LONGTEXT,
    workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
    revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_stats;
CREATE TABLE IF NOT EXISTS sd_stats (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(45),
    report_time TIMESTAMP(6) NOT NULL,
    stats_data LONGTEXT,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_flow_exporter;
CREATE TABLE IF NOT EXISTS sd_flow_exporter (
    id BIGINT(20) NOT NULL,
    sd_transport_protocol VARCHAR(45),
    sd_management_port_id BIGINT(20),
    sd_transport_port INTEGER(20),
    ip_address VARCHAR(50),
    c_plane_idle_timer INTEGER(20),
    pen_value INTEGER(20),
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (sd_management_port_id)
         REFERENCES sd_physical_interface (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_flow_exporter_history;
CREATE TABLE IF NOT EXISTS sd_flow_exporter_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    flow_exporter_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);
ALTER TABLE policy ADD column created_from_sd BIT(1) NOT NULL DEFAULT 0;