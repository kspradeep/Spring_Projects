DROP TABLE IF EXISTS tap_policy_history;
DROP TABLE IF EXISTS openstack_basic_rule;
DROP TABLE IF EXISTS openstack_advanced_rule;
DROP TABLE IF EXISTS openstack_advanced_ruleset;
DROP TABLE IF EXISTS openstack_basic_ruleset;
DROP TABLE IF EXISTS openstack_ruleset;
DROP TABLE IF EXISTS openstack_policy;
DROP TABLE IF EXISTS openstack_policyset;
DROP TABLE IF EXISTS virtual_port;
DROP TABLE IF EXISTS virtual_machine;
DROP TABLE IF EXISTS cloud_tenant;
DROP TABLE IF EXISTS compute_node;
DROP TABLE IF EXISTS virtual_network;
DROP TABLE IF EXISTS cloud_instance;

ALTER TABLE flow ADD COLUMN flow_name varchar(255);

ALTER TABLE policy ADD COLUMN audit_flow_name varchar(255);

DROP TABLE IF EXISTS stablenet_agent_config;
CREATE TABLE IF NOT EXISTS stablenet_agent_config (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	agent_id VARCHAR(50) NOT NULL,
	ip VARCHAR(50) NOT NULL,
	name VARCHAR(100),
	port_no INT NOT NULL,
	is_connected BIT,
	PRIMARY KEY (id)
);

DROP TABLE IF EXISTS stablenet_device_config;
CREATE TABLE IF NOT EXISTS stablenet_device_config (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(100),
  	value LONGTEXT,
  	PRIMARY KEY (id)
  );

DROP TABLE IF EXISTS packet_truncation;
CREATE TABLE IF NOT EXISTS packet_truncation (
  	id BIGINT(20) NOT NULL,
  	name VARCHAR(50),
  	frame_size BIGINT(20),
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
  	    REFERENCES managed_object (id)
  	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_truncation_device_mapping;
CREATE TABLE IF NOT EXISTS packet_truncation_device_mapping (
  	id BIGINT(20) NOT NULL,
  	name VARCHAR(50),
  	packet_truncation_id BIGINT(20),
  	device_id BIGINT(20),
  	port_id BIGINT(20),
  	port_group_id BIGINT(20),
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
  	    REFERENCES managed_object (id)
  	    ON DELETE CASCADE,
  	FOREIGN KEY (device_id)
  	    REFERENCES device (id)
  	    ON DELETE CASCADE,
  	FOREIGN KEY (port_id)
  	    REFERENCES port (id)
  	    ON DELETE CASCADE,
  	FOREIGN KEY (port_group_id)
  	    REFERENCES port_group (id)
  	    ON DELETE CASCADE,
  	FOREIGN KEY (packet_truncation_id)
  	    REFERENCES packet_truncation (id)
  	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_truncation_device_history;
CREATE TABLE IF NOT EXISTS packet_truncation_device_history (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(50),
  	parent_id BIGINT(20) NOT NULL,
  	packet_truncation_json LONGTEXT,
  	device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
  	revision_time TIMESTAMP(6) NOT NULL,
  	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE flow  ADD column packet_truncation_mapping_id BIGINT(20) NULL DEFAULT NULL;

ALTER TABLE flow ADD FOREIGN KEY (packet_truncation_mapping_id) REFERENCES packet_truncation_device_mapping (id) ON DELETE CASCADE;
