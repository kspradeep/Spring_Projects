ALTER table
  device_utilization
ADD
  COLUMN in_band_width BIGINT(20) UNSIGNED ZEROFILL NOT NULL,
ADD
  COLUMN out_band_width BIGINT(20) UNSIGNED ZEROFILL NOT NULL
;