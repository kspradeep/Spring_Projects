DROP TABLE IF EXISTS device_utilization;
CREATE TABLE `device_utilization` (
	`id` BIGINT(20) NULL DEFAULT NULL,
	`out_packets` BIGINT(20) NULL DEFAULT NULL,
	`in_packets` BIGINT(20) NULL DEFAULT NULL,
	`in_octets` BIGINT(20) NULL DEFAULT NULL,
	`out_octets` BIGINT(20) NULL DEFAULT NULL,
	`in_pkts_per_second` BIGINT(20) NULL DEFAULT NULL,
	`out_pkts_per_second` BIGINT(20) NULL DEFAULT NULL,
	`last_updated_time` TIMESTAMP NULL DEFAULT NULL,
	`received_time` DATETIME NULL DEFAULT NULL
)
COMMENT='in_packets BIGINT(20) NULL DEFAULT NULL,\r\n	out_packets BIGINT(20) NULL DEFAULT NULL,\r\n	in_octets BIGINT(20) NULL DEFAULT NULL,\r\n	out_octets BIGINT(20) NULL DEFAULT NULL,\r\n	in_pkts_per_second BIGINT(20) NULL DEFAULT NULL,\r\n	out_pkts_per_second BIGINT(20) NULL DEFAULT NULL'
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;