ALTER TABLE filter_rule ADD column sequence INT NOT NULL;

ALTER TABLE device ADD column active_since VARCHAR(200);