ALTER TABLE flow ALTER COLUMN is_tagged SET DEFAULT 0;

ALTER TABLE rule ALTER COLUMN is_permit SET DEFAULT 0;
ALTER TABLE rule ADD COLUMN is_hexadecimal_type_1 BIT(1) NOT NULL DEFAULT 1;
ALTER TABLE rule ADD COLUMN is_hexadecimal_type_2 BIT(1) NOT NULL DEFAULT 1;
ALTER TABLE rule ADD COLUMN is_hexadecimal_type_3 BIT(1) NOT NULL DEFAULT 1;
ALTER TABLE rule ADD COLUMN is_hexadecimal_type_4 BIT(1) NOT NULL DEFAULT 1;

ALTER TABLE application_constant CHANGE value_json value LONGTEXT;

ALTER TABLE job ADD COLUMN error_log LONGTEXT;

ALTER TABLE flow_port_mapping_ingress MODIFY COLUMN managed_object_id BIGINT(20) NULL;

ALTER TABLE flow_port_mapping_egress MODIFY COLUMN managed_object_id BIGINT(20) NULL;

ALTER TABLE flex_match_profile ADD COLUMN is_default BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE collector_running_status ADD COLUMN is_reconciliation_running BIT(1) NOT NULL DEFAULT 0;

DROP TABLE IF EXISTS device_firmware_info;
CREATE TABLE IF NOT EXISTS device_firmware_info (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    device_id BIGINT(20) NOT NULL,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    firmware_name VARCHAR(255) NOT NULL,
    is_reboot_required BIT(1) NOT NULL DEFAULT 0,
    is_deleted BIT(1) NOT NULL DEFAULT 0,
    workflow_status VARCHAR(25),
        PRIMARY KEY (id),
        FOREIGN KEY (device_id)
            REFERENCES device (id)
            ON DELETE CASCADE
);

DROP TABLE IF EXISTS firmware_job;
CREATE TABLE IF NOT EXISTS firmware_job (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    target_host_id BIGINT(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(25) NOT NULL,
    parent_object_id BIGINT(20),
    job_result LONGTEXT,
    created_time TIMESTAMP(6) NOT NULL,
    last_updated_time TIMESTAMP(6) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (target_host_id) REFERENCES target_host (id) ON DELETE CASCADE
);
