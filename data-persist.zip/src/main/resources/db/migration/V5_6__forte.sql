ALTER TABLE device_utilization ADD in_link_utilization DOUBLE(6,2) NOT NULL;
ALTER TABLE device_utilization ADD out_link_utilization DOUBLE(6,2) NOT NULL;
ALTER TABLE device_utilization ADD throughput BIGINT(20) NOT NULL;