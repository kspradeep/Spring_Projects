ALTER TABLE packet_stamping_module_policy ADD column device_id BIGINT(20);
ALTER TABLE packet_stamping_module_policy ADD CONSTRAINT device_id
    FOREIGN KEY (device_id)
       REFERENCES device (id)
       ON DELETE CASCADE;

ALTER TABLE header_stripping_module_policy DROP column header;
ALTER TABLE header_stripping_module_policy ADD column device_id BIGINT(20);
ALTER TABLE header_stripping_module_policy ADD CONSTRAINT device_id1
    FOREIGN KEY (device_id)
       REFERENCES device (id)
       ON DELETE CASCADE;

ALTER TABLE device ADD column is_reconciled BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE policy ADD column is_legacy BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE rule
    ADD COLUMN is_match_payload_length BIT NOT NULL DEFAULT 0,
    ADD COLUMN is_count_enabled BIT NOT NULL DEFAULT 0;

ALTER TABLE flow ADD COLUMN is_default_route_map_drop BIT NOT NULL DEFAULT 0;

ALTER TABLE policy ADD COLUMN is_gtp_http_filtered BIT NOT NULL DEFAULT 0;

ALTER TABLE flow ADD COLUMN tagged_vlan_id INTEGER(20);

DROP TABLE IF EXISTS header_strip_mapping;
CREATE TABLE IF NOT EXISTS header_strip_mapping (
    header_strip_id BIGINT(20) NOT NULL,
    strip_header VARCHAR(45) NOT NULL,
    FOREIGN KEY (header_strip_id)
        REFERENCES header_stripping_module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS header_strip_port_mapping;
CREATE TABLE IF NOT EXISTS header_strip_port_mapping (
    module_policy_id BIGINT(20) NOT NULL,
    port_id BIGINT(20) NOT NULL,
    FOREIGN KEY (port_id)
        REFERENCES port (id)
        ON DELETE CASCADE,
    FOREIGN KEY (module_policy_id)
        REFERENCES header_stripping_module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_labeling_module_policy;
CREATE TABLE IF NOT EXISTS packet_labeling_module_policy (
    id BIGINT(20) NOT NULL,
    processor_number VARCHAR(25) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_labeling_module_policy_history;
CREATE TABLE IF NOT EXISTS packet_labeling_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS gtp_de_encapsulation_module_policy;
CREATE TABLE IF NOT EXISTS gtp_de_encapsulation_module_policy (
    id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS gtp_de_encapsulation_port_mapping;
CREATE TABLE IF NOT EXISTS gtp_de_encapsulation_port_mapping (
	module_policy_id BIGINT(20) NOT NULL,
	port_id BIGINT(20) NOT NULL,
	FOREIGN KEY (module_policy_id)
    	REFERENCES gtp_de_encapsulation_module_policy (id)
    	ON DELETE CASCADE,
	FOREIGN KEY (port_id)
    	REFERENCES port (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS gtp_de_encapsulation_module_policy_history;
CREATE TABLE IF NOT EXISTS gtp_de_encapsulation_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS template_policy;
CREATE TABLE IF NOT EXISTS template_policy(
	id BIGINT(20) NOT NULL,
	device_type VARCHAR(50),
	device_mode VARCHAR(50),
	device_model VARCHAR(50),
	PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS flex_match_profile;
CREATE TABLE IF NOT EXISTS flex_match_profile (
    id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES template_policy (id)
        ON DELETE CASCADE
);


DROP TABLE IF EXISTS flex_header;
CREATE TABLE IF NOT EXISTS flex_header (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    header_name VARCHAR(50),
    header_level INT,
    flex_match_profile_id BIGINT(20) NOT NULL,
    sequence INT,
    PRIMARY KEY (id),
    FOREIGN KEY (flex_match_profile_id)
        REFERENCES flex_match_profile (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS flex_header_field;
CREATE TABLE IF NOT EXISTS flex_header_field (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    header_field VARCHAR(100),
    is_positive BIT NOT NULL DEFAULT 0,
    offset INT,
    custom_offset INT,
    custom_field VARCHAR(100),
    byte_size INT,
    flex_header_id BIGINT(20) NOT NULL,
    sequence INT,
    PRIMARY KEY (id),
    FOREIGN KEY (flex_header_id)
        REFERENCES flex_header (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS flex_match_profile_history;
CREATE TABLE IF NOT EXISTS flex_match_profile_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    profile_json LONGTEXT,
    device_model VARCHAR(50),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS template_policy_mapping;
CREATE TABLE IF NOT EXISTS template_policy_mapping (
	policy_id BIGINT(20) NOT NULL,
	template_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
        	REFERENCES policy (id)
        	ON DELETE CASCADE,
     FOREIGN KEY (template_id)
         	REFERENCES template_policy (id)
         	ON DELETE CASCADE
);



DROP TABLE IF EXISTS ip_payload_length_policy;
CREATE TABLE IF NOT EXISTS ip_payload_length_policy (
    id BIGINT(20) NOT NULL,
    processor_number VARCHAR(25) NOT NULL,
    ip_type VARCHAR(25) NOT NULL,
    min_range BIGINT(20) NOT NULL,
    max_range BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE,
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS ip_payload_length_policy_history;
CREATE TABLE IF NOT EXISTS ip_payload_length_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS application_constant;
CREATE TABLE IF NOT EXISTS application_constant (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    value_json LONGTEXT,
    PRIMARY KEY (id)
);

ALTER TABLE sd_global_config ADD COLUMN ip_fragmentation_status BIT NOT NULL DEFAULT 0;