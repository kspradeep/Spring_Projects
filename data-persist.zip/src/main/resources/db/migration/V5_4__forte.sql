ALTER TABLE interface_statistics ADD COLUMN in_link_utilization DOUBLE (6,2);
ALTER TABLE interface_statistics ADD COLUMN out_link_utilization DOUBLE (6,2);
