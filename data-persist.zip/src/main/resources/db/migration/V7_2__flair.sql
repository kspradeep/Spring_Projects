ALTER TABLE packet_capture DROP COLUMN ip;
ALTER TABLE packet_capture  ADD column destination_ip  VARCHAR(50);
ALTER TABLE policy ADD column is_custom_rm_name BIT NOT NULL DEFAULT 0;