ALTER TABLE header_stripping_module_policy ADD column is_preserve BIT(1) NOT NULL DEFAULT 0;

DROP TABLE IF EXISTS reserved_vlan_device_policy;
CREATE TABLE IF NOT EXISTS reserved_vlan_device_policy (
    id BIGINT(20) NOT NULL,
    reserved_vlan INT NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

ALTER TABLE policy ADD column preserve_header BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE flow ADD column tvf_domain BIT(1) NOT NULL DEFAULT 0;