ALTER TABLE device ADD COLUMN is_authorization_configured BIT NOT NULL DEFAULT 0;
ALTER TABLE device CHANGE is_tacacs_configured is_authentication_configured BIT NOT NULL DEFAULT 0;