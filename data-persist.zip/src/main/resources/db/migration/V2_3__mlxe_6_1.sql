ALTER TABLE header_stripping_module_policy
ADD column intermediate_vlan INT NOT NULL DEFAULT 0,
ADD column intermediate_port_id BIGINT(20) NULL,
ADD column replace_vlan INT NOT NULL DEFAULT 0;
DROP TABLE IF EXISTS slx_ptp_policy;
CREATE TABLE IF NOT EXISTS slx_ptp_policy (
    id BIGINT(20) NOT NULL,
    is_enabled BIT(1) NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS slx_ptp_policy_history;
CREATE TABLE IF NOT EXISTS slx_ptp_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_policy_json LONGTEXT,
    device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

ALTER TABLE policy ADD column is_timestamp BIT(1) NOT NULL DEFAULT 0;