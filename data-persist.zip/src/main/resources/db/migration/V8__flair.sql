DROP TABLE IF EXISTS setup_history;
CREATE TABLE IF NOT EXISTS setup_history (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	vm_ip_address  VARCHAR(50),
  	username  VARCHAR(1000),
  	version  VARCHAR(1000),
  	installdate VARCHAR(50),
  	upgradedate  VARCHAR(50),
  	checksum VARCHAR(1000),
  	PRIMARY KEY (id)
);