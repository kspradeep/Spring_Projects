ALTER TABLE packet_truncation ADD column is_global BIT NOT NULL DEFAULT 0;
ALTER TABLE packet_truncation ADD column global_policy_name VARCHAR(255);
ALTER TABLE packet_truncation ADD column global_policy_sequence_number BIGINT(20);