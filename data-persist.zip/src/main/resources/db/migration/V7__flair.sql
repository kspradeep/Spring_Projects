DROP TABLE IF EXISTS packet_capture;
CREATE TABLE IF NOT EXISTS packet_capture (
  	id BIGINT(20) NOT NULL,
  	device_id BIGINT(20),
  	port_id BIGINT(20),
  	direction  VARCHAR(50),
  	filter  VARCHAR(50),
  	packet_count BIGINT(20),
  	is_pcap_created BIT NOT NULL DEFAULT 0,
  	is_downloaded BIT NOT NULL DEFAULT 0,
  	destination_path  VARCHAR(50),
  	file_name  VARCHAR(50),
    ip  VARCHAR(50),
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
  	    REFERENCES managed_object (id)
  	    ON DELETE CASCADE,
  	FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
  	 FOREIGN KEY (port_id)
        REFERENCES port (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_capture_history;
CREATE TABLE IF NOT EXISTS packet_capture_history (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(50),
  	parent_id BIGINT(20) NOT NULL,
  	packet_capture_json LONGTEXT,
  	device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
  	revision_time TIMESTAMP(6) NOT NULL,
  	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

