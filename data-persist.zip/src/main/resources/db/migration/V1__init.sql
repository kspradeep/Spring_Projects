DROP TABLE IF EXISTS managed_object;
CREATE TABLE IF NOT EXISTS managed_object (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	object_type VARCHAR(255) NOT NULL,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
  	last_updated_time TIMESTAMP(6) NOT NULL,
  	PRIMARY KEY (id),
  	INDEX (object_type),
  	INDEX (name)
);

DROP TABLE IF EXISTS device;
CREATE TABLE IF NOT EXISTS device (
    id BIGINT(20) NOT NULL,
	stablenet_id BIGINT(20) NOT NULL,
	openflow_id VARCHAR(255),
  	model VARCHAR(255),
  	type VARCHAR(25) NOT NULL,
  	mode VARCHAR(25) NOT NULL,
  	os VARCHAR(255),
  	ip_address VARCHAR(255) NOT NULL,
  	description TEXT,
  	last_collected_time TIMESTAMP(6) NOT NULL,
  	is_deleted BIT(1) NOT NULL,
  	system_description TEXT,
   	PRIMARY KEY (id),
   	UNIQUE KEY (stablenet_id),
   	FOREIGN KEY (id)
   	    REFERENCES managed_object (id)
   	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS module;
CREATE TABLE IF NOT EXISTS module (
	id BIGINT(20) NOT NULL,
	device_id BIGINT(20) NOT NULL,
	stablenet_id BIGINT(20) NOT NULL,
	serial_number VARCHAR(255) NOT NULL,
	module_number INT NOT NULL,
	type VARCHAR(100),
	PRIMARY KEY (id),
	UNIQUE KEY (device_id, stablenet_id),
	FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
	FOREIGN KEY (device_id)
	    REFERENCES device (id)
	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS module_policy;
CREATE TABLE IF NOT EXISTS module_policy (
    id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS module_policy_mapping;
CREATE TABLE IF NOT EXISTS module_policy_mapping (
	module_id BIGINT(20) NOT NULL,
	module_policy_id BIGINT(20) NOT NULL,
	FOREIGN KEY (module_id)
        	REFERENCES module (id)
        	ON DELETE CASCADE,
     FOREIGN KEY (module_policy_id)
         	REFERENCES module_policy (id)
         	ON DELETE CASCADE
);


DROP TABLE IF EXISTS load_balance_module_policy;
CREATE TABLE IF NOT EXISTS load_balance_module_policy (
    id BIGINT(20) NOT NULL,
    is_source_ip_included BIT(1) NOT NULL,
    is_source_port_included BIT(1) NOT NULL,
    is_dest_ip_included BIT(1) NOT NULL,
    is_dest_port_included BIT(1) NOT NULL,
    is_teid_included BIT(1) NOT NULL,
    is_inner_ip_included BIT(1) NOT NULL,
    is_protocol_mask_included BIT(1) NOT NULL,
    is_bidirectional BIT(1) NOT NULL,
    tunneling_protocol VARCHAR(255) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS load_balance_module_policy_history;
CREATE TABLE IF NOT EXISTS load_balance_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS header_stripping_module_policy;
CREATE TABLE IF NOT EXISTS header_stripping_module_policy (
    id BIGINT(20) NOT NULL,
    processor_number VARCHAR(25) NOT NULL,
    header VARCHAR(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS header_stripping_module_policy_history;
CREATE TABLE IF NOT EXISTS header_stripping_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS packet_stamping_module_policy;
CREATE TABLE IF NOT EXISTS packet_stamping_module_policy (
    id BIGINT(20) NOT NULL,
    processor_number VARCHAR(25) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_stamping_module_policy_history;
CREATE TABLE IF NOT EXISTS packet_stamping_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS packet_slicing_module_policy;
CREATE TABLE IF NOT EXISTS packet_slicing_module_policy (
    id BIGINT(20) NOT NULL,
    number_of_bytes INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_slicing_port_mapping;
CREATE TABLE IF NOT EXISTS packet_slicing_port_mapping (
	module_policy_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (module_policy_id)
    	REFERENCES module_policy (id)
    	ON DELETE CASCADE,
	FOREIGN KEY (managed_object_id)
    	REFERENCES managed_object (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS packet_slicing_module_policy_history;
CREATE TABLE IF NOT EXISTS packet_slicing_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS port;
CREATE TABLE IF NOT EXISTS port (
  	id BIGINT(20) NOT NULL,
  	module_id BIGINT(20) NOT NULL,
  	stablenet_id BIGINT(20) NOT NULL,
  	stablenet_index BIGINT(20) NOT NULL,
  	openflow_id VARCHAR(255),
  	physical_address VARCHAR(255),
  	link_status VARCHAR(25),
  	admin_status VARCHAR(25),
  	description TEXT,
  	PRIMARY KEY (id),
  	UNIQUE KEY (module_id, stablenet_id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
  	FOREIGN KEY (module_id)
  	    REFERENCES module (id)
  	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS port_bvm_defined;
CREATE TABLE IF NOT EXISTS port_bvm_defined (
  	id BIGINT(20) NOT NULL,
  	description VARCHAR(255),
  	type VARCHAR(25),
  	mode VARCHAR(25),
  	admin_status VARCHAR(25),
  	last_updated_time TIMESTAMP(6) NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
  	    REFERENCES port (id)
  	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS port_history;
CREATE TABLE IF NOT EXISTS port_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    mode VARCHAR(25),
    name VARCHAR(255),
    workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
    revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS port_group;
CREATE TABLE IF NOT EXISTS port_group (
	id BIGINT(20) NOT NULL,
	device_id BIGINT(20) NOT NULL,
	primary_port_id BIGINT(20) NULL,
	gtp_device_policy_id BIGINT(20),
	PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
	FOREIGN KEY (device_id)
		REFERENCES device (id)
		ON DELETE CASCADE,
	FOREIGN KEY (primary_port_id)
		REFERENCES port (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS port_group_history;
CREATE TABLE IF NOT EXISTS port_group_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    port_group_json LONGTEXT,
    name VARCHAR(255),
    workflow_status VARCHAR(25),
    workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
    revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS port_portgroup_mapping;
CREATE TABLE IF NOT EXISTS port_portgroup_mapping (
	port_group_id BIGINT(20) NOT NULL,
	port_id BIGINT(20) NOT NULL,
	FOREIGN KEY (port_group_id)
		REFERENCES port_group (id)
		ON DELETE CASCADE,
	FOREIGN KEY (port_id)
		REFERENCES port (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS policy;
CREATE TABLE IF NOT EXISTS policy (
	id BIGINT(20) NOT NULL,
	device_id BIGINT(20) NOT NULL,
	field_offset_1 BIGINT(20),
	field_offset_2 BIGINT(20),
	field_offset_3 BIGINT(20),
	field_offset_4 BIGINT(20),
	is_loopback BIT(1) NOT NULL,
	gtp_device_policy_id BIGINT(20),
	PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
	FOREIGN KEY (device_id)
		REFERENCES device (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS policy_history;
CREATE TABLE IF NOT EXISTS policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS flow;
CREATE TABLE IF NOT EXISTS flow (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	policy_id BIGINT(20) NOT NULL,
	sequence INT NOT NULL,
	source_mac_tag VARCHAR(25),
	destination_mac_tag VARCHAR(25),
	is_tagged BIT(1) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (policy_id)
		REFERENCES policy (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS flow_vlan_mapping;
CREATE TABLE IF NOT EXISTS flow_vlan_mapping (
	vlan_id VARCHAR(20) NOT NULL, -- Mlxe accepts 'any'
	flow_id BIGINT(20) NOT NULL,
	FOREIGN KEY (flow_id)
		REFERENCES flow (id)
	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS flow_tunnel_mapping;
CREATE TABLE IF NOT EXISTS flow_tunnel_mapping (
	flow_id BIGINT(20) NOT NULL,
	tunnel_id BIGINT(20) NOT NULL,
	order_index INT NOT NULL,
	FOREIGN KEY (flow_id)
		REFERENCES flow (id)
	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS flow_port_mapping_ingress;
CREATE TABLE IF NOT EXISTS flow_port_mapping_ingress (
	flow_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (flow_id)
    	REFERENCES flow (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS flow_port_mapping_egress;
CREATE TABLE IF NOT EXISTS flow_port_mapping_egress (
	flow_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (flow_id)
    	REFERENCES flow (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS ruleset;
CREATE TABLE IF NOT EXISTS ruleset (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	flow_id BIGINT(20) NOT NULL,
  	type VARCHAR(15) NOT NULL,
  	ip_version VARCHAR(2),
  	sequence INT NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (flow_id)
    	REFERENCES flow (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS rule;
CREATE TABLE IF NOT EXISTS rule (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	ruleset_id BIGINT(20) NOT NULL,
  	source_ip VARCHAR(255),
  	destination_ip VARCHAR(255),
  	source_port INT,
  	source_port_operator VARCHAR(25),
  	destination_port INT,
  	destination_port_operator VARCHAR(25),
  	vlan_id INT(4),
  	protocol VARCHAR(25),
  	protocol_type VARCHAR(25),
  	is_permit BIT(1) NOT NULL,
  	custom_acl TEXT,
  	source_mac VARCHAR(255),
  	source_mac_mask VARCHAR(255),
  	destination_mac VARCHAR(255),
  	destination_mac_mask VARCHAR(255),
  	eth_type VARCHAR(255),
  	sequence INT NOT NULL,
  	field_mask_1 VARCHAR(255),
  	field_mask_2 VARCHAR(255),
  	field_mask_3 VARCHAR(255),
  	field_mask_4 VARCHAR(255),
  	field_value_1 VARCHAR(255),
  	field_value_2 VARCHAR(255),
  	field_value_3 VARCHAR(255),
  	field_value_4 VARCHAR(255),
 	PRIMARY KEY (id),
 	FOREIGN KEY (ruleset_id)
    	REFERENCES ruleset (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS device_policy;
CREATE TABLE IF NOT EXISTS device_policy(
	id BIGINT(20) NOT NULL,
	device_id BIGINT(20) NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
	FOREIGN KEY (device_id)
		REFERENCES device (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_filter_policy;
CREATE TABLE IF NOT EXISTS sd_filter_policy (
	id BIGINT(20) NOT NULL,
    sequence INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_filter_policy_history;
CREATE TABLE IF NOT EXISTS sd_filter_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(25),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS gtp_device_policy;
CREATE TABLE IF NOT EXISTS gtp_device_policy (
    id BIGINT(20) NOT NULL,
    profile_id BIGINT(20) NOT NULL,
    is_gtpc_teid_enabled BIT(1) NOT NULL,
    is_gtpu_l3_enabled BIT(1) NOT NULL,
    is_gtpu_teid_enabled BIT(1) NOT NULL,
    description TEXT,
    PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);


DROP TABLE IF EXISTS gtp_device_policy_history;
CREATE TABLE IF NOT EXISTS gtp_device_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_policy_json LONGTEXT,
    device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS mpls_device_policy;
CREATE TABLE IF NOT EXISTS mpls_device_policy (
    id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);


DROP TABLE IF EXISTS mpls_port_pair;
CREATE TABLE IF NOT EXISTS mpls_port_pair (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    device_policy_id BIGINT(20) NOT NULL,
    ingress_port_id BIGINT(20) NOT NULL,
    egress_port_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_policy_id)
            REFERENCES mpls_device_policy (id)
            ON DELETE CASCADE,
    FOREIGN KEY (ingress_port_id)
            REFERENCES port (id)
            ON DELETE CASCADE,
    FOREIGN KEY (egress_port_id)
            REFERENCES port (id)
            ON DELETE CASCADE
);

DROP TABLE IF EXISTS mpls_device_policy_history;
CREATE TABLE IF NOT EXISTS mpls_device_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_policy_json LONGTEXT,
    device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS tunnel_device_policy;
CREATE TABLE IF NOT EXISTS tunnel_device_policy (
    id BIGINT(20) NOT NULL,
    type VARCHAR(25) NOT NULL,
    is_enabled BIT(1) NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS tunnel_device_policy_history;
CREATE TABLE IF NOT EXISTS tunnel_device_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_policy_json LONGTEXT,
    device_id BIGINT(20) NOT NULL,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_imsi_policy;
CREATE TABLE IF NOT EXISTS sd_imsi_policy (
	id BIGINT(20) NOT NULL,
	drop_rate INT,
	is_sampling_enable BIT(1) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_imsi_policy_history;
CREATE TABLE IF NOT EXISTS sd_imsi_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(25),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_dedupe_policy;
CREATE TABLE IF NOT EXISTS sd_dedupe_policy (
	id BIGINT(20) NOT NULL,
	timeout INT,
	is_dedupe_enable BIT(1) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_dedupe_policy_history;
CREATE TABLE IF NOT EXISTS sd_dedupe_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(25),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_load_balance_policy;
CREATE TABLE IF NOT EXISTS sd_load_balance_policy (
	id BIGINT(20) NOT NULL,
	lb_algorithm VARCHAR(10),
	PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_load_balance_policy_history;
CREATE TABLE IF NOT EXISTS sd_load_balance_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(25),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_port_group;
CREATE TABLE IF NOT EXISTS sd_port_group (
	id BIGINT(20) NOT NULL,
	pb_device_id BIGINT(20) NOT NULL,
	sequence INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id)
        REFERENCES device_policy (id)
        ON DELETE CASCADE,
    FOREIGN KEY (pb_device_id)
    		REFERENCES device (id)
    		ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_pb_port;
CREATE TABLE IF NOT EXISTS sd_pb_port (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	sd_port_group_id BIGINT(20) NOT NULL,
	port_id BIGINT(20) NOT NULL,
	vlan INT,
	interface_name VARCHAR(10),
	imsi_limit VARCHAR(20),
	sequence INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (sd_port_group_id)
        REFERENCES sd_port_group (id)
        ON DELETE CASCADE,
    FOREIGN KEY (port_id)
    		REFERENCES port (id)
    		ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_port_group_history;
CREATE TABLE IF NOT EXISTS sd_port_group_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    device_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(25),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS sd_ruleset;
CREATE TABLE IF NOT EXISTS sd_ruleset (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	sd_policy_id BIGINT(20) NOT NULL,
  	sequence INT NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (sd_policy_id)
    	REFERENCES sd_filter_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS sd_rule;
CREATE TABLE IF NOT EXISTS sd_rule (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	sd_ruleset_id BIGINT(20) NOT NULL,
    sequence INT NOT NULL,
    priority INT,
    apn VARCHAR(256),
    is_apn_include_all BIT(1) NOT NULL,
    imsi VARCHAR(25),
    imsi_range INT,
    qci INT,
    is_permit BIT(1) NOT NULL,
    vlan_id INT,
 	PRIMARY KEY (id),
    FOREIGN KEY (sd_ruleset_id)
    	REFERENCES sd_ruleset (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS job;
CREATE TABLE IF NOT EXISTS job (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    device_id BIGINT(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(25) NOT NULL,
    external_job_id BIGINT(20),
    parent_object_id BIGINT(20),
    job_result LONGTEXT,
    created_by VARCHAR(255) NOT NULL,
    created_time TIMESTAMP(6) NOT NULL,
    last_updated_time TIMESTAMP(6) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS job_object_mapping;
CREATE TABLE IF NOT EXISTS job_object_mapping (
    job_id BIGINT(20) NOT NULL,
    impacted_object_id BIGINT(20) NOT NULL,
    FOREIGN KEY (job_id)
        REFERENCES job (id)
        ON DELETE CASCADE,
    FOREIGN KEY (impacted_object_id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS event;
CREATE TABLE IF NOT EXISTS event (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    status VARCHAR(25) NOT NULL,
    created_time TIMESTAMP(6) NOT NULL,
    last_updated_time TIMESTAMP(6) NOT NULL,
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS event_job_mapping;
CREATE TABLE IF NOT EXISTS event_job_mapping (
    event_id BIGINT(20) NOT NULL,
    job_id BIGINT(20) NOT NULL,
    FOREIGN KEY (event_id)
        REFERENCES event (id)
        ON DELETE CASCADE,
    FOREIGN KEY (job_id)
        REFERENCES job (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS application_user;
CREATE TABLE IF NOT EXISTS application_user (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    temporary_token VARCHAR(255),
    token_generated_time TIMESTAMP(6),
    PRIMARY KEY(id)
);

DROP TABLE IF EXISTS application_config;
CREATE TABLE IF NOT EXISTS application_config (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    config_key VARCHAR(255) NOT NULL,
    config_value VARCHAR(255),
    PRIMARY KEY(id),
    UNIQUE KEY (config_key)
);
