DROP TABLE IF EXISTS target_host;
CREATE TABLE IF NOT EXISTS target_host (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	object_type VARCHAR(255) NOT NULL,
  	mode VARCHAR(25) NOT NULL,
  	ip_address VARCHAR(255) NOT NULL,
  	last_updated_time TIMESTAMP(6) NOT NULL,
  	PRIMARY KEY (id)
);

-- migration script for converting managed object -> device to target host -> device
ALTER TABLE device DROP FOREIGN KEY device_ibfk_1;
INSERT INTO target_host (id, name, last_updated_time, object_type, ip_address, mode)
    SELECT m.id, m.name, m.last_updated_time, m.object_type, d.ip_address, d.mode
    FROM managed_object m JOIN device d WHERE d.id = m.id AND m.object_type = 'device';
--updating the foreign key ref in device from managed object to device object
ALTER TABLE device ADD FOREIGN KEY (id) REFERENCES  target_host (id) ON DELETE CASCADE;

--remove the migrated columns on the device as they are moved to target host
ALTER TABLE device DROP COLUMN ip_address;
ALTER TABLE device DROP COLUMN mode;

--delete the migrated device entries from the managed object
DELETE FROM managed_object WHERE object_type='device';

-- migration script for updating the relation of job -> device  to job -> target host
ALTER TABLE job CHANGE device_id target_host_id BIGINT;
ALTER TABLE job DROP FOREIGN KEY job_ibfk_1;
ALTER TABLE job ADD FOREIGN KEY (target_host_id) REFERENCES target_host (id) ON DELETE CASCADE;

ALTER TABLE port ADD column line_speed BIGINT(20) DEFAULT NULL;
ALTER TABLE port ADD column max_speed BIGINT(20) DEFAULT NULL;
ALTER TABLE port_group ADD column line_speed BIGINT(20) DEFAULT NULL;
ALTER TABLE port_history ADD column line_speed BIGINT(20) DEFAULT NULL;

ALTER TABLE application_config MODIFY config_value VARCHAR(2000);

DROP TABLE IF EXISTS collector_running_status;
CREATE TABLE IF NOT EXISTS collector_running_status (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	PRIMARY KEY (id),
	is_running BIT(1) NOT NULL
);

DROP TABLE IF EXISTS cloud_instance;
CREATE TABLE IF NOT EXISTS cloud_instance (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (id),
  	FOREIGN KEY (id)
        REFERENCES target_host (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS cloud_tenant;
CREATE TABLE IF NOT EXISTS cloud_tenant (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
    external_id VARCHAR(255),
    cloud_instance_id BIGINT(20) NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (cloud_instance_id)
        REFERENCES cloud_instance (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS compute_node;
CREATE TABLE IF NOT EXISTS compute_node (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
    external_id VARCHAR(255),
	hostname VARCHAR(255),
	availability_zone VARCHAR(255),
	cloud_instance_id BIGINT(20) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (cloud_instance_id)
        REFERENCES cloud_instance (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS virtual_machine;
CREATE TABLE IF NOT EXISTS virtual_machine (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	external_id VARCHAR(255),
    cloud_tenant_id BIGINT(20) NOT NULL,
	compute_node_id BIGINT(20) NOT NULL,
	is_deleted BIT(1) NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (cloud_tenant_id)
        REFERENCES cloud_tenant (id)
        ON DELETE CASCADE,
	FOREIGN KEY (compute_node_id)
        REFERENCES compute_node (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS virtual_network;
CREATE TABLE IF NOT EXISTS virtual_network (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	external_id VARCHAR(255),
    is_shared BIT(1) NOT NULL,
    cloud_instance_id BIGINT(20),
    PRIMARY KEY(id),
    FOREIGN KEY (cloud_instance_id)
        REFERENCES cloud_instance (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS virtual_port;
CREATE TABLE IF NOT EXISTS virtual_port (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
    external_id VARCHAR(255),
    ip_address VARCHAR(50),
    floating_ip_address VARCHAR(50),
    port_type VARCHAR(255),
    mac_address VARCHAR(50),
    virtual_machine_id BIGINT(20) NOT NULL,
    virtual_network_id BIGINT(20) NOT NULL,
    is_deleted BIT(1) NOT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (virtual_machine_id)
        REFERENCES virtual_machine (id)
        ON DELETE CASCADE,
    FOREIGN KEY (virtual_network_id)
        REFERENCES virtual_network (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_policyset;
CREATE TABLE IF NOT EXISTS openstack_policyset (
	id BIGINT(20) NOT NULL,
	-- sequence INT NOT NULL,
	virtual_tap_id BIGINT(20),
	source_vm_id BIGINT(20) NOT NULL,
	tap_port_id BIGINT(20) NOT NULL,
	vlan_id int,
	PRIMARY KEY (id),
	FOREIGN KEY (source_vm_id)
        REFERENCES virtual_machine (id)
        ON DELETE CASCADE,
	FOREIGN KEY (tap_port_id)
        REFERENCES virtual_port (id)
        ON DELETE CASCADE,
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
    FOREIGN KEY (virtual_tap_id)
         REFERENCES virtual_machine (id)
);

DROP TABLE IF EXISTS openstack_policy;
CREATE TABLE IF NOT EXISTS openstack_policy (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	sequence INT NOT NULL,
	policyset_id BIGINT(20) NOT NULL,
	destination_vm_id BIGINT(20) NOT NULL,
	destination_port_id BIGINT(20) NOT NULL,
	tunnel_id int,
	PRIMARY KEY (id),
	FOREIGN KEY (policyset_id)
		REFERENCES openstack_policyset (id)
		ON DELETE CASCADE,
	FOREIGN KEY (destination_vm_id)
        REFERENCES virtual_machine (id)
        ON DELETE CASCADE,
	FOREIGN KEY (destination_port_id)
        REFERENCES virtual_port (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_ruleset;
CREATE TABLE IF NOT EXISTS openstack_ruleset (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	policy_id BIGINT(20) NOT NULL,
  	sequence INT NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (policy_id)
    	REFERENCES openstack_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_basic_ruleset;
CREATE TABLE IF NOT EXISTS openstack_basic_ruleset (
  	id BIGINT(20) NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
        REFERENCES openstack_ruleset (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_advanced_ruleset;
CREATE TABLE IF NOT EXISTS openstack_advanced_ruleset (
  	id BIGINT(20) NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (id)
        REFERENCES openstack_ruleset (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_basic_rule;
CREATE TABLE IF NOT EXISTS openstack_basic_rule (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	sequence INT NOT NULL,
  	priority INT NOT NULL,
  	method_type VARCHAR(25),
	hostname VARCHAR(255),
	direction VARCHAR(25),
    is_permit BIT(1) NOT NULL,
	source_ip VARCHAR(50),
	destination_ip VARCHAR(50),
    eth_type VARCHAR(25),
    source_mac VARCHAR(255),
    source_mac_mask VARCHAR(255),
    destination_mac VARCHAR(255),
    destination_mac_mask VARCHAR(255),
    source_port INT,
    destination_port INT,
    protocol_type VARCHAR(25),
    priority_old INT,
	source_ip_old VARCHAR(50),
    destination_ip_old VARCHAR(50),
    eth_type_old VARCHAR(25),
    source_mac_old VARCHAR(255),
    source_mac_mask_old VARCHAR(255),
    destination_mac_old VARCHAR(255),
    destination_mac_mask_old VARCHAR(255),
    source_port_old INT,
    destination_port_old INT,
    protocol_type_old VARCHAR(25),
    ruleset_id BIGINT(20) NOT NULL,
 	PRIMARY KEY (id),
    FOREIGN KEY (ruleset_id)
        REFERENCES openstack_basic_ruleset (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS openstack_advanced_rule;
CREATE TABLE IF NOT EXISTS openstack_advanced_rule (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	rule_id BIGINT(20),
  	sequence INT NOT NULL,
  	is_permit BIT(1) NOT NULL,
  	priority INT NOT NULL,
  	ruleset_id BIGINT(20) NOT NULL,
	field_offset_1 INT,
    field_offset_2 INT,
    field_offset_3 INT,
    field_offset_4 INT,
  	field_value_1 VARCHAR(255),
  	field_value_2 VARCHAR(255),
  	field_value_3 VARCHAR(255),
  	field_value_4 VARCHAR(255),
  	header_strip_ip_type VARCHAR(25),
  	header_strip VARCHAR(25),
  	packet_slicing_ip_type VARCHAR(25),
  	packet_slicing INT,
 	PRIMARY KEY (id),
 	FOREIGN KEY (ruleset_id)
        REFERENCES openstack_advanced_ruleset (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS tap_policy_history;
CREATE TABLE IF NOT EXISTS tap_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS slx_load_balance_module_policy;
CREATE TABLE IF NOT EXISTS slx_load_balance_module_policy (
    id BIGINT(20) NOT NULL,
    applied_load_balance_policy VARCHAR(30) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES module_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS slx_load_balance_module_policy_history;
CREATE TABLE IF NOT EXISTS slx_load_balance_module_policy_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id BIGINT(20) NOT NULL,
    module_policy_json LONGTEXT,
    name VARCHAR(255),
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25) NOT NULL,
    PRIMARY KEY (id)
);