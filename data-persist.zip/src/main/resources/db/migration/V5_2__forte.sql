
ALTER TABLE grid_matrix DROP column destination_device_id;

ALTER TABLE grid_topology_path MODIFY tool_address INT NULL;

DROP TABLE IF EXISTS matrix_destination_device_mapping;
CREATE TABLE IF NOT EXISTS matrix_destination_device_mapping (
    matrix_id BIGINT(20) NOT NULL,
	destination_device_id BIGINT(20) NOT NULL,
	FOREIGN KEY (matrix_id)
		REFERENCES grid_matrix (id)
	    ON DELETE CASCADE
);
