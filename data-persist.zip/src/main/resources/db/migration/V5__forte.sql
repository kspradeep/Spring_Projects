ALTER TABLE device ADD COLUMN chassis VARCHAR(100);
ALTER TABLE device ADD COLUMN is_profile_configured BIT NOT NULL DEFAULT 0;
ALTER TABLE device ADD COLUMN is_tacacs_configured BIT NOT NULL DEFAULT 0;

ALTER TABLE policy ADD column is_grid_policy BIT(1) NOT NULL DEFAULT 0;

ALTER TABLE job ADD COLUMN created_by_pwd VARCHAR(255);

ALTER TABLE event add column target_host VARCHAR(200);
ALTER TABLE event add column parent_object_id BIGINT(20);
ALTER TABLE event add column type VARCHAR(150);
ALTER TABLE event add column job_status VARCHAR(50);
ALTER TABLE event add column job_severity VARCHAR(50);
ALTER TABLE event add column created_by VARCHAR(100);
ALTER TABLE event add column result LONGTEXT;

DROP TABLE IF EXISTS device_grid;
CREATE TABLE IF NOT EXISTS device_grid (
    id BIGINT(20) NOT NULL,
    name VARCHAR(255),
    description VARCHAR(255),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS device_grid_history;
CREATE TABLE IF NOT EXISTS device_grid_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    device_grid_id BIGINT(20) NOT NULL,
    grid_json LONGTEXT,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS grid_cluster;
CREATE TABLE IF NOT EXISTS grid_cluster (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    device_id BIGINT(20) NOT NULL,
    grid_source_id BIGINT(20),
    grid_destination_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (grid_source_id)
        REFERENCES device_grid (id)
        ON DELETE CASCADE,
    FOREIGN KEY (grid_destination_id)
        REFERENCES device_grid (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS cluster_node_interface;
CREATE TABLE IF NOT EXISTS cluster_node_interface (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    grid_cluster_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (grid_cluster_id)
        REFERENCES grid_cluster (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS cluster_node_port_mapping;
CREATE TABLE IF NOT EXISTS cluster_node_port_mapping (
	cluster_node_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (cluster_node_id)
    	REFERENCES cluster_node_interface (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_matrix;
CREATE TABLE IF NOT EXISTS grid_matrix (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    failure_count INT,
    grid_topology_path_id BIGINT(20),
    grid_policy_set_id BIGINT(20),
    policy_id BIGINT(20),
    source_device_id BIGINT(20),
    destination_device_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_matrix_history;
CREATE TABLE IF NOT EXISTS grid_matrix_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    grid_policy_set_id BIGINT(20) NOT NULL,
    policy_id BIGINT(20),
    grid_matrix_json LONGTEXT,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS grid_topology_path;
CREATE TABLE IF NOT EXISTS grid_topology_path (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    policy_set_id BIGINT(20) NOT NULL,
    path_id BIGINT(20) NOT NULL,
    bandwidth BIGINT(20),
    tool_address INT NOT NULL,
    is_active BIT(1) NOT NULL DEFAULT 0,
    is_cspf_enabled BIT(1) NOT NULL DEFAULT 0,
    path_json LONGTEXT,
    grid_matrix_id BIGINT(20) NOT NULL,
    tool_node_interface_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (grid_matrix_id)
        REFERENCES grid_matrix (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS tap_node_interface_mapping;
CREATE TABLE IF NOT EXISTS tap_node_interface_mapping (
	topology_path_id BIGINT(20) NOT NULL,
	tap_node_interface_id BIGINT(20) NOT NULL,
	FOREIGN KEY (topology_path_id)
    	REFERENCES grid_topology_path (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS intermediate_node;
CREATE TABLE IF NOT EXISTS intermediate_node (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    sequence INT,
    device_id BIGINT(20) NOT NULL,
    grid_topology_path_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (grid_topology_path_id)
        REFERENCES grid_topology_path (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS network_node;
CREATE TABLE IF NOT EXISTS network_node (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    sequence INT,
    device_id BIGINT(20) NOT NULL,
    grid_topology_source_id BIGINT(20),
    grid_topology_destination_id BIGINT(20),
    PRIMARY KEY (id),
    FOREIGN KEY (device_id)
        REFERENCES device (id)
        ON DELETE CASCADE,
    FOREIGN KEY (grid_topology_source_id)
        REFERENCES grid_topology_path (id)
        ON DELETE CASCADE,
    FOREIGN KEY (grid_topology_destination_id)
        REFERENCES grid_topology_path (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS network_node_interface_mapping_ingress;
CREATE TABLE IF NOT EXISTS network_node_interface_mapping_ingress (
	node_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (node_id)
    	REFERENCES network_node (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS network_node_interface_mapping_egress;
CREATE TABLE IF NOT EXISTS network_node_interface_mapping_egress (
	node_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (node_id)
    	REFERENCES network_node (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS intermediate_node_interface_mapping_ingress;
CREATE TABLE IF NOT EXISTS intermediate_node_interface_mapping_ingress (
	node_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (node_id)
    	REFERENCES intermediate_node (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS intermediate_node_interface_mapping_egress;
CREATE TABLE IF NOT EXISTS intermediate_node_interface_mapping_egress (
	node_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (node_id)
    	REFERENCES intermediate_node (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_policy_set;
CREATE TABLE IF NOT EXISTS grid_policy_set (
	id BIGINT(20) NOT NULL,
	grid_id BIGINT(20) NOT NULL,
	field_offset_1 BIGINT(20),
	field_offset_2 BIGINT(20),
	field_offset_3 BIGINT(20),
	field_offset_4 BIGINT(20),
	is_loopback BIT(1) NOT NULL,
	is_cspf_enabled BIT(1) NOT NULL DEFAULT 0,
	is_over_subscription_allowed BIT(1) NOT NULL DEFAULT 0,
	is_gtp_http_filtered BIT(1) NOT NULL DEFAULT 0,
	is_ingress_valid BIT(1) NOT NULL DEFAULT 0,
	is_timestamp BIT(1) NOT NULL DEFAULT 0,
	preserve_header BIT(1) NOT NULL DEFAULT 0,
	gtp_device_policy_id BIGINT(20),
	egress_action VARCHAR(10),
	PRIMARY KEY (id),
    FOREIGN KEY (id)
        REFERENCES managed_object (id)
        ON DELETE CASCADE,
	FOREIGN KEY (grid_id)
		REFERENCES device_grid (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_policy_set_history;
CREATE TABLE IF NOT EXISTS grid_policy_set_history (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    parent_id BIGINT(20) NOT NULL,
    grid_id BIGINT(20) NOT NULL,
    policy_json LONGTEXT,
  	workflow_status VARCHAR(25),
  	workflow_type VARCHAR(50),
    revision_time TIMESTAMP(6) NOT NULL,
   	revision_type VARCHAR(25),
    PRIMARY KEY (id)
);

DROP TABLE IF EXISTS grid_policy;
CREATE TABLE IF NOT EXISTS grid_policy (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	sequence INT NOT NULL,
	is_default_route_map_drop BIT(1) NOT NULL DEFAULT 0,
	tvf_domain BIT(1) NOT NULL DEFAULT 0,
	vlan_stripping BIT(1) NOT NULL DEFAULT 0,
	source_mac_tag VARCHAR(25),
	destination_mac_tag VARCHAR(25),
	is_tagged BIT(1) NOT NULL,
	tagged_vlan_id INTEGER(20),
	grid_policyset_id BIGINT(20) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (grid_policyset_id)
		REFERENCES grid_policy_set (id)
		ON DELETE CASCADE
);

DROP TABLE IF EXISTS policy_port_mapping_ingress;
CREATE TABLE IF NOT EXISTS policy_port_mapping_ingress (
	policy_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
    	REFERENCES grid_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS policy_port_mapping_egress;
CREATE TABLE IF NOT EXISTS policy_port_mapping_egress (
	policy_id BIGINT(20) NOT NULL,
	managed_object_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
    	REFERENCES grid_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_ruleset;
CREATE TABLE IF NOT EXISTS grid_ruleset (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	policy_id BIGINT(20) NOT NULL,
  	type VARCHAR(15) NOT NULL,
  	ip_version VARCHAR(2),
  	sequence INT NOT NULL,
  	PRIMARY KEY (id),
  	FOREIGN KEY (policy_id)
    	REFERENCES grid_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_rule;
CREATE TABLE IF NOT EXISTS grid_rule (
  	id BIGINT(20) NOT NULL AUTO_INCREMENT,
  	name VARCHAR(255),
  	ruleset_id BIGINT(20) NOT NULL,
  	source_ip VARCHAR(255),
  	destination_ip VARCHAR(255),
  	source_port INT,
  	source_port_operator VARCHAR(25),
  	destination_port INT,
  	destination_port_operator VARCHAR(25),
  	vlan_id INT(4),
  	protocol VARCHAR(25),
  	protocol_type VARCHAR(25),
  	is_permit BIT(1) NOT NULL,
  	custom_acl TEXT,
  	source_mac VARCHAR(255),
  	source_mac_mask VARCHAR(255),
  	destination_mac VARCHAR(255),
  	destination_mac_mask VARCHAR(255),
  	eth_type VARCHAR(255),
  	sequence BIGINT NOT NULL,
  	is_count_enabled BIT NOT NULL DEFAULT 0,
  	is_match_payload_length BIT NOT NULL DEFAULT 0,
  	field_mask_1 VARCHAR(255),
  	field_mask_2 VARCHAR(255),
  	field_mask_3 VARCHAR(255),
  	field_mask_4 VARCHAR(255),
  	field_value_1 VARCHAR(255),
  	field_value_2 VARCHAR(255),
  	field_value_3 VARCHAR(255),
  	field_value_4 VARCHAR(255),
  	byte_size_1 INT,
    byte_size_2 INT,
    byte_size_3 INT,
    byte_size_4 INT,
    is_hexadecimal_type_1 BIT(1) NOT NULL DEFAULT 1,
    is_hexadecimal_type_2 BIT(1) NOT NULL DEFAULT 1,
    is_hexadecimal_type_3 BIT(1) NOT NULL DEFAULT 1,
    is_hexadecimal_type_4 BIT(1) NOT NULL DEFAULT 1,
 	PRIMARY KEY (id),
 	FOREIGN KEY (ruleset_id)
    	REFERENCES grid_ruleset (id)
    	ON DELETE CASCADE
);


DROP TABLE IF EXISTS flow_managed_object_egress;
CREATE TABLE IF NOT EXISTS flow_managed_object_egress (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	name VARCHAR(255),
	precedence INT,
	tvf_domain_id VARCHAR(20),
	managed_object_id BIGINT(20) NOT NULL,
	flow_id BIGINT(20) NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (managed_object_id)
		REFERENCES managed_object (id)
		ON DELETE CASCADE,
	FOREIGN KEY (flow_id)
		REFERENCES flow (id)
		ON DELETE CASCADE
);

INSERT INTO flow_managed_object_egress (managed_object_id, flow_id, precedence)
SELECT f.managed_object_id, f.flow_id, 0 FROM flow_port_mapping_egress f WHERE f.managed_object_id IS NOT NULL AND f.flow_id IS NOT NULL;


DROP TABLE IF EXISTS grid_template_policy_mapping;
CREATE TABLE IF NOT EXISTS grid_template_policy_mapping (
	policy_set_id BIGINT(20) NOT NULL,
	template_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_set_id)
        REFERENCES grid_policy_set (id)
        ON DELETE CASCADE,
     FOREIGN KEY (template_id)
        REFERENCES template_policy (id)
        ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_policy_vlan_mapping;
CREATE TABLE IF NOT EXISTS grid_policy_vlan_mapping (
	vlan_id VARCHAR(20) NOT NULL,
	policy_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
		REFERENCES grid_policy (id)
	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_policy_cluster_node_mapping_ingress;
CREATE TABLE IF NOT EXISTS grid_policy_cluster_node_mapping_ingress (
	policy_id BIGINT(20) NOT NULL,
	cluster_node_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
    	REFERENCES grid_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS grid_policy_cluster_node_mapping_egress;
CREATE TABLE IF NOT EXISTS grid_policy_cluster_node_mapping_egress (
	policy_id BIGINT(20) NOT NULL,
	cluster_node_id BIGINT(20) NOT NULL,
	FOREIGN KEY (policy_id)
    	REFERENCES grid_policy (id)
    	ON DELETE CASCADE
);

DROP TABLE IF EXISTS destination_group;
CREATE TABLE IF NOT EXISTS destination_group (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    group_id INT NOT NULL,
    grid_matrix_id BIGINT(20) NOT NULL,
    PRIMARY KEY (id),
	FOREIGN KEY (grid_matrix_id)
		REFERENCES grid_matrix (id)
	    ON DELETE CASCADE
);

DROP TABLE IF EXISTS group_path_address_topology_mapping;
CREATE TABLE IF NOT EXISTS group_path_address_topology_mapping (
    destination_group_id BIGINT(20) NOT NULL,
	grid_topology_path_id BIGINT(20) NOT NULL,
	FOREIGN KEY (destination_group_id)
		REFERENCES destination_group (id)
	    ON DELETE CASCADE
);


DROP TABLE IF EXISTS collector_device_mapping;
CREATE TABLE collector_device_mapping (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	device_id BIGINT(20),
	profile_type VARCHAR(255) NOT NULL,
	PRIMARY KEY (id)
);

DROP TABLE IF EXISTS system_utilization_statistics;
CREATE TABLE system_utilization_statistics (
	id BIGINT(20) NOT NULL,
	collector_device_id BIGINT(20) NOT NULL,
	last_updated_time TIMESTAMP(6) NOT NULL,
	total_system_memory BIGINT(20) NOT NULL,
	total_used_memory BIGINT(20) NOT NULL,
	total_free_memory BIGINT(20) NOT NULL,
	cached_memory BIGINT(20) NOT NULL,
	buffers BIGINT(20) NOT NULL,
	user_free_memory BIGINT(20) NOT NULL,
	kernel_free_memory BIGINT(20) NOT NULL,
	user_process BIGINT(20) NOT NULL,
	system_process BIGINT(20) NOT NULL,
	idle_state BIGINT(20) NOT NULL,
	uptime BIGINT(20) NOT NULL,
	received_time DATETIME NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (collector_device_id)
        REFERENCES collector_device_mapping(id)
        ON DELETE CASCADE
);
DROP TABLE IF EXISTS interface_statistics;
CREATE TABLE interface_statistics (
	id BIGINT(20) NOT NULL,
    collector_device_id BIGINT(20) NOT NULL,
    last_updated_time TIMESTAMP(6) NOT NULL,
	port_id BIGINT(20),
	if_index BIGINT(20) NOT NULL,
	if_name VARCHAR(255) NOT NULL,
	in_packets BIGINT(20) NOT NULL,
	in_octets BIGINT(20) NOT NULL,
	in_errors BIGINT(20) NOT NULL,
	in_discards BIGINT(20) NOT NULL,
	in_unicast_pkts BIGINT(20) NOT NULL,
	in_multicast_pkts BIGINT(20) NOT NULL,
	in_broadcast_pkts BIGINT(20) NOT NULL,
    in_pkts_per_second BIGINT(20) NOT NULL,
    in_band_width BIGINT(20) NOT NULL,
    in_crc_errors BIGINT(20) NOT NULL,
	out_packets BIGINT(20) NOT NULL,
	out_octets BIGINT(20) NOT NULL,
	out_errors BIGINT(20) NOT NULL,
	out_discards BIGINT(20) NOT NULL,
	out_unicast_pkts BIGINT(20) NOT NULL,
	out_multicast_pkts BIGINT(20) NOT NULL,
	out_broadcast_pkts BIGINT(20) NOT NULL,
	out_pkts_per_second BIGINT(20) NOT NULL,
	out_band_width BIGINT(20) NOT NULL,
	out_crc_errors BIGINT(20) NOT NULL,
	received_time DATETIME NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (collector_device_id)
           REFERENCES collector_device_mapping(id)
           ON DELETE CASCADE
);
DROP TABLE IF EXISTS pbr_statistics;
CREATE TABLE pbr_statistics (
	id BIGINT(20) NOT NULL,
    collector_device_id BIGINT(20) NOT NULL,
    last_updated_time TIMESTAMP(6) NOT NULL,
	interface_name VARCHAR(255) NOT NULL,
	received_time DATETIME NOT NULL,
	PRIMARY KEY (id),
    FOREIGN KEY (collector_device_id)
            REFERENCES collector_device_mapping(id)
            ON DELETE CASCADE
   );

DROP TABLE IF EXISTS acl_statistics;
CREATE TABLE acl_statistics (
	id BIGINT(20) NOT NULL,
  	interface_name VARCHAR(255) NOT NULL,
	acl_name VARCHAR(255) NOT NULL,
	rules_count BIGINT(20) NOT NULL,
	policy_id BIGINT(20) NOT NULL,
 	pbr_statistics_id BIGINT(20) NOT NULL,
 	PRIMARY KEY (id),
 	FOREIGN KEY (pbr_statistics_id)
            REFERENCES pbr_statistics(id)
            ON DELETE CASCADE
);

DROP TABLE IF EXISTS acl;
CREATE TABLE acl (
	id BIGINT(20) NOT NULL,
  	seq_num BIGINT(20) NOT NULL,
	byte_count BIGINT(20) NOT NULL,
	hit_count BIGINT(20) NOT NULL,
	acl_statistics_id BIGINT(20) NOT NULL,
	last_updated_time TIMESTAMP(6),
	PRIMARY KEY (id),
 	FOREIGN KEY (acl_statistics_id)
            REFERENCES acl_statistics(id)
            ON DELETE CASCADE
);


ALTER TABLE policy ADD COLUMN grid_policy_set_id BIGINT(20);

ALTER TABLE flow ADD COLUMN grid_policy_id BIGINT(20);
ALTER TABLE flow ADD COLUMN destination_group_id INT;

ALTER TABLE ruleset ADD COLUMN grid_ruleset_id BIGINT(20);

ALTER TABLE rule ADD COLUMN grid_rule_id BIGINT(20);

ALTER TABLE device ADD COLUMN status INTEGER(2);

DROP TABLE IF EXISTS stats_dashboard;
CREATE TABLE stats_dashboard (
	user_name VARCHAR(255) NOT NULL,
	dashboard LONGTEXT,
	PRIMARY KEY (`user_name`)
);
