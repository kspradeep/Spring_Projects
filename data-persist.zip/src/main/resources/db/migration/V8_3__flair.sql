DROP TABLE IF EXISTS template_policy_device_mapping;
CREATE TABLE IF NOT EXISTS template_policy_device_mapping (
    template_policy_id BIGINT(20) NOT NULL,
	device_id BIGINT(20) NOT NULL,
	FOREIGN KEY (template_policy_id)
		REFERENCES template_policy (id)
	    ON DELETE CASCADE
);