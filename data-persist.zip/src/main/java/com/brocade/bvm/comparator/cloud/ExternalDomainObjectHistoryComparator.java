package com.brocade.bvm.comparator.cloud;

import com.brocade.bvm.comparator.HistoryComparator;
import com.brocade.bvm.model.ExternalDomainObject;
import com.brocade.bvm.model.HistoryDifference;

import javax.inject.Named;
import java.util.Set;
import java.util.stream.Collectors;

@Named
public class ExternalDomainObjectHistoryComparator<T extends ExternalDomainObject> implements HistoryComparator<T> {

    @Override
    public HistoryDifference<T> transform(Set<T>... from) {
        Set<T> discoveredObjects = from[0];
        Set<T> dbObjects = from[1];

        Set<T> deletedObjects = dbObjects.stream()
                .filter(dbObject -> discoveredObjects.stream()
                        .noneMatch(discoveredObject -> discoveredObject.getExternalId().equals(dbObject.getExternalId())))
                .collect(Collectors.toSet());

        Set<T> newObjects = discoveredObjects.stream()
                .filter(discoveredObject -> dbObjects.stream()
                        .noneMatch(dbObject -> dbObject.getExternalId() != null && dbObject.getExternalId().equals(discoveredObject.getExternalId())))
                .collect(Collectors.toSet());

        Set<HistoryDifference.UpdatedEntityHolder<T>> updatedObjects = dbObjects.stream()
                .filter(dbObject -> discoveredObjects.stream().anyMatch(t -> t.getExternalId().equals(dbObject.getExternalId())))
                .map(dbObject -> {
                    return new HistoryDifference.UpdatedEntityHolder<T>(dbObject,
                            discoveredObjects.stream()
                                    .filter(dObj -> dObj.getExternalId().equals(dbObject.getExternalId()))
                                    .findAny()
                                    .get());
                }).collect(Collectors.toSet());


        return new HistoryDifference<>(newObjects, updatedObjects, deletedObjects);

    }
}
