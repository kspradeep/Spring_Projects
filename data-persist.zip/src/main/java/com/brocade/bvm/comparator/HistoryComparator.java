package com.brocade.bvm.comparator;

import com.brocade.bvm.model.DomainObject;
import com.brocade.bvm.model.HistoryDifference;

import java.util.Set;

public interface HistoryComparator<T extends DomainObject> extends Transformer<Set<T>, HistoryDifference<T>> {
}
