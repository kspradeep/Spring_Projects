package com.brocade.bvm.comparator;

public interface Transformer<F, T> {
    T transform(F... from);
}
