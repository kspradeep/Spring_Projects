package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.ProfileMapping;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface ProfileMappingRepository extends CrudRepository<ProfileMapping, Long> {

    @EntityGraph(attributePaths = "profile")
    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1")
    ProfileMapping findByDeviceId(Long deviceId);
}
