package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.FlowEgressManagedObject;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface FlowEgressManagedObjectRepository extends CrudRepository<FlowEgressManagedObject, Long> {

    @Query(value = "SELECT distinct f.tvfDomainId from #{#entityName} f WHERE f.flow.id = ?1 AND f.precedence = ?2 AND f.tvfDomainId <> NULL")
    List<String> findTvfDomainIdsByFlowIdAndPrecedence(Long flowId, Integer precedence);
}
