package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.PacketCaptureHistory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketCaptureHistoryRepository extends CrudRepository<PacketCaptureHistory, Long> {

    List<PacketCaptureHistory> findByParentIdAndDevice_IdAndWorkflowStatusInOrderByRevisionTimeDesc(Long id, Long deviceId, List<WorkflowParticipant.WorkflowStatus> statuses);

}