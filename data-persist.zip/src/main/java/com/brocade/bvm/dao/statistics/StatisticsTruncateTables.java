package com.brocade.bvm.dao.statistics;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;

@Repository
@Slf4j
public class StatisticsTruncateTables {

    @Inject
    private JdbcTemplate jdbcTemplate;

    private void disableForeignKeyChecks() {
        try {
            jdbcTemplate.update("SET FOREIGN_KEY_CHECKS = 0;");

        } catch (DataAccessException e) {

        }
    }
    private void enableForeignKeyChecks() {
        try {
            jdbcTemplate.update("SET FOREIGN_KEY_CHECKS = 1;");

        } catch (DataAccessException e) {

        }
    }
    private int truncateInterfaceStatistics() {
        try {
            int result = jdbcTemplate.update("TRUNCATE TABLE interface_statistics");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }

    private int truncateSystemUtilizationStatistics() {
        try {
            int result = jdbcTemplate.update("TRUNCATE TABLE system_utilization_statistics");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }
    private int truncatePBRStatistics() {
        try {
            int result = jdbcTemplate.update("TRUNCATE TABLE pbr_statistics");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }
    private int truncateACLStatistics() {
        try {
            int result = jdbcTemplate.update("TRUNCATE TABLE acl_statistics");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }

    private int deletePBRAndACLStatistics() {
        try {
            int result = jdbcTemplate.update("DELETE pbr_statistics, acl_statistics\n" +
                    "    FROM pbr_statistics\n" +
                    "    INNER JOIN acl_statistics ON pbr_statistics.id = acl_statistics.pbr_statistics_id");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }

    private int truncateACLs() {
        try {
            int result = jdbcTemplate.update("TRUNCATE TABLE acl");
            return result;
        } catch (DataAccessException e) {
            return 0;
        }
    }

    public void deleteAllProfilesStats() {
        try{
            log.debug("Start: Clearing of statistics data.");
            disableForeignKeyChecks();
            truncateInterfaceStatistics();
            truncateSystemUtilizationStatistics();
            truncatePBRStatistics();
            truncateACLStatistics();
            truncateACLs();
            enableForeignKeyChecks();
            log.debug("End: Clearing of statistics data.");
        }catch (Exception e) {
            log.error("Error while clearing statistics data {}", e.getMessage());
        }
    }
}