package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.FlowExporter;
import org.springframework.data.repository.CrudRepository;


public interface FlowExporterRepository extends CrudRepository<FlowExporter, Long> {

    FlowExporter findByDeviceId(Long deviceId);

}
