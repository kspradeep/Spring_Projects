package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.Rule;
import com.brocade.bvm.model.db.RuleSet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;

public interface RuleRepository extends CrudRepository<Rule, Long> {

    @Query(value = "Select ru from #{#entityName} ru where ru.id = ?1")
    Rule findOne(Long id);

    List<Rule> findByProtocol(String protocol);

    @Query(value = "select count(1) from rule where rule_set_id=?1", nativeQuery = true)
    Integer getRuleCountByRuleSetId(BigInteger ruleSetId);

    @Query(value = "select count(1) from #{#entityName} ru where ru.ruleSet.flow.policy.device.id= ?1 AND ru.ruleSet.flow.policy.workflowStatus= ?2 AND ru.ruleSet.flow.policy.id != ?3")
    Integer findAllRulesByDeviceAndStatusAndNotInPolicy(Long deviceId, WorkflowStatus status, Long policyId);

    @Query(value = "select ru from #{#entityName} ru where ru.ruleSet.flow.policy.device.id= ?1")
    List<Rule> findAllRulesByDevice(Long deviceId);

    @Query(value = "select ru.vlanId from #{#entityName} ru where ru.ruleSet.flow.policy.device.id= ?1")
    List<Long> findVlanIdsByDevice(Long deviceId);

    @Query(value = "SELECT MAX(ru.sequence) FROM #{#entityName} ru WHERE ru.ruleSet.id = ?1")
	Long getMaxSequenceByRuleSetId(Long ruleSetId);

}
