package com.brocade.bvm.dao;


import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.GtpDeEncapsulationModulePolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GtpDeEncapsulationModulePolicyHistoryRepository extends CrudRepository<GtpDeEncapsulationModulePolicyHistory, Long> {

    @Query(value = "Select ps from #{#entityName} ps where ps.parentId= ?1 AND ps.workflowStatus = ?2 order by ps.revisionTime DESC")
    List<GtpDeEncapsulationModulePolicyHistory> findByIdAndWorkflowStatus(Long modulePolicyId, WorkflowParticipant.WorkflowStatus status);
}
