package com.brocade.bvm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;

public interface LoadBalanceModulePolicyHistoryRepository extends CrudRepository<LoadBalanceModulePolicyHistory, Long> {

	@Query(value = "Select po from #{#entityName} po where po.id = ?1")
	LoadBalanceModulePolicyHistory findOne(Long id);

	LoadBalanceModulePolicyHistory findByParentId(Long modulePolicyId);

	@Query (value = "Select mp from #{#entityName} mp where mp.parentId= ?1 AND mp.workflowStatus = ?2 Order by mp.revisionTime DESC")
	List<LoadBalanceModulePolicyHistory> findByIdAndWorkflowStatus(Long modulePolicyId, WorkflowStatus status);
}
