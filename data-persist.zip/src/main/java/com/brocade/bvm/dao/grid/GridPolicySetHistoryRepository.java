package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.GridPolicySetHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GridPolicySetHistoryRepository extends CrudRepository<GridPolicySetHistory, Long> {

    List<GridPolicySetHistory> findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(Long policySetId, List<WorkflowParticipant.WorkflowStatus> statuses);

    @Query(value = "select t1.* from (select * from bvm.grid_policy_set_history p where p.grid_id = ?1 AND p.parent_id =?2 and p.workflow_status = 'ACTIVE' and p.revision_type not in ('DELETED') order by p.revision_time DESC LIMIT 1) t1 LEFT JOIN (select * from bvm.grid_policy_set_history p where p.grid_id = ?1 AND p.parent_id =?2 and p.workflow_status = 'ACTIVE' and p.revision_type in ('DELETED') order by p.revision_time DESC LIMIT 1) t2 ON t1.revision_time > t2.revision_time", nativeQuery = true)
    GridPolicySetHistory findCurrentActivePolicy(Long gridId, Long draftPolicyId);
}
