package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.PortGroupRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PortGroup;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import com.brocade.bvm.model.db.statistics.SwitchUtilization;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

@Service
@Slf4j
@Getter
public class SwitchCache {
  private TreeSet<SwitchUtilization> topFiveSwitches =
      new StatisticsTreeSet<>(
          Comparator.comparing(SwitchUtilization::getUtilization)
              .thenComparing(SwitchUtilization::hashCode));
  private TreeSet<SwitchUtilization> bottomFiveSwitches =
      new StatisticsTreeSet<>(
          Comparator.comparing(SwitchUtilization::getUtilization)
              .thenComparing(SwitchUtilization::hashCode));
  @Inject private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private PortGroupRepository portGroupRepository;

  private void setBottomFiveSwitches(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.debug("Start: set bottom five switches for device {}", device.getName());
    try {
      AtomicDouble atomicDouble = new AtomicDouble();
      interfaceStatistics.forEach(
          interfaceStatistics1 ->
              atomicDouble.getAndAdd(interfaceStatistics1.getInLinkUtilization()));
      SwitchUtilization switchUtilization = new SwitchUtilization();
      switchUtilization.setDevice(device);
      switchUtilization.setId(device.getId());
      switchUtilization.setUtilization(atomicDouble.doubleValue());
      if (atomicDouble.doubleValue() <= 0) {
        Iterator<SwitchUtilization> iterator = bottomFiveSwitches.iterator();
        while (iterator.hasNext()) {
          if (iterator.next().getId() == device.getId()) {
            iterator.remove();
            break;
          }
        }
        return;
      }

      ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
      lock.writeLock().lock();

      if (bottomFiveSwitches.size() < 5) {
        bottomFiveSwitches.add(switchUtilization);
      } else {
        SwitchUtilization existingSwitch = bottomFiveSwitches.pollLast();
        if (Objects.requireNonNull(existingSwitch).getUtilization() > atomicDouble.doubleValue()) {
          bottomFiveSwitches.add(switchUtilization);
        } else bottomFiveSwitches.add(existingSwitch);
      }

      lock.writeLock().unlock();
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    log.debug("End: set bottom five switches ports for device {}", device.getName());
  }

  @Async
  void setTopFiveSwitches(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.trace("Start: set top five switches for device {}", device.getName());
    try {
      AtomicDouble atomicDouble = new AtomicDouble(0);
      interfaceStatistics.forEach(
          interfaceStatistics1 ->
              atomicDouble.getAndAdd(interfaceStatistics1.getInLinkUtilization()));
      SwitchUtilization switchUtilization = new SwitchUtilization();
      switchUtilization.setDevice(device);
      switchUtilization.setId(device.getId());
      switchUtilization.setUtilization(atomicDouble.doubleValue());
      if (atomicDouble.doubleValue() <= 0) {
        try {
          if(!topFiveSwitches.isEmpty()) {
            topFiveSwitches.removeIf(
                    switchUtilization1 -> switchUtilization1.getId() == device.getId());
          }
          if (this.topFiveSwitches.size() < 5) {
            this.bottomFiveSwitches.clear();
          }
        } catch (Exception e) {
        }
        return;
      }

      ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
      lock.writeLock().lock();

      if (topFiveSwitches.size() < 5) {
        topFiveSwitches.add(switchUtilization);
      } else {
        SwitchUtilization existingSwitch = topFiveSwitches.pollFirst();
        if (Objects.requireNonNull(existingSwitch).getUtilization() < atomicDouble.doubleValue()) {
          topFiveSwitches.add(switchUtilization);
        } else {
          topFiveSwitches.add(existingSwitch);
        }
      }

      lock.writeLock().unlock();
    } catch (Exception e) {
      log.error(e.getMessage());
    }
//    if (this.topFiveSwitches.size() >= 5) {
//      this.setBottomFiveSwitches(device, interfaceStatistics);
//    }
    log.trace("End: set top five switches ports for device {}", device.getName());
  }

  @Async
  public void saveDeviceStatisctisc(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    if (device != null && device.getId() != null && !interfaceStatistics.isEmpty()) {
        AtomicLong inPackets = new AtomicLong(0);
        AtomicLong outPackets = new AtomicLong(0);
        AtomicLong inOctets = new AtomicLong(0);
        AtomicLong outOctets = new AtomicLong(0);
        AtomicLong inPPS = new AtomicLong(0);
        AtomicLong outPPS = new AtomicLong(0);
        AtomicLong throughput = new AtomicLong(0);
        AtomicDouble inUtilization = new AtomicDouble(0);
        AtomicDouble outUtilization = new AtomicDouble(0);
        AtomicLong inBandwidth = new AtomicLong(0);
        AtomicLong outBandwidth = new AtomicLong(0);
      List<PortGroup> portGroups = portGroupRepository.findByDeviceId(device.getId());
      List<Long> portGroupIds = portGroups.stream().map(portGroup -> portGroup.getId()).collect(Collectors.toList());
      Instant lastUpdateTime = interfaceStatistics.stream().findFirst().get().getLastUpdatedTime();
      interfaceStatistics.forEach(
              interfaceStatistic -> {
                if(portGroupIds != null && !portGroupIds.isEmpty() && portGroupIds.contains(interfaceStatistic.getPortId())){
                        //do nothing avoid portgroup
                }else{
                    inPackets.getAndAdd(interfaceStatistic.getInPackets());
                    outPackets.getAndAdd(interfaceStatistic.getOutPackets());
                    inOctets.getAndAdd(interfaceStatistic.getInOctets());
                    outOctets.getAndAdd(interfaceStatistic.getOutOctets());
                    inPPS.getAndAdd(interfaceStatistic.getInPktsPerSecond());
                    inUtilization.getAndAdd(interfaceStatistic.getInLinkUtilization());
                    outUtilization.getAndAdd(interfaceStatistic.getOutLinkUtilization());
                    throughput.getAndAdd(interfaceStatistic.getInBandwidth());
                    inBandwidth.getAndAdd(interfaceStatistic.getInBandwidth());
                    outBandwidth.getAndAdd(interfaceStatistic.getOutBandwidth());
                    outPPS.getAndAdd(interfaceStatistic.getOutPktsPerSecond());
                }
              });
      if (lastUpdateTime != null) {
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("id", device.getId());
        map.addValue("inPackets", inPackets.longValue());
        map.addValue("outPackets", outPackets.longValue());
        map.addValue("inOctets", inOctets.longValue());
        map.addValue("outOctets", outOctets.longValue());
        map.addValue("inPPS", inPPS.longValue());
        map.addValue("outPPS", outPPS.longValue());
        map.addValue("inUtilization", inUtilization.doubleValue());
        map.addValue("outUtilization", outUtilization.doubleValue());
        map.addValue("throughput", throughput.longValue());
        map.addValue("inBandwidth", inBandwidth.longValue());
        map.addValue("outBandwidth", outBandwidth.longValue());
        map.addValue("lastUpdatedTime", Timestamp.from(lastUpdateTime));
        map.addValue("receivedTime", new Date(System.currentTimeMillis()));
        String sql =
            "insert into device_utilization(id, in_packets, out_packets, in_octets, out_octets, in_pkts_per_second," +
                    " out_pkts_per_second, in_link_utilization, out_link_utilization, throughput,in_band_width, out_band_width," +
                    " last_updated_time, received_time) "
                + "values (:id, :inPackets, :outPackets, :inOctets, :outOctets, :inPPS, :outPPS, :inUtilization, :outUtilization," +
                    " :throughput, :inBandwidth, :outBandwidth, :lastUpdatedTime, :receivedTime)";

      try{
        namedParameterJdbcTemplate.update(sql, map);
      }catch (DataAccessException e) {
        log.error("Error while inserting device utilization {}", e.getMessage());
      }}
    }
  }

  public void deleteDeviceUtilization(Long timeInterval) {
    try{
      int rows = jdbcTemplate.update("DELETE FROM device_utilization WHERE received_time < DATE_SUB(NOW(), INTERVAL 1800 SECOND)");
      log.trace("Clearing device utilization {}", rows);
    }catch (DataAccessException e) {
      log.error("Error while deleting device utilization {}", e.getMessage());
    }
  }

}
