package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.PortGroup;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface PortGroupRepository extends CrudRepository<PortGroup, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PortGroup findOne(Long id);

    @Query(value = "Select po.name from #{#entityName} po where po.id = ?1")
    String findNameById(Long id);

    @Query(value = "SELECT port_group_id, port_id FROM port_portgroup_mapping WHERE port_id IN ?1", nativeQuery = true)
    List<Object[]> findPortGroupIdsByPortIds(List<Long> portIds);

    PortGroup findById(Long portGroupId);

    PortGroup findByNameAndDevice(String name, Device device);

    PortGroup findByNameAndDeviceId(String name, Long deviceId);

    @Query(value = "SELECT pg.id FROM port_group pg, port_portgroup_mapping pm WHERE pg.id=pm.port_group_id and pm.port_id=?1", nativeQuery = true)
    Long findByPortId(Long portId);

    @Query("SELECT p.name FROM port_group p WHERE p.device.id = ?1 and p.name like ?2 and p.id <> ?3")
    Set<String> findName(Long deviceId, String name, Long portGroupId);

    @Query(value = "SELECT port_id FROM port_portgroup_mapping WHERE port_id IN ?1", nativeQuery = true)
    List<Long> findPortIdsByPortIds(List<Long> portIds);

    @Query(value = "SELECT port_id FROM port_portgroup_mapping WHERE port_id IN ?1 and port_group_id <> ?2", nativeQuery = true)
    List<Long> findPortIdsByPortIdsAndIdNotIn(List<Long> portIds, Long portGroupId);

    @Query(value = "SELECT p.id as port_id FROM bvm.flow_port_mapping_egress fpme, bvm.flow_port_mapping_ingress fpmi, bvm.port_bvm_defined p where (fpme.managed_object_id=p.id or fpmi.managed_object_id=p.id) and (p.type=\"SERVICE_PORT\" or p.type=\"EGRESS\") and p.id IN ?1", nativeQuery = true)
    List<Long> findIngressOrEgressPortIdsByPortIds(List<Long> portIds);

    @Query(value = "select p.id from policy p, flow f, managed_object m where p.id = f.policy_id and m.id=p.id and f.id in (SELECT flow_id FROM flow_port_mapping_ingress WHERE managed_object_id = ?1)", nativeQuery = true)
    List<Long> findServicePortGroupIsUseInPolicy(Long portGroupId);

    @Query(value = "select p.id from policy p, flow f, managed_object m where p.id = f.policy_id and m.id=p.id and f.id in (SELECT flow_id FROM flow_port_mapping_egress WHERE managed_object_id = ?1)", nativeQuery = true)
    List<Long> findEgressPortGroupIsUseInPolicy(Long portGroupId);

    @Query(value = "select p.id from packet_slicing_port_mapping pm, port p where p.id=pm.managed_object_id and p.id in ?1", nativeQuery = true)
    List<Long> findTruncateEnabledEgressPorts(List<Long> portIds);

    @Query(value = "SELECT pg.id from #{#entityName} pg JOIN pg.gtpProfile gtp WHERE pg.device.id = ?1 AND gtp.id = ?2")
    List<Long> findByDeviceIdAndGTPProfile(Long deviceId, Long gtpProfileId);

    @Query(value = "SELECT pg from #{#entityName} pg JOIN pg.ports p WHERE pg.device.id = ?1 AND p.id = ?2")
    List<PortGroup> findByDeviceIdAndEgress(Long deviceId, Long egressId);

    @Query(value = "select pg.id from port_group pg, port_portgroup_mapping pm, gtp_device_policy gdp where pg.device_id = ?1 and pg.id = pm.port_group_id and pg.gtp_device_policy_id = gdp.id and pm.port_id = ?2 and gdp.id = ?3", nativeQuery = true)
    List<Long> findByPrimaryPortAndGTPProfile(Long deviceId, Long primaryPortId, Long gtpProfileId);

    @Query(value = "SELECT p.id as port_id FROM bvm.flow_port_mapping_ingress fpmi, bvm.port_bvm_defined p where fpmi.managed_object_id=p.id and p.id IN ?1", nativeQuery = true)
    List<Long> findsPortIdsUsedInPolicy(List<Long> portIds);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow fl, policy p where fl.tvf_domain = 1 and fl.policy_id = p.id and p.device_id = ?1 and fpme.managed_object_id in ?2", nativeQuery = true)
    List<Long> findByDeviceIdTvfDomainAndEgressPortsAndNotInCurrentPolicy(Long deviceId, List<Long> egressPorts);

    @Query(value = "SELECT p.id as port_id FROM bvm.flow_port_mapping_egress fpme, bvm.flow_port_mapping_ingress fpmi, bvm.port_bvm_defined p where (fpme.managed_object_id=p.id or fpmi.managed_object_id=p.id) and p.id IN ?1", nativeQuery = true)
    List<Long> findIngressOrEgressPortIdsByPortIdsInPolicy(List<Long> portIds);

    @Query("SELECT p.id FROM #{#entityName} p WHERE p.id IN ?1 AND p.workflowStatus IN ?2 ")
    List<Long> findAllPortChannelsInWorkflowStatus(Set<Long> ingressPortChannels, List<WorkflowParticipant.WorkflowStatus> statuses);

    @Query(value = "SELECT pg from #{#entityName} pg WHERE pg.device.id = ?1")
    List<PortGroup> findByDeviceId(Long deviceId);

    @Query(value = "SELECT pg from #{#entityName} pg WHERE pg.device.id = ?1 AND pg.workflowStatus IN ?2")
    List<PortGroup> findByDeviceIdAndWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> statuses);

    @Query(value = "SELECT pg from #{#entityName} pg WHERE pg.device.id = ?1 and pg.primaryPort.name like %?2")
    PortGroup findByPrimaryPort(Long deviceId, String portName);

    @Query(value = "SELECT pg from #{#entityName} pg JOIN pg.ports p WHERE pg.device.id = ?1 AND p.id = ?2")
    PortGroup findByDeviceAndPortId(Long deviceId, Long portId);

    @Query(value = "SELECT pg from #{#entityName} pg JOIN pg.ports p WHERE pg.device.id = ?1 AND p.name like %?2")
    PortGroup findByDeviceAndPortName(Long deviceId, String portName);

    @Query(value = "SELECT pg.name from #{#entityName} pg WHERE pg.device.id = ?1")
    List<String> findNamesByDeviceId(Long deviceId);

    @Query(value = "Select po.name from #{#entityName} po where po.id in ?1")
    List<String> findNamesByIds(List<Long> ids);
}
