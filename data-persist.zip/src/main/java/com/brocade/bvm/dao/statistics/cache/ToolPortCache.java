package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import com.brocade.bvm.model.db.statistics.PortUtilization;
import com.brocade.bvm.model.db.statistics.SwitchUtilization;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Slf4j
@Service
@Getter
public class ToolPortCache {
  private TreeSet<PortUtilization> topFiveToolPorts =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  private TreeSet<PortUtilization> bottomFiveToolPorts =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));

  @Inject private GridRepository gridRepository;
  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private EntityManager entityManager;
  @Inject private StatisticsPortRepository statisticsPortRepository;

  @Async
  void setTopFiveToolPorts(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.trace("Start: set top five tool ports for device {}", device.getName());
    try {
      Set<DeviceGrid> grids = Sets.newConcurrentHashSet(gridRepository.findAll());
      AtomicDouble atomicDouble = new AtomicDouble(0);
      grids.forEach(
          grid ->
              grid.getDestinationNodes()
                  .forEach(
                      gridCluster -> {
                        Long deviceId = getDeviceId(gridCluster.getId());
                        List<Long> ports = getAllToolPortsByDeviceId(deviceId);
                        if (ports.size() == 0) {
                          return;
                        }
                        if (StringUtils.isEmpty(deviceId)) {
                          log.error("Device id is empty for grid cluster {}", gridCluster.getId());
                        } else {
                          if (deviceId == device.getId()) {
                            interfaceStatistics.forEach(
                                interfaceStatistics1 -> {
                                  if (ports.contains(interfaceStatistics1.getPortId())) {
                                    atomicDouble.getAndAdd(
                                        interfaceStatistics1.getInLinkUtilization());
                                    PortUtilization portUtilization = new PortUtilization();
                                    portUtilization.setId(interfaceStatistics1.getPortId());
                                    portUtilization.setPort(device.getName() + "-" +interfaceStatistics1.getIfName());
                                    portUtilization.setUtilization(atomicDouble.doubleValue());

                                    if (atomicDouble.doubleValue() <= 0) {
                                      try {
                                        if (topFiveToolPorts.isEmpty()) {
                                          return;
                                        }
                                        topFiveToolPorts.removeIf(
                                            portUtilization1 ->
                                                portUtilization.getId()
                                                    == portUtilization1.getId());
                                      } catch (Exception e) {
                                      }
                                      return;
                                    }
                                    ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                                    lock.writeLock().lock();

                                    if (topFiveToolPorts.size() < 5) {
                                      topFiveToolPorts.add(portUtilization);
                                    } else {
                                      PortUtilization existingPort = topFiveToolPorts.pollFirst();
                                      if (existingPort != null) {
                                        if (existingPort.getUtilization()
                                            < portUtilization.getUtilization()) {
                                          topFiveToolPorts.add(portUtilization);
                                        } else {
                                          topFiveToolPorts.add(existingPort);
                                        }
                                      }
                                    }

                                    lock.writeLock().unlock();
                                  }
                                });
                          }
                        }
                      }));
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    //    if (this.topFiveToolPorts.size() >= 5) {
    //      this.setBottomFiveToolPorts(device, interfaceStatistics);
    //    }
    log.trace("End: set top five tool ports for device {}", device.getName());
  }

  private void setBottomFiveToolPorts(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.trace("Start: set bottom five tool ports for device {}", device.getName());
    try {
      Set<DeviceGrid> grids = Sets.newConcurrentHashSet(gridRepository.findAll());
      AtomicDouble atomicDouble = new AtomicDouble(0);
      grids.forEach(
          grid ->
              grid.getDestinationNodes()
                  .forEach(
                      gridCluster -> {
                        Long deviceId = getDeviceId(gridCluster.getId());
                        List<Long> ports = getAllToolPortsByDeviceId(deviceId);
                        if (ports.size() == 0) {
                          return;
                        }
                        if (StringUtils.isEmpty(deviceId)) {
                          log.error("Device id is empty for grid cluster {}", gridCluster.getId());
                        } else {
                          if (Objects.equals(device.getId(), deviceId)) {
                            interfaceStatistics.forEach(
                                interfaceStatistics1 -> {
                                  if (ports.contains(interfaceStatistics1.getPortId())) {
                                    atomicDouble.getAndAdd(
                                        interfaceStatistics1.getInLinkUtilization());
                                    PortUtilization portUtilization = new PortUtilization();
                                    portUtilization.setId(interfaceStatistics1.getPortId());
                                    portUtilization.setPort(interfaceStatistics1.getIfName());
                                    portUtilization.setUtilization(atomicDouble.doubleValue());
                                    if (atomicDouble.doubleValue() <= 0) {
                                      bottomFiveToolPorts.remove(portUtilization);
                                      return;
                                    }
                                    ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                                    lock.writeLock().lock();

                                    if (bottomFiveToolPorts.size() < 5) {
                                      bottomFiveToolPorts.add(portUtilization);
                                    } else {
                                      PortUtilization existingPort = bottomFiveToolPorts.pollLast();
                                      if (existingPort != null) {
                                        if (existingPort.getUtilization()
                                            > portUtilization.getUtilization()) {
                                          bottomFiveToolPorts.add(portUtilization);
                                        } else {
                                          bottomFiveToolPorts.add(existingPort);
                                        }
                                      }
                                    }

                                    lock.writeLock().unlock();
                                  }
                                });
                          }
                        }
                      }));
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    log.trace("End: set top five tool ports for device {}", device.getName());
  }

  private Long getDeviceId(Long id) {
    try {
      return jdbcTemplate.queryForObject(
          "select gc.device_id from bvm.grid_cluster gc where gc.id=?",
          new Object[] {id},
          Long.class);
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  private List<Long> getAllToolPortsByDeviceId(Long id) {
    List<Long> ports = new ArrayList<>();
    Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
    deviceGrids.forEach(
        deviceGrid ->
            deviceGrid
                .getDestinationNodes()
                .forEach(
                    networkNode -> {
                      Long deviceId = getDeviceId(networkNode.getId());
                      if (Objects.equals(deviceId, id)) {
                        networkNode
                            .getClusterNodeInterfaces()
                            .forEach(
                                clusterNodeInterface -> {
                                  List<Long> managedObjectIds =
                                      getManagedObjectId(clusterNodeInterface.getId());
                                  ports.addAll(managedObjectIds);
                                });
                      }
                    }));
    return ports;
  }

  private List<Long> getManagedObjectId(Long clusterNodeId) {
    return jdbcTemplate.query(
        "select cn.managed_object_id from bvm.cluster_node_port_mapping cn where cn.cluster_node_id=?",
        new Object[] {clusterNodeId},
        rowMapper);
  }

  private RowMapper<Long> rowMapper = (ResultSet rs, int rowNum) -> rs.getLong("managed_object_id");
}
