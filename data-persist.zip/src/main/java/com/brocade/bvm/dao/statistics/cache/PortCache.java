package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import com.brocade.bvm.model.db.statistics.PortUtilization;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

@Service
@Slf4j
@Getter
public class PortCache {
  @Inject private PortRepository portRepository;
  @Inject private StatisticsPortRepository statisticsPortRepository;
  private TreeSet<PortUtilization> topFiveIngress =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  private TreeSet<PortUtilization> bottomFiveIngress =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  private TreeSet<PortUtilization> topFiveEgress =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  private TreeSet<PortUtilization> bottomFiveEgress =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));

  @Async
  void setFiveIngressAndEgress(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    interfaceStatistics.forEach(
        interfaceStatistic -> {
          PortUtilization portUtilization = new PortUtilization();
          portUtilization.setId(interfaceStatistic.getPortId());
          double utilization = interfaceStatistic.getInLinkUtilization();
          portUtilization.setUtilization(utilization);
          if (utilization <= 0) {
            try {
              if(!topFiveIngress.isEmpty()) {
                topFiveIngress.removeIf(portUtilization1 -> portUtilization.getId() == portUtilization1.getId());
              }
              if(!topFiveEgress.isEmpty()) {
                bottomFiveEgress.removeIf(portUtilization1 -> portUtilization1.getId() == portUtilization.getId());
              }
            } catch (Exception e) {
            }
            return;
          }
          if (interfaceStatistic.getIfName().startsWith("E")) {
            portUtilization.setPort(device.getName() + "-" + interfaceStatistic.getIfName());
          } else {
            portUtilization.setPort(
                device.getName() + "-Ethernet " + interfaceStatistic.getIfName());
          }
          ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
          lock.writeLock().lock();
          Port port = portRepository.findOne(interfaceStatistic.getPortId());
          if (port != null && port.getType() != null) {
            if (port.getType().equals(Port.Type.INGRESS)
                || port.getType().equals(Port.Type.SERVICE_PORT)) {
              if (topFiveIngress.size() < 5) {
                topFiveIngress.add(portUtilization);
              } else {
                PortUtilization existingPort = topFiveIngress.pollFirst();
                if (existingPort != null) {
                  if (existingPort.getUtilization() < portUtilization.getUtilization()) {
                    topFiveIngress.add(portUtilization);
                  } else {
                    topFiveIngress.add(existingPort);
                  }
                }
              }
              if (this.topFiveIngress.size() >= 5) {
                if (this.bottomFiveIngress.size() < 5) {
                  this.bottomFiveIngress.add(portUtilization);
                } else {
                  PortUtilization existingPort = bottomFiveIngress.pollLast();
                  if (existingPort != null) {
                    if (existingPort.getUtilization() < portUtilization.getUtilization()) {
                      bottomFiveIngress.add(portUtilization);
                    } else {
                      bottomFiveIngress.add(existingPort);
                    }
                  }
                }
              }
            } else if (port.getType().equals(Port.Type.EGRESS)) {
              if (this.topFiveEgress.size() < 5) {
                this.topFiveEgress.add(portUtilization);
              } else {
                PortUtilization existingPort = topFiveEgress.pollFirst();
                if (existingPort != null) {
                  if (existingPort.getUtilization() < portUtilization.getUtilization()) {
                    topFiveEgress.add(portUtilization);
                  } else {
                    topFiveEgress.add(existingPort);
                  }
                }
              }
              if (this.topFiveEgress.size() >= 5) {
                if (bottomFiveEgress.size() < 5) {
                  this.bottomFiveEgress.add(portUtilization);
                } else {
                  PortUtilization existingPort = this.bottomFiveEgress.pollLast();
                  if (existingPort != null) {
                    if (existingPort.getUtilization() < portUtilization.getUtilization()) {
                      this.bottomFiveEgress.add(portUtilization);
                    } else {
                      this.bottomFiveEgress.add(existingPort);
                    }
                  }
                }
              }
            }
          }

          lock.writeLock().unlock();
        });
  }

  public Set<String> getTopFiveIngress() {
    return topFiveIngress.stream().map(PortUtilization::getPort).collect(Collectors.toSet());
  }

  public Set<String> getTopFiveEgress() {
    return topFiveEgress.stream().map(PortUtilization::getPort).collect(Collectors.toSet());
  }

  public Set<String> getBottomFiveEgress() {
    return bottomFiveEgress.stream().map(PortUtilization::getPort).collect(Collectors.toSet());
  }

  public Set<String> getBottomFiveIngress() {
    return bottomFiveIngress.stream().map(PortUtilization::getPort).collect(Collectors.toSet());
  }
}
