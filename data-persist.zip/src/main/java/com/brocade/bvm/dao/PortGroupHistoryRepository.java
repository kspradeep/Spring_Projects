package com.brocade.bvm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.brocade.bvm.model.db.history.PortGroupHistory;

public interface PortGroupHistoryRepository extends CrudRepository<PortGroupHistory, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PortGroupHistory findOne(Long id);

    @Query(value="select history from port_group_history history where history.parentId = ?1 and history.workflowStatus like 'ACTIVE' order by history.revisionTime desc")
    List<PortGroupHistory> findByIdAndWorkflowStatus(Long portGroupId);

}

	