package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.SetupHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SetupHistoryRepository extends CrudRepository<SetupHistory, Long> {

    Page<SetupHistory> findAllByOrderByIdDesc(Pageable pageable);

    List<SetupHistory> findByVersionAndAction(String version, String action);

}
