package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.ManagedObject;
import org.springframework.data.repository.CrudRepository;

public interface ManagedObjectRepository extends CrudRepository<ManagedObject, Long> {



}
