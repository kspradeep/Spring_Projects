package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.NetworkNode;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.Set;

public interface NetworkNodeRepository extends CrudRepository<NetworkNode, Long> {

    @Query(value = "Select p.managed_object_id from network_node_interface_mapping_egress p where p.node_id = ?1", nativeQuery = true)
    Set<BigInteger> findEgressByNodeId(Long id);
}
