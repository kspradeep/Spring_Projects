package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketLabelingModulePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketLabelingModulePolicyRepository extends CrudRepository<PacketLabelingModulePolicy, Long> {
    @Query(value = "select mpm.module_id from module_policy_mapping mpm where mpm.module_id in ?1", nativeQuery = true)
    List<Long> findModulesByModuleIds(List<Long> moduleIds);

    @Query(value = "select plmp.id from packet_labeling_module_policy plmp, module_policy_mapping mpm where mpm.module_policy_id = plmp.id and mpm.module_id = ?1 and plmp.processor_number in ?2", nativeQuery = true)
    List<Long> findModulesPolicyByModuleIdAndProcessorNumber(Long moduleId, List<String> processorNumber);
}
