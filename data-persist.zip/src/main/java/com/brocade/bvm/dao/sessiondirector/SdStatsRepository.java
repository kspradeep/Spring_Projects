package com.brocade.bvm.dao.sessiondirector;


import com.brocade.bvm.model.db.sessiondirector.SdStats;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.Instant;
import java.util.List;

public interface SdStatsRepository extends CrudRepository<SdStats, Long> {
    @Query(value = "SELECT sdstats from #{#entityName} sdstats WHERE sdstats.device.id = ?1")
    List<SdStats> findAllByDeviceId(Long deviceId);

    @Query(value = "SELECT sdstats FROM #{#entityName} sdstats WHERE sdstats.device.id = ?1 AND sdstats.reportTime BETWEEN ?2 AND ?3")
    List<SdStats> findLastOneHourData(Long deviceId, Instant fromTime, Instant toTime);
}
