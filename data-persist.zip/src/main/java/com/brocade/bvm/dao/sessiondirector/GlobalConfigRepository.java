package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.GlobalConfig;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface GlobalConfigRepository extends CrudRepository<GlobalConfig, Long> {

    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1")
    GlobalConfig findByDeviceId(Long deviceId);
}
