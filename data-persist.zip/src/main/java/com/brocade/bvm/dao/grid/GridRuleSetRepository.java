package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.GridRuleSet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GridRuleSetRepository extends CrudRepository<GridRuleSet, Long> {

    @Query(value = "SELECT rs.name FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.gridPolicy.gridPolicySet.deviceGrid.id = ?2")
    List<String> findByNameAndDeviceGridId(List<String> names, Long deviceGridId);

    @Query(value = "SELECT rs.name FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.gridPolicy.gridPolicySet.deviceGrid.id = ?2 and rs.gridPolicy.gridPolicySet.id <> ?3")
    List<String> findByNameAndDeviceGridIdAndNotPolicySetId(List<String> names, Long deviceGridId, Long policySetId);
}
