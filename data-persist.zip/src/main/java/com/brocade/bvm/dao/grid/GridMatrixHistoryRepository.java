package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.GridMatrixHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GridMatrixHistoryRepository extends CrudRepository<GridMatrixHistory, Long> {

    @Query(value = "Select m from #{#entityName} m where m.parentId= ?1 AND m.workflowStatus = ?2 order by m.revisionTime DESC")
    List<GridMatrixHistory> findByIdAndWorkflowStatus(Long matrixId, WorkflowParticipant.WorkflowStatus status);
}
