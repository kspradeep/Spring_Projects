package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.MPLSDevicePolicy;
import com.brocade.bvm.model.db.MPLSPair;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MPLSDevicePolicyRepository extends CrudRepository<MPLSDevicePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    MPLSDevicePolicy findOne(Long id);

    @Query(value = "SELECT mpls.id from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.ingressPort.id = ?2")
    List<Long> findByDeviceIdAndIngressPort(Long deviceId, Long ingressPortId);

    @Query(value = "SELECT mpls.id from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.egressPort.id in ?2")
    List<Long> findByEgressPort(Long deviceId, List<Long> egressPortIds);

    @Query(value = "SELECT mpls.id from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.ingressPort.id in ?2")
    List<Long> findByIngressPort(Long deviceId, List<Long> ingressPortIds);

    @Query(value = "SELECT mp from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.egressPort.id <> ?2 and mp.egressPort.module.id = ?3")
    List<MPLSPair> findByEgressPortNotIn(Long deviceId, Long egressPortId, Long moduleId);

    @Query(value = "SELECT mp from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.egressPort.id = ?2")
    List<MPLSPair> findByDeviceIdAndEgressPort(Long deviceId, Long egressPortId);

    @Query(value = "SELECT mp from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.egressPort.module.id = ?2 AND mp.egressPort.ppcr = ?3")
    List<MPLSPair> findByEgressPortModuleAndPPCR(Long deviceId, Long egressModuleId, Integer egressPpcr);

    @Query(value = "SELECT mp from #{#entityName} mpls JOIN mpls.mplsPairs mp WHERE mpls.device.id = ?1 AND mp.ingressPort.module.id = ?2 AND mp.ingressPort.ppcr = ?3")
    List<MPLSPair> findByIngressPortModuleAndPPCR(Long deviceId, Long ingressModuleId, Integer ingressPpcr);


}
