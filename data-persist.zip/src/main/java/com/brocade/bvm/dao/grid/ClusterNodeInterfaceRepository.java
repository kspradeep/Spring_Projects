package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.grid.ClusterNodeInterface;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.Set;

public interface ClusterNodeInterfaceRepository extends CrudRepository<ClusterNodeInterface, Long> {

    @Query(value = "SELECT c.managed_object_id FROM cluster_node_port_mapping c WHERE c.managed_object_id IN ?1", nativeQuery = true)
    Set<BigInteger> findAllPortIdsById(Set<Long> portIds);

    @Query(value = "SELECT c.portsAndPortGroups from #{#entityName} c WHERE c.gridCluster.device.id = ?1")
    Set<ManagedObject> findManagedObjectsByDeviceId(Long deviceId);
}
