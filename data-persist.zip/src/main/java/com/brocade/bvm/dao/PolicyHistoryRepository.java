package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.history.PolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PolicyHistoryRepository extends CrudRepository<PolicyHistory, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PolicyHistory findOne(Long id);

    @Query(value = "Select p from #{#entityName} p where p.parentId= ?1 AND p.workflowStatus = ?2 Order by p.revisionTime DESC")
    List<PolicyHistory> findByIdAndWorkflowStatus(Long policyId, WorkflowStatus status);

    @Query(value = "Select p from #{#entityName} p where p.parentId= ?1 AND p.workflowStatus in ?2 Order by p.revisionTime DESC")
    List<PolicyHistory> findByIdAndWorkflowStatusses(Long policyId, List<WorkflowStatus> statusses);

    List<PolicyHistory> findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(Long policyId, List<WorkflowStatus> statusses);

    @Query(value = "Select p from #{#entityName} p where p.name like ?1 and p.parentId != ?2 Order by p.id DESC")
    List<PolicyHistory> findByNameAndNotParentId(String Name, Long policyId);

    @Query(value = "select t1.* from (select * from bvm.policy_history p where p.device_id = ?1 AND p.parent_id =?2 and p.workflow_status = 'ACTIVE' and p.revision_type not in ('DELETED') order by p.revision_time DESC LIMIT 1) t1 LEFT JOIN (select * from bvm.policy_history p where p.device_id = ?1 AND p.parent_id =?2 and p.workflow_status = 'ACTIVE' and p.revision_type in ('DELETED') order by p.revision_time DESC LIMIT 1) t2 ON t1.revision_time > t2.revision_time", nativeQuery = true)
    PolicyHistory findCurrentActivePolicy(Long deviceId, Long draftPolicyId);
}
