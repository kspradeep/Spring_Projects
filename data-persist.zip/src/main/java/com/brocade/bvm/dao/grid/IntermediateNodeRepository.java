package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.IntermediateNode;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.Set;

public interface IntermediateNodeRepository extends CrudRepository<IntermediateNode, Long> {

    @Query(value = "Select p.managed_object_id from intermediate_node_interface_mapping_egress p where p.node_id = ?1", nativeQuery = true)
    Set<BigInteger> findEgressByNodeId(Long id);

    @Query(value = "Select i from #{#entityName} i where i.device.id = ?1")
    Set<IntermediateNode> findByDeviceId(Long deviceId);
}
