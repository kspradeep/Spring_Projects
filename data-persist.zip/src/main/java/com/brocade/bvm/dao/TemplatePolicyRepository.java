package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.TemplatePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public interface TemplatePolicyRepository extends CrudRepository<TemplatePolicy, Long> {

    @Query("SELECT t FROM #{#entityName} t WHERE t.deviceModel = ?1 or t.deviceModel = null")
    List<TemplatePolicy> findByDeviceModelAndNullDeviceModel(String deviceModel);

    @Query("SELECT t FROM #{#entityName} t WHERE t.name = ?1")
    List<TemplatePolicy> findByName(String name);

    @Query(value = "SELECT t.template_policy_id from template_policy_device_mapping t WHERE t.device_id = ?1", nativeQuery = true)
    Set<BigInteger> findIdByDeviceId(Long deviceId);
}
