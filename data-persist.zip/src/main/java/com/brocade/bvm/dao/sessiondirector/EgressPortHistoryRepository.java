package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.EgressPortHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EgressPortHistoryRepository extends CrudRepository<EgressPortHistory, Long> {

    @Query(value = "Select history from #{#entityName} history where history.parentId= ?1 AND history.workflowStatus in ?2 order by history.revisionTime DESC")
    List<EgressPortHistory> findByIdAndWorkflowStatus(Long portId, List<WorkflowParticipant.WorkflowStatus> status);

    @Query(value = "Select history from #{#entityName} history where history.parentId= ?1 AND history.revisionType in ?2 order by history.revisionTime DESC")
    List<EgressPortHistory> findByIdAndRevisionTypes(Long portId, List<HistoryObject.RevisionType> revisionTypes);
}
