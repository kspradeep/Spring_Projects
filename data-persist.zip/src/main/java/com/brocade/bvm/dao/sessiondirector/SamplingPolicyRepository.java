package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.sessiondirector.SamplingPolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface SamplingPolicyRepository extends CrudRepository<SamplingPolicy, Long> {
    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2 AND po.id <> ?3")
    List<SamplingPolicy> findByNameAndDeviceForUpdate(String name, Long deviceId, Long policyId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2")
    List<SamplingPolicy> findByNameAndDevice(String name, Long deviceId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2")
    List<SamplingPolicy> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> notAcceptableStatus);

    @Query(value = "SELECT sp from #{#entityName} sp WHERE sp.device.id = ?1")
    List<SamplingPolicy> findAllByDeviceId(Long deviceId);
}
