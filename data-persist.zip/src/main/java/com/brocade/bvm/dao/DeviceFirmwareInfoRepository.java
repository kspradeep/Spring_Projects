package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.DeviceFirmwareInfo;
import com.brocade.bvm.model.db.FirmwareJob;
import com.brocade.bvm.model.db.Job;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DeviceFirmwareInfoRepository extends CrudRepository<DeviceFirmwareInfo, Long> {

    @Query("SELECT df FROM #{#entityName} df WHERE df.deleted=0 Order by df.id desc")
    List<DeviceFirmwareInfo> findByDeletedFalse();

}
