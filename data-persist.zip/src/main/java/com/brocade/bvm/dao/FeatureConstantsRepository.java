package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.admin.ApplicationConstant;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface FeatureConstantsRepository extends CrudRepository<ApplicationConstant, Long> {

    @Query(value = "Select o from #{#entityName} o where o.name = ?1")
    ApplicationConstant findByName(String name);
}
