package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.history.HasHistory;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import com.brocade.bvm.model.db.sessiondirector.FilterRule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Slf4j
@Repository
public class PersistFilterPolicyInBatch {
    @Autowired
    private EntityManager entityManager;

    @Inject
    private FilterPolicyRepository filterPolicyRepository;

    @Value("${spring.jpa.properties.hibernate.jdbc.batch_size:100}")
    private Long batchSize;

    @Transactional(readOnly = false)
    public FilterPolicy saveFilterPolicyInBatch(FilterPolicy filterPolicy) {
        long i = 0;
        boolean isCreating = false;
        if (filterPolicy.getId() == null) {
            isCreating = true;
        }
        SortedSet<FilterRule> newRules = new TreeSet<>(filterPolicy.getRules().stream().filter(filterRule -> filterRule.getId() == null).collect(Collectors.toSet()));
        filterPolicy.removeRules(newRules);
        filterPolicy = entityManager.merge(filterPolicy);

        entityManager.flush();
        entityManager.clear();

        if (newRules != null && !newRules.isEmpty()) {
            SortedSet<FilterRule> savedFilterRules = new TreeSet<>();
            for (FilterRule filterRule : newRules) {
                filterRule.setPolicy(filterPolicy);
                savedFilterRules.add(entityManager.merge(filterRule));
                i++;
                if (i % batchSize == 0) {
                    log.trace("Saving the batch :{} ", i);
                    entityManager.flush();
                    entityManager.clear();
                }
            }
            filterPolicy.setRules(savedFilterRules);
            if (isCreating) {
                buildHistoryObject(filterPolicy, HistoryObject.RevisionType.UPDATED);
            }
        }
        return filterPolicy;
    }

    private void buildHistoryObject(Object target, HistoryObject.RevisionType revisionType) {
        if (target instanceof HasHistory && target instanceof ManagedObject) {
            HistoryObject historyObject = ((HasHistory) target).buildHistory();
            historyObject.setParentId(((HasHistory) target).getId());
            historyObject.setName(((ManagedObject) target).getName());
            historyObject.setWorkflowStatus(((ManagedObject) target).getWorkflowStatus());
            historyObject.setWorkflowType(((ManagedObject) target).getWorkflowType());
            historyObject.setRevisionType(revisionType);
            historyObject.setRevisionTime(Instant.now());
            entityManager.merge(historyObject);
        }
    }
}
