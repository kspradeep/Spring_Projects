package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.TunnelDevicePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TunnelDevicePolicyRepository extends CrudRepository<TunnelDevicePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    TunnelDevicePolicy findOne(Long devicePolicyId);

    @Query(value = "Select po.id from #{#entityName} po where po.type = ?1")
    List<Long> findByType(TunnelDevicePolicy.Type type);
}
