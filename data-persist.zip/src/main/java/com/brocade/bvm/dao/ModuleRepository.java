package com.brocade.bvm.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Module;

public interface ModuleRepository extends CrudRepository<Module, Long> {

	@Query(value = "Select mo from #{#entityName} mo where mo.id = ?1")
	Module findOne(Long id);

	Module findByNameAndStablenetIdAndDevice(String moduleName, Long stablenetId, Device device);
}
