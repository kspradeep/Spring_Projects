package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketTruncation;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketTruncationRepository extends CrudRepository<PacketTruncation, Long> {

    List<PacketTruncation> findByName(String name);
}
