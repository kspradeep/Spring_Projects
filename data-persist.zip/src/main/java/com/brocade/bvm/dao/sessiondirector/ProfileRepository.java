package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.Profile;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface ProfileRepository extends CrudRepository<Profile, Long> {

    List<Profile> findByDevice(Device device);

    @Query(value = "Select d from #{#entityName} d where d.name = ?1 and d.device.id = ?2")
    Profile findByNameDeviceId(String name, Long deviceId);

    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1 and d.id = ?2")
    Profile findByDeviceProfileId(Long deviceId, Long profileId);

    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1 and d.profileId IN ?2")
    List<Profile> findByDeviceIdAndProfileIdIn(Long deviceId, List<Integer> profileIds);
}
