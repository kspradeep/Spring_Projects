package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.GTPDevicePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Set;


public interface GTPDevicePolicyRepository extends CrudRepository<GTPDevicePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    GTPDevicePolicy findOne(Long id);

    @Query(value = "SELECT gtpdp.id FROM #{#entityName} gtpdp WHERE gtpdp.device.id= ?1 and gtpdp.profileId = ?2 and gtpdp.id <> ?3")
    Set<Long> findByDeviceIdAndProfileIdAndIdNotIn(Long deviceId, Long profileId, Long id);

    @Query(value = "SELECT gtpdp.id FROM #{#entityName} gtpdp WHERE gtpdp.device.id= ?1 and gtpdp.name = ?2 and gtpdp.id <> ?3")
    Set<Long> findByDeviceIdAndNameAndIdNotIn(Long deviceId, String name, Long id);

    @Query(value = "SELECT gtpdp.id FROM #{#entityName} gtpdp WHERE gtpdp.device.id= ?1 and gtpdp.profileId = ?2")
    Set<Long> findByDeviceIdAndProfileId(Long deviceId, Long profileId);

    @Query(value = "SELECT gtpdp.id FROM #{#entityName} gtpdp WHERE gtpdp.device.id= ?1 and gtpdp.name = ?2")
    Set<Long> findByDeviceIdAndName(Long deviceId, String name);

}
