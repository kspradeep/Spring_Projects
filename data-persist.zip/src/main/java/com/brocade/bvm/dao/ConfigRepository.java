package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.admin.ApplicationConfig;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ConfigRepository extends CrudRepository<ApplicationConfig, Long> {

    @Query(value = "Select c from #{#entityName} c where c.id = ?1")
    ApplicationConfig findOne(Long id);

    ApplicationConfig findByKey(ApplicationConfig.Key key);
}
