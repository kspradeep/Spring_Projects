package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.Profile;
import com.brocade.bvm.model.db.sessiondirector.ProfileInterfaceMapping;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProfileInterfaceMappingRepository extends CrudRepository<ProfileInterfaceMapping, Long> {
    @Query(value = "Select pi from #{#entityName} pi where pi.profile = ?1")
    List<ProfileInterfaceMapping> findByProfile(Profile profile);
}
