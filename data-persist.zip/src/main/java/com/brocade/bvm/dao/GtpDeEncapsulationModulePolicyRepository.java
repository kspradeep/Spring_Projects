package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.GtpDeEncapsulationModulePolicy;
import com.brocade.bvm.model.db.Port;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GtpDeEncapsulationModulePolicyRepository extends CrudRepository<GtpDeEncapsulationModulePolicy, Long> {

    @Query(value = "Select po.id from #{#entityName} p JOIN p.ports po where p.device.id = ?1")
    List<Long> findPortIdsByDeviceId(Long deviceId);

    @Query(value = "Select po.id from #{#entityName} p JOIN p.ports po where p.device.isDeleted = 0 and po.type = ?1")
    List<Long> findPortIdsByPortType(Port.Type type);
}
