package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsPortRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import com.brocade.bvm.model.db.statistics.PortUtilization;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Service
@Slf4j
@Getter
public class TapPortCache {
  private TreeSet<PortUtilization> topFiveTapPorts =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  private TreeSet<PortUtilization> bottomFiveTapPorts =
      new StatisticsTreeSet<>(
          Comparator.comparing(PortUtilization::getUtilization)
              .thenComparing(PortUtilization::hashCode));
  @Inject private GridRepository gridRepository;
  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private DeviceRepository deviceRepository;
  @Inject private StatisticsPortRepository statisticsPortRepository;

  private void setBottomFiveTapPorts(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.trace("Start: set bottom five tap ports for device {}", device.getName());
    try {
      Set<DeviceGrid> grids = Sets.newConcurrentHashSet(gridRepository.findAll());
      AtomicDouble atomicDouble = new AtomicDouble(0);
      grids.forEach(
          grid ->
              grid.getSourceNodes()
                  .forEach(
                      gridCluster -> {
                        Long deviceId = getDeviceId(gridCluster.getId());
                        List<Long> ports = getALLTapPortsByDeviceId(deviceId);
                        if (ports.size() == 0) {
                          return;
                        }
                        if (StringUtils.isEmpty(deviceId)) {
                          log.error("Device id is empty for grid cluster {}", gridCluster.getId());
                        } else {
                          if (Objects.equals(device.getId(), deviceId)) {
                            interfaceStatistics.forEach(
                                interfaceStatistics1 -> {
                                  if (ports.contains(interfaceStatistics1.getPortId())) {
                                    atomicDouble.getAndAdd(
                                        interfaceStatistics1.getInLinkUtilization());
                                    PortUtilization portUtilization = new PortUtilization();
                                    portUtilization.setId(interfaceStatistics1.getPortId());
                                    portUtilization.setPort(interfaceStatistics1.getIfName());
                                    portUtilization.setUtilization(atomicDouble.doubleValue());
                                    if (atomicDouble.doubleValue() <= 0) {
                                      bottomFiveTapPorts.remove(portUtilization);
                                      return;
                                    }
                                    ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                                    lock.writeLock().lock();

                                    if (bottomFiveTapPorts.size() < 5) {
                                      bottomFiveTapPorts.add(portUtilization);
                                    } else {
                                      PortUtilization existingPort = bottomFiveTapPorts.pollLast();
                                      if (existingPort != null) {
                                        if (existingPort.getUtilization()
                                            > portUtilization.getUtilization()) {
                                          bottomFiveTapPorts.add(portUtilization);
                                        } else {
                                          bottomFiveTapPorts.add(existingPort);
                                        }
                                      }
                                    }

                                    lock.writeLock().unlock();
                                  }
                                });
                          }
                        }
                      }));
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    log.trace("End: set bottom five tap ports for device {}", device.getName());
  }

  @Async
  void setTopFiveTapPorts(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    log.trace("Start: set top five tap ports for device {}", device.getName());
    Set<DeviceGrid> grids;
    try {
      grids = Sets.newConcurrentHashSet(gridRepository.findAll());
      AtomicDouble atomicDouble = new AtomicDouble(0);
      grids.forEach(
          grid ->
              grid.getSourceNodes()
                  .forEach(
                      gridCluster -> {
                        Long deviceId = getDeviceId(gridCluster.getId());
                        List<Long> ports = getALLTapPortsByDeviceId(deviceId);
                        if (ports.size() == 0) {
                          return;
                        }
                        if (StringUtils.isEmpty(deviceId)) {
                          log.error("Device id is empty for grid cluster {}", gridCluster.getId());
                        } else {
                          if (device.getId() == deviceId) {
                            interfaceStatistics.forEach(
                                interfaceStatistics1 -> {
                                  if (ports.contains(interfaceStatistics1.getPortId())) {
                                    atomicDouble.getAndAdd(
                                        interfaceStatistics1.getInLinkUtilization());
                                    PortUtilization portUtilization = new PortUtilization();
                                    portUtilization.setId(interfaceStatistics1.getPortId());
                                    portUtilization.setPort(device.getName() + "-" + interfaceStatistics1.getIfName());
                                    portUtilization.setUtilization(atomicDouble.doubleValue());
                                    if (atomicDouble.doubleValue() <= 0) {
                                      try {
                                        if (topFiveTapPorts.isEmpty()) {
                                          return;
                                        }
                                        topFiveTapPorts.removeIf(
                                            portUtilization1 ->
                                                portUtilization1.getId()
                                                    == portUtilization.getId());
                                      } catch (Exception e) {
                                      }
                                      return;
                                    }
                                    ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                                    lock.writeLock().lock();

                                    if (topFiveTapPorts.size() < 5) {
                                      topFiveTapPorts.add(portUtilization);
                                    } else {
                                      PortUtilization existingPort = topFiveTapPorts.pollFirst();
                                      if (existingPort != null) {
                                        if (existingPort.getUtilization()
                                            < portUtilization.getUtilization()) {
                                          topFiveTapPorts.add(portUtilization);
                                        } else {
                                          topFiveTapPorts.add(existingPort);
                                        }
                                      }
                                    }

                                    lock.writeLock().unlock();
                                  }
                                });
                          }
                        }
                      }));
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    //    if (this.topFiveTapPorts.size() >= 5) {
    //      this.setBottomFiveTapPorts(device, interfaceStatistics);
    //    }
    log.trace("End: set top five tap ports for device {}", device.getName());
  }

  private Long getDeviceId(Long id) {
    try {
      return jdbcTemplate.queryForObject(
          "select gc.device_id from bvm.grid_cluster gc where gc.id=?",
          new Object[] {id},
          Long.class);
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  public List<Long> getALLTapPortsByDeviceId(Long id) {
    List<Long> ports = new ArrayList<>();
    Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
    deviceGrids.forEach(
        deviceGrid ->
            deviceGrid
                .getSourceNodes()
                .forEach(
                    networkNode -> {
                      Long deviceId = getDeviceId(networkNode.getId());
                      if (Objects.equals(deviceId, id)) {
                        networkNode
                            .getClusterNodeInterfaces()
                            .forEach(
                                clusterNodeInterface -> {
                                  List<Long> managedObjectIds =
                                      getManagedObjectId(clusterNodeInterface.getId());
                                  ports.addAll(managedObjectIds);
                                });
                      }
                    }));
    return ports;
  }

  private List<Long> getManagedObjectId(Long clusterNodeId) {
    return jdbcTemplate.query(
        "select cn.managed_object_id from bvm.cluster_node_port_mapping cn where cn.cluster_node_id=?",
        new Object[] {clusterNodeId},
        rowMapper);
  }

  private RowMapper<Long> rowMapper = (ResultSet rs, int rowNum) -> rs.getLong("managed_object_id");
}
