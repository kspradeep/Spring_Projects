package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.ModulePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface ModulePolicyRepository extends CrudRepository<ModulePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    ModulePolicy findOne(Long id);

    @Query(value = "SELECT mp FROM #{#entityName} mp JOIN mp.modules mo WHERE mo.device.id= ?1")
    public List<ModulePolicy> findByDeviceId(Long deviceId);

    public ModulePolicy findById(Long modulePolicyId);

    @Query(value = "SELECT mp FROM #{#entityName} mp JOIN mp.modules mo WHERE mo.id= ?1")
    public List<ModulePolicy> findByModuleId(Long moduleId);

    @Query(value = "SELECT mp FROM #{#entityName} mp WHERE mp.objectType = ?1")
    public Set<ModulePolicy> findByType(String type);

}
