package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.Flow;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public interface FlowRepository extends CrudRepository<Flow, Long> {

    @Query(value = "Select f from #{#entityName} f where f.id = ?1")
    Flow findOne(Long id);

    @Query(value = "SELECT fpmi.managed_object_id FROM flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and fpmi.flow_id=f.id and fpmi.managed_object_id IN ?1", nativeQuery = true)
    List<BigInteger> findManagedObjectIdsInIngressPortMapping(List<Long> managedObjectIds);

    @Query(value = "SELECT f.policy_id FROM flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and fpmi.flow_id=f.id and fpmi.managed_object_id IN ?1", nativeQuery = true)
    List<BigInteger> findPolicyIdsInIngressPortMapping(List<Long> portIds);

    @Query(value = "SELECT f.policy_id FROM flow f, policy p, flow_port_mapping_egress fpme WHERE f.policy_id=p.id and fpme.flow_id=f.id and fpme.managed_object_id IN ?1", nativeQuery = true)
    List<BigInteger> findPolicyIdsInEgressPortMapping(List<Long> portIds);

    @Query(value = "SELECT distinct(f.policy_id), fpmi.managed_object_id, p.device_id FROM flow f, policy p, flow_port_mapping_ingress fpmi WHERE p.is_grid_policy=0 and f.policy_id=p.id and fpmi.flow_id=f.id and fpmi.managed_object_id IN ?1", nativeQuery = true)
    List<Object[]> findNonGridPolicyInfoInIngressPortMappingById(List<Long> portIds);

    @Query(value = "select f.policy_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id and fpmi.managed_object_id in (?2) and f.sequence=?3", nativeQuery = true)
    List<Long> findByDeviceIdAndIngressPortsAndSequence(Long deviceId, Set<Long> ingressPort, Integer sequence);

    @Query(value = "select f.policy_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id and fpmi.managed_object_id in (?2)", nativeQuery = true)
    List<Long> findByDeviceIdAndIngressPorts(Long deviceId, Set<Long> ingressPort);

    @Query(value = "select f.policy_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id and fpmi.managed_object_id in (?2) and p.id <> ?3", nativeQuery = true)
    List<Long> findByDeviceIdAndIngressPortsAndPolicyId(Long deviceId, Set<Long> ingressPort, Long policyId);

    @Query(value = "select f.policy_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id and fpmi.managed_object_id in (?2) and f.sequence=?3 and p.id <> ?4", nativeQuery = true)
    List<Long> findByDeviceIdAndIngressPortsAndSequenceAndId(Long deviceId, Set<Long> ingressPort, Integer sequence, Long policyId);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id=?2 and fpme.managed_object_id in ?3 and fl.is_tagged <> ?4 and p.id <> ?5", nativeQuery = true)
    List<Long> findByVlanAndEgressPortsAndTaggedNotInPolicy(Long deviceId, String vlanId, Set<Long> egressPorts, boolean tagged, Long policyId);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id=?2 and fpme.managed_object_id in ?3 and fl.is_tagged <> ?4", nativeQuery = true)
    List<Long> findByVlanAndEgressPortsAndTagged(Long deviceId, String vlanId, Set<Long> egressPorts, boolean tagged);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id<>?2 and fpme.managed_object_id in ?3 and fl.is_tagged = ?4 and fl.id <> ?5", nativeQuery = true)
    Set<Long> findByVlanNotInAndEgressPortsAndTaggedAndFlowIdNotIn(Long deviceId, String vlanId, Set<Long> egressPorts, boolean tagged, Long flowId);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id<>?2 and fpme.managed_object_id in ?3 and fl.is_tagged = ?4", nativeQuery = true)
    Set<Long> findByVlanNotInAndEgressPortsAndTagged(Long deviceId, String vlanId, Set<Long> egressPorts, boolean tagged);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and p.id <> ?2 and fvm.vlan_id=?3 and fpme.managed_object_id in ?4 and fl.is_tagged = ?5", nativeQuery = true)
    List<Long> findByVlanAndEgressPortsAndTaggedNotInCurrentPolicy(Long deviceId, Long policyId, String vlanId, Set<Long> egressPorts, boolean tagged);

    @Query(value = "select fl.id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl, policy p where fl.tvf_domain = 1 and fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and p.id <> ?2 and fvm.vlan_id=?3 and fpme.managed_object_id in ?4", nativeQuery = true)
    List<Long> findByTvfDomainAndEgressPortsAndNotInCurrentPolicy(Long deviceId, Long policyId, String vlanId, Set<Long> egressPorts);

    @Query(value = "select fvm.vlan_id from flow_vlan_mapping fvm, flow fl, policy p where fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1", nativeQuery = true)
    List<String> findVlansByDeviceId(Long deviceId);

    @Query(value = "select f.policy_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id and fpmi.managed_object_id in (?2)", nativeQuery = true)
    List<BigInteger> findPolicyIdByDeviceIdAndACLName(Long deviceId, Long portId);

    @Query(value = "select f.policy_id from flow f where f.packet_truncation_mapping_id = ?1", nativeQuery = true)
    Set<BigInteger> findByPacketTruncationMappingId(Long truncationMappingId);

    @Query(value = "select f from #{#entityName} f WHERE f.policy.id = ?1 and f.sequence = ?2")
    List<Flow> findByPolicyIdAndFlowSequenceId(Long policyId, Integer flowSequence);

    @Query(value = "select fpmi.managed_object_id from flow f, policy p, flow_port_mapping_ingress fpmi WHERE f.policy_id=p.id and p.device_id = ?1 and fpmi.flow_id=f.id", nativeQuery = true)
    List<BigInteger> findManagedObjectIdsByDeviceId(Long deviceId);

    @Query(value = "select fl.id, fl.tvf_domain, fl.is_tagged, fvm.vlan_id from flow_port_mapping_egress fpme, flow_vlan_mapping fvm, flow fl where fpme.flow_id = fvm.flow_id and fvm.flow_id=fl.id and fpme.managed_object_id = ?1", nativeQuery = true)
    List<Object[]> findVlanByEgressPortGroup(Long egressPortGroupId);

    @Query(value = "select fvm.vlan_id, fl.tvf_domain from flow_vlan_mapping fvm, flow fl, policy p where fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id= ?2 and fl.tvf_domain=1", nativeQuery = true)
    List<String> findTvfVlansByDeviceIdAndVlan(Long deviceId, String vlanId);

    @Query(value = "select fvm.vlan_id, fl.tvf_domain from flow_vlan_mapping fvm, flow fl, policy p where fvm.flow_id=fl.id and fl.policy_id=p.id and p.device_id = ?1 and fvm.vlan_id= ?2 and fl.tvf_domain=0", nativeQuery = true)
    List<String> findFlowVlansByDeviceIdAndVlan(Long deviceId, String vlanId);
}
