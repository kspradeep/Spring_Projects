package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.model.db.statistics.CollectorDeviceMapping;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CollectorDeviceMappingRepository extends CrudRepository<CollectorDeviceMapping, Long> {
    @Query(value = "SELECT cdm FROM #{#entityName} cdm WHERE cdm.device.id = ?1 and cdm.profileType = ?2")
    CollectorDeviceMapping findByDeviceIdAndProfileType(Long deviceId, CollectorDeviceMapping.TYPE profileType);
}
