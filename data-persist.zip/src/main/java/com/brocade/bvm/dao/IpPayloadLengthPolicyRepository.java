package com.brocade.bvm.dao;


import com.brocade.bvm.model.IpPayloadLengthPolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IpPayloadLengthPolicyRepository extends CrudRepository<IpPayloadLengthPolicy, Long> {
    @Query(value = "select mpm.module_id from module_policy_mapping mpm where mpm.module_id in ?1", nativeQuery = true)
    List<Long> findModulesByModuleIds(List<Long> moduleIds);

    @Query(value = "select iplp.id from ip_payload_length_policy iplp, module_policy_mapping mpm where mpm.module_policy_id=iplp.id and mpm.module_id in ?1 AND iplp.ip_type=?2", nativeQuery = true)
    List<Long> findIpPayloadLengthPolicyByModuleIds(List<Long> moduleIds, String ipType);
}
