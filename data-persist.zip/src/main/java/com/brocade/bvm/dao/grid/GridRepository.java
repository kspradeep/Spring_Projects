package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.DeviceGrid;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

public interface GridRepository extends CrudRepository<DeviceGrid, Long> {

    @Query(value = "SELECT g from #{#entityName} g WHERE g.name = ?1")
    DeviceGrid findByName(String name);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM managed_object WHERE id = ?1", nativeQuery = true)
    Integer deleteById(Long gridId);

    @Query(value = "SELECT g.name from #{#entityName} g WHERE g.id = ?1")
    String findNameById(Long gridId);
}
