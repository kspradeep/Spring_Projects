package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.GridTopologyPath;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public interface GridTopologyPathRepository extends CrudRepository<GridTopologyPath, Long> {

    @Query(value = "Select p from #{#entityName} p where p.pathId = ?1 AND p.isActive = ?2")
    Set<GridTopologyPath> findAllByPathIdAndIsActive(Long pathId, Boolean isActive);

    @Query(value = "Select p from #{#entityName} p where p.policySetId = ?1 AND p.pathId = ?2 AND p.isActive = ?3")
    Set<GridTopologyPath> findAllByPathIdAndPolicyIdAndIsActive(Long policySetId, Long pathId, Boolean isActive);

    @Query(value = "Select p from #{#entityName} p where p.pathId = ?1 AND p.isActive = ?2")
    GridTopologyPath findByPathIdAndIsActive(Long pathId, Boolean isActive);

    @Query(value = "Select p from #{#entityName} p where p.isActive = ?1")
    Set<GridTopologyPath> getAllPaths(Boolean isActive);

    @Query(value = "Select count(*) from #{#entityName} p where p.isActive = ?1")
    Integer getAllPathCount(Boolean isActive);

    @Query(value = "Select p.toolAddress from #{#entityName} p Order by p.toolAddress")
    Set<Integer> getAllToolAddresses();

    @Query(value = "Select p.pathId from #{#entityName} p where p.policySetId = ?1 AND p.isActive= ?2")
    Set<Long> findByPolicySetIdAndIsActive(Long policySetId, Boolean isActive);

    @Query(value = "Select p.id from grid_topology_path p JOIN tap_node_interface_mapping t where p.policy_set_id = ?1 AND p.id = t.topology_path_id AND t.tap_node_interface_id= ?2", nativeQuery = true)
    Set<BigInteger> findByPolicySetIdAndSourceInterfaceId(Long policySetId, Long tapNodeInterfaceId);

    @Query(value = "Select p.id from grid_topology_path p where p.policy_set_id = ?1 AND p.tool_node_interface_id= ?2", nativeQuery = true)
    Set<BigInteger> findByPolicySetIdAndDestinationInterfaceId(Long policySetId, Long toolNodeInterfaceId);

    @Query(value = "Select p.node_id from intermediate_node_interface_mapping_ingress p where p.managed_object_id in ?1", nativeQuery = true)
    Set<Long> findIntermediateIngressByManagedObjectId(List<Long> managedObjectIds);

    @Query(value = "Select p.node_id from intermediate_node_interface_mapping_egress p where p.managed_object_id in ?1", nativeQuery = true)
    Set<Long> findIntermediateEgressByManagedObjectId(List<Long> managedObjectIds);

    @Query(value = "Select p.node_id from network_node_interface_mapping_ingress p where p.managed_object_id in ?1", nativeQuery = true)
    Set<Long> findSourceIngressByManagedObjectId(List<Long> managedObjectIds);

    @Query(value = "Select p.node_id from network_node_interface_mapping_egress p where p.managed_object_id in ?1", nativeQuery = true)
    Set<Long> findDestinationEgressByManagedObjectId(List<Long> managedObjectIds);

    @Query(value = "Select p.policySetId from #{#entityName} p JOIN p.intermediateNodes n where n.id= ?1")
    Set<Long> findPoicySetIdByIntermediateDeviceId(Long intermediateNodeId);
}
