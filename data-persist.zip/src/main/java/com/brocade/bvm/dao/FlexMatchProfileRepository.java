package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.FlexMatchProfile;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface FlexMatchProfileRepository extends CrudRepository<FlexMatchProfile, Long> {

    @Query(value = "Select po from #{#entityName} po where po.name = ?1")
    FlexMatchProfile findByName(String name);
}
