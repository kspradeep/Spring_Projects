package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.sessiondirector.EgressPort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EgressPortRepository extends CrudRepository<EgressPort, Long> {

    List<EgressPort> findByDeviceId(Long deviceId);

    EgressPort findByIsDefaultTrueAndDeviceId(Long deviceId);

    @Query(value = "Select egress from #{#entityName} egress where egress.device.id= ?1 and egress.isDefault=1")
    EgressPort findDefaultPortByDeviceId(Long deviceId);

    @Query(value = "Select egress from #{#entityName} egress where egress.device.id= ?1 and egress.isDefault=0")
    List<EgressPort> findEgressPortsByIsDefaultFalseAndDeviceId(Long deviceId);

    @Query(value = "SELECT pg.id FROM #{#entityName} pg WHERE pg.sourcePort.id IN ?1")
    List<Long> findEgressPortIdsByPortIds(List<Long> portIds);

    @Query(value = "SELECT pg FROM #{#entityName} pg WHERE pg.sourcePort.id IN ?1")
    List<EgressPort> findEgressPortByPortIds(List<Long> portIds);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2")
    List<Long> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> acceptableStatus);
}
