package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.sessiondirector.FilterPolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface FilterPolicyRepository extends CrudRepository<FilterPolicy, Long> {
    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2 AND po.id <> ?3")
    List<FilterPolicy> findByNameAndDeviceForUpdate(String name, Long deviceId, Long policyId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2")
    List<FilterPolicy> findByNameAndDevice(String name, Long deviceId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2")
    List<FilterPolicy> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> notAcceptableStatus);

    @Query(value = "SELECT fp from #{#entityName} fp WHERE fp.device.id = ?1")
    List<FilterPolicy> findAllByDeviceId(Long deviceId);

    @Query(value = "SELECT r.portGroup.id from #{#entityName} f JOIN f.rules r WHERE f.id = r.policy.id")
    List<Long> findPortGroupUsedInFilter();

    @Query(value = "SELECT r.samplingPolicy.id from #{#entityName} f JOIN f.rules r WHERE f.id = r.policy.id")
    List<Long> findSamplingPolicyUsedInFilter();

    @Query(value = "SELECT r.samplingPolicy.id from #{#entityName} f JOIN f.rules r WHERE f.id=r.policy.id AND r.samplingPolicy.id = ?1")
    List<FilterPolicy> findFilterPolicyBasedOnSamplingPolicyId(Long deviceId);

    @Query(value = "SELECT r.policy.id from #{#entityName} f JOIN f.rules r WHERE f.id = r.policy.id AND (r.imsiFileName = ?1 OR r.imeiFileName = ?1 OR r.apnFileName = ?1 OR r.sipCallingPartyFileName = ?1 OR r.sipCalledPartyFileName = ?1)")
    List<Long> findImsiFileUsedInFilterRule(String imsiFileName);

}
