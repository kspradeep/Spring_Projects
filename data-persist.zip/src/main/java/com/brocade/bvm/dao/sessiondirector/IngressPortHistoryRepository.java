package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import org.springframework.data.repository.CrudRepository;

public interface IngressPortHistoryRepository extends CrudRepository<IngressPort, Long> {


}
