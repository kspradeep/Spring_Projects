package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.Job;
import com.brocade.bvm.model.db.history.HistoryObject;
import com.brocade.bvm.model.db.history.PortHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PortHistoryRepository extends CrudRepository<PortHistory, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PortHistory findOne(Long id);

    @Query(value = "Select mp from #{#entityName} mp where mp.parentId= ?1 AND mp.workflowStatus = ?2 Order by mp.revisionTime DESC")
    List<PortHistory> findByIdAndWorkflowStatus(Long portId, WorkflowStatus status);

    List<PortHistory> findTop1ByParentIdAndWorkflowStatusOrderByRevisionTimeDesc(Long parentId, WorkflowStatus status);

    @Query(value = "Select mp from #{#entityName} mp where mp.parentId= ?1 AND mp.revisionType = ?2 Order by mp.revisionTime DESC")
    List<PortHistory> findByIdAndRevisionType(Long portId, HistoryObject.RevisionType revisionType);

    List<PortHistory> findTop5ByParentIdAndWorkflowStatusAndLineSpeedNotInOrderByRevisionTimeDesc(Long portId, WorkflowStatus status, List<Long> breakoutSpeeds);

    List<PortHistory> findTop5ByParentIdInAndWorkflowStatusAndWorkflowTypeOrderByRevisionTimeDesc(List<Long> parentIds, WorkflowStatus status, Job.Type type);

}
