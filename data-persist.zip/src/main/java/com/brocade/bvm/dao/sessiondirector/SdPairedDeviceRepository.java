package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.PairedDevice;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface SdPairedDeviceRepository extends CrudRepository<PairedDevice, Long> {

    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1")
    PairedDevice findByDeviceId(Long deviceId);

    @Query(value = "Select d from #{#entityName} d where d.targetDevice.id = ?1 AND d.device.isDeleted = 0")
    PairedDevice findByTargetDeviceId(Long targetDeviceId);
}
