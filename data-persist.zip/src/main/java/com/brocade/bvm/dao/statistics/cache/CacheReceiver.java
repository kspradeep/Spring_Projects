package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.util.Set;

@Service
@Slf4j
public class CacheReceiver {
  @Inject private TapPortCache tapPortCache;
  @Inject private GridCache gridCache;
  @Inject private SwitchCache switchCache;
  @Inject private ToolPortCache toolPortCache;
  @Inject private PortCache portCache;

  @Async
  public void receiveDeviceStats(Device device, Set<InterfaceStatistics> interfaceStatistics) {
    if (StringUtils.isEmpty(device) || StringUtils.isEmpty(interfaceStatistics)) {
      log.error("Received statistics for device where device is null");
      return;
    }

    log.trace("Start: receiving data from collector for device {}", device.getName());
    try{
//    switchCache.setTopFiveSwitches(device, interfaceStatistics);
    switchCache.saveDeviceStatisctisc(device, interfaceStatistics);
//    tapPortCache.setTopFiveTapPorts(device, interfaceStatistics);
//    toolPortCache.setTopFiveToolPorts(device, interfaceStatistics);

//    gridCache.setTopFiveGrids(device);

//    portCache.setFiveIngressAndEgress(device, interfaceStatistics);
    }catch (Exception e) {
      log.error("Error while receiving stats {}",e.getMessage());
    }

    log.trace("End: receiving data from collector for device {}", device.getName());
  }
}
