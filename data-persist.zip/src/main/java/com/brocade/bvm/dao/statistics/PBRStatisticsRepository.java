package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.model.db.statistics.PBRStatistics;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

public interface PBRStatisticsRepository extends CrudRepository<PBRStatistics, Long> {

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE FROM pbr_statistics WHERE received_time  < DATE_SUB(NOW(), INTERVAL ? SECOND)")
    Integer deletePBRStatistics(Long timeInterval);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE pbr FROM pbr_statistics pbr, collector_device_mapping cm WHERE pbr.collector_device_id=cm.id AND cm.device_id=?1")
    Integer deletePBRStatisticsByCollectorId(Long collectorId);
}
