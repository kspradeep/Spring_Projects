package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.statistics.*;
import com.brocade.bvm.util.SQLFileLoader;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
@Slf4j
public class StatisticsPortRepository {

    @Inject
    JdbcTemplate jdbcTemplate;
    @Inject
    private GridRepository gridRepository;
    @Inject
    private PortRepository portRepository;
    @Inject
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<PortBandwidth> getPortUtilization(long portId) {
        Port port = portRepository.findOne(portId);
        AtomicLong maxSpeed = new AtomicLong(0);
        if (!Objects.isNull(port)) {
            maxSpeed.set(port.getMaxSpeed());
        }
        List<PortBandwidth> ports =
                jdbcTemplate.query(
                        "select i.in_band_width, i.out_band_width, i.in_link_utilization, i.out_link_utilization,i.received_time, i.last_updated_time, i.port_id from interface_statistics i where i.port_id=? ORDER by i.last_updated_time DESC limit 20",
                        new Object[]{portId},
                        portUtilizationRowMapper);
        if (ports != null && ports.size() > 0) {
            ports.forEach(p -> {
                p.setLineSpeed(maxSpeed.longValue());
                if (p.getInUtilization() > 100.00) {
                    p.setInUtilization(100);
                }
                if (p.getOutUtilization() > 100.00) {
                    p.setOutUtilization(100);
                }
            });
            ports.sort(Comparator.comparing(PortBandwidth::getLastUpdatedTime));
        }

        return ports;
    }

    public List<PortPackets> findPortPacketInformation(Long portId, int samples) {
        List<PortPackets> results =
                jdbcTemplate.query(
                        SQLFileLoader.loadQueryFromFile("stats-port-packets.sql"),
                        new Object[]{portId, samples},
                        portPacketsRowMapper);
        if (results != null && results.size() > 0) {
            results.sort(Comparator.comparing(PortPackets::getLastUpdatedTime));
        }

        return results;
    }

    public List<PortPacketsDrop> findGridDropPackets(List<Long> portIds, int samples) {
        List<PortPacketsDrop> results = null;
        if (portIds != null && portIds.size() > 0) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", portIds);
            parameters.addValue("limit", samples);
            results =
                    namedParameterJdbcTemplate.query(
                            SQLFileLoader.loadQueryFromFile("stats-port-group-packets-drop.sql"),
                            parameters,
                            portPacketsDropRowMapper);
        }
        if (results != null && results.size() > 0) {
            results.sort(Comparator.comparing(PortPacketsDrop::getLastUpdatedTime));
        }

        return results;
    }

    public List<PortPacketsError> findGridErrorPackets(List<Long> portIds, int samples) {
        List<PortPacketsError> results = null;
        if (portIds != null && portIds.size() > 0) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", portIds);
            parameters.addValue("limit", samples);
            results =
                    namedParameterJdbcTemplate.query(
                            SQLFileLoader.loadQueryFromFile("stats-port-group-packets-error.sql"),
                            parameters,
                            portPacketsErrorRowMapper);
        }
        if (results != null && results.size() > 0) {
            results.sort(Comparator.comparing(PortPacketsError::getLastUpdatedTime));
        }

        return results;
    }

    public List<PortBandwidth> findGridPortsUtilization(List<Long> portIds) {
        Long maxSpeed = getMaxSpeed(portIds);
        List<PortBandwidth> results = null;
        if (portIds != null && portIds.size() > 0) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", portIds);
            parameters.addValue("limit", 20);
            results =
                    namedParameterJdbcTemplate.query(
                            SQLFileLoader.loadQueryFromFile("stats-port-group-utilization.sql"),
                            parameters,
                            portUtilizationRowMapper);
        }
        if (results != null && results.size() > 0) {
            results.forEach(
                    result -> {
                        result.setLineSpeed(maxSpeed);
                        if (result.getInUtilization() > 100.00) {
                            result.setInUtilization(100.00);
                        }
                        if (result.getOutUtilization() > 100.00) {
                            result.setOutUtilization(100.00);
                        }
                    });
            results.sort(Comparator.comparing(PortBandwidth::getLastUpdatedTime));
        }
        return results;
    }

    private Long getMaxSpeed(List<Long> portIds) {
        Long result = 0l;
        MapSqlParameterSource map = new MapSqlParameterSource();
        map.addValue("ids", portIds);
        try {
            result = namedParameterJdbcTemplate.queryForObject(
                    "select sum(max_speed) as max from port where id IN (:ids)",
                    map, ((rs, rowNum) -> rs.getLong("max")));
        } catch (DataAccessException e) {
            log.error("Error while getting the max speed of ports {}", portIds);
        }
        return result;
    }

    public List<PortPackets> findGridPackets(List<Long> portIds, int samples) {
        List<PortPackets> results = null;
        if (portIds != null && portIds.size() > 0) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", portIds);
            parameters.addValue("limit", samples);
            results =
                    namedParameterJdbcTemplate.query(
                            SQLFileLoader.loadQueryFromFile("stats-port-group-port-packets.sql"),
                            parameters,
                            devicePortPacketsRowMapper);
        }
        if (results != null && results.size() > 0) {
            results.sort(Comparator.comparing(PortPackets::getLastUpdatedTime));
        }

        return results;
    }

    public List<PortPacketType> findGridPacketsType(List<Long> portIds, int samples) {
        List<PortPacketType> results = null;
        if (portIds != null && portIds.size() > 0) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", portIds);
            parameters.addValue("limit", samples);
            results =
                    namedParameterJdbcTemplate.query(
                            SQLFileLoader.loadQueryFromFile("stats-port-group-packet-type.sql"),
                            parameters,
                            portPacketTypeRowMapper);
        }
        if (results != null && results.size() > 0) {
            results.sort(Comparator.comparing(PortPacketType::getLastUpdatedTime));
        }

        return results;
    }

    public EVMOverview evmOverview() {
        return jdbcTemplate.queryForObject(
                SQLFileLoader.loadQueryFromFile("stats-evm-overview.sql"), evmOverviewRowMapper);
    }

    public List<PortPacketType> portTypePackets(Long portId, int samples) {
        return jdbcTemplate.query(
                SQLFileLoader.loadQueryFromFile("stats-port-packet-type.sql"),
                new Object[]{portId, samples},
                portPacketTypeRowMapper);
    }

    public List<PortPacketsDrop> portDropPackets(Long portId, int samples) {
        return jdbcTemplate.query(
                SQLFileLoader.loadQueryFromFile("stats-port-packets-drop.sql"),
                new Object[]{portId, samples},
                portPacketsDropRowMapper);
    }

    ;

    public List<PortPacketsError> portErrorPackets(Long portId, int samples) {
        return jdbcTemplate.query(
                SQLFileLoader.loadQueryFromFile("stats-port-packets-error.sql"),
                new Object[]{portId, samples},
                portPacketsErrorRowMapper);
    }

    public Map<String, Long> getGridTapAndToolPorts() {
        AtomicLong tapPorts = new AtomicLong(0);
        AtomicLong toolPorts = new AtomicLong(0);
        Set<DeviceGrid> grids = Sets.newHashSet(gridRepository.findAll());
        if (grids != null) {
            grids.forEach(
                    grid -> {
                        if (!StringUtils.isEmpty(grid)) {
                            grid.getSourceNodes().stream()
                                    .forEach(
                                            module ->
                                                    tapPorts.getAndAdd(module.getClusterNodeInterfaces().stream().count()));
                            grid.getDestinationNodes()
                                    .forEach(
                                            module ->
                                                    toolPorts.getAndAdd(module.getClusterNodeInterfaces().stream().count()));
                        }
                    });
        }

        Map<String, Long> ports = new HashMap<>();
        ports.put("tap", tapPorts.longValue());
        ports.put("tool", toolPorts.longValue());
        return ports;
    }

    public long getALLTapPortsCount() {
        long gridTaps = getGridTapAndToolPorts().get("tap");
        long ingress = getAllIngressAndEgressTapPorts().get("ingress");
        return ingress + gridTaps;
    }

    public Map<String, Long> getAllIngressAndEgressTapPorts() {
        long ingress = 0;
        long egress = 0;
        Set<Port> ingressPorts =
                Sets.newHashSet(
                        portRepository.findPortByDeviceTypeAndPortTypeAndNotDeleted(
                                Device.Type.SLX, Port.Type.INGRESS));
        Set<Port> servicePorts =
                Sets.newHashSet(
                        portRepository.findPortByDeviceTypeAndPortTypeAndNotDeleted(
                                Device.Type.SLX, Port.Type.SERVICE_PORT));
        if (ingressPorts != null && !ingressPorts.isEmpty()) {
            ingress = ingressPorts.size();
        }
        if (servicePorts != null && !servicePorts.isEmpty()) {
            ingress = ingress + servicePorts.size();
        }
        Set<Port> egressPorts =
                Sets.newHashSet(
                        portRepository.findPortByDeviceTypeAndPortTypeAndNotDeleted(
                                Device.Type.SLX, Port.Type.EGRESS));
        if (egressPorts != null && !egressPorts.isEmpty()) {
            egress = egressPorts.size();
        }

        Map<String, Long> tapTool = new HashMap<>();
        tapTool.put("ingress", ingress);
        tapTool.put("egress", egress);
        return tapTool;
    }

    public long getAllToolPortsCount() {
        long gridTools = getGridTapAndToolPorts().get("tool");
        long egress = getAllIngressAndEgressTapPorts().get("egress");
        return egress + gridTools;
    }

    public int getAllGridPolicies() {
        return jdbcTemplate.queryForObject(
                "select count(*) from bvm.grid_policy_set g, bvm.managed_object mo where mo.id=g.id and mo.workflow_status='ACTIVE'",
                Integer.class);
    }

    public List<OnePolicyStatistics> findPolicyStatistics(String policyName, int samples) {
        String query =
                "select mo.name from bvm.port p, bvm.module m, bvm.managed_object mo where m.device_id IN(select p.device_id from bvm.policy p, bvm.managed_object mno where mno.name=?)";
        List<String> interfaces = jdbcTemplate.query(query, new Object[]{policyName}, interfacesNames);
        AtomicLong hitCount = new AtomicLong();
        AtomicLong byteCount = new AtomicLong();
        interfaces.forEach(
                s -> {
                    Long hits = 0L;
                    try {
                        hits =
                                jdbcTemplate.queryForObject(
                                        "select pb.hit_count from bvm.pbr_statistics pb where pb.interface_name=?",
                                        new Object[]{s},
                                        Long.class);
                    } catch (EmptyResultDataAccessException e) {
                        log.error("PBR stats for interface {} not available", s);
                    }

                    hitCount.getAndAdd(hits);
                    Long bytes = 0L;
                    try {
                        bytes =
                                jdbcTemplate.queryForObject(
                                        "select pb.byte_count from bvm.pbr_statistics pb where pb.interface_name=?",
                                        new Object[]{s},
                                        Long.class);
                    } catch (EmptyResultDataAccessException e) {
                        log.error("PBR stats for interface {} not available", s);
                    }

                    byteCount.getAndAdd(bytes);
                });

        OnePolicyStatistics onePolicyStatistics = new OnePolicyStatistics();
        onePolicyStatistics.setPacketHitCounts(hitCount.longValue());
        onePolicyStatistics.setByteCounts(byteCount.longValue());

        return null;
    }

    public long lineSpeed(long id) {
        Long lineSpeed = 0L;
        try {
            lineSpeed =
                    jdbcTemplate.queryForObject(
                            "select p.line_speed from port p where p.id=?", new Object[]{id}, Long.class);
        } catch (EmptyResultDataAccessException e) {
            log.warn("Line speed no specified for port {}", id);
        }
        if (lineSpeed == null) {
            lineSpeed = 0L;
        }
        return lineSpeed;
    }

    public List<Long> findPortsByTapId(Long id) {
        try {
            return jdbcTemplate.query(
                    "select managed_object_id from bvm.cluster_node_port_mapping c where c.cluster_node_id=?",
                    new Object[]{id},
                    (rs, rowNum) -> rs.getLong("managed_object_id"));
        } catch (DataAccessException e) {
            log.error("Error while pulling the ports of tap port {}", e.getMessage());
        }
        return null;
    }

    private RowMapper<String> interfacesNames = (ResultSet rs, int rowNum) -> rs.getString("name");

    private RowMapper<PortPackets> portPacketsRowMapper =
            (ResultSet rs, int rowNum) -> {
                PortPackets statisticsInterfaceSummary = new PortPackets();
                statisticsInterfaceSummary.setSequence(rowNum);
                statisticsInterfaceSummary.setReceivedTime(rs.getTimestamp("received_time").toString());
                statisticsInterfaceSummary.setInBytes(rs.getLong("in_octets"));
                statisticsInterfaceSummary.setOutBytes(rs.getLong("out_octets"));
                statisticsInterfaceSummary.setInPackets(rs.getLong("in_packets"));
                statisticsInterfaceSummary.setOutPackets(rs.getLong("out_packets"));
                statisticsInterfaceSummary.setInPPS(rs.getLong("in_pkts_per_second"));
                statisticsInterfaceSummary.setOutPPS(rs.getLong("out_pkts_per_second"));
                statisticsInterfaceSummary.setInPortsUtilization(rs.getLong("in_band_width"));
                statisticsInterfaceSummary.setOutPortUtilization(rs.getLong("out_band_width"));
                statisticsInterfaceSummary.setLastUpdatedTime(
                        rs.getTimestamp("last_updated_time").toString());
                statisticsInterfaceSummary.setThroughput(rs.getLong("in_band_width"));
                return statisticsInterfaceSummary;
            };

    private RowMapper<PortPacketsError> portPacketsErrorRowMapper =
            (ResultSet rs, int row) -> {
                PortPacketsError portPacketsError = new PortPacketsError();
                portPacketsError.setInPacketsError(rs.getLong("in_errors"));
                portPacketsError.setOutPacketsError(rs.getLong("out_errors"));
                portPacketsError.setLastUpdatedTime(rs.getTimestamp("last_updated_time").toString());
                return portPacketsError;
            };

    private RowMapper<EVMOverview> evmOverviewRowMapper =
            (ResultSet rs, int rowNum) -> {
                EVMOverview evmOverview = new EVMOverview();
                evmOverview.setTotalNoOfGrids(rs.getInt("totalGrids"));
                evmOverview.setTotalTapPorts(rs.getInt("totalTapPorts"));
                evmOverview.setTotalToolPorts(rs.getInt("totalToolPorts"));
                evmOverview.setTotalPolices(rs.getInt("totalPolicies"));
                return evmOverview;
            };

    private RowMapper<PortPacketType> portPacketTypeRowMapper =
            (ResultSet rs, int rowNum) -> {
                PortPacketType portPacketType = new PortPacketType();
                portPacketType.setInUniCastPackets(rs.getLong("in_unicast_pkts"));
                portPacketType.setOutUniCastPackets(rs.getLong("out_unicast_pkts"));
                portPacketType.setInMultiCastPackets(rs.getLong("in_multicast_pkts"));
                portPacketType.setOutMultiCastPackets(rs.getLong("out_multicast_pkts"));
                portPacketType.setInBroadcastPackets(rs.getLong("in_broadcast_pkts"));
                portPacketType.setOutBroadcastPackets(rs.getLong("out_broadcast_pkts"));
                portPacketType.setLastUpdatedTime(rs.getTimestamp("last_updated_time").toString());
                return portPacketType;
            };

    private RowMapper<PortPacketsDrop> portPacketsDropRowMapper =
            (ResultSet rs, int rowNum) -> {
                PortPacketsDrop portPacketsDrop = new PortPacketsDrop();
                portPacketsDrop.setInDropPackets(rs.getLong("in_discards"));
                portPacketsDrop.setOutDropPackets(rs.getLong("out_discards"));
                portPacketsDrop.setLastUpdatedTime(rs.getTimestamp("last_updated_time").toString());
                return portPacketsDrop;
            };

    private RowMapper<PortBandwidth> portUtilizationRowMapper =
            (ResultSet rs, int rowNum) -> {
                PortBandwidth portBandwidth = new PortBandwidth();
                portBandwidth.setInBandwidth(rs.getLong("in_band_width"));
                portBandwidth.setOutBandwidth(rs.getLong("out_band_width"));
                portBandwidth.setInUtilization(rs.getDouble("in_link_utilization"));
                portBandwidth.setOutUtilization(rs.getDouble("out_link_utilization"));
                portBandwidth.setInBandwidth(rs.getLong("in_band_width"));
                portBandwidth.setOutBandwidth(rs.getLong("out_band_width"));
                portBandwidth.setLastUpdatedTime(rs.getTimestamp("last_updated_time").toString());
                portBandwidth.setReceivedTime(rs.getTimestamp("received_time").toString());
                portBandwidth.setPortId(rs.getLong("port_id"));

                return portBandwidth;
            };

    private RowMapper<PortPackets> devicePortPacketsRowMapper =
            (ResultSet rs, int rowNum) -> {
                PortPackets portPackets = new PortPackets();
                portPackets.setInBytes(rs.getLong("in_octets"));
                portPackets.setOutBytes(rs.getLong("out_octets"));
                portPackets.setInPackets(rs.getLong("in_packets"));
                portPackets.setOutPackets(rs.getLong("out_packets"));
                portPackets.setInPPS(rs.getLong("in_pkts_per_second"));
                portPackets.setOutPPS(rs.getLong("out_pkts_per_second"));
                portPackets.setThroughput(rs.getLong("in_band_width"));
                portPackets.setLastUpdatedTime(rs.getTimestamp("i.last_updated_time").toString());
                return portPackets;
            };
}
