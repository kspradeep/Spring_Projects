package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.admin.CollectorRunningStatus;
import org.springframework.data.repository.CrudRepository;

public interface CollectorRunningStatusRepository extends CrudRepository<CollectorRunningStatus, Long> {
}