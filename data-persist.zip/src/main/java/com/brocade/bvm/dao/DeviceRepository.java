package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.Device;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.Instant;
import java.util.List;


public interface DeviceRepository extends CrudRepository<Device, Long> {

    @Query(value = "Select d from #{#entityName} d where d.id = ?1")
    Device findOne(Long id);

    @Query("SELECT d.id FROM device d WHERE d.stablenetId IN ?1 AND d.isDeleted = 0")
    List<Long> findIdsByStablenetIdIn(List<Long> stablenetIds);

    Device findById(Long id);

    @Query(value = "Select d from #{#entityName} d where d.chassis = ?1 AND d.isDeleted = 0")
    Device findByChassis(String chassis);

    @Query(value = "Select d.id, d.name, d.status from #{#entityName} d where d.chassis = ?1 AND d.isDeleted = 0 AND d.isProfileConfigured = 1 AND d.isReconciled = 1")
    Object findByChassisAndIsNotDeleted(String chassis);

    @Query("SELECT MAX(d.lastUpdatedTime) FROM device d WHERE d.isDeleted = 0")
    Instant getLastUpdatedTime();

    @Query(value = "SELECT d FROM #{#entityName} d JOIN d.modules m WHERE m.id = ?1")
    Device findByModuleId(Long moduleId);

    @Query(value = "SELECT d.id from #{#entityName} d where d.id = ?1 AND d.isDeleted = 0 AND d.isProfileConfigured = 1")
    Long findIdByIdAndIsDeletedAndIsProfileConfigured(Long id);

    @Query(value = "SELECT d.id from #{#entityName} d where d.id = ?1 AND d.isDeleted = ?2")
    Long findIdByIdAndIsDeleted(Long id, Boolean isDeleted);

    List<Device> findByIsDeletedFalse();

    List<Device> findByIsDeletedTrue();

    @Query("SELECT d FROM #{#entityName} d WHERE d.id IN ?1 AND d.type IN ?2 AND d.mode IN ?3 AND d.isDeleted = 0 and d.isReconciled = 1")
    List<Device> findByReconciledAndIsDeletedFalseAndTypeInAndModeIn(List<Long> stablenetIds, List<Device.Type> types, List<Device.Mode> modes);

    @Query(value = "SELECT d.id FROM #{#entityName} d where d.isDeleted = 0 and d.type='MLXE' and d.openflowId IS NULL and d.isReconciled = 0")
    List<Long> findAllMlxeDevicesNotReconciled();

    @Query(value = "SELECT d.id FROM #{#entityName} d where d.isDeleted = 0 and d.type='SLX' and d.model NOT LIKE '%SLX9850%' and d.openflowId IS NULL and d.isReconciled = 0")
    List<Long> findAllSLXDevicesNotReconciled();

    @Query(value = "select count(d) from #{#entityName} d where d.isReconciled = 1 AND d.isDeleted = 0 AND d.type IN ?1")
    Long getReconciledDeviceCountByType(List<Device.Type> types);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.id IN ?1 AND d.isReconciled = 1 AND d.isDeleted = 0")
    List<Device> findAllByIdsAndIsReconciled(List<Long> deviceIds);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.id = ?1 AND d.isReconciled = 1 AND d.isDeleted = 0")
    Device findByIdsAndIsReconciled(Long id);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.id IN ?1 AND d.isReconciled = 1 AND d.type IN ?2 AND d.isDeleted = 0 AND d.isProfileConfigured = 1")
    List<Device> findAllByIdsAndTypeAndReconciledAndProfileSet(List<Long> deviceIds, List<Device.Type> types);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.ipAddress = ?1 AND d.isReconciled = 1 AND d.isDeleted = 0")
    Device findByIpAddress(String ipAddress);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.id = ?1 AND d.isDeleted = 0 AND d.isReconciled = 1 AND d.type = ?2")
    Device findByIdAndTypeAndIsReconciled(Long id, Device.Type type);

    @Query(value = "SELECT d.id, d.os, d.model FROM #{#entityName} d WHERE d.isDeleted = 0 AND d.isReconciled = 1 AND d.type IN ?1 AND d.isProfileConfigured = ?2")
    List<Object[]> findAllByTypeAndIsReconciledAndIsProfileConfigured(List<Device.Type> types, Boolean isProfileConfigured);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.isDeleted = 0 AND d.isReconciled = 1 AND d.type IN ?1 AND d.authenticationConfigured = ?2")
    List<Device> findByTypeAndIsReconciledAndIsAuthenticated(List<Device.Type> types, Boolean isAuthenticationConfigured);

    @Query(value = "SELECT d FROM #{#entityName} d WHERE d.isDeleted = 0 AND d.isReconciled = 1 AND d.authenticationConfigured = 1 AND d.type IN ?1 AND d.authorizationConfigured = ?2")
    List<Device> findByTypeAndIsReconciledAndAuthenticatedAndIsAuthorized(List<Device.Type> types, Boolean isAuthorizationConfigured);

    @Query(value = "SELECT d.name FROM #{#entityName} d WHERE d.id = ?1")
    String findNameById(Long id);

    @Query(value = "SELECT count(1) FROM #{#entityName} d WHERE d.isReconciled = 1 AND d.isDeleted = 0 AND d.type IN ?1 AND d.isProfileConfigured = ?2 AND d.status = ?3")
    Integer getCountByTypeAndIsReconciledAndIsProfileConfiguredAndStatus(List<Device.Type> types, Boolean isProfileConfigured, Integer status);

    @Query(value = "select d from #{#entityName} d where d.isReconciled = 1 AND d.isDeleted = 0 AND d.type IN ?1")
    List<Device> getDevicesByType(List<Device.Type> types);

    @Query(value = "select d from #{#entityName} d where d.isDeleted = 0 AND d.id IN ?1")
    List<Device> getdevicesNotDeletedByDeviceId(List<Long> idList);
}
