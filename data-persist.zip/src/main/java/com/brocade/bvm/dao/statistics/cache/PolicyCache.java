package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.grid.GridPolicySetRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.statistics.PolicyUtilization;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
public class PolicyCache {
  @Inject private GridPolicySetRepository gridPolicySetRepository;
  @Inject private JdbcTemplate jdbcTemplate;

  private TreeSet<PolicyUtilization> topFivePolicies =
      new StatisticsTreeSet<>(Comparator.comparing(PolicyUtilization::getHits).thenComparing(PolicyUtilization::hashCode));

  public List<String> getTopFivePoliciesByHitCount(Long gridId) {
    List<String> policies = new ArrayList<>();
    List<GridPolicySet> gridPolicySets =
        gridPolicySetRepository.findByGridId(gridId);
    if (gridPolicySets.size() <= 0) {
      return policies;
    }
    for (GridPolicySet policySet : gridPolicySets) {
      if (StringUtils.isEmpty(policySet)) {
        return policies;
      }
      if (policySet.getWorkflowStatus().equals(WorkflowParticipant.WorkflowStatus.ACTIVE)) {
        policySet
            .getGridPolicies()
            .forEach(
                gridPolicy -> {
                  Long policyId = gridPolicy.getId();
                  String policyName = gridPolicy.getName();
                  if (!StringUtils.isEmpty(policyId)) {
                    Long hits = getHits(policyId);
                    if (StringUtils.isEmpty(hits)) {
                      hits = 0L;
                    }
                    PolicyUtilization policyUtilization = new PolicyUtilization();
                    policyUtilization.setHits(hits);
                    policyUtilization.setId(policyId);
                    policyUtilization.setName(policyName);

                    if (topFivePolicies.size() < 5) {
                      topFivePolicies.add(policyUtilization);
                    } else {
                      PolicyUtilization existing = topFivePolicies.pollLast();
                      if (existing != null && (existing.getHits() < policyUtilization.getHits())) {
                        topFivePolicies.add(policyUtilization);
                      } else {
                        topFivePolicies.add(existing);
                      }
                    }
                  }
                });
      }
    }
    if (this.topFivePolicies.size() > 5) {
      policies =
          topFivePolicies.stream().map(PolicyUtilization::getName).collect(Collectors.toList());
    }

    return policies;
  }

  private Long getHits(Long policyId) {
    try {
      return jdbcTemplate.queryForObject(
          "select sum(hit_count) from bvm.acl acl where acl.acl_statistics_id IN(select acls.id from bvm.acl_statistics acls where acls.policy_id=?)",
          new Object[] {policyId},
          Long.class);
    } catch (EmptyResultDataAccessException e) {
      return 0L;
    }
  }
}
