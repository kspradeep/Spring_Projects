package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.sessiondirector.DeDupePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface DedupePolicyRepository extends CrudRepository<DeDupePolicy, Long> {
    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2 AND po.id <> ?3")
    List<DeDupePolicy> findByNameAndDeviceForUpdate(String name, Long deviceId, Long policyId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2")
    List<DeDupePolicy> findByNameAndDevice(String name, Long deviceId);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2")
    List<Long> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> notAcceptableStatus);

    @Query(value = "SELECT dp from #{#entityName} dp WHERE dp.device.id = ?1")
    List<DeDupePolicy> findAllByDeviceId(Long deviceId);
}
