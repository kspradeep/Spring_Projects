package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.GridMatrix;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.Set;

public interface GridMatrixRepository extends CrudRepository<GridMatrix, Long> {

    @Query(value = "SELECT m from #{#entityName} m WHERE m.gridPolicySetId = ?1")
    Set<GridMatrix> findByPolicySetId(Long policySetId);

    @Query(value = "SELECT m.id from grid_matrix m JOIN matrix_destination_device_mapping d WHERE m.id = d.matrix_id AND m.grid_policy_set_id = ?1 AND m.source_device_id = ?2 AND d.destination_device_id in ?3", nativeQuery = true)
    Set<BigInteger> findByPolicySetIdAndSourceAndDestination(Long policySetId, Long sourceIdId, Set<Long> destinationIds);

    @Query(value = "SELECT m from #{#entityName} m JOIN m.gridTopologyPaths d WHERE d.id = ?1")
    GridMatrix findByTopologyPathId(Long topologyPathId);
}