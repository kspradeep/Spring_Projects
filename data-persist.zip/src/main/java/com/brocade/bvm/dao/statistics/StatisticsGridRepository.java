package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.dao.*;
import com.brocade.bvm.dao.grid.GridPolicySetRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.cache.GridCache;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Event;
import com.brocade.bvm.model.db.Port;
import com.brocade.bvm.model.db.admin.ApplicationConfig;
import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import com.brocade.bvm.model.db.statistics.AllPoliciesAndHitCount;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@Repository
@Slf4j
public class StatisticsGridRepository {

  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private FeatureConstantsRepository featureConstantsRepository;
  @Inject GridPolicySetRepository gridPolicySetRepository;
  @Inject private GridCache gridCache;
  @Inject private EventRepository eventRepository;
  @Inject private ConfigRepository configRepository;
  @Inject private PortRepository portRepository;
  @Inject private GridRepository gridRepository;
  @Inject private DeviceRepository deviceRepository;

  private Map<Long, Integer> portOverThreshold = new HashMap<>();

  @Async
  public CompletableFuture<List<String>> findTopFiveGrids() {
    List<String> grids = new ArrayList<>();
    gridCache
        .getTopFiveGrids()
        .forEach(gridUtilization -> grids.add(gridUtilization.getDeviceGrid().getName()));
    return CompletableFuture.completedFuture(grids);
  }

  @Async
  public CompletableFuture<List<String>> findBottomFiveGrids() {
    List<String> grids = new ArrayList<>();
    gridCache
        .getBottomFiveGrids()
        .forEach(gridUtilization -> grids.add(gridUtilization.getDeviceGrid().getName()));
    return CompletableFuture.completedFuture(grids);
  }

  private long findBandwidthCountById(Long portId) {
    Long count = 0L;
    try {
      count =
          jdbcTemplate.queryForObject(
              "select i.in_band_width packets from bvm.interface_statistics i where i.port_id=? ORDER BY i.last_updated_time DESC limit 1",
              new Object[] {portId},
              Long.class);
      if (count == null) {
        count = 0L;
      }
    } catch (EmptyResultDataAccessException e) {
    }
    return count;
  }

  public int getPortOverThresholdCount(Long deviceGridId) {
    return this.portOverThreshold.get(deviceGridId);
  }

  // Call this method after setPacketDifferenceInPort is done execution
  public void calculatePortsOverthreshold(DeviceGrid deviceGrid) {
    AtomicInteger counter = new AtomicInteger();
    ApplicationConstant constant =
        featureConstantsRepository.findByName(
            ApplicationConstant.THRESHOLD.UTILIZATION_THRESHOLD.getConstant());
    double threshold = 100.00;
    if (constant != null) {
      threshold = Double.parseDouble(constant.getValue());
    }
    List<Long> ports = new ArrayList<>();
    deviceGrid
        .getSourceNodes()
        .forEach(
            gridCluster -> {
              Long deviceId = getDeviceId(gridCluster.getId());
              if (deviceId != null) {
                ports.addAll(getALLTapPortsByDeviceId(deviceId));
              }
            });

    if (ports.size() > 0) {
      final double thres = threshold;
      ports
          .forEach(
              portId -> {
                Port port = portRepository.findOne(portId);
                if (port != null) {
                  Long packets = findBandwidthCountById(port.getId());
                  double limit = 0l;
                  if (port.getMaxSpeed() != null) {
                    long bitConstant = 1000000l;
                    if (port.getMaxSpeed() != null) {
                      limit = (port.getMaxSpeed() * bitConstant * thres) / 100;
                    }
                  }
                  String deviceName = "Device";
                  if (findDeviceByPortId(port.getId()).isPresent()) {
                    Device device = findDeviceByPortId(port.getId()).get();
                    deviceName = device.getName();
                  }
                  if (packets != null && packets > 0) {
                    if (packets > limit) {
                      String overthreshold = calculatePercentage(packets, limit);
                      Long maxSpeed = port.getMaxSpeed()*1000000;
                      if (packets > maxSpeed) {
                        fireEvent(
                            deviceGrid.getId(),
                            "Port "
                                + port.getName()
                                + " of grid "
                                + deviceGrid.getName()
                                + " of device "
                                + deviceName
                                + " sending more packets than port max speed. Max speed is ["
                                + port.getMaxSpeed()*1000*1000
                                + "] bits and packet count is ["
                                + packets
                                + "] bits",
                            port.getId(),
                            deviceGrid.getName());
                      } else {
                        fireEvent(
                            deviceGrid.getId(),
                            "Port "
                                + port.getName()
                                + " of grid "
                                + deviceGrid.getName()
                                + " of device "
                                + deviceName
                                + " exceeded the threshold by ["
                                + overthreshold
                                + "]%",
                            port.getId(),
                            deviceGrid.getName());
                      }

                      counter.getAndIncrement();
                    }
                  }
                }
              });
    }
    this.portOverThreshold.clear();
    this.portOverThreshold.put(deviceGrid.getId(), counter.intValue());
  }

  private String calculatePercentage(long packets, double limit) {
    double diff = ((packets - limit));
    double diffpercentage = (diff / limit) * 100;
    if(diffpercentage > 100.00) {
      diffpercentage = 100.00;
    }
    DecimalFormat df = new DecimalFormat("#.##");
    df.setRoundingMode(RoundingMode.CEILING);
    return df.format(diffpercentage);
  }

  public void fireEvent(long deviceGridId, String result, Long portId, String gridName) {
    try {
      List<String> objects =
          jdbcTemplate.queryForList(
              "select parent_object_id from bvm.event be where be.parent_object_id = ?",
              new Object[] {portId},
              String.class);
      if (objects != null && objects.size() > 0) {
        jdbcTemplate.execute("delete from bvm.event where parent_object_id =" + portId + "");
      }
    } catch (DataAccessException e) {
      log.info("No threshold for port {}", portId);
    }

    Event event = new Event();
    jdbcTemplate.execute("delete from bvm.event where event.target_host=\'" + deviceGridId + "\'");
    event.setParentObjectId(portId);
    event.setType("THRESHOLD");
    event.setJobStatus("FAILED");
    event.setSeverity(Event.Severity.WARNING);
    event.setCreatedByUser(
        SecurityContextHolder.getContext().getAuthentication() != null
            ? SecurityContextHolder.getContext().getAuthentication().getName()
            : configRepository.findByKey(ApplicationConfig.Key.StablenetUsername).getValue());
    event.setCreatedTime(Instant.now());
    event.setTargetHost(gridName);
    event.setLastUpdatedTime(Instant.now());
    event.setResult(result);
    eventRepository.save(event);
  }

  public Long setPacketDifferenceInPort(DeviceGrid deviceGrid) {
    AtomicLong tapPackets = new AtomicLong(0L);
    AtomicLong toolPackets = new AtomicLong(0L);

    // port utilization calculation by line speed
    deviceGrid
        .getSourceNodes()
        .forEach(
            networkNode ->
                networkNode
                    .getClusterNodeInterfaces()
                    .forEach(
                        networkNodeInterface ->
                            networkNodeInterface
                                .getPorts()
                                .forEach(
                                    port -> {
                                      if (port != null) {
                                        long portId = port.getId();
                                        long previous = tapPackets.get();
                                        long currentCount = findBandwidthCountById(portId);
                                        long current = previous + currentCount;
                                        tapPackets.set(current);
                                      }
                                    })));
    deviceGrid
        .getDestinationNodes()
        .forEach(
            networkNode ->
                networkNode
                    .getClusterNodeInterfaces()
                    .forEach(
                        networkNodeInterface -> {
                          networkNodeInterface
                              .getPorts()
                              .forEach(
                                  port -> {
                                    if (port != null) {
                                      long portId = port.getId();
                                      long previous = toolPackets.get();
                                      long currentCount = findBandwidthCountById(portId);
                                      long current = previous + currentCount;
                                      toolPackets.set(current);
                                    }
                                  });
                        }));

    return Math.abs(tapPackets.get() - toolPackets.get());
  }

  public List<AllPoliciesAndHitCount> findAllPolicesAndHitCount(long gridId) {
    List<GridPolicySet> gridPolicySets = gridPolicySetRepository.findByGridId(gridId);
    List<AllPoliciesAndHitCount> allPoliciesAndHitCounts = new ArrayList<>();
    gridPolicySets.forEach(
        gridPolicySet -> {
          if (gridPolicySet.getWorkflowStatus().equals(WorkflowParticipant.WorkflowStatus.ACTIVE)) {
            Long gridSetId = gridPolicySet.getId();
            List<InnerPolicy> policies = getPolicies(gridSetId);
            if (policies != null) {
              policies.forEach(
                  policy -> {
                    AllPoliciesAndHitCount allPoliciesAndHitCount = new AllPoliciesAndHitCount();
                    allPoliciesAndHitCount.setHitCount(hitCounts(policy.getId()));
                    allPoliciesAndHitCount.setPolicyName(policy.getName());
                    allPoliciesAndHitCounts.add(allPoliciesAndHitCount);
                  });
            }
          }
        });
    return allPoliciesAndHitCounts;
  }

  private Long hitCounts(Long policyId) {
    try {
      Long count =
          jdbcTemplate.queryForObject(
              "select sum(ac.hit_count) as hit_count from bvm.acl ac where ac.acl_statistics_id IN (select aac.id from bvm.acl_statistics aac where aac.policy_id=?)",
              new Object[] {policyId},
              Long.class);
      if (StringUtils.isEmpty(count)) {
        return 0L;
      } else {
        return count;
      }
    } catch (EmptyResultDataAccessException e) {
      log.error("No policy count found {}", policyId);
      return 0L;
    }
  }

  private List<InnerPolicy> getPolicies(Long gridSetId) {
    return jdbcTemplate.query(
        "select p.id, mo.name from bvm.policy p, bvm.managed_object mo where p.grid_policy_set_id=? and p.id=mo.id",
        new Object[] {gridSetId},
        policyRowMapper);
  }

  private RowMapper<InnerPolicy> policyRowMapper =
      (ResultSet rs, int row) -> {
        InnerPolicy policy = new InnerPolicy();
        policy.setId(rs.getLong("id"));
        policy.setName(rs.getString("name"));
        return policy;
      };

  @Data
  class InnerPolicy {
    Long id;
    String name;
  }

  public List<Long> getALLTapPortsByDeviceId(Long id) {
    List<Long> ports = new ArrayList<>();
    Set<DeviceGrid> deviceGrids = Sets.newHashSet(gridRepository.findAll());
    deviceGrids.forEach(
        deviceGrid ->
            deviceGrid
                .getSourceNodes()
                .forEach(
                    networkNode -> {
                      Long deviceId = getDeviceId(networkNode.getId());
                      if (Objects.equals(deviceId, id)) {
                        networkNode
                            .getClusterNodeInterfaces()
                            .forEach(
                                clusterNodeInterface -> {
                                  List<Long> managedObjectIds =
                                      getManagedObjectId(clusterNodeInterface.getId());
                                  ports.addAll(managedObjectIds);
                                });
                      }
                    }));
    return ports;
  }

  private List<Long> getManagedObjectId(Long clusterNodeId) {
    return jdbcTemplate.query(
        "select cn.managed_object_id from bvm.cluster_node_port_mapping cn where cn.cluster_node_id=?",
        new Object[] {clusterNodeId},
        (ResultSet rs, int rowNum) -> rs.getLong("managed_object_id"));
  }

  private Long getDeviceId(Long id) {
    try {
      return jdbcTemplate.queryForObject(
          "select gc.device_id from bvm.grid_cluster gc where gc.id=?",
          new Object[] {id},
          Long.class);
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  private Optional<Device> findDeviceByPortId(Long portId) {
    if (StringUtils.isEmpty(portId)) {
      return Optional.empty();
    }
    Long deviceId =
        jdbcTemplate.queryForObject(
            "select m.device_id from bvm.port p, bvm.module m where p.module_id=m.id and p.id=?",
            new Object[] {portId},
            Long.class);
    if (deviceId != null) {
      return Optional.of(deviceRepository.findById(deviceId));
    } else {
      return Optional.empty();
    }
  }
}
