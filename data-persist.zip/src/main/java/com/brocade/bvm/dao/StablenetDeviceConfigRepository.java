package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.admin.ApplicationConstant;
import com.brocade.bvm.model.db.admin.StablenetDeviceConfig;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface StablenetDeviceConfigRepository extends CrudRepository<StablenetDeviceConfig, Long> {

    @Query(value = "Select o from #{#entityName} o where o.name = ?1")
    StablenetDeviceConfig findByName(String name);
}
