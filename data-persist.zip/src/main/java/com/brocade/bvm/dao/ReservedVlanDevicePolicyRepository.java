package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.ReservedVlanDevicePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ReservedVlanDevicePolicyRepository extends CrudRepository<ReservedVlanDevicePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    ReservedVlanDevicePolicy findOne(Long devicePolicyId);

    @Query(value = "Select po from #{#entityName} po where po.device.id = ?1")
    ReservedVlanDevicePolicy findByDeviceId(Long deviceId);

    @Query(value = "Select po from #{#entityName} po where po.device.id = ?1 and po.id <> ?2")
    ReservedVlanDevicePolicy findByDeviceIdAndNotInPolicy(Long deviceId, Long policyId);

    @Query(value = "SELECT flow_id FROM flow_vlan_mapping WHERE vlan_id =?1", nativeQuery = true)
    List<Long> findFlowIdsByVlanId(Integer vlanId);

    @Query(value = "SELECT fvm.vlan_id FROM flow_vlan_mapping fvm, flow f, policy p WHERE fvm.flow_id = f.id and f.policy_id = p.id and p.device_id = ?1 order by fvm.vlan_id", nativeQuery = true)
    List<String> findVlanIdsByDeviceId(Long deviceId);
}
