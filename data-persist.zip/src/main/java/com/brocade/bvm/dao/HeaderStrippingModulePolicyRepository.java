package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.HeaderStrippingModulePolicy;
import com.brocade.bvm.model.db.Port;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface HeaderStrippingModulePolicyRepository extends CrudRepository<HeaderStrippingModulePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    HeaderStrippingModulePolicy findOne(Long id);

    @Query(value = "Select po from #{#entityName} po JOIN po.stripHeaders shs where po.isPreserve = true and po.device.id = ?1 and shs IN('BR802','VNTAG','ALL')")
    List<HeaderStrippingModulePolicy> findModulePoliciesByDeviceId(Long deviceId);

    @Query(value = "SELECT fvm.flow_id FROM flow_vlan_mapping fvm, flow f, policy p WHERE p.device_id = ?1 and p.id = f.policy_id and f.id = fvm.flow_id and fvm.vlan_id =?2", nativeQuery = true)
    List<Long> findFlowIdsByDeviceIdAndVlanId(Long deviceId, Integer vlanId);

    @Query(value = "Select po.intermediateVlan from #{#entityName} po JOIN po.modules mo where mo.device.id = ?1")
    List<Long> findVlanIdsByDeviceId(Long deviceId);

    @Query(value = "select hsmpo from #{#entityName} hsmpo JOIN hsmpo.modules mo where hsmpo.device.id = ?1 and mo.id in ?2 and hsmpo.isPreserve = ?3 and hsmpo.workflowStatus in ?4")
    List<HeaderStrippingModulePolicy> findHeaderStrippingModulePolicyByDeviceIdAndModuleIds(Long deviceId, List<Long> moduleIds, boolean isPreserve, List<WorkflowParticipant.WorkflowStatus> workflowStatuses);

    @Query(value = "select hsmpo from #{#entityName} hsmpo JOIN hsmpo.modules mo where hsmpo.device.id = ?1 and mo.id in ?2 and hsmpo.isPreserve <> ?3 and hsmpo.workflowStatus in ?4")
    List<HeaderStrippingModulePolicy> findHeaderStrippingModulePolicyByDeviceIdAndModuleIdsAndOppositePreserve(Long deviceId, List<Long> moduleIds, boolean isPreserve, List<WorkflowParticipant.WorkflowStatus> workflowStatuses);

    @Query(value = "select hsmpo from #{#entityName} hsmpo JOIN hsmpo.ports po where hsmpo.device.id = ?1 and po.id in ?2 and hsmpo.isPreserve = ?3 and hsmpo.workflowStatus in ?4")
    List<HeaderStrippingModulePolicy> findHeaderStrippingModulePolicyByDeviceIdAndPortIds(Long deviceId, List<Long> portIds, boolean isPreserve, List<WorkflowParticipant.WorkflowStatus> workflowStatuses);

    @Query(value = "select hsmpo.id from #{#entityName} hsmpo JOIN hsmpo.ports po JOIN hsmpo.stripHeaders shs where hsmpo.device.id = ?1 and po.id in ?2 and hsmpo.workflowStatus in ?3 and shs in ?4")
    List<Long> findModulePolicyByPortIdsAndVNTAGAndBR(Long deviceId, List<Long> portIds, List<WorkflowParticipant.WorkflowStatus> workflowStatuses, List<HeaderStrippingModulePolicy.Headers> headers);

    @Query(value = "Select po.id from #{#entityName} p JOIN p.ports po where p.device.isDeleted = 0 and po.type = ?1")
    List<Long> findPortIdsByPortType(Port.Type type);
}
