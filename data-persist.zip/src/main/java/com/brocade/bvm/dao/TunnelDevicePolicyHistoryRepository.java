package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Policy;
import com.brocade.bvm.model.db.history.TunnelDevicePolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface TunnelDevicePolicyHistoryRepository extends CrudRepository<TunnelDevicePolicyHistory, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    TunnelDevicePolicyHistory findOne(Long devicePolicyId);

    @Query(value = "Select td from #{#entityName} td where td.parentId= ?1 AND td.workflowStatus = ?2 Order by td.revisionTime DESC")
    List<TunnelDevicePolicyHistory> findByIdAndWorkflowStatus(Long devicePolicyId, WorkflowParticipant.WorkflowStatus status);
}
