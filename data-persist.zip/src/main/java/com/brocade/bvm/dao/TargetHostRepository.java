package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.TargetHost;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.Instant;
import java.util.List;

/**
 * Created by nthatiko on 9/27/2016.
 */
public interface TargetHostRepository extends CrudRepository<TargetHost, Long> {

    @Query(value = "Select d from #{#entityName} d where d.id = ?1")
    TargetHost findOne(Long id);

    TargetHost findById(Long id);

    @Query("SELECT MAX(d.lastUpdatedTime) FROM #{#entityName} d")
    Instant getLastUpdatedTime();

    @Query(value = "SELECT d FROM #{#entityName} d JOIN d.modules m WHERE m.id = ?1")
    TargetHost findByModuleId(Long moduleId);
}
