package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.DeviceDiscoveryJob;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface DeviceDiscoveryJobRepository extends CrudRepository<DeviceDiscoveryJob, Long> {

    List<DeviceDiscoveryJob> findByIpAddress(String ipAddress);

    DeviceDiscoveryJob findByObjId(String objId);

    @Query(value = "select d from #{#entityName} d where d.id IN ?1")
    List<DeviceDiscoveryJob> findByInIds(List<Long> ids);

    @Query(value = "select d from #{#entityName} d where d.ipAddress IN ?1")
    List<DeviceDiscoveryJob> findByInIpAddress(Set<String> ips);

}
