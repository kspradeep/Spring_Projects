package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Port;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface PortRepository extends CrudRepository<Port, Long> {

    @Query(value = "Select po.name from #{#entityName} po where po.id = ?1")
    String findNameById(Long id);

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    Port findOne(Long id);

    @Query("SELECT id FROM port WHERE module.device.id = ?1 AND stablenet_index IN ?2")
    List<Long> findIdsByDeviceIdAndPortIndex(Long deviceId, List<Long> portIndex);

    @Query("SELECT id, stablenetIndex FROM port WHERE module.device.id = ?1 AND stablenetIndex IN ?2")
    List<Object[]> findByDeviceIdAndPortIndex(Long deviceId, List<Long> portIndex);

    @Query("SELECT port.id FROM #{#entityName} port WHERE port.id IN ?1 AND port.workflowStatus IN ?2 ")
    List<Long> findAllPortAndInWorkflowStatus(Set<Long> ingressPorts, List<WorkflowParticipant.WorkflowStatus> statuses);

    @Query("SELECT p FROM port p WHERE p.name like %?1% AND p.module.device.id = ?2")
    List<Port> getPortsByNameAndDeviceId(String portName, Long deviceId);

    @EntityGraph(attributePaths = "module.device")
    @Query("SELECT p FROM port p WHERE p.module.device.id = ?2 AND p.name like %?1")
    Port findPortByNameAndDeviceId(String portName, Long deviceId);

    @Query("SELECT p FROM port p WHERE p.type is NOT NULL and p.module.device.id = ?1")
    List<Port> findPortsByTypeNotNullAndDeviceId(Long deviceId);

    @Query("SELECT count(*) from port p WHERE p.type=?1")
    Long findPortsByTypeAndGroupByType(Port.Type type);

    @Query("SELECT p FROM port p WHERE p.module.device.id = ?1")
    List<Port> findPortsByDeviceId(Long deviceId);

    @Query(value = "Select po.lineSpeed from #{#entityName} po where po.id = ?1")
    Long findLineSpeedById(Long id);

    @Query(value = "Select p from port p where p.module.device.type=?1 and p.type=?2 and p.module.device.isDeleted=0 and p.module.device.isReconciled=1 and p.module.device.isProfileConfigured=1")
    List<Port> findPortByDeviceTypeAndPortTypeAndNotDeleted(Device.Type type, Port.Type portType);

    @Query(value = "Select po.name from #{#entityName} po where po.id in ?1")
    List<String> findNamesByIds(List<Long> ids);

    @Query(value = "Select p from port p where p.module.device.id=?1 and p.type IN ?2")
    List<Port> findPortByDeviceIdAndPortTypes(Long deviceId, List<Port.Type> portTypes);
}
