package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.DedupePolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DedupePolicyHistoryRepository extends CrudRepository<DedupePolicyHistory, Long> {
    @Query(value = "Select history from #{#entityName} history where history.parentId= ?1 AND history.workflowStatus in ?2 order by history.revisionTime DESC")
    List<DedupePolicyHistory> findByIdAndWorkflowStatus(Long sdDedupePolicyId, List<WorkflowParticipant.WorkflowStatus> status);
}
