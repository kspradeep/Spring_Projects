package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.PolicySetInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

@Repository
public class GridPolicyRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<PolicySetInterface> getPolicyTapInterfaces(Set<Long> clusterNodeIds) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("ids", clusterNodeIds);
        List<PolicySetInterface> policySetInterfaces = namedParameterJdbcTemplate.query("SELECT c.cluster_node_id, g.grid_policyset_id FROM grid_policy_cluster_node_mapping_ingress c " +
                "JOIN grid_policy g WHERE c.policy_id = g.id AND c.cluster_node_id IN (:ids)", parameters, policySetInterfaceRowMapper);
        return policySetInterfaces;
    }

    public List<PolicySetInterface> getPolicyToolInterfaces(Set<Long> clusterNodeIds) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("ids", clusterNodeIds);
        List<PolicySetInterface> policySetInterfaces = namedParameterJdbcTemplate.query("SELECT c.cluster_node_id, g.grid_policyset_id FROM grid_policy_cluster_node_mapping_egress c " +
                "JOIN grid_policy g WHERE c.policy_id = g.id AND c.cluster_node_id IN (:ids)", parameters, policySetInterfaceRowMapper);
        return policySetInterfaces;
    }

    private RowMapper<PolicySetInterface> policySetInterfaceRowMapper = (ResultSet rs, int rowNum) -> {
        PolicySetInterface policySetInterface = new PolicySetInterface();
        policySetInterface.setPolicySetId(rs.getLong("grid_policyset_id"));
        policySetInterface.setClusterNodeId(rs.getLong("cluster_node_id"));
        return policySetInterface;
    };
}
