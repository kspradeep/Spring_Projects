package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.DevicePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Set;

public interface DevicePolicyRepository extends CrudRepository<DevicePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    DevicePolicy findOne(Long id);

    @Query(value = "SELECT dp FROM #{#entityName} dp WHERE dp.device.id= ?1")
    Set<DevicePolicy> findByDeviceId(Long deviceId);

    @Query(value = "SELECT dp FROM #{#entityName} dp WHERE dp.objectType = ?1")
    Set<DevicePolicy> findByType(String type);
}
