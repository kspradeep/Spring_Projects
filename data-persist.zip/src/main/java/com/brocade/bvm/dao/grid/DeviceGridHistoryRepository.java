package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.DeviceGridHistory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DeviceGridHistoryRepository extends CrudRepository<DeviceGridHistory, Long> {

    List<DeviceGridHistory> findTop5ByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(Long gridId, List<WorkflowParticipant.WorkflowStatus> statuses);
}
