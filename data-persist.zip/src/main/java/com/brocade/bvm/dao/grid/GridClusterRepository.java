package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.GridCluster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

public interface GridClusterRepository extends CrudRepository<GridCluster, Long> {

    @Query(value = "SELECT c.id as cluster_id, c.grid_source_id, c.grid_destination_id from grid_cluster c WHERE c.device_id = ?1", nativeQuery = true)
    List<Object[]> findAllByDeviceId(Long deviceId);

    @Query(value = "SELECT c.id from grid_cluster c WHERE c.device_id = ?1 AND c.id <> ?2", nativeQuery = true)
    List<Object[]> findIdsByDeviceIdAndNotClusterId(Long deviceId, Long clusterId);

    @Query(value = "SELECT distinct c.id from grid_cluster c WHERE c.device_id = ?1", nativeQuery = true)
    List<BigInteger> findIdAllByDeviceId(Long deviceId);

    @Query(value = "Select p.cluster_node_id from cluster_node_port_mapping p where p.managed_object_id in ?1", nativeQuery = true)
    Set<Long> findInterfaceByManagedObjectId(List<Long> managedObjectIds);

    @Query(value = "SELECT c from #{#entityName} c WHERE c.device.id = ?1")
    List<GridCluster> findByDeviceId(Long deviceId);
}
