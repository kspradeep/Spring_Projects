package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.statistics.DeviceSnapshot;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.List;

@Repository
@Slf4j
public class DeviceCustomRepository {

    @Inject
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<DeviceSnapshot> findDeviceInfo(List<Long> deviceIds, List<String> types) {
        if (deviceIds != null && !deviceIds.isEmpty() && types != null && !types.isEmpty()) {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue("ids", deviceIds);
            parameters.addValue("types", types);

            List<DeviceSnapshot> devices =
                    namedParameterJdbcTemplate.query(
                            "select d.id, d.os, d.type, d.is_profile_configured, t.name, t.ip_address from device d, target_host t where d.id = t.id and d.is_deleted = 0 and d.is_reconciled = 1 and d.id in (:ids) and d.type in (:types)",
                            parameters,
                            deviceInfoRowMapper);
            return devices;
        }
        return Lists.newArrayList();
    }

    private RowMapper<DeviceSnapshot> deviceInfoRowMapper =
            (ResultSet rs, int rowNum) -> {
                DeviceSnapshot deviceSnapshot = new DeviceSnapshot();
                deviceSnapshot.setId(rs.getLong("id"));
                deviceSnapshot.setName(rs.getString("name"));
                deviceSnapshot.setOs(rs.getString("os"));
                deviceSnapshot.setType(rs.getString("type"));
                deviceSnapshot.setProfileConfigured(rs.getBoolean("is_profile_configured"));
                deviceSnapshot.setIpAddress(rs.getString("ip_address"));
                return deviceSnapshot;
            };
}
