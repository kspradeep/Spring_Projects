package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant.WorkflowStatus;
import com.brocade.bvm.model.db.Flow;
import com.brocade.bvm.model.db.ManagedObject;
import com.brocade.bvm.model.db.Policy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;


public interface PolicyRepository extends CrudRepository<Policy, Long> {

    @Transactional
    long deleteById(Long Id);

    @Query(value = "Select p.name from #{#entityName} p where p.id = ?1")
    String findNameById(Long id);

    @Query(value = "Select e from #{#entityName} e where e.id = ?1")
    Policy findOne(Long policyId);

    @Query(value = "Select po from #{#entityName} po where po.device.id = ?1 and po.createdFromSd = ?2")
    List<Policy> findByDeviceIdAndCreatedFromSd(Long deviceId, boolean createdFromSd);

    @Query(value = "Select po from #{#entityName} po where po.device.id = ?1")
    List<Policy> findByDeviceId(Long deviceId);

    @Query(value = "Select po from #{#entityName} po where po.device.id = ?1 and po.id <> ?2")
    List<Policy> findByDeviceIdAndNotInpolicyId(Long deviceId, Long policyId);

    @Query(value = "SELECT flow_id FROM flow_port_mapping_ingress WHERE managed_object_id IN ?1", nativeQuery = true)
    List<Long> findFlowIdsByIngressPortOrPortGroupIds(List<Long> portIds);

    @Query(value = "SELECT flow_id FROM flow_port_mapping_egress WHERE managed_object_id IN ?1", nativeQuery = true)
    List<Long> findFlowIdsByEgressPortOrPortGroupIds(List<Long> portIds);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2")
    List<Policy> findByNameAndDevice(String name, Long deviceId);

    @Query(value = "SELECT distinct(po.device.name) from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2")
    String findDeviceNamesByNameAndDeviceId(String name, Long deviceId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.device.id = ?2 AND po.id <> ?3")
    List<Policy> findByNameAndDeviceForUpdate(String name, Long deviceId, Long policyId);

    @Query(value = "SELECT po.id from #{#entityName} po JOIN po.flows fl JOIN fl.ingressPortsAndPortGroups pt WHERE po.device.id = ?1 AND po.workflowStatus IN ('SUBMITTED') AND pt.id IN (?2)")
    List<Long> getCountOfPolicyGettingDeletedByIngressPorts(Long id, Set<Long> ingressId);

    @Query(value = "SELECT po FROM #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2 AND ?3 NOT MEMBER OF po.flows")
    List<Policy> findByDeviceIdAndStatusInAndFlowIdNot(Long id, List<WorkflowStatus> statuses, Flow flow);

    @Query(value = "SELECT po FROM #{#entityName} po JOIN po.flows fl JOIN fl.ingressPortsAndPortGroups pt WHERE po.device.id = ?1 AND po.workflowStatus IN ('ACTIVE','DRAFT') AND pt.id IN (?2)")
    List<Policy> findByDeviceIdAndIngressPorts(Long id, Set<Long> ingressPorts);

    @Query(value = "SELECT po.id from #{#entityName} po JOIN po.gtpProfile gtp WHERE po.device.id = ?1 AND gtp.id = ?2")
    List<Long> findByDeviceIdAndGTPProfile(Long deviceId, Long gtpProfileId);

    @Query(value = "SELECT flow_id FROM flow_tunnel_mapping WHERE tunnel_id =?1", nativeQuery = true)
    List<Long> findFlowIdsByTunnelId(Long tunnelId);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ('DRAFT') AND po.id <> ?2")
    List<Long> findDraftPoliciesByDeviceId(Long deviceId, Long policyId);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.device.id = ?1 AND po.preserveHeader = ?2")
    List<Long> findPoliciesByDeviceIdAndPreserveHeader(Long deviceId, boolean preserveHeader);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.device.id = ?1 AND po.preserveHeader = ?2 AND po.workflowStatus IN ('ACTIVE') AND po.id <> ?3")
    List<Long> findPoliciesByDeviceIdAndPreserveHeaderAndNotInCurrentPolicy(Long deviceId, boolean preserveHeader, Long policyId);

    @Query(value = "SELECT pt from #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE po.device.id = ?1 AND po.workflowStatus IN ('ACTIVE') AND po.preserveHeader = 1")
    List<ManagedObject> getAllEgressPortsAndPortGroupsByDeviceId(Long deviceId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ('ACTIVE') AND po.id <> ?2")
    List<Policy> findAllActivePoliciesByDeviceIdNotCurrentPolicy(Long deviceId, Long policyId);

    @Query(value = "SELECT po FROM #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE pt.id = ?1 and po.id <> ?2")
    List<Policy> findPoliciesByEgressPortGroupIdAndNotInCurrentPolicy(Long portGroupId, Long policyId);

    @Query(value = "SELECT po.id FROM #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE po.isTimestamp=true AND pt.id IN (?1)")
    List<Long> findByTimestampEgressPorts(List<Long> ingressPorts);

    @Query(value = "Select po.id from #{#entityName} po where po.device.id = ?1 and po.createdFromSd = ?2")
    List<Long> findIdsByDeviceIdAndCreatedFromSd(Long deviceId, boolean createdFromSd);

    // To query the Policy which are committed with the given Flex Match Profile Id and device id
    @Query(value = "SELECT po from #{#entityName} po JOIN po.flexMatchProfiles fmp WHERE fmp.id IN (?1) AND po.device.id = ?2 AND po.workflowStatus IN ?3")
    List<Policy> findByFMProfileIdAndStatusInAndDevice(Long flexMatchProfileId, Long deviceId, List<WorkflowStatus> statuses);

    @Query(value = "SELECT po from #{#entityName} po JOIN po.flexMatchProfiles fmp WHERE fmp.id IN (?1) AND po.device.id = ?2")
    List<Policy> findByFMProfileIdInAndDevice(Long flexMatchProfileId, Long deviceId);

    // To query the Policy which are committed with the given Flex Match Profile Id
    @Query(value = "SELECT po.id from #{#entityName} po JOIN po.flexMatchProfiles fmp WHERE fmp.id IN (?1)")
    List<Long> findIdsByFlexMatchProfileId(Long flexMatchProfileId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 AND po.id <> ?2")
    List<Policy> findAllPoliciesByDeviceIdNotCurrentPolicy(Long deviceId, Long policyId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1")
    List<Policy> findAllPoliciesByDeviceId(Long deviceId);

    @Query(value = "SELECT po.id from #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE po.device.id = ?1 AND pt.id=?2")
    List<Long> findFlowIdsByDeviceIdAndIngressId(Long deviceId, Long portId);

    @Query(value = "SELECT po.id from #{#entityName} po JOIN po.flows fl JOIN fl.ingressPortsAndPortGroups pt WHERE po.device.id = ?1 AND pt.id=?2")
    List<Long> findFlowIdsByDeviceIdAndEgressId(Long deviceId, Long portId);

    @Query(value = "SELECT po.workflowStatus from #{#entityName} po WHERE po.id = ?1")
    WorkflowStatus findWorkFlowStatusByPolicyId(Long policyId);

    @Query(value = "SELECT po from #{#entityName} po where po.workflowStatus IN ('ACTIVE')")
    List<Policy> findAllActive();

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 and po.workflowStatus IN ('ACTIVE')")
    List<Policy> findActivePoliciesByDeviceId(Long deviceId);

    @Query(value = "SELECT distinct(po.id) from #{#entityName} po where po.device.id = ?1 and po.workflowStatus IN ('DRAFT')")
    Set<Long> findAllDraftByDeviceId(Long deviceId);

    @Query(value = "SELECT pt.id from #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE po.device.id = ?1 AND pt.id IN ?2")
    List<Long> findPortIdsByEgressPortIds(Long deviceId, List<Long> portIds);

    @Query(value = "SELECT po FROM #{#entityName} po JOIN po.flows fl JOIN fl.egressPortsAndPortGroups pt WHERE pt.id = ?1")
    Set<Policy> findPoliciesByEgressPortGroupId(Long portGroupId);

    @Query(value = "SELECT po FROM #{#entityName} po JOIN po.flows fl JOIN fl.ingressPortsAndPortGroups pt WHERE pt.id = ?1")
    Set<Policy> findPoliciesByIngressPortGroupId(Long portGroupId);

}
