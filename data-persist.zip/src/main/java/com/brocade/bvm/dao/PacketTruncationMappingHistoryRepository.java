package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.PacketTruncationMappingHistory;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketTruncationMappingHistoryRepository extends CrudRepository<PacketTruncationMappingHistory, Long> {

    List<PacketTruncationMappingHistory> findByParentIdAndWorkflowStatusInOrderByRevisionTimeDesc(Long id, List<WorkflowParticipant.WorkflowStatus> statuses);

}
