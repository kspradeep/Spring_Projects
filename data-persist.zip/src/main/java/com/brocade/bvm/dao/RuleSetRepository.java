package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.RuleSet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface RuleSetRepository extends CrudRepository<RuleSet, Long> {

    @Query(value = "Select ru from #{#entityName} ru where ru.id = ?1")
    RuleSet findOne(Long id);

    @Query(value = "SELECT rs FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.flow.policy.device.id = ?2")
    Set<RuleSet> findByNameAndDeviceId(List<String> names, Long deviceId);

    @Query(value = "SELECT rs FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.flow.policy.device.id = ?2 and rs.flow.policy.id <> ?3")
    Set<RuleSet> findByNameAndDeviceIdAndNotPolicyId(List<String> names, Long deviceId, Long policyId);

    @Query(value = "SELECT rs.id, rs.name, rs.flow.policy.id FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.flow.policy.device.id = ?2 and rs.flow.policy.id <> ?3")
    List<Object[]> findIdAndNameAndPolicyIdByNameAndDeviceIdAndNotPolicyId(List<String> names, Long deviceId, Long policyId);

    @Query(value = "Select ru.id from #{#entityName} ru where ru.name = ?1 and ru.id <> ?2 and ru.flow.policy.device.id= ?3 and ru.flow.policy.id <> ?4")
    List<Long> findIdsByNameAndDeviceIdAndNotInPolicyId(String name, Long id, Long deviceId, Long policyId);

    @Query(value = "Select ru from #{#entityName} ru where ru.name = ?1 and ru.flow.policy.device.id= ?2 and ru.flow.policy.id <> ?3 and ru.flow.policy.workflowStatus IN ?4")
    List<RuleSet> findByNameAndDeviceIdAndNotInPolicyId(String name, Long deviceId, Long policyId, List<WorkflowParticipant.WorkflowStatus> workflowStatuses);

    @Query(value = "Select rs.flow.policy.id from #{#entityName} rs where rs.id = ?1")
    Long findPolicyIdById(Long id);

    @Query(value = "Select rs from #{#entityName} rs where rs.flow.policy.device.id = ?1 and rs.flow.policy.workflowStatus IN ?2 and rs.flow.policy.createdFromSd=0 group by rs.name, rs.isInactive")
    Set<RuleSet> findByDeviceIdAndPolicyNotCreatedBySD(Long deviceId, List<WorkflowParticipant.WorkflowStatus> workflowStatuses);

    @Query(value = "Select rs from #{#entityName} rs where rs.name = ?1 and rs.flow.policy.device.id = ?2 and rs.flow.policy.workflowStatus IN ('ERROR') and rs.isInactive = ?3 and rs.flow.policy.createdFromSd=0 group by rs.name")
    Set<RuleSet> findByNameAndDeviceIdAndNonActiveAndNotCreatedBySD(String name, Long deviceId, boolean rulesetIsInActive);

    @Query(value = "SELECT rs.name FROM #{#entityName} rs WHERE rs.name IN ?1 and rs.flow.policy.device.id = ?2")
    List<String> findNameByNameAndDeviceId(List<String> names, Long deviceId);

    @Query(value = "SELECT rs.name FROM #{#entityName} rs WHERE rs.flow.policy.device.id = ?1 and rs.flow.policy.workflowStatus IN ('ERROR') ")
    Set<String> findNamesByDeviceIdAndInErrorState(Long deviceId);

    @Query(value = "SELECT rs.flow.policy.id FROM #{#entityName} rs WHERE rs.id IN ?1 and rs.flow.policy.workflowStatus IN ?2")
    List<Long> findPolicyByRuleSetIdAndWorkFlowStatus(List<Long> ids, List<WorkflowParticipant.WorkflowStatus> policyWorkflowStatus);

    @Query(value = "SELECT rs FROM #{#entityName} rs WHERE rs.name = ?1 and rs.flow.policy.id = ?2 and rs.id <>?3")
    Set<RuleSet> findByNameAndPolicyIdAndNotInRulesetId(String name, Long policyId, Long rulesetId);

}
