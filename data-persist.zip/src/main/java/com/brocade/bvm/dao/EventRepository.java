package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.Event;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Set;

public interface EventRepository extends CrudRepository<Event, Long> {

    @Query(value = "Select e from #{#entityName} e where e.id = ?1")
    Event findOne(Long id);

    // Entity Graph helps in explicitly loading of the properties of a JPA entity which are marked as lazy.
    // By Defining the path, hibernate will understand the relation and load the entity. We can define multiple paths.
    @EntityGraph(attributePaths = "job.targetHost")
    List<Event> findByStatusIn(List<Event.Status> statuses);

    List<Event> findByStatusInAndType(List<Event.Status> statuses, String type);

    @EntityGraph(attributePaths = {"job.targetHost"})
    List<Event> findTop500ByStatusInOrderByLastUpdatedTimeDesc(List<Event.Status> statuses);

    @Query(value = "SELECT e FROM #{#entityName} e JOIN e.job j WHERE j.targetHost.id = ?1 AND e.status IN ?2")
    List<Event> findByTargetHostIdAndStatusIn(Long targetHosId, Set<Event.Status> status);

    @Query(value = "SELECT e FROM #{#entityName} e JOIN e.job j WHERE j.targetHost.id = ?1")
    List<Event> findByTargetHostId(Long targetHosId);

    @Query(value = "SELECT e FROM #{#entityName} e JOIN e.job j WHERE j.id IN ?1")
    List<Event> findByJobId(List<Long> jobIds);

    @Query(value = "select concat (id,':',name) from managed_object where id IN ?1", nativeQuery = true)
    List<String> findManagedObjectNames(List<Long> ids);

    @Query(value = "select e.result from event e where e.parent_object_id =?1 order by e.last_updated_time desc LIMIT 1", nativeQuery = true)
    String getEventByObjectId(Long objectId);

}
