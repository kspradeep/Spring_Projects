package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.db.grid.DestinationGroup;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.Set;

public interface DestinationGroupRepository extends CrudRepository<DestinationGroup, Long> {

    @Query(value = "Select d.id from destination_group d JOIN group_path_address_topology_mapping g WHERE d.id = g.destination_group_id AND g.grid_topology_path_id = ?1", nativeQuery = true)
    Set<BigInteger> findByGridTopologyPathId(Long topologyPathId);

    @Query(value = "Select d from #{#entityName} d where d.groupId = ?1")
    DestinationGroup findByGroupId(Integer groupId);

    @Query(value = "Select d.groupId from #{#entityName} d Order by d.groupId")
    Set<Integer> getAllGroupIds();
}
