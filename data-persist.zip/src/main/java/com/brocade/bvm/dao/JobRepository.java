package com.brocade.bvm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.brocade.bvm.model.db.Job;

public interface JobRepository extends CrudRepository<Job, Long> {

    @EntityGraph(attributePaths = "targetHost")
    @Query(value = "Select jo from #{#entityName} jo where jo.id = ?1")
    Job findOne(Long id);

    int countByTargetHostId(Long targetHostId);

    int countByTargetHostIdAndStatusIn(Long targetHostId, List<Job.Status> statuses);

    @Query(value = "select j.job_result, j.status from job j where j.id=(select jm.job_id from job_object_mapping jm where jm.impacted_object_id=?1 order by jm.job_id desc LIMIT 1) or j.parent_object_id =?1 order by j.last_updated_time desc LIMIT 1", nativeQuery = true)
    Object getJobStatusByObjectId(Long objectId);

    @Query("SELECT j.id FROM job j WHERE j.status IN ?1")
    List<Long> findByStatusIn(List<Job.Status> statuses);

    @Query(value = "SELECT count(j) from #{#entityName} j where j.parentObjectId IN ?1 AND j.type IN ?2")
    Long getAllJobsOnAPolicyAndInType(List<Long> parentObjectId, List<Job.Type> jobTypes);

    @Query("SELECT j.id FROM #{#entityName} j WHERE j.type IN ?1 AND j.status IN ?2")
    List<Long> findByTypeAndStatusIn(List<Job.Type> jobTypes, List<Job.Status> statuses);

    @Query("SELECT j.jobResult FROM #{#entityName} j WHERE j.id = ?1")
    String getJobResultByJobId(Long jobId);

    List<Job> findByParentObjectIdAndStatusIn(Long parentObjectId, List<Job.Status> statuses);

    Job findTop1ByParentObjectIdOrderByIdDesc(Long parentObjectId);
}
