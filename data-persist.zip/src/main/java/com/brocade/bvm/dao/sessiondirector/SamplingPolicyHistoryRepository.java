package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.SamplingPolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface SamplingPolicyHistoryRepository extends CrudRepository<SamplingPolicyHistory, Long> {
    @Query(value = "Select history from #{#entityName} history where history.parentId= ?1 AND history.workflowStatus in ?2 order by history.revisionTime DESC")
    List<SamplingPolicyHistory> findByIdAndWorkflowStatus(Long sdSamplingPolicyId, List<WorkflowParticipant.WorkflowStatus> status);
}
