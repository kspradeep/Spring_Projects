package com.brocade.bvm.dao.statistics.cache;

import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.grid.GridRepository;
import com.brocade.bvm.dao.statistics.StatisticsTreeSet;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.grid.DeviceGrid;
import com.brocade.bvm.model.db.statistics.GridUtilization;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Service
@Slf4j
@Getter
public class GridCache {
  private TreeSet<GridUtilization> topFiveGrids =
      new StatisticsTreeSet<>(
          Comparator.comparing(GridUtilization::getUtilization)
              .thenComparing(GridUtilization::hashCode));
  private TreeSet<GridUtilization> bottomFiveGrids =
      new StatisticsTreeSet<>(
          Comparator.comparing(GridUtilization::getUtilization)
              .thenComparing(GridUtilization::hashCode));

  @Inject TapPortCache tapPortCache;
  @Inject private GridRepository gridRepository;
  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private PortRepository portRepository;

  private void setBottomFiveGrids(Device device) {
    log.trace("Start: set bottom five grids for device {}", device.getName());
    try {
      Set<DeviceGrid> grids = Sets.newConcurrentHashSet(gridRepository.findAll());
      grids.stream()
          .forEach(
              deviceGrid -> {
                AtomicDouble allPortsCount = new AtomicDouble(0);
                deviceGrid.getSourceNodes().stream()
                    .forEach(
                        gridCluster -> {
                          Long deviceId = getDeviceId(gridCluster.getId());
                          if (deviceId != null) {
                            if (deviceId == device.getId()) {
                              List<Long> ports = tapPortCache.getALLTapPortsByDeviceId(deviceId);
                              if (ports.size() == 0) {
                                log.trace("No tap port available for device {}", deviceId);
                              } else {
                                ports.stream()
                                    .forEach(
                                        port -> {
                                          allPortsCount.getAndAdd(totalCountOfPort(port));
                                        });
                              }
                            }
                          }
                        });
                double utilization = allPortsCount.doubleValue();
                if (utilization > 0) {
                  GridUtilization gridUtilization = new GridUtilization();
                  gridUtilization.setId(deviceGrid.getId());
                  gridUtilization.setDeviceGrid(deviceGrid);
                  gridUtilization.setUtilization(utilization);
                  if (allPortsCount.longValue() <= 0) {
                    Iterator<GridUtilization> iterator = bottomFiveGrids.iterator();
                    while (iterator.hasNext()) {
                      if (iterator.next().getId() == deviceGrid.getId()) {
                        iterator.remove();
                        break;
                      }
                    }
                    bottomFiveGrids.remove(gridUtilization);
                  }
                  ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                  lock.writeLock().lock();

                  if (bottomFiveGrids.size() < 5) {
                    bottomFiveGrids.add(gridUtilization);
                  } else {
                    GridUtilization existingGrid = bottomFiveGrids.pollLast();
                    if (existingGrid.getUtilization() > gridUtilization.getUtilization()) {
                      bottomFiveGrids.add(gridUtilization);
                    } else {
                      bottomFiveGrids.add(existingGrid);
                    }
                  }

                  lock.writeLock().unlock();
                } else {
                  Iterator<GridUtilization> iterator = bottomFiveGrids.iterator();
                  while (iterator.hasNext()) {
                    if (iterator.next().getId() == deviceGrid.getId()) {
                      iterator.remove();
                    }
                  }
                }
              });
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    log.trace("End: set bottom five grids for device {}", device.getName());
  }

  @Async
  public void setTopFiveGrids(Device device) {
    log.trace("Start: set top five grids for device {}", device.getName());
    try {
      Set<DeviceGrid> grids = Sets.newConcurrentHashSet(gridRepository.findAll());

      if (StringUtils.isEmpty(grids)) {
        log.error("Device {} not added in any grid", device.getId());
      } else {
        grids.stream()
            .forEach(
                deviceGrid -> {
                  AtomicDouble allPortsCount = new AtomicDouble(0);
                  deviceGrid.getSourceNodes().stream()
                      .forEach(
                          gridCluster -> {
                            Long deviceId = getDeviceId(gridCluster.getId());
                            if (StringUtils.isEmpty(deviceId)) {
                              log.error(
                                  "Device id is empty for grid cluster {}", gridCluster.getId());
                            } else {
                              if (deviceId == device.getId()) {
                                List<Long> ports = tapPortCache.getALLTapPortsByDeviceId(deviceId);
                                if (ports.size() == 0) {
                                  log.trace("No tap port available for device {}", deviceId);
                                } else {
                                  ports.stream()
                                      .forEach(
                                          port -> {
                                            if (StringUtils.isEmpty(port)) {
                                              log.error("Port {} is not available", port);
                                            } else {
                                              allPortsCount.getAndAdd(totalCountOfPort(port));
                                            }
                                          });
                                }
                              }
                            }
                          });
                  double utilization = allPortsCount.doubleValue();
                  if (utilization > 0) {
                    GridUtilization gridUtilization = new GridUtilization();
                    gridUtilization.setId(deviceGrid.getId());
                    gridUtilization.setDeviceGrid(deviceGrid);
                    gridUtilization.setUtilization(utilization);
                    if (allPortsCount.doubleValue() <= 0) {
                      try {
                        if(topFiveGrids.isEmpty()) {
                          return;
                        }
                        topFiveGrids.removeIf(gridUtilization1 -> gridUtilization1.getId() == gridUtilization.getId());
                      } catch (Exception e) {
                      }
                    }
                    ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
                    lock.writeLock().lock();

                    if (topFiveGrids.size() < 5) {
                      topFiveGrids.add(gridUtilization);
                    } else {
                      GridUtilization existingGrid = topFiveGrids.pollFirst();
                      if (existingGrid.getUtilization() < gridUtilization.getUtilization()) {
                        topFiveGrids.add(gridUtilization);
                      } else {
                        topFiveGrids.add(existingGrid);
                      }
                    }

                    lock.writeLock().unlock();
                  } else {
                    Iterator<GridUtilization> iterator = topFiveGrids.iterator();
                    while (iterator.hasNext()) {
                      if (iterator.next().getId() == deviceGrid.getId()) {
                        iterator.remove();
                      }
                    }
                  }
                });
      }
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    //    if (this.topFiveGrids.size() >= 5) {
    //      this.setBottomFiveGrids(device);
    //    }
    log.trace("End: set top five grids for device {}", device.getName());
  }

  private Long getDeviceId(Long id) {
    try {
      return jdbcTemplate.queryForObject(
          "select gc.device_id from bvm.grid_cluster gc where gc.id=?",
          new Object[] {id},
          Long.class);
    } catch (EmptyResultDataAccessException e) {
      return null;
    }
  }

  private double totalCountOfPort(Long id) {
    try {
      return jdbcTemplate.queryForObject(
          "select (i.in_link_utilization) as total from bvm.interface_statistics i "
              + "where i.port_id=? order by i.last_updated_time desc limit 1",
          new Object[] {id},
          Double.class);
    } catch (EmptyResultDataAccessException e) {
      return 0L;
    }
  }
}
