package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.FirmwareJob;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface FirmwareJobRepository extends CrudRepository<FirmwareJob, Long> {

    @EntityGraph(attributePaths = "targetHost")
    @Query(value = "Select jo from #{#entityName} jo where jo.id = ?1")
    FirmwareJob findOne(Long id);

    int countByTargetHostIdAndStatusIn(Long targetHostId, List<FirmwareJob.Status> statuses);

    @Query("SELECT j.id FROM #{#entityName} j WHERE j.status IN ?1")
    List<Long> findByStatusIn(List<FirmwareJob.Status> statuses);

    @Query("SELECT jo FROM #{#entityName} jo WHERE jo.targetHost.id=?1 AND jo.parentObjectId=?2 Order by jo.lastUpdatedTime desc")
    List<FirmwareJob> findByTargetHostIdAndParentObjectId(Long targetHostId, Long parentObjectId);

    @Query(value = "select j.job_result from firmware_job j where j.parent_object_id =?1 order by j.last_updated_time desc LIMIT 1", nativeQuery = true)
    String getJobStatusByObjectId(Long objectId);
}
