package com.brocade.bvm.dao.grid;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.grid.GridPolicySet;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface GridPolicySetRepository extends CrudRepository<GridPolicySet, Long> {

    @Query(value = "Select po from #{#entityName} po where po.deviceGrid.id = ?1")
    List<GridPolicySet> findByGridId(Long gridId);

    @Query(value = "Select po.grid_id from grid_policy_set po where po.id = ?1", nativeQuery = true)
    Long findGridIdById(Long id);

    @Query(value = "Select po.id from #{#entityName} po where po.deviceGrid.id = ?1")
    List<Long> findIdsByGridId(Long gridId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.deviceGrid.id = ?2")
    List<GridPolicySet> findByNameAndDevice(String name, Long gridId);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.name = ?1 AND po.deviceGrid.id = ?2 AND po.id <> ?3")
    List<GridPolicySet> findByNameAndDeviceForUpdate(String name, Long gridId, Long policyId);

    @Query(value = "SELECT po.id from #{#entityName} po WHERE po.deviceGrid.id = ?1 AND po.workflowStatus IN ('DRAFT') AND po.id <> ?2")
    List<Long> findDraftPoliciesByDeviceId(Long gridId, Long policyId);

    @Query(value = "Select po.name from #{#entityName} po where po.deviceGrid.id = ?1 AND po.workflowStatus = ?2")
    List<String> findNameByGridIdAndWorkflowStatus(Long gridId, WorkflowParticipant.WorkflowStatus workflowStatus);

    @Query(value = "Select p.name from #{#entityName} p where p.id = ?1")
    String findNameById(Long id);
}
