package com.brocade.bvm.dao.statistics;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class StatisticsTreeSet<T> extends TreeSet<T> {

  public StatisticsTreeSet(Comparator<T> utilizationComparator) {
    super(utilizationComparator);
  }

  public boolean add(T e) {
    boolean existsElement = false;

    Iterator<T> it = iterator();
    while (it.hasNext() && !existsElement) {
      T nextElement = it.next();
      if (nextElement.equals(e)) {
        // Element found
        existsElement = true;
        Comparator<? super T> comparator = comparator();
        int compare = comparator.compare(nextElement, e);
        if (compare > 0) {
          it.remove();
          super.add(e);
          return true;
        }
      }
    }

    if (!existsElement) {
      return super.add(e);
    }

    // This is forcibly returned true
    return true;
  }
}
