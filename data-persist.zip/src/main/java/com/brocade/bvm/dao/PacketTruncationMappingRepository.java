package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketTruncationMapping;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketTruncationMappingRepository extends CrudRepository<PacketTruncationMapping, Long> {

    @Query(value = "select pm from #{#entityName} pm where pm.device.id = ?1 and pm.device.isDeleted = 0")
    List<PacketTruncationMapping> findByDeviceId(Long deviceId);

    @Query(value = "select pm from #{#entityName} pm where pm.packetTruncation.id = ?1 and pm.device.isDeleted = 0")
    List<PacketTruncationMapping> findByPacketTruncationId(Long truncationId);

    @Query(value = "select pm.port.id from #{#entityName} pm where pm.device.id = ?1 and pm.port.id in ?2 and pm.device.isDeleted = 0")
    List<Long> findPortsByDeviceIdAndPortIds(Long deviceId, List<Long> portIds);

    @Query(value = "select pm.portGroup.id from #{#entityName} pm where pm.device.id = ?1 and pm.portGroup.id in ?2 and pm.device.isDeleted = 0")
    List<Long> findPortGroupsByDeviceIdAndPortGroupIds(Long deviceId, List<Long> portGroupIds);

    @Query(value = "select pm from #{#entityName} pm where pm.device.id = ?1 and pm.port.id = ?2 or pm.portGroup.id= ?2 and pm.device.isDeleted = 0")
    PacketTruncationMapping findByDeviceIdAndInterface(Long deviceId, Long interfaceChannel);

    @Query(value = "select pm from #{#entityName} pm where pm.packetTruncation.name = ?1 and pm.device.id = ?2 and pm.device.isDeleted = 0")
    List<PacketTruncationMapping> findByProfileNameAndDeviceId(String name, Long deviceId);

    @Query(value = "select pm from #{#entityName} pm where pm.packetTruncation.name = ?1 and pm.device.id = ?2 and pm.device.isDeleted = 0")
    PacketTruncationMapping findByProfileNameAndDevice(String name, Long deviceId);

    @Query(value = "select pm.port.id, pm.packetTruncation.id from #{#entityName} pm where pm.device.isDeleted = 0 and pm.port.id <> NULL")
    List<Object[]> findPortIds();

    @Query(value = "select pm.portGroup.id, pm.packetTruncation.id from #{#entityName} pm where pm.device.isDeleted = 0 and pm.portGroup.id <> NULL")
    List<Object[]> findPortGroupIds();

    @Query(value = "select pm from #{#entityName} pm where  pm.port.id = ?1 and pm.device.id = ?2 and pm.device.isDeleted = 0")
    PacketTruncationMapping findByPortIdAndDeviceId(Long interfaceChannel, Long deviceId);

    @Query(value = "select pm from #{#entityName} pm where  pm.portGroup.id = ?1 and pm.device.id = ?2 and pm.device.isDeleted = 0")
    PacketTruncationMapping findByPortGroupIdAndDeviceId(Long portGroupId, Long deviceId);

    @Query(value = "select pm.port.name from #{#entityName} pm where pm.device.id = ?1 and pm.port.id in ?2 and pm.device.isDeleted = 0")
    List<String> findPortNamesByPortIdAndDeviceId(Long deviceId, List<Long> portIds);
}
