package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.EgressPortGroupHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EgressPortGroupHistoryRepository extends CrudRepository<EgressPortGroupHistory, Long> {

    @Query(value = "Select history from #{#entityName} history where history.parentId= ?1 AND history.workflowStatus in ?2 order by history.revisionTime DESC")
    List<EgressPortGroupHistory> findByIdAndWorkflowStatus(Long portId, List<WorkflowParticipant.WorkflowStatus> status);
}
