package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.sessiondirector.SdPortGroup;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EgressPortGroupRepository extends CrudRepository<SdPortGroup, Long> {
    @Query(value = "SELECT pg from #{#entityName} pg WHERE pg.device.id = ?1")
    List<SdPortGroup> findAllByDeviceId(Long deviceId);

    SdPortGroup findByIsDefaultTrueAndDeviceId(Long deviceId);

    SdPortGroup findById(Long portGroupId);

    SdPortGroup findByNameAndDevice(String name, Device device);

    @Query(value = "SELECT sd_egress_port_group_id FROM port_port_group WHERE sd_port_id IN ?1", nativeQuery = true)
    List<Long> findPortGroupIdsByPortIds(List<Long> portIds);

    @Query(value = "SELECT r.id from filter_policy f JOIN filter_rule r WHERE r.filter_policy_id=f.id and r.port_group_id IN ?1", nativeQuery = true)
    List<Long> findPortGroupUsedInFilter(List<Long> portGroupIds);

    @Query(value = "SELECT po from #{#entityName} po WHERE po.device.id = ?1 AND po.workflowStatus IN ?2")
    List<SdPortGroup> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> acceptableStatus);
}
