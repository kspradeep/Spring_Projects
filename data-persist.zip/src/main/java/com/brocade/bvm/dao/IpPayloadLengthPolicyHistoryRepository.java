package com.brocade.bvm.dao;


import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.IpPayloadLengthPolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IpPayloadLengthPolicyHistoryRepository extends CrudRepository<IpPayloadLengthPolicyHistory, Long> {
    IpPayloadLengthPolicyHistory findByParentId(Long modulePolicyId);

    @Query(value = "Select mp from #{#entityName} mp where mp.parentId= ?1 AND mp.workflowStatus = ?2 Order by mp.revisionTime DESC")
    List<IpPayloadLengthPolicyHistory> findByIdAndWorkflowStatus(Long modulePolicyId, WorkflowParticipant.WorkflowStatus status);
}
