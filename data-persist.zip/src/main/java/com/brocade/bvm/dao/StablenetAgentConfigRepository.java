package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.admin.StablenetAgentConfig;
import com.brocade.bvm.model.db.admin.StablenetDeviceConfig;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface StablenetAgentConfigRepository extends CrudRepository<StablenetAgentConfig, Long> {

    StablenetAgentConfig findByAgentId(String id);

    @Query(value = "Select * from #{#entityName} limit ?", nativeQuery = true)
    StablenetAgentConfig findAnyOne(int topN);
}
