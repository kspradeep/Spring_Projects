package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketCapture;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketCaptureRepository extends CrudRepository<PacketCapture, Long> {

    PacketCapture findByDevice_IdAndPort_Id(Long deviceId, Long portId);

    PacketCapture findByDevice_Id(Long deviceId);

    @Query(value = "SELECT port_id  FROM packet_capture WHERE id = ?1", nativeQuery = true)
    Long findPortById(Long id);
}
