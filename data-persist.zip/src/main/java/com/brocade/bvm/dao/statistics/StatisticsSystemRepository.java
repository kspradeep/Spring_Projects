package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.model.db.statistics.SystemUtilizationModel;
import com.brocade.bvm.model.db.statistics.SystemUtilizationStatistics;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.List;
import java.util.Optional;

@Repository
public class StatisticsSystemRepository {
  @Inject private JdbcTemplate jdbcTemplate;

  public SystemUtilizationModel getSystemUtilization(Long deviceId) {
    List<SystemUtilizationModel> sys =
        jdbcTemplate.query(
            "select * from system_utilization_statistics su, collector_device_mapping cd where cd.device_id=? and " +
                    "cd.id=su.collector_device_id and cd.profile_type='SystemUtilization'",
            new Object[] {deviceId},
            systemUtilizationModelRowMapper);
    Optional<SystemUtilizationModel> optionalSystemUtilizationStatistics = sys.stream().findFirst();
    if (optionalSystemUtilizationStatistics.isPresent()) {
      return optionalSystemUtilizationStatistics.get();
    } else {
      return new SystemUtilizationModel();
    }
  }

  private RowMapper<SystemUtilizationModel> systemUtilizationModelRowMapper =
      (ResultSet rs, int row) -> {
        SystemUtilizationModel systemUtilizationStatistics = new SystemUtilizationModel();
        systemUtilizationStatistics.setBuffers(rs.getLong("buffers"));
        systemUtilizationStatistics.setCachedMemory(rs.getLong("cached_memory"));
        systemUtilizationStatistics.setIdleState(rs.getLong("idle_state"));
        systemUtilizationStatistics.setId(rs.getLong("id"));
        systemUtilizationStatistics.setUptime(rs.getLong("uptime"));
        systemUtilizationStatistics.setSystemProcess(rs.getLong("system_process"));
        systemUtilizationStatistics.setUserProcess(rs.getLong("user_process"));
        systemUtilizationStatistics.setKernelFreeMemory(rs.getLong("kernel_free_memory"));
        systemUtilizationStatistics.setUserFreeMemory(rs.getLong("user_free_memory"));
        systemUtilizationStatistics.setTotalFreeMemory(rs.getLong("total_free_memory"));
        systemUtilizationStatistics.setTotalUsedMemory(rs.getLong("total_used_memory"));
        systemUtilizationStatistics.setTotalSystemMemory(rs.getLong("total_system_memory"));
        systemUtilizationStatistics.setLastUpdatedTime(
            rs.getTimestamp("last_updated_time").toString());
        return systemUtilizationStatistics;
      };
}
