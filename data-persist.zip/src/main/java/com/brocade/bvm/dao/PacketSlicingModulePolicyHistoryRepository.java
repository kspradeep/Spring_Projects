package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import com.brocade.bvm.model.db.history.LoadBalanceModulePolicyHistory;
import com.brocade.bvm.model.db.history.PacketSlicingModulePolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by dneelapa on 6/27/2016.
 */
public interface PacketSlicingModulePolicyHistoryRepository extends CrudRepository<PacketSlicingModulePolicyHistory, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PacketSlicingModulePolicyHistory findOne(Long id);

    PacketSlicingModulePolicyHistory findByParentId(Long modulePolicyId);

    @Query(value = "Select ps from #{#entityName} ps where ps.parentId= ?1 AND ps.workflowStatus = ?2 order by ps.revisionTime DESC")
    List<PacketSlicingModulePolicyHistory> findByIdAndWorkflowStatus(Long modulePolicyId, WorkflowParticipant.WorkflowStatus status);
}
