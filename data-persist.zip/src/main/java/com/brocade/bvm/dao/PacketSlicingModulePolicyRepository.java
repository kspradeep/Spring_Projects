package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by dneelapa on 6/27/2016.
 */
public interface PacketSlicingModulePolicyRepository extends CrudRepository<PacketSlicingModulePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PacketSlicingModulePolicy findOne(Long id);

    @Query(value = "select mpm.module_id from module_policy_mapping mpm, packet_slicing_module_policy psp where mpm.module_policy_id=psp.id and mpm.module_id in ?1", nativeQuery = true)
    List<Long> findModulesByModuleIds(List<Long> moduleIds);

    @Query(value = "select pspm.module_policy_id from packet_slicing_port_mapping pspm where pspm.managed_object_id in ?1", nativeQuery = true)
    List<Long> findPoliciesByEgressPorts(List<Long> moduleIds);

    @Query(value = "select pspm.managed_object_id from packet_slicing_port_mapping pspm where pspm.managed_object_id in ?1", nativeQuery = true)
    List<Long> findPortsByEgressPorts(List<Long> egressPortIds);
}
