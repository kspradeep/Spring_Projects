package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.PhysicalInterface;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface PhysicalInterfaceRepository extends CrudRepository<PhysicalInterface, Long> {

    @Query(value = "Select d from #{#entityName} d where d.device.id = ?1")
    List<PhysicalInterface> findByDeviceId(Long deviceId);

    PhysicalInterface findByNameAndDeviceId(String name, Long deviceId);

    PhysicalInterface findByIdAndDeviceId(Long id, Long deviceId);

}
