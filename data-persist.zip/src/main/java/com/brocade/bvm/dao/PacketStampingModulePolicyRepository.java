package com.brocade.bvm.dao;

import com.brocade.bvm.model.db.PacketSlicingModulePolicy;
import com.brocade.bvm.model.db.PacketStampingModulePolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by dneelapa on 6/27/2016.
 */
public interface PacketStampingModulePolicyRepository extends CrudRepository<PacketStampingModulePolicy, Long> {

    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PacketStampingModulePolicy findOne(Long id);

    @Query(value = "select mpm.module_id from module_policy_mapping mpm, packet_stamping_module_policy psp where mpm.module_policy_id = psp.id and mpm.module_id = ?1 and psp.processor_number in ?2", nativeQuery = true)
    List<Long> findModulesPolicyByModuleIdAndProcessorNumber(Long moduleId, List<String> processorNumber);
}
