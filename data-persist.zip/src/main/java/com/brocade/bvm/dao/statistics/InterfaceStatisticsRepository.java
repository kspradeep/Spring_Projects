package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.model.db.statistics.InterfaceStatistics;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface InterfaceStatisticsRepository extends CrudRepository<InterfaceStatistics, Long> {
    @Query(nativeQuery = true, value = "select * from bvm.interface_statistics o where o.port_id=? order by o.last_updated_time desc limit ?")
    List<InterfaceStatistics> findLatestPortById(Long id, int samples);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE FROM interface_statistics WHERE received_time  < DATE_SUB(NOW(), INTERVAL ? SECOND)")
    Integer deleteInterfaceStatistics(Long timeInterval);
}
