package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.model.db.statistics.SystemUtilizationStatistics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

public interface SystemUtilizationStatisticsRepository extends JpaRepository<SystemUtilizationStatistics, Long> {
    @Query(value = "SELECT su FROM #{#entityName} su WHERE su.collectorDeviceMapping.id = ?1")
    Set<SystemUtilizationStatistics> findByDeviceId(Long deviceId);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE FROM system_utilization_statistics WHERE received_time  < DATE_SUB(NOW(), INTERVAL ? SECOND)")
    Integer deleteSystemUtilizationStatistics(Long timeInterval);

    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "DELETE su FROM system_utilization_statistics su , collector_device_mapping cm WHERE su.collector_device_id=cm.id AND cm.device_id=?1")
    Integer deleteSystemUtilizationStatisticsByCollectorId(Long collectorId);

}

