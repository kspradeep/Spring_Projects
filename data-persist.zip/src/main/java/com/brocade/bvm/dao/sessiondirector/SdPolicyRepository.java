package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.SdPolicy;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.Set;

public interface SdPolicyRepository extends CrudRepository<SdPolicy, Long> {

    @Query(value = "SELECT dp FROM #{#entityName} dp WHERE dp.device.id= ?1")
    Set<SdPolicy> findByDeviceId(Long deviceId);
}
