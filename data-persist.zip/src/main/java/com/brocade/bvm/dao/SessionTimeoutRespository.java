package com.brocade.bvm.dao;

import com.brocade.bvm.model.SessionTimeout;
import org.springframework.data.repository.CrudRepository;

public interface SessionTimeoutRespository extends CrudRepository<SessionTimeout, Long> {
    SessionTimeout findByUserName(String userName);
}
