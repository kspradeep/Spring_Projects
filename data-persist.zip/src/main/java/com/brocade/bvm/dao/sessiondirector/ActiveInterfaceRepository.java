package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.sessiondirector.ActiveInterface;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface ActiveInterfaceRepository extends CrudRepository<ActiveInterface, Long> {
    @Query(value = "SELECT ai.id from #{#entityName} ai WHERE ai.filterPolicy.id = ?1")
    List<Long> findActiveInterfaceBasedOnFilterPolicyId(Long filterPolicyId);

    @Query(value = "SELECT ai.id from #{#entityName} ai WHERE ai.samplingPolicy.id = ?1")
    List<Long> findActiveInterfaceBasedOnSamplingPolicyId(Long samplingPolicyId);

    @Query(value = "SELECT ai from #{#entityName} ai JOIN ai.profileInterfaceMapping pim WHERE pim.id=ai.profileInterfaceMapping.id AND pim.profile.device.id = ?1")
    List<ActiveInterface> findAllActiveInterfaceByDeviceId(Long deviceId);

    @Query(value = "SELECT ai from #{#entityName} ai WHERE ai.portGroup.id = ?1")
    List<ActiveInterface> findActiveInterfacesByPortGroupId(Long portGroupId);

    @Query(value = "SELECT ai from #{#entityName} ai JOIN ai.profileInterfaceMapping pim WHERE pim.id=ai.profileInterfaceMapping.id AND pim.profile.device.id = ?1 AND ai.profileInterfaceMapping.id = ?2")
    List<ActiveInterface> findAllActiveInterfaceByDeviceIdAndInterfaceId(Long deviceId, Long interfaceId);

    @Query(value = "SELECT ai.id from #{#entityName} ai JOIN ai.profileInterfaceMapping pim WHERE pim.id=ai.profileInterfaceMapping.id AND pim.profile.device.id = ?1 AND ai.profileInterfaceMapping.id = ?2 AND ai.portGroup.id <> ?3")
    List<Long> findAllActiveInterfaceIdsByDeviceIdInterfaceIdAndPortGroupId(Long deviceId, Long interfaceId, Long portGroupId);

    @Query(value = "SELECT ai from #{#entityName} ai WHERE ai.profileInterfaceMapping.profile.device.id = ?1 AND ai.workflowStatus IN ?2")
    List<ActiveInterface> findByDeviceAndInWorkflowStatus(Long deviceId, List<WorkflowParticipant.WorkflowStatus> notAcceptableStatus);
}
