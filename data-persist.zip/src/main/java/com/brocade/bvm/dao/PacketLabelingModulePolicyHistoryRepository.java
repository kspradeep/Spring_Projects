package com.brocade.bvm.dao;

import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.history.PacketLabelingModulePolicyHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacketLabelingModulePolicyHistoryRepository extends CrudRepository<PacketLabelingModulePolicyHistory, Long> {
    @Query(value = "Select po from #{#entityName} po where po.id = ?1")
    PacketLabelingModulePolicyHistory findOne(Long id);

    PacketLabelingModulePolicyHistory findByParentId(Long modulePolicyId);

    @Query(value = "Select mp from #{#entityName} mp where mp.parentId= ?1 AND mp.workflowStatus = ?2 Order by mp.revisionTime DESC")
    List<PacketLabelingModulePolicyHistory> findByIdAndWorkflowStatus(Long modulePolicyId, WorkflowParticipant.WorkflowStatus status);
}
