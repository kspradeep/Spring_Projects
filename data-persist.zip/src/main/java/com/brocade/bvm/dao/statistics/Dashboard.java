package com.brocade.bvm.dao.statistics;

import lombok.Data;

@Data
public class Dashboard {
    private String userName;
    private String dashboard;
}
