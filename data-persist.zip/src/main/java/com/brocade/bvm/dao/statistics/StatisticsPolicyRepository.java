package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.dao.PolicyRepository;
import com.brocade.bvm.model.WorkflowParticipant;
import com.brocade.bvm.model.db.Device;
import com.brocade.bvm.model.db.Flow;
import com.brocade.bvm.model.db.RuleSet;
import com.brocade.bvm.model.db.statistics.ACLSummary;
import com.brocade.bvm.model.db.statistics.Policy;
import com.brocade.bvm.model.db.statistics.PolicyStatistics;
import com.brocade.bvm.model.db.statistics.PolicyStatisticsWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@Repository
@Slf4j
public class StatisticsPolicyRepository {

    @Inject
    private JdbcTemplate jdbcTemplate;
    @Inject
    private PolicyRepository policyRepository;

    public List<Policy> getPolicies() {
        List<Policy> devicePolicies =
                jdbcTemplate.query(
                        "select po.id, mo.name, (select t.name from target_host t where id=po.device_id) as deviceName from bvm.policy po, bvm.managed_object mo where mo.id=po.id and mo.workflow_status=? and po.device_id IN(select d.id from bvm.device d where d.is_deleted=0 and d.is_reconciled=1 and d.is_profile_configured=1)",
                        new Object[] {"ACTIVE"},
                        policyRowMapper);
        return devicePolicies;
    }

    public int operationalSwitchesPoliciesCount() {
        return jdbcTemplate.queryForObject(
                "select count(*) from bvm.policy p, bvm.managed_object mo where mo.id=p.id "
                        + "and mo.workflow_status='ACTIVE' and p.device_id IN(select d.id from bvm.device d where d.type='SLX' and d.is_deleted=0 and d.is_reconciled=1)",
                Integer.class);
    }

    public PolicyStatisticsWrapper getPolicyStatistics(Long id) {
        PolicyStatisticsWrapper policyStatisticsWrapper = new PolicyStatisticsWrapper();
        final List<PolicyStatistics> policyStatistics = policyStatisticsWrapper.getPolicyStatistics();
        String name = "";
        com.brocade.bvm.model.db.Policy policy = policyRepository.findOne(id);
        if (StringUtils.isEmpty(policy)) {
            log.warn("Policy not available with id {}", id);
            return new PolicyStatisticsWrapper();
        } else {
            Device device = policy.getDevice();
            if (device != null) {
                name = policy.getDevice().getName();
                policyStatisticsWrapper.setName(name);
            }
            if (policy.getWorkflowStatus().equals(WorkflowParticipant.WorkflowStatus.ACTIVE)) {
                List<ACLSummary> aclIds = getPolicyAcl(id);
                aclIds.forEach(acl -> setAclHitCount(acl, policyStatistics));
                if (policyStatistics.size() > 0) {
                    policyStatisticsWrapper.setName(name);
                    policyStatisticsWrapper.setPolicyStatistics(policyStatistics);
                }

                if (policyStatistics.size() <= 0) {
                    AtomicReference<List<PolicyStatistics>> listAtomicReference =
                            new AtomicReference<>(new ArrayList<>());
                    for (Flow flow : policy.getFlows()) {
                        Set<RuleSet> ruleSets = flow.getRuleSets();
                        flow.getIngressPorts()
                                .forEach(
                                        port -> {
                                            PolicyStatistics policyStatistics1 = new PolicyStatistics();
                                            StringBuilder acls = new StringBuilder();
                                            StringBuilder types = new StringBuilder();
                                            policyStatistics1.setPortNumber(port.getName());
                                            ruleSets.forEach(
                                                    ruleSet -> {
                                                        acls.append(ruleSet.getName());
                                                        types.append(ruleSet.getType().name());
                                                    });

                                            policyStatistics1.setAcls(acls.toString());
                                            policyStatistics1.setRule(types.toString());
                                            policyStatistics1.setPacketCount(0L);
                                            listAtomicReference.get().add(policyStatistics1);
                                        });
                    }
                    List<PolicyStatistics> dummy = listAtomicReference.get();
                    if (dummy.size() > 0) {
                        policyStatisticsWrapper.setPolicyStatistics(dummy);
                    }
                } else {
                    return policyStatisticsWrapper;
                }
            }
        }
        return policyStatisticsWrapper;
    }

    private void setAclHitCount(ACLSummary aclSummary, List<PolicyStatistics> policyStatistics) {
        List<PolicyStatistics> statistics = new ArrayList<>();
        statistics = jdbcTemplate.query("select hit_count from acl where acl.acl_statistics_id=? order by last_updated_time DESC limit 1",
                new Object[]{aclSummary.getId()}, policyStatisticsRowMapper);
        PolicyStatistics policyStat = new PolicyStatistics();
        if (statistics.size() > 0) {
            policyStat = statistics.get(0);
            policyStat.setAcls(aclSummary.getName());
            policyStat.setPortNumber(aclSummary.getPort());
        }
        policyStatistics.add(policyStat);
    }

    private RowMapper<PolicyStatistics> policyStatisticsRowMapper = (ResultSet rs, int rowNum) -> {
        PolicyStatistics policyStatistics = new PolicyStatistics();
        policyStatistics.setPacketCount(rs.getLong("hit_count"));
        return policyStatistics;
    };


    private List<ACLSummary> getPolicyAcl(Long id) {
        return jdbcTemplate.query(
                "select acll.id, acll.acl_name, acll.interface_name from bvm.acl_statistics acll where acll.policy_id = ?",
                new Object[]{id},
                aclRowMapper);

    }

    private RowMapper<ACLSummary> aclRowMapper = (ResultSet rs, int rowNum) -> {
        ACLSummary aclSummary = new ACLSummary();
        aclSummary.setId(rs.getLong("id"));
        aclSummary.setName(rs.getString("acl_name"));
        aclSummary.setPort(rs.getString("interface_name"));
        return aclSummary;
    };

    public Map<String, List<String>> getTopFivePolices() {
        Map<String, List<String>> topPolicies = new HashMap<>();
        Map<String, Long> gridPolicy = new HashMap<>();
        Map<String, Long> devicePolicy = new HashMap<>();
        List<String> gridPolicyNames = new ArrayList<>();
        List<String> devicePolicyNames = new ArrayList<>();
        List<Policy> statPolicies = getPolicies();
        List<com.brocade.bvm.model.db.Policy> policies = new ArrayList<>();
        if (statPolicies != null && !statPolicies.isEmpty()) {
            statPolicies.forEach(policy -> policies.add(policyRepository.findOne(policy.getId())));
        }

        try {
            if (Objects.isNull(policies) || policies.isEmpty()) {
                return topPolicies;
            }
            policies.forEach(
                    policy -> {
                        PolicyStatisticsWrapper policyStatisticsWrapper =
                                this.getPolicyStatistics(policy.getId());
                        if (policyStatisticsWrapper != null) {
                            List<PolicyStatistics> policyStatistics =
                                    policyStatisticsWrapper.getPolicyStatistics();
                            if (policy.getObjectType().startsWith("grid")) {
                                AtomicLong counter = new AtomicLong(0);
                                if (policyStatistics != null && !policyStatistics.isEmpty()) {
                                    policyStatistics.forEach(
                                            policyStatistic -> {
                                                if (policyStatistic.getPacketCount() > 0) {
                                                    counter.getAndAdd(policyStatistic.getPacketCount());
                                                }
                                            });
                                }
                                gridPolicy.put(policy.getName(), counter.longValue());
                            } else {
                                AtomicLong counter = new AtomicLong(0);
                                if (policyStatistics != null && !policyStatistics.isEmpty()) {
                                    policyStatistics.forEach(
                                            policyStatistic -> {
                                                if (policyStatistic.getPacketCount() > 0) {
                                                    counter.getAndAdd(policyStatistic.getPacketCount());
                                                }
                                            });
                                }
                                devicePolicy.put(policy.getName(), counter.longValue());
                            }
                        }
                    });

            if (!gridPolicy.isEmpty()) {
                List<String> names = new ArrayList<>();
                Map<String, Long> sortedGrid = sortByValue(gridPolicy);
                sortedGrid.forEach((s, aLong) -> names.add(s));
                if (names.size() > 5) {
                    gridPolicyNames.addAll(names.subList(0, 4));
                } else {
                    gridPolicyNames.addAll(names);
                }
            }
            if (!devicePolicy.isEmpty()) {
                List<String> names = new ArrayList<>();
                Map<String, Long> sortedDevice = sortByValue(devicePolicy);
                sortedDevice.forEach((s, aLong) -> names.add(s));
                if (devicePolicyNames.size() > 5) {
                    devicePolicyNames.addAll(names.subList(0, 4));
                } else {
                    devicePolicyNames.addAll(names);
                }
            }

            topPolicies.put("grid", gridPolicyNames);
            topPolicies.put("device", devicePolicyNames);

        } catch (Exception e) {
        }
        return topPolicies;
    }

//    private RowMapper<PolicyStatistics> policyStatisticsRowMapper =
//            (ResultSet rs, int rowNum) -> {
//                PolicyStatistics policyStatistics = new PolicyStatistics();
//                policyStatistics.setPortNumber(rs.getString("port"));
//                policyStatistics.setPacketCount(rs.getLong("hit_count"));
//                policyStatistics.setAcls(rs.getString("acls"));
//                return policyStatistics;
//            };

    private RowMapper<Policy> policyRowMapper =
            (ResultSet rs, int rowNum) -> {
                Policy policy = new Policy();
                policy.setId(rs.getLong("id"));
                policy.setName(rs.getString("name"));
                policy.setDeviceName(rs.getString("deviceName"));
                return policy;
            };

    private RowMapper<Policy> aclsRowMapper =
            (ResultSet rs, int rowNum) -> {
                Policy policy = new Policy();
                policy.setId(rs.getLong("id"));
                policy.setName(rs.getString("name"));
                return policy;
            };

    private static Map<String, Long> sortByValue(Map<String, Long> unsortMap) {

        List<Map.Entry<String, Long>> list =
                new LinkedList<Map.Entry<String, Long>>(unsortMap.entrySet());
        Collections.sort(
                list,
                new Comparator<Map.Entry<String, Long>>() {
                    public int compare(Map.Entry<String, Long> o1, Map.Entry<String, Long> o2) {
                        return (o1.getValue()).compareTo(o2.getValue());
                    }
                });
        Map<String, Long> sortedMap = new LinkedHashMap<String, Long>();
        for (Map.Entry<String, Long> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }
}
