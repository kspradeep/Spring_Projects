package com.brocade.bvm.dao.statistics;

import com.brocade.bvm.dao.DeviceRepository;
import com.brocade.bvm.dao.PortRepository;
import com.brocade.bvm.dao.statistics.cache.SwitchCache;
import com.brocade.bvm.model.db.statistics.PortBandwidth;
import com.brocade.bvm.model.db.statistics.PortPackets;
import com.brocade.bvm.model.db.statistics.PortUtilization;
import com.brocade.bvm.model.db.statistics.SwitchUtilization;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.sql.ResultSet;
import java.util.*;

@Repository
@Getter
@Slf4j
public class StatisticsSwitchRepository {

  @Inject private JdbcTemplate jdbcTemplate;
  @Inject private DeviceRepository deviceRepository;
  @Inject private SwitchCache switchCache;
  @Inject private InterfaceStatisticsRepository interfaceStatisticsRepository;
  @Inject private PortRepository portRepository;

  // Cache switches from stream
  private Set<PortUtilization> overThresholdPortsError =
      new StatisticsTreeSet<>(Comparator.comparing(PortUtilization::getUtilization));
  private Set<PortUtilization> overThresholdPortsDrop =
      new StatisticsTreeSet<>(Comparator.comparing(PortUtilization::getUtilization));

  public TreeSet<SwitchUtilization> getBottomFiveSwitches() {
    return this.switchCache.getBottomFiveSwitches();
  }

  public TreeSet<SwitchUtilization> getTopFiveSwitches() {
    return this.switchCache.getTopFiveSwitches();
  }

  public List<PortPackets> findDevicePortPacketsInformation(Long deviceId, int samples) {
    List<PortPackets> portPackets = new ArrayList<>();
    try{
      if (deviceId != null && samples > 0) {
        portPackets =
                jdbcTemplate.query(
                        "select i.in_packets, i.out_packets, i.in_octets, i.out_octets, i.in_pkts_per_second, i.out_pkts_per_second, i.last_updated_time, " +
                                "i.received_time from bvm.device_utilization i where i.id=? ORDER by i.last_updated_time DESC limit ?",
                        new Object[] {deviceId, samples},
                        devicePortPacketsRowMapper);
        if (portPackets != null && portPackets.size() > 0) {
          portPackets.sort(Comparator.comparing(PortPackets::getLastUpdatedTime));
        }
      }
    }catch (Exception e) {
      log.error("Error while pulling device packets {}", e.getMessage());
    }

    return portPackets;
  }

  public List<PortBandwidth> findDeviceUtilization(Long deviceId, int samples) {
    Long lineSpeed = getMaxSpeedOfPorts(deviceId);
    List<PortBandwidth> portBandwidths = new ArrayList<>();
    try{
      if (samples > 0) {
        if (deviceId != null) {
          portBandwidths =
                  jdbcTemplate.query(
                          "select i.in_link_utilization, i.out_link_utilization, i.throughput, i.last_updated_time, " +
                                  "i.received_time, i.in_band_width, i.out_band_width from bvm.device_utilization i where" +
                                  " i.id=? ORDER by i.last_updated_time DESC limit ?",
                          new Object[] {deviceId, samples},
                          deviceUtilizationRowMapper);
          if (portBandwidths != null && portBandwidths.size() > 0) {
            portBandwidths.forEach(
                    portBandwidth -> {
                      portBandwidth.setLineSpeed(lineSpeed);
                      if(portBandwidth.getInUtilization() > 100.00) {
                        portBandwidth.setInUtilization(100.00);
                      }
                      if(portBandwidth.getOutUtilization() > 100.00) {
                        portBandwidth.setOutUtilization(100.00);
                      }
                    });
            portBandwidths.sort(Comparator.comparing(PortBandwidth::getLastUpdatedTime));
          }
        }
      }}catch (Exception e) {
      log.error("Error while pulling device utilization {}", e.getMessage());
    }

    return portBandwidths;
  }

  public int findAllStandaloneSwitchesCount() {
    int total =
        jdbcTemplate.queryForObject(
            "select count(*) from bvm.device d where d.is_deleted=0 and d.is_reconciled=1",
            Integer.class);
    return total - findALLGridsSwitchesCount();
  }

  public int findALLGridsSwitchesCount() {
    return jdbcTemplate.queryForObject("select count(*) from bvm.grid_cluster", Integer.class);
  }

  public int findCountOfAllSLXDevices() {
    return jdbcTemplate.queryForObject(
        "select count(*) from bvm.device d where d.type='SLX' and d.is_deleted=0 and d.is_reconciled=1",
        Integer.class);
  }

  public int findCountOfAllMLXEDevices() {
    return jdbcTemplate.queryForObject(
        "select count(*) from bvm.device d where d.type='MLXE' and d.is_deleted=0 and d.is_reconciled=1", Integer.class);
  }

  public int findAllSDDevicesCount() {
    return jdbcTemplate.queryForObject(
        "select count(*) from bvm.device d where d.type='SD' and d.is_deleted=0 and d.is_reconciled=1", Integer.class);
  }

  public int findAllActiveSwitchesCount() {
    return jdbcTemplate.queryForObject(
        "select count(*) from bvm.device d where d.is_reconciled = 1 AND"
            + " d.is_deleted = 0 and d.type='SLX'",
        Integer.class);
  }

  public List<Long> findALLSLXDevices() {
    try {
      return jdbcTemplate.query(
          "select d.id from bvm.device d where d.is_reconciled = 1 AND"
              + " d.is_deleted = 0 and d.type='SLX'",
          deviceIDs);
    } catch (EmptyResultDataAccessException e) {
      log.error("No SLX devices found");
      return new ArrayList<>();
    }
  }

  private RowMapper<Long> deviceIDs =
      (ResultSet rs, int row) -> {
        return rs.getLong("id");
      };

  private RowMapper<Long> rowMapper = (ResultSet rs, int row) -> rs.getLong("id");

  private RowMapper<PortPackets> devicePortPacketsRowMapper =
      (ResultSet rs, int rowNum) -> {
        PortPackets portPackets = new PortPackets();
        portPackets.setInBytes(rs.getLong("in_octets"));
        portPackets.setOutBytes(rs.getLong("out_octets"));
        portPackets.setInPackets(rs.getLong("in_packets"));
        portPackets.setOutPackets(rs.getLong("out_packets"));
        portPackets.setInPPS(rs.getLong("in_pkts_per_second"));
        portPackets.setOutPPS(rs.getLong("out_pkts_per_second"));
        portPackets.setLastUpdatedTime(rs.getTimestamp("i.last_updated_time").toString());
        return portPackets;
      };

  private RowMapper<PortBandwidth> deviceUtilizationRowMapper =
      (ResultSet rs, int rowNum) -> {
        PortBandwidth portBandwidth = new PortBandwidth();
        portBandwidth.setInUtilization(rs.getDouble("i.in_link_utilization"));
        portBandwidth.setLastUpdatedTime(rs.getTimestamp("i.last_updated_time").toString());
        portBandwidth.setOutUtilization(rs.getDouble("i.out_link_utilization"));
        portBandwidth.setThroughput(rs.getLong("i.throughput"));
        portBandwidth.setInBandwidth(rs.getLong("i.in_band_width"));
        portBandwidth.setOutBandwidth(rs.getLong("i.out_band_width"));
        return portBandwidth;
      };

  private List<Long> getPortsByCollector(Long colletorId) {
    return jdbcTemplate.query(
        "select i.port_id from interface_statistics i where i.collector_device_id=?",
        new Object[] {colletorId},
        (rs, rowNum) -> rs.getLong("port_id"));
  }

  private Long getMaxSpeedOfPorts(Long id) {
    Long maxSpeed = null;
    if (id != null) {
      try {
        maxSpeed =
            jdbcTemplate.queryForObject(
                "select sum(max_speed) from port p where p.module_id=(select id from module where device_id=?)",
                new Object[] {id},
                Long.class);
      } catch (DataAccessException e) {
        log.error("Error while getting maz speed of all ports of a device {}", e.getMessage());
      }
    }
    return maxSpeed;
  }
}
