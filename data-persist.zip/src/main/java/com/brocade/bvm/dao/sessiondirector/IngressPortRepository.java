package com.brocade.bvm.dao.sessiondirector;

import com.brocade.bvm.model.db.sessiondirector.IngressPort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface IngressPortRepository extends CrudRepository<IngressPort, Long> {

    List<IngressPort> findByDeviceId(Long deviceId);

    @Query(value = "Select i from #{#entityName} i where i.device.id = ?1 and i.profile.id = ?2")
    List<IngressPort> findByDeviceIdAndProfileId(Long deviceId, Long profileId);

    @Query(value = "Select i.id from #{#entityName} i where i.servicePort.id in (?1)")
    List<Long> findByServicePortIds(List<Long> servicePortIds);

    @Query(value = "Select i from #{#entityName} i where i.name = ?1 and i.profile.id = ?2 and i.device.id = ?3")
    IngressPort findByNameAndProfileIdAndDeviceId(String name, Long profileId, Long deviceId);

    List<IngressPort> findByPhysicalInterfaceIdAndDeviceId(Long physicalInterfaceId, Long deviceId);

}
