package com.brocade.bvm.util;

import java.text.DecimalFormat;

public class Converter {
  public static final double GB = 1024 * 1024 * 1024;

  public static double formatBytes(long bytes) {
    double d = bytes / GB;
    DecimalFormat df = new DecimalFormat("#.00");
    return Double.parseDouble(df.format(d));
  }

  public static String formatBytesInBMKGTPE(long bytes) {
    int unit = 1024;
    if (bytes < unit) return bytes + " B";
    int exp = (int) (Math.log(bytes) / Math.log(unit));
    String pre = ("KMGTPE").charAt(exp - 1) + "";
    return String.format("%.1f %sB", bytes / Math.pow(unit, exp), pre);
  }
}
