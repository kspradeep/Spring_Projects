package com.brocade.bvm.util;

import jdk.nashorn.internal.runtime.regexp.joni.Regex;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.StreamUtils;

import java.io.File;
import java.nio.charset.Charset;

@Slf4j
public class SQLFileLoader {
    public static String loadQueryFromFile(@NonNull String fileName) {
        try {
            Resource resource = new ClassPathResource("database"+ File.separator + fileName);
            return StreamUtils.copyToString(resource.getInputStream(), Charset.defaultCharset()).replace("\\t|\\n|\\r", "");
        } catch (Exception e) {
            log.error("Error occurred during loading sql file to string, file=" + fileName, e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
