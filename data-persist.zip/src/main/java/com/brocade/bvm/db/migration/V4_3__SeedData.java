package com.brocade.bvm.db.migration;

import org.flywaydb.core.api.migration.spring.BaseSpringJdbcMigration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * This class clear the existing FLEX_MATCH_HEADER_JSON entry in application_constant table.
 */
public class V4_3__SeedData extends BaseSpringJdbcMigration {

    @Override
    public void migrate(JdbcTemplate jdbcTemplate) throws Exception {
        String removedApplicationConstant = "delete from application_constant where name = 'FLEX_MATCH_HEADER_JSON'";
        jdbcTemplate.update(removedApplicationConstant);
    }
}