package com.brocade.bvm.db.migration;

import com.brocade.bvm.model.db.admin.ApplicationConfig;
import org.flywaydb.core.api.migration.spring.BaseSpringJdbcMigration;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class V6_1__SeedData extends BaseSpringJdbcMigration {

    @Override
    public void migrate(JdbcTemplate jdbcTemplate) throws Exception {
        List<String> configs = new ArrayList<>();
        configs.add(ApplicationConfig.Key.OpenStackUsername.toString());
        configs.add(ApplicationConfig.Key.OpenStackPassword.toString());
        configs.add(ApplicationConfig.Key.OpenStackRestUrl.toString());

        String sql = "DELETE FROM application_config where config_key = ?";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                String key = configs.get(i);
                ps.setString(1, key);
            }

            @Override
            public int getBatchSize() {
                return configs.size();
            }
        });
    }
}
