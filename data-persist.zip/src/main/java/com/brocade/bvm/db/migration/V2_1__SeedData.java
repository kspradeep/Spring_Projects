package com.brocade.bvm.db.migration;

import com.brocade.bvm.model.db.admin.ApplicationConfig;
import org.flywaydb.core.api.migration.spring.BaseSpringJdbcMigration;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class V2_1__SeedData extends BaseSpringJdbcMigration {

    @Override
    public void migrate(JdbcTemplate jdbcTemplate) throws Exception {
        List<ApplicationConfig> configs = new ArrayList<>();
        configs.add(new ApplicationConfig(ApplicationConfig.Key.OpenStackRestUrl, ""));
        configs.add(new ApplicationConfig(ApplicationConfig.Key.OpenStackUsername, "bvm_user"));
        configs.add(new ApplicationConfig(ApplicationConfig.Key.OpenStackPassword, "password"));

        String sql = "INSERT INTO application_config VALUES (?, ?, ?)";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ApplicationConfig config = configs.get(i);
                ps.setLong(1, i + 9);
                ps.setString(2, config.getKey().name());
                ps.setString(3, config.getRawValue());
            }

            @Override
            public int getBatchSize() {
                return configs.size();
            }
        });
    }
}
