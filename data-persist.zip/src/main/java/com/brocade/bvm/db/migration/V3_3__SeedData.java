package com.brocade.bvm.db.migration;

import com.brocade.bvm.model.db.admin.ApplicationConfig;
import org.flywaydb.core.api.migration.spring.BaseSpringJdbcMigration;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class adds the ODL configuration properties to application_config table
 */
public class V3_3__SeedData extends BaseSpringJdbcMigration {
    @Override
    public void migrate(JdbcTemplate jdbcTemplate) {
        List<ApplicationConfig> configs = new ArrayList<>();
        configs.add(new ApplicationConfig(ApplicationConfig.Key.OdlRestUrl, "http://10.37.133.168:8181/restconf"));
        configs.add(new ApplicationConfig(ApplicationConfig.Key.OdlUsername, "admin"));
/*        configs.add(new ApplicationConfig(ApplicationConfig.Key.OdlPassword, "admin"));configs.add(new ApplicationConfig(ApplicationConfig.Key.StablenetJobId, "1007"));
        configs.add(new ApplicationConfig(ApplicationConfig.Key.StablenetDeleteJobId, "1006"));
        configs.add(new ApplicationConfig(ApplicationConfig.Key.StablenetRediscoverJobId, "1008"));*/

        String sqlMaxId = "SELECT max(id) FROM application_config";
        Long idMax = jdbcTemplate.queryForObject(sqlMaxId, Long.class);

        String sql = "INSERT INTO application_config VALUES (?, ?, ?)";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ApplicationConfig config = configs.get(i);
                ps.setLong(1, (i + idMax + 1));
                ps.setString(2, config.getKey().name());
                ps.setString(3, config.getRawValue());
            }

            @Override
            public int getBatchSize() {
                return configs.size();
            }
        });
    }
}
