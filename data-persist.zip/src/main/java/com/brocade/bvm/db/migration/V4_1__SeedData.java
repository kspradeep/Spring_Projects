package com.brocade.bvm.db.migration;

import org.flywaydb.core.api.migration.spring.BaseSpringJdbcMigration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * This class sets the is_reconciled flag to true for devices which are discovered earlier.
 */
public class V4_1__SeedData extends BaseSpringJdbcMigration {

    @Override
    public void migrate(JdbcTemplate jdbcTemplate) throws Exception {
        String updateDevice = "update device set is_reconciled = 1 where type in ('SLX', 'MLXE')";
        jdbcTemplate.update(updateDevice);
    }
}
